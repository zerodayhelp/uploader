<?php
// ⚠️ REMPLACE CES VALEURS PAR TES INFORMATIONS TELEGRAM
define('TELEGRAM_BOT_TOKEN', '1234567890:ABCdefGHIjklmNOPqrstUVwxyz'); // Ton token de bot Telegram
define('TELEGRAM_CHAT_ID', '123456789'); // Ton chat ID Telegram
?>
