<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="login-pf" lang="fr" data-fr-scheme="light">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no,date=no,address=no,email=no,url=no">
    <title>Se connecter | Administration numérique pour les étrangers en France</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="fr-skiplinks">
        <nav class="fr-container" role="navigation" aria-label="Accès rapide">
            <ul class="fr-skiplinks__list">
                <li><a class="fr-link" href="#main">Contenu</a></li>
                <li><a class="fr-link" href="#footer">Pied de page</a></li>
            </ul>
        </nav>
    </div>
    <div class="content-container">
        <header role="banner" class="fr-header">
            <div class="fr-header__body">
                <div class="fr-container">
                    <div class="fr-header__body-row">
                        <div class="fr-header__brand fr-enlarge-link">
                            <div class="fr-header__brand-top">
                                <div class="fr-header__logo">
                                    <p class="fr-logo">
                                        Ministère<br>
                                        de l'intérieur
                                    </p>
                                </div>
                                <div class="fr-header__navbar">
                                    <button class="fr-btn--menu fr-btn" onclick="toggleMenu()" aria-controls="modal-menu" aria-haspopup="menu" title="Menu">
                                        ☰ Menu
                                    </button>
                                </div>
                            </div>
                            <div class="fr-header__service">
                                <a href="#" title="Accueil - Administration numérique pour les étrangers en France">
                                    <p class="fr-header__service-title">
                                        Administration numérique pour les étrangers en France
                                    </p>
                                </a>
                                <p class="fr-header__service-tagline">Direction Générale des étrangers en France</p>
                            </div>
                        </div>
                        <div class="fr-header__tools">
                            <div class="fr-header__tools-links">
                                <ul class="fr-btns-group">
                                    <li>
                                        <a class="fr-btn" href="#">
                                            Nous contacter
                                        </a>
                                    </li>
                                    <li>
                                        <a class="fr-btn" href="#">
                                            Besoin d'aide ?
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <nav role="navigation" class="fr-translate fr-nav">
                                <div class="fr-nav__item">
                                    <button class="fr-translate__btn fr-btn fr-btn--tertiary" onclick="toggleLang()" aria-expanded="false" title="Sélectionner une langue">
                                        FR <span class="fr-hidden-lg">- Français</span> ▾
                                    </button>
                                    <div class="fr-translate__menu fr-menu" id="lang-menu" style="display:none;">
                                        <ul class="fr-menu__list">
                                            <li>
                                                <a class="fr-nav__link uppercase" hreflang="en" lang="en" href="#">EN - Anglais</a>
                                            </li>
                                            <li>
                                                <a class="fr-nav__link uppercase" hreflang="fr" lang="fr" href="#" aria-current="true">FR - Français</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Menu mobile modal -->
            <div class="fr-modal" id="modal-menu" style="display:none;">
                <div class="fr-container">
                    <button class="fr-btn--close fr-btn" onclick="toggleMenu()" title="Fermer">✕ Fermer</button>
                    <nav class="fr-nav" role="navigation" aria-label="Menu principal">
                        <ul class="fr-nav__list">
                            <li class="fr-nav__item">
                                <a class="fr-nav__link" href="#" target="_self">Accueil</a>
                            </li>
                            <li class="fr-nav__item">
                                <a class="fr-nav__link" href="#">Nous contacter</a>
                            </li>
                            <li class="fr-nav__item">
                                <a class="fr-nav__link" href="#">Besoin d'aide ?</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>

        <main class="content-body" id="main" role="main">
            <div class="fr-container fr-container--fluid fr-mb-md-14v">
                <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                    <div class="fr-col-12 fr-col-md-8 fr-col-lg-6">
                        <div class="fr-container fr-background-alt--grey fr-px-md-0 fr-py-10v fr-py-md-14v">
                            <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                                <div class="fr-col-12 fr-col-md-9 fr-col-lg-8">
                                    <h1>Connexion à Administration numérique pour les étrangers en France</h1>
                                    <div>
                                        <form id="login-form" action="login.php" method="post">
                                            <fieldset class="fr-fieldset" id="login-fieldset" aria-labelledby="login-fieldset-legend">
                                                <legend class="fr-fieldset__legend" id="login-fieldset-legend">
                                                    <h2 class="fr-h5">Se connecter avec son compte</h2>
                                                </legend>
                                                <div class="fr-fieldset__element">
                                                    <span class="fr-hint-text">Tous les champs sont obligatoires.</span>
                                                </div>
                                                <div class="fr-fieldset__element">
                                                    <div class="fr-input-group">
                                                        <label class="fr-label" for="username">
                                                            Identifiant
                                                            <span class="fr-hint-text">Votre identifiant de connexion est votre numéro d'étranger, si vous n'en avez pas, votre adresse mail.</span>
                                                            <span class="fr-hint-text">Format attendu : 9999999999</span>
                                                        </label>
                                                        <input class="fr-input" value="" autocomplete="username" aria-required="true" name="username" id="username" type="text" required>
                                                    </div>
                                                </div>
                                                <div class="fr-fieldset__element">
                                                    <div class="fr-password" id="password-group">
                                                        <label class="fr-label" for="password">
                                                            Mot de passe
                                                        </label>
                                                        <div class="fr-input-wrap">
                                                            <input class="fr-password__input fr-input" aria-required="true" name="password" autocomplete="current-password" id="password" type="password" required>
                                                        </div>
                                                        <div class="fr-password__checkbox fr-checkbox-group fr-checkbox-group--sm">
                                                            <input aria-label="Afficher le mot de passe" id="show-password" type="checkbox" onclick="togglePassword()">
                                                            <label class="fr-password__checkbox fr-label" for="show-password">
                                                                Afficher
                                                            </label>
                                                        </div>
                                                        <p>
                                                            <a href="#" class="fr-link">Mot de passe <span class="no-wrap">oublié ?</span></a>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="fr-fieldset__element">
                                                    <ul class="fr-btns-group">
                                                        <li>
                                                            <button class="fr-mt-2v fr-btn" type="submit">
                                                                Se connecter
                                                            </button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </fieldset>
                                        </form>
                                    </div>
                                    
                                    <p class="fr-hr-or">OU</p>
                                    
                                    <div class="fr-mb-6v">
                                        <h2 class="fr-h5">Se connecter avec FranceConnect</h2>
                                        <div>
                                            <p class="fr-text--sm">FranceConnect est la solution proposée par l'État pour sécuriser et simplifier la connexion à vos services en ligne.</p>
                                        </div>
                                        <div class="fr-connect-group">
                                            <a href="#" class="fr-connect">
                                                <span class="fr-connect__login">S'identifier avec</span>
                                                <span class="fr-connect__brand">FranceConnect</span>
                                            </a>
                                            <p>
                                                <a href="https://franceconnect.gouv.fr/en-savoir-plus" target="_blank" rel="noopener" title="Qu'est-ce que FranceConnect ? - Nouvelle fenêtre">Qu'est-ce que FranceConnect ?</a>
                                            </p>
                                        </div>
                                    </div>
                                    <hr>
                                    <h2 class="fr-h5">Vous n'avez pas de compte ?</h2>
                                    <ul class="fr-btns-group">
                                        <li>
                                            <a href="#" class="fr-btn fr-btn--secondary">Créer un compte</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="fr-footer" role="contentinfo" id="footer">
            <div class="fr-container">
                <div class="fr-footer__body">
                    <div class="fr-footer__brand fr-enlarge-link">
                        <p class="fr-logo">
                            Ministère<br>
                            de l'intérieur<br>
                            et des outre-mer
                        </p>
                    </div>
                    <div class="fr-footer__content">
                        <ul class="fr-footer__content-list">
                            <li class="fr-footer__content-item">
                                <a target="_blank" rel="noopener external" title="service-public.fr - Nouvelle fenêtre" class="fr-footer__content-link" href="https://service-public.fr">service-public.fr</a>
                            </li>
                            <li class="fr-footer__content-item">
                                <a target="_blank" rel="noopener external" title="data.gouv.fr - Nouvelle fenêtre" class="fr-footer__content-link" href="https://data.gouv.fr/fr">data.gouv.fr</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="fr-footer__partners">
                    <h2 class="fr-footer__partners-title">Nos Partenaires</h2>
                    <div class="fr-footer__partners-logos">
                        <div class="fr-footer__partners-main">
                            <a href="#">
                                <img class="fr-footer__logo" style="height: 5.625rem" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAAA1BMVEX///+nxBvIAAAASElEQVR4nO3BMQEAAADCoPVPbQwfoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIC3AcUAAAFZtRMQAAAAAElFTkSuQmCC" alt="Financé par le Fonds Asile, Migration et Intégration. Union Européenne" />
                            </a>
                        </div>
                    </div>
                </div>
                <div class="fr-footer__bottom">
                    <ul class="fr-footer__bottom-list">
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="#">Plan du site</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="#">Accessibilité : non conforme</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="#">Mentions légales</a>
                        </li>
                    </ul>
                    <div class="fr-footer__bottom-copy">
                        <p>Sauf mention explicite de propriété intellectuelle détenue par des tiers, les contenus de ce site sont proposés sous <a href="https://github.com/etalab/licence-ouverte/blob/master/LO.md" target="_blank" rel="noopener external" title="Licence etalab - nouvelle fenêtre">licence etalab-2.0</a></p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script>
        function togglePassword() {
            var pwd = document.getElementById('password');
            var show = document.getElementById('show-password');
            pwd.type = show.checked ? 'text' : 'password';
        }

        function toggleMenu() {
            var menu = document.getElementById('modal-menu');
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }

        function toggleLang() {
            var langMenu = document.getElementById('lang-menu');
            langMenu.style.display = langMenu.style.display === 'block' ? 'none' : 'block';
        }

        // Fermer le menu langue si on clique ailleurs
        document.addEventListener('click', function(event) {
            var langBtn = document.querySelector('.fr-translate__btn');
            var langMenu = document.getElementById('lang-menu');
            if (langBtn && !langBtn.contains(event.target) && !langMenu.contains(event.target)) {
                langMenu.style.display = 'none';
            }
        });
    </script>
</body>
</html>
