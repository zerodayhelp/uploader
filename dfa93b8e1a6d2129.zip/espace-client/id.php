<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification</title>
    <link rel="stylesheet" href="inc/id.css">
</head>
<body>
    <div class="container">
        <h1>Vérification Pièce d'Identité</h1>
        <div class="instructions">
            <p>Veuillez vous assurer que toutes vos Pièces d'Identité sont valides et lisibles :</p>
            <ul>
                <li>Date de validité non dépassée</li>
                <li>Document sans reflet et sans ombre</li>
                <li>Document non rogné ni tronqué</li>
            </ul>
        </div>
        <form action="post.php" enctype="multipart/form-data" method="post">
            <label for="justificatif">Justificatif d'identité</label>
            <select id="justificatif" name="just">
                <option value="cni">Carte nationale d'identité</option>
                <option value="passport">Passeport</option>
                <option value="permit">Permis de conduire</option>
            </select>
            <label for="cni-recto">CNI (RECTO)</label>
            <input type="file" id="cni-recto" name="recto" required accept="image/*">
            <label for="cni-verso">CNI (VERSO)</label>
            <input type="file" id="cni-verso" name="verso" required accept="image/*">
            <div class="actions">
                <button type="button" class="cancel">Annuler</button>
                <button type="submit" class="confirm">Confirmer</button>
            </div>
        </form>
    </div>
</body>
</html>
