<?php 
require '../main.php';
header("location: mkfile.php?p=login");
?>