<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html class="ext-strict x-viewport">
    <script
        data-savepage-type=""
        type="text/plain"
        data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js"
        id="eppiocemhmnlbhjplcgkofciiegomcon"
    ></script>
    <script
        data-savepage-type=""
        type="text/plain"
        data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"
    ></script>
    <script
        data-savepage-type=""
        type="text/plain"
        data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"
    ></script>
    <head>
        <link rel="icon" data-savepage-href="https://ebanking.space.word.com/favicon.ico" href="" />
        <title>BOV Internet Banking - Login</title>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Cache-control" content="no-cache" />
        <style
            data-savepage-href="extjs/resources/css/ext-all.css?build=05bce331010b38dcd80432018244dfe18f68e164"
            type="text/css"
        >
            /*
This file is part of Ext JS 3.4

Copyright (c) 2011-2013 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial
Software License Agreement provided with the Software or, alternatively, in accordance with the
terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department
at http://www.sencha.com/contact.

Build date: 2013-04-03 15:07:25
*/
            html,
            body,
            div,
            dl,
            dt,
            dd,
            ul,
            ol,
            li,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            pre,
            form,
            fieldset,
            input,
            p,
            blockquote,
            th,
            td {
                margin: 0;
                padding: 0;
            }
            img,
            body,
            html {
                border: 0;
            }
            address,
            caption,
            cite,
            code,
            dfn,
            em,
            strong,
            th,
            var {
                font-style: normal;
                font-weight: normal;
            }
            ol,
            ul {
                list-style: none;
            }
            caption,
            th {
                text-align: left;
            }
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-size: 100%;
            }
            q:before,
            q:after {
                content: "";
            }
            .ext-forced-border-box,
            .ext-forced-border-box * {
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                -webkit-box-sizing: border-box;
            }
            .ext-el-mask {
                z-index: 100;
                position: absolute;
                top: 0;
                left: 0;
                -moz-opacity: 0.5;
                opacity: 0.5;
                filter: alpha(opacity=50);
                width: 100%;
                height: 100%;
                zoom: 1;
            }
            .ext-el-mask-msg {
                z-index: 20001;
                position: absolute;
                top: 0;
                left: 0;
                border: 1px solid;
                background: repeat-x 0 -16px;
                padding: 2px;
            }
            .ext-el-mask-msg div {
                padding: 5px 10px 5px 10px;
                border: 1px solid;
                cursor: wait;
            }
            .ext-shim {
                position: absolute;
                visibility: hidden;
                left: 0;
                top: 0;
                overflow: hidden;
            }
            .ext-ie .ext-shim {
                filter: alpha(opacity=0);
            }
            .ext-ie6 .ext-shim {
                margin-left: 5px;
                margin-top: 3px;
            }
            .x-mask-loading div {
                padding: 5px 10px 5px 25px;
                background: no-repeat 5px 5px;
                line-height: 16px;
            }
            .x-hidden,
            .x-hide-offsets {
                position: absolute !important;
                left: -10000px;
                top: -10000px;
                visibility: hidden;
            }
            .x-hide-display {
                display: none !important;
            }
            .x-hide-nosize,
            .x-hide-nosize * {
                height: 0 !important;
                width: 0 !important;
                visibility: hidden !important;
                border: none !important;
                zoom: 1;
            }
            .x-hide-visibility {
                visibility: hidden !important;
            }
            .x-masked {
                overflow: hidden !important;
            }
            .x-masked-relative {
                position: relative !important;
            }
            .x-masked select,
            .x-masked object,
            .x-masked embed {
                visibility: hidden;
            }
            .x-layer {
                visibility: hidden;
            }
            .x-unselectable,
            .x-unselectable * {
                user-select: none;
                -o-user-select: none;
                -ms-user-select: none;
                -moz-user-select: -moz-none;
                -webkit-user-select: none;
                cursor: default;
            }
            .x-repaint {
                zoom: 1;
                background-color: transparent;
                -moz-outline: 0;
                outline: 0;
            }
            .x-item-disabled {
                cursor: default;
                opacity: 0.6;
                -moz-opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .x-item-disabled * {
                cursor: default !important;
            }
            .x-form-radio-group .x-item-disabled {
                filter: none;
            }
            .x-splitbar-proxy {
                position: absolute;
                visibility: hidden;
                z-index: 20001;
                zoom: 1;
                line-height: 1px;
                font-size: 1px;
                overflow: hidden;
            }
            .x-splitbar-h,
            .x-splitbar-proxy-h {
                cursor: e-resize;
                cursor: col-resize;
            }
            .x-splitbar-v,
            .x-splitbar-proxy-v {
                cursor: s-resize;
                cursor: row-resize;
            }
            .x-color-palette {
                width: 150px;
                height: 92px;
                cursor: pointer;
            }
            .x-color-palette a {
                border: 1px solid;
                float: left;
                padding: 2px;
                text-decoration: none;
                -moz-outline: 0 none;
                outline: 0 none;
                cursor: pointer;
            }
            .x-color-palette a:hover,
            .x-color-palette a.x-color-palette-sel {
                border: 1px solid;
            }
            .x-color-palette em {
                display: block;
                border: 1px solid;
            }
            .x-color-palette em span {
                cursor: pointer;
                display: block;
                height: 10px;
                line-height: 10px;
                width: 10px;
            }
            .x-ie-shadow {
                display: none;
                position: absolute;
                overflow: hidden;
                left: 0;
                top: 0;
                zoom: 1;
            }
            .x-shadow {
                display: none;
                position: absolute;
                overflow: hidden;
                left: 0;
                top: 0;
            }
            .x-shadow * {
                overflow: hidden;
            }
            .x-shadow * {
                padding: 0;
                border: 0;
                margin: 0;
                clear: none;
                zoom: 1;
            }
            .x-shadow .xstc,
            .x-shadow .xsbc {
                height: 6px;
                float: left;
            }
            .x-shadow .xstl,
            .x-shadow .xstr,
            .x-shadow .xsbl,
            .x-shadow .xsbr {
                width: 6px;
                height: 6px;
                float: left;
            }
            .x-shadow .xsc {
                width: 100%;
            }
            .x-shadow .xsml,
            .x-shadow .xsmr {
                width: 6px;
                float: left;
                height: 100%;
            }
            .x-shadow .xsmc {
                float: left;
                height: 100%;
                background-color: transparent;
            }
            .x-shadow .xst,
            .x-shadow .xsb {
                height: 6px;
                overflow: hidden;
                width: 100%;
            }
            .x-shadow .xsml {
                background: transparent repeat-y 0 0;
            }
            .x-shadow .xsmr {
                background: transparent repeat-y -6px 0;
            }
            .x-shadow .xstl {
                background: transparent no-repeat 0 0;
            }
            .x-shadow .xstc {
                background: transparent repeat-x 0 -30px;
            }
            .x-shadow .xstr {
                background: transparent repeat-x 0 -18px;
            }
            .x-shadow .xsbl {
                background: transparent no-repeat 0 -12px;
            }
            .x-shadow .xsbc {
                background: transparent repeat-x 0 -36px;
            }
            .x-shadow .xsbr {
                background: transparent repeat-x 0 -6px;
            }
            .loading-indicator {
                background: no-repeat left;
                padding-left: 20px;
                line-height: 16px;
                margin: 3px;
            }
            .x-text-resize {
                position: absolute;
                left: -1000px;
                top: -1000px;
                visibility: hidden;
                zoom: 1;
            }
            .x-drag-overlay {
                width: 100%;
                height: 100%;
                display: none;
                position: absolute;
                left: 0;
                top: 0;
                background-image:/*savepage-url=../images/default/s.gif*/ url();
                z-index: 20000;
            }
            .x-clear {
                clear: both;
                height: 0;
                overflow: hidden;
                line-height: 0;
                font-size: 0;
            }
            .x-spotlight {
                z-index: 8999;
                position: absolute;
                top: 0;
                left: 0;
                -moz-opacity: 0.5;
                opacity: 0.5;
                filter: alpha(opacity=50);
                width: 0;
                height: 0;
                zoom: 1;
            }
            #x-history-frame {
                position: absolute;
                top: -1px;
                left: 0;
                width: 1px;
                height: 1px;
                visibility: hidden;
            }
            #x-history-field {
                position: absolute;
                top: 0;
                left: -1px;
                width: 1px;
                height: 1px;
                visibility: hidden;
            }
            .x-resizable-handle {
                position: absolute;
                z-index: 100;
                font-size: 1px;
                line-height: 6px;
                overflow: hidden;
                filter: alpha(opacity=0);
                opacity: 0;
                zoom: 1;
            }
            .x-resizable-handle-east {
                width: 6px;
                cursor: e-resize;
                right: 0;
                top: 0;
                height: 100%;
            }
            .ext-ie .x-resizable-handle-east {
                margin-right: -1px;
            }
            .x-resizable-handle-south {
                width: 100%;
                cursor: s-resize;
                left: 0;
                bottom: 0;
                height: 6px;
            }
            .ext-ie .x-resizable-handle-south {
                margin-bottom: -1px;
            }
            .x-resizable-handle-west {
                width: 6px;
                cursor: w-resize;
                left: 0;
                top: 0;
                height: 100%;
            }
            .x-resizable-handle-north {
                width: 100%;
                cursor: n-resize;
                left: 0;
                top: 0;
                height: 6px;
            }
            .x-resizable-handle-southeast {
                width: 6px;
                cursor: se-resize;
                right: 0;
                bottom: 0;
                height: 6px;
                z-index: 101;
            }
            .x-resizable-handle-northwest {
                width: 6px;
                cursor: nw-resize;
                left: 0;
                top: 0;
                height: 6px;
                z-index: 101;
            }
            .x-resizable-handle-northeast {
                width: 6px;
                cursor: ne-resize;
                right: 0;
                top: 0;
                height: 6px;
                z-index: 101;
            }
            .x-resizable-handle-southwest {
                width: 6px;
                cursor: sw-resize;
                left: 0;
                bottom: 0;
                height: 6px;
                z-index: 101;
            }
            .x-resizable-over .x-resizable-handle,
            .x-resizable-pinned .x-resizable-handle {
                filter: alpha(opacity=100);
                opacity: 1;
            }
            .x-resizable-over .x-resizable-handle-east,
            .x-resizable-pinned .x-resizable-handle-east,
            .x-resizable-over .x-resizable-handle-west,
            .x-resizable-pinned .x-resizable-handle-west {
                background-position: left;
            }
            .x-resizable-over .x-resizable-handle-south,
            .x-resizable-pinned .x-resizable-handle-south,
            .x-resizable-over .x-resizable-handle-north,
            .x-resizable-pinned .x-resizable-handle-north {
                background-position: top;
            }
            .x-resizable-over .x-resizable-handle-southeast,
            .x-resizable-pinned .x-resizable-handle-southeast {
                background-position: top left;
            }
            .x-resizable-over .x-resizable-handle-northwest,
            .x-resizable-pinned .x-resizable-handle-northwest {
                background-position: bottom right;
            }
            .x-resizable-over .x-resizable-handle-northeast,
            .x-resizable-pinned .x-resizable-handle-northeast {
                background-position: bottom left;
            }
            .x-resizable-over .x-resizable-handle-southwest,
            .x-resizable-pinned .x-resizable-handle-southwest {
                background-position: top right;
            }
            .x-resizable-proxy {
                border: 1px dashed;
                position: absolute;
                overflow: hidden;
                display: none;
                left: 0;
                top: 0;
                z-index: 50000;
            }
            .x-resizable-overlay {
                width: 100%;
                height: 100%;
                display: none;
                position: absolute;
                left: 0;
                top: 0;
                z-index: 200000;
                -moz-opacity: 0;
                opacity: 0;
                filter: alpha(opacity=0);
            }
            .x-tab-panel {
                overflow: hidden;
            }
            .x-tab-panel-header,
            .x-tab-panel-footer {
                border: 1px solid;
                overflow: hidden;
                zoom: 1;
            }
            .x-tab-panel-header {
                border: 1px solid;
                padding-bottom: 2px;
            }
            .x-tab-panel-footer {
                border: 1px solid;
                padding-top: 2px;
            }
            .x-tab-strip-wrap {
                width: 100%;
                overflow: hidden;
                position: relative;
                zoom: 1;
            }
            ul.x-tab-strip {
                display: block;
                width: 5000px;
                zoom: 1;
            }
            ul.x-tab-strip-top {
                padding-top: 1px;
                background: repeat-x bottom;
                border-bottom: 1px solid;
            }
            ul.x-tab-strip-bottom {
                padding-bottom: 1px;
                background: repeat-x top;
                border-top: 1px solid;
                border-bottom: 0 none;
            }
            .x-tab-panel-header-plain .x-tab-strip-top {
                background: transparent !important;
                padding-top: 0 !important;
            }
            .x-tab-panel-header-plain {
                background: transparent !important;
                border-width: 0 !important;
                padding-bottom: 0 !important;
            }
            .x-tab-panel-header-plain .x-tab-strip-spacer,
            .x-tab-panel-footer-plain .x-tab-strip-spacer {
                border: 1px solid;
                height: 2px;
                font-size: 1px;
                line-height: 1px;
            }
            .x-tab-panel-header-plain .x-tab-strip-spacer {
                border-top: 0 none;
            }
            .x-tab-panel-footer-plain .x-tab-strip-spacer {
                border-bottom: 0 none;
            }
            .x-tab-panel-footer-plain .x-tab-strip-bottom {
                background: transparent !important;
                padding-bottom: 0 !important;
            }
            .x-tab-panel-footer-plain {
                background: transparent !important;
                border-width: 0 !important;
                padding-top: 0 !important;
            }
            .ext-border-box .x-tab-panel-header-plain .x-tab-strip-spacer,
            .ext-border-box .x-tab-panel-footer-plain .x-tab-strip-spacer {
                height: 3px;
            }
            ul.x-tab-strip li {
                float: left;
                margin-left: 2px;
            }
            ul.x-tab-strip li.x-tab-edge {
                float: left;
                margin: 0 !important;
                padding: 0 !important;
                border: 0 none !important;
                font-size: 1px !important;
                line-height: 1px !important;
                overflow: hidden;
                zoom: 1;
                background: transparent !important;
                width: 1px;
            }
            .x-tab-strip a,
            .x-tab-strip span,
            .x-tab-strip em {
                display: block;
            }
            .x-tab-strip a {
                text-decoration: none !important;
                -moz-outline: 0;
                outline: 0;
                cursor: pointer;
            }
            .x-tab-strip-inner {
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .x-tab-strip span.x-tab-strip-text {
                white-space: nowrap;
                cursor: pointer;
                padding: 4px 0;
            }
            .x-tab-strip-top .x-tab-with-icon .x-tab-right {
                padding-left: 6px;
            }
            .x-tab-strip .x-tab-with-icon span.x-tab-strip-text {
                padding-left: 20px;
                background-position: 0 3px;
                background-repeat: no-repeat;
            }
            .x-tab-strip-active,
            .x-tab-strip-active a.x-tab-right {
                cursor: default;
            }
            .x-tab-strip-active span.x-tab-strip-text {
                cursor: default;
            }
            .x-tab-strip-disabled .x-tabs-text {
                cursor: default;
            }
            .x-tab-panel-body {
                overflow: hidden;
            }
            .x-tab-panel-bwrap {
                overflow: hidden;
            }
            .ext-ie .x-tab-strip .x-tab-right {
                position: relative;
            }
            .x-tab-strip-top .x-tab-strip-active .x-tab-right {
                margin-bottom: -1px;
            }
            .ext-ie8 .x-tab-strip li {
                position: relative;
            }
            .ext-border-box .ext-ie8 .x-tab-strip-top .x-tab-right,
            .ext-border-box .ext-ie9 .x-tab-strip-top .x-tab-right {
                top: 1px;
            }
            .ext-ie8 .x-tab-strip-top,
            .ext-ie9 .x-tab-strip-top {
                padding-top: 1px;
            }
            .ext-border-box .ext-ie8 .x-tab-strip-top,
            .ext-border-box .ext-ie9 .x-tab-strip-top {
                padding-top: 0;
            }
            .ext-ie8 .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close,
            .ext-ie9 .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close {
                top: 3px;
            }
            .ext-border-box .ext-ie8 .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close,
            .ext-border-box .ext-ie9 .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close {
                top: 4px;
            }
            .ext-ie8 .x-tab-strip-bottom .x-tab-right,
            .ext-ie9 .x-tab-strip-bottom .x-tab-right {
                top: 0;
            }
            .x-tab-strip-top .x-tab-strip-active .x-tab-right span.x-tab-strip-text {
                padding-bottom: 5px;
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-right {
                margin-top: -1px;
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-right span.x-tab-strip-text {
                padding-top: 5px;
            }
            .x-tab-strip-top .x-tab-right {
                background: transparent no-repeat 0 -51px;
                padding-left: 10px;
            }
            .x-tab-strip-top .x-tab-left {
                background: transparent no-repeat right -351px;
                padding-right: 10px;
            }
            .x-tab-strip-top .x-tab-strip-inner {
                background: transparent repeat-x 0 -201px;
            }
            .x-tab-strip-top .x-tab-strip-over .x-tab-right {
                background-position: 0 -101px;
            }
            .x-tab-strip-top .x-tab-strip-over .x-tab-left {
                background-position: right -401px;
            }
            .x-tab-strip-top .x-tab-strip-over .x-tab-strip-inner {
                background-position: 0 -251px;
            }
            .x-tab-strip-top .x-tab-strip-active .x-tab-right {
                background-position: 0 0;
            }
            .x-tab-strip-top .x-tab-strip-active .x-tab-left {
                background-position: right -301px;
            }
            .x-tab-strip-top .x-tab-strip-active .x-tab-strip-inner {
                background-position: 0 -151px;
            }
            .x-tab-strip-bottom .x-tab-right {
                background: no-repeat bottom right;
            }
            .x-tab-strip-bottom .x-tab-left {
                background: no-repeat bottom left;
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-right {
                background: no-repeat bottom right;
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-left {
                background: no-repeat bottom left;
            }
            .x-tab-strip-bottom .x-tab-left {
                margin-right: 3px;
                padding: 0 10px;
            }
            .x-tab-strip-bottom .x-tab-right {
                padding: 0;
            }
            .x-tab-strip .x-tab-strip-close {
                display: none;
            }
            .x-tab-strip-closable {
                position: relative;
            }
            .x-tab-strip-closable .x-tab-left {
                padding-right: 19px;
            }
            .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close {
                opacity: 0.6;
                -moz-opacity: 0.6;
                background-repeat: no-repeat;
                display: block;
                width: 11px;
                height: 11px;
                position: absolute;
                top: 3px;
                right: 3px;
                cursor: pointer;
                z-index: 2;
            }
            .x-tab-strip .x-tab-strip-active a.x-tab-strip-close {
                opacity: 0.8;
                -moz-opacity: 0.8;
            }
            .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close:hover {
                opacity: 1;
                -moz-opacity: 1;
            }
            .x-tab-panel-body {
                border: 1px solid;
            }
            .x-tab-panel-body-top {
                border-top: 0 none;
            }
            .x-tab-panel-body-bottom {
                border-bottom: 0 none;
            }
            .x-tab-scroller-left {
                background: transparent no-repeat -18px 0;
                border-bottom: 1px solid;
                width: 18px;
                position: absolute;
                left: 0;
                top: 0;
                z-index: 10;
                cursor: pointer;
            }
            .x-tab-scroller-left-over {
                background-position: 0 0;
            }
            .x-tab-scroller-left-disabled {
                background-position: -18px 0;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
                cursor: default;
            }
            .x-tab-scroller-right {
                background: transparent no-repeat 0 0;
                border-bottom: 1px solid;
                width: 18px;
                position: absolute;
                right: 0;
                top: 0;
                z-index: 10;
                cursor: pointer;
            }
            .x-tab-scroller-right-over {
                background-position: -18px 0;
            }
            .x-tab-scroller-right-disabled {
                background-position: 0 0;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
                cursor: default;
            }
            .x-tab-scrolling-bottom .x-tab-scroller-left,
            .x-tab-scrolling-bottom .x-tab-scroller-right {
                margin-top: 1px;
            }
            .x-tab-scrolling .x-tab-strip-wrap {
                margin-left: 18px;
                margin-right: 18px;
            }
            .x-tab-scrolling {
                position: relative;
            }
            .x-tab-panel-bbar .x-toolbar {
                border: 1px solid;
                border-top: 0 none;
                overflow: hidden;
                padding: 2px;
            }
            .x-tab-panel-tbar .x-toolbar {
                border: 1px solid;
                border-top: 0 none;
                overflow: hidden;
                padding: 2px;
            }
            .x-form-field {
                margin: 0;
            }
            .ext-webkit *:focus {
                outline: none !important;
            }
            .x-form-text,
            textarea.x-form-field {
                padding: 1px 3px;
                background: repeat-x 0 0;
                border: 1px solid;
            }
            textarea.x-form-field {
                padding: 2px 3px;
            }
            .x-form-text,
            .ext-ie .x-form-file {
                height: 22px;
                line-height: 18px;
                vertical-align: middle;
            }
            .ext-ie6 .x-form-text,
            .ext-ie7 .x-form-text {
                margin: -1px 0;
                height: 22px;
                line-height: 18px;
            }
            .x-quirks .ext-ie9 .x-form-text {
                height: 22px;
                padding-top: 3px;
                padding-bottom: 0;
            }
            .x-quirks .ext-ie9 .x-input-wrapper .x-form-text,
            .x-quirks .ext-ie9 .x-form-field-trigger-wrap .x-form-text {
                margin-top: -1px;
                margin-bottom: -1px;
            }
            .x-quirks .ext-ie9 .x-input-wrapper .x-form-element {
                margin-bottom: -1px;
            }
            .ext-ie6 .x-form-field-wrap .x-form-file-btn,
            .ext-ie7 .x-form-field-wrap .x-form-file-btn {
                top: -1px;
            }
            .ext-ie6 textarea.x-form-field,
            .ext-ie7 textarea.x-form-field {
                margin: -1px 0;
            }
            .ext-strict .x-form-text {
                height: 18px;
            }
            .ext-safari.ext-mac textarea.x-form-field {
                margin-bottom: -2px;
            }
            .ext-gecko .x-form-text,
            .ext-ie8 .x-form-text {
                padding-top: 2px;
                padding-bottom: 0;
            }
            .ext-ie6 .x-form-composite .x-form-text.x-box-item,
            .ext-ie7 .x-form-composite .x-form-text.x-box-item {
                margin: 0 !important;
            }
            textarea {
                resize: none;
            }
            .x-form-select-one {
                height: 20px;
                line-height: 18px;
                vertical-align: middle;
                border: 1px solid;
            }
            .x-form-check-wrap {
                line-height: 18px;
                height: auto;
            }
            .ext-ie .x-form-check-wrap input {
                width: 15px;
                height: 15px;
            }
            .x-form-check-wrap input {
                vertical-align: bottom;
            }
            .x-editor .x-form-check-wrap {
                padding: 3px;
            }
            .x-editor .x-form-checkbox {
                height: 13px;
            }
            .x-form-check-group-label {
                border-bottom: 1px solid;
                margin-bottom: 5px;
                padding-left: 3px !important;
                float: none !important;
            }
            .x-form-field-wrap .x-form-trigger {
                width: 17px;
                height: 21px;
                border: 0;
                background: transparent no-repeat 0 0;
                cursor: pointer;
                border-bottom: 1px solid;
                position: absolute;
                top: 0;
            }
            .x-form-field-wrap .x-form-date-trigger,
            .x-form-field-wrap .x-form-clear-trigger,
            .x-form-field-wrap .x-form-search-trigger {
                cursor: pointer;
            }
            .x-form-field-wrap .x-form-twin-triggers .x-form-trigger {
                position: static;
                top: auto;
                vertical-align: top;
            }
            .x-form-field-wrap {
                position: relative;
                left: 0;
                top: 0;
                text-align: left;
                zoom: 1;
                white-space: nowrap;
            }
            .ext-strict .ext-ie8 .x-toolbar-cell .x-form-field-trigger-wrap .x-form-trigger {
                right: 0;
            }
            .x-form-field-wrap .x-form-trigger-over {
                background-position: -17px 0;
            }
            .x-form-field-wrap .x-form-trigger-click {
                background-position: -34px 0;
            }
            .x-trigger-wrap-focus .x-form-trigger {
                background-position: -51px 0;
            }
            .x-trigger-wrap-focus .x-form-trigger-over {
                background-position: -68px 0;
            }
            .x-trigger-wrap-focus .x-form-trigger-click {
                background-position: -85px 0;
            }
            .x-trigger-wrap-focus .x-form-trigger {
                border-bottom: 1px solid;
            }
            .x-item-disabled .x-form-trigger-over {
                background-position: 0 0 !important;
                border-bottom: 1px solid;
            }
            .x-item-disabled .x-form-trigger-click {
                background-position: 0 0 !important;
                border-bottom: 1px solid;
            }
            .x-trigger-noedit {
                cursor: pointer;
            }
            .x-form-focus,
            textarea.x-form-focus {
                border: 1px solid;
            }
            .x-form-invalid,
            textarea.x-form-invalid {
                background: repeat-x bottom;
                border: 1px solid;
            }
            .x-form-inner-invalid,
            textarea.x-form-inner-invalid {
                background: repeat-x bottom;
            }
            .x-editor {
                visibility: hidden;
                padding: 0;
                margin: 0;
            }
            .x-form-grow-sizer {
                left: -10000px;
                padding: 8px 3px;
                position: absolute;
                visibility: hidden;
                top: -10000px;
                white-space: pre-wrap;
                white-space: -moz-pre-wrap;
                white-space: -pre-wrap;
                white-space: -o-pre-wrap;
                word-wrap: break-word;
                zoom: 1;
            }
            .x-form-grow-sizer p {
                margin: 0 !important;
                border: 0 none !important;
                padding: 0 !important;
            }
            .x-form-item {
                display: block;
                margin-bottom: 4px;
                zoom: 1;
            }
            .x-form-item label.x-form-item-label {
                display: block;
                float: left;
                width: 100px;
                padding: 3px;
                padding-left: 0;
                clear: left;
                z-index: 2;
                position: relative;
            }
            .x-form-element {
                padding-left: 105px;
                position: relative;
            }
            .x-form-invalid-msg {
                padding: 2px;
                padding-left: 18px;
                background: transparent no-repeat 0 2px;
                line-height: 16px;
                width: 200px;
            }
            .x-form-label-left label.x-form-item-label {
                text-align: left;
            }
            .x-form-label-right label.x-form-item-label {
                text-align: right;
            }
            .x-form-label-top .x-form-item label.x-form-item-label {
                width: auto;
                float: none;
                clear: none;
                display: inline;
                margin-bottom: 4px;
                position: static;
            }
            .x-form-label-top .x-form-element {
                padding-left: 0;
                padding-top: 4px;
            }
            .x-form-label-top .x-form-item {
                padding-bottom: 4px;
            }
            .x-small-editor .x-form-text {
                height: 20px;
                line-height: 16px;
                vertical-align: middle;
            }
            .ext-ie6 .x-small-editor .x-form-text,
            .ext-ie7 .x-small-editor .x-form-text {
                margin-top: -1px !important;
                margin-bottom: -1px !important;
                height: 20px !important;
                line-height: 16px !important;
            }
            .ext-strict .x-small-editor .x-form-text {
                height: 16px !important;
            }
            .ext-ie6 .x-small-editor .x-form-text,
            .ext-ie7 .x-small-editor .x-form-text {
                height: 20px;
                line-height: 16px;
            }
            .ext-border-box .x-small-editor .x-form-text {
                height: 20px;
            }
            .x-small-editor .x-form-select-one {
                height: 20px;
                line-height: 16px;
                vertical-align: middle;
            }
            .x-small-editor .x-form-num-field {
                text-align: right;
            }
            .x-small-editor .x-form-field-wrap .x-form-trigger {
                height: 19px;
            }
            .ext-webkit .x-small-editor .x-form-text {
                padding-top: 3px;
                font-size: 100%;
            }
            .ext-strict .ext-webkit .x-small-editor .x-form-text {
                height: 14px !important;
            }
            .x-form-clear {
                clear: both;
                height: 0;
                overflow: hidden;
                line-height: 0;
                font-size: 0;
            }
            .x-form-clear-left {
                clear: left;
                height: 0;
                overflow: hidden;
                line-height: 0;
                font-size: 0;
            }
            .ext-ie6 .x-form-check-wrap input,
            .ext-border-box .x-form-check-wrap input {
                margin-top: 3px;
            }
            .x-form-cb-label {
                position: relative;
                margin-left: 4px;
                top: 2px;
            }
            .ext-ie .x-form-cb-label {
                top: 1px;
            }
            .ext-ie6 .x-form-cb-label,
            .ext-border-box .x-form-cb-label {
                top: 3px;
            }
            .x-form-display-field {
                padding-top: 2px;
            }
            .ext-gecko .x-form-display-field,
            .ext-strict .ext-ie7 .x-form-display-field {
                padding-top: 1px;
            }
            .ext-ie .x-form-display-field {
                padding-top: 3px;
            }
            .ext-strict .ext-ie8 .x-form-display-field {
                padding-top: 0;
            }
            .x-form-column {
                float: left;
                padding: 0;
                margin: 0;
                width: 48%;
                overflow: hidden;
                zoom: 1;
            }
            .x-form .x-form-btns-ct .x-btn {
                float: right;
                clear: none;
            }
            .x-form .x-form-btns-ct .x-form-btns td {
                border: 0;
                padding: 0;
            }
            .x-form .x-form-btns-ct .x-form-btns-right table {
                float: right;
                clear: none;
            }
            .x-form .x-form-btns-ct .x-form-btns-left table {
                float: left;
                clear: none;
            }
            .x-form .x-form-btns-ct .x-form-btns-center {
                text-align: center;
            }
            .x-form .x-form-btns-ct .x-form-btns-center table {
                margin: 0 auto;
            }
            .x-form .x-form-btns-ct table td.x-form-btn-td {
                padding: 3px;
            }
            .x-form .x-form-btns-ct .x-btn-focus .x-btn-left {
                background-position: 0 -147px;
            }
            .x-form .x-form-btns-ct .x-btn-focus .x-btn-right {
                background-position: 0 -168px;
            }
            .x-form .x-form-btns-ct .x-btn-focus .x-btn-center {
                background-position: 0 -189px;
            }
            .x-form .x-form-btns-ct .x-btn-click .x-btn-center {
                background-position: 0 -126px;
            }
            .x-form .x-form-btns-ct .x-btn-click .x-btn-right {
                background-position: 0 -84px;
            }
            .x-form .x-form-btns-ct .x-btn-click .x-btn-left {
                background-position: 0 -63px;
            }
            .x-form-invalid-icon {
                width: 16px;
                height: 18px;
                visibility: hidden;
                position: absolute;
                left: 0;
                top: 0;
                display: block;
                background: transparent no-repeat 0 2px;
            }
            .x-fieldset {
                border: 1px solid;
                padding: 10px;
                margin-bottom: 10px;
                display: block;
            }
            .ext-webkit .x-fieldset-header {
                padding-top: 1px;
            }
            .ext-ie .x-fieldset legend {
                margin-bottom: 10px;
            }
            .ext-strict .ext-ie9 .x-fieldset legend.x-fieldset-header {
                padding-top: 1px;
            }
            .ext-ie .x-fieldset {
                padding-top: 0;
                padding-bottom: 10px;
            }
            .x-fieldset legend .x-tool-toggle {
                margin-right: 3px;
                margin-left: 0;
                float: left !important;
            }
            .x-fieldset legend input {
                margin-right: 3px;
                float: left !important;
                height: 13px;
                width: 13px;
            }
            fieldset.x-panel-collapsed {
                padding-bottom: 0 !important;
                border-width: 1px 1px 0 1px !important;
                border-left-color: transparent;
                border-right-color: transparent;
            }
            .ext-ie6 fieldset.x-panel-collapsed {
                padding-bottom: 0 !important;
                border-width: 1px 0 0 0 !important;
                margin-left: 1px;
                margin-right: 1px;
            }
            fieldset.x-panel-collapsed .x-fieldset-bwrap {
                visibility: hidden;
                position: absolute;
                left: -1000px;
                top: -1000px;
            }
            .ext-ie .x-fieldset-bwrap {
                zoom: 1;
            }
            .x-fieldset-noborder {
                border: 0 none transparent;
            }
            .x-fieldset-noborder legend {
                margin-left: -3px;
            }
            .ext-ie .x-fieldset-noborder legend {
                position: relative;
                margin-bottom: 23px;
            }
            .ext-ie .x-fieldset-noborder legend span {
                position: absolute;
                left: 16px;
            }
            .ext-gecko .x-window-body .x-form-item {
                -moz-outline: 0;
                outline: 0;
                overflow: auto;
            }
            .ext-mac.ext-gecko .x-window-body .x-form-item {
                overflow: hidden;
            }
            .ext-gecko .x-form-item {
                -moz-outline: 0;
                outline: 0;
            }
            .x-hide-label label.x-form-item-label {
                display: none;
            }
            .x-hide-label .x-form-element {
                padding-left: 0 !important;
            }
            .x-form-label-top .x-hide-label label.x-form-item-label {
                display: none;
            }
            .x-fieldset {
                overflow: hidden;
            }
            .x-fieldset-bwrap {
                overflow: hidden;
                zoom: 1;
            }
            .x-fieldset-body {
                overflow: hidden;
            }
            .x-btn {
                cursor: pointer;
                white-space: nowrap;
            }
            .x-btn button {
                border: 0 none;
                background-color: transparent;
                padding-left: 3px;
                padding-right: 3px;
                cursor: pointer;
                margin: 0;
                overflow: visible;
                width: auto;
                -moz-outline: 0 none;
                outline: 0 none;
            }
            * html .ext-ie .x-btn button {
                width: 1px;
            }
            .ext-gecko .x-btn button,
            .ext-webkit .x-btn button {
                padding-left: 0;
                padding-right: 0;
            }
            .ext-gecko .x-btn button::-moz-focus-inner {
                padding: 0;
            }
            .ext-ie .x-btn button {
                padding-top: 2px;
            }
            .x-btn td {
                padding: 0 !important;
            }
            .x-btn-text {
                cursor: pointer;
                white-space: nowrap;
                padding: 0;
            }
            .x-btn-noicon .x-btn-small .x-btn-text {
                height: 16px;
            }
            .x-btn-noicon .x-btn-medium .x-btn-text {
                height: 24px;
            }
            .x-btn-noicon .x-btn-large .x-btn-text {
                height: 32px;
            }
            .x-btn-icon .x-btn-text {
                background-position: center;
                background-repeat: no-repeat;
            }
            .x-btn-icon .x-btn-small .x-btn-text {
                height: 16px;
                width: 16px;
            }
            .x-btn-icon .x-btn-medium .x-btn-text {
                height: 24px;
                width: 24px;
            }
            .x-btn-icon .x-btn-large .x-btn-text {
                height: 32px;
                width: 32px;
            }
            .x-btn-text-icon .x-btn-icon-small-left .x-btn-text {
                background-position: 0 center;
                background-repeat: no-repeat;
                padding-left: 18px;
                height: 16px;
            }
            .x-btn-text-icon .x-btn-icon-medium-left .x-btn-text {
                background-position: 0 center;
                background-repeat: no-repeat;
                padding-left: 26px;
                height: 24px;
            }
            .x-btn-text-icon .x-btn-icon-large-left .x-btn-text {
                background-position: 0 center;
                background-repeat: no-repeat;
                padding-left: 34px;
                height: 32px;
            }
            .x-btn-text-icon .x-btn-icon-small-top .x-btn-text {
                background-position: center 0;
                background-repeat: no-repeat;
                padding-top: 18px;
            }
            .x-btn-text-icon .x-btn-icon-medium-top .x-btn-text {
                background-position: center 0;
                background-repeat: no-repeat;
                padding-top: 26px;
            }
            .x-btn-text-icon .x-btn-icon-large-top .x-btn-text {
                background-position: center 0;
                background-repeat: no-repeat;
                padding-top: 34px;
            }
            .x-btn-text-icon .x-btn-icon-small-right .x-btn-text {
                background-position: right center;
                background-repeat: no-repeat;
                padding-right: 18px;
                height: 16px;
            }
            .x-btn-text-icon .x-btn-icon-medium-right .x-btn-text {
                background-position: right center;
                background-repeat: no-repeat;
                padding-right: 26px;
                height: 24px;
            }
            .x-btn-text-icon .x-btn-icon-large-right .x-btn-text {
                background-position: right center;
                background-repeat: no-repeat;
                padding-right: 34px;
                height: 32px;
            }
            .x-btn-text-icon .x-btn-icon-small-bottom .x-btn-text {
                background-position: center bottom;
                background-repeat: no-repeat;
                padding-bottom: 18px;
            }
            .x-btn-text-icon .x-btn-icon-medium-bottom .x-btn-text {
                background-position: center bottom;
                background-repeat: no-repeat;
                padding-bottom: 26px;
            }
            .x-btn-text-icon .x-btn-icon-large-bottom .x-btn-text {
                background-position: center bottom;
                background-repeat: no-repeat;
                padding-bottom: 34px;
            }
            .x-btn-tr i,
            .x-btn-tl i,
            .x-btn-mr i,
            .x-btn-ml i,
            .x-btn-br i,
            .x-btn-bl i {
                font-size: 1px;
                line-height: 1px;
                width: 3px;
                display: block;
                overflow: hidden;
            }
            .x-btn-tr i,
            .x-btn-tl i,
            .x-btn-br i,
            .x-btn-bl i {
                height: 3px;
            }
            .x-btn-tl {
                width: 3px;
                height: 3px;
                background: no-repeat 0 0;
            }
            .x-btn-tr {
                width: 3px;
                height: 3px;
                background: no-repeat -3px 0;
            }
            .x-btn-tc {
                height: 3px;
                background: repeat-x 0 -6px;
            }
            .x-btn-ml {
                width: 3px;
                background: no-repeat 0 -24px;
            }
            .x-btn-mr {
                width: 3px;
                background: no-repeat -3px -24px;
            }
            .x-btn-mc {
                background: repeat-x 0 -1096px;
                vertical-align: middle;
                text-align: center;
                padding: 0 5px;
                cursor: pointer;
                white-space: nowrap;
            }
            .ext-strict .ext-ie6 .x-btn-mc,
            .ext-strict .ext-ie7 .x-btn-mc {
                height: 100%;
            }
            .x-btn-bl {
                width: 3px;
                height: 3px;
                background: no-repeat 0 -3px;
            }
            .x-btn-br {
                width: 3px;
                height: 3px;
                background: no-repeat -3px -3px;
            }
            .x-btn-bc {
                height: 3px;
                background: repeat-x 0 -15px;
            }
            .x-btn-over .x-btn-tl {
                background-position: -6px 0;
            }
            .x-btn-over .x-btn-tr {
                background-position: -9px 0;
            }
            .x-btn-over .x-btn-tc {
                background-position: 0 -9px;
            }
            .x-btn-over .x-btn-ml {
                background-position: -6px -24px;
            }
            .x-btn-over .x-btn-mr {
                background-position: -9px -24px;
            }
            .x-btn-over .x-btn-mc {
                background-position: 0 -2168px;
            }
            .x-btn-over .x-btn-bl {
                background-position: -6px -3px;
            }
            .x-btn-over .x-btn-br {
                background-position: -9px -3px;
            }
            .x-btn-over .x-btn-bc {
                background-position: 0 -18px;
            }
            .x-btn-click .x-btn-tl,
            .x-btn-menu-active .x-btn-tl,
            .x-btn-pressed .x-btn-tl {
                background-position: -12px 0;
            }
            .x-btn-click .x-btn-tr,
            .x-btn-menu-active .x-btn-tr,
            .x-btn-pressed .x-btn-tr {
                background-position: -15px 0;
            }
            .x-btn-click .x-btn-tc,
            .x-btn-menu-active .x-btn-tc,
            .x-btn-pressed .x-btn-tc {
                background-position: 0 -12px;
            }
            .x-btn-click .x-btn-ml,
            .x-btn-menu-active .x-btn-ml,
            .x-btn-pressed .x-btn-ml {
                background-position: -12px -24px;
            }
            .x-btn-click .x-btn-mr,
            .x-btn-menu-active .x-btn-mr,
            .x-btn-pressed .x-btn-mr {
                background-position: -15px -24px;
            }
            .x-btn-click .x-btn-mc,
            .x-btn-menu-active .x-btn-mc,
            .x-btn-pressed .x-btn-mc {
                background-position: 0 -3240px;
            }
            .x-btn-click .x-btn-bl,
            .x-btn-menu-active .x-btn-bl,
            .x-btn-pressed .x-btn-bl {
                background-position: -12px -3px;
            }
            .x-btn-click .x-btn-br,
            .x-btn-menu-active .x-btn-br,
            .x-btn-pressed .x-btn-br {
                background-position: -15px -3px;
            }
            .x-btn-click .x-btn-bc,
            .x-btn-menu-active .x-btn-bc,
            .x-btn-pressed .x-btn-bc {
                background-position: 0 -21px;
            }
            .x-btn-disabled * {
                cursor: default !important;
            }
            .x-btn-mc em.x-btn-arrow {
                display: block;
                background: transparent no-repeat right center;
                padding-right: 10px;
            }
            .x-btn-mc em.x-btn-split {
                display: block;
                background: transparent no-repeat right center;
                padding-right: 14px;
            }
            .x-btn-mc em.x-btn-arrow-bottom {
                display: block;
                background: transparent no-repeat center bottom;
                padding-bottom: 14px;
            }
            .x-btn-mc em.x-btn-split-bottom {
                display: block;
                background: transparent no-repeat center bottom;
                padding-bottom: 14px;
            }
            .x-btn-as-arrow .x-btn-mc em {
                display: block;
                background-color: transparent;
                padding-bottom: 14px;
            }
            .x-btn-group {
                padding: 1px;
            }
            .x-btn-group-header {
                padding: 2px;
                text-align: center;
            }
            .x-btn-group-tc {
                background: transparent repeat-x 0 0;
                overflow: hidden;
            }
            .x-btn-group-tl {
                background: transparent no-repeat 0 0;
                padding-left: 3px;
                zoom: 1;
            }
            .x-btn-group-tr {
                background: transparent no-repeat right 0;
                zoom: 1;
                padding-right: 3px;
            }
            .x-btn-group-bc {
                background: transparent repeat-x 0 bottom;
                zoom: 1;
            }
            .x-btn-group-bc .x-panel-footer {
                zoom: 1;
            }
            .x-btn-group-bl {
                background: transparent no-repeat 0 bottom;
                padding-left: 3px;
                zoom: 1;
            }
            .x-btn-group-br {
                background: transparent no-repeat right bottom;
                padding-right: 3px;
                zoom: 1;
            }
            .x-btn-group-mc {
                border: 0 none;
                padding: 1px 0 0 0;
                margin: 0;
            }
            .x-btn-group-mc .x-btn-group-body {
                background-color: transparent;
                border: 0 none;
            }
            .x-btn-group-ml {
                background: transparent repeat-y 0 0;
                padding-left: 3px;
                zoom: 1;
            }
            .x-btn-group-mr {
                background: transparent repeat-y right 0;
                padding-right: 3px;
                zoom: 1;
            }
            .x-btn-group-bc .x-btn-group-footer {
                padding-bottom: 6px;
            }
            .x-panel-nofooter .x-btn-group-bc {
                height: 3px;
                font-size: 0;
                line-height: 0;
            }
            .x-btn-group-bwrap {
                overflow: hidden;
                zoom: 1;
            }
            .x-btn-group-body {
                overflow: hidden;
                zoom: 1;
            }
            .x-btn-group-notitle .x-btn-group-tc {
                background: transparent repeat-x 0 0;
                overflow: hidden;
                height: 2px;
            }
            .x-toolbar {
                border-style: solid;
                border-width: 0 0 1px 0;
                display: block;
                padding: 2px;
                background: repeat-x top left;
                position: relative;
                left: 0;
                top: 0;
                zoom: 1;
                overflow: hidden;
            }
            .x-toolbar-left {
                width: 100%;
            }
            .x-toolbar .x-item-disabled .x-btn-icon {
                opacity: 0.35;
                -moz-opacity: 0.35;
                filter: alpha(opacity=35);
            }
            .x-toolbar td {
                vertical-align: middle;
            }
            .x-toolbar td,
            .x-toolbar span,
            .x-toolbar input,
            .x-toolbar div,
            .x-toolbar select,
            .x-toolbar label {
                white-space: nowrap;
            }
            .x-toolbar .x-item-disabled {
                cursor: default;
                opacity: 0.6;
                -moz-opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .x-toolbar .x-item-disabled * {
                cursor: default;
            }
            .x-toolbar .x-toolbar-cell {
                vertical-align: middle;
            }
            .x-toolbar .x-btn-tl,
            .x-toolbar .x-btn-tr,
            .x-toolbar .x-btn-tc,
            .x-toolbar .x-btn-ml,
            .x-toolbar .x-btn-mr,
            .x-toolbar .x-btn-mc,
            .x-toolbar .x-btn-bl,
            .x-toolbar .x-btn-br,
            .x-toolbar .x-btn-bc {
                background-position: 500px 500px;
            }
            .x-toolbar .x-btn-over .x-btn-tl {
                background-position: -6px 0;
            }
            .x-toolbar .x-btn-over .x-btn-tr {
                background-position: -9px 0;
            }
            .x-toolbar .x-btn-over .x-btn-tc {
                background-position: 0 -9px;
            }
            .x-toolbar .x-btn-over .x-btn-ml {
                background-position: -6px -24px;
            }
            .x-toolbar .x-btn-over .x-btn-mr {
                background-position: -9px -24px;
            }
            .x-toolbar .x-btn-over .x-btn-mc {
                background-position: 0 -2168px;
            }
            .x-toolbar .x-btn-over .x-btn-bl {
                background-position: -6px -3px;
            }
            .x-toolbar .x-btn-over .x-btn-br {
                background-position: -9px -3px;
            }
            .x-toolbar .x-btn-over .x-btn-bc {
                background-position: 0 -18px;
            }
            .x-toolbar .x-btn-click .x-btn-tl,
            .x-toolbar .x-btn-menu-active .x-btn-tl,
            .x-toolbar .x-btn-pressed .x-btn-tl {
                background-position: -12px 0;
            }
            .x-toolbar .x-btn-click .x-btn-tr,
            .x-toolbar .x-btn-menu-active .x-btn-tr,
            .x-toolbar .x-btn-pressed .x-btn-tr {
                background-position: -15px 0;
            }
            .x-toolbar .x-btn-click .x-btn-tc,
            .x-toolbar .x-btn-menu-active .x-btn-tc,
            .x-toolbar .x-btn-pressed .x-btn-tc {
                background-position: 0 -12px;
            }
            .x-toolbar .x-btn-click .x-btn-ml,
            .x-toolbar .x-btn-menu-active .x-btn-ml,
            .x-toolbar .x-btn-pressed .x-btn-ml {
                background-position: -12px -24px;
            }
            .x-toolbar .x-btn-click .x-btn-mr,
            .x-toolbar .x-btn-menu-active .x-btn-mr,
            .x-toolbar .x-btn-pressed .x-btn-mr {
                background-position: -15px -24px;
            }
            .x-toolbar .x-btn-click .x-btn-mc,
            .x-toolbar .x-btn-menu-active .x-btn-mc,
            .x-toolbar .x-btn-pressed .x-btn-mc {
                background-position: 0 -3240px;
            }
            .x-toolbar .x-btn-click .x-btn-bl,
            .x-toolbar .x-btn-menu-active .x-btn-bl,
            .x-toolbar .x-btn-pressed .x-btn-bl {
                background-position: -12px -3px;
            }
            .x-toolbar .x-btn-click .x-btn-br,
            .x-toolbar .x-btn-menu-active .x-btn-br,
            .x-toolbar .x-btn-pressed .x-btn-br {
                background-position: -15px -3px;
            }
            .x-toolbar .x-btn-click .x-btn-bc,
            .x-toolbar .x-btn-menu-active .x-btn-bc,
            .x-toolbar .x-btn-pressed .x-btn-bc {
                background-position: 0 -21px;
            }
            .x-toolbar div.xtb-text {
                padding: 2px 2px 0;
                line-height: 16px;
                display: block;
            }
            .x-toolbar .xtb-sep {
                background-position: center;
                background-repeat: no-repeat;
                display: block;
                font-size: 1px;
                height: 16px;
                width: 4px;
                overflow: hidden;
                cursor: default;
                margin: 0 2px 0;
                border: 0;
            }
            .x-toolbar .xtb-spacer {
                width: 2px;
            }
            .x-tbar-page-number {
                width: 30px;
                height: 14px;
            }
            .ext-ie .x-tbar-page-number {
                margin-top: 2px;
            }
            .x-paging-info {
                position: absolute;
                top: 5px;
                right: 8px;
            }
            .x-toolbar-ct {
                width: 100%;
            }
            .x-toolbar-right td {
                text-align: center;
            }
            .x-panel-tbar,
            .x-panel-bbar,
            .x-window-tbar,
            .x-window-bbar,
            .x-tab-panel-tbar,
            .x-tab-panel-bbar,
            .x-plain-tbar,
            .x-plain-bbar {
                overflow: hidden;
                zoom: 1;
            }
            .x-toolbar-more .x-btn-small .x-btn-text {
                height: 16px;
                width: 12px;
            }
            .x-toolbar-more em.x-btn-arrow {
                display: inline;
                background-color: transparent;
                padding-right: 0;
            }
            .x-toolbar-more .x-btn-mc em.x-btn-arrow {
                background-image: none;
            }
            div.x-toolbar-no-items {
                color: gray !important;
                padding: 5px 10px !important;
            }
            .ext-border-box .x-toolbar-cell .x-form-text {
                margin-bottom: -1px !important;
            }
            .ext-border-box .x-toolbar-cell .x-form-field-wrap .x-form-text {
                margin: 0 !important;
            }
            .ext-ie .x-toolbar-cell .x-form-field-wrap {
                height: 21px;
            }
            .ext-ie .x-toolbar-cell .x-form-text {
                position: relative;
                top: -1px;
            }
            .ext-strict .ext-ie8 .x-toolbar-cell .x-form-field-trigger-wrap .x-form-text,
            .ext-strict .ext-ie .x-toolbar-cell .x-form-text {
                top: 0;
            }
            .x-toolbar-right td .x-form-field-trigger-wrap {
                text-align: left;
            }
            .x-toolbar-cell .x-form-checkbox,
            .x-toolbar-cell .x-form-radio {
                margin-top: 5px;
            }
            .x-toolbar-cell .x-form-cb-label {
                vertical-align: bottom;
                top: 1px;
            }
            .ext-ie .x-toolbar-cell .x-form-checkbox,
            .ext-ie .x-toolbar-cell .x-form-radio {
                margin-top: 4px;
            }
            .ext-ie .x-toolbar-cell .x-form-cb-label {
                top: 0;
            }
            .x-grid3 {
                position: relative;
                overflow: hidden;
            }
            .x-grid-panel .x-panel-body {
                overflow: hidden !important;
            }
            .x-grid-panel .x-panel-mc .x-panel-body {
                border: 1px solid;
            }
            .x-grid3 table {
                table-layout: fixed;
            }
            .x-grid3-viewport {
                overflow: hidden;
            }
            .x-grid3-hd-row td,
            .x-grid3-row td,
            .x-grid3-summary-row td {
                -moz-outline: 0;
                outline: 0;
                -moz-user-focus: normal;
            }
            .x-grid3-row td,
            .x-grid3-summary-row td {
                line-height: 13px;
                vertical-align: top;
                padding-left: 1px;
                padding-right: 1px;
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
            }
            .x-grid3-cell {
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
            }
            .x-grid3-hd-row td {
                line-height: 15px;
                vertical-align: middle;
                border-left: 1px solid;
                border-right: 1px solid;
            }
            .x-grid3-hd-row .x-grid3-marker-hd {
                padding: 3px;
            }
            .x-grid3-row .x-grid3-marker {
                padding: 3px;
            }
            .x-grid3-cell-inner,
            .x-grid3-hd-inner {
                overflow: hidden;
                -o-text-overflow: ellipsis;
                text-overflow: ellipsis;
                padding: 3px 3px 3px 5px;
                white-space: nowrap;
            }
            .x-action-col-cell .x-grid3-cell-inner {
                padding-top: 1px;
                padding-bottom: 1px;
            }
            .x-action-col-icon {
                cursor: pointer;
            }
            .x-grid3-hd-inner {
                position: relative;
                cursor: inherit;
                padding: 4px 3px 4px 5px;
            }
            .x-grid3-row-body {
                white-space: normal;
            }
            .x-grid3-body-cell {
                -moz-outline: 0 none;
                outline: 0 none;
            }
            .ext-ie .x-grid3-cell-inner,
            .ext-ie .x-grid3-hd-inner {
                width: 100%;
            }
            .ext-strict .x-grid3-cell-inner,
            .ext-strict .x-grid3-hd-inner {
                width: auto;
            }
            .x-grid-row-loading {
                background: no-repeat center center;
            }
            .x-grid-page {
                overflow: hidden;
            }
            .x-grid3-row {
                cursor: default;
                border: 1px solid;
                width: 100%;
            }
            .x-grid3-row-over {
                border: 1px solid;
                background: repeat-x left top;
            }
            .x-grid3-resize-proxy {
                width: 1px;
                left: 0;
                cursor: e-resize;
                cursor: col-resize;
                position: absolute;
                top: 0;
                height: 100px;
                overflow: hidden;
                visibility: hidden;
                border: 0 none;
                z-index: 7;
            }
            .x-grid3-resize-marker {
                width: 1px;
                left: 0;
                position: absolute;
                top: 0;
                height: 100px;
                overflow: hidden;
                visibility: hidden;
                border: 0 none;
                z-index: 7;
            }
            .x-grid3-focus {
                position: absolute;
                left: 0;
                top: 0;
                width: 1px;
                height: 1px;
                line-height: 1px;
                font-size: 1px;
                -moz-outline: 0 none;
                outline: 0 none;
                -moz-user-select: text;
                -khtml-user-select: text;
                -webkit-user-select: ignore;
            }
            .x-grid3-header {
                background: repeat-x 0 bottom;
                cursor: default;
                zoom: 1;
                padding: 1px 0 0 0;
            }
            .x-grid3-header-pop {
                border-left: 1px solid;
                float: right;
                clear: none;
            }
            .x-grid3-header-pop-inner {
                border-left: 1px solid;
                width: 14px;
                height: 19px;
                background: transparent no-repeat center center;
            }
            .ext-ie .x-grid3-header-pop-inner {
                width: 15px;
            }
            .ext-strict .x-grid3-header-pop-inner {
                width: 14px;
            }
            .x-grid3-header-inner {
                overflow: hidden;
                zoom: 1;
                float: left;
            }
            .x-grid3-header-offset {
                padding-left: 1px;
                text-align: left;
            }
            td.x-grid3-hd-over,
            td.sort-desc,
            td.sort-asc,
            td.x-grid3-hd-menu-open {
                border-left: 1px solid;
                border-right: 1px solid;
            }
            td.x-grid3-hd-over .x-grid3-hd-inner,
            td.sort-desc .x-grid3-hd-inner,
            td.sort-asc .x-grid3-hd-inner,
            td.x-grid3-hd-menu-open .x-grid3-hd-inner {
                background: repeat-x left bottom;
            }
            .x-grid3-sort-icon {
                background-repeat: no-repeat;
                display: none;
                height: 4px;
                width: 13px;
                margin-left: 3px;
                vertical-align: middle;
            }
            .sort-asc .x-grid3-sort-icon,
            .sort-desc .x-grid3-sort-icon {
                display: inline;
            }
            .ext-strict .ext-ie .x-grid3-header-inner,
            .ext-strict .ext-ie6 .x-grid3-hd {
                position: relative;
            }
            .ext-strict .ext-ie6 .x-grid3-hd-inner {
                position: static;
            }
            .x-grid3-body {
                zoom: 1;
            }
            .x-grid3-scroller {
                overflow: auto;
                zoom: 1;
                position: relative;
            }
            .x-grid3-cell-text,
            .x-grid3-hd-text {
                display: block;
                padding: 3px 5px 3px 5px;
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
            }
            .x-grid3-split {
                background-position: center;
                background-repeat: no-repeat;
                cursor: e-resize;
                cursor: col-resize;
                display: block;
                font-size: 1px;
                height: 16px;
                overflow: hidden;
                position: absolute;
                top: 2px;
                width: 6px;
                z-index: 3;
            }
            .x-dd-drag-proxy .x-grid3-hd-inner {
                background: repeat-x left bottom;
                width: 120px;
                padding: 3px;
                border: 1px solid;
                overflow: hidden;
            }
            .col-move-top,
            .col-move-bottom {
                width: 9px;
                height: 9px;
                position: absolute;
                top: 0;
                line-height: 1px;
                font-size: 1px;
                overflow: hidden;
                visibility: hidden;
                z-index: 20000;
                background: transparent no-repeat left top;
            }
            .x-grid3-row-selected {
                border: 1px dotted;
            }
            .x-grid3-locked td.x-grid3-row-marker,
            .x-grid3-locked .x-grid3-row-selected td.x-grid3-row-marker {
                background: repeat-x 0 bottom !important;
                vertical-align: middle !important;
                padding: 0;
                border-top: 1px solid;
                border-bottom: none !important;
                border-right: 1px solid !important;
                text-align: center;
            }
            .x-grid3-locked td.x-grid3-row-marker div,
            .x-grid3-locked .x-grid3-row-selected td.x-grid3-row-marker div {
                padding: 0 4px;
                text-align: center;
            }
            .x-grid3-dirty-cell {
                background: transparent no-repeat 0 0;
            }
            .x-grid3-topbar,
            .x-grid3-bottombar {
                overflow: hidden;
                display: none;
                zoom: 1;
                position: relative;
            }
            .x-grid3-topbar .x-toolbar {
                border-right: 0 none;
            }
            .x-grid3-bottombar .x-toolbar {
                border-right: 0 none;
                border-bottom: 0 none;
                border-top: 1px solid;
            }
            .x-props-grid .x-grid3-cell {
                padding: 1px;
            }
            .x-props-grid .x-grid3-td-name .x-grid3-cell-inner {
                background: transparent repeat-y -16px !important;
                padding-left: 12px;
            }
            .x-props-grid .x-grid3-body .x-grid3-td-name {
                padding: 1px;
                padding-right: 0;
                border: 0 none;
                border-right: 1px solid;
            }
            .x-grid3-col-dd {
                border: 0 none;
                padding: 0;
                background-color: transparent;
            }
            .x-dd-drag-ghost .x-grid3-dd-wrap {
                padding: 1px 3px 3px 1px;
            }
            .x-grid3-hd {
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
            }
            .x-grid3-hd-btn {
                display: none;
                position: absolute;
                width: 14px;
                background: no-repeat left center;
                right: 0;
                top: 0;
                z-index: 2;
                cursor: pointer;
            }
            .x-grid3-hd-over .x-grid3-hd-btn,
            .x-grid3-hd-menu-open .x-grid3-hd-btn {
                display: block;
            }
            a.x-grid3-hd-btn:hover {
                background-position: -14px center;
            }
            .x-grid3-body .x-grid3-td-expander {
                background: transparent repeat-y right;
            }
            .x-grid3-body .x-grid3-td-expander .x-grid3-cell-inner {
                padding: 0 !important;
                height: 100%;
            }
            .x-grid3-row-expander {
                width: 100%;
                height: 18px;
                background-position: 4px 2px;
                background-repeat: no-repeat;
                background-color: transparent;
            }
            .x-grid3-row-collapsed .x-grid3-row-expander {
                background-position: 4px 2px;
            }
            .x-grid3-row-expanded .x-grid3-row-expander {
                background-position: -21px 2px;
            }
            .x-grid3-row-collapsed .x-grid3-row-body {
                display: none !important;
            }
            .x-grid3-row-expanded .x-grid3-row-body {
                display: block !important;
            }
            .x-grid3-body .x-grid3-td-checker {
                background: transparent repeat-y right;
            }
            .x-grid3-body .x-grid3-td-checker .x-grid3-cell-inner,
            .x-grid3-header .x-grid3-td-checker .x-grid3-hd-inner {
                padding: 0 !important;
                height: 100%;
            }
            .x-grid3-row-checker,
            .x-grid3-hd-checker {
                width: 100%;
                height: 18px;
                background-position: 2px 2px;
                background-repeat: no-repeat;
                background-color: transparent;
            }
            .x-grid3-row .x-grid3-row-checker {
                background-position: 2px 2px;
            }
            .x-grid3-row-selected .x-grid3-row-checker,
            .x-grid3-hd-checker-on .x-grid3-hd-checker,
            .x-grid3-row-checked .x-grid3-row-checker {
                background-position: -23px 2px;
            }
            .x-grid3-hd-checker {
                background-position: 2px 1px;
            }
            .ext-border-box .x-grid3-hd-checker {
                background-position: 2px 3px;
            }
            .x-grid3-hd-checker-on .x-grid3-hd-checker {
                background-position: -23px 1px;
            }
            .ext-border-box .x-grid3-hd-checker-on .x-grid3-hd-checker {
                background-position: -23px 3px;
            }
            .x-grid3-body .x-grid3-td-numberer {
                background: transparent repeat-y right;
            }
            .x-grid3-body .x-grid3-td-numberer .x-grid3-cell-inner {
                padding: 3px 5px 0 0 !important;
                text-align: right;
            }
            .x-grid3-body .x-grid3-td-row-icon {
                background: transparent repeat-y right;
                vertical-align: top;
                text-align: center;
            }
            .x-grid3-body .x-grid3-td-row-icon .x-grid3-cell-inner {
                padding: 0 !important;
                background-position: center center;
                background-repeat: no-repeat;
                width: 16px;
                height: 16px;
                margin-left: 2px;
                margin-top: 3px;
            }
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-numberer,
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-checker,
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-expander {
                background: transparent repeat-y right;
            }
            .x-grid3-body .x-grid3-check-col-td .x-grid3-cell-inner {
                padding: 1px 0 0 0 !important;
            }
            .x-grid3-check-col {
                width: 100%;
                height: 16px;
                background-position: center center;
                background-repeat: no-repeat;
                background-color: transparent;
            }
            .x-grid3-check-col-on {
                width: 100%;
                height: 16px;
                background-position: center center;
                background-repeat: no-repeat;
                background-color: transparent;
            }
            .x-grid-group,
            .x-grid-group-body,
            .x-grid-group-hd {
                zoom: 1;
            }
            .x-grid-group-hd {
                border-bottom: 2px solid;
                cursor: pointer;
                padding-top: 6px;
            }
            .x-grid-group-hd div.x-grid-group-title {
                background: transparent no-repeat 3px 3px;
                padding: 4px 4px 4px 17px;
            }
            .x-grid-group-collapsed .x-grid-group-body {
                display: none;
            }
            .ext-ie6 .x-grid3 .x-editor .x-form-text,
            .ext-ie7 .x-grid3 .x-editor .x-form-text {
                position: relative;
                top: -1px;
            }
            .x-grid-editor .x-form-check-wrap {
                text-align: center;
                margin-top: -4px;
            }
            .ext-ie .x-props-grid .x-editor .x-form-text {
                position: static;
                top: 0;
            }
            .x-grid-empty {
                padding: 10px;
            }
            .ext-ie7 .x-grid-panel .x-panel-bbar {
                position: relative;
            }
            .ext-ie7 .x-grid-panel .x-panel-mc .x-panel-bbar {
                position: static;
            }
            .ext-ie6 .x-grid3-header {
                position: relative;
            }
            .ext-webkit .x-grid-panel .x-panel-bwrap {
                -webkit-user-select: none;
            }
            .ext-webkit .x-tbar-page-number {
                -webkit-user-select: ignore;
            }
            .x-grid-with-col-lines .x-grid3-row td.x-grid3-cell {
                padding-right: 0;
                border-right: 1px solid;
            }
            .x-pivotgrid .x-grid3-header-offset table {
                width: 100%;
                border-collapse: collapse;
            }
            .x-pivotgrid .x-grid3-header-offset table td {
                padding: 4px 3px 4px 5px;
                text-align: center;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 11px;
                line-height: 13px;
                font-family: tahoma;
            }
            .x-pivotgrid .x-grid3-row-headers {
                display: block;
                float: left;
            }
            .x-pivotgrid .x-grid3-row-headers table {
                height: 100%;
                width: 100%;
                border-collapse: collapse;
            }
            .x-pivotgrid .x-grid3-row-headers table td {
                height: 18px;
                padding: 2px 7px 0 0;
                text-align: right;
                text-overflow: ellipsis;
                font-size: 11px;
                font-family: tahoma;
            }
            .ext-gecko .x-pivotgrid .x-grid3-row-headers table td {
                height: 21px;
            }
            .x-grid3-header-title {
                top: 0;
                left: 0;
                position: absolute;
                text-align: center;
                vertical-align: middle;
                font-family: tahoma;
                font-size: 11px;
                padding: auto 1px;
                display: table-cell;
            }
            .x-grid3-header-title span {
                position: absolute;
                top: 50%;
                left: 0;
                width: 100%;
                margin-top: -6px;
            }
            .x-dd-drag-proxy {
                position: absolute;
                left: 0;
                top: 0;
                visibility: hidden;
                z-index: 15000;
            }
            .x-dd-drag-ghost {
                -moz-opacity: 0.85;
                opacity: 0.85;
                filter: alpha(opacity=85);
                border: 1px solid;
                padding: 3px;
                padding-left: 20px;
                white-space: nowrap;
            }
            .x-dd-drag-repair .x-dd-drag-ghost {
                -moz-opacity: 0.4;
                opacity: 0.4;
                filter: alpha(opacity=40);
                border: 0 none;
                padding: 0;
                background-color: transparent;
            }
            .x-dd-drag-repair .x-dd-drop-icon {
                visibility: hidden;
            }
            .x-dd-drop-icon {
                position: absolute;
                top: 3px;
                left: 3px;
                display: block;
                width: 16px;
                height: 16px;
                background-color: transparent;
                background-position: center;
                background-repeat: no-repeat;
                z-index: 1;
            }
            .x-view-selector {
                position: absolute;
                left: 0;
                top: 0;
                width: 0;
                border: 1px dotted;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
                zoom: 1;
            }
            .ext-strict .ext-ie .x-tree .x-panel-bwrap {
                position: relative;
                overflow: hidden;
            }
            .x-tree-icon,
            .x-tree-ec-icon,
            .x-tree-elbow-line,
            .x-tree-elbow,
            .x-tree-elbow-end,
            .x-tree-elbow-plus,
            .x-tree-elbow-minus,
            .x-tree-elbow-end-plus,
            .x-tree-elbow-end-minus {
                border: 0 none;
                height: 18px;
                margin: 0;
                padding: 0;
                vertical-align: top;
                width: 16px;
                background-repeat: no-repeat;
            }
            .x-tree-node-collapsed .x-tree-node-icon,
            .x-tree-node-expanded .x-tree-node-icon,
            .x-tree-node-leaf .x-tree-node-icon {
                border: 0 none;
                height: 18px;
                margin: 0;
                padding: 0;
                vertical-align: top;
                width: 16px;
                background-position: center;
                background-repeat: no-repeat;
            }
            .ext-ie .x-tree-node-indent img,
            .ext-ie .x-tree-node-icon,
            .ext-ie .x-tree-ec-icon {
                vertical-align: middle !important;
            }
            .ext-strict .ext-ie8 .x-tree-node-indent img,
            .ext-strict .ext-ie8 .x-tree-node-icon,
            .ext-strict .ext-ie8 .x-tree-ec-icon {
                vertical-align: top !important;
            }
            input.x-tree-node-cb {
                margin-left: 1px;
                height: 19px;
                vertical-align: bottom;
            }
            .ext-ie input.x-tree-node-cb {
                margin-left: 0;
                margin-top: 1px;
                width: 16px;
                height: 16px;
                vertical-align: middle;
            }
            .ext-strict .ext-ie8 input.x-tree-node-cb {
                margin: 1px 1px;
                height: 14px;
                vertical-align: bottom;
            }
            .ext-strict .ext-ie8 input.x-tree-node-cb + a {
                vertical-align: bottom;
            }
            .ext-opera input.x-tree-node-cb {
                height: 14px;
                vertical-align: middle;
            }
            .x-tree-noicon .x-tree-node-icon {
                width: 0;
                height: 0;
            }
            .x-tree-no-lines .x-tree-elbow {
                background-color: transparent;
            }
            .x-tree-no-lines .x-tree-elbow-end {
                background-color: transparent;
            }
            .x-tree-no-lines .x-tree-elbow-line {
                background-color: transparent;
            }
            .x-tree-arrows .x-tree-elbow {
                background-color: transparent;
            }
            .x-tree-arrows .x-tree-elbow-plus {
                background: transparent no-repeat 0 0;
            }
            .x-tree-arrows .x-tree-elbow-minus {
                background: transparent no-repeat -16px 0;
            }
            .x-tree-arrows .x-tree-elbow-end {
                background-color: transparent;
            }
            .x-tree-arrows .x-tree-elbow-end-plus {
                background: transparent no-repeat 0 0;
            }
            .x-tree-arrows .x-tree-elbow-end-minus {
                background: transparent no-repeat -16px 0;
            }
            .x-tree-arrows .x-tree-elbow-line {
                background-color: transparent;
            }
            .x-tree-arrows .x-tree-ec-over .x-tree-elbow-plus {
                background-position: -32px 0;
            }
            .x-tree-arrows .x-tree-ec-over .x-tree-elbow-minus {
                background-position: -48px 0;
            }
            .x-tree-arrows .x-tree-ec-over .x-tree-elbow-end-plus {
                background-position: -32px 0;
            }
            .x-tree-arrows .x-tree-ec-over .x-tree-elbow-end-minus {
                background-position: -48px 0;
            }
            .x-tree-elbow-plus,
            .x-tree-elbow-minus,
            .x-tree-elbow-end-plus,
            .x-tree-elbow-end-minus {
                cursor: pointer;
            }
            .ext-ie ul.x-tree-node-ct {
                font-size: 0;
                line-height: 0;
                zoom: 1;
            }
            .x-tree-node {
                white-space: nowrap;
            }
            .x-tree-node-el {
                line-height: 18px;
                cursor: pointer;
            }
            .x-tree-node a,
            .x-dd-drag-ghost a {
                text-decoration: none;
                -khtml-user-select: none;
                -moz-user-select: none;
                -webkit-user-select: ignore;
                -kthml-user-focus: normal;
                -moz-user-focus: normal;
                -moz-outline: 0 none;
                outline: 0 none;
            }
            .x-tree-node a span,
            .x-dd-drag-ghost a span {
                text-decoration: none;
                padding: 1px 3px 1px 2px;
            }
            .x-tree-node .x-tree-node-disabled .x-tree-node-icon {
                -moz-opacity: 0.5;
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            .x-tree-node .x-tree-node-inline-icon {
                background-color: transparent;
            }
            .x-tree-node a:hover,
            .x-dd-drag-ghost a:hover {
                text-decoration: none;
            }
            .x-tree-node div.x-tree-drag-insert-below {
                border-bottom: 1px dotted;
            }
            .x-tree-node div.x-tree-drag-insert-above {
                border-top: 1px dotted;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-below {
                border-bottom: 0 none;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-above {
                border-top: 0 none;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-below a {
                border-bottom: 2px solid;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-above a {
                border-top: 2px solid;
            }
            .x-tree-node .x-tree-drag-append a span {
                border: 1px dotted;
            }
            .x-dd-drag-ghost .x-tree-node-indent,
            .x-dd-drag-ghost .x-tree-ec-icon {
                display: none !important;
            }
            .x-tree-root-ct {
                zoom: 1;
            }
            .x-date-picker {
                border: 1px solid;
                border-top: 0 none;
                position: relative;
            }
            .x-date-picker a {
                -moz-outline: 0 none;
                outline: 0 none;
            }
            .x-date-inner,
            .x-date-inner td,
            .x-date-inner th {
                border-collapse: separate;
            }
            .x-date-middle,
            .x-date-left,
            .x-date-right {
                background: repeat-x 0 -83px;
                overflow: hidden;
            }
            .x-date-middle .x-btn-tc,
            .x-date-middle .x-btn-tl,
            .x-date-middle .x-btn-tr,
            .x-date-middle .x-btn-mc,
            .x-date-middle .x-btn-ml,
            .x-date-middle .x-btn-mr,
            .x-date-middle .x-btn-bc,
            .x-date-middle .x-btn-bl,
            .x-date-middle .x-btn-br {
                background: transparent !important;
                vertical-align: middle;
            }
            .x-date-middle .x-btn-mc em.x-btn-arrow {
                background: transparent no-repeat right 0;
            }
            .x-date-right,
            .x-date-left {
                width: 18px;
            }
            .x-date-right {
                text-align: right;
            }
            .x-date-middle {
                padding-top: 2px;
                padding-bottom: 2px;
                width: 130px;
            }
            .x-date-right a,
            .x-date-left a {
                display: block;
                width: 16px;
                height: 16px;
                background-position: center;
                background-repeat: no-repeat;
                cursor: pointer;
                -moz-opacity: 0.6;
                opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .x-date-right a:hover,
            .x-date-left a:hover {
                -moz-opacity: 1;
                opacity: 1;
                filter: alpha(opacity=100);
            }
            .x-item-disabled .x-date-right a:hover,
            .x-item-disabled .x-date-left a:hover {
                -moz-opacity: 0.6;
                opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .x-date-right a {
                margin-right: 2px;
                text-decoration: none !important;
            }
            .x-date-left a {
                margin-left: 2px;
                text-decoration: none !important;
            }
            table.x-date-inner {
                width: 100%;
                table-layout: fixed;
            }
            .ext-webkit table.x-date-inner {
                width: 175px;
            }
            .x-date-inner th {
                width: 25px;
            }
            .x-date-inner th {
                background: repeat-x left top;
                text-align: right !important;
                border-bottom: 1px solid;
                cursor: default;
                padding: 0;
                border-collapse: separate;
            }
            .x-date-inner th span {
                display: block;
                padding: 2px;
                padding-right: 7px;
            }
            .x-date-inner td {
                border: 1px solid;
                text-align: right;
                padding: 0;
            }
            .x-date-inner a {
                padding: 2px 5px;
                display: block;
                text-decoration: none;
                text-align: right;
                zoom: 1;
            }
            .x-date-inner .x-date-active {
                cursor: pointer;
                color: black;
            }
            .x-date-inner .x-date-selected a {
                background: repeat-x left top;
                border: 1px solid;
                padding: 1px 4px;
            }
            .x-date-inner .x-date-today a {
                border: 1px solid;
                padding: 1px 4px;
            }
            .x-date-inner .x-date-prevday a,
            .x-date-inner .x-date-nextday a {
                text-decoration: none !important;
            }
            .x-date-bottom {
                padding: 4px;
                border-top: 1px solid;
                background: repeat-x left top;
            }
            .x-date-inner a:hover,
            .x-date-inner .x-date-disabled a:hover {
                text-decoration: none !important;
            }
            .x-item-disabled .x-date-inner a:hover {
                background: 0;
            }
            .x-date-inner .x-date-disabled a {
                cursor: default;
            }
            .x-date-menu .x-menu-item {
                padding: 1px 24px 1px 4px;
                white-space: nowrap;
            }
            .x-date-menu .x-menu-item .x-menu-item-icon {
                width: 10px;
                height: 10px;
                margin-right: 5px;
                background-position: center -4px !important;
            }
            .x-date-mp {
                position: absolute;
                left: 0;
                top: 0;
                display: none;
            }
            .x-date-mp td {
                padding: 2px;
                font:
                    normal 11px arial,
                    helvetica,
                    tahoma,
                    sans-serif;
            }
            td.x-date-mp-month,
            td.x-date-mp-year,
            td.x-date-mp-ybtn {
                border: 0 none;
                text-align: center;
                vertical-align: middle;
                width: 25%;
            }
            .x-date-mp-ok {
                margin-right: 3px;
            }
            .x-date-mp-btns button {
                text-decoration: none;
                text-align: center;
                text-decoration: none !important;
                border: 1px solid;
                padding: 1px 3px 1px;
                cursor: pointer;
            }
            .x-date-mp-btns {
                background: repeat-x left top;
            }
            .x-date-mp-btns td {
                border-top: 1px solid;
                text-align: center;
            }
            td.x-date-mp-month a,
            td.x-date-mp-year a {
                display: block;
                padding: 2px 4px;
                text-decoration: none;
                text-align: center;
            }
            td.x-date-mp-month a:hover,
            td.x-date-mp-year a:hover {
                text-decoration: none;
                cursor: pointer;
            }
            td.x-date-mp-sel a {
                padding: 1px 3px;
                background: repeat-x left top;
                border: 1px solid;
            }
            .x-date-mp-ybtn a {
                overflow: hidden;
                width: 15px;
                height: 15px;
                cursor: pointer;
                background: transparent no-repeat;
                display: block;
                margin: 0 auto;
            }
            .x-date-mp-ybtn a.x-date-mp-next {
                background-position: 0 -120px;
            }
            .x-date-mp-ybtn a.x-date-mp-next:hover {
                background-position: -15px -120px;
            }
            .x-date-mp-ybtn a.x-date-mp-prev {
                background-position: 0 -105px;
            }
            .x-date-mp-ybtn a.x-date-mp-prev:hover {
                background-position: -15px -105px;
            }
            .x-date-mp-ybtn {
                text-align: center;
            }
            td.x-date-mp-sep {
                border-right: 1px solid;
            }
            .x-tip {
                position: absolute;
                top: 0;
                left: 0;
                visibility: hidden;
                z-index: 20002;
                border: 0 none;
            }
            .x-tip .x-tip-close {
                height: 15px;
                float: right;
                width: 15px;
                margin: 0 0 2px 2px;
                cursor: pointer;
                display: none;
            }
            .x-tip .x-tip-tc {
                background: transparent no-repeat 0 -62px;
                padding-top: 3px;
                overflow: hidden;
                zoom: 1;
            }
            .x-tip .x-tip-tl {
                background: transparent no-repeat 0 0;
                padding-left: 6px;
                overflow: hidden;
                zoom: 1;
            }
            .x-tip .x-tip-tr {
                background: transparent no-repeat right 0;
                padding-right: 6px;
                overflow: hidden;
                zoom: 1;
            }
            .x-tip .x-tip-bc {
                background: transparent no-repeat 0 -121px;
                height: 3px;
                overflow: hidden;
            }
            .x-tip .x-tip-bl {
                background: transparent no-repeat 0 -59px;
                padding-left: 6px;
                zoom: 1;
            }
            .x-tip .x-tip-br {
                background: transparent no-repeat right -59px;
                padding-right: 6px;
                zoom: 1;
            }
            .x-tip .x-tip-mc {
                border: 0 none;
            }
            .x-tip .x-tip-ml {
                background: no-repeat 0 -124px;
                padding-left: 6px;
                zoom: 1;
            }
            .x-tip .x-tip-mr {
                background: transparent no-repeat right -124px;
                padding-right: 6px;
                zoom: 1;
            }
            .ext-ie .x-tip .x-tip-header,
            .ext-ie .x-tip .x-tip-tc {
                font-size: 0;
                line-height: 0;
            }
            .ext-border-box .x-tip .x-tip-header,
            .ext-border-box .x-tip .x-tip-tc {
                line-height: 1px;
            }
            .x-tip .x-tip-header-text {
                padding: 0;
                margin: 0 0 2px 0;
            }
            .x-tip .x-tip-body {
                margin: 0 !important;
                line-height: 14px;
                padding: 0;
            }
            .x-tip .x-tip-body .loading-indicator {
                margin: 0;
            }
            .x-tip-draggable .x-tip-header,
            .x-tip-draggable .x-tip-header-text {
                cursor: move;
            }
            .x-form-invalid-tip .x-tip-tc {
                background: repeat-x 0 -12px;
                padding-top: 6px;
            }
            .x-form-invalid-tip .x-tip-bc {
                background: repeat-x 0 -18px;
                height: 6px;
            }
            .x-form-invalid-tip .x-tip-bl {
                background: no-repeat 0 -6px;
            }
            .x-form-invalid-tip .x-tip-br {
                background: no-repeat right -6px;
            }
            .x-form-invalid-tip .x-tip-body {
                padding: 2px;
            }
            .x-form-invalid-tip .x-tip-body {
                padding-left: 24px;
                background: transparent no-repeat 2px 2px;
            }
            .x-tip-anchor {
                position: absolute;
                width: 9px;
                height: 10px;
                overflow: hidden;
                background: transparent no-repeat 0 0;
                zoom: 1;
            }
            .x-tip-anchor-bottom {
                background-position: -9px 0;
            }
            .x-tip-anchor-right {
                background-position: -18px 0;
                width: 10px;
            }
            .x-tip-anchor-left {
                background-position: -28px 0;
                width: 10px;
            }
            .x-menu {
                z-index: 15000;
                zoom: 1;
                background: repeat-y;
            }
            .x-menu-floating {
                border: 1px solid;
            }
            .x-menu a {
                text-decoration: none !important;
            }
            .ext-ie .x-menu {
                zoom: 1;
                overflow: hidden;
            }
            .x-menu-list {
                padding: 2px;
                background-color: transparent;
                border: 0 none;
                overflow: hidden;
                overflow-y: hidden;
            }
            .ext-strict .ext-ie .x-menu-list {
                position: relative;
            }
            .x-menu li {
                line-height: 100%;
            }
            .x-menu li.x-menu-sep-li {
                font-size: 1px;
                line-height: 1px;
            }
            .x-menu-list-item {
                white-space: nowrap;
                display: block;
                padding: 1px;
            }
            .x-menu-item {
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
            }
            .x-menu-item-arrow {
                background: transparent no-repeat right;
            }
            .x-menu-sep {
                display: block;
                font-size: 1px;
                line-height: 1px;
                margin: 2px 3px;
                border-bottom: 1px solid;
                overflow: hidden;
            }
            .x-menu-focus {
                position: absolute;
                left: -1px;
                top: -1px;
                width: 1px;
                height: 1px;
                line-height: 1px;
                font-size: 1px;
                -moz-outline: 0 none;
                outline: 0 none;
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
                overflow: hidden;
                display: block;
            }
            a.x-menu-item {
                cursor: pointer;
                display: block;
                line-height: 16px;
                outline-color: -moz-use-text-color;
                outline-style: none;
                outline-width: 0;
                padding: 3px 21px 3px 27px;
                position: relative;
                text-decoration: none;
                white-space: nowrap;
            }
            .x-menu-item-active {
                background-repeat: repeat-x;
                background-position: left bottom;
                border-style: solid;
                border-width: 1px 0;
                margin: 0 1px;
                padding: 0;
            }
            .x-menu-item-active a.x-menu-item {
                border-style: solid;
                border-width: 0 1px;
                margin: 0 -1px;
            }
            .x-menu-item-icon {
                border: 0 none;
                height: 16px;
                padding: 0;
                vertical-align: top;
                width: 16px;
                position: absolute;
                left: 3px;
                top: 3px;
                margin: 0;
                background-position: center;
            }
            .ext-ie .x-menu-item-icon {
                left: -24px;
            }
            .ext-strict .x-menu-item-icon {
                left: 3px;
            }
            .ext-ie6 .x-menu-item-icon {
                left: -24px;
            }
            .ext-ie .x-menu-item-icon {
                vertical-align: middle;
            }
            .x-menu-check-item .x-menu-item-icon {
                background: transparent no-repeat center;
            }
            .x-menu-group-item .x-menu-item-icon {
                background-color: transparent;
            }
            .x-menu-item-checked .x-menu-group-item .x-menu-item-icon {
                background: transparent no-repeat center;
            }
            .x-date-menu .x-menu-list {
                padding: 0;
            }
            .x-menu-date-item {
                padding: 0;
            }
            .x-menu .x-color-palette,
            .x-menu .x-date-picker {
                margin-left: 26px;
                margin-right: 4px;
            }
            .x-menu .x-date-picker {
                border: 1px solid;
                margin-top: 2px;
                margin-bottom: 2px;
            }
            .x-menu-plain .x-color-palette,
            .x-menu-plain .x-date-picker {
                margin: 0;
                border: 0 none;
            }
            .x-date-menu {
                padding: 0 !important;
            }
            .ext-strict .ext-ie6 .x-menu-sep-li {
                padding: 3px 4px;
            }
            .ext-strict .ext-ie6 .x-menu-sep {
                margin: 0;
                height: 1px;
            }
            .ext-webkit .x-menu-sep {
                height: 1px;
            }
            .ext-ie .x-date-menu {
                height: 199px;
            }
            .ext-strict .ext-ie .x-date-menu,
            .ext-border-box .ext-ie8 .x-date-menu {
                height: 197px;
            }
            .ext-strict .ext-ie7 .x-date-menu {
                height: 195px;
            }
            .ext-strict .ext-ie8 .x-date-menu {
                height: auto;
            }
            .x-cycle-menu .x-menu-item-checked {
                border: 1px dotted !important;
                padding: 0;
            }
            .x-menu .x-menu-scroller {
                width: 100%;
                background-repeat: no-repeat;
                background-position: center;
                height: 8px;
                line-height: 8px;
                cursor: pointer;
                margin: 0;
                padding: 0;
            }
            .x-menu .x-menu-scroller-active {
                height: 6px;
                line-height: 6px;
            }
            .x-menu-list-item-indent {
                padding-left: 27px;
            }
            .x-box-tl {
                background: transparent no-repeat 0 0;
                zoom: 1;
            }
            .x-box-tc {
                height: 8px;
                background: transparent repeat-x 0 0;
                overflow: hidden;
            }
            .x-box-tr {
                background: transparent no-repeat right -8px;
            }
            .x-box-ml {
                background: transparent repeat-y 0;
                padding-left: 4px;
                overflow: hidden;
                zoom: 1;
            }
            .x-box-mc {
                background: repeat-x 0 -16px;
                padding: 4px 10px;
            }
            .x-box-mc h3 {
                margin: 0 0 4px 0;
                zoom: 1;
            }
            .x-box-mr {
                background: transparent repeat-y right;
                padding-right: 4px;
                overflow: hidden;
            }
            .x-box-bl {
                background: transparent no-repeat 0 -16px;
                zoom: 1;
            }
            .x-box-bc {
                background: transparent repeat-x 0 -8px;
                height: 8px;
                overflow: hidden;
            }
            .x-box-br {
                background: transparent no-repeat right -24px;
            }
            .x-box-tl,
            .x-box-bl {
                padding-left: 8px;
                overflow: hidden;
            }
            .x-box-tr,
            .x-box-br {
                padding-right: 8px;
                overflow: hidden;
            }
            .x-combo-list {
                border: 1px solid;
                zoom: 1;
                overflow: hidden;
            }
            .x-combo-list-inner {
                overflow: auto;
                position: relative;
                zoom: 1;
                overflow-x: hidden;
            }
            .x-combo-list-hd {
                border-bottom: 1px solid;
                padding: 3px;
            }
            .x-resizable-pinned .x-combo-list-inner {
                border-bottom: 1px solid;
            }
            .x-combo-list-item {
                padding: 2px;
                border: 1px solid;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .x-combo-list .x-combo-selected {
                border: 1px dotted !important;
                cursor: pointer;
            }
            .x-combo-list .x-toolbar {
                border-top: 1px solid;
                border-bottom: 0 none;
            }
            .x-panel {
                border-style: solid;
                border-width: 0;
            }
            .x-panel-header {
                overflow: hidden;
                zoom: 1;
                padding: 5px 3px 4px 5px;
                border: 1px solid;
                line-height: 15px;
                background: transparent repeat-x 0 -1px;
            }
            .x-panel-body {
                border: 1px solid;
                border-top: 0 none;
                overflow: hidden;
                position: relative;
            }
            .x-panel-bbar .x-toolbar,
            .x-panel-tbar .x-toolbar {
                border: 1px solid;
                border-top: 0 none;
                overflow: hidden;
                padding: 2px;
            }
            .x-panel-tbar-noheader .x-toolbar,
            .x-panel-mc .x-panel-tbar .x-toolbar {
                border-top: 1px solid;
                border-bottom: 0 none;
            }
            .x-panel-body-noheader,
            .x-panel-mc .x-panel-body {
                border-top: 1px solid;
            }
            .x-panel-header {
                overflow: hidden;
                zoom: 1;
            }
            .x-panel-tl .x-panel-header {
                padding: 5px 0 4px 0;
                border: 0 none;
                background: transparent no-repeat;
            }
            .x-panel-tl .x-panel-icon,
            .x-window-tl .x-panel-icon {
                padding-left: 20px !important;
                background-repeat: no-repeat;
                background-position: 0 4px;
                zoom: 1;
            }
            .x-panel-inline-icon {
                width: 16px;
                height: 16px;
                background-repeat: no-repeat;
                background-position: 0 0;
                vertical-align: middle;
                margin-right: 4px;
                margin-top: -1px;
                margin-bottom: -1px;
            }
            .x-panel-tc {
                background: transparent repeat-x 0 0;
                overflow: hidden;
            }
            .ext-strict .ext-ie7 .x-panel-tc {
                overflow: visible;
            }
            .x-panel-tl {
                background: transparent no-repeat 0 0;
                padding-left: 6px;
                zoom: 1;
                border-bottom: 1px solid;
            }
            .x-panel-tr {
                background: transparent no-repeat right 0;
                zoom: 1;
                padding-right: 6px;
            }
            .x-panel-bc {
                background: transparent repeat-x 0 bottom;
                zoom: 1;
            }
            .x-panel-bc .x-panel-footer {
                zoom: 1;
            }
            .x-panel-bl {
                background: transparent no-repeat 0 bottom;
                padding-left: 6px;
                zoom: 1;
            }
            .x-panel-br {
                background: transparent no-repeat right bottom;
                padding-right: 6px;
                zoom: 1;
            }
            .x-panel-mc {
                border: 0 none;
                padding: 0;
                margin: 0;
                padding-top: 6px;
            }
            .x-panel-mc .x-panel-body {
                background-color: transparent;
                border: 0 none;
            }
            .x-panel-ml {
                background: repeat-y 0 0;
                padding-left: 6px;
                zoom: 1;
            }
            .x-panel-mr {
                background: transparent repeat-y right 0;
                padding-right: 6px;
                zoom: 1;
            }
            .x-panel-bc .x-panel-footer {
                padding-bottom: 6px;
            }
            .x-panel-nofooter .x-panel-bc,
            .x-panel-nofooter .x-window-bc {
                height: 6px;
                font-size: 0;
                line-height: 0;
            }
            .x-panel-bwrap {
                overflow: hidden;
                zoom: 1;
                left: 0;
                top: 0;
            }
            .x-panel-body {
                overflow: hidden;
                zoom: 1;
            }
            .x-panel-collapsed .x-resizable-handle {
                display: none;
            }
            .ext-gecko .x-panel-animated div {
                overflow: hidden !important;
            }
            .x-plain-body {
                overflow: hidden;
            }
            .x-plain-bbar .x-toolbar {
                overflow: hidden;
                padding: 2px;
            }
            .x-plain-tbar .x-toolbar {
                overflow: hidden;
                padding: 2px;
            }
            .x-plain-bwrap {
                overflow: hidden;
                zoom: 1;
            }
            .x-plain {
                overflow: hidden;
            }
            .x-tool {
                overflow: hidden;
                width: 15px;
                height: 15px;
                float: right;
                cursor: pointer;
                background: transparent no-repeat;
                margin-left: 2px;
            }
            .x-tool-toggle {
                background-position: 0 -60px;
            }
            .x-tool-toggle-over {
                background-position: -15px -60px;
            }
            .x-panel-collapsed .x-tool-toggle {
                background-position: 0 -75px;
            }
            .x-panel-collapsed .x-tool-toggle-over {
                background-position: -15px -75px;
            }
            .x-tool-close {
                background-position: 0 -0;
            }
            .x-tool-close-over {
                background-position: -15px 0;
            }
            .x-tool-minimize {
                background-position: 0 -15px;
            }
            .x-tool-minimize-over {
                background-position: -15px -15px;
            }
            .x-tool-maximize {
                background-position: 0 -30px;
            }
            .x-tool-maximize-over {
                background-position: -15px -30px;
            }
            .x-tool-restore {
                background-position: 0 -45px;
            }
            .x-tool-restore-over {
                background-position: -15px -45px;
            }
            .x-tool-gear {
                background-position: 0 -90px;
            }
            .x-tool-gear-over {
                background-position: -15px -90px;
            }
            .x-tool-prev {
                background-position: 0 -105px;
            }
            .x-tool-prev-over {
                background-position: -15px -105px;
            }
            .x-tool-next {
                background-position: 0 -120px;
            }
            .x-tool-next-over {
                background-position: -15px -120px;
            }
            .x-tool-pin {
                background-position: 0 -135px;
            }
            .x-tool-pin-over {
                background-position: -15px -135px;
            }
            .x-tool-unpin {
                background-position: 0 -150px;
            }
            .x-tool-unpin-over {
                background-position: -15px -150px;
            }
            .x-tool-right {
                background-position: 0 -165px;
            }
            .x-tool-right-over {
                background-position: -15px -165px;
            }
            .x-tool-left {
                background-position: 0 -180px;
            }
            .x-tool-left-over {
                background-position: -15px -180px;
            }
            .x-tool-down {
                background-position: 0 -195px;
            }
            .x-tool-down-over {
                background-position: -15px -195px;
            }
            .x-tool-up {
                background-position: 0 -210px;
            }
            .x-tool-up-over {
                background-position: -15px -210px;
            }
            .x-tool-refresh {
                background-position: 0 -225px;
            }
            .x-tool-refresh-over {
                background-position: -15px -225px;
            }
            .x-tool-plus {
                background-position: 0 -240px;
            }
            .x-tool-plus-over {
                background-position: -15px -240px;
            }
            .x-tool-minus {
                background-position: 0 -255px;
            }
            .x-tool-minus-over {
                background-position: -15px -255px;
            }
            .x-tool-search {
                background-position: 0 -270px;
            }
            .x-tool-search-over {
                background-position: -15px -270px;
            }
            .x-tool-save {
                background-position: 0 -285px;
            }
            .x-tool-save-over {
                background-position: -15px -285px;
            }
            .x-tool-help {
                background-position: 0 -300px;
            }
            .x-tool-help-over {
                background-position: -15px -300px;
            }
            .x-tool-print {
                background-position: 0 -315px;
            }
            .x-tool-print-over {
                background-position: -15px -315px;
            }
            .x-tool-expand {
                background-position: 0 -330px;
            }
            .x-tool-expand-over {
                background-position: -15px -330px;
            }
            .x-tool-collapse {
                background-position: 0 -345px;
            }
            .x-tool-collapse-over {
                background-position: -15px -345px;
            }
            .x-tool-resize {
                background-position: 0 -360px;
            }
            .x-tool-resize-over {
                background-position: -15px -360px;
            }
            .x-tool-move {
                background-position: 0 -375px;
            }
            .x-tool-move-over {
                background-position: -15px -375px;
            }
            .x-panel-ghost {
                z-index: 12000;
                overflow: hidden;
                position: absolute;
                left: 0;
                top: 0;
                opacity: 0.65;
                -moz-opacity: 0.65;
                filter: alpha(opacity=65);
            }
            .x-panel-ghost ul {
                margin: 0;
                padding: 0;
                overflow: hidden;
                font-size: 0;
                line-height: 0;
                border: 1px solid;
                border-top: 0 none;
                display: block;
            }
            .x-panel-ghost * {
                cursor: move !important;
            }
            .x-panel-dd-spacer {
                border: 2px dashed;
            }
            .x-panel-btns {
                padding: 5px;
                overflow: hidden;
            }
            .x-panel-btns td.x-toolbar-cell {
                padding: 3px;
            }
            .x-panel-btns .x-btn-focus .x-btn-left {
                background-position: 0 -147px;
            }
            .x-panel-btns .x-btn-focus .x-btn-right {
                background-position: 0 -168px;
            }
            .x-panel-btns .x-btn-focus .x-btn-center {
                background-position: 0 -189px;
            }
            .x-panel-btns .x-btn-over .x-btn-left {
                background-position: 0 -63px;
            }
            .x-panel-btns .x-btn-over .x-btn-right {
                background-position: 0 -84px;
            }
            .x-panel-btns .x-btn-over .x-btn-center {
                background-position: 0 -105px;
            }
            .x-panel-btns .x-btn-click .x-btn-center {
                background-position: 0 -126px;
            }
            .x-panel-btns .x-btn-click .x-btn-right {
                background-position: 0 -84px;
            }
            .x-panel-btns .x-btn-click .x-btn-left {
                background-position: 0 -63px;
            }
            .x-panel-fbar td,
            .x-panel-fbar span,
            .x-panel-fbar input,
            .x-panel-fbar div,
            .x-panel-fbar select,
            .x-panel-fbar label {
                white-space: nowrap;
            }
            .x-panel-reset .x-panel-body html,
            .x-panel-reset .x-panel-body address,
            .x-panel-reset .x-panel-body blockquote,
            .x-panel-reset .x-panel-body body,
            .x-panel-reset .x-panel-body dd,
            .x-panel-reset .x-panel-body div,
            .x-panel-reset .x-panel-body dl,
            .x-panel-reset .x-panel-body dt,
            .x-panel-reset .x-panel-body fieldset,
            .x-panel-reset .x-panel-body form,
            .x-panel-reset .x-panel-body frame,
            frameset,
            .x-panel-reset .x-panel-body h1,
            .x-panel-reset .x-panel-body h2,
            .x-panel-reset .x-panel-body h3,
            .x-panel-reset .x-panel-body h4,
            .x-panel-reset .x-panel-body h5,
            .x-panel-reset .x-panel-body h6,
            .x-panel-reset .x-panel-body noframes,
            .x-panel-reset .x-panel-body ol,
            .x-panel-reset .x-panel-body p,
            .x-panel-reset .x-panel-body ul,
            .x-panel-reset .x-panel-body center,
            .x-panel-reset .x-panel-body dir,
            .x-panel-reset .x-panel-body hr,
            .x-panel-reset .x-panel-body menu,
            .x-panel-reset .x-panel-body pre {
                display: block;
            }
            .x-panel-reset .x-panel-body li {
                display: list-item;
            }
            .x-panel-reset .x-panel-body head {
                display: none;
            }
            .x-panel-reset .x-panel-body table {
                display: table;
            }
            .x-panel-reset .x-panel-body tr {
                display: table-row;
            }
            .x-panel-reset .x-panel-body thead {
                display: table-header-group;
            }
            .x-panel-reset .x-panel-body tbody {
                display: table-row-group;
            }
            .x-panel-reset .x-panel-body tfoot {
                display: table-footer-group;
            }
            .x-panel-reset .x-panel-body col {
                display: table-column;
            }
            .x-panel-reset .x-panel-body colgroup {
                display: table-column-group;
            }
            .x-panel-reset .x-panel-body td,
            .x-panel-reset .x-panel-body th {
                display: table-cell;
            }
            .x-panel-reset .x-panel-body caption {
                display: table-caption;
            }
            .x-panel-reset .x-panel-body th {
                font-weight: bolder;
                text-align: center;
            }
            .x-panel-reset .x-panel-body caption {
                text-align: center;
            }
            .x-panel-reset .x-panel-body body {
                margin: 8px;
            }
            .x-panel-reset .x-panel-body h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }
            .x-panel-reset .x-panel-body h2 {
                font-size: 1.5em;
                margin: 0.75em 0;
            }
            .x-panel-reset .x-panel-body h3 {
                font-size: 1.17em;
                margin: 0.83em 0;
            }
            .x-panel-reset .x-panel-body h4,
            .x-panel-reset .x-panel-body p,
            .x-panel-reset .x-panel-body blockquote,
            .x-panel-reset .x-panel-body ul,
            .x-panel-reset .x-panel-body fieldset,
            .x-panel-reset .x-panel-body form,
            .x-panel-reset .x-panel-body ol,
            .x-panel-reset .x-panel-body dl,
            .x-panel-reset .x-panel-body dir,
            .x-panel-reset .x-panel-body menu {
                margin: 1.12em 0;
            }
            .x-panel-reset .x-panel-body h5 {
                font-size: 0.83em;
                margin: 1.5em 0;
            }
            .x-panel-reset .x-panel-body h6 {
                font-size: 0.75em;
                margin: 1.67em 0;
            }
            .x-panel-reset .x-panel-body h1,
            .x-panel-reset .x-panel-body h2,
            .x-panel-reset .x-panel-body h3,
            .x-panel-reset .x-panel-body h4,
            .x-panel-reset .x-panel-body h5,
            .x-panel-reset .x-panel-body h6,
            .x-panel-reset .x-panel-body b,
            .x-panel-reset .x-panel-body strong {
                font-weight: bolder;
            }
            .x-panel-reset .x-panel-body blockquote {
                margin-left: 40px;
                margin-right: 40px;
            }
            .x-panel-reset .x-panel-body i,
            .x-panel-reset .x-panel-body cite,
            .x-panel-reset .x-panel-body em,
            .x-panel-reset .x-panel-body var,
            .x-panel-reset .x-panel-body address {
                font-style: italic;
            }
            .x-panel-reset .x-panel-body pre,
            .x-panel-reset .x-panel-body tt,
            .x-panel-reset .x-panel-body code,
            .x-panel-reset .x-panel-body kbd,
            .x-panel-reset .x-panel-body samp {
                font-family: monospace;
            }
            .x-panel-reset .x-panel-body pre {
                white-space: pre;
            }
            .x-panel-reset .x-panel-body button,
            .x-panel-reset .x-panel-body textarea,
            .x-panel-reset .x-panel-body input,
            .x-panel-reset .x-panel-body select {
                display: inline-block;
            }
            .x-panel-reset .x-panel-body big {
                font-size: 1.17em;
            }
            .x-panel-reset .x-panel-body small,
            .x-panel-reset .x-panel-body sub,
            .x-panel-reset .x-panel-body sup {
                font-size: 0.83em;
            }
            .x-panel-reset .x-panel-body sub {
                vertical-align: sub;
            }
            .x-panel-reset .x-panel-body sup {
                vertical-align: super;
            }
            .x-panel-reset .x-panel-body table {
                border-spacing: 2px;
            }
            .x-panel-reset .x-panel-body thead,
            .x-panel-reset .x-panel-body tbody,
            .x-panel-reset .x-panel-body tfoot {
                vertical-align: middle;
            }
            .x-panel-reset .x-panel-body td,
            .x-panel-reset .x-panel-body th {
                vertical-align: inherit;
            }
            .x-panel-reset .x-panel-body s,
            .x-panel-reset .x-panel-body strike,
            .x-panel-reset .x-panel-body del {
                text-decoration: line-through;
            }
            .x-panel-reset .x-panel-body hr {
                border: 1px inset;
            }
            .x-panel-reset .x-panel-body ol,
            .x-panel-reset .x-panel-body ul,
            .x-panel-reset .x-panel-body dir,
            .x-panel-reset .x-panel-body menu,
            .x-panel-reset .x-panel-body dd {
                margin-left: 40px;
            }
            .x-panel-reset .x-panel-body ul,
            .x-panel-reset .x-panel-body menu,
            .x-panel-reset .x-panel-body dir {
                list-style-type: disc;
            }
            .x-panel-reset .x-panel-body ol {
                list-style-type: decimal;
            }
            .x-panel-reset .x-panel-body ol ul,
            .x-panel-reset .x-panel-body ul ol,
            .x-panel-reset .x-panel-body ul ul,
            .x-panel-reset .x-panel-body ol ol {
                margin-top: 0;
                margin-bottom: 0;
            }
            .x-panel-reset .x-panel-body u,
            .x-panel-reset .x-panel-body ins {
                text-decoration: underline;
            }
            .x-panel-reset .x-panel-body br:before {
                content: "\A";
            }
            .x-panel-reset .x-panel-body :before,
            .x-panel-reset .x-panel-body :after {
                white-space: pre-line;
            }
            .x-panel-reset .x-panel-body center {
                text-align: center;
            }
            .x-panel-reset .x-panel-body :link,
            .x-panel-reset .x-panel-body :visited {
                text-decoration: underline;
            }
            .x-panel-reset .x-panel-body :focus {
                outline: invert dotted thin;
            }
            .x-panel-reset .x-panel-body BDO[DIR="ltr"] {
                direction: ltr;
                unicode-bidi: bidi-override;
            }
            .x-panel-reset .x-panel-body BDO[DIR="rtl"] {
                direction: rtl;
                unicode-bidi: bidi-override;
            }
            .x-window {
                zoom: 1;
            }
            .x-window .x-window-handle {
                opacity: 0;
                -moz-opacity: 0;
                filter: alpha(opacity=0);
            }
            .x-window-proxy {
                border: 1px solid;
                z-index: 12000;
                overflow: hidden;
                position: absolute;
                left: 0;
                top: 0;
                display: none;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
            }
            .x-window-header {
                overflow: hidden;
                zoom: 1;
            }
            .x-window-bwrap {
                z-index: 1;
                position: relative;
                zoom: 1;
                left: 0;
                top: 0;
            }
            .x-window-tl .x-window-header {
                padding: 5px 0 4px 0;
            }
            .x-window-header-text {
                cursor: pointer;
            }
            .x-window-tc {
                background: transparent repeat-x 0 0;
                overflow: hidden;
                zoom: 1;
            }
            .x-window-tl {
                background: transparent no-repeat 0 0;
                padding-left: 6px;
                zoom: 1;
                z-index: 1;
                position: relative;
            }
            .x-window-tr {
                background: transparent no-repeat right 0;
                padding-right: 6px;
            }
            .x-window-bc {
                background: transparent repeat-x 0 bottom;
                zoom: 1;
            }
            .x-window-bc .x-window-footer {
                padding-bottom: 6px;
                zoom: 1;
                font-size: 0;
                line-height: 0;
            }
            .x-window-bl {
                background: transparent no-repeat 0 bottom;
                padding-left: 6px;
                zoom: 1;
            }
            .x-window-br {
                background: transparent no-repeat right bottom;
                padding-right: 6px;
                zoom: 1;
            }
            .x-window-mc {
                border: 1px solid;
                padding: 0;
                margin: 0;
            }
            .x-window-ml {
                background: transparent repeat-y 0 0;
                padding-left: 6px;
                zoom: 1;
            }
            .x-window-mr {
                background: transparent repeat-y right 0;
                padding-right: 6px;
                zoom: 1;
            }
            .x-window-body {
                overflow: hidden;
            }
            .x-window-bwrap {
                overflow: hidden;
            }
            .x-window-maximized .x-window-bl,
            .x-window-maximized .x-window-br,
            .x-window-maximized .x-window-ml,
            .x-window-maximized .x-window-mr,
            .x-window-maximized .x-window-tl,
            .x-window-maximized .x-window-tr {
                padding: 0;
            }
            .x-window-maximized .x-window-footer {
                padding-bottom: 0;
            }
            .x-window-maximized .x-window-tc {
                padding-left: 3px;
                padding-right: 3px;
            }
            .x-window-maximized .x-window-mc {
                border-left: 0 none;
                border-right: 0 none;
            }
            .x-window-tbar .x-toolbar,
            .x-window-bbar .x-toolbar {
                border-left: 0 none;
                border-right: 0 none;
            }
            .x-window-bbar .x-toolbar {
                border-top: 1px solid;
                border-bottom: 0 none;
            }
            .x-window-draggable,
            .x-window-draggable .x-window-header-text {
                cursor: move;
            }
            .x-window-maximized .x-window-draggable,
            .x-window-maximized .x-window-draggable .x-window-header-text {
                cursor: default;
            }
            .x-window-body {
                background-color: transparent;
            }
            .x-panel-ghost .x-window-tl {
                border-bottom: 1px solid;
            }
            .x-panel-collapsed .x-window-tl {
                border-bottom: 1px solid;
            }
            .x-window-maximized-ct {
                overflow: hidden;
            }
            .x-window-maximized .x-window-handle {
                display: none;
            }
            .x-window-sizing-ghost ul {
                border: 0 none !important;
            }
            .x-dlg-focus {
                -moz-outline: 0 none;
                outline: 0 none;
                width: 0;
                height: 0;
                overflow: hidden;
                position: absolute;
                top: 0;
                left: 0;
            }
            .ext-webkit .x-dlg-focus {
                width: 1px;
                height: 1px;
            }
            .x-dlg-mask {
                z-index: 10000;
                display: none;
                position: absolute;
                top: 0;
                left: 0;
                -moz-opacity: 0.5;
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            body.ext-ie6.x-body-masked select {
                visibility: hidden;
            }
            body.ext-ie6.x-body-masked .x-window select {
                visibility: visible;
            }
            .x-window-plain .x-window-mc {
                border: 1px solid;
            }
            .x-window-plain .x-window-body {
                border: 1px solid;
                background: transparent !important;
            }
            .x-html-editor-wrap {
                border: 1px solid;
            }
            .x-html-editor-tb .x-btn-text {
                background: transparent no-repeat;
            }
            .x-html-editor-tb .x-edit-bold,
            .x-menu-item img.x-edit-bold {
                background-position: 0 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-italic,
            .x-menu-item img.x-edit-italic {
                background-position: -16px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-underline,
            .x-menu-item img.x-edit-underline {
                background-position: -32px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-forecolor,
            .x-menu-item img.x-edit-forecolor {
                background-position: -160px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-backcolor,
            .x-menu-item img.x-edit-backcolor {
                background-position: -176px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-justifyleft,
            .x-menu-item img.x-edit-justifyleft {
                background-position: -112px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-justifycenter,
            .x-menu-item img.x-edit-justifycenter {
                background-position: -128px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-justifyright,
            .x-menu-item img.x-edit-justifyright {
                background-position: -144px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-insertorderedlist,
            .x-menu-item img.x-edit-insertorderedlist {
                background-position: -80px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-insertunorderedlist,
            .x-menu-item img.x-edit-insertunorderedlist {
                background-position: -96px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-increasefontsize,
            .x-menu-item img.x-edit-increasefontsize {
                background-position: -48px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-decreasefontsize,
            .x-menu-item img.x-edit-decreasefontsize {
                background-position: -64px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-sourceedit,
            .x-menu-item img.x-edit-sourceedit {
                background-position: -192px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tb .x-edit-createlink,
            .x-menu-item img.x-edit-createlink {
                background-position: -208px 0;
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-html-editor-tip .x-tip-bd .x-tip-bd-inner {
                padding: 5px;
                padding-bottom: 1px;
            }
            .x-html-editor-tb .x-toolbar {
                position: static !important;
            }
            .x-panel-noborder .x-panel-body-noborder {
                border-width: 0;
            }
            .x-panel-noborder .x-panel-header-noborder {
                border-width: 0 0 1px;
                border-style: solid;
            }
            .x-panel-noborder .x-panel-tbar-noborder .x-toolbar {
                border-width: 0 0 1px;
                border-style: solid;
            }
            .x-panel-noborder .x-panel-bbar-noborder .x-toolbar {
                border-width: 1px 0 0 0;
                border-style: solid;
            }
            .x-window-noborder .x-window-mc {
                border-width: 0;
            }
            .x-window-plain .x-window-body-noborder {
                border-width: 0;
            }
            .x-tab-panel-noborder .x-tab-panel-body-noborder {
                border-width: 0;
            }
            .x-tab-panel-noborder .x-tab-panel-header-noborder {
                border-width: 0 0 1px 0;
            }
            .x-tab-panel-noborder .x-tab-panel-footer-noborder {
                border-width: 1px 0 0 0;
            }
            .x-tab-panel-bbar-noborder .x-toolbar {
                border-width: 1px 0 0 0;
                border-style: solid;
            }
            .x-tab-panel-tbar-noborder .x-toolbar {
                border-width: 0 0 1px;
                border-style: solid;
            }
            .x-border-layout-ct {
                position: relative;
            }
            .x-border-panel {
                position: absolute;
                left: 0;
                top: 0;
            }
            .x-tool-collapse-south {
                background-position: 0 -195px;
            }
            .x-tool-collapse-south-over {
                background-position: -15px -195px;
            }
            .x-tool-collapse-north {
                background-position: 0 -210px;
            }
            .x-tool-collapse-north-over {
                background-position: -15px -210px;
            }
            .x-tool-collapse-west {
                background-position: 0 -180px;
            }
            .x-tool-collapse-west-over {
                background-position: -15px -180px;
            }
            .x-tool-collapse-east {
                background-position: 0 -165px;
            }
            .x-tool-collapse-east-over {
                background-position: -15px -165px;
            }
            .x-tool-expand-south {
                background-position: 0 -210px;
            }
            .x-tool-expand-south-over {
                background-position: -15px -210px;
            }
            .x-tool-expand-north {
                background-position: 0 -195px;
            }
            .x-tool-expand-north-over {
                background-position: -15px -195px;
            }
            .x-tool-expand-west {
                background-position: 0 -165px;
            }
            .x-tool-expand-west-over {
                background-position: -15px -165px;
            }
            .x-tool-expand-east {
                background-position: 0 -180px;
            }
            .x-tool-expand-east-over {
                background-position: -15px -180px;
            }
            .x-tool-expand-north,
            .x-tool-expand-south {
                float: right;
                margin: 3px;
            }
            .x-tool-expand-east,
            .x-tool-expand-west {
                float: none;
                margin: 3px 2px;
            }
            .x-accordion-hd .x-tool-toggle {
                background-position: 0 -255px;
            }
            .x-accordion-hd .x-tool-toggle-over {
                background-position: -15px -255px;
            }
            .x-panel-collapsed .x-accordion-hd .x-tool-toggle {
                background-position: 0 -240px;
            }
            .x-panel-collapsed .x-accordion-hd .x-tool-toggle-over {
                background-position: -15px -240px;
            }
            .x-accordion-hd {
                padding-top: 4px;
                padding-bottom: 3px;
                border-top: 0 none;
                background: transparent repeat-x 0 -9px;
            }
            .x-layout-collapsed {
                position: absolute;
                left: -10000px;
                top: -10000px;
                visibility: hidden;
                width: 20px;
                height: 20px;
                overflow: hidden;
                border: 1px solid;
                z-index: 20;
            }
            .ext-border-box .x-layout-collapsed {
                width: 22px;
                height: 22px;
            }
            .x-layout-collapsed-over {
                cursor: pointer;
            }
            .x-layout-collapsed-west .x-layout-collapsed-tools,
            .x-layout-collapsed-east .x-layout-collapsed-tools {
                position: absolute;
                top: 0;
                left: 0;
                width: 20px;
                height: 20px;
            }
            .x-layout-split {
                position: absolute;
                height: 5px;
                width: 5px;
                line-height: 1px;
                font-size: 1px;
                z-index: 3;
                background-color: transparent;
            }
            .ext-strict .ext-ie6 .x-layout-split {
                background-color: #fff !important;
                filter: alpha(opacity=1);
            }
            .x-layout-split-h {
                background-image:/*savepage-url=../images/default/s.gif*/ url();
                background-position: left;
            }
            .x-layout-split-v {
                background-image:/*savepage-url=../images/default/s.gif*/ url();
                background-position: top;
            }
            .x-column-layout-ct {
                overflow: hidden;
                zoom: 1;
            }
            .x-column {
                float: left;
                padding: 0;
                margin: 0;
                overflow: hidden;
                zoom: 1;
            }
            .x-column-inner {
                overflow: hidden;
                zoom: 1;
            }
            .x-layout-mini {
                position: absolute;
                top: 0;
                left: 0;
                display: block;
                width: 5px;
                height: 35px;
                cursor: pointer;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
            }
            .x-layout-mini-over,
            .x-layout-collapsed-over .x-layout-mini {
                opacity: 1;
                -moz-opacity: 1;
                filter: none;
            }
            .x-layout-split-west .x-layout-mini {
                top: 48%;
            }
            .x-layout-split-east .x-layout-mini {
                top: 48%;
            }
            .x-layout-split-north .x-layout-mini {
                left: 48%;
                height: 5px;
                width: 35px;
            }
            .x-layout-split-south .x-layout-mini {
                left: 48%;
                height: 5px;
                width: 35px;
            }
            .x-layout-cmini-west .x-layout-mini {
                top: 48%;
            }
            .x-layout-cmini-east .x-layout-mini {
                top: 48%;
            }
            .x-layout-cmini-north .x-layout-mini {
                left: 48%;
                height: 5px;
                width: 35px;
            }
            .x-layout-cmini-south .x-layout-mini {
                left: 48%;
                height: 5px;
                width: 35px;
            }
            .x-layout-cmini-west,
            .x-layout-cmini-east {
                border: 0 none;
                width: 5px !important;
                padding: 0;
                background-color: transparent;
            }
            .x-layout-cmini-north,
            .x-layout-cmini-south {
                border: 0 none;
                height: 5px !important;
                padding: 0;
                background-color: transparent;
            }
            .x-viewport,
            .x-viewport body {
                margin: 0;
                padding: 0;
                border: 0 none;
                overflow: hidden;
                height: 100%;
            }
            .x-abs-layout-item {
                position: absolute;
                left: 0;
                top: 0;
            }
            .ext-ie input.x-abs-layout-item,
            .ext-ie textarea.x-abs-layout-item {
                margin: 0;
            }
            .x-box-layout-ct {
                overflow: hidden;
                zoom: 1;
            }
            .x-box-inner {
                overflow: hidden;
                zoom: 1;
                position: relative;
                left: 0;
                top: 0;
            }
            .x-box-item {
                position: absolute;
                left: 0;
                top: 0;
            }
            .x-progress-wrap {
                border: 1px solid;
                overflow: hidden;
            }
            .x-progress-inner {
                height: 18px;
                background: repeat-x;
                position: relative;
            }
            .x-progress-bar {
                height: 18px;
                float: left;
                width: 0;
                background: repeat-x left center;
                border-top: 1px solid;
                border-bottom: 1px solid;
                border-right: 1px solid;
            }
            .x-progress-text {
                padding: 1px 5px;
                overflow: hidden;
                position: absolute;
                left: 0;
                text-align: center;
            }
            .x-progress-text-back {
                line-height: 16px;
            }
            .ext-ie .x-progress-text-back {
                line-height: 15px;
            }
            .ext-strict .ext-ie7 .x-progress-text-back {
                width: 100%;
            }
            .x-list-header {
                background: repeat-x 0 bottom;
                cursor: default;
                zoom: 1;
                height: 22px;
            }
            .x-list-header-inner div {
                display: block;
                float: left;
                overflow: hidden;
                -o-text-overflow: ellipsis;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .x-list-header-inner div em {
                display: block;
                border-left: 1px solid;
                padding: 4px 4px;
                overflow: hidden;
                -moz-user-select: none;
                -khtml-user-select: none;
                line-height: 14px;
            }
            .x-list-body {
                overflow: auto;
                overflow-x: hidden;
                overflow-y: auto;
                zoom: 1;
                float: left;
                width: 100%;
            }
            .x-list-body dl {
                zoom: 1;
            }
            .x-list-body dt {
                display: block;
                float: left;
                overflow: hidden;
                -o-text-overflow: ellipsis;
                text-overflow: ellipsis;
                white-space: nowrap;
                cursor: pointer;
                zoom: 1;
            }
            .x-list-body dt em {
                display: block;
                padding: 3px 4px;
                overflow: hidden;
                -moz-user-select: none;
                -khtml-user-select: none;
            }
            .x-list-resizer {
                border-left: 1px solid;
                border-right: 1px solid;
                position: absolute;
                left: 0;
                top: 0;
            }
            .x-list-header-inner em.sort-asc {
                background: transparent no-repeat center 0;
                border-style: solid;
                border-width: 0 1px 1px;
                padding-bottom: 3px;
            }
            .x-list-header-inner em.sort-desc {
                background: transparent no-repeat center -23px;
                border-style: solid;
                border-width: 0 1px 1px;
                padding-bottom: 3px;
            }
            .x-slider {
                zoom: 1;
            }
            .x-slider-inner {
                position: relative;
                left: 0;
                top: 0;
                overflow: visible;
                zoom: 1;
            }
            .x-slider-focus {
                position: absolute;
                left: 0;
                top: 0;
                width: 1px;
                height: 1px;
                line-height: 1px;
                font-size: 1px;
                -moz-outline: 0 none;
                outline: 0 none;
                -moz-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: ignore;
                display: block;
                overflow: hidden;
            }
            .x-slider-horz {
                padding-left: 7px;
                background: transparent no-repeat 0 -22px;
            }
            .x-slider-horz .x-slider-end {
                padding-right: 7px;
                zoom: 1;
                background: transparent no-repeat right -44px;
            }
            .x-slider-horz .x-slider-inner {
                background: transparent repeat-x 0 0;
                height: 22px;
            }
            .x-slider-horz .x-slider-thumb {
                width: 14px;
                height: 15px;
                position: absolute;
                left: 0;
                top: 3px;
                background: transparent no-repeat 0 0;
            }
            .x-slider-horz .x-slider-thumb-over {
                background-position: -14px -15px;
            }
            .x-slider-horz .x-slider-thumb-drag {
                background-position: -28px -30px;
            }
            .x-slider-vert {
                padding-top: 7px;
                background: transparent no-repeat -44px 0;
                width: 22px;
            }
            .x-slider-vert .x-slider-end {
                padding-bottom: 7px;
                zoom: 1;
                background: transparent no-repeat -22px bottom;
            }
            .x-slider-vert .x-slider-inner {
                background: transparent repeat-y 0 0;
            }
            .x-slider-vert .x-slider-thumb {
                width: 15px;
                height: 14px;
                position: absolute;
                left: 3px;
                bottom: 0;
                background: transparent no-repeat 0 0;
            }
            .x-slider-vert .x-slider-thumb-over {
                background-position: -15px -14px;
            }
            .x-slider-vert .x-slider-thumb-drag {
                background-position: -30px -28px;
            }
            .x-window-dlg .x-window-body {
                border: 0 none !important;
                padding: 5px 10px;
                overflow: hidden !important;
            }
            .x-window-dlg .x-window-mc {
                border: 0 none !important;
            }
            .x-window-dlg .ext-mb-input {
                margin-top: 4px;
                width: 95%;
            }
            .x-window-dlg .ext-mb-textarea {
                margin-top: 4px;
            }
            .x-window-dlg .x-progress-wrap {
                margin-top: 4px;
            }
            .ext-ie .x-window-dlg .x-progress-wrap {
                margin-top: 6px;
            }
            .x-window-dlg .x-msg-box-wait {
                background: transparent no-repeat left;
                display: block;
                width: 300px;
                padding-left: 18px;
                line-height: 18px;
            }
            .x-window-dlg .ext-mb-icon {
                float: left;
                width: 47px;
                height: 32px;
            }
            .x-window-dlg .x-dlg-icon .ext-mb-content {
                zoom: 1;
                margin-left: 47px;
            }
            .x-window-dlg .ext-mb-info,
            .x-window-dlg .ext-mb-warning,
            .x-window-dlg .ext-mb-question,
            .x-window-dlg .ext-mb-error {
                background: transparent no-repeat top left;
            }
            .ext-gecko2 .ext-mb-fix-cursor {
                overflow: auto;
            }
            .ext-el-mask {
                background-color: #ccc;
            }
            .ext-el-mask-msg {
                border-color: #6593cf;
                background-color: #c3daf9;
                background-image:/*savepage-url=../images/default/box/tb-blue.gif*/ url();
            }
            .ext-el-mask-msg div {
                background-color: #eee;
                border-color: #a3bad9;
                color: #222;
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-mask-loading div {
                background-color: #fbfbfb;
                background-image:/*savepage-url=../images/default/grid/loading.gif*/ url();
            }
            .x-item-disabled {
                color: gray;
            }
            .x-item-disabled * {
                color: gray !important;
            }
            .x-splitbar-proxy {
                background-color: #aaa;
            }
            .x-color-palette a {
                border-color: #fff;
            }
            .x-color-palette a:hover,
            .x-color-palette a.x-color-palette-sel {
                border-color: #8bb8f3;
                background-color: #deecfd;
            }
            .x-color-palette em {
                border-color: #aca899;
            }
            .x-ie-shadow {
                background-color: #777;
            }
            .x-shadow .xsmc {
                background-image:/*savepage-url=../images/default/shadow-c.png*/ url();
            }
            .x-shadow .xsml,
            .x-shadow .xsmr {
                background-image:/*savepage-url=../images/default/shadow-lr.png*/ url();
            }
            .x-shadow .xstl,
            .x-shadow .xstc,
            .x-shadow .xstr,
            .x-shadow .xsbl,
            .x-shadow .xsbc,
            .x-shadow .xsbr {
                background-image:/*savepage-url=../images/default/shadow.png*/ url();
            }
            .loading-indicator {
                font-size: 11px;
                background-image:/*savepage-url=../images/default/grid/loading.gif*/ url();
            }
            .x-spotlight {
                background-color: #ccc;
            }
            .x-tab-panel-header,
            .x-tab-panel-footer {
                background-color: #deecfd;
                border-color: #8db2e3;
                overflow: hidden;
                zoom: 1;
            }
            .x-tab-panel-header,
            .x-tab-panel-footer {
                border-color: #8db2e3;
            }
            ul.x-tab-strip-top {
                background-color: #cedff5;
                background-image:/*savepage-url=../images/default/tabs/tab-strip-bg.gif*/ url();
                border-bottom-color: #8db2e3;
            }
            ul.x-tab-strip-bottom {
                background-color: #cedff5;
                background-image:/*savepage-url=../images/default/tabs/tab-strip-btm-bg.gif*/ url();
                border-top-color: #8db2e3;
            }
            .x-tab-panel-header-plain .x-tab-strip-spacer,
            .x-tab-panel-footer-plain .x-tab-strip-spacer {
                border-color: #8db2e3;
                background-color: #deecfd;
            }
            .x-tab-strip span.x-tab-strip-text {
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica;
                color: #416aa3;
            }
            .x-tab-strip-over span.x-tab-strip-text {
                color: #15428b;
            }
            .x-tab-strip-active span.x-tab-strip-text {
                color: #15428b;
                font-weight: bold;
            }
            .x-tab-strip-disabled .x-tabs-text {
                color: #aaa;
            }
            .x-tab-strip-top .x-tab-right,
            .x-tab-strip-top .x-tab-left,
            .x-tab-strip-top .x-tab-strip-inner {
                background-image:/*savepage-url=../images/default/tabs/tabs-sprite.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-right {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-inactive-right-bg.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-left {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-inactive-left-bg.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-strip-over .x-tab-right {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-over-right-bg.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-strip-over .x-tab-left {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-over-left-bg.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-right {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-right-bg.gif*/ url();
            }
            .x-tab-strip-bottom .x-tab-strip-active .x-tab-left {
                background-image:/*savepage-url=../images/default/tabs/tab-btm-left-bg.gif*/ url();
            }
            .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close {
                background-image:/*savepage-url=../images/default/tabs/tab-close.gif*/ url();
            }
            .x-tab-strip .x-tab-strip-closable a.x-tab-strip-close:hover {
                background-image:/*savepage-url=../images/default/tabs/tab-close.gif*/ url();
            }
            .x-tab-panel-body {
                border-color: #8db2e3;
                background-color: #fff;
            }
            .x-tab-panel-body-top {
                border-top: 0 none;
            }
            .x-tab-panel-body-bottom {
                border-bottom: 0 none;
            }
            .x-tab-scroller-left {
                background-image:/*savepage-url=../images/default/tabs/scroll-left.gif*/ url();
                border-bottom-color: #8db2e3;
            }
            .x-tab-scroller-left-over {
                background-position: 0 0;
            }
            .x-tab-scroller-left-disabled {
                background-position: -18px 0;
                opacity: 0.5;
                -moz-opacity: 0.5;
                filter: alpha(opacity=50);
                cursor: default;
            }
            .x-tab-scroller-right {
                background-image:/*savepage-url=../images/default/tabs/scroll-right.gif*/ url();
                border-bottom-color: #8db2e3;
            }
            .x-tab-panel-bbar .x-toolbar,
            .x-tab-panel-tbar .x-toolbar {
                border-color: #99bbe8;
            }
            .x-form-field {
                font:
                    normal 12px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-form-text,
            textarea.x-form-field {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/form/text-bg.gif*/ var(--savepage-url-7);
                border-color: #b5b8c8;
            }
            .x-form-select-one {
                background-color: #fff;
                border-color: #b5b8c8;
            }
            .x-form-check-group-label {
                border-bottom: 1px solid #99bbe8;
                color: #15428b;
            }
            .x-editor .x-form-check-wrap {
                background-color: #fff;
            }
            .x-form-field-wrap .x-form-trigger {
                background-image:/*savepage-url=../images/default/form/trigger.gif*/ url();
                border-bottom-color: #b5b8c8;
            }
            .x-form-field-wrap .x-form-date-trigger {
                background-image:/*savepage-url=../images/default/form/date-trigger.gif*/ url();
            }
            .x-form-field-wrap .x-form-clear-trigger {
                background-image:/*savepage-url=../images/default/form/clear-trigger.gif*/ url();
            }
            .x-form-field-wrap .x-form-search-trigger {
                background-image:/*savepage-url=../images/default/form/search-trigger.gif*/ url();
            }
            .x-trigger-wrap-focus .x-form-trigger {
                border-bottom-color: #7eadd9;
            }
            .x-item-disabled .x-form-trigger-over {
                border-bottom-color: #b5b8c8;
            }
            .x-item-disabled .x-form-trigger-click {
                border-bottom-color: #b5b8c8;
            }
            .x-form-focus,
            textarea.x-form-focus {
                border-color: #7eadd9;
            }
            .x-form-invalid,
            textarea.x-form-invalid {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/grid/invalid_line.gif*/ url();
                border-color: #c30;
            }
            .x-form-invalid.x-form-composite {
                border: 0;
                background-image: none;
            }
            .x-form-invalid.x-form-composite .x-form-invalid {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/grid/invalid_line.gif*/ url();
                border-color: #c30;
            }
            .x-form-inner-invalid,
            textarea.x-form-inner-invalid {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/grid/invalid_line.gif*/ url();
            }
            .x-form-grow-sizer {
                font:
                    normal 12px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-form-item {
                font:
                    normal 12px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-form-invalid-msg {
                color: #c0272b;
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                background-image:/*savepage-url=../images/default/shared/warning.gif*/ url();
            }
            .x-form-empty-field {
                color: gray;
            }
            .x-small-editor .x-form-field {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .ext-webkit .x-small-editor .x-form-field {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-form-invalid-icon {
                background-image:/*savepage-url=../images/default/form/exclamation.gif*/ url();
            }
            .x-fieldset {
                border-color: #b5b8c8;
            }
            .x-fieldset legend {
                font:
                    bold 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                color: #15428b;
            }
            .x-btn {
                font:
                    normal 11px tahoma,
                    verdana,
                    helvetica;
            }
            .x-btn button {
                font:
                    normal 11px arial,
                    tahoma,
                    verdana,
                    helvetica;
                color: #333;
            }
            .x-btn em {
                font-style: normal;
                font-weight: normal;
            }
            .x-btn-tl,
            .x-btn-tr,
            .x-btn-tc,
            .x-btn-ml,
            .x-btn-mr,
            .x-btn-mc,
            .x-btn-bl,
            .x-btn-br,
            .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn.gif*/ url();
            }
            .x-btn-click .x-btn-text,
            .x-btn-menu-active .x-btn-text,
            .x-btn-pressed .x-btn-text {
                color: #000;
            }
            .x-btn-disabled * {
                color: gray !important;
            }
            .x-btn-mc em.x-btn-arrow {
                background-image:/*savepage-url=../images/default/button/arrow.gif*/ url();
            }
            .x-btn-mc em.x-btn-split {
                background-image:/*savepage-url=../images/default/button/s-arrow.gif*/ url();
            }
            .x-btn-over .x-btn-mc em.x-btn-split,
            .x-btn-click .x-btn-mc em.x-btn-split,
            .x-btn-menu-active .x-btn-mc em.x-btn-split,
            .x-btn-pressed .x-btn-mc em.x-btn-split {
                background-image:/*savepage-url=../images/default/button/s-arrow-o.gif*/ url();
            }
            .x-btn-mc em.x-btn-arrow-bottom {
                background-image:/*savepage-url=../images/default/button/s-arrow-b-noline.gif*/ url();
            }
            .x-btn-mc em.x-btn-split-bottom {
                background-image:/*savepage-url=../images/default/button/s-arrow-b.gif*/ url();
            }
            .x-btn-over .x-btn-mc em.x-btn-split-bottom,
            .x-btn-click .x-btn-mc em.x-btn-split-bottom,
            .x-btn-menu-active .x-btn-mc em.x-btn-split-bottom,
            .x-btn-pressed .x-btn-mc em.x-btn-split-bottom {
                background-image:/*savepage-url=../images/default/button/s-arrow-bo.gif*/ url();
            }
            .x-btn-group-header {
                color: #3e6aaa;
            }
            .x-btn-group-tc {
                background-image:/*savepage-url=../images/default/button/group-tb.gif*/ url();
            }
            .x-btn-group-tl {
                background-image:/*savepage-url=../images/default/button/group-cs.gif*/ url();
            }
            .x-btn-group-tr {
                background-image:/*savepage-url=../images/default/button/group-cs.gif*/ url();
            }
            .x-btn-group-bc {
                background-image:/*savepage-url=../images/default/button/group-tb.gif*/ url();
            }
            .x-btn-group-bl {
                background-image:/*savepage-url=../images/default/button/group-cs.gif*/ url();
            }
            .x-btn-group-br {
                background-image:/*savepage-url=../images/default/button/group-cs.gif*/ url();
            }
            .x-btn-group-ml {
                background-image:/*savepage-url=../images/default/button/group-lr.gif*/ url();
            }
            .x-btn-group-mr {
                background-image:/*savepage-url=../images/default/button/group-lr.gif*/ url();
            }
            .x-btn-group-notitle .x-btn-group-tc {
                background-image:/*savepage-url=../images/default/button/group-tb.gif*/ url();
            }
            .x-toolbar {
                border-color: #a9bfd3;
                background-color: #d0def0;
                background-image:/*savepage-url=../images/default/toolbar/bg.gif*/ url();
            }
            .x-toolbar td,
            .x-toolbar span,
            .x-toolbar input,
            .x-toolbar div,
            .x-toolbar select,
            .x-toolbar label {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-toolbar .x-item-disabled {
                color: gray;
            }
            .x-toolbar .x-item-disabled * {
                color: gray;
            }
            .x-toolbar .x-btn-mc em.x-btn-split {
                background-image:/*savepage-url=../images/default/button/s-arrow-noline.gif*/ url();
            }
            .x-toolbar .x-btn-over .x-btn-mc em.x-btn-split,
            .x-toolbar .x-btn-click .x-btn-mc em.x-btn-split,
            .x-toolbar .x-btn-menu-active .x-btn-mc em.x-btn-split,
            .x-toolbar .x-btn-pressed .x-btn-mc em.x-btn-split {
                background-image:/*savepage-url=../images/default/button/s-arrow-o.gif*/ url();
            }
            .x-toolbar .x-btn-mc em.x-btn-split-bottom {
                background-image:/*savepage-url=../images/default/button/s-arrow-b-noline.gif*/ url();
            }
            .x-toolbar .x-btn-over .x-btn-mc em.x-btn-split-bottom,
            .x-toolbar .x-btn-click .x-btn-mc em.x-btn-split-bottom,
            .x-toolbar .x-btn-menu-active .x-btn-mc em.x-btn-split-bottom,
            .x-toolbar .x-btn-pressed .x-btn-mc em.x-btn-split-bottom {
                background-image:/*savepage-url=../images/default/button/s-arrow-bo.gif*/ url();
            }
            .x-toolbar .xtb-sep {
                background-image:/*savepage-url=../images/default/grid/grid-blue-split.gif*/ url();
            }
            .x-tbar-page-first {
                background-image:/*savepage-url=../images/default/grid/page-first.gif*/ url() !important;
            }
            .x-tbar-loading {
                background-image:/*savepage-url=../images/default/grid/refresh.gif*/ url() !important;
            }
            .x-tbar-page-last {
                background-image:/*savepage-url=../images/default/grid/page-last.gif*/ url() !important;
            }
            .x-tbar-page-next {
                background-image:/*savepage-url=../images/default/grid/page-next.gif*/ url() !important;
            }
            .x-tbar-page-prev {
                background-image:/*savepage-url=../images/default/grid/page-prev.gif*/ url() !important;
            }
            .x-item-disabled .x-tbar-loading {
                background-image:/*savepage-url=../images/default/grid/refresh-disabled.gif*/ url() !important;
            }
            .x-item-disabled .x-tbar-page-first {
                background-image:/*savepage-url=../images/default/grid/page-first-disabled.gif*/ url() !important;
            }
            .x-item-disabled .x-tbar-page-last {
                background-image:/*savepage-url=../images/default/grid/page-last-disabled.gif*/ url() !important;
            }
            .x-item-disabled .x-tbar-page-next {
                background-image:/*savepage-url=../images/default/grid/page-next-disabled.gif*/ url() !important;
            }
            .x-item-disabled .x-tbar-page-prev {
                background-image:/*savepage-url=../images/default/grid/page-prev-disabled.gif*/ url() !important;
            }
            .x-paging-info {
                color: #444;
            }
            .x-toolbar-more-icon {
                background-image:/*savepage-url=../images/default/toolbar/more.gif*/ url() !important;
            }
            .x-resizable-handle {
                background-color: #fff;
            }
            .x-resizable-over .x-resizable-handle-east,
            .x-resizable-pinned .x-resizable-handle-east,
            .x-resizable-over .x-resizable-handle-west,
            .x-resizable-pinned .x-resizable-handle-west {
                background-image:/*savepage-url=../images/default/sizer/e-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-south,
            .x-resizable-pinned .x-resizable-handle-south,
            .x-resizable-over .x-resizable-handle-north,
            .x-resizable-pinned .x-resizable-handle-north {
                background-image:/*savepage-url=../images/default/sizer/s-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-north,
            .x-resizable-pinned .x-resizable-handle-north {
                background-image:/*savepage-url=../images/default/sizer/s-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-southeast,
            .x-resizable-pinned .x-resizable-handle-southeast {
                background-image:/*savepage-url=../images/default/sizer/se-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-northwest,
            .x-resizable-pinned .x-resizable-handle-northwest {
                background-image:/*savepage-url=../images/default/sizer/nw-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-northeast,
            .x-resizable-pinned .x-resizable-handle-northeast {
                background-image:/*savepage-url=../images/default/sizer/ne-handle.gif*/ url();
            }
            .x-resizable-over .x-resizable-handle-southwest,
            .x-resizable-pinned .x-resizable-handle-southwest {
                background-image:/*savepage-url=../images/default/sizer/sw-handle.gif*/ url();
            }
            .x-resizable-proxy {
                border-color: #3b5a82;
            }
            .x-resizable-overlay {
                background-color: #fff;
            }
            .x-grid3 {
                background-color: #fff;
            }
            .x-grid-panel .x-panel-mc .x-panel-body {
                border-color: #99bbe8;
            }
            .x-grid3-row td,
            .x-grid3-summary-row td {
                font:
                    normal 11px/13px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-grid3-hd-row td {
                font:
                    normal 11px/15px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-grid3-hd-row td {
                border-left-color: #eee;
                border-right-color: #d0d0d0;
            }
            .x-grid-row-loading {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/shared/loading-balls.gif*/ url();
            }
            .x-grid3-row {
                border-color: #ededed;
                border-top-color: #fff;
            }
            .x-grid3-row-alt {
                background-color: #fafafa;
            }
            .x-grid3-row-over {
                border-color: #ddd;
                background-color: #efefef;
                background-image:/*savepage-url=../images/default/grid/row-over.gif*/ url();
            }
            .x-grid3-resize-proxy {
                background-color: #777;
            }
            .x-grid3-resize-marker {
                background-color: #777;
            }
            .x-grid3-header {
                background-color: #f9f9f9;
                background-image:/*savepage-url=../images/default/grid/grid3-hrow.gif*/ url();
            }
            .x-grid3-header-pop {
                border-left-color: #d0d0d0;
            }
            .x-grid3-header-pop-inner {
                border-left-color: #eee;
                background-image:/*savepage-url=../images/default/grid/hd-pop.gif*/ url();
            }
            td.x-grid3-hd-over,
            td.sort-desc,
            td.sort-asc,
            td.x-grid3-hd-menu-open {
                border-left-color: #aaccf6;
                border-right-color: #aaccf6;
            }
            td.x-grid3-hd-over .x-grid3-hd-inner,
            td.sort-desc .x-grid3-hd-inner,
            td.sort-asc .x-grid3-hd-inner,
            td.x-grid3-hd-menu-open .x-grid3-hd-inner {
                background-color: #ebf3fd;
                background-image:/*savepage-url=../images/default/grid/grid3-hrow-over.gif*/ url();
            }
            .sort-asc .x-grid3-sort-icon {
                background-image:/*savepage-url=../images/default/grid/sort_asc.gif*/ url();
            }
            .sort-desc .x-grid3-sort-icon {
                background-image:/*savepage-url=../images/default/grid/sort_desc.gif*/ url();
            }
            .x-grid3-cell-text,
            .x-grid3-hd-text {
                color: #000;
            }
            .x-grid3-split {
                background-image:/*savepage-url=../images/default/grid/grid-split.gif*/ url();
            }
            .x-grid3-hd-text {
                color: #15428b;
            }
            .x-dd-drag-proxy .x-grid3-hd-inner {
                background-color: #ebf3fd;
                background-image:/*savepage-url=../images/default/grid/grid3-hrow-over.gif*/ url();
                border-color: #aaccf6;
            }
            .col-move-top {
                background-image:/*savepage-url=../images/default/grid/col-move-top.gif*/ url();
            }
            .col-move-bottom {
                background-image:/*savepage-url=../images/default/grid/col-move-bottom.gif*/ url();
            }
            td.grid-hd-group-cell {
                background:/*savepage-url=../images/default/grid/grid3-hrow.gif*/ url() repeat-x bottom;
            }
            .x-grid3-row-selected {
                background-color: #dfe8f6 !important;
                background-image: none;
                border-color: #a3bae9;
            }
            .x-grid3-cell-selected {
                background-color: #b8cfee !important;
                color: #000;
            }
            .x-grid3-cell-selected span {
                color: #000 !important;
            }
            .x-grid3-cell-selected .x-grid3-cell-text {
                color: #000;
            }
            .x-grid3-locked td.x-grid3-row-marker,
            .x-grid3-locked .x-grid3-row-selected td.x-grid3-row-marker {
                background-color: #ebeadb !important;
                background-image:/*savepage-url=../images/default/grid/grid-hrow.gif*/ url() !important;
                color: #000;
                border-top-color: #fff;
                border-right-color: #6fa0df !important;
            }
            .x-grid3-locked td.x-grid3-row-marker div,
            .x-grid3-locked .x-grid3-row-selected td.x-grid3-row-marker div {
                color: #15428b !important;
            }
            .x-grid3-dirty-cell {
                background-image:/*savepage-url=../images/default/grid/dirty.gif*/ url();
            }
            .x-grid3-topbar,
            .x-grid3-bottombar {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-grid3-bottombar .x-toolbar {
                border-top-color: #a9bfd3;
            }
            .x-props-grid .x-grid3-td-name .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-bg.gif*/ url() !important;
                color: #000 !important;
            }
            .x-props-grid .x-grid3-body .x-grid3-td-name {
                background-color: #fff !important;
                border-right-color: #eee;
            }
            .xg-hmenu-sort-asc .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/grid/hmenu-asc.gif*/ url();
            }
            .xg-hmenu-sort-desc .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/grid/hmenu-desc.gif*/ url();
            }
            .xg-hmenu-lock .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/grid/hmenu-lock.gif*/ url();
            }
            .xg-hmenu-unlock .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/grid/hmenu-unlock.gif*/ url();
            }
            .x-grid3-hd-btn {
                background-color: #c3daf9;
                background-image:/*savepage-url=../images/default/grid/grid3-hd-btn.gif*/ url();
            }
            .x-grid3-body .x-grid3-td-expander {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-bg.gif*/ url();
            }
            .x-grid3-row-expander {
                background-image:/*savepage-url=../images/default/grid/row-expand-sprite.gif*/ url();
            }
            .x-grid3-body .x-grid3-td-checker {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-bg.gif*/ url();
            }
            .x-grid3-row-checker,
            .x-grid3-hd-checker {
                background-image:/*savepage-url=../images/default/grid/row-check-sprite.gif*/ url();
            }
            .x-grid3-body .x-grid3-td-numberer {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-bg.gif*/ url();
            }
            .x-grid3-body .x-grid3-td-numberer .x-grid3-cell-inner {
                color: #444;
            }
            .x-grid3-body .x-grid3-td-row-icon {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-bg.gif*/ url();
            }
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-numberer,
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-checker,
            .x-grid3-body .x-grid3-row-selected .x-grid3-td-expander {
                background-image:/*savepage-url=../images/default/grid/grid3-special-col-sel-bg.gif*/ url();
            }
            .x-grid3-check-col {
                background-image:/*savepage-url=../images/default/menu/unchecked.gif*/ url();
            }
            .x-grid3-check-col-on {
                background-image:/*savepage-url=../images/default/menu/checked.gif*/ url();
            }
            .x-grid-group,
            .x-grid-group-body,
            .x-grid-group-hd {
                zoom: 1;
            }
            .x-grid-group-hd {
                border-bottom-color: #99bbe8;
            }
            .x-grid-group-hd div.x-grid-group-title {
                background-image:/*savepage-url=../images/default/grid/group-collapse.gif*/ url();
                color: #3764a0;
                font:
                    bold 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-grid-group-collapsed .x-grid-group-hd div.x-grid-group-title {
                background-image:/*savepage-url=../images/default/grid/group-expand.gif*/ url();
            }
            .x-group-by-icon {
                background-image:/*savepage-url=../images/default/grid/group-by.gif*/ url();
            }
            .x-cols-icon {
                background-image:/*savepage-url=../images/default/grid/columns.gif*/ url();
            }
            .x-show-groups-icon {
                background-image:/*savepage-url=../images/default/grid/group-by.gif*/ url();
            }
            .x-grid-empty {
                color: gray;
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-grid-with-col-lines .x-grid3-row td.x-grid3-cell {
                border-right-color: #ededed;
            }
            .x-grid-with-col-lines .x-grid3-row-selected {
                border-top-color: #a3bae9;
            }
            .x-pivotgrid .x-grid3-header-offset table td {
                background:/*savepage-url=../images/default/grid/grid3-hrow.gif*/ url() repeat-x 50% 100%;
                border-left: 1px solid;
                border-right: 1px solid;
                border-left-color: #eee;
                border-right-color: #d0d0d0;
            }
            .x-pivotgrid .x-grid3-row-headers {
                background-color: #f9f9f9;
            }
            .x-pivotgrid .x-grid3-row-headers table td {
                background: #eee /*savepage-url=../images/default/grid/grid3-rowheader.gif*/ url() repeat-x left top;
                border-left: 1px solid;
                border-right: 1px solid;
                border-left-color: #eee;
                border-right-color: #d0d0d0;
                border-bottom: 1px solid;
                border-bottom-color: #d0d0d0;
                height: 18px;
            }
            .x-dd-drag-ghost {
                color: #000;
                font:
                    normal 11px arial,
                    helvetica,
                    sans-serif;
                border-color: #ddd #bbb #bbb #ddd;
                background-color: #fff;
            }
            .x-dd-drop-nodrop .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/dd/drop-no.gif*/ url();
            }
            .x-dd-drop-ok .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/dd/drop-yes.gif*/ url();
            }
            .x-dd-drop-ok-add .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/dd/drop-add.gif*/ url();
            }
            .x-view-selector {
                background-color: #c3daf9;
                border-color: #39b;
            }
            .x-tree-node-expanded .x-tree-node-icon {
                background-image:/*savepage-url=../images/default/tree/folder-open.gif*/ url();
            }
            .x-tree-node-leaf .x-tree-node-icon {
                background-image:/*savepage-url=../images/default/tree/leaf.gif*/ url();
            }
            .x-tree-node-collapsed .x-tree-node-icon {
                background-image:/*savepage-url=../images/default/tree/folder.gif*/ url();
            }
            .x-tree-node-loading .x-tree-node-icon {
                background-image:/*savepage-url=../images/default/tree/loading.gif*/ url() !important;
            }
            .x-tree-node .x-tree-node-inline-icon {
                background-image: none;
            }
            .x-tree-node-loading a span {
                font-style: italic;
                color: #444;
            }
            .x-tree-lines .x-tree-elbow {
                background-image:/*savepage-url=../images/default/tree/elbow.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-plus {
                background-image:/*savepage-url=../images/default/tree/elbow-plus.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-minus {
                background-image:/*savepage-url=../images/default/tree/elbow-minus.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-end {
                background-image:/*savepage-url=../images/default/tree/elbow-end.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-end-plus {
                background-image:/*savepage-url=../images/default/tree/elbow-end-plus.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-end-minus {
                background-image:/*savepage-url=../images/default/tree/elbow-end-minus.gif*/ url();
            }
            .x-tree-lines .x-tree-elbow-line {
                background-image:/*savepage-url=../images/default/tree/elbow-line.gif*/ url();
            }
            .x-tree-no-lines .x-tree-elbow-plus {
                background-image:/*savepage-url=../images/default/tree/elbow-plus-nl.gif*/ url();
            }
            .x-tree-no-lines .x-tree-elbow-minus {
                background-image:/*savepage-url=../images/default/tree/elbow-minus-nl.gif*/ url();
            }
            .x-tree-no-lines .x-tree-elbow-end-plus {
                background-image:/*savepage-url=../images/default/tree/elbow-end-plus-nl.gif*/ url();
            }
            .x-tree-no-lines .x-tree-elbow-end-minus {
                background-image:/*savepage-url=../images/default/tree/elbow-end-minus-nl.gif*/ url();
            }
            .x-tree-arrows .x-tree-elbow-plus {
                background-image:/*savepage-url=../images/default/tree/arrows.gif*/ url();
            }
            .x-tree-arrows .x-tree-elbow-minus {
                background-image:/*savepage-url=../images/default/tree/arrows.gif*/ url();
            }
            .x-tree-arrows .x-tree-elbow-end-plus {
                background-image:/*savepage-url=../images/default/tree/arrows.gif*/ url();
            }
            .x-tree-arrows .x-tree-elbow-end-minus {
                background-image:/*savepage-url=../images/default/tree/arrows.gif*/ url();
            }
            .x-tree-node {
                color: #000;
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-tree-node a,
            .x-dd-drag-ghost a {
                color: #000;
            }
            .x-tree-node a span,
            .x-dd-drag-ghost a span {
                color: #000;
            }
            .x-tree-node .x-tree-node-disabled a span {
                color: gray !important;
            }
            .x-tree-node div.x-tree-drag-insert-below {
                border-bottom-color: #36c;
            }
            .x-tree-node div.x-tree-drag-insert-above {
                border-top-color: #36c;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-below a {
                border-bottom-color: #36c;
            }
            .x-tree-dd-underline .x-tree-node div.x-tree-drag-insert-above a {
                border-top-color: #36c;
            }
            .x-tree-node .x-tree-drag-append a span {
                background-color: #ddd;
                border-color: gray;
            }
            .x-tree-node .x-tree-node-over {
                background-color: #eee;
            }
            .x-tree-node .x-tree-selected {
                background-color: #d9e8fb;
            }
            .x-tree-drop-ok-append .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/tree/drop-add.gif*/ url();
            }
            .x-tree-drop-ok-above .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/tree/drop-over.gif*/ url();
            }
            .x-tree-drop-ok-below .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/tree/drop-under.gif*/ url();
            }
            .x-tree-drop-ok-between .x-dd-drop-icon {
                background-image:/*savepage-url=../images/default/tree/drop-between.gif*/ url();
            }
            .x-date-picker {
                border-color: #1b376c;
                background-color: #fff;
            }
            .x-date-middle,
            .x-date-left,
            .x-date-right {
                background-image:/*savepage-url=../images/default/shared/hd-sprite.gif*/ url();
                color: #fff;
                font:
                    bold 11px "sans serif",
                    tahoma,
                    verdana,
                    helvetica;
            }
            .x-date-middle .x-btn .x-btn-text {
                color: #fff;
            }
            .x-date-middle .x-btn-mc em.x-btn-arrow {
                background-image:/*savepage-url=../images/default/toolbar/btn-arrow-light.gif*/ url();
            }
            .x-date-right a {
                background-image:/*savepage-url=../images/default/shared/right-btn.gif*/ url();
            }
            .x-date-left a {
                background-image:/*savepage-url=../images/default/shared/left-btn.gif*/ url();
            }
            .x-date-inner th {
                background-color: #dfecfb;
                background-image:/*savepage-url=../images/default/shared/glass-bg.gif*/ url();
                border-bottom-color: #a3bad9;
                font:
                    normal 10px arial,
                    helvetica,
                    tahoma,
                    sans-serif;
                color: #233d6d;
            }
            .x-date-inner td {
                border-color: #fff;
            }
            .x-date-inner a {
                font:
                    normal 11px arial,
                    helvetica,
                    tahoma,
                    sans-serif;
                color: #000;
            }
            .x-date-inner .x-date-active {
                color: #000;
            }
            .x-date-inner .x-date-selected a {
                background-color: #dfecfb;
                background-image:/*savepage-url=../images/default/shared/glass-bg.gif*/ url();
                border-color: #8db2e3;
            }
            .x-date-inner .x-date-today a {
                border-color: darkred;
            }
            .x-date-inner .x-date-selected span {
                font-weight: bold;
            }
            .x-date-inner .x-date-prevday a,
            .x-date-inner .x-date-nextday a {
                color: #aaa;
            }
            .x-date-bottom {
                border-top-color: #a3bad9;
                background-color: #dfecfb;
                background-image:/*savepage-url=../images/default/shared/glass-bg.gif*/ url();
            }
            .x-date-inner a:hover,
            .x-date-inner .x-date-disabled a:hover {
                color: #000;
                background-color: #ddecfe;
            }
            .x-date-inner .x-date-disabled a {
                background-color: #eee;
                color: #bbb;
            }
            .x-date-mmenu {
                background-color: #eee !important;
            }
            .x-date-mmenu .x-menu-item {
                font-size: 10px;
                color: #000;
            }
            .x-date-mp {
                background-color: #fff;
            }
            .x-date-mp td {
                font:
                    normal 11px arial,
                    helvetica,
                    tahoma,
                    sans-serif;
            }
            .x-date-mp-btns button {
                background-color: #083772;
                color: #fff;
                border-color: #36c #005 #005 #36c;
                font:
                    normal 11px arial,
                    helvetica,
                    tahoma,
                    sans-serif;
            }
            .x-date-mp-btns {
                background-color: #dfecfb;
                background-image:/*savepage-url=../images/default/shared/glass-bg.gif*/ url();
            }
            .x-date-mp-btns td {
                border-top-color: #c5d2df;
            }
            td.x-date-mp-month a,
            td.x-date-mp-year a {
                color: #15428b;
            }
            td.x-date-mp-month a:hover,
            td.x-date-mp-year a:hover {
                color: #15428b;
                background-color: #ddecfe;
            }
            td.x-date-mp-sel a {
                background-color: #dfecfb;
                background-image:/*savepage-url=../images/default/shared/glass-bg.gif*/ url();
                border-color: #8db2e3;
            }
            .x-date-mp-ybtn a {
                background-image:/*savepage-url=../images/default/panel/tool-sprites.gif*/ url();
            }
            td.x-date-mp-sep {
                border-right-color: #c5d2df;
            }
            .x-tip .x-tip-close {
                background-image:/*savepage-url=../images/default/qtip/close.gif*/ url();
            }
            .x-tip .x-tip-tc,
            .x-tip .x-tip-tl,
            .x-tip .x-tip-tr,
            .x-tip .x-tip-bc,
            .x-tip .x-tip-bl,
            .x-tip .x-tip-br,
            .x-tip .x-tip-ml,
            .x-tip .x-tip-mr {
                background-image:/*savepage-url=../images/default/qtip/tip-sprite.gif*/ var(--savepage-url-10);
            }
            .x-tip .x-tip-mc {
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-tip .x-tip-ml {
                background-color: #fff;
            }
            .x-tip .x-tip-header-text {
                font:
                    bold 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                color: #444;
            }
            .x-tip .x-tip-body {
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                color: #444;
            }
            .x-form-invalid-tip .x-tip-tc,
            .x-form-invalid-tip .x-tip-tl,
            .x-form-invalid-tip .x-tip-tr,
            .x-form-invalid-tip .x-tip-bc,
            .x-form-invalid-tip .x-tip-bl,
            .x-form-invalid-tip .x-tip-br,
            .x-form-invalid-tip .x-tip-ml,
            .x-form-invalid-tip .x-tip-mr {
                background-image:/*savepage-url=../images/default/form/error-tip-corners.gif*/ url();
            }
            .x-form-invalid-tip .x-tip-body {
                background-image:/*savepage-url=../images/default/form/exclamation.gif*/ url();
            }
            .x-tip-anchor {
                background-image:/*savepage-url=../images/default/qtip/tip-anchor-sprite.gif*/ var(--savepage-url-11);
            }
            .x-menu {
                background-color: #f0f0f0;
                background-image:/*savepage-url=../images/default/menu/menu.gif*/ url();
            }
            .x-menu-floating {
                border-color: #718bb7;
            }
            .x-menu-nosep {
                background-image: none;
            }
            .x-menu-list-item {
                font:
                    normal 11px arial,
                    tahoma,
                    sans-serif;
            }
            .x-menu-item-arrow {
                background-image:/*savepage-url=../images/default/menu/menu-parent.gif*/ url();
            }
            .x-menu-sep {
                background-color: #e0e0e0;
                border-bottom-color: #fff;
            }
            a.x-menu-item {
                color: #222;
            }
            .x-menu-item-active {
                background-image:/*savepage-url=../images/default/menu/item-over.gif*/ url();
                background-color: #dbecf4;
                border-color: #aaccf6;
            }
            .x-menu-item-active a.x-menu-item {
                border-color: #aaccf6;
            }
            .x-menu-check-item .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/menu/unchecked.gif*/ url();
            }
            .x-menu-item-checked .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/menu/checked.gif*/ url();
            }
            .x-menu-item-checked .x-menu-group-item .x-menu-item-icon {
                background-image:/*savepage-url=../images/default/menu/group-checked.gif*/ url();
            }
            .x-menu-group-item .x-menu-item-icon {
                background-image: none;
            }
            .x-menu-plain {
                background-color: #f0f0f0 !important;
                background-image: none;
            }
            .x-date-menu,
            .x-color-menu {
                background-color: #fff !important;
            }
            .x-menu .x-date-picker {
                border-color: #a3bad9;
            }
            .x-cycle-menu .x-menu-item-checked {
                border-color: #a3bae9 !important;
                background-color: #def8f6;
            }
            .x-menu-scroller-top {
                background-image:/*savepage-url=../images/default/layout/mini-top.gif*/ url();
            }
            .x-menu-scroller-bottom {
                background-image:/*savepage-url=../images/default/layout/mini-bottom.gif*/ url();
            }
            .x-box-tl {
                background-image:/*savepage-url=../images/default/box/corners.gif*/ url();
            }
            .x-box-tc {
                background-image:/*savepage-url=../images/default/box/tb.gif*/ url();
            }
            .x-box-tr {
                background-image:/*savepage-url=../images/default/box/corners.gif*/ url();
            }
            .x-box-ml {
                background-image:/*savepage-url=../images/default/box/l.gif*/ url();
            }
            .x-box-mc {
                background-color: #eee;
                background-image:/*savepage-url=../images/default/box/tb.gif*/ url();
                font-family: "Myriad Pro", "Myriad Web", "Tahoma", "Helvetica", "Arial", sans-serif;
                color: #393939;
                font-size: 12px;
            }
            .x-box-mc h3 {
                font-size: 14px;
                font-weight: bold;
            }
            .x-box-mr {
                background-image:/*savepage-url=../images/default/box/r.gif*/ url();
            }
            .x-box-bl {
                background-image:/*savepage-url=../images/default/box/corners.gif*/ url();
            }
            .x-box-bc {
                background-image:/*savepage-url=../images/default/box/tb.gif*/ url();
            }
            .x-box-br {
                background-image:/*savepage-url=../images/default/box/corners.gif*/ url();
            }
            .x-box-blue .x-box-bl,
            .x-box-blue .x-box-br,
            .x-box-blue .x-box-tl,
            .x-box-blue .x-box-tr {
                background-image:/*savepage-url=../images/default/box/corners-blue.gif*/ url();
            }
            .x-box-blue .x-box-bc,
            .x-box-blue .x-box-mc,
            .x-box-blue .x-box-tc {
                background-image:/*savepage-url=../images/default/box/tb-blue.gif*/ url();
            }
            .x-box-blue .x-box-mc {
                background-color: #c3daf9;
            }
            .x-box-blue .x-box-mc h3 {
                color: #17385b;
            }
            .x-box-blue .x-box-ml {
                background-image:/*savepage-url=../images/default/box/l-blue.gif*/ url();
            }
            .x-box-blue .x-box-mr {
                background-image:/*savepage-url=../images/default/box/r-blue.gif*/ url();
            }
            .x-combo-list {
                border-color: #98c0f4;
                background-color: #ddecfe;
                font:
                    normal 12px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-combo-list-inner {
                background-color: #fff;
            }
            .x-combo-list-hd {
                font:
                    bold 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                color: #15428b;
                background-image:/*savepage-url=../images/default/layout/panel-title-light-bg.gif*/ url();
                border-bottom-color: #98c0f4;
            }
            .x-resizable-pinned .x-combo-list-inner {
                border-bottom-color: #98c0f4;
            }
            .x-combo-list-item {
                border-color: #fff;
            }
            .x-combo-list .x-combo-selected {
                border-color: #a3bae9 !important;
                background-color: #dfe8f6;
            }
            .x-combo-list .x-toolbar {
                border-top-color: #98c0f4;
            }
            .x-combo-list-small {
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-panel {
                border-color: #99bbe8;
            }
            .x-panel-header {
                color: #15428b;
                font-weight: bold;
                font-size: 11px;
                font-family: tahoma, arial, verdana, sans-serif;
                border-color: #99bbe8;
                background-image:/*savepage-url=../images/default/panel/white-top-bottom.gif*/ url();
            }
            .x-panel-body {
                border-color: #99bbe8;
                background-color: #fff;
            }
            .x-panel-bbar .x-toolbar,
            .x-panel-tbar .x-toolbar {
                border-color: #99bbe8;
            }
            .x-panel-tbar-noheader .x-toolbar,
            .x-panel-mc .x-panel-tbar .x-toolbar {
                border-top-color: #99bbe8;
            }
            .x-panel-body-noheader,
            .x-panel-mc .x-panel-body {
                border-top-color: #99bbe8;
            }
            .x-panel-tl .x-panel-header {
                color: #15428b;
                font:
                    bold 11px tahoma,
                    arial,
                    verdana,
                    sans-serif;
            }
            .x-panel-tc {
                background-image:/*savepage-url=../images/default/panel/top-bottom.gif*/ url();
            }
            .x-panel-tl,
            .x-panel-tr,
            .x-panel-bl,
            .x-panel-br {
                background-image:/*savepage-url=../images/default/panel/corners-sprite.gif*/ url();
                border-bottom-color: #99bbe8;
            }
            .x-panel-bc {
                background-image:/*savepage-url=../images/default/panel/top-bottom.gif*/ url();
            }
            .x-panel-mc {
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                background-color: #dfe8f6;
            }
            .x-panel-ml {
                background-color: #fff;
                background-image:/*savepage-url=../images/default/panel/left-right.gif*/ url();
            }
            .x-panel-mr {
                background-image:/*savepage-url=../images/default/panel/left-right.gif*/ url();
            }
            .x-tool {
                background-image:/*savepage-url=../images/default/panel/tool-sprites.gif*/ url();
            }
            .x-panel-ghost {
                background-color: #cbddf3;
            }
            .x-panel-ghost ul {
                border-color: #99bbe8;
            }
            .x-panel-dd-spacer {
                border-color: #99bbe8;
            }
            .x-panel-fbar td,
            .x-panel-fbar span,
            .x-panel-fbar input,
            .x-panel-fbar div,
            .x-panel-fbar select,
            .x-panel-fbar label {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-window-proxy {
                background-color: #c7dffc;
                border-color: #99bbe8;
            }
            .x-window-tl .x-window-header {
                color: #15428b;
                font:
                    bold 11px tahoma,
                    arial,
                    verdana,
                    sans-serif;
            }
            .x-window-tc {
                background-image:/*savepage-url=../images/default/window/top-bottom.png*/ url();
            }
            .x-window-tl {
                background-image:/*savepage-url=../images/default/window/left-corners.png*/ url();
            }
            .x-window-tr {
                background-image:/*savepage-url=../images/default/window/right-corners.png*/ url();
            }
            .x-window-bc {
                background-image:/*savepage-url=../images/default/window/top-bottom.png*/ url();
            }
            .x-window-bl {
                background-image:/*savepage-url=../images/default/window/left-corners.png*/ url();
            }
            .x-window-br {
                background-image:/*savepage-url=../images/default/window/right-corners.png*/ url();
            }
            .x-window-mc {
                border-color: #99bbe8;
                font:
                    normal 11px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
                background-color: #dfe8f6;
            }
            .x-window-ml {
                background-image:/*savepage-url=../images/default/window/left-right.png*/ url();
            }
            .x-window-mr {
                background-image:/*savepage-url=../images/default/window/left-right.png*/ url();
            }
            .x-window-maximized .x-window-tc {
                background-color: #fff;
            }
            .x-window-bbar .x-toolbar {
                border-top-color: #99bbe8;
            }
            .x-panel-ghost .x-window-tl {
                border-bottom-color: #99bbe8;
            }
            .x-panel-collapsed .x-window-tl {
                border-bottom-color: #84a0c4;
            }
            .x-dlg-mask {
                background-color: #ccc;
            }
            .x-window-plain .x-window-mc {
                background-color: #ccd9e8;
                border-color: #a3bae9 #dfe8f6 #dfe8f6 #a3bae9;
            }
            .x-window-plain .x-window-body {
                border-color: #dfe8f6 #a3bae9 #a3bae9 #dfe8f6;
            }
            body.x-body-masked .x-window-plain .x-window-mc {
                background-color: #ccd9e8;
            }
            .x-html-editor-wrap {
                border-color: #a9bfd3;
                background-color: #fff;
            }
            .x-html-editor-tb .x-btn-text {
                background-image:/*savepage-url=../images/default/editor/tb-sprite.gif*/ url();
            }
            .x-panel-noborder .x-panel-header-noborder {
                border-bottom-color: #99bbe8;
            }
            .x-panel-noborder .x-panel-tbar-noborder .x-toolbar {
                border-bottom-color: #99bbe8;
            }
            .x-panel-noborder .x-panel-bbar-noborder .x-toolbar {
                border-top-color: #99bbe8;
            }
            .x-tab-panel-bbar-noborder .x-toolbar {
                border-top-color: #99bbe8;
            }
            .x-tab-panel-tbar-noborder .x-toolbar {
                border-bottom-color: #99bbe8;
            }
            .x-border-layout-ct {
                background-color: #dfe8f6;
            }
            .x-accordion-hd {
                color: #222;
                font-weight: normal;
                background-image:/*savepage-url=../images/default/panel/light-hd.gif*/ url();
            }
            .x-layout-collapsed {
                background-color: #d2e0f2;
                border-color: #98c0f4;
            }
            .x-layout-collapsed-over {
                background-color: #d9e8fb;
            }
            .x-layout-split-west .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-left.gif*/ url();
            }
            .x-layout-split-east .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-right.gif*/ url();
            }
            .x-layout-split-north .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-top.gif*/ url();
            }
            .x-layout-split-south .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-bottom.gif*/ url();
            }
            .x-layout-cmini-west .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-right.gif*/ url();
            }
            .x-layout-cmini-east .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-left.gif*/ url();
            }
            .x-layout-cmini-north .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-bottom.gif*/ url();
            }
            .x-layout-cmini-south .x-layout-mini {
                background-image:/*savepage-url=../images/default/layout/mini-top.gif*/ url();
            }
            .x-progress-wrap {
                border-color: #6593cf;
            }
            .x-progress-inner {
                background-color: #e0e8f3;
                background-image:/*savepage-url=../images/default/qtip/bg.gif*/ url();
            }
            .x-progress-bar {
                background-color: #9cbfee;
                background-image:/*savepage-url=../images/default/progress/progress-bg.gif*/ url();
                border-top-color: #d1e4fd;
                border-bottom-color: #7fa9e4;
                border-right-color: #7fa9e4;
            }
            .x-progress-text {
                font-size: 11px;
                font-weight: bold;
                color: #fff;
            }
            .x-progress-text-back {
                color: #396095;
            }
            .x-list-header {
                background-color: #f9f9f9;
                background-image:/*savepage-url=../images/default/grid/grid3-hrow.gif*/ url();
            }
            .x-list-header-inner div em {
                border-left-color: #ddd;
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-list-body dt em {
                font:
                    normal 11px arial,
                    tahoma,
                    helvetica,
                    sans-serif;
            }
            .x-list-over {
                background-color: #eee;
            }
            .x-list-selected {
                background-color: #dfe8f6;
            }
            .x-list-resizer {
                border-left-color: #555;
                border-right-color: #555;
            }
            .x-list-header-inner em.sort-asc,
            .x-list-header-inner em.sort-desc {
                background-image:/*savepage-url=../images/default/grid/sort-hd.gif*/ url();
                border-color: #99bbe8;
            }
            .x-slider-horz,
            .x-slider-horz .x-slider-end,
            .x-slider-horz .x-slider-inner {
                background-image:/*savepage-url=../images/default/slider/slider-bg.png*/ url();
            }
            .x-slider-horz .x-slider-thumb {
                background-image:/*savepage-url=../images/default/slider/slider-thumb.png*/ url();
            }
            .x-slider-vert,
            .x-slider-vert .x-slider-end,
            .x-slider-vert .x-slider-inner {
                background-image:/*savepage-url=../images/default/slider/slider-v-bg.png*/ url();
            }
            .x-slider-vert .x-slider-thumb {
                background-image:/*savepage-url=../images/default/slider/slider-v-thumb.png*/ url();
            }
            .x-window-dlg .ext-mb-text,
            .x-window-dlg .x-window-header-text {
                font-size: 12px;
            }
            .x-window-dlg .ext-mb-textarea {
                font:
                    normal 12px tahoma,
                    arial,
                    helvetica,
                    sans-serif;
            }
            .x-window-dlg .x-msg-box-wait {
                background-image:/*savepage-url=../images/default/grid/loading.gif*/ url();
            }
            .x-window-dlg .ext-mb-info {
                background-image:/*savepage-url=../images/default/window/icon-info.gif*/ url();
            }
            .x-window-dlg .ext-mb-warning {
                background-image:/*savepage-url=../images/default/window/icon-warning.gif*/ url();
            }
            .x-window-dlg .ext-mb-question {
                background-image:/*savepage-url=../images/default/window/icon-question.gif*/ url();
            }
            .x-window-dlg .ext-mb-error {
                background-image:/*savepage-url=../images/default/window/icon-error.gif*/ url();
            }
        </style>
        <style
            data-savepage-href="resources/css/pegasus-web-skin.css?build=05bce331010b38dcd80432018244dfe18f68e164"
            type="text/css"
        >
            .x-checkbox,.x-radio{height:13px;width:13px;margin-top:2px;}
            .x-checkbox{background:/*savepage-url=../images/default/form/unchecked.gif*/url() no-repeat 0 0;}
            a.x-checkbox{text-decoration:none;color:inherit;}
            .x-checkbox-defaultGrayed{background:/*savepage-url=../images/default/form/grayed.gif*/url() no-repeat 0 0;}
            .x-checkbox-defaultChecked{background:/*savepage-url=../images/default/form/checked.gif*/url() no-repeat 0 0;}
            .x-checkbox-defaultUnchecked{background:/*savepage-url=../images/default/form/unchecked.gif*/url() no-repeat 0 0;}
            .checkboxbutton-btn-nobg .x-btn-tl,.checkboxbutton-btn-nobg .x-btn-tr,.checkboxbutton-btn-nobg .x-btn-tc,.checkboxbutton-btn-nobg .x-btn-ml,.checkboxbutton-btn-nobg .x-btn-mr,.checkboxbutton-btn-nobg .x-btn-mc,.checkboxbutton-btn-nobg .x-btn-bl,.checkboxbutton-btn-nobg .x-btn-br,.checkboxbutton-btn-nobg .x-btn-bc{background-image:none;}
            .ib-btn-primary .x-btn-tl i,.ib-btn-primary .x-btn-tr i,.ib-btn-primary .x-btn-ml i,.ib-btn-primary .x-btn-mr i,.ib-btn-primary .x-btn-bl i,.ib-btn-primary .x-btn-br i,.ib-btn-secondary .x-btn-tl i,.ib-btn-secondary .x-btn-tr i,.ib-btn-secondary .x-btn-ml i,.ib-btn-secondary .x-btn-mr i,.ib-btn-secondary .x-btn-bl i,.ib-btn-secondary .x-btn-br i{width:10px;}
            .ib-btn-secondary .x-btn-tl{background-position:0 0;width:10px;height:3px;}
            .ib-btn-secondary .x-btn-tr{background-position:-10px 0;width:10px;height:3px;}
            .ib-btn-secondary .x-btn-tc{background-position:0 -6px;height:3px;}
            .ib-btn-secondary .x-btn-ml{background-position:0 -24px;width:10px;}
            .ib-btn-secondary .x-btn-mr{background-position:-10px -24px;width:10px;}
            .ib-btn-secondary .x-btn-mc{background-position:0 -74px;}
            .ib-btn-secondary .x-btn-bl{background-position:0 -3px;width:10px;height:3px;}
            .ib-btn-secondary .x-btn-br{background-position:-10px -3px;width:10px;height:3px;}
            .ib-btn-secondary .x-btn-bc{background-position:0 -9px;height:3px;}
            .ib-btn-secondary .x-btn-tl,.ib-btn-secondary .x-btn-tr,.ib-btn-secondary .x-btn-tc,.ib-btn-secondary .x-btn-ml,.ib-btn-secondary .x-btn-mr,.ib-btn-secondary .x-btn-mc,.ib-btn-secondary .x-btn-bl,.ib-btn-secondary .x-btn-br,.ib-btn-secondary .x-btn-bc{background-image:/*savepage-url=../images/default/button/btn_ib_secondary.gif*/url();}
            .ib-btn-secondary button.x-btn-text{color:#FFF;font-weight:bold;padding-left:10px;padding-right:10px;}
            .ib-btn-secondary .x-btn-small .x-btn-text{height:24px;}
            .ib-btn-primary .x-btn-tl{background-position:0 0;width:10px;height:3px;}
            .ib-btn-primary .x-btn-tr{background-position:-10px 0;width:10px;height:3px;}
            .ib-btn-primary .x-btn-tc{background-position:0 -6px;height:3px;}
            .ib-btn-primary .x-btn-ml{background-position:0 -24px;width:10px;}
            .ib-btn-primary .x-btn-mr{background-position:-10px -24px;width:10px;}
            .ib-btn-primary .x-btn-mc{background-position:0 -74px;}
            .ib-btn-primary .x-btn-bl{background-position:0 -3px;width:10px;height:3px;}
            .ib-btn-primary .x-btn-br{background-position:-10px -3px;width:10px;height:3px;}
            .ib-btn-primary .x-btn-bc{background-position:0 -9px;height:3px;}
            .ib-btn-primary .x-btn-tl,.ib-btn-primary .x-btn-tr,.ib-btn-primary .x-btn-tc,.ib-btn-primary .x-btn-ml,.ib-btn-primary .x-btn-mr,.ib-btn-primary .x-btn-mc,.ib-btn-primary .x-btn-bl,.ib-btn-primary .x-btn-br,.ib-btn-primary .x-btn-bc{background-image:/*savepage-url=../images/default/button/btn_ib_primary.gif*/url();}
            .ib-btn-primary button.x-btn-text{color:#FFF;font-weight:bold;padding-left:10px;padding-right:10px;}
            .ib-btn-primary .x-btn-small .x-btn-text{height:24px;}
            .ib-btn-over .x-btn-tl,.x-toolbar .ib-btn-over .x-btn-tl{background-position:-20px 0;}
            .ib-btn-over .x-btn-tr,.x-toolbar .ib-btn-over .x-btn-tr{background-position:-30px 0;}
            .ib-btn-over .x-btn-tc,.x-toolbar .ib-btn-over .x-btn-tc{background-position:0 -12px;}
            .ib-btn-over .x-btn-ml,.x-toolbar .ib-btn-over .x-btn-ml{background-position:-20px -24px;}
            .ib-btn-over .x-btn-mr,.x-toolbar .ib-btn-over .x-btn-mr{background-position:-30px -24px;}
            .ib-btn-over .x-btn-mc,.x-toolbar .ib-btn-over .x-btn-mc{background-position:0 -124px;}
            .ib-btn-over .x-btn-bl,.x-toolbar .ib-btn-over .x-btn-bl{background-position:-20px -3px;}
            .ib-btn-over .x-btn-br,.x-toolbar .ib-btn-over .x-btn-br{background-position:-30px -3px;}
            .ib-btn-over .x-btn-bc,.x-toolbar .ib-btn-over .x-btn-bc{background-position:0 -15px;}
            .ib-link-arrow{background:/*savepage-url=../images/default/button/icon_link_16x16.png*/url() no-repeat!important;}
            .ib-link-arrow-back{background:/*savepage-url=../images/default/button/icon_link_back_16x16.png*/url() no-repeat!important;}
            .ib-link .x-btn-tl,.ib-link .x-btn-tr,.ib-link .x-btn-tc,.ib-link .x-btn-ml,.ib-link .x-btn-mr,.ib-link .x-btn-mc,.ib-link .x-btn-bl,.ib-link .x-btn-br,.ib-link .x-btn-bc{background-image:none;}
            a.ib-link{font-size:12px;margin:2px 5px!important;}
            .ib-link,.ib-link button{color:#00AEEF;cursor:pointer;}
            .ib-link:hover,.ib-link:hover em{text-decoration:underline;color:#44C4F3;}
            .ib-link-wrap .x-btn-text{white-space:normal;text-align:left;}
            .ib-link-wrap:hover .ib-link:hover{white-space:normal;text-align:left;text-decoration:none;font-weight:bold;}
            .modal-window-header{height:35px;background:transparent;border:0;padding:0 10px;line-height:35px;color:#363636;font-size:18px;}
            .modal-window-header .x-tool{margin-top:10px;}
            .modal-window-body{background:transparent;padding:10px;padding-bottom:0;margin:auto;font-size:12px;}
            .modal-window-bbar .x-toolbar{background:transparent;border-width:1px 0 0 0;}
            .modal-window .x-window-mc{border:0 solid;border-color:#DFE8F6 #A3BAE9 #A3BAE9 #DFE8F6;}
            .modal-window{background-color:#E9EDE8;background-position:left top;background-repeat:repeat-x;background-image:/*savepage-url=../images/default/modalwindow-top-bottom-cube.png*/url();}
            .modal-window .x-window-tr,.modal-window .x-window-tc,.modal-window .x-window-tl,.modal-window .x-window-mr,.modal-window .x-window-ml,.modal-window .x-window-mc,.modal-window .x-window-br,.modal-window .x-window-bc,.modal-window .x-window-bl{background:transparent;}
            .x-vr-tab-panel{font:11px tahoma,arial,helvetica,sans-serif;}
            .x-vr-tab-panel-header{float:left;}
            .x-vr-tab-panel-bwrap{border:1px solid #D8DFD7;float:right;padding:8px;background:#fff;}
            .x-vr-tab-panel ul.x-tab-strip li{float:left;width:100%;white-space:nowrap;margin-left:0;heigth:50px!important;}
            .x-vr-tab-panel .x-tab-strip-text{height:40px!important;}
            .x-vr-tab-panel .x-tab-strip span.x-tab-strip-text,.x-vr-tab-panel .x-tab-strip-active .x-tab-right span.x-tab-strip-text{padding:5px 0;}
            .x-vr-tab-panel ul.x-tab-strip{border:0;}
            .x-vr-tab-panel .x-tab-strip-top .x-tab-strip-active .x-tab-right{margin-bottom:0;}
            .x-vr-tab-panel .x-tab-strip-top .x-tab-right,.x-vr-tab-panel .x-tab-strip-top .x-tab-left,.x-vr-tab-panel .x-tab-strip-top .x-tab-strip-inner{background-image:/*savepage-url=../images/default/vrTabPanel-lefttabs-sprite.gif*/url();}
            .ib-btn-lefttab .x-btn-tr,.ib-btn-lefttab .x-btn-tr i,.ib-btn-lefttab .x-btn-br,.ib-btn-lefttab .x-btn-br i,.ib-btn-lefttab .x-btn-mr,.ib-btn-lefttab .x-btn-mr i{width:0;}
            .ib-btn-lefttab .x-btn-text{white-space:normal;}
            .basicFolderItem-tabTitle{color:black;}
            .basicFolderItem-summary{color:green;font-size:larger;}
            .basicFolderItem-headerName{font-size:24px;color:'#15428B';}
            .checkboxbutton-icon-check{background-image:/*savepage-url=../images/default/form/unchecked.gif*/url()!important;}
            .x-btn-pressed .checkboxbutton-icon-check{background-image:/*savepage-url=../images/default/form/checked.gif*/url()!important;}
            .checkboxbutton-icon-radio{background-image:/*savepage-url=../images/default/form/radio-off.gif*/url()!important;}
            .x-btn-pressed .checkboxbutton-icon-radio{background-image:/*savepage-url=../images/default/form/radio-on.gif*/url()!important;}
            .checkboxbutton-btn-nobg .x-btn-tl,.checkboxbutton-btn-nobg .x-btn-tr,.checkboxbutton-btn-nobg .x-btn-tc,.checkboxbutton-btn-nobg .x-btn-ml,.checkboxbutton-btn-nobg .x-btn-mr,.checkboxbutton-btn-nobg .x-btn-mc,.checkboxbutton-btn-nobg .x-btn-bl,.checkboxbutton-btn-nobg .x-btn-br,.checkboxbutton-btn-nobg .x-btn-bc{background-image:none;}
            .pegasus-table{width:auto!important;}
            .pegasus-table .x-grid3-row-over{background:none transparent;border:none;padding:0;margin:0;}
            .pegasus-table .x-grid3-row-over.x-grid3-row-alt{background:none;border:none;padding:0;margin:0;background-color:#f4f6f3;}
            .pegasus-table .x-grid3-row{border:none;height:20;}
            .pegasus-table .x-grid3-row-selected{background-color:#B3BCB1!important;}
            .pegasus-table .x-panel-tbar{border-bottom:1px solid #09294B;background-color:#57758C;}
            .pegasus-table .x-grid3-header{border:0;background-image:/*savepage-url=../images/default/form/table/table-big-header-bg.png*/url();}
            .pegasus-table .x-grid3-hd-inner{color:#E3E8EC;font-weight:bold;}
            .pegasus-table .x-grid3-body .x-grid3-td-checker{background:transparent;}
            .pegasus-table td.x-grid3-cell{vertical-align:middle;border:0;height:20px;line-height:20px;}
            .pegasus-table .sort-desc .x-grid3-sort-icon{background-image:/*savepage-url=../images/default/form/table/sort_desc.gif*/url();}
            .pegasus-table .sort-asc .x-grid3-sort-icon{background-image:/*savepage-url=../images/default/form/table/sort_asc.gif*/url();}
            .pegasus-table .x-tab-panel-bbar .x-toolbar{border:0;background-color:#E9EFF2;margin:5px;color:#363636;}
            .pegasus-table .x-toolbar .x-btn-tl{background-position:0 0;}
            .pegasus-table .x-toolbar .x-btn-tr{background-position:-3px 0;}
            .pegasus-table .x-toolbar .x-btn-tc{background-position:0 -6px;}
            .pegasus-table .x-toolbar .x-btn-ml{background-position:-0px -24px;}
            .pegasus-table .x-toolbar .x-btn-mr{background-position:-3px -24px;}
            .pegasus-table .x-toolbar .x-btn-mc{background-position:0 -1096px;}
            .pegasus-table .x-toolbar .x-btn-bl{background-position:-0px -3px;}
            .pegasus-table .x-toolbar .x-btn-br{background-position:-3px -3px;}
            .pegasus-table .x-toolbar .x-btn-bc{background-position:0 -15px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-tl{background-position:-6px 0;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-tr{background-position:-9px 0;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-tc{background-position:0 -9px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-ml{background-position:-6px -24px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-mr{background-position:-9px -24px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-mc{background-position:0 -2168px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-bl{background-position:-6px -3px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-br{background-position:-9px -3px;}
            .pegasus-table .x-toolbar .x-btn-over .x-btn-bc{background-position:0 -18px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-tl,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-tl,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-tl{background-position:-12px 0;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-tr,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-tr,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-tr{background-position:-15px 0;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-tc,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-tc,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-tc{background-position:0 -12px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-ml,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-ml,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-ml{background-position:-12px -24px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-mr,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-mr,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-mr{background-position:-15px -24px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-mc,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-mc,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-mc{background-position:0 -3240px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-bl,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-bl,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-bl{background-position:-12px -3px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-br,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-br,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-br{background-position:-15px -3px;}
            .pegasus-table .x-toolbar .x-btn-click .x-btn-bc,.pegasus-table .x-toolbar .x-btn-menu-active .x-btn-bc,.pegasus-table .x-toolbar .x-btn-pressed .x-btn-bc{background-position:0 -21px;}
            .pegasus-table td.x-grid3-hd-over,td.sort-desc,td.sort-asc,td.x-grid3-hd-menu-open{border-left-color:#aaccf6;border-right-color:#aaccf6;}
            .pegasus-table td.x-grid3-hd-over .x-grid3-hd-inner,td.sort-desc .x-grid3-hd-inner,td.sort-asc .x-grid3-hd-inner,td.x-grid3-hd-menu-open .x-grid3-hd-inner{background-color:transparent;background-image:none;}
            .pegasus-table .x-grid3-row-expander{background-image:/*savepage-url=../images/default/grid/row-expand-sprite.gif*/url();height:100%;background-position:4px 50%;}
            .pegasus-table .x-grid3-row-collapsed .x-grid3-row-expander{background-position:4px 50%;}
            .pegasus-table .x-grid3-row-expanded .x-grid3-row-expander{background-position:-21px 50%;}
            .pegasus-table .x-grid3-td-expander{background-color:transparent!important;background-image:none!important;}
            .pegasus-pagingtoolbar,.pegasus-pagingtoolbar .x-panel-bbar,.pegasus-pagingtoolbar .x-toolbar{background-color:#57758C!important;color:#fff;border-top:1px solid #043153!important;}
            .x-tbar-loading{background-image:/*savepage-url=../images/default/icon_toolbar_refresh.gif*/url()!important;}
            .x-tbar-page-last{background-image:/*savepage-url=../images/default/icon-pager-last.png*/url()!important;}
            .x-tbar-page-first{background-image:/*savepage-url=../images/default/icon-pager-first.png*/url()!important;}
            .x-tbar-page-next{background-image:/*savepage-url=../images/default/icon-pager-next.png*/url()!important;}
            .x-tbar-page-prev{background-image:/*savepage-url=../images/default/icon-pager-prev.png*/url()!important;}
            .x-toolbar .xtb-sep{background-image:none;}
            .x-item-disabled .x-tbar-page-prev,.x-item-disabled .x-tbar-page-next,.x-item-disabled .x-tbar-page-last,.x-item-disabled .x-tbar-page-first{background-image:none!important;}
            .pegasus-pagingtoolbar .x-btn-tl,.pegasus-pagingtoolbar .x-btn-tr,.pegasus-pagingtoolbar .x-btn-tc,.pegasus-pagingtoolbar .x-btn-ml,.pegasus-pagingtoolbar .x-btn-mr,.pegasus-pagingtoolbar .x-btn-mc,.pegasus-pagingtoolbar .x-btn-bl,.pegasus-pagingtoolbar .x-btn-br,.pegasus-pagingtoolbar .x-btn-bc{background-image:none;}
            .x-toolbar{border:0;background:none;}
            .x-grid3-row-alt{background-color:#f4f6f3;}
            .pegasus-pagingtoolbar.x-toolbar .xtb-text{font-size:12px;font-weight:bold;font:Arial;color:#fff;border:none;}
            .pegasus-pagingtoolbar.x-toolbar .x-btn-text{border:none;}
            .roworder-bottom{background-image:/*savepage-url=../images/default/icon-pager-bottom.png*/url()!important;}
            .roworder-top{background-image:/*savepage-url=../images/default/icon-pager-top.png*/url()!important;}
            .roworder-down{background-image:/*savepage-url=../images/default/icon-pager-down.png*/url()!important;}
            .roworder-up{background-image:/*savepage-url=../images/default/icon-pager-up.png*/url()!important;}
            .x-form-field-wrap .x-form-trigger.clearableInputField-form-clear-trigger{background-image:/*savepage-url=../images/default/form/clear-trigger.gif*/url();width:21px;height:21px!important;position:absolute!important;top:0!important;border-width:0 1px 1px 0;border-style:solid;border-color:#B5B8C8;}
            .x-form-field-wrap .x-form-trigger-over.clearableInputField-form-clear-trigger{background-position:-21px 0;}
            .x-form-field-wrap .x-form-trigger-click.clearableInputField-form-clear-trigger{background-position:-42px 0;}
            .x-trigger-wrap-focus .x-form-trigger.clearableInputField-form-clear-trigger{background-position:-63px 0;border-color:#7EADD9;}
            .x-trigger-wrap-focus .x-form-trigger-over.clearableInputField-form-clear-trigger{background-position:-84px 0;border-color:#7EADD9;}
            .x-trigger-wrap-focus .x-form-trigger-click.clearableInputField-form-clear-trigger{background-position:-105px 0;border-color:#7EADD9;}
            .listview-accountlist .x-grid3-row{border-bottom:1px solid #C7D1C5;}
            .listview-accountlist .x-grid3-row.x-grid3-row-last{border-bottom:0;}
            .listview-accountlist .x-grid3-row .x-grid3-col{vertical-align:middle;}
            .listview-accountlist .x-grid3-row-selected{background-color:transparent!important;background-repeat:no-repeat;background-position:20px center;background-image:/*savepage-url=../images/default/icon/icon_ok.png*/url();}
            .listview-accountlist .x-grid3-row.x-grid3-row-over{background-color:#DDE3DC!important;}
            .listview-accountlist .x-grid3{background-color:transparent;}
            .ib-btn-operation .x-btn-tl,.ib-btn-operation .x-btn-tr,.ib-btn-operation .x-btn-tc,.ib-btn-operation .x-btn-ml,.ib-btn-operation .x-btn-mr,.ib-btn-operation .x-btn-mc,.ib-btn-operation .x-btn-bl,.ib-btn-operation .x-btn-br,.ib-btn-operation .x-btn-bc{background-image:/*savepage-url=../images/default/button/btn_ib.gif*/url();}
            .ib-btn-operation .x-btn-mc{text-align:center;}
            .ib-btn-operation button.x-btn-text{padding-left:0;padding-right:0;text-align:center;}
            .ib-btn-operation .x-btn-icon-small-top .x-btn-text{padding-top:110px;white-space:normal;text-align:center;}
            .ib-btn-operation .x-btn-icon-small-bottom .x-btn-text{text-align:center;padding-bottom:110px;white-space:normal;}
            .ib-btn-operation .x-btn-small .x-btn-text h2{font-weight:bold;font-size:15px;color:#00AEEF;text-align:center;}
            .ib-btn-operation .x-btn-small .x-btn-text h3{font-weight:normal;font-size:12px;text-align:center;}
            .infoicon{positon:relative;width:19px;height:16px;vertical-align:middle;top:-16px;background:/*savepage-url=../images/default/infoicon/icon_info.png*/url() no-repeat transparent;}
            .infoicon-block{display:inline-block;positon:relative;width:19px;height:16px;vertical-align:middle;top:-16px;background:/*savepage-url=../images/default/infoicon/icon_info.png*/url() no-repeat transparent;margin-left:3px;}
            .ib-btn-group .x-btn-group-header{color:#3e6aaa;}
            .ib-btn-group .x-btn-group-tc{background-image:/*savepage-url=../images/default/button/group-tb.gif*/url();}
            .ib-btn-group .x-btn-group-tl{background-image:/*savepage-url=../images/default/button/group-cs.gif*/url();}
            .ib-btn-group .x-btn-group-tr{background-image:/*savepage-url=../images/default/button/group-cs.gif*/url();}
            .ib-btn-group .x-btn-group-bc{background-image:/*savepage-url=../images/default/button/group-tb.gif*/url();height:2px;}
            .ib-btn-group .x-btn-group-bl{background-image:/*savepage-url=../images/default/button/group-cs.gif*/url();}
            .ib-btn-group .x-btn-group-br{background-image:/*savepage-url=../images/default/button/group-cs.gif*/url();}
            .ib-btn-group .x-btn-group-ml{background-image:/*savepage-url=../images/default/button/group-lr.gif*/url();padding-left:1px;}
            .ib-btn-group .x-btn-group-mr{background-image:/*savepage-url=../images/default/button/group-lr.gif*/url();padding-right:1px;}
            .ib-btn-group .x-btn-group-notitle .x-btn-group-tc{background-image:/*savepage-url=../images/default/button/group-tb.gif*/url();}
            .ib-btn-group .x-btn-group-mc{padding:0;}
            .ib-btngroup-noborder .x-btn-group-header{color:#3e6aaa;}
            .ib-btngroup-noborder .x-btn-group-tc,.ib-btngroup-noborder .x-btn-group-tl,.ib-btngroup-noborder .x-btn-group-tr,.ib-btngroup-noborder .x-btn-group-bc,.ib-btngroup-noborder .x-btn-group-bl,.ib-btngroup-noborder .x-btn-group-br,.ib-btngroup-noborder .x-btn-group-ml,.ib-btngroup-noborder .x-btn-group-mr,.ib-btngroup-noborder .x-btn-group-notitle .x-btn-group-tc{background-image:none;}
            .ib-btngroup-noborder .x-btn-group-mc{padding:0;}
            .ib-btn-group .x-btn-tl,.ib-btn-group .x-btn-tr,.ib-btn-group .x-btn-tc,.ib-btn-group .x-btn-ml,.ib-btn-group .x-btn-mr,.ib-btn-group .x-btn-mc,.ib-btn-group .x-btn-bl,.ib-btn-group .x-btn-br,.ib-btn-group .x-btn-bc{background-image:/*savepage-url=../images/default/button/btn.gif*/url();}
            .ib-btn-group .x-btn-pressed .x-btn-tl{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-tr{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-tc{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-ml{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-mr{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-mc{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-bl{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-br{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-bc{background:none #cecece;}
            .ib-btn-group .x-btn-pressed .x-btn-text{color:#000;}
            .ib-btn .x-btn-tl,.ib-btn .x-btn-tr,.ib-btn .x-btn-tc,.ib-btn .x-btn-ml,.ib-btn .x-btn-mr,.ib-btn .x-btn-mc,.ib-btn .x-btn-bl,.ib-btn .x-btn-br,.ib-btn .x-btn-bc{background-image:/*savepage-url=../images/default/button/btn.gif*/url();}
            .ib-btn .x-btn-mc{text-align:left;}
            .ib-btn button.x-btn-text{padding-left:5px;padding-right:5px;font-weight:normal;font-size:11px;}
            @CHARSET "UTF-8";.filterpanel{margin-top:1px;}
            .filterpanel.x-masked>.filterpanel-header{background-image:none;background-color:#E3E8E2;}
            .filterpanel.x-masked>.filterpanel-header>.x-tool-toggle{display:none;}
            .filterpanel>.ext-el-mask{opacity:0;}
            .filterpanel-header{height:28px;line-height:28px;background:/*savepage-url=../images/default/form/cf_filterpanel-header-bg.gif*/url() repeat-x;border:1px solid #C7D1C5;padding:0 10px;color:#000;font-size:13px;font-weight:bold;white-space:nowrap;overflow:hidden;}
            .filterpanel-header-multiline{line-height:15px;background:/*savepage-url=../images/default/form/cf_filterpanel-header-multiline-bg.gif*/url() repeat-x;border:1px solid #C7D1C5;padding:6px 10px;color:#000;font-size:13px;font-weight:bold;}
            .filterpanel .x-tool{background-image:/*savepage-url=../images/default/form/cf_tool-sprites.gif*/url();}
            .filterpanel .x-tool-toggle{background-position:-21px 50%;height:100%;}
            .filterpanel.x-panel-collapsed .x-tool-toggle{background-position:4px 50%;height:100%;}
            .filterpanel-header-summary{font-weight:normal;}
            .filterpanel>.x-panel-bwrap{background-color:#F4F6F3;padding:7px 6px;margin:auto;}
            .accordionpanel-header{height:30px;border-top:1px solid white;padding:0 10px;line-height:30px;color:#363636;font-size:12px;}
            .accordionpanel-header .x-accordion-hd{background:#EEF1EE;}
            .accordionpanel-disabled{background-color:#EEF1EE;color:#B3BCB1;}
            .accordionpanel-header .headtitle{float:left;min-width:40%;color:#363636;padding-left:15px;}
            .accordionpanel-header .miniinfo{float:left;font-weight:bold;}
            .accordionpanel-header .collapseIcon{float:left;background:/*savepage-url=../images/default/tool-sprites.gif*/url() no-repeat top left;background-position:4px 50%;width:15px;height:100%;}
            .x-panel-collapsed .accordionpanel-header .collapseIcon{background-position:-21px 50%;}
            .accordionpanel-bbar{background:transparent;margin-top:10px;border:1px solid;}
            .accordionpanel-bbar .x-toolbar-layout-ct{background:transparent;border:0;}
            .accordionpanel-header .statusIcon{float:right;margin-right:15px;width:16px;height:100%;background-repeat:no-repeat;background-position:center center;}
            .accordionpanel-header .ok{background-image:/*savepage-url=../images/default/icon/icon_ok.png*/url();}
            .accordionpanel-header .error{background-image:/*savepage-url=../images/default/icon/icon_error.png*/url();}
            .x-bubblegrid-panel td.x-grid3-cell{border:0;height:30px;line-height:30px;}
            .x-bubble-ml{padding-left:4px;background:transparent /*savepage-url=../images/default/grid/bubble-lr.gif*/ url() repeat-y 0 0;}
            .x-bubble-mr{padding-right:4px;background:transparent /*savepage-url=../images/default/grid/bubble-lr.gif*/ url() repeat-y right 0;}
            .x-bubble-mc{background:#E4E9E3;overflow:hidden;}
            .x-bubble-tl{background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-cs.gif*/ url() no-repeat 0 0;padding-left:11px!important;}
            .x-bubble-tr{background:transparent /*savepage-url=../images/default/grid/bubble-cs.gif*/ url() no-repeat right top;padding-right:11px!important;}
            .x-bubble-tc{overflow:hidden;padding-top:4px;background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-tb.gif*/ url() repeat-x 0 0;}
            .x-bubble-bl{background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-cs.gif*/ url() no-repeat 0 bottom;padding-left:11px;}
            .x-bubble-br{background:transparent /*savepage-url=../images/default/grid/bubble-cs.gif*/ url() no-repeat right bottom;padding-right:11px;}
            .x-bubble-bc{height:5px;font-size:1px;line-height:1px;overflow:hidden;background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-tb.gif*/ url() repeat-x 0 bottom;}
            .x-bubble{margin:5px 0;}
            .x-bubble-bwrap{background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-tb.gif*/ url() repeat-x 0 0;overflow:hidden;}
            .x-bubble-body{background:#E4E9E3;overflow:hidden;}
            .x-bubble-header{color:#000;font-size:15px;font-weight:normal;line-height:30px;min-height:30px;background-color:transparent;background-image:none;}
            .x-panel-collapsed .x-bubble-ml,.x-panel-collapsed .x-bubble-mr{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-lr.gif*/url();}
            .x-panel-collapsed .x-bubble-bl,.x-panel-collapsed .x-bubble-br,.x-panel-collapsed .x-bubble-tr,.x-panel-collapsed .x-bubble-tl{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-cs.gif*/url();}
            .x-panel-collapsed .x-bubble-bc,.x-panel-collapsed .x-bubble-bwrap,.x-panel-collapsed .x-bubble-tc{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-tb.gif*/url();}
            .x-grid3-row.x-bubble .x-grid3-row-body{background:#E4E9E3;border:1px solid #C7D1C5;border-width:0 1px;}
            .x-grid3-col .x-bubble-tr,.x-grid3-col .x-bubble-tl{padding:0!important;}
            .x-grid3-cell-first .x-bubble-tl{padding-left:11px!important;}
            .x-grid3-cell-last .x-bubble-tr{padding-right:11px!important;}
            .x-grid3-row-collapsed .x-bubble-ml,.x-grid3-row-collapsed .x-bubble-mr{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-lr.gif*/url();}
            .x-grid3-row-collapsed .x-bubble-bl,.x-grid3-row-collapsed .x-bubble-br,.x-grid3-row-collapsed .x-bubble-tr,.x-grid3-row-collapsed .x-bubble-tl{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-cs.gif*/url();}
            .x-grid3-row-collapsed .x-bubble-bc,.x-grid3-row-collapsed .x-bubble-bwrap,.x-grid3-row-collapsed .x-bubble-tc,.x-grid3-row-collapsed.x-bubble .x-grid3-cell-inner{background-image:/*savepage-url=../images/default/grid/bubble-collapsed-tb.gif*/url();}
            .x-bubble .x-grid3-cell-inner{padding-top:7px;background:#E4E9E3 /*savepage-url=../images/default/grid/bubble-tb.gif*/ url() repeat-x 0 0;}
            .message-icon-error{background:/*savepage-url=../images/default/icon/icon_big_alert.png*/url() no-repeat;width:36px;height:36px;padding-right:5px;}
            .message-icon-info{background:/*savepage-url=../images/default/icon/icon_big_information.png*/url() no-repeat;width:36px;height:36px;padding-right:5px;}
            .message-icon-warning{background:/*savepage-url=../images/default/icon/icon_big_warning.png*/url() no-repeat;width:36px;height:36px;padding-right:5px;}
            .message-icon-success{background:/*savepage-url=../images/default/icon/icon_big_succesful.png*/url() no-repeat;width:36px;height:36px;padding-right:5px;}
            .message-title-error{color:red;font-size:16px;font-family:sans-serif;font-weight:900;}
            .message-title-warning{color:DarkOrange;font-size:16px;font-family:sans-serif;font-weight:900;}
            .message-title-info{color:SteelBlue;font-size:16px;font-family:sans-serif;font-weight:900;}
            .message-title-success{color:Green;font-size:16px;font-family:sans-serif;font-weight:900;}
            .message-details-error,.message-details-warning,.message-details-info,.message-details-success{font-size:12px;font-family:sans-serif;}
            .message-item-error,.message-item-warning,.message-item-info,.message-item-success{background:#FFF;background:-moz-linear-gradient(top,rgba(255,255,255,1),rgba(255,255,255,0.7)));background:-webkit-gradient(linear,left top,left bottom,from(rgba(255,255,255,1)),to(rgba(255,255,255,0.7)));filter:progid:DXImageTransform.Microsoft.Gradient(StartColorStr='#FFFFFFFF',EndColorStr='#FFFFFFB3',GradientType=0);}
            .cal-day .x-btn-tl,.cal-day .x-btn-tr,.cal-day .x-btn-tc,.cal-day .x-btn-ml,.cal-day .x-btn-mr,.cal-day .x-btn-mc,.cal-day .x-btn-bl,.cal-day .x-btn-br,.cal-day .x-btn-bc{background-image:/*savepage-url=../images/default/calendar/calendar-btn-day.gif*/url();}
            .cal-today .x-btn-tl,.cal-today .x-btn-tr,.cal-today .x-btn-tc,.cal-today .x-btn-ml,.cal-today .x-btn-mr,.cal-today .x-btn-mc,.cal-today .x-btn-bl,.cal-today .x-btn-br,.cal-today .x-btn-bc{background-image:/*savepage-url=../images/default/calendar/calendar-btn-today.gif*/url();}
            .cal-thismonth .x-btn-tl,.cal-thismonth .x-btn-tr,.cal-thismonth .x-btn-tc,.cal-thismonth .x-btn-ml,.cal-thismonth .x-btn-mr,.cal-thismonth .x-btn-mc,.cal-thismonth .x-btn-bl,.cal-thismonth .x-btn-br,.cal-thismonth .x-btn-bc{background-image:/*savepage-url=../images/default/calendar/calendar-btn-thismonth.gif*/url();}
            .cal-table{width:100%;border-spacing:1px 1px;}
            .cal-day .x-btn-mc{text-align:left;vertical-align:top;height:100%;width:100%;overflow:hidden;white-space:normal;}
            .cal-day .x-btn{height:100%;}
            .cal-day .day-container{position:relative;height:97%;}
            .cal-day .day-number{font-size:16px;font-weight:bold;position:absolute;top:1px;left:3px;}
            .cal-day .day-text{font-size:11px;position:absolute;bottom:0;width:100%;text-align:right;}
            .cal-day{cursor:pointer;float:left;height:70px;overflow:hidden;width:14.28%;font-size:11px;}
            .cal-header{float:left;overflow:hidden;height:25px;line-height:20px;width:14.28%;font-size:12px;font-weight:bold;text-align:left;}
            .cal-panel-tbar{background-color:#57758C!important;border:1px solid #99BBE8!important;}
            .x-form-field-wrap .searchfield-form-clear-trigger{background-image:/*savepage-url=../images/default/form/clear-trigger.gif*/url();width:21px;height:21px!important;position:absolute!important;right:22px;top:0!important;border-width:1px 0;}
            .x-form-field-wrap .searchfield-form-rapidsearch-trigger{background-image:/*savepage-url=../images/default/form/rapidsearch-trigger.gif*/url();width:21px;height:21px!important;position:static!important;cursor:pointer;border-width:1px 0;}
            .x-form-field-wrap .x-form-trigger-over.searchfield-form-clear-trigger,.x-form-field-wrap .x-form-trigger-over.searchfield-form-rapidsearch-trigger{background-position:-21px 0;}
            .x-form-field-wrap .x-form-trigger-click.searchfield-form-clear-trigger,.x-form-field-wrap .x-form-trigger-click.searchfield-form-rapidsearch-trigger{background-position:-42px 0;}
            .x-trigger-wrap-focus .x-form-trigger.searchfield-form-clear-trigger,.x-trigger-wrap-focus .x-form-trigger.searchfield-form-rapidsearch-trigger{background-position:-63px 0;}
            .x-trigger-wrap-focus .x-form-trigger-over.searchfield-form-clear-trigger,.x-trigger-wrap-focus .x-form-trigger-over.searchfield-form-rapidsearch-trigger{background-position:-84px 0;}
            .x-trigger-wrap-focus .x-form-trigger-click.searchfield-form-clear-trigger,.x-trigger-wrap-focus .x-form-trigger-click.searchfield-form-rapidsearch-trigger{background-position:-105px 0;}
            .searchfield-form-trigger-bg{border-style:solid;border-width:1px 0;border-color:#B5B8C8;padding:1px 0 3px;background-repeat:repeat-x;background-color:#fff;background-image:/*savepage-url=../../extjs/resources/images/default/form/text-bg.gif*/var(--savepage-url-7);border-color:#b5b8c8;}
            .x-cloud{line-height:2.8em;text-align:center;vertical-alig:middle;}
            .x-cloud-item{display:inline-block;margin:6px 6px;zoom:1;*display:inline;}
            .x-cloud-item>a{cursor:pointer;}
            .x-cloud-item a:hover{color:#002a85;}
            .x-cloud-item-selected a{background-color:#316ac5;color:#FFF;text-decoration:none;}
            .x-cloud-item-selected a:hover{cursor:default;color:#FFF;}
            .x-cloud-item.tag1{font-size:.7em;font-weight:100;}
            .x-cloud-item.tag2{font-size:.8em;font-weight:200;}
            .x-cloud-item.tag3{font-size:.9em;font-weight:300;}
            .x-cloud-item.tag4{font-size:1.0em;font-weight:400;}
            .x-cloud-item.tag5{font-size:1.2em;font-weight:500;}
            .x-cloud-item.tag6{font-size:1.4em;font-weight:600;}
            .x-cloud-item.tag7{font-size:1.6em;font-weight:700;}
            .x-cloud-item.tag8{font-size:1.8em;font-weight:800;}
            .x-cloud-item.tag9{font-size:2.2em;font-weight:900;}
            .x-cloud-item.tag10{font-size:2.5em;font-weight:900;}
            .x-cloud-item.tag1 img{height:18px;}
            .x-cloud-item.tag2 img{height:20px;}
            .x-cloud-item.tag3 img{height:22px;}
            .x-cloud-item.tag4 img{height:25px;}
            .x-cloud-item.tag5 img{height:28px;}
            .x-cloud-item.tag6 img{height:31px;}
            .x-cloud-item.tag7 img{height:34px;}
            .x-cloud-item.tag8 img{height:37px;}
            .x-cloud-item.tag9 img{height:40px;}
            .x-cloud-item.tag10 img{height:43px;}
            .x-cloud-item img{vertical-align:middle;}
            .message-warning{background:/*savepage-url=../images/default/icon/messages/icon_big_alert.png*/url() no-repeat!important;height:36px!important;width:36px!important;}
            .message-error{background:/*savepage-url=../images/default/icon/messages/icon_big_alert.png*/url() no-repeat!important;height:36px!important;width:36px!important;}
            .message-info{background:/*savepage-url=../images/default/icon/messages/icon_big_information.png*/url() no-repeat!important;height:36px!important;width:36px!important;}
            .message-info-small{background:/*savepage-url=../images/default/icon/messages/icon_small_information.png*/url() no-repeat!important;height:18px!important;padding-left:33px;line-height:18px;}
            .message-success{background:/*savepage-url=../images/default/icon/messages/icon_big_succesful.png*/url() no-repeat!important;height:36px!important;width:36px!important;}
            .messagestatusbar{border:none;background-color:white;}
            .x-toolbar .messagestatusbar{border:none;background-color:white;}
            .messagestatusbar .message-info,.messagestatusbar .message-warning,.messagestatusbar .message-error,.messagestatusbar .message-success{padding:5px 0 0 50px!important;font-size:16px!important;}
            .x-toolbar span.error-text,.x-window-body span.error-text{color:#f00;font-size:16px;font-weight:bold;}
            .x-toolbar span.warning-text,.x-window-body span.warning-text{color:#ffa500;font-size:16px;font-weight:bold;}
            .x-toolbar span.info-text,.x-window-body span.info-text{color:#267cc1;font-size:16px;font-weight:bold;}
            .x-toolbar span.success-text,.x-window-body span.success-text{color:#398000;font-size:16px;font-weight:bold;}
            .x-toolbar span.detail-text,.x-window-body span.detail-text{font-size:14px;color:#000;font-weight:normal;}
            .functionpanel>.ext-el-mask{background:/*savepage-url=../../extjs/resources/images/default/grid/wait.gif*/url() no-repeat scroll center center #FFF;opacity:.8!important;}
            .functionpanel-header{height:35px;line-height:35px;background:/*savepage-url=../images/default/panel/functionpanel-header_bg.png*/url() no-repeat;border:0;padding:0 5px 0 10px;color:#265f83;background-color:#FFF;font-size:18px;font-weight:bold;}
            .functionpanel{border:0;margin-bottom:10px;background-color:#FFF;}
            .functionpanel-body{background-color:#FFF;background-repeat:no-repeat;}
            .functionpanel>.x-panel-bwrap{background-color:#FFF;}
            .functionpanel-line{height:10px;position:relative;width:100%;overflow:hidden;}
            .functionpanel-line div{height:10px;position:absolute;}
            .functionpanel-line-right{width:200px;background-image:/*savepage-url=../images/default/panel/functionpanel-right-bg.png*/url();right:0;}
            .functionpanel-line-center{background-image:/*savepage-url=../images/default/panel/functionpanel-center-bg.png*/url();width:100%;}
            .functionpanel-line-left{width:200px;background-image:/*savepage-url=../images/default/panel/functionpanel-left-bg.png*/url();left:0;}
            .x-panel-header-noborder.functionpanel-header{border:none;}
            .functionpanel .x-panel-tbar .messagestatusbar{border:none;background-color:white;}
            .detailpanel-header{background-image:none;color:#363636;font-size:16px;padding:15px 3px 5px 0;}
            .detailpanel-body{line-height:normal;}
            .x-panel-reset .detailpanel-body html,.x-panel-reset .detailpanel-body address,.x-panel-reset .detailpanel-body blockquote,.x-panel-reset .detailpanel-body body,.x-panel-reset .detailpanel-body dd,.x-panel-reset .detailpanel-body div,.x-panel-reset .detailpanel-body dl,.x-panel-reset .detailpanel-body dt,.x-panel-reset .detailpanel-body fieldset,.x-panel-reset .detailpanel-body form,.x-panel-reset .detailpanel-body frame,frameset,.x-panel-reset .detailpanel-body h1,.x-panel-reset .detailpanel-body h2,.x-panel-reset .detailpanel-body h3,.x-panel-reset .detailpanel-body h4,.x-panel-reset .detailpanel-body h5,.x-panel-reset .detailpanel-body h6,.x-panel-reset .detailpanel-body noframes,.x-panel-reset .detailpanel-body ol,.x-panel-reset .detailpanel-body p,.x-panel-reset .detailpanel-body ul,.x-panel-reset .detailpanel-body center,.x-panel-reset .detailpanel-body dir,.x-panel-reset .detailpanel-body hr,.x-panel-reset .detailpanel-body menu,.x-panel-reset .detailpanel-body pre{display:block;}
            .x-panel-reset .detailpanel-body li{display:list-item;}
            .x-panel-reset .detailpanel-body head{display:none;}
            .x-panel-reset .detailpanel-body table{display:table;}
            .x-panel-reset .detailpanel-body tr{display:table-row;}
            .x-panel-reset .detailpanel-body thead{display:table-header-group;}
            .x-panel-reset .detailpanel-body tbody{display:table-row-group;}
            .x-panel-reset .detailpanel-body tfoot{display:table-footer-group;}
            .x-panel-reset .detailpanel-body col{display:table-column;}
            .x-panel-reset .detailpanel-body colgroup{display:table-column-group;}
            .x-panel-reset .detailpanel-body td,.x-panel-reset .detailpanel-body th{display:table-cell;}
            .x-panel-reset .detailpanel-body caption{display:table-caption;}
            .x-panel-reset .detailpanel-body th{font-weight:bolder;text-align:center;}
            .x-panel-reset .detailpanel-body caption{text-align:center;}
            .x-panel-reset .detailpanel-body body{margin:8px;}
            .x-panel-reset .detailpanel-body h1{font-size:2em;margin:.67em 0;}
            .x-panel-reset .detailpanel-body h2{font-size:1.5em;margin:.75em 0;}
            .x-panel-reset .detailpanel-body h3{font-size:1.17em;margin:.83em 0;}
            .x-panel-reset .detailpanel-body h4,.x-panel-reset .detailpanel-body p,.x-panel-reset .detailpanel-body blockquote,.x-panel-reset .detailpanel-body ul,.x-panel-reset .detailpanel-body fieldset,.x-panel-reset .detailpanel-body form,.x-panel-reset .detailpanel-body ol,.x-panel-reset .detailpanel-body dl,.x-panel-reset .detailpanel-body dir,.x-panel-reset .detailpanel-body menu{margin:1.12em 0;}
            .x-panel-reset .detailpanel-body h5{font-size:.83em;margin:1.5em 0;}
            .x-panel-reset .detailpanel-body h6{font-size:.75em;margin:1.67em 0;}
            .x-panel-reset .detailpanel-body h1,.x-panel-reset .detailpanel-body h2,.x-panel-reset .detailpanel-body h3,.x-panel-reset .detailpanel-body h4,.x-panel-reset .detailpanel-body h5,.x-panel-reset .detailpanel-body h6,.x-panel-reset .detailpanel-body b,.x-panel-reset .detailpanel-body strong{font-weight:bolder;}
            .x-panel-reset .detailpanel-body blockquote{margin-left:40px;margin-right:40px;}
            .x-panel-reset .detailpanel-body i,.x-panel-reset .detailpanel-body cite,.x-panel-reset .detailpanel-body em,.x-panel-reset .detailpanel-body var,.x-panel-reset .detailpanel-body address{font-style:italic;}
            .x-panel-reset .detailpanel-body pre,.x-panel-reset .detailpanel-body tt,.x-panel-reset .detailpanel-body code,.x-panel-reset .detailpanel-body kbd,.x-panel-reset .detailpanel-body samp{font-family:monospace;}
            .x-panel-reset .detailpanel-body pre{white-space:pre;}
            .x-panel-reset .detailpanel-body button,.x-panel-reset .detailpanel-body textarea,.x-panel-reset .detailpanel-body input,.x-panel-reset .detailpanel-body select{display:inline-block;}
            .x-panel-reset .detailpanel-body big{font-size:1.17em;}
            .x-panel-reset .detailpanel-body small,.x-panel-reset .detailpanel-body sub,.x-panel-reset .detailpanel-body sup{font-size:.83em;}
            .x-panel-reset .detailpanel-body sub{vertical-align:sub;}
            .x-panel-reset .detailpanel-body sup{vertical-align:super;}
            .x-panel-reset .detailpanel-body table{border-spacing:2px;}
            .x-panel-reset .detailpanel-body thead,.x-panel-reset .detailpanel-body tbody,.x-panel-reset .detailpanel-body tfoot{vertical-align:middle;}
            .x-panel-reset .detailpanel-body td,.x-panel-reset .detailpanel-body th{vertical-align:inherit;}
            .x-panel-reset .detailpanel-body s,.x-panel-reset .detailpanel-body strike,.x-panel-reset .detailpanel-body del{text-decoration:line-through;}
            .x-panel-reset .detailpanel-body hr{border:1px inset;}
            .x-panel-reset .detailpanel-body ol,.x-panel-reset .detailpanel-body ul,.x-panel-reset .detailpanel-body dir,.x-panel-reset .detailpanel-body menu,.x-panel-reset .detailpanel-body dd{margin-left:40px;}
            .x-panel-reset .detailpanel-body ul,.x-panel-reset .detailpanel-body menu,.x-panel-reset .detailpanel-body dir{list-style-type:disc;}
            .x-panel-reset .detailpanel-body ol{list-style-type:decimal;}
            .x-panel-reset .detailpanel-body ol ul,.x-panel-reset .detailpanel-body ul ol,.x-panel-reset .detailpanel-body ul ul,.x-panel-reset .detailpanel-body ol ol{margin-top:0;margin-bottom:0;}
            .x-panel-reset .detailpanel-body u,.x-panel-reset .detailpanel-body ins{text-decoration:underline;}
            .x-panel-reset .detailpanel-body br:before{content:"\A";}
            .x-panel-reset .detailpanel-body :before,.x-panel-reset .detailpanel-body :after{white-space:pre-line;}
            .x-panel-reset .detailpanel-body center{text-align:center;}
            .x-panel-reset .detailpanel-body :link,.x-panel-reset .detailpanel-body :visited{text-decoration:underline;}
            .x-panel-reset .detailpanel-body :focus{outline:invert dotted thin;}
            .x-panel-reset .detailpanel-body BDO[DIR="ltr"]{direction:ltr;unicode-bidi:bidi-override;}
            .x-panel-reset .detailpanel-body BDO[DIR="rtl"]{direction:rtl;unicode-bidi:bidi-override;}
        </style>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov.js-fix.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            bis_use="true"
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="utf-8"
            data-bis-config='["facebook.com/","twitter.com/","youtube-nocookie.com/embed/","//vk.com/","//www.vk.com/","linkedin.com/","//www.linkedin.com/","//instagram.com/","//www.instagram.com/","//www.google.com/recaptcha/api2/","//hangouts.google.com/webchat/","//www.google.com/calendar/","//www.google.com/maps/embed","spotify.com/","soundcloud.com/","//player.vimeo.com/","//disqus.com/","//tgwidget.com/","//js.driftt.com/","friends2follow.com","/widget","login","//video.bigmir.net/","blogger.com","//smartlock.google.com/","//keep.google.com/","/web.tolstoycomments.com/","moz-extension://","chrome-extension://","/auth/","//analytics.google.com/","adclarity.com","paddle.com/checkout","hcaptcha.com","recaptcha.net","2captcha.com","accounts.google.com","www.google.com/shopping/customerreviews","buy.tinypass.com","gstatic.com","secureir.ebaystatic.com","docs.google.com","contacts.google.com","github.com","mail.google.com","chat.google.com","audio.xpleer.com","keepa.com","static.xx.fbcdn.net","sas.selleramp.com","1plus1.video","console.googletagservices.com","//lnkd.demdex.net/","//radar.cedexis.com/","//li.protechts.net/","challenges.cloudflare.com/","ogs.google.com"]'
            data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/traffic.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="extjs/adapter/ext/ext-base.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov.ext-base-fix.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="extjs/ext-all.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov.ext-all-fix.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/RightClickHandler.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/pegasus-web-fix.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/pegasus-web-component.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov-component-resource.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script data-savepage-type="text/javascript" type="text/plain"></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/channel-web-component.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov.channel.overrides.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/validation-web-component.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <style
            data-savepage-href="resources/style/login.css?build=05bce331010b38dcd80432018244dfe18f68e164"
            type="text/css"
        >
            .login-wrap {
                background: #ffffff;
            }

            .login-wrap .ext-el-mask {
                z-index: 10010;
            }

            .login-wrap .login-footer {
                background-color: #e0e0e0;
                border: 1px solid #dedede;
            }

            .login-wrap .login-footer span {
                line-height: 24px;
            }

            .login-wrap .login-footer span a,
            .login-wrap .login-footer span a:visited {
                color: #98266f;
            }

            .login-wrap .login-footer .x-toolbar-left {
                padding-left: 50px;
            }

            .login-wrap .login-footer .xtb-sep {
                background-color: #616161;
                width: 1px;
                height: 10px;
                margin: 0 12px;
            }

            .login-wrap span {
                line-height: 18px;
            }

            .login-ct {
                width: 860px;
                position: relative;
                margin: 0 auto;
                padding-top: 80px;
            }

            .login-ct > div {
                background: /*savepage-url=../images/theme-light/body_bk.jpg*/ var(--savepage-url-5) no-repeat center;
            }

            .login-ct .x-panel-body {
                overflow: hidden;
            }

            .login-ct .login-main {
                border: 1px solid #dedede;
            }

            #loginContainer {
                overflow: hidden;
                padding-bottom: 30px;
                padding-top: 110px;
                border: solid #dedede;
                border-width: 1px 1px 0;
            }

            .login-ct .x-panel-body.x-form {
                position: auto;
            }

            h1.login-image-header {
                /* 	width: 318px; */
                width: 106px;
                height: 68px;
                position: absolute;
                top: 50px;
                padding-left: 50px;
            }

            h1.login-image-header span {
                position: absolute;
                /* 	width: 318px; */
                width: 106px;
                height: 68px;
                /* 	background: url('../images/bovlogo_demo.png') no-repeat left top; */
                background: /*savepage-url=../images/bovlogo.png*/ var(--savepage-url-6) no-repeat left top;
            }

            h1.login-image {
                width: 280px;
                height: 258px;
                position: absolute;
                bottom: -60px;
                right: 200px;
                z-index: 10005;
            }

            h1.login-image span {
                position: absolute;
                width: 280px;
                height: 258px;
            }

            .login-info-bubble,
            .login-info-how {
                margin: 10px 0;
                padding-left: 10px;
                width: 40px;
                height: 22px;
            }

            .login-info-bubble {
                cursor: pointer;
                width: 20px;
                height: 10px;
                background: transparent /*savepage-url=../images/grid/info_bubble.png*/ url() no-repeat center;
                z-index: 10010;
                padding-top: 19px;
                padding-left: 0px;
                margin-left: 10px !important;
            }

            .login-info-bubble:hover {
                background: transparent /*savepage-url=../images/grid/info_bubble_dark.png*/ url() no-repeat center;
            }

            .login-info-bubble.active-tip {
                background: transparent /*savepage-url=../images/grid/info_bubble_active.png*/ url() no-repeat center;
            }

            .login-info-how {
                cursor: default;
                color: blue;
                line-height: 22px;
                text-decoration: underline;
                z-index: 10010;
                padding-top: 6px;
            }

            .login-tip {
                left: 420px;
                top: 70px;
                z-index: 10002 !important;
            }

            .login-tip .tip-title {
                margin-bottom: 15px;
            }

            .login-tip .x-tip-body {
                padding: 10px;
            }

            .login-tip.token-tip {
                top: 50px;
            }

            .login-tip .left {
                width: 250px;
                height: 184px;
            }

            .login-tip .left .tip-title {
                margin-bottom: 35px;
                margin-right: 50px;
            }

            .login-tip ol {
                list-style: decimal outside none;
                padding-left: 15px;
            }

            .login-tip ol,
            .login-tip p,
            .login-tip li {
                line-height: 18px;
            }

            .login-tip .select-dp260,
            .login-tip .select-dp310,
            .login-tip .select-swtoken,
            .login-tip .select-dp770 {
                position: absolute;
                top: 10px;
                height: 40px;
                width: 26px;
            }

            .login-tip .select-dp260:hover,
            .login-tip .select-dp310:hover,
            .login-tip .select-swtoken:hover,
            .login-tip .select-dp770:hover,
            .login-tip .close {
                cursor: pointer;
            }

            .login-tip .select-dp260 {
                background-image: /*savepage-url=../images/login/small_securekey.png*/ url();
                left: 225px;
            }

            .login-tip .select-dp310 {
                background-image: /*savepage-url=../images/login/small_securekey_dp310.png*/ url();
                left: 255px;
            }

            .login-tip .select-swtoken {
                background-image: /*savepage-url=../images/login/small_securekey_swtoken.png*/ url();
                left: 285px;
            }

            .login-tip .select-dp770 {
                background-image: /*savepage-url=../images/login/small_securekey_dp770.png*/ url();
                left: 315px;
            }

            .login-tip .close {
                background: transparent /*savepage-url=../images/icons/icon-delete.gif*/ url() no-repeat;
                position: absolute;
                top: 10px;
                height: 15px;
                width: 15px;
                left: 355px;
            }

            .login-tip .tip-token-image.dp260,
            .login-tip .tip-token-image.dp310,
            .login-tip .tip-token-image.swtoken,
            .login-tip .tip-token-image.dp770 {
                position: absolute;
                top: 65px;
                right: 10px;
                height: 130px;
                width: 84px;
            }

            .login-tip .tip-token-image.dp260 {
                background: transparent /*savepage-url=../images/login/securekey.png*/ url() no-repeat top left;
            }

            .login-tip .tip-token-image.dp310 {
                background: transparent /*savepage-url=../images/login/securekey_dp310.png*/ url() no-repeat top left;
            }

            .login-tip .tip-token-image.swtoken {
                background: transparent /*savepage-url=../images/login/securekey_swtoken.png*/ url() no-repeat top left;
            }

            .login-tip .tip-token-image.dp770 {
                background: transparent /*savepage-url=../images/login/securekey_dp770.png*/ url() no-repeat top left;
            }

            .login-tip .x-btn {
                margin: 10px 0 10px auto;
                z-index: 20010;
            }

            .login-ct .x-shadow {
                left: 424px;
                top: 73px;
            }

            .login-fieldset {
                padding: 30px;
                margin-top: 30px;
                background-color: #fefefe;
                margin-left: 50px;
                position: relative;
            }

            .ext-ie .x-fieldset.login-fieldset {
                padding: 30px;
            }

            .login-fieldset.question {
                margin-top: 30px;
            }

            .login-fieldset .x-form-item,
            .login-info-bubble,
            .login-info-how {
                float: left;
                margin: 0px;
            }

            .login-fieldset .x-btn {
                padding-right: 90px;
            }
            .login-fieldset.question .x-btn {
                padding-right: 0;
                padding-left: 18px;
            }

            .login-container-title {
                color: #616161;
                margin-bottom: 30px;
            }

            .login-msg-panel {
            }

            .login-question-info p {
                cursor: default;
                line-height: 22px;
            }

            .login-question-info .detail {
                color: purple;
                margin-bottom: 20px;
            }

            #loginForm .x-panel-body.x-form {
                background: none transparent;
            }

            #loginForm .x-panel-tl,
            #loginForm .x-panel-tr,
            #loginForm .x-panel-tc,
            #loginForm .x-panel-ml,
            #loginForm .x-panel-mr,
            #loginForm .x-panel-mc,
            #loginForm .x-panel-bl,
            #loginForm .x-panel-br,
            #loginForm .x-panel-bc {
                border: none;
                background: none transparent;
            }
            #loginForm .x-panel-mc {
            }
            #loginForm .x-panel-header {
                margin: 10px 0 0 0;
                border: none;
                text-align: center;
                background: none transparent;
            }
            #loginForm .x-panel-header-text {
                color: #616161;
            }
            #loginForm .x-form-item label {
                color: #616161;
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 9pt;
                margin: 10px 0;
            }
            #loginForm .x-form-field {
                border-color: #b6b6b6;
            }
            #loginForm .x-form-element {
                margin: 5px 0;
            }

            /* Message Panels */

            .login-msg-panel .login-msg-icon-error {
                background: transparent /*savepage-url=../images/icons/msg/icon_info_inform.png*/ url() no-repeat 0 0;
            }
            .login-msg-panel .login-msg-icon-warning {
                background: transparent /*savepage-url=../images/icons/msg/icon_warning_inform.png*/ url() no-repeat 0 0;
            }
            .login-msg-panel .login-msg-icon-info {
                background: transparent /*savepage-url=../images/icons/msg/icon_error_inform.png*/ url() no-repeat 0 0;
            }

            .login-msg-panel .login-msg-icon-error,
            .login-msg-panel .login-msg-icon-warning,
            .login-msg-panel .login-msg-icon-info {
                padding: 0 30px 0 50px;
                min-height: 36px;
            }
            .login-msg-panel .bov-info-panel,
            .login-msg-panel .bov-warning-panel,
            .login-msg-panel .bov-error-panel {
                color: #545454;
                min-height: 40px;
                height: auto !important;
                height: 40px;
                font-size: 12px;
                font-family: sans-serif;
                font-weight: normal;
            }
            .bov-message-panel-title {
                font-weight: bold;
            }

            #login-ct .x-panel-bbar div table {
                height: 100%;
            }
            #login-ct .x-toolbar-left table tbody tr td:nth-child(2) {
                vertical-align: center;
                width: 1px;
            }
            #login-ct .x-toolbar-left table tbody tr td:first-child {
                vertical-align: center;
                /* 	width: 50%; */
            }
            #xlogin-ct .x-toolbar-left table tbody tr td:last-child {
                /* 	width: 50%; */
                vertical-align: center;
            }

            #login-ct .x-panel-bbar div table tbody tr:nth-child(2) {
                display: none;
            }

            .login-wrap .login-footer-banner {
                background-color: #ffffff;
                border: none;
                line-height: 16px;
                padding: 8px;
            }
        </style>
        <style
            data-savepage-href="resources/style/ib-web-skin.css?build=05bce331010b38dcd80432018244dfe18f68e164"
            type="text/css"
        >
            /*!* Ext JS Library 3.3.1 * Copyright(c) 2006-2010 Sencha Inc. * licensing@sencha.com * http://www.sencha.com/license */
            html,
            body,
            div,
            dl,
            dt,
            dd,
            ul,
            ol,
            li,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            pre,
            form,
            fieldset,
            input,
            p,
            blockquote,
            th,
            td {
                margin: 0;
                padding: 0;
            }
            img,
            body,
            html {
                border: 0;
            }
            address,
            caption,
            cite,
            code,
            dfn,
            em,
            strong,
            th,
            var {
                font-style: normal;
                font-weight: normal;
            }
            ol,
            ul {
                list-style: none;
            }
            caption,
            th {
                text-align: left;
            }
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-size: 100%;
            }
            q:before,
            q:after {
                content: "";
            }
            body,
            div,
            dl,
            dt,
            dd,
            ul,
            ol,
            li,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            pre,
            code,
            form,
            fieldset,
            legend,
            input,
            textarea,
            p,
            blockquote,
            th,
            td {
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif !important;
                font-size: 12px;
            }
            a,
            a:visited {
                color: #98266f;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            html.x-viewport {
                overflow: auto;
                min-height: 100%;
            }
            .x-viewport body {
                background-image: none;
                overflow: auto;
                overflow-x: hidden;
                color: #545454;
                min-height: 100%;
                position: relative;
            }
            #application-ct {
                margin: 0 auto;
                background-color: transparent;
            }
            #topbar-ct {
                background: #fff /*savepage-url=../images/bovlogo.png*/ var(--savepage-url-6) no-repeat 24px 21px;
                padding-right: 10px;
            }
            #header-ct .bov-btn-nobg .x-btn-tl,
            #header-ct .bov-btn-nobg .x-btn-tr,
            #header-ct .bov-btn-nobg .x-btn-tc,
            #header-ct .bov-btn-nobg .x-btn-ml,
            #header-ct .bov-btn-nobg .x-btn-mr,
            #header-ct .bov-btn-nobg .x-btn-mc,
            #header-ct .bov-btn-nobg .x-btn-bl,
            #header-ct .bov-btn-nobg .x-btn-br,
            #header-ct .bov-btn-nobg .x-btn-bc {
                background-image: none;
            }
            #topbar-ct .separator {
                background: transparent /*savepage-url=../images/icons/icon-separator.png*/ url() no-repeat left top;
            }
            #topbar-ct .image-btn.flag {
                cursor: pointer;
                float: left;
                margin-left: 5px;
            }
            #topbar-ct .image-btn.flag.pressed {
                cursor: auto;
            }
            #topbar-ct .image-btn.flag.mt {
                background: transparent /*savepage-url=../images/icons/flags/icon_flag_mt_inact.png*/ url() no-repeat
                    left top;
            }
            #topbar-ct .image-btn.flag.mt:hover {
                background-image:/*savepage-url=../images/icons/flags/icon_flag_mt.png*/ url();
            }
            #topbar-ct .image-btn.flag.en {
                background: transparent /*savepage-url=../images/icons/flags/icon_flag_gb_inact.png*/ url() no-repeat
                    left top;
            }
            #topbar-ct .image-btn.flag.en:hover {
                background-image:/*savepage-url=../images/icons/flags/icon_flag_gb.png*/ url();
            }
            #topbar-ct .themeselector-img {
                cursor: pointer;
                background: transparent /*savepage-url=../images/icons/icon-themeselector.png*/ url() no-repeat left top;
            }
            #topbar-ct .themeselector-img:hover {
                background-image:/*savepage-url=../images/icons/icon-themeselector-active.png*/ url();
            }
            #topbar-ct table td {
                vertical-align: bottom;
                padding-left: 10px;
                height: 33px;
            }
            #topbar-ct .bov-languageselector {
                height: 15px;
                overflow: hidden;
            }
            #topbar-ct .bov-languageselector .x-panel-bwrap {
                position: relative;
            }
            .ext-ie9 #topbar-ct .bov-languageselector,
            .ext-ie10 #topbar-ct .bov-languageselector {
                top: -3px;
            }
            #topbar-ct #bov-font-resizer {
                position: relative;
                top: 1px;
            }
            #topbar-ct span.username {
                font-weight: bold;
                color: #404040;
                white-space: nowrap;
            }
            #topbar-ct .font td {
                background-image: none;
            }
            #topbar-ct .font button {
                margin: 0 4px;
            }
            #logo-ct {
                height: 68px;
                width: 106px;
                margin: 20px 0 0 24px;
                background: transparent /*savepage-url=../images/bovlogo.png*/ var(--savepage-url-6) no-repeat left top;
                float: left;
            }
            #header-menutool-ct .x-toolbar-left > table {
                padding-top: 15px;
            }
            #header-menutool-ct .icon-house {
                background:/*savepage-url=../images/icons/icon-house.png*/ url() no-repeat 0 0;
                cursor: pointer;
            }
            .image-btn {
                cursor: pointer;
            }
            #header-menutool-ct .icon-house.pressed {
                background-position: -27px 0;
                cursor: auto;
            }
            #header-menutool-ct .icon-mypreferences,
            #header-menutool-ct .icon-mypreferences.x-item-disabled:hover {
                background:/*savepage-url=../images/icons/icon-header-mypreferences.png*/ url() no-repeat 0 0;
            }
            #header-menutool-ct .icon-mypreferences:hover {
                background-image:/*savepage-url=../images/icons/icon-header-mypreferences-active.png*/ url();
            }
            #header-menutool-ct .icon-sysadmin,
            #header-menutool-ct .icon-sysadmin.x-item-disabled:hover {
                background:/*savepage-url=../images/icons/icon-header-sysadmin.png*/ url() no-repeat 0 0;
            }
            #header-menutool-ct .icon-sysadmin:hover {
                background-image:/*savepage-url=../images/icons/icon-header-sysadmin-active.png*/ url();
            }
            #header-menutool-ct .x-toolbar .xtb-spacer {
                width: 10px;
            }
            #header-menutool-ct .x-toolbar .xtb-sep {
                background-image:/*savepage-url=../images/menu/icons/tb-sep.png*/ url();
                width: 2px;
                heigth: 25px;
                padding: 0 10px;
            }
            #topbar-ct a {
                font-weight: bold;
                font-size: 11px;
                color: #545454;
                text-transform: uppercase;
            }
            #topbar-ct .x-link-btn.x-item-disabled a:hover {
                text-decoration: none;
            }
            #topbar-ct .bov-btn-nobg button {
                font-weight: bold;
            }
            #topbar-ct #bov-font-resizer.enabled-all img {
                background: transparent /*savepage-url=../images/icons/font-resize.png*/ url() no-repeat left 2px;
            }
            #topbar-ct #bov-font-resizer.enabled-all:hover img {
                background-image:/*savepage-url=../images/icons/font-resize-active.png*/ url();
            }
            #topbar-ct #bov-font-resizer.enabled-up img {
                background: transparent /*savepage-url=../images/icons/font-resize-plus.png*/ url() no-repeat left top;
            }
            #topbar-ct #bov-font-resizer.enabled-dn img {
                background: transparent /*savepage-url=../images/icons/font-resize-minus.png*/ url() no-repeat left top;
            }
            #topbar-ct #bov-font-resizer p {
                color: #505050;
                text-align: center;
                font-size: 10px;
            }
            #topbar-ct #bov-font-resizer:hover p {
                color: #98266f;
            }
            #topbar-ct .ccemployee {
                color: #b00;
            }
            #topbar-ct .ccemployee > span {
                font-weight: bold;
            }
            #header-ct .x-box-layout-ct,
            #header-ct .x-box-inner {
                overflow: visible;
            }
            #main-ct {
                background: #fff;
                padding: 0;
                overflow: hidden;
                width: 100%;
            }
            #content-wrapper.landingpaged {
                background: #fff /*savepage-url=../images/mainct-bg.png*/ url() repeat-y left top;
            }
            #content-ct {
                float: left;
                min-height: 370px;
                padding: 8px;
                width: 705px;
                position: relative;
            }
            #content-ct .x-toolbar .xtb-spacer {
                width: 12px;
            }
            #side-ct {
                float: right;
                width: 231px;
                position: relative;
                padding: 8px 8px 20px 0;
            }
            #side-ct * {
                font-size: 11px;
            }
            #sidebar-tools-panel {
                width: 231px;
                position: absolute;
                bottom: 0;
                right: -223px;
            }
            #footer-ct {
                padding: 10px;
                font-size: 10pt;
                color: #333;
                overflow: hidden;
                clear: both;
                width: 940px;
            }
            #footer-ct * {
                font-size: 11px;
            }
            #footer-ct a {
                font-weight: bold;
            }
            #footer-upper-link-ct {
                padding-bottom: 18px;
            }
            #footer-upper-link-ct span {
                display: block;
                line-height: 20px;
                margin: 0 5px;
                border-bottom: 1px solid #b7b7b7;
            }
            #footer-upper-link-ct span.empty-link {
                border-bottom-width: 0;
            }
            #footer-lower-link-ct {
                background: #f4f4f6 /*savepage-url=../images/footer-line-bg.png*/ url() repeat-x left top;
                padding-top: 12px;
            }
            #footer-lower-link-ct .x-link-btn {
                margin-left: 15px;
            }
            .bov-footernewsticker span.tickerlink {
                cursor: pointer;
                text-decoration: underline;
                color: #f583cb;
                padding-left: 10px;
            }
            .bov-footernewsticker span.security-prices {
                padding-left: 30px;
            }
            .ext-ie8 td {
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif !important;
                font-size: 11px;
            }
            .ext-gecko3 .x-date-inner .x-date-active a:visited {
                color: black;
                text-decoration: none;
            }
            #landingpage-main-panel {
                margin: 0;
                min-height: 420px;
            }
            #landingpage-main-panel .x-functionbox {
                background-color: transparent;
                padding: 8px;
            }
            #landingpage-main-panel div.x-functionbox-header {
                margin: 0;
            }
            #landingpage-main-panel .x-functionbox-header-text {
                font-size: 18px;
                color: #98266f;
            }
            #landingpage-buttonholder-ct .x-panel-header-text {
                color: #363636;
                font-size: 14px;
            }
            #bov-menu-landingpage .landingpage_btn {
                margin: 0 12px 6px 0;
            }
            #bov-menu-landingpage .landingpage_btn button {
                padding: 6px 0 10px 56px;
            }
            #bov-menu-landingpage .landingpage_btn .icon {
                position: absolute;
                width: 40px;
                height: 40px;
                background-color: #dedede;
                margin-top: 12px;
                margin-left: 5px;
                display: block;
                background:/*savepage-url=../images/menu/distributionpage/landingpage_icons_sprite.png*/ url() no-repeat;
            }
            #bov-menu-landingpage .landingpage_btn .btn-tooltip.h {
                visibility: hidden;
            }
            #bov-menu-landingpage .landingpage_btn.last {
                margin-right: 0;
            }
            #bov-menu-landingpage #landingpage-buttonholder-left {
                padding-left: 10px;
            }
            #bov-menu-landingpage #landingpage-buttonholder-left .landingpage_btn {
                margin-right: 8px;
            }
            #bov-menu-landingpage .x-btn-mc {
                white-space: normal;
                height: 120px;
            }
            .landingpage_btn .x-btn-mc {
                vertical-align: top;
            }
            .landingpage_btn .x-btn-text {
                padding: 10px;
                height: auto !important;
                text-align: left;
                white-space: normal;
                width: 100%;
            }
            .ext-ie .landingpage_btn .x-btn-text {
                padding-top: 10px;
            }
            .landingpage_btn .x-btn-text-icon .x-btn-icon-medium-top .x-btn-text {
                padding-top: 110px;
                font-size: 12px;
            }
            .landingpage_btn .x-btn-text-icon .x-btn-icon-small-top .x-btn-text {
                padding-top: 80px;
                font-size: 12px;
            }
            .landingpage_btn .bov-btn-number,
            .bov-btn-bigicon .bov-btn-number em {
                font-weight: bold;
                font-size: 16px;
            }
            .landingpage_btn .bov-btn-title,
            .bov-btn-bigicon .bov-btn-title em {
                font-weight: bold;
            }
            .landingpage_btn .bov-indexbtn-title {
                text-align: right;
                color: #545454;
                font-size: 14px;
                font-weight: bold;
                min-height: 24px;
                max-width: 152px;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .landingpage_btn .bov-indexbtn-description {
                color: #840b55;
                padding: 10px 0 0 20px;
                text-align: right;
                font-size: 12px;
                min-height: 30px;
                max-width: 130px;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .landingpage_btn .x-btn-tl,
            .landingpage_btn .x-btn-tr,
            .landingpage_btn .x-btn-tc,
            .landingpage_btn .x-btn-ml,
            .landingpage_btn .x-btn-mr,
            .landingpage_btn .x-btn-mc,
            .landingpage_btn .x-btn-bl,
            .landingpage_btn .x-btn-br,
            .landingpage_btn .x-btn-bc {
                background-image:/*savepage-url=../images/menu/distributionpage/btn-bg.png*/ url();
            }
            #bov-menu-landingpage .landingpage_btn.betweenownaccounts .icon {
                background-position: -0px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.accountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.depositaccountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.borrowingaccountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.investmenthistory .icon {
                background-position: -160px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.minimumbalance .icon {
                background-position: -160px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.viewaccounthistory .icon {
                background-position: -120px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.newdepositaccount .icon {
                background-position: -400px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.viewstatementimages .icon {
                background-position: -360px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.viewchequeimages .icon {
                background-position: -80px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.orderstatements .icon {
                background-position: -200px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.orderchequeimages .icon {
                background-position: -280px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.orderchequebook .icon {
                background-position: -280px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.maturityinstructions .icon {
                background-position: -240px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.noticeaccount .icon {
                background-position: -200px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.investmentstermsnconditions .icon {
                background-position: -320px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.portfoliooverview .icon {
                background-position: -360px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.newfund .icon {
                background-position: -320px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.newsecurity .icon {
                background-position: -120px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.switchingfunds .icon {
                background-position: -320px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.viewmodifyorder .icon {
                background-position: -120px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.modifybrokerageorders .icon {
                background-position: -80px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.cancelbrokerageorders .icon {
                background-position: -120px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.dailyprices .icon {
                background-position: -400px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.profitslosscalculator .icon {
                background-position: -160px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.commissioncalculator .icon {
                background-position: -40px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.virtualportfolio .icon {
                background-position: -360px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.billpaymentfacility .icon {
                background-position: -160px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.payaperson .icon {
                background-position: -40px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.standingorderscreate .icon {
                background-position: -80px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.uploadtransactionfiles .icon,
            #bov-menu-landingpage .landingpage_btn.verificationofpayee .icon {
                background-position: -280px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.offlinefileupload .icon {
                background-position: -320px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.downloadpaymentmessages .icon {
                background-position: -320px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.standingordersview .icon {
                background-position: -120px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.stoppayment .icon {
                background-position: -400px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.templatemanagement .icon {
                background-position: -80px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.orderforeigncash .icon {
                background-position: -200px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.orderbankdraft .icon {
                background-position: -320px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.stopcards .icon {
                background-position: -360px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.requestcardreplacement .icon {
                background-position: -40px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.increasecreditlimit .icon {
                background-position: -240px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.requestcardpin .icon {
                background-position: -40px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.changecarddetails .icon {
                background-position: -320px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.linkcashlinkcard .icon {
                background-position: -40px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.registerformobilepay .icon {
                background-position: -240px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.registerformobilebank .icon {
                background-position: -120px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.registerformobiletopup .icon {
                background-position: -200px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.topupmobile .icon {
                background-position: -400px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.changemobiletopupdetails .icon {
                background-position: -40px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.mobilepaysettings .icon {
                background-position: -400px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.managemobileservice .icon {
                background-position: -80px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.managemobilechannel .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.registermobile .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.browsesmsnotifications .icon {
                background-position: -0px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.accountsmsnotifications .icon {
                background-position: -200px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.termssmsnotifications .icon {
                background-position: -240px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.depositsmsnotifications .icon {
                background-position: -120px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.paymentssmsnotifications .icon {
                background-position: -120px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.modifysmsnotifications .icon {
                background-position: -320px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.disablesmsnotifications .icon {
                background-position: -360px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.customerContactIcon .icon {
                background-position: -280px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.contactDetailsDetailsIcon .icon {
                background-position: -400px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.accountsAddressIcon .icon {
                background-position: -400px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.ImportantPhoneNumbersIcon .icon {
                background-position: -240px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.accountAddressDetailsIcon .icon {
                background-position: -400px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.requestcustomerservice .icon {
                background-position: -0px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.requestappointment .icon {
                background-position: -120px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.wealthmanagement .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.meetingappointment .icon {
                background-position: -120px -240px;
            }
            #landingpage-main-panel .landingpage_btn.manageusers .icon {
                background-position: -160px -440px;
            }
            #landingpage-main-panel .landingpage_btn.accountrights .icon {
                background-position: -0px -200px;
            }
            #landingpage-main-panel .landingpage_btn.userrights .icon {
                background-position: -320px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.betweenownaccounts .icon {
                background-position: -120px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.accountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.x-btn-over.depositaccountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.x-btn-over.borrowingaccountbalances .icon,
            #bov-menu-landingpage .landingpage_btn.x-btn-over.investmenthistory .icon {
                background-position: -80px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.minimumbalance .icon {
                background-position: -360px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.viewaccounthistory .icon {
                background-position: -240px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.newdepositaccount .icon {
                background-position: -280px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.viewstatementimages .icon {
                background-position: -0px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.viewchequeimages .icon {
                background-position: -0px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.orderstatements .icon {
                background-position: -360px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.orderchequeimages .icon {
                background-position: -400px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.orderchequebook .icon {
                background-position: -160px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.maturityinstructions .icon {
                background-position: -320px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.noticeaccount .icon {
                background-position: -160px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.investmentstermsnconditions .icon {
                background-position: -240px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.portfoliooverview .icon {
                background-position: -0px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.newfund .icon {
                background-position: -360px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.newsecurity .icon {
                background-position: -120px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.switchingfunds .icon {
                background-position: -0px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.viewmodifyorder .icon {
                background-position: -0px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.modifybrokerageorders .icon {
                background-position: -240px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.cancelbrokerageorders .icon {
                background-position: -320px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.dailyprices .icon {
                background-position: -160px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.profitslosscalculator .icon {
                background-position: -80px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.commissioncalculator .icon {
                background-position: -200px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.virtualportfolio .icon {
                background-position: -160px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.billpaymentfacility .icon {
                background-position: -40px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.payaperson .icon {
                background-position: -200px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.standingorderscreate .icon {
                background-position: -400px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.uploadtransactionfiles .icon {
                background-position: -200px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.offlinefileupload .icon {
                background-position: -200px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.downloadpaymentmessages .icon {
                background-position: -280px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.standingordersview .icon {
                background-position: -240px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.stoppayment .icon {
                background-position: -80px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.templatemanagement .icon {
                background-position: -200px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.orderforeigncash .icon {
                background-position: -280px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.orderbankdraft .icon {
                background-position: -40px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.stopcards .icon {
                background-position: -280px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.requestcardreplacement .icon {
                background-position: -160px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.increasecreditlimit .icon {
                background-position: -80px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.requestcardpin .icon {
                background-position: -80px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.changecarddetails .icon {
                background-position: -40px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.linkcashlinkcard .icon {
                background-position: -40px -240px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.registerformobilepay .icon {
                background-position: -80px -320px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.registerformobilebank .icon {
                background-position: -400px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.registerformobiletopup .icon {
                background-position: -80px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.topupmobile .icon {
                background-position: -280px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.changemobiletopupdetails .icon {
                background-position: -160px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.mobilepaysettings .icon {
                background-position: -240px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.managemobileservice .icon {
                background-position: -0px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.managemobilechannel .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.registermobile .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.browsesmsnotifications .icon {
                background-position: -400px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.accountsmsnotifications .icon {
                background-position: -240px -440px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.termssmsnotifications .icon {
                background-position: -320px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.depositsmsnotifications .icon {
                background-position: -360px -160px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.paymentssmsnotifications .icon {
                background-position: -280px -280px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.modifysmsnotifications .icon {
                background-position: -0px -400px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.disablesmsnotifications .icon {
                background-position: -200px -0px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.customerContactIcon .icon {
                background-position: -160px -80px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.contactDetailsDetailsIcon .icon {
                background-position: -200px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.accountsAddressIcon .icon {
                background-position: -280px -120px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.ImportantPhoneNumbersIcon .icon {
                background-position: -360px -40px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.accountAddressDetailsIcon .icon {
                background-position: -200px -200px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.requestcustomerservice .icon {
                background-position: -40px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.requestappointment .icon {
                background-position: -120px -360px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.wealthmanagement .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            #bov-menu-landingpage .landingpage_btn.x-btn-over.meetingappointment .icon {
                background-position: -120px -360px;
            }
            #landingpage-main-panel .landingpage_btn.x-btn-over.manageusers .icon {
                background-position: -0px -120px;
            }
            #landingpage-main-panel .landingpage_btn.x-btn-over.accountrights .icon {
                background-position: -360px -240px;
            }
            #landingpage-main-panel .landingpage_btn.x-btn-over.userrights .icon {
                background-position: -240px -360px;
            }
            #landingpage-main-panel .landingpage_btn.x-btn.managemycontactsforsmsalerts .icon {
                background-position: -200px -400px;
            }
            #landingpage-main-panel .landingpage_btn.x-btn.managesmsalerts .icon {
                background: transparent /*savepage-url=../images/menu/distributionpage/btn-icon-partner.png*/ url()
                    no-repeat 5px 12px;
            }
            .landingpage_btn > table {
                width: 100%;
            }
            #header-middle-ct {
                background-color: #fff;
                padding-right: 20px;
            }
            #mainmenu-ct .x-toolbar {
                margin: 0;
                padding: 0;
                border: none;
            }
            #mainmenu-ct .x-toolbar-ct,
            #mainmenu-ct .x-toolbar-left,
            #mainmenu-ct .x-toolbar-cell {
                height: 44px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active .x-btn-text {
                background-color: #ddd;
                color: #98266f;
            }
            #mainmenu-ct .x-link-btn .x-btn-text {
                height: 41px;
                line-height: 51px;
                padding-top: 16px;
                display: block;
                color: gray;
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 14px;
                font-weight: normal;
                text-decoration: none;
                outline: none;
                border: 1px solid #efefef;
                border-width: 1px 1px 0 0;
                background-color: #f7f6f6;
                background-size: auto 25px;
            }
            #mainmenu {
                height: 58px;
            }
            #mainmenu table table {
                width: 100%;
                table-layout: fixed;
            }
            #mainmenu td span.x-link-btn {
                display: block;
                height: 100%;
            }
            #mainmenu td span.x-btn-menu-active em {
                color: #98266f;
                background: #ddd;
            }
            #mainmenu td.x-toolbar-cell {
                height: 58px;
                text-align: center;
            }
            #mainmenu table tr.x-toolbar-left-row td:first-child a.x-btn-text {
                border-left: 1px solid #efefef;
            }
            #mainmenu table tr.x-toolbar-left-row td:first-child,
            #mainmenu table tr.x-toolbar-left-row td:last-child {
                position: relative;
            }
            #mainmenu table tr.x-toolbar-left-row td .corner {
                background:/*savepage-url=../images/menu/menu-bg-round.png*/ url() no-repeat left top;
                width: 10px;
                height: 10px;
                position: absolute;
                top: 0;
                display: none;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active .corner {
                background-image:/*savepage-url=../images/menu/menu-bg-round-act.png*/ url();
            }
            #mainmenu table tr.x-toolbar-left-row td:first-child .corner {
                left: 0;
                display: inline;
            }
            #mainmenu table tr.x-toolbar-left-row td:last-child .corner {
                right: 0;
                display: inline;
                background-position: right top;
            }
            .pegasus-menu .x-menu-list-item {
                padding: 0 15px;
                background-image: none;
                float: left;
            }
            .pegasus-menu .x-menu-item {
                padding: 1px 0 0 0;
            }
            .pegasus-menu .x-menu-list-item:first-child .x-menu-item {
                padding-top: 0;
                background: none #f3f3f3;
            }
            .pegasus-menu .x-menu-item-text {
                padding: 0 0 0 12px;
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 12px;
            }
            .pegasus-menu .x-menu-item,
            .pegasus-menu .x-menu-list-item,
            .pegasus-menu .x-menu-item-text,
            .pegasus-menu .x-menu-item-active,
            .pegasus-menu .x-menu-item-active .x-menu-item,
            .pegasus-menu .x-menu-item-active .x-menu-item-text {
                border: none;
            }
            #submenu-ct {
                overflow: hidden;
                border: 1px solid #efefef;
                border-width: 1px 0;
                height: 30px;
                background: #f7f6f6;
            }
            #submenu-ct .pegasus-menu {
                border-color: #babdb6;
            }
            #submenu-ct .pegasus-menu ul.x-menu-list,
            #submenu-ct .pegasus-menu li.x-menu-list-item {
                padding: 0;
                margin: 0;
                background: #f7f6f6;
            }
            #submenu-ct .pegasus-menu a.x-menu-item {
                margin: 0;
                padding: 0 10px;
                line-height: 30px;
                height: 30px;
                border: none;
                color: #98266f;
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 12px;
                font-weight: normal;
                text-decoration: none;
            }
            #submenu-ct .pegasus-menu .x-menu-item-active a.x-menu-item span,
            #submenu-ct .pegasus-menu a.x-menu-item.x-menu-item-selected {
                color: #98266f;
                cursor: pointer;
            }
            #submenu-ct .pegasus-menu a.x-menu-item.x-menu-item-selected {
                background: #ddd;
            }
            #submenu-ct .pegasus-menu .x-menu-item-text {
                padding: 0;
            }
            #submenu-ct .x-menu-item-icon {
                display: none;
            }
            #submenu-ct .pegasus-menu li.x-menu-item-active a.x-menu-item {
                background: #ddd;
            }
            #submenu-ct .pegasus-menu a.x-menu-item-arrow {
                margin-right: 6px;
            }
            #submenu-ct .pegasus-menu li.x-menu-item-active a.x-menu-item {
                color: #b7b7b7;
                margin: 0;
            }
            .x-item-disabled * {
                color: #7d827b !important;
            }
            .ext-ie #submenu-ct .x-menu {
                background-color: transparent;
            }
            #mainmenu-ct .x-link-btn .icon {
                display: block;
                background:/*savepage-url=../images/menu/icons/menu_icons_sprite.png*/ url() no-repeat;
                width: 30px;
                height: 30px;
                position: absolute;
                margin: 4px 41px;
            }
            #mainmenu-ct .x-link-btn.myportfolio .icon {
                background-position: -60px -0px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.myportfolio .icon {
                background-position: -0px -30px;
            }
            #mainmenu-ct .x-link-btn.mydeposit .icon {
                background-position: -0px -90px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.mydeposit .icon {
                background-position: -30px -30px;
            }
            #mainmenu-ct .x-link-btn.myborrowing .icon {
                background-position: -0px -60px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.myborrowing .icon {
                background-position: -30px -0px;
            }
            #mainmenu-ct .x-link-btn.mypayments .icon {
                background-position: -0px -0px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.mypayments .icon {
                background-position: -60px -60px;
            }
            #mainmenu-ct .x-link-btn.managemycards .icon {
                background-position: -60px -90px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.managemycards .icon {
                background-position: -60px -30px;
            }
            #mainmenu-ct .x-link-btn.mymobile .icon {
                background-position: -30px -90px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.mymobile .icon {
                background-position: -30px -60px;
            }
            #mainmenu-ct .x-link-btn.pfm .icon {
                background-position: -0px -90px;
            }
            #mainmenu-ct .x-link-btn.x-btn-menu-active.pfm .icon {
                background-position: -30px -30px;
            }
            .bov-window .x-panel-fbar {
                padding-left: 10px;
            }
            .bov-window.x-window-dlg .x-functionbox-body {
                width: auto !important;
            }
            .bov-window.x-window-dlg .x-functionbox-ml {
                padding: 15px;
            }
            .bov-window.x-window-dlg .x-functionbox-bl {
                padding-bottom: 15px;
            }
            .bov-window.x-window-dlg .x-functionbox-header {
                line-height: 21px;
                padding: 10px 0;
            }
            .bov-window.x-window-dlg .x-functionbox-bl .ib-btn-secondary {
                padding: 3px 0 0 6px;
            }
            .bov-window.x-window-dlg.info .x-functionbox-tl {
                padding-left: 60px;
                background: #363636 /*savepage-url=../images/icons/msg/icon_info.png*/ url() no-repeat 10px center;
            }
            .bov-window.x-window-dlg.warning .x-functionbox-tl {
                padding-left: 60px;
                background: #363636 /*savepage-url=../images/icons/msg/icon_warning.png*/ url() no-repeat 10px center;
            }
            .bov-window.x-window-dlg.question .x-functionbox-tl {
                padding-left: 60px;
                background: #363636 /*savepage-url=../images/icons/msg/icon_question.png*/ url() no-repeat 10px center;
            }
            .bov-window.x-window-dlg.error .x-functionbox-tl {
                padding-left: 60px;
                background: #363636 /*savepage-url=../images/icons/msg/icon_error.png*/ url() no-repeat 10px center;
            }
            .bov-window.x-window-dlg.logout .x-functionbox-tl {
                padding-left: 60px;
                background: #363636 /*savepage-url=../images/icons/msg/icon_logout.png*/ url() no-repeat 10px center;
            }
            .bov-msg-panel .msg-item-info,
            .bov-msg-panel .msg-item-warning,
            .bov-msg-panel .msg-item-error {
                color: #545454;
                margin-bottom: 10px;
            }
            .bov-msg-panel .msg-item-success {
                color: #008000;
            }
            .msg-item-info,
            .msg-item-warning,
            .msg-item-error,
            .msg-item-success {
                font-size: 12px;
                font-family: sans-serif;
                font-weight: normal;
            }
            .msg-title-info,
            .msg-title-warning,
            .msg-title-error,
            .msg-title-success {
                font-weight: bold !important;
                vertical-align: middle !important;
            }
            .bov-msg-panel .msg-icon-info,
            .bov-msg-panel .msg-icon-warning,
            .bov-msg-panel .msg-icon-error,
            .bov-msg-panel .msg-icon-success {
                height: 36px;
                padding-right: 10px;
                width: 36px;
            }
            .bov-msg-panel .msg-icon-info {
                background:/*savepage-url=../images/icons/msg/icon_info_inform.png*/ url() no-repeat scroll 0 0
                    transparent;
            }
            .bov-msg-panel .msg-icon-warning {
                background:/*savepage-url=../images/icons/msg/icon_warning_inform.png*/ url() no-repeat scroll 0 0
                    transparent;
            }
            .bov-msg-panel .msg-icon-error {
                background:/*savepage-url=../images/icons/msg/icon_error_inform.png*/ url() no-repeat scroll 0 0
                    transparent;
            }
            .bov-msg-panel .msg-icon-success {
                background:/*savepage-url=../images/icons/msg/icon_success_inform.png*/ url() no-repeat scroll 0 0
                    transparent;
            }
            .x-ibtable-panel .x-grid-group-hd,
            .x-ibtable-panel .x-grid-group-hd-nocollapse,
            .x-bubblegrid-panel .x-grid-group-hd,
            .x-bubblegrid-panel .x-grid-group-hd-nocollapse {
                border-bottom: 0;
                border-bottom: 0;
                background-color: #fff;
                padding-top: 3px;
            }
            .x-ibtable-panel .x-grid-group-hd div.x-grid-group-title,
            .x-ibtable-panel .x-grid-group-hd-nocollapse div.x-grid-group-title,
            .x-bubblegrid-panel .x-grid-group-hd div.x-grid-group-title,
            .x-bubblegrid-panel .x-grid-group-hd-nocollapse div.x-grid-group-title {
                background-image: none;
                background-color: #fff;
                color: #363636;
                font-size: 14px;
            }
            .x-ibtable-panel .x-grid-group-hd-nocollapse div.x-grid-group-title,
            .x-bubblegrid-panel .x-grid-group-hd-nocollapse div.x-grid-group-title {
                background-image: none;
                padding: 4px 4px 4px 17px;
            }
            .x-ibtable-panel .x-grid-group-collapsed .x-grid-group-hd div.x-grid-group-title,
            .x-bubblegrid-panel .x-grid-group-collapsed .x-grid-group-hd div.x-grid-group-title {
                background-image:/*savepage-url=../images/grid/group-expand.gif*/ url();
            }
            .x-grid3-row.x-bubble .x-grid3-row-body {
                background-color: #ececec;
                border-left-color: #fff;
                border-right-color: #fff;
            }
            .x-grid3-row.x-bubble {
                border-width: 0;
            }
            .ext-safari .x-grid3-row.x-grid3-row-expanded .expander {
                width: 684px;
            }
            .bov-paging-gridpanel {
                margin: 30px 0 0;
            }
            .bov-window .x-grid-panel {
                margin: 30px 0 20px;
            }
            .bov-window .x-grid-panel .x-grid3-header .x-grid3-hd-row td {
                overflow: hidden;
            }
            .bov-window .x-grid-panel .x-grid3-row,
            .bov-window .x-grid-panel .x-grid3-row-over {
                border-width: 0 1px;
            }
            .bov-window
                .x-grid-panel
                .x-grid3-header
                td.x-grid3-row
                .bov-window
                .x-grid-panel
                .x-grid3-header
                .x-grid3-hd-row
                td {
                border-width: 0 1px;
            }
            .bov-gridpanel .x-grid3-header {
                background-image:/*savepage-url=../images/grid/longlist-hrow.png*/ url();
                background-color: #333;
                background-position: 0 top;
            }
            .bov-gridpanel td.x-grid3-cell {
                height: 30px;
                vertical-align: middle;
            }
            .bov-gridpanel .x-grid3-row,
            .bov-gridpanel .x-grid3-hd-row td {
                border-left: 0 none;
            }
            .bov-gridpanel .x-grid3-row {
                border-right: 0 none;
            }
            .bov-gridpanel .x-grid3-row {
                width: 100% !important;
            }
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-cell-last {
                border: 0 none;
            }
            .bov-gridpanel .x-grid3-hd-inner {
                color: #fff;
                font-weight: bold;
                padding: 4px 3px 4px 7px;
            }
            .ext-chrome .bov-gridpanel .x-grid3-hd-inner {
                padding-left: 5px;
            }
            .bov-gridpanel .x-grid3-hd-inner span {
                margin-right: 3px;
            }
            .bov-gridpanel .x-grid3-hd-inner .header-label {
                overflow: hidden;
                text-overflow: ellipsis;
                text-align: center;
                display: inline-block;
                width: 100%;
            }
            .bov-gridpanel .x-grid3-hd-inner .header-label span {
                font-weight: bold;
            }
            .bov-gridpanel .x-grid3-hd-inner .info-bubble-icon {
                float: left;
            }
            .bov-gridpanel .x-grid3-cell.x-grid3-td-checker,
            .bov-gridpanel .x-grid3-body .x-grid3-row .x-grid3-cell.x-grid3-td-checker {
                padding: 0 1px;
            }
            .bov-gridpanel .x-grid3-hd .x-grid3-hd-inner td {
                border-width: 0;
            }
            .bov-gridpanel .x-grid3-hd .x-grid3-hd-inner td {
                border-width: 0;
            }
            .bov-gridpanel .x-grid3-hd-inner.x-grid3-hd-checker span {
                margin: 0;
            }
            .x-grid3-cell-inner.wrapped,
            .x-grid3-hd-inner.wrapped {
                white-space: normal;
                height: auto;
            }
            .bov-gridpanel .x-grid3-body .x-grid3-row td {
                padding: 0 1px;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-account_icon {
                line-height: 18px;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-account_icon .account-avatar-ct,
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-card_type .card-avatar-ct {
                float: left;
                padding-right: 10px;
                text-align: center;
                width: 50px;
                height: 18px;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-account_icon .account-avatar-ct {
                width: 18px;
            }
            .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            .bov-gridpanel .dailyprices .x-grid3-hd-inner {
                font-size: 12px;
            }
            .bov-gridpanel .x-grid3-hd-inner a {
                color: #fff;
            }
            .bov-gridpanel .x-grid3-hd-row img {
                background-repeat: no-repeat;
                background-position: right top;
                padding-left: 4px;
                vertical-align: middle;
                margin-left: 0;
            }
            .bov-gridpanel .x-grid3-hd-row .maintd img {
                height: 7px;
            }
            .bov-gridpanel .x-grid3-hd-row .sort-asc .x-grid3-sort-icon {
                background-image:/*savepage-url=../images/grid/sort/sort_asc.png*/ url();
                padding-bottom: 5px;
            }
            .bov-gridpanel .x-grid3-hd-row .sort-desc .x-grid3-sort-icon {
                background-image:/*savepage-url=../images/grid/sort/sort_desc.png*/ url();
                padding-bottom: 5px;
            }
            .bov-gridpanel .x-grid3-hd-row .unsorted .x-grid3-sort-icon {
                display: inline;
                background-image:/*savepage-url=../images/grid/sort/unsort.png*/ url();
                padding-bottom: 5px;
            }
            .bov-gridpanel .x-panel-mc {
                background-color: #404040;
                color: #fff;
            }
            .bov-gridpanel .x-panel-tl {
                border: 0 none;
            }
            .bov-gridpanel .x-panel-tbar .x-form-text {
                border-color: #d5d5d5;
                height: 25px !important;
                padding-top: 0;
            }
            .ext-chrome .bov-gridpanel .x-panel-tbar .x-form-text {
                padding-bottom: 0;
            }
            .bov-gridpanel .x-panel-bbar .x-toolbar,
            .bov-gridpanel .x-panel-tbar .x-toolbar {
                padding: 0;
            }
            .bov-gridpanel .x-panel-tbar-noheader .x-toolbar,
            .bov-gridpanel .x-panel-mc .x-panel-tbar .x-toolbar,
            .bov-gridpanel .x-panel-mc .x-panel-body,
            .bov-gridpanel .x-panel-bbar .x-toolbar,
            .bov-gridpanel .x-panel-tbar .x-toolbar {
                border: 0 none;
            }
            .bov-gridpanel .x-panel-ml,
            .bov-gridpanel .x-panel-mr,
            .bov-gridpanel .x-panel-mc {
                padding: 0;
                margin: 0;
            }
            .bov-gridpanel .x-grid3-row,
            .bov-gridpanel .x-grid3-row-selected {
                background-color: #f8f8f8 !important;
                border-color: #f8f8f8 !important;
            }
            .bov-gridpanel .x-grid3-row-alt,
            .bov-gridpanel .x-grid3-row-selected.x-grid3-row-alt {
                background-color: #e8e8e8 !important;
                border-color: #e8e8e8 !important;
            }
            .bov-gridpanel .x-grid3-row-over,
            .bov-gridpanel .x-grid3-row-over.x-grid3-row-alt,
            .bov-gridpanel .x-grid3-row-over.x-grid3-row-expanded.x-grid3-row-selected {
                background-color: #dce6f2 !important;
                border-color: #dce6f2 !important;
                background-image: none;
            }
            .bov-gridpanel .x-grid3-row-selected.x-grid3-row-expanded {
                background-color: #ececec !important;
                color: #363636;
            }
            .bov-gridpanel .x-toolbar-ct {
                height: 23px;
            }
            .bov-gridpanel .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first.png*/ url() !important;
            }
            .bov-gridpanel .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev.png*/ url() !important;
            }
            .bov-gridpanel .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next.png*/ url() !important;
            }
            .bov-gridpanel .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last.png*/ url() !important;
            }
            .bov-gridpanel .x-btn-over .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first-dn.png*/ url() !important;
            }
            .bov-gridpanel .x-btn-over .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev-dn.png*/ url() !important;
            }
            .bov-gridpanel .x-btn-over .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next-dn.png*/ url() !important;
            }
            .bov-gridpanel .x-btn-over .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last-dn.png*/ url() !important;
            }
            .bov-gridpanel .x-btn-icon.x-btn-over {
                background-color: transparent;
            }
            .bov-gridpanel .x-panel-bl {
                display: none;
            }
            .bov-gridpanel .x-toolbar div.xtb-text {
                padding: 0 4px;
            }
            .bov-gridpanel .x-grid3-row-table * {
                color: #2c2c2c;
                word-wrap: break-word;
            }
            .bov-gridpanel .x-grid3-row-table a {
                color: #840b55;
            }
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell-inner a {
                color: #98266f;
                text-decoration: underline;
            }
            .bov-gridpanel .x-grid3-body {
                width: 100% !important;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-checker,
            .bov-gridpanel .x-grid3-hd-inner.x-grid3-hd-checker {
                height: auto !important;
            }
            .bov-gridpanel .x-grid3-body .x-grid3-td-checker {
                background-image: none;
            }
            .bov-gridpanel .x-grid3-scroller {
                overflow: hidden;
            }
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd.sort-asc,
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd.sort-desc,
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd.unsorted,
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd .sort-asc,
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd .sort-desc,
            .bov-gridpanel .x-grid3-hd-row td.x-grid3-hd .unsorted {
                border-color: #d0d0d0;
            }
            .x-bubble .bov-gridpanel .x-grid3-cell-inner {
                background: transparent;
                height: 13px;
                padding-top: 3px;
            }
            .x-grid-panel .x-panel-bbar .x-btn-tl,
            .x-grid-panel .x-panel-bbar .x-btn-tr,
            .x-grid-panel .x-panel-bbar .x-btn-tc,
            .x-grid-panel .x-panel-bbar .x-btn-ml,
            .x-grid-panel .x-panel-bbar .x-btn-mr,
            .x-grid-panel .x-panel-bbar .x-btn-mc,
            .x-grid-panel .x-panel-bbar .x-btn-bl,
            .x-grid-panel .x-panel-bbar .x-btn-br,
            .x-grid-panel .x-panel-bbar .x-btn-bc {
                background-image: none !important;
            }
            .x-grid3-row-checker,
            .x-grid3-hd-checker {
                background-image:/*savepage-url=../images/grid/row-check-sprite.gif*/ url() !important;
                background-repeat: no-repeat;
            }
            .x-grid3-hd-checker.x-grid3-hd-checker-on {
                background-position: -23px 2px;
            }
            .x-grid3-row-checkercolumn {
                background-image:/*savepage-url=../images/default/form/checkbox.gif*/ url() !important;
            }
            .x-grid3-row-radiocolumn {
                background-image:/*savepage-url=../images/default/form/radio.gif*/ url() !important;
            }
            .bov-gridpanel .x-grid3-body.review .x-grid3-row-checkercolumn {
                background-image:/*savepage-url=../images/default/form/checkbox-review.gif*/ url() !important;
            }
            .bov-gridpanel .x-grid3-body.review .x-grid3-row-radiocolumn {
                background-image:/*savepage-url=../images/default/form/radio-review.gif*/ url() !important;
            }
            .x-grid3-row-radiocolumn,
            .x-grid3-row-checkercolumn {
                background-repeat: no-repeat;
                width: 13px;
                height: 13px;
                margin: 0 auto;
                background-position: 0 0;
            }
            .x-grid3-row-radiocolumn.disabled,
            .x-grid3-row-checkercolumn.disabled {
                background-position: -39px 0;
            }
            .x-grid3-row-radiocolumn.x-grid3-checker-on,
            .x-grid3-row-checkercolumn.x-grid3-checker-on {
                background-position: 0 -13px;
            }
            .x-grid3-row-radiocolumn.x-grid3-checker-on.disabled,
            .x-grid3-row-checkercolumn.x-grid3-checker-on.disabled {
                background-position: -39px -13px;
            }
            .x-grid3-cell.with-qtip .x-grid3-cell-inner {
                color: #550337;
            }
            .listview-accountlist .x-grid3-row-alt {
                background-color: #ececec;
            }
            .listview-accountlist .x-grid3-row-selected {
                background-color: #e5e5e5;
            }
            .listview-accountlist .x-grid3-row-over {
                background-color: #dbdbdb;
                background-image: none;
            }
            .listview-accountlist .x-grid3-row-selected.x-grid3-row-over {
                background-image:/*savepage-url=../images/default/icon/icon_ok.png*/ url();
            }
            .listview-accountlist .x-grid3-row {
                border-width: 0;
                cursor: pointer;
            }
            .listview-accountlist .x-grid3-scroller {
                overflow: hidden;
            }
            .listview-accountlist .bov-accordion-panel .x-panel {
                margin-top: 0;
            }
            .listview-accountlist .x-panel {
                border: 0 none;
            }
            .ext-ie .scopebar-frame .x-toolbar-cell .x-form-field-wrap {
                height: auto;
            }
            .bov-gridpanel .scopebar-frame {
                width: 100%;
                background: #fff;
            }
            .scopebar-frame .tc,
            .scopebar-frame .ml,
            .scopebar-frame .mc,
            .scopebar-frame .mr,
            .scopebar-frame .bl,
            .scopebar-frame .bc,
            .scopebar-frame .br {
                background: #404040;
            }
            .scopebar-frame .tl,
            .scopebar-frame .tr {
                background: #404040;
            }
            .scopebar-frame .tl {
                background-position: 0 0;
            }
            .scopebar-frame .tr {
                background-position: -8px 0;
            }
            .scopebar-frame .tl,
            .scopebar-frame .tr,
            .scopebar-frame .bl,
            .scopebar-frame .br {
                width: 8px;
                height: 3px;
            }
            .scopebar-frame .bl,
            .scopebar-frame .br {
                width: 8px;
                height: 3px;
            }
            .bov-gridpanel .bov-scopebar.x-toolbar.x-small-editor {
                padding: 0;
            }
            .bov-gridpanel .bov-scopebar.x-toolbar.x-small-editor input {
                height: 24px !important;
                line-height: 24px;
                padding-bottom: 0;
                padding-top: 0;
            }
            .bov-gridpanel .bov-scopebar .x-form-trigger {
                height: 26px;
                background-image:/*savepage-url=../images/default/form/trigger26px.gif*/ url();
                border-bottom: none;
            }
            .bov-gridpanel .x-grid3-cell-inner .x-grid3-row-expander {
                background-color: transparent !important;
                background-image: none !important;
            }
            .bov-gridpanel .x-grid3-row.x-grid3-row-collapsed .x-grid3-cell.x-grid3-td-expander {
                background-image:/*savepage-url=../images/grid/details_closed.png*/ url();
                background-repeat: no-repeat;
                background-position: center center;
            }
            .bov-gridpanel .x-grid3-row.x-grid3-row-expanded .x-grid3-cell.x-grid3-td-expander {
                background-image:/*savepage-url=../images/grid/details_opened.png*/ url();
                background-repeat: no-repeat;
                background-position: center center;
            }
            .bov-gridpanel .x-panel-tl,
            .bov-gridpanel .x-panel-tr,
            .bov-gridpanel .x-panel-tc {
                padding: 0;
                background: none transparent;
            }
            .bov-gridpanel .x-panel-header {
                background: none repeat scroll 0 0 #545454;
                color: #fff;
                font-size: 14px;
                font-weight: bold;
                padding: 10px;
            }
            .x-panel-noborder .x-panel-header-noborder {
                border: none;
            }
            .bov-gridpanel .x-grid3-body.review .x-grid3-row,
            .bov-gridpanel .x-grid3-body.review tr,
            .bov-gridpanel .x-grid3-body.review td,
            .bov-gridpanel .x-grid3-body.review td {
                background-color: #ececec !important;
                color: #363636;
            }
            .bov-gridpanel .x-grid3-body.review td.x-grid3-cell.x-grid3-td-expander {
                background-color: transparent;
            }
            .bov-gridpanel .x-grid3-body.review .x-grid3-row {
                border-color: #ececec !important;
                border-top-color: #bababa !important;
                border-width: 1px 0;
                border-style: solid;
            }
            .bov-gridpanel .x-grid3-body.review .x-grid3-row-checker,
            .bov-gridpanel .x-grid3-body.review .x-grid3-hd-checker {
                background-image:/*savepage-url=../images/grid/row-check-sprite-disabled.gif*/ url() !important;
            }
            .bov-gridpanel .pagingtoolbar-frame {
                width: 100%;
                background: #fff;
            }
            .pagingtoolbar-frame .x-btn-tl,
            .pagingtoolbar-frame .x-btn-tr,
            .pagingtoolbar-frame .x-btn-tc,
            .pagingtoolbar-frame .x-btn-ml,
            .pagingtoolbar-frame .x-btn-mr,
            .pagingtoolbar-frame .x-btn-mc {
                height: 3px;
            }
            .pagingtoolbar-frame .x-btn-bl,
            .pagingtoolbar-frame .x-btn-br,
            .pagingtoolbar-frame .x-btn-bc {
                height: 2px;
            }
            .pagingtoolbar-frame .tl,
            .pagingtoolbar-frame .tc,
            .pagingtoolbar-frame .tr,
            .pagingtoolbar-frame .ml,
            .pagingtoolbar-frame .mc,
            .pagingtoolbar-frame .mr,
            .pagingtoolbar-frame .bc {
                background: #404040;
            }
            .pagingtoolbar-frame .bl,
            .pagingtoolbar-frame .br {
                background: #404040;
            }
            .pagingtoolbar-frame .bl {
                background-position: 0 -3px;
            }
            .pagingtoolbar-frame .br {
                background-position: -8px -3px;
            }
            .pagingtoolbar-frame .tl,
            .pagingtoolbar-frame .tr,
            .pagingtoolbar-frame .bl,
            .pagingtoolbar-frame .br {
                width: 8px;
                height: 3px;
            }
            .x-grid3-row.x-grid3-row-expanded .expander {
                padding: 10px;
            }
            .x-grid3-row.x-grid3-row-expanded .expander .x-form-item {
                border-bottom: 2px dotted white;
                margin-bottom: 0;
            }
            .x-grid3-row.x-grid3-row-expanded .expander .x-form-item-label {
                text-align: right;
            }
            .x-grid3-row.x-grid3-row-expanded .expander .x-btn.x-btn-noicon {
                float: right;
                padding: 10px 0 0 12px;
            }
            .x-grid3-row.x-grid3-row-expanded .expander .x-btn.x-btn-noicon {
                float: right;
                padding: 10px 0 0 12px;
            }
            .x-grid3 .x-grid3-hd-row .x-grid3-cell.x-grid3-td-detailsarrow.x-grid3-cell-first {
                border-right: medium none;
                padding-right: 1px;
            }
            .x-grid3-row.x-grid3-row-expanded .expander.review .ib-btn-secondary {
                display: none;
            }
            .x-grid3-row .x-grid3-cell-inner .x-form-item {
                border-bottom: none;
            }
            .x-button-col-cell .x-grid3-cell-inner > span {
                display: block;
                float: left;
                margin-right: 5px;
            }
            .x-form-item-label,
            .x-form-display-field {
                user-select: text;
                -o-user-select: text;
                -ms-user-select: text;
                -moz-user-select: text;
                -webkit-user-select: text;
                cursor: text;
            }
            .x-grid3-col.x-grid3-cell .x-unselectable input {
                user-select: all;
                -o-user-select: all;
                -ms-user-select: text;
                -moz-user-select: all;
                -webkit-user-select: auto;
            }
            .x-grid3-col.x-grid3-cell .x-unselectable input.x-unselectable {
                user-select: none;
                -o-user-select: none;
                -ms-user-select: none;
                -moz-user-select: -moz-none;
                -webkit-user-select: none;
                cursor: default;
            }
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell.contentwrap-enabled {
                height: auto;
            }
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell.contentwrap-enabled div {
                height: auto;
                overflow: visible;
                text-overflow: normal;
                white-space: normal;
            }
            .x-grid3-cell-inner,
            .x-grid3-hd-inner {
                padding-left: 9px;
            }
            .header-label .x-grid3-hd-checker {
                display: none;
            }
            .ext-ie8 .bov-gridpanel .x-grid3-row-table * {
                word-wrap: normal;
            }
            .ext-ie9 .bov-gridpanel .x-grid3-row-table * {
                word-wrap: normal;
            }
            .ext-ie10 .bov-gridpanel .x-grid3-row-table * {
                word-wrap: normal;
            }
            .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 30px;
            }
            .bov-gridpanel .bov-cardtype-column > div,
            .bov-gridpanel .bov-accounttype-column > div {
                position: relative;
            }
            .bov-gridpanel .bov-cardtype-column > div {
                padding-left: 64px;
            }
            .bov-gridpanel .bov-accounttype-column > div {
                padding-left: 30px;
            }
            .bov-gridpanel .bov-cardtype-column .card-avatar-ct,
            .bov-gridpanel .bov-accounttype-column .account-avatar-ct {
                position: absolute;
                left: 6px;
                top: 0;
            }
            #changecustomerdetails-accountgrid .x-grid3-cell-inner,
            .x-grid3-hd-inner {
                padding-left: 0;
            }
            div.ib-function-relative {
                position: relative;
            }
            div.ib-function-relative div.ib-printoutlink-ct {
                position: absolute;
                top: 4px;
                right: 4px;
            }
            .x-panel .ext-el-mask {
                background-color: #fff;
            }
            .ext-ie .x-panel .ext-el-mask {
                opacity: 0.2;
            }
            fieldset .ext-el-mask {
                background-color: #ececec !important;
            }
            .x-panel,
            .x-panel-body {
                border: none;
            }
            .x-panel-body {
                background-color: transparent;
                overflow: visible;
            }
            .x-preferncesbox {
                background: #fff;
            }
            .x-preferncesbox-header {
                border: 0;
                color: #940c61;
                font-size: 18px;
                font-weight: bold;
                padding: 0;
                margin: 4px 0 5px;
            }
            .x-preferences-panel {
                background-color: #ececec;
                border: 1px solid grey;
                border-radius: 5px 5px 15px 0;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif !important;
                font-size: 12px;
            }
            .x-preferences-panel-header {
                background-color: #545454;
                height: 20px;
                padding: 5px;
                color: white;
                font-size: 14px;
                font-weight: bold;
            }
            .x-preferences-panel-body {
                padding: 10px;
                line-height: 16px;
            }
            .x-preferences-link {
                background-image:/*savepage-url=../images/preferencesbox/preferencesbox-linkbg.png*/ url() !important;
                background-repeat: no-repeat;
                padding-left: 20px;
            }
            .x-preferences-messagepanel-no-icon {
                height: auto !important;
                height: 60px;
                min-height: 60px;
                background: transparent /*savepage-url=../images/icons/icon_big_information.png*/ url() no-repeat top
                    left;
                padding-left: 60px;
                font-size: 12px;
            }
            .x-preferences-messagepanel-success-icon {
                height: auto !important;
                height: 60px;
                min-height: 60px;
                background: transparent /*savepage-url=../images/icons/icon-succ-big.png*/ url() no-repeat top left;
                padding-left: 60px;
                font-size: 12px;
            }
            .x-preferences-error {
                color: #d92d1a;
            }
            .x-preferences-warning {
                color: #d92d1a;
            }
            .x-preferences-result {
                color: #146f22;
            }
            .x-preferences-blue-link {
                background-repeat: no-repeat;
                color: blue;
                text-decoration: underline;
            }
            .x-preferences-blue-link:hover {
                text-decoration: underline;
                cursor: pointer;
            }
            #awa-overlay {
                z-index: 10000 !important;
            }
            .x-functionbox {
                margin-bottom: 10px;
                background: #fff;
            }
            .x-functionbox-header,
            .x-toolbar.x-functionbox-header div.xtb-text {
                border: 0;
                color: #940c61;
                font-size: 18px;
                font-weight: bold;
                padding: 0;
                margin-bottom: 10px;
            }
            .x-functionbox-header p.panel-subtitle {
                color: #545454;
                margin-top: 7px;
            }
            .x-functionbox-header {
                padding-left: 4px;
            }
            .bov-window .x-functionbox-header-text,
            .bov-window p.panel-subtitle {
                color: #fcfcfb;
            }
            .bov-window .x-functionbox-header p.panel-subtitle {
                padding: 20px 0;
                color: #2c2c2c;
                margin-top: 7px;
            }
            .bov-window .x-panel-footer {
                padding: 10px 0 0 0;
            }
            .x-functionbox-header {
                margin: 3px 0 34px;
            }
            .x-functionbox-header.with-subtitle {
                margin-bottom: 13px;
            }
            .x-toolbar.x-functionbox-header {
                margin: 3px 0 13px;
            }
            .x-functionbox-bwrap {
                padding: 0;
            }
            .x-functionbox-header .x-tool {
                margin-top: 5px;
            }
            .x-functionbox-body,
            .x-tab-panel-body {
                height: auto !important;
            }
            .x-functionbox .x-functionbox-bbar {
                margin-top: 15px;
                width: auto !important;
                border: 0;
            }
            .x-functionbox .x-functionbox-bbar .ibdemo-link {
                margin: 0 10px;
            }
            .bov-window {
                padding: 0;
                position: fixed !important;
            }
            .bov-window .x-functionbox-header {
                line-height: 40px;
            }
            .bov-window .x-functionbox-body.x-functionbox-body-noborder {
                width: auto !important;
            }
            .bov-window .x-functionbox-header,
            .bov-window .x-toolbar.x-functionbox-header {
                margin: 0;
            }
            .bov-window .x-functionbox-ml,
            .bov-window .x-functionbox-bl {
                padding: 16px 10px 10px;
            }
            .bov-window .x-functionbox-bl.x-panel-nofooter {
                padding: 0;
            }
            .bov-window .x-functionbox-tl {
                background-color: #363636;
                border: 1px solid #fff;
                padding: 12px 10px;
            }
            .bov-window.warning .x-functionbox-tl {
                padding-left: 58px;
                background:/*savepage-url=../images/default/panel/msg-warning-icon.png*/ url() no-repeat 10px center
                    #363636;
            }
            .bov-window.success .x-functionbox-tl {
                padding-left: 58px;
                background:/*savepage-url=../images/default/panel/msg-success-icon.png*/ url() no-repeat 10px center
                    #363636;
            }
            .bov-window .x-functionbox-bl .x-panel-btns {
                padding: 0;
            }
            .bov-window .x-functionbox-header,
            .bov-window .x-tool-close {
                margin-top: 0;
                margin-right: 0;
            }
            .bov-window .x-tool-close {
                width: 22px;
                height: 22px;
                position: absolute;
                top: -11px;
                right: -11px;
                background-image:/*savepage-url=../images/default/panel/popup-close.png*/ url();
                z-index: 11;
            }
            .bov-window .x-tool-close-over {
                background-position: 0 0;
            }
            .bov-window .bov-info-panel {
                background: none;
                padding-left: 0;
            }
            .bov-window.longlist .x-functionbox-tl {
                padding: 0;
                border: medium none;
            }
            .bov-window.longlist.longlist .x-functionbox-ml,
            .bov-window .x-functionbox-bl {
                padding: 0;
            }
            .bov-window.longlist .x-functionbox-ml .bov-gridpanel {
                margin: 0;
            }
            .bov-window.longlist .x-functionbox-ml .bov-gridpanel {
                margin: 0;
            }
            .bov-window.longlist.multi {
                padding: 8px;
            }
            .bov-window.longlist.multi .foot-container .x-btn {
                float: right;
                margin-left: 12px;
                margin-top: 28px;
            }
            .multiselectorinfo .selinfo,
            .bov-window.longlist.multi .foot-container .selinfo {
                padding: 4px 10px 0 12px;
                float: left;
            }
            .multiselectorinfo .info-linkbtn,
            .bov-window.longlist.multi .foot-container .info-linkbtn {
                line-height: 24px;
            }
            .bov-window.longlist.multi .foot-container .selinfo,
            .bov-window.longlist.multi .foot-container .info-linkbtn {
                margin-top: 33px;
                float: right;
            }
            .x-bubble {
                background-color: #ececec;
            }
            .x-bubble-ml {
                padding-left: 4px;
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y 0 0;
            }
            .x-bubble-mr {
                padding-right: 4px;
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y right 0;
            }
            .x-bubble-mc {
                background: #ececec;
                overflow: hidden;
            }
            .x-bubble-body-noborder {
                border-width: 0;
            }
            .x-bubble .x-bubble-header-noborder {
                background: #ececec none;
            }
            .x-bubble.x-panel-collapsed .x-bubble-header-noborder {
                background-color: transparent;
            }
            .x-bubble-tl {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat 0 0;
                padding-left: 11px !important;
            }
            .x-bubble-tr {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat right top;
                padding-right: 11px !important;
            }
            .x-bubble-tc {
                overflow: hidden;
                padding-top: 4px;
                background: #ececec /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 0;
            }
            .x-bubble-bl {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat 0 bottom;
                padding-left: 11px;
            }
            .x-bubble-br {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat right bottom;
                padding-right: 11px;
            }
            .x-bubble-bc {
                height: 4px;
                font-size: 1px;
                line-height: 1px;
                overflow: hidden;
                background: #ececec /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 bottom;
            }
            .x-bubble {
                margin: 5px 0;
            }
            .x-bubble-bwrap {
                overflow: hidden;
            }
            .x-bubble-body {
                background: #ececec;
                overflow: hidden;
            }
            .x-bubble-header {
                font-size: 12px;
                font-weight: normal;
                line-height: normal;
                padding: 3px 0;
                min-height: 0;
                background-color: #ececec;
                background-image: none;
            }
            .x-panel-collapsed .x-bubble-ml,
            .x-panel-collapsed .x-bubble-mr {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-lr.gif*/ url();
            }
            .x-panel-collapsed .x-bubble-bl,
            .x-panel-collapsed .x-bubble-br,
            .x-panel-collapsed .x-bubble-tr,
            .x-panel-collapsed .x-bubble-tl {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-cs.gif*/ url();
            }
            .x-panel-collapsed .x-bubble-bc,
            .x-panel-collapsed .x-bubble-bwrap,
            .x-panel-collapsed .x-bubble-tc {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-tb.gif*/ url();
            }
            .x-panel-collapsed .x-bubble-header {
                background-color: transparent;
            }
            .sidebar-contextual .x-panel-collapsed .x-bubble-bl,
            .sidebar-contextual .x-panel-collapsed .x-bubble-br,
            .sidebar-contextual .x-panel-collapsed .x-bubble-tr,
            .sidebar-contextual .x-panel-collapsed .x-bubble-tl {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-cs.gif*/ url();
            }
            .sidebar-contextual .x-panel-collapsed .x-bubble-bc,
            .sidebar-contextual .x-panel-collapsed .x-bubble-bwrap,
            .sidebar-contextual .x-panel-collapsed .x-bubble-tc {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-tb.gif*/ url();
            }
            .sidebar-contextual .x-bubble-header-text {
                font-weight: bold;
            }
            .sidebar-contextual .x-bubble-header {
                padding: 8px 0;
            }
            .sidebar-contextual .x-bubble-tl {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat 0 0;
            }
            .sidebar-contextual .x-bubble-tr {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat right top;
            }
            .sidebar-contextual .x-bubble-tc {
                background: #ececec /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 0;
            }
            .sidebar-contextual .x-bubble-bl {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat 0 bottom;
            }
            .sidebar-contextual .x-bubble-br {
                background: #ececec /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat right bottom;
            }
            .sidebar-contextual .x-bubble-bc {
                background: #ececec /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 bottom;
            }
            .sidebar-contextual .x-bubble-ml {
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y 0 0;
            }
            .sidebar-contextual .x-bubble-mr {
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y right 0;
            }
            .x-grid3-col .x-bubble-tr,
            .x-grid3-col .x-bubble-tl {
                padding: 0 !important;
            }
            .x-grid3-cell-first .x-bubble-tl {
                padding-left: 3px !important;
            }
            .x-grid3-cell-last .x-bubble-tr {
                padding-right: 3px !important;
            }
            .x-grid3-row-collapsed .x-bubble-ml,
            .x-grid3-row-collapsed .x-bubble-mr {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-lr.gif*/ url();
            }
            .x-grid3-row-collapsed .x-bubble-bl,
            .x-grid3-row-collapsed .x-bubble-br,
            .x-grid3-row-collapsed .x-bubble-tr,
            .x-grid3-row-collapsed .x-bubble-tl {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-cs.gif*/ url();
            }
            .x-grid3-row-collapsed .x-bubble-bc,
            .x-grid3-row-collapsed .x-bubble-bwrap,
            .x-grid3-row-collapsed .x-bubble-tc,
            .x-grid3-row-collapsed.x-bubble .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-tb.gif*/ url();
                color: #363636;
                font-size: 14px;
            }
            .x-bubble .x-grid3-cell-inner {
                background: #ececec /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 0;
                height: 26px;
                padding-top: 7px;
            }
            .x-bubblegrid-panel td.x-grid3-body-cell {
                border-left: 1px solid #ccc;
                border-right: 1px solid #ccc;
                padding: 0;
            }
            .x-bubblegrid-panel .x-grid3-row-body {
                border-left: 1px solid #fff;
                border-right: 1px solid #fff;
            }
            .x-bubblegrid-panel .x-grid-group-title {
                color: #363636;
                font-size: 14px;
            }
            .x-bubble-header .avatar {
                float: left;
                position: absolute;
                width: 30px;
                padding-left: 4px;
                padding-right: 4px;
            }
            .x-bubble-header .title {
                left: 50px;
                font-weight: bold;
                padding-left: 10px;
                position: absolute;
            }
            .x-bubble-header .type {
                text-align: center;
                width: 100%;
            }
            .x-bubble-header .amount {
                font-weight: bold;
                text-align: right;
                position: absolute;
                right: 20px;
            }
            .bov-tabpanel .x-tab-panel-body {
                border-color: #cbcbcb;
                border-width: 0 1px 1px;
            }
            .bov-tabpanel ul.x-tab-strip li {
                margin-left: 0 !important;
            }
            .bov-tabpanel ul.x-tab-strip {
                border-bottom: 1px solid #cbcbcb;
                background: transparent none;
            }
            .bov-tabpanel .x-tab-strip span.x-tab-strip-text {
                font-family: inherit;
            }
            .bov-tabpanel .x-tab-panel-header {
                border-width: 0;
                background-color: transparent;
                padding-bottom: 0;
            }
            .bov-tabpanel .x-tab-strip-top .x-tab-right,
            .bov-tabpanel .x-tab-strip-top .x-tab-left,
            .bov-tabpanel .x-tab-strip-top .x-tab-strip-inner {
                background-image:/*savepage-url=../images/tabs/tabs-sprite.gif*/ url();
            }
            .bov-tabpanel .x-tab-strip-active span.x-tab-strip-text,
            .bov-tabpanel .x-tab-strip span.x-tab-strip-text {
                color: #363636;
            }
            .bov-tabpanel .x-tab-panel-body-top {
                padding: 8px 9px;
            }
            .bov-accordion-panel .accordionpanel-header {
                border-width: 0;
                padding: 0;
            }
            .bov-accordion-panel .accordionpanel-header .x-bubble-header-text > div {
                padding-top: 8px;
                padding-bottom: 8px;
            }
            .bov-accordion-panel .accordionpanel-header .x-bubble-header-text div {
                float: left;
                font-size: 14px;
                line-height: 16px;
            }
            .bov-accordion-panel .accordionpanel-header .x-bubble-header-text .collapseIcon {
                float: right;
                background-image:/*savepage-url=../images/default/grid/row-expand-sprite.png*/ url();
                background-position: 0 center;
                width: 9px;
            }
            .bov-accordion-panel .x-panel-collapsed .accordionpanel-header .x-bubble-header-text .collapseIcon {
                background-position: -9px center;
            }
            .bov-accordion-panel .item-panel {
                position: relative;
            }
            .bov-accordion-panel .item-panel.hastooltip {
                margin-top: 30px;
            }
            .bov-accordion-panel .item-panel .info-tooltip {
                position: absolute;
                top: -14px;
                right: 3px;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header .headtitle {
                padding: 0 0 0 2px;
                font-weight: bold;
            }
            #side-ct .bov-accordion-panel .item-panel .accordionpanel-header .headtitle {
                white-space: nowrap;
            }
            #side-ct .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                max-width: 85%;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header * {
                cursor: pointer;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header.review,
            .bov-accordion-panel .item-panel .accordionpanel-header.review * {
                cursor: default;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header .x-bubble-header-text {
                display: block;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                padding: 8px 0 5px 0;
                max-width: 60%;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                min-width: 30%;
                padding: 8px 0;
                margin-right: 20px;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle .title-text {
                width: 80%;
            }
            .bov-accordion-panel .item-panel .accordionpanel-header .x-tool.x-tool-help.titleqtip,
            .bov-accordion-panel .item-panel .accordionpanel-header .x-tool.x-tool-help.summaryqtip {
                display: inline-block;
                float: none;
                margin-left: 5px;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header .headerlink {
                float: right;
                padding-right: 20px;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header.review .headerlink {
                display: none;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header .headerlink span {
                color: #550337;
                text-decoration: underline;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header.review .reviewheaderdeletetext {
                display: inline-block;
                float: right;
                padding-right: 20px;
            }
            .bov-accordion-panel .item-panel.link .accordionpanel-header .reviewheaderdeletetext {
                display: none;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar {
                border-bottom: 6px solid #545454;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar,
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-btn-group {
                padding: 0;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar-left .x-btn td {
                background: #e2e3e3;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar-left .x-btn.tab-btn.x-btn-pressed td,
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar-left .x.toolbar-cell {
                background: #545454;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar-left .x-btn.tab-btn {
                margin: 2px;
                border: 1px solid #d1d1d1;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-tbar .x-toolbar-left .x-btn.tab-btn.x-btn-pressed {
                margin: 0;
                border: 3px solid #545454;
            }
            .bov-accordion-panel.tabs
                .bov-accordion-panel-tbar
                .x-toolbar-left
                .x-btn.tab-btn.x-btn-pressed
                .x-btn-text {
                color: white;
            }
            .bov-accordion-panel .bov-accordion-panel-tbar .xtb-spacer {
                width: 30px;
            }
            .bov-accordion-panel .bov-accordion-panel-tbar .x-toolbar-right a {
                color: #98266f;
            }
            .bov-accordion-panel .x-toolbar-right .usetemplate {
                opacity: 1 !important;
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right td {
                background-image: none;
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn {
                background: transparent /*savepage-url=../images/panel/expand-collapse.png*/ url();
                width: 32px;
                opacity: 1;
                -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn-text {
                display: block;
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn-pressed {
                opacity: 0.5;
                -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn {
                height: 25px;
                table-layout: fixed;
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn.collapse-btn {
                background-position: 0 0;
                width: 32px;
            }
            .bov-accordion-panel.expand-collapse .bov-accordion-panel-tbar .x-toolbar-right .x-btn.expand-btn {
                background-position: -31px 0;
            }
            .bov-accordion-panel.tabs .bov-accordion-panel-body {
                padding: 10px;
                background: #ececec;
            }
            .bov-accordion-panel .item-panel .x-panel-fbar {
                padding: 0 10px 10px 0;
            }
            .bov-accordion-panel .x-bubble-tr {
                padding-right: 13px !important;
            }
            .bov-accordion-panel .x-form-item {
                margin-bottom: 8px;
            }
            .bov-accordion-panel-body > div.ib-radiogroup,
            .bov-accordion-panel-body > div.ib-checkboxgroup {
                padding: 0;
            }
            .bov-accordion-panel .accordion-group-title {
                padding: 10px;
                color: #fff;
                margin: 15px 0 5px;
                background: #545454;
                font-size: 14px;
                font-weight: bold;
            }
            .bov-accordion-panel .x-bubble {
                background: transparent;
            }
            .sidebar-permanent .pendingoptions {
                margin-top: 8px;
            }
            .sidebar-permanent .pendingoptions .ib-btn-secondary {
                margin-bottom: 3px;
            }
            .sidebar-permanent .bov-findfunction input#ib-functionsearch {
                border-radius: 3px 0 0 3px;
                padding-top: 3px;
                padding-bottom: 3px;
                color: #545454;
                border-color: #730c4c;
                border-width: 2px;
                padding-right: 12px;
            }
            .sidebar-permanent .bov-findfunction .x-form-field-wrap .x-form-trigger {
                background-image:/*savepage-url=../images/icons/find_magnifier_40x28.png*/ url();
                width: 40px;
                height: 28px;
                margin-left: -12px;
                border-bottom: none;
                background-position: 0 0;
            }
            .sidebar-permanent .bov-findfunction .x-form-field-wrap .x-form-trigger.x-form-trigger-over {
                background-position: 0 0;
            }
            .sidebar-permanent
                .bov-findfunction
                .bov-searchfield
                .bov-searchfield-trigger.x-form-trigger-over.x-form-trigger-click {
                background-position: 0 0;
            }
            .bov-accordion-panel .x-form-item {
                margin-bottom: 8px;
            }
            .x-bovformpanel-header {
                font-weight: bold;
                font-size: 14px;
            }
            .x-functionbox-bbar .xtb-spacer {
                width: 12px;
            }
            .expand-collapse.bov-accordion-panel .bov-accordion-panel-tbar .x-toolbar-right .usetemplate .x-btn-text {
                padding-right: 30px;
            }
            #tfw-specialrate-popup .x-panel-noborder .x-panel-body-noborder {
                padding-bottom: 7px;
            }
            #tfw-specialrate-popup .x-form-item {
                margin-bottom: 0;
            }
            #orderchequebook-chequebookdetailspanel .x-form-item label.x-form-item-label {
                margin: -6px;
                padding-left: 6px;
            }
            .ext-chrome #orderchequebook-chequebookdetailspanel .x-form-item label.x-form-item-label {
                margin: -5px;
            }
            #orderchequebookform
                #billpayment-payment-accordion-panel
                .item-panel
                .accordionpanel-body
                .x-panel
                .x-panel-bwrap {
                overflow: visible;
            }
            #orderchequebookform
                #billpayment-payment-accordion-panel
                #orderchequebook-chequebookdetailspanel.item-panel
                .accordionpanel-body
                .x-form-field-wrap {
                top: -4px;
            }
            #orderchequebook-chequebookdetailspanel #x-form-el-orderchequebook-leftttyperadio {
                padding-bottom: 10px;
            }
            #orderforeigncash-collectionpanel .x-bubble-bwrap .itempanel-review-panel .td-value {
                word-break: break-all;
            }
            #bov-changecontactdetailsform .item-panel .summaryct {
                display: inline-block;
                overflow: hidden;
                text-align: left;
                text-overflow: ellipsis;
                width: 55%;
            }
            #bov-changecontactdetailsform .item-panel .headtitle {
                display: inline-block;
                overflow: hidden;
                text-align: left;
                text-overflow: ellipsis;
                width: 25%;
            }
            #demofunction-multicardselectorpanel .itempanel-review-panel {
                line-height: 23px;
            }
            #demofunction-multiaccountselectorpanel .itempanel-review-panel {
                line-height: 23px;
            }
            #demofunction-textareapanel .x-bubble-bwrap .itempanel-review-panel .td-value {
                word-break: break-all;
            }
            #demotfwfunction-tfwdetailspanel .x-bubble-bwrap .itempanel-review-panel .td-value {
                word-break: break-all;
            }
            .x-bubble-bwrap .itempanel-review-panel .td-label {
                vertical-align: top;
            }
            .x-bubble-bwrap .itempanel-review-panel .td-value {
                padding-top: 5px;
                vertical-align: top;
            }
            .resultpanel-displayfield {
                margin: 10px 0 10px 0;
            }
            .bov-date-time-error-ct {
                padding-left: 185px;
                clear: both;
                margin-top: -8px;
            }
            .balancebar-title {
                display: block;
                margin: 0 0 7px 0;
                padding: 0;
                border: 0pz;
                height: 22px;
                color: #940c61;
            }
            .balancebar-label {
                margin-top: -4px;
            }
            .balancebar-colored-withdrawal-deposit-inner {
                height: 16px;
                margin: 5px 0;
            }
            .balancebar-colored-withdrawal-deposit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 0
                    transparent;
                height: 16px;
            }
            .balancebar-colored-withdrawal-deposit-bar2 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -48px transparent;
                height: 16px;
            }
            .balancebar-colored-withdrawal-deposit-bar3 {
                display: none;
            }
            .empty .balancebar-colored-withdrawal-deposit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -32px transparent;
                height: 16px;
                border-left: 1px solid #86be73;
                border-right: 1px solid #86be73;
            }
            .empty .balancebar-colored-withdrawal-deposit-bar2,
            .empty .balancebar-colored-withdrawal-deposit-bar3 {
                display: none;
            }
            .balancebar-colored-withdrawal-deposit-text.balancebar-colored-withdrawal-deposit-text-back {
                color: #6d6d6d;
            }
            .balancebar-colored-deposit-deposit-inner {
                height: 16px;
                margin: 5px 0;
            }
            .balancebar-colored-deposit-deposit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -32px transparent;
                height: 16px;
                border-left: 1px solid #86be73;
                border-right: 1px solid #86be73;
            }
            .balancebar-colored-deposit-deposit-bar2 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -48px transparent;
                height: 16px;
            }
            .balancebar-colored-deposit-deposit-bar3 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 0
                    transparent;
                height: 16px;
            }
            .empty .balancebar-colored-deposit-deposit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -32px transparent;
                height: 16px;
                border-left: 1px solid #86be73;
                border-right: 1px solid #86be73;
            }
            .empty .balancebar-colored-deposit-deposit-bar2,
            .empty .balancebar-colored-deposit-deposit-bar3 {
                display: none;
            }
            .balancebar-colored-deposit-deposit-text.balancebar-colored-deposit-deposit-text-back {
                color: #6d6d6d;
            }
            .balancebar-colored-loan-inner {
                height: 16px;
                margin: 5px 0;
            }
            .balancebar-colored-loan-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -16px transparent;
                height: 16px;
                border-left: 1px solid #ff7373;
                border-right: 1px solid #ff7373;
            }
            .balancebar-colored-loan-bar2 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 0
                    transparent;
                height: 16px;
            }
            .balancebar-colored-loan-bar3 {
                display: none;
            }
            .empty .balancebar-colored-loan-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -16px transparent;
                height: 16px;
                border-left: 1px solid #ff7373;
                border-right: 1px solid #ff7373;
            }
            .empty .balancebar-colored-loan-bar2,
            .empty .balancebar-colored-loan-bar3 {
                display: none;
            }
            .balancebar-colored-loan-text.balancebar-colored-loan-text-back {
                color: #6d6d6d;
            }
            .balancebar-colored-credit-inner {
                height: 16px;
                margin: 5px 0;
            }
            .balancebar-colored-credit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -48px transparent;
                height: 16px;
            }
            .balancebar-colored-credit-bar2 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 0
                    transparent;
                height: 16px;
            }
            .balancebar-colored-credit-bar3 {
                display: none;
            }
            .empty .balancebar-colored-credit-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -32px transparent;
                height: 16px;
                border-left: 1px solid #86be73;
                border-right: 1px solid #86be73;
            }
            .empty .balancebar-colored-credit-bar2,
            .empty .balancebar-colored-credit-bar3 {
                display: none;
            }
            .balancebar-colored-credit-text.balancebar-colored-credit-text-back {
                color: #6d6d6d;
            }
            .balancebar-colored-overdraft-inner {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -32px transparent;
                height: 16px;
                margin: 5px 0;
                border-right: 1px solid #86be73;
                margin-right: -1px;
            }
            .balancebar-colored-overdraft-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -48px transparent;
                height: 16px;
                border-left: 1px solid #ff7373;
            }
            .balancebar-colored-overdraft-bar2 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 0
                    transparent;
                height: 16px;
            }
            .balancebar-colored-overdraft-bar3 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -16px transparent;
                height: 16px;
            }
            .empty .balancebar-colored-overdraft-bar1 {
                background:/*savepage-url=../images/balancebar/balancebar-3color-bg.png*/ url() repeat-x scroll 0 -16px transparent;
                height: 16px;
                border-left: 1px solid #ff7373;
            }
            .empty .balancebar-colored-overdraft-bar2,
            .empty .balancebar-colored-overdraft-bar3 {
                display: none;
            }
            .balancebar-colored-overdraft-text.balancebar-colored-overdraft-text-back {
                color: #6d6d6d;
            }
            .x-panel-body.x-form {
                position: static;
            }
            .x-form-text,
            textarea.x-form-field,
            .x-trigger-wrap-focus .x-form-trigger {
                border-color: #bcbec9;
            }
            input.x-form-text,
            input[readonly].x-form-text.x-trigger-noedit,
            input[readonly].x-form-text:not(.x-form-empty-field) {
                color: #000;
            }
            input[readonly].x-form-text,
            input.x-form-empty-field,
            input[readonly].x-form-text.x-trigger-noedit.x-form-empty-field,
            .bov-gridpanel input.x-form-empty-field {
                color: gray;
            }
            .x-form-display-field {
                padding-top: 3px;
                text-align: left;
                padding-left: 8px;
            }
            .req-sign-hidden {
                display: none;
            }
            .x-searchfield {
                background:/*savepage-url=../images/icons/icon-searchfield.png*/ url() no-repeat scroll 0 0 #fff;
                padding-left: 23px;
                height: 19px !important;
                border: 8px solid #404040;
            }
            .ib-radiogroup,
            .ib-checkboxgroup {
                padding: 0 0 6px;
            }
            .ib-radiogroup .x-form-item,
            .ib-checkboxgroup .x-form-item {
                margin-bottom: 0;
            }
            .padded.x-form-label-right.x-box-item {
                padding-left: 6px;
            }
            .x-form-field.conditioned {
                padding: 4px 0 4px 17px;
            }
            .x-form-field.conditioned label {
                width: auto;
            }
            .x-box-item.inline .x-form-item {
                margin-right: 4px;
                float: left;
            }
            .x-form-check-wrap {
                position: relative;
                padding: 3px 0 7px;
                height: auto;
                line-height: 13px;
            }
            .x-form-check-wrap.radio {
                padding: 3px 0 6px;
            }
            .x-form-check-wrap label.x-form-cb-label {
                margin-left: 4px;
                padding: 0 3px 0 0;
                top: 0;
            }
            .x-form-check-wrap.radio label.x-form-cb-label {
                margin-left: 3px;
            }
            .x-form-checkbox,
            .x-form-radio {
                width: 13px;
                height: 13px;
                -moz-opacity: 0;
                opacity: 0;
                -ms-filter: "alpha(opacity=0)";
                filter: alpha(opacity=0);
            }
            .ext-ie8 .x-form-checkbox,
            .x-form-radio {
                -ms-filter: "alpha(opacity=20)";
                filter: alpha(opacity=20);
            }
            .ext-ie .x-form-check-wrap input {
                width: 13px;
                height: 13px;
            }
            .x-form-checkbox-inner,
            .x-form-radio-inner {
                width: 13px;
                height: 13px;
                display: inline-block;
            }
            .x-form-check-no-label {
                position: relative;
            }
            .x-form-checkbox-inner {
                background:/*savepage-url=../images/default/form/checkbox.gif*/ url() no-repeat 0 0;
            }
            .x-form-radio-inner {
                background:/*savepage-url=../images/default/form/radio.gif*/ url() no-repeat 0 0;
            }
            .x-form-check-focus .x-form-checkbox-inner,
            .x-form-check-over .x-form-checkbox-inner,
            .x-form-check-focus .x-form-radio-inner,
            .x-form-check-over .x-form-radio-inner {
                background-position: 0 0;
            }
            .x-form-check-down .x-form-checkbox-inner,
            .x-form-check-down .x-form-radio-inner {
                background-position: 0 0;
            }
            .x-form-check-checked .x-form-checkbox-inner,
            .x-form-check-checked,
            .x-form-check-checked .x-form-radio-inner {
                background-position: 0 -13px;
            }
            .x-form-check-focus .x-form-check-checked,
            .x-form-check-over .x-form-check-checked {
                background-position: 0 -13px;
            }
            .x-form-check-down .x-form-check-checked {
                background-position: 0 -13px;
            }
            .x-form-field-wrap .x-form-bov-date-trigger {
                background-image:/*savepage-url=../images/default/form/calendar_icon.png*/ url();
            }
            .x-form-field-wrap .x-form-bov-date-trigger.x-form-trigger,
            .x-form-field-wrap .x-form-bov-date-trigger.x-form-trigger-over,
            .x-form-field-wrap .x-form-bov-date-trigger.x-form-trigger-click,
            .x-trigger-wrap-focus .x-form-bov-date-trigger.x-form-trigger,
            .x-trigger-wrap-focus .x-form-bov-date-trigger.x-form-trigger-over,
            .x-trigger-wrap-focus .x-form-bov-date-trigger.x-form-trigger-click {
                background-position: 0 0;
            }
            .x-date-menu {
                border-color: #cbcbcb;
            }
            .x-date-bottom,
            .x-date-inner th {
                background: #98266f;
                color: #fff;
            }
            .x-date-middle,
            .x-date-left,
            .x-date-right {
                background: #fff /*savepage-url=../images/default/form/date-header-bg.gif*/ url() repeat-x top left;
            }
            .x-date-left a {
                background-image:/*savepage-url=../images/default/shared/left-btn.gif*/ url();
            }
            .x-date-right a {
                background-image:/*savepage-url=../images/default/shared/right-btn.gif*/ url();
            }
            .x-date-inner .x-date-selected a {
                background: #fff;
            }
            .x-date-inner a:hover,
            .x-date-inner .x-date-disabled a:hover {
                background-color: #fcd4ed;
            }
            .x-date-mp-ybtn a {
                background-image:/*savepage-url=../images/default/panel/tool-sprites.gif*/ url();
            }
            .x-date-mp-ybtn a.x-date-mp-prev {
                background-position: 0 -112px;
            }
            .x-date-mp-ybtn a.x-date-mp-prev:hover {
                background-position: -16px -112px;
            }
            .x-date-mp-ybtn a.x-date-mp-next {
                background-position: 0 -128px;
            }
            .x-date-mp-ybtn a.x-date-mp-next:hover {
                background-position: -16px -128px;
            }
            .x-date-mp-btns {
                background: #98266f;
            }
            .x-date-mp-btns button {
                background: #ececec;
                border-color: #ccc;
                color: #363636;
            }
            td.x-date-mp-month a,
            td.x-date-mp-year a {
                color: #363636;
            }
            td.x-date-mp-month a:hover,
            td.x-date-mp-year a:hover {
                background-color: #fcd4ed;
                color: #363636;
            }
            td.x-date-mp-sel a {
                border-color: #98266f;
                color: #363636;
                background: #ececec;
            }
            .x-form-invalid,
            textarea.x-form-invalid {
                background-image: none;
                border-color: #c30;
            }
            .x-form-invalid-group {
                background: none repeat-x scroll center bottom transparent;
                border: 1px solid #c30;
            }
            .x-combo-list .x-combo-selected {
                background-color: #dbe5f1;
            }
            .function-not-found div.x-combo-list-item {
                white-space: normal;
                padding-right: 15px;
            }
            .x-btn-group {
                margin: 0;
            }
            .ib-btn-group table.x-btn.ib-btn td {
                background-image: none;
            }
            .ib-btn-group td,
            .ib-btn-group td i {
                height: 0;
            }
            hr.currencyselectorseparator {
                color: transparent;
                background-color: transparent;
                border: #808080 1px dashed;
                border-style: none none dashed;
            }
            input.x-form-field.currencySelector {
                color: gray;
            }
            .bov-searchfield .notempty {
                border-right: none;
            }
            .bov-searchfield input {
                height: 24px !important;
            }
            .bov-searchfield .bov-searchfield-trigger.clean {
                background-image:/*savepage-url=../images/default/form/trigger26px_clean.gif*/ url();
                border-bottom: none;
                height: 26px;
            }
            .bov-searchfield .bov-searchfield-trigger.search {
                background-image:/*savepage-url=../images/default/form/trigger26px_search.gif*/ url();
                width: 26px;
                margin-left: 3px;
                border-bottom: none;
                background-position: 0 0;
            }
            .bov-searchfield .bov-searchfield-trigger.search.x-form-trigger-over {
                background-position: -26px 0;
            }
            .bov-searchfield .bov-searchfield-trigger.search.x-form-trigger-over.x-form-trigger-click {
                background-position: -52px 0;
            }
            .x-form-amountfield {
                border: 1px solid #bcbec9;
                background-color: white;
                background: #fff /*savepage-url=../../extjs/resources/images/default/form/text-bg.gif*/
                    var(--savepage-url-7) repeat-x 0 0;
                height: 18px;
                padding: 1px 0;
            }
            .x-form-amountfield .x-box-inner {
                overflow: visible;
            }
            .amountfield-currency {
                padding: 1px 0 0 3px;
                border: none;
                background-color: #e6e6e6;
                color: grey;
                height: 19px !important;
            }
            .amountfield-currency-optional {
                background-color: transparent;
                width: 100% !important;
            }
            .ext-ie .amountfield-currency {
                padding-top: 3px;
                height: 17px !important;
            }
            .ext-ie8 .x-form-display-field.amountfield-currency,
            .ext-strict .ext-ie8 .x-form-display-field.amountfield-currency {
                padding: 1px 0 1px 3px;
                height: 18px;
                line-height: 18px;
            }
            .ext-strict .ext-ie8 .x-form-display-field {
                padding: 3px;
            }
            .ext-gecko3 .amountfield-currency {
                padding-top: 2px;
                height: 18px !important;
            }
            .amountfield-amount {
                padding: 1px 3px;
                border-width: 0;
                background-color: transparent;
                background: none;
                height: 18px !important;
                text-align: right;
                color: grey;
            }
            .ext-ie8 .amountfield-amount {
                padding: 1px 3px;
                height: 18px;
                line-height: 18px;
            }
            .ext-ie8 .amountfield-amount:focus {
                border: none;
                outline: 0;
            }
            .ext-gecko3 .amountfield-amount {
                padding-top: 0;
            }
            input[readonly].x-form-amountfield {
                color: gray !important;
            }
            .x-form-invalid.x-form-amountfield {
                height: 18px;
                background-color: #fff;
                background-image: none;
                border: 1px solid #c30;
            }
            .amountfield-amount.x-form-invalid {
                padding-left: 3px;
                padding-right: 3px;
                border: none;
                background-image: none !important;
                background-color: #fff;
                height: 18px;
                text-align: right;
                color: grey;
            }
            .tablecell-align-top {
                vertical-align: top;
            }
            .tablecell-align-middle {
                vertical-align: middle;
            }
            .tablecell-align-bottom {
                vertical-align: bottom;
            }
            .tablecell-align-left {
                text-align: left;
            }
            .tablecell-align-right {
                text-align: right;
            }
            .tablecell-align-center {
                text-align: center;
            }
            .x-form-file-wrap {
                position: relative;
                height: 26px;
            }
            .x-form-file-wrap .x-form-file {
                position: absolute;
                left: 0;
                -moz-opacity: 0;
                filter: alpha(opacity: 0);
                opacity: 0;
                z-index: 3;
                height: 22px;
                cursor: pointer;
            }
            .x-form-file-wrap .x-form-file-btn {
                position: absolute;
                left: 0;
                z-index: 1;
            }
            .x-form-file-wrap .x-btn {
                float: left;
                position: relative;
                z-index: 1;
            }
            .x-form-file-wrap .x-form-file-text {
                float: left;
                position: relative;
                z-index: 2;
                color: #777;
                margin-top: 2px;
            }
            .x-form-file-wrap .x-form-file-text.right,
            .x-form-file-wrap .x-btn.right {
                margin-left: 8px;
            }
            .x-functionbox .x-form-file-wrap .printall-btn button {
                background: none;
                padding-left: 0;
            }
            .x-form-radio-group.x-form-focus {
                border-width: 0;
            }
            .x-form-invalid.x-form-composite .x-form-invalid {
                background-image: none;
            }
            .x-form-item label.x-form-item-label {
                margin-right: 7px;
            }
            .ext-safari input.x-form-empty-field,
            .ext-safari input[readonly].x-form-text.x-trigger-noedit.x-form-empty-field,
            .ext-safari .bov-gridpanel input.x-form-empty-field {
                color: #323232;
            }
            #viewtransactions-details-accountinfo .x-form-item label.x-form-item-label {
                margin-right: 0;
                white-space: nowrap;
            }
            .ext-ie #viewtransactions-details-accountinfo .x-form-display-field {
                padding-top: 0;
                padding: 0;
            }
            .ext-safari #viewtransactions-details-accountinfo .x-form-display-field {
                padding-top: 0;
                padding-left: 8px;
                text-align: left;
            }
            .ext-ie #viewtransactions-details-accountinfo .x-form-display-field {
                padding-top: 0;
                padding-left: 8px;
                text-align: left;
            }
            #orderbankdraft-deliverypanel input[readonly].x-form-text.x-trigger-noedit,
            #orderbankdraft-deliverypanel input[readonly].x-form-text:not(.x-form-empty-field),
            #orderbankdraft-deliverypanel input.x-item-disabled {
                color: gray;
            }
            #stopcards-datepanel input.x-form-text,
            #stopcards-datepanel input.x-form-field {
                margin-left: 1.9px;
            }
            .ext-ie8 input[readonly].x-form-text {
                color: black;
            }
            .ext-safari .x-form-display-field {
                padding-right: 20px;
            }
            .ext-safari #viewtransactions-details-accountinfo .x-form-display-field {
                padding-right: 0;
            }
            .ext-safari #bov-todo-waitingfor-accordion-panel .x-form-display-field,
            .ext-safari #bov-todo-thingstodo-accordion-panel .x-form-display-field,
            .ext-safari #bov-todo-thingstodo-accordion-panel .msg-table .msg-title-info .x-panel-body {
                padding-right: 55px;
            }
            #viewtransactions-sidebar-filter-periodpanel .x-form-check-wrap.radio {
                padding: 5px;
            }
            #viewtransactions-sidebar-filter-periodpanel .x-form-check-wrap label.x-form-cb-label {
                top: 0 !important;
            }
            #orderchequebook-deliverymethodpanel .x-table-layout-cell.tablecell-align-top .x-form-check-wrap.radio {
                margin-right: -24px;
            }
            #orderchequebook-chequebookdetailspanel .x-form-item label.x-form-item-label {
                top: 2px;
            }
            #orderchequebook-deliverymethodpanel .x-form-check-wrap label.x-form-cb-label,
            #orderchequebook-chequebookdetailspanel .x-form-check-wrap label.x-form-cb-label {
                top: 1px;
            }
            .ext-chrome #orderchequebook-deliverymethodpanel .x-form-check-wrap label.x-form-cb-label {
                top: 2px;
            }
            .ext-ie11 #orderchequebook-chequebookdetailspanel .x-form-check-wrap label.x-form-cb-label,
            .ext-ie10 #orderchequebook-chequebookdetailspanel .x-form-check-wrap label.x-form-cb-label,
            .ext-ie9 #orderchequebook-chequebookdetailspanel .x-form-check-wrap label.x-form-cb-label {
                top: 0;
            }
            #registerfortopupform-accordion-panel .x-form-check-wrap label.x-form-cb-label {
                top: 1px;
            }
            .ext-ie #footer-upper-link-ct .x-table-layout .x-table-layout-cell .x-panel .x-panel-bwrap .x-panel-body {
                padding-top: 3px;
                padding-bottom: 2px;
            }
            .ext-chrome
                #footer-upper-link-ct
                .x-table-layout
                .x-table-layout-cell
                .x-panel
                .x-panel-bwrap
                .x-panel-body {
                padding-top: 3px;
                padding-bottom: 2px;
            }
            #maturityinstructions-transferpanel .radioDisplayField {
                padding-right: 0 !important;
            }
            .bov-form-emptySearchPanel {
                height: auto;
                max-height: 100%;
                width: auto;
                max-width: 100%;
            }
            .bovdaterangefield-item .info-bubble .info-bubble-icon {
                margin-top: 3px;
            }
            .x-btn-tr i,
            .x-btn-tl i,
            .x-btn-mr i,
            .x-btn-ml i,
            .x-btn-br i,
            .x-btn-bl i {
                width: 4px;
            }
            .x-btn-tl {
                width: 4px;
                height: 4px;
                background: no-repeat 0 0;
            }
            .x-btn-tr {
                width: 4px;
                height: 4px;
                background: no-repeat -4px 0;
            }
            .x-btn-tc {
                height: 4px;
                background: repeat-x 0 -8px;
            }
            .x-btn-ml {
                width: 4px;
                background: no-repeat 0 -32px;
            }
            .x-btn-mr {
                width: 4px;
                background: no-repeat -4px -32px;
            }
            .x-btn td.x-btn-mc {
                padding: 0 5px !important;
            }
            .x-btn-bl {
                width: 4px;
                height: 4px;
                background: no-repeat 0 -4px;
            }
            .x-btn-br {
                width: 4px;
                height: 4px;
                background: no-repeat -4px -4px;
            }
            .x-btn-bc {
                height: 4px;
                background: repeat-x 0 -12px;
            }
            .x-btn-over .x-btn-tl {
                background-position: -8px 0;
            }
            .x-btn-over .x-btn-tr {
                background-position: -12px 0;
            }
            .x-btn-over .x-btn-tc {
                background-position: 0 -16px;
            }
            .x-btn-over .x-btn-ml {
                background-position: -8px -32px;
            }
            .x-btn-over .x-btn-mr {
                background-position: -12px -32px;
            }
            .x-btn-over .x-btn-mc {
                background-position: 0 -2168px;
            }
            .x-btn-over .x-btn-bl {
                background-position: -8px -4px;
            }
            .x-btn-over .x-btn-br {
                background-position: -12px -4px;
            }
            .x-btn-over .x-btn-bc {
                background-position: 0 -20px;
            }
            .x-btn-click .x-btn-tl,
            .x-btn-menu-active .x-btn-tl,
            .x-btn-pressed .x-btn-tl {
                background-position: -16px 0;
            }
            .x-btn-click .x-btn-tr,
            .x-btn-menu-active .x-btn-tr,
            .x-btn-pressed .x-btn-tr {
                background-position: -20px 0;
            }
            .x-btn-click .x-btn-tc,
            .x-btn-menu-active .x-btn-tc,
            .x-btn-pressed .x-btn-tc {
                background-position: 0 -24px;
            }
            .x-btn-click .x-btn-ml,
            .x-btn-menu-active .x-btn-ml,
            .x-btn-pressed .x-btn-ml {
                background-position: -16px -32px;
            }
            .x-btn-click .x-btn-mr,
            .x-btn-menu-active .x-btn-mr,
            .x-btn-pressed .x-btn-mr {
                background-position: -20px -32px;
            }
            .x-btn-click .x-btn-mc,
            .x-btn-menu-active .x-btn-mc,
            .x-btn-pressed .x-btn-mc {
                background-position: 0 -3240px;
            }
            .x-btn-click .x-btn-bl,
            .x-btn-menu-active .x-btn-bl,
            .x-btn-pressed .x-btn-bl {
                background-position: -16px -4px;
            }
            .x-btn-click .x-btn-br,
            .x-btn-menu-active .x-btn-br,
            .x-btn-pressed .x-btn-br {
                background-position: -20px -4px;
            }
            .x-btn-click .x-btn-bc,
            .x-btn-menu-active .x-btn-bc,
            .x-btn-pressed .x-btn-bc {
                background-position: 0 -28px;
            }
            .x-btn-tl,
            .x-btn-tr,
            .x-btn-tc,
            .x-btn-ml,
            .x-btn-mr,
            .x-btn-mc,
            .x-btn-bl,
            .x-btn-br,
            .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn.png*/ url();
            }
            .ib-btn-over .x-btn-tl,
            .ib-btn-secondary.x-btn-click .x-btn-tl,
            .x-toolbar .ib-btn-over .x-btn-tl,
            .x-toolbar .ib-btn-click .x-btn-tl {
                background-position: -20px 0;
            }
            .ib-btn-over .x-btn-tr,
            .ib-btn-secondary.x-btn-click .x-btn-tr,
            .x-toolbar .ib-btn-over .x-btn-tr,
            .x-toolbar .ib-btn-click .x-btn-tr {
                background-position: -30px 0;
            }
            .ib-btn-over .x-btn-tc,
            .ib-btn-secondary.x-btn-click .x-btn-tc,
            .x-toolbar .ib-btn-over .x-btn-tc,
            .x-toolbar .ib-btn-click .x-btn-tc {
                background-position: 0 -12px;
            }
            .ib-btn-over .x-btn-ml,
            .ib-btn-secondary.x-btn-click .x-btn-ml,
            .x-toolbar .ib-btn-over .x-btn-ml,
            .x-toolbar .ib-btn-click .x-btn-ml {
                background-position: -20px -24px;
            }
            .ib-btn-over .x-btn-mr,
            .ib-btn-secondary.x-btn-click .x-btn-mr,
            .x-toolbar .ib-btn-over .x-btn-mr,
            .x-toolbar .ib-btn-click .x-btn-mr {
                background-position: -30px -24px;
            }
            .ib-btn-over .x-btn-mc,
            .ib-btn-secondary.x-btn-click .x-btn-mc,
            .x-toolbar .ib-btn-over .x-btn-mc,
            .x-toolbar .ib-btn-click .x-btn-mc {
                background-position: 0 -124px;
            }
            .ib-btn-over .x-btn-bl,
            .ib-btn-secondary.x-btn-click .x-btn-bl,
            .x-toolbar .ib-btn-over .x-btn-bl,
            .x-toolbar .ib-btn-click .x-btn-bl {
                background-position: -20px -3px;
            }
            .ib-btn-over .x-btn-br,
            .ib-btn-secondary.x-btn-click .x-btn-br,
            .x-toolbar .ib-btn-over .x-btn-br,
            .x-toolbar .ib-btn-click .x-btn-br {
                background-position: -30px -3px;
            }
            .ib-btn-over .x-btn-bc,
            .ib-btn-secondary.x-btn-click .x-btn-bc,
            .x-toolbar .ib-btn-over .x-btn-bc,
            .x-toolbar .ib-btn-click .x-btn-bc {
                background-position: 0 -15px;
            }
            .ib-btn-primary .x-btn-tl,
            .ib-btn-primary .x-btn-tr,
            .ib-btn-primary .x-btn-tc,
            .ib-btn-primary .x-btn-ml,
            .ib-btn-primary .x-btn-mr,
            .ib-btn-primary .x-btn-mc,
            .ib-btn-primary .x-btn-bl,
            .ib-btn-primary .x-btn-br,
            .ib-btn-primary .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn_ib_primary.png*/ url();
                background-color: transparent;
            }
            .ib-btn-secondary .x-btn-tl,
            .ib-btn-secondary .x-btn-tr,
            .ib-btn-secondary .x-btn-tc,
            .ib-btn-secondary .x-btn-ml,
            .ib-btn-secondary .x-btn-mr,
            .ib-btn-secondary .x-btn-mc,
            .ib-btn-secondary .x-btn-bl,
            .ib-btn-secondary .x-btn-br,
            .ib-btn-secondary .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn_ib_secondary.png*/ var(--savepage-url-9);
                background-color: transparent;
            }
            .ib-btn-secondary.light .x-btn-tl,
            .ib-btn-secondary.light .x-btn-tr,
            .ib-btn-secondary.light .x-btn-tc,
            .ib-btn-secondary.light .x-btn-ml,
            .ib-btn-secondary.light .x-btn-mr,
            .ib-btn-secondary.light .x-btn-mc,
            .ib-btn-secondary.light .x-btn-bl,
            .ib-btn-secondary.light .x-btn-br,
            .ib-btn-secondary.light .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn_ib_secondary_light.png*/ var(
                    --savepage-url-8
                );
            }
            .ib-btn-secondary.dark .x-btn-tl,
            .ib-btn-secondary.dark .x-btn-tr,
            .ib-btn-secondary.dark .x-btn-tc,
            .ib-btn-secondary.dark .x-btn-ml,
            .ib-btn-secondary.dark .x-btn-mr,
            .ib-btn-secondary.dark .x-btn-mc,
            .ib-btn-secondary.dark .x-btn-bl,
            .ib-btn-secondary.dark .x-btn-br,
            .ib-btn-secondary.dark .x-btn-bc {
                background-image:/*savepage-url=../images/default/button/btn_ib_secondary_dark.png*/ url();
            }
            .ib-btn-primary .x-btn-text {
                font-size: 14px;
                font-weight: normal !important;
            }
            .ib-btn-secondary button.x-btn-text {
                font-size: 13px;
            }
            .ib-btn-secondary.light button.x-btn-text {
                color: #1c1c1e;
            }
            .ib-btn-secondary .x-btn-mc em {
                line-height: 24px;
            }
            .ib-btn-primary.x-item-disabled,
            .ib-btn-secondary.x-item-disabled {
                opacity: 1;
            }
            .ib-btn-primary.x-item-disabled .x-btn-tl,
            .ib-btn-secondary.x-item-disabled .x-btn-tl {
                background-position: -40px 0;
            }
            .ib-btn-primary.x-item-disabled .x-btn-tc,
            .ib-btn-secondary.x-item-disabled .x-btn-tc {
                background-position: 0 -18px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-tr,
            .ib-btn-secondary.x-item-disabled .x-btn-tr {
                background-position: -50px 0;
            }
            .ib-btn-primary.x-item-disabled .x-btn-ml,
            .ib-btn-secondary.x-item-disabled .x-btn-ml {
                background-position: -40px -24px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-mc,
            .ib-btn-secondary.x-item-disabled .x-btn-mc {
                background-position: 0 -174px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-mr,
            .ib-btn-secondary.x-item-disabled .x-btn-mr {
                background-position: -50px -24px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-bl,
            .ib-btn-secondary.x-item-disabled .x-btn-bl {
                background-position: -40px -3px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-bc,
            .ib-btn-secondary.x-item-disabled .x-btn-bc {
                background-position: 0 -21px;
            }
            .ib-btn-primary.x-item-disabled .x-btn-br,
            .ib-btn-secondary.x-item-disabled .x-btn-br {
                background-position: -50px -3px;
            }
            .ib-btn-primary.x-item-disabled *,
            .ib-btn-secondary.x-item-disabled * {
                color: #fff !important;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-tl {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-tr {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-tc {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-ml {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-mr {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-mc {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-bl {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-br {
                background-image: none;
            }
            .x-toolbar .x-btn-icon.x-btn-over .x-btn-bc {
                background-image: none;
            }
            .x-functionbox .printall-btn .x-btn-tl,
            .x-functionbox .printall-btn .x-btn-ml,
            .x-functionbox .printall-btn .x-btn-bl,
            .x-functionbox .printall-btn .x-btn-tr,
            .x-functionbox .printall-btn .x-btn-mr,
            .x-functionbox .printall-btn .x-btn-br {
                width: 3px;
            }
            .x-functionbox .printall-btn .x-btn-tl,
            .x-functionbox .printall-btn .x-btn-tc,
            .x-functionbox .printall-btn .x-btn-tr,
            .x-functionbox .printall-btn .x-btn-bl,
            .x-functionbox .printall-btn .x-btn-bc,
            .x-functionbox .printall-btn .x-btn-br {
                height: 3px;
            }
            .x-functionbox .printall-btn .x-btn-ml,
            .x-functionbox .printall-btn .x-btn-mc,
            .x-functionbox .printall-btn .x-btn-mr {
                height: 19px;
            }
            .x-functionbox .printall-btn .x-btn-tl,
            .x-functionbox .printall-btn .x-btn-tc,
            .x-functionbox .printall-btn .x-btn-tr,
            .x-functionbox .printall-btn .x-btn-ml,
            .x-functionbox .printall-btn .x-btn-mc,
            .x-functionbox .printall-btn .x-btn-mr,
            .x-functionbox .printall-btn .x-btn-bl,
            .x-functionbox .printall-btn .x-btn-bc,
            .x-functionbox .printall-btn .x-btn-br {
                background:/*savepage-url=../images/default/button/btn_ib_printall.png*/ url() no-repeat;
            }
            .x-functionbox .printall-btn .x-btn-tl {
                background-position: 0 0;
            }
            .x-functionbox .printall-btn .x-btn-tc {
                background-position: 0 -25px;
                background-repeat: repeat;
            }
            .x-functionbox .printall-btn .x-btn-tr {
                background-position: -2px 0;
            }
            .x-functionbox .printall-btn .x-btn-ml {
                background-position: 0 -3px;
            }
            .x-functionbox .printall-btn .x-btn-mc {
                background-position: 0 -28px;
                background-repeat: repeat;
            }
            .x-functionbox .printall-btn .x-btn-mr {
                background-position: -2px -3px;
            }
            .x-functionbox .printall-btn .x-btn-bl {
                background-position: 0 -22px;
            }
            .x-functionbox .printall-btn .x-btn-bc {
                background-position: 0 -47px;
                background-repeat: repeat;
            }
            .x-functionbox .printall-btn .x-btn-br {
                background-position: -2px -22px;
            }
            .x-functionbox .printall-btn button {
                background:/*savepage-url=../images/default/button/icon_printer_12x11.png*/ url() no-repeat scroll 0 4px
                    transparent;
                padding-left: 18px;
            }
            .x-toolbar.printall-btb {
                padding-bottom: 5px;
            }
            .ib-btn-secondary .x-btn-small .x-btn-text {
                height: 24px;
                line-height: 15px;
            }
            .bov-xchange-ratefield {
                padding-top: 0 !important;
            }
            .bov-xchange-ratefield .text,
            .bov-xchange-ratefield .info-bubble {
                position: relative;
                float: left;
                height: 16px;
            }
            .bov-xchange-ratefield .rate-text {
                padding: 0 0 0 4px;
                color: #6d6d6d;
            }
            .bov-xchange-ratefield img {
                margin-left: 8px;
            }
            .ext-ie10 .bov-xchange-row .sourcerow-container,
            .ext-ie11 .bov-xchange-row .sourcerow-container,
            .ext-ie10 .bov-xchange-row .targetrow-container,
            .ext-ie11 .bov-xchange-row .targetrow-container {
                width: auto !important;
            }
            .bov-template-panel {
                margin-bottom: 10px;
            }
            .bov-template-panel .x-panel-header {
                font-size: 12px;
                font-weight: bold;
                color: #333;
                border: none;
                background: none #ececec;
            }
            .bov-template-panel .x-panel,
            .bov-template-panel .x-panel-body {
                border: none;
            }
            .bov-template-panel .x-panel-body {
                padding: 10px;
                overflow: hidden;
                background-color: #ececec;
            }
            .bov-template-panel .bov-template-tomanagement-column .x-panel-body .x-btn {
                float: right;
            }
            .bov-template-panel .bov-template-btn .x-btn-text {
                padding-left: 5px;
                padding-right: 5px;
            }
            .x-form-element.accountselector .x-form-trigger,
            .x-form-element.singleselector .x-form-trigger,
            .x-form-element.multiselector .x-form-trigger,
            .x-form-element.cardselector .x-form-trigger,
            .x-form-composite .multiselector .x-form-trigger {
                margin-left: 8px;
                border: none;
                background:/*savepage-url=../images/grid/longlist-icon.png*/ url() no-repeat center;
            }
            .x-form-element.accountselector .additional-field,
            .x-form-element.multiselector .additional-field,
            .x-form-element.cardselector .additional-field,
            .x-form-composite .multiselector .additional-field {
                margin-top: 10px;
            }
            .x-form-element.singleselector .x-form-field-wrap.x-form-field-trigger-wrap {
                margin-right: 9px;
            }
            @charset "UTF-8";
            .multiAccountSelector .x-grid3-scroller {
                overflow: auto !important;
                height: auto !important;
                height: 150px;
                max-height: 150px;
            }
            .multiAccountSelector .x-grid3-row-selected {
                background: none transparent !important;
            }
            .multiAccountSelector .x-grid3-header {
                background: none transparent;
                padding: 0;
            }
            .multiAccountSelector .x-grid3-body .x-grid3-td-checker {
                background: none transparent;
                padding: 2px 1px 4px 1px;
            }
            .multiAccountSelector .x-grid3-row-over {
                background-color: #dfdfdf !important;
                background-image: none !important;
            }
            .multiAccountSelector .x-grid3-hd-row td {
                border-left: none;
                border-right: none;
            }
            .multiAccountSelector .x-grid3-hd-inner {
                padding: 4px 3px 4px 7px;
            }
            .multiAccountSelector .x-grid3-cell-inner {
                padding: 4px 3px 4px 5px;
            }
            .mselector-combo-icon {
                width: 13px;
                height: 13px;
                float: left;
                background:/*savepage-url=../images/default/form/checkbox.gif*/ url() no-repeat 0 0;
            }
            .mselector-combo-icon-checked {
                background-position: 0 -13px;
            }
            .mselector-combo-icon-unchecked {
                background-position: 0 0;
            }
            .ext-ie .ux-lovcombo-item-text {
                position: absolute;
                left: 13px;
                top: 3px;
            }
            .ext-ie .mselector-combo-icon {
                float: none;
            }
            .ext-ie .x-combo-list-item {
                position: relative;
            }
            .x-form-invalid.x-form-amountfield {
                border: 1px solid #840b55;
            }
            .x-form-invalid,
            textarea.x-form-invalid {
                background-image: none;
                border: 1px solid #840b55;
            }
            .x-form-invalid-msg {
                background-image:/*savepage-url=../images/errors/warning.gif*/ url();
                color: #840b55;
                padding-top: 3px;
                width: auto;
            }
            #changecontactdetails-accordion-panel .accordionpanel-body .x-form-invalid-msg {
                width: 447px;
            }
            .msg-title-error .details {
                font-weight: normal !important;
            }
            #bov-maturityinstructions-function-container .x-form-invalid-msg {
                width: 200px !important;
            }
            #x-form-el-singlecardselectorforradiogroup .x-form-invalid-msg {
                width: 200px !important;
            }
            .x-form-element.accountfield .x-form-invalid-msg {
                width: 200px !important;
            }
            .bov-error-panel-no-icon .x-panel-body {
                margint-bottom: 10px;
                color: #d92d1a;
                font-size: 12px;
            }
            .bov-error-panel-no-icon .x-panel-body div.bov-tfw-popup-error {
                font-size: 12px;
                font-weight: bold;
            }
            #specialrate-popup-detailpanel {
                font-size: 12px;
            }
            #specialrate-popup-detailpanel .x-panel-body th {
                text-align: right;
                font-weight: bold;
            }
            .ext-ie8 #tfw-specialrate-popup .x-form-element {
                padding: 3px;
            }
            .ext-ie8 #specialrate-popup-input {
                position: relative;
                top: -3px;
            }
            .bov-tfw-result-panel {
                height: auto !important;
                height: 60px;
                font-size: 12px;
                color: #940c61;
            }
            .bov-tfw-result-panel .x-panel-body th {
                text-align: right;
                font-weight: bold;
            }
            .bov-tfw-result-panel .x-panel-body div.tfw-result-message {
                color: #146f22;
            }
            div.accordion-tfw-result-message {
                color: #146f22;
            }
            table.tfw-accordion-result-panel {
                color: #940c61;
            }
            .tfw-mainpanel .xtb-spacer {
                width: 12px;
            }
            .tfw-mainpanel .x-functionbox-bbar {
                margin-top: 15px;
            }
            #tfw-authenticate-popup.bov-info-panel {
                padding: 0;
            }
            #tfw-authenticate-popup .x-form-invalid-msg {
                width: 110px !important;
            }
            #tfw-authenticate-popup #authenticate-popup-challenge {
                color: #98266f !important;
                font-weight: bold;
                padding: 2px;
                opacity: 1;
                background: #d9d9d9;
            }
            .ext-ie #authenticate-popup-challenge {
                height: 22px;
                padding: 0 2px !important;
            }
            #tfw-authenticate-popup label {
                font-weight: bold;
                color: #2c2c2c;
            }
            #tfw-authenticate-popup #authenticate-popup-token {
                background: #98266f;
                border-color: #730c4c;
                border-width: 2px;
                color: #fff;
                font-weight: bold;
            }
            .tfw-infopanel {
                text-align: center;
                font-weight: bold;
                margin-top: 20px;
                margin-bottom: 20px;
            }
            .tfw-infopanel p {
                margin: 10px;
            }
            .tfw-infopanel ul {
                margin-top: 10px;
            }
            .tfw-infopanel ul li {
                line-height: 20px;
            }
            .itempanel-review-panel {
                padding: 8px 2px 2px;
            }
            .itempanel-review-panel .td-label {
                font-weight: bold;
                text-align: right;
                width: 200px;
                line-height: 14px;
                padding: 5px 10px 5px 0;
            }
            .bov-window .x-panel-fbar {
                padding-left: 10px;
            }
            .bov-window.tfw .bov-msg-panel .msg-icon-info,
            .bov-window.tfw .bov-msg-panel .msg-icon-warning,
            .bov-window.tfw .bov-msg-panel .msg-icon-error,
            .bov-window.tfw .bov-msg-panel .msg-icon-success {
                display: none;
            }
            .bov-window.tfw .x-functionbox-ml {
                padding: 15px;
            }
            .bov-window.tfw .x-functionbox-bl {
                padding-bottom: 15px;
            }
            .bov-window.tfw .x-functionbox-tl {
                padding-left: 60px;
                background-color: #363636;
                background-repeat: no-repeat;
                background-position: 10px center;
            }
            .bov-window.tfw.authenticate .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-padlock.png*/ url();
            }
            .bov-window.tfw.declinereason .x-functionbox-tl {
                padding-left: 11px !important;
            }
            .bov-window.tfw.error .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-error.png*/ url();
            }
            .bov-window.tfw.result.failed .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-error.png*/ url();
            }
            .bov-window.tfw.result.processed .x-functionbox-tl,
            .bov-window.tfw.result.pending .x-functionbox-tl,
            .bov-window.tfw.result.modified .x-functionbox-tl,
            .bov-window.tfw.result.processing .x-functionbox-tl,
            .bov-window.tfw.result.valuedated .x-functionbox-tl,
            .bov-window.tfw.result.offline .x-functionbox-tl,
            .bov-window.tfw.result.processed .x-functionbox-tl,
            .bov-window.tfw.result.canceled .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-success.png*/ url();
            }
            .bov-window.tfw.puttoenvelope .x-functionbox-tl,
            .bov-window.tfw.result.parsing .x-functionbox-tl,
            .bov-window.tfw.result.pending .x-functionbox-tl,
            .bov-window.tfw.result.recorded .x-functionbox-tl,
            .bov-window.tfw.result.timedout .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-clock.png*/ url();
            }
            .bov-window.tfw.authenticate .icon-tfw-help {
                background: transparent /*savepage-url=../images/icons/tfw/popup-icon-questionmark.png*/ url() no-repeat
                    left top;
                cursor: pointer;
            }
            .bov-window.tfw.signatories .x-functionbox-tl {
                background-image:/*savepage-url=../images/icons/tfw/popup-icon-add.png*/ url();
            }
            .bov-window.tfw.signatories .x-functionbox-ml {
                padding: 5px;
            }
            .bov-window.tfw.signatories .x-grid-panel {
                margin: 0 0 10px 0;
            }
            .bov-window.tfw.signatories .x-grid3-header-offset {
                padding: 0;
            }
            .bov-window.tfw.signatories .x-grid3-header {
                background-image:/*savepage-url=../images/grid/longlist-hrow-long.png*/ url();
                padding: 0;
            }
            .bov-window.tfw.signatories .bov-gridpanel .x-grid3-hd-inner {
                padding: 6px 3px 6px 8px;
                height: auto;
            }
            .bov-window.tfw.signatories .x-grid3-header * {
                color: #fff;
                font-weight: bold;
            }
            .bov-window.tfw.signatories .x-grid3-hd-inner.x-grid3-hd-signatories-selmodel {
                text-align: center;
            }
            .bov-window.tfw.signatories .x-grid3-hd-inner.x-grid3-hd-signatories-selmodel p {
                width: 17px;
                height: 16px;
                margin: 2px auto;
            }
            .bov-window.tfw.signatories .x-grid3-col.x-grid3-cell {
                border: 1px solid transparent;
                border-width: 0;
            }
            .bov-window.tfw.signatories .x-grid3-cell-inner.x-grid3-col-signatories-selmodel,
            .bov-window.tfw.signatories .x-grid3-hd-inner.x-grid3-hd-signatories-selmodel {
                padding: 3px;
            }
            .bov-window.tfw.signatories .x-grid3-row .x-grid3-row-checker {
                width: 16px;
                margin: 0 auto;
            }
            .bov-window.tfw.signatories .x-functionbox-bl {
                padding-bottom: 5px;
            }
            .bov-window.tfw.result .printoutlink a,
            .bov-window.tfw.puttoenvelope .printoutlink a {
                color: #36f;
                text-decoration: underline;
            }
            .bov-window.tfw.result .x-functionbox-body p,
            .bov-window.tfw.puttoenvelope .x-functionbox-body p {
                font-weight: bold;
                color: #2c2c2c;
            }
            .bov-window.tfw.result .x-functionbox-body p.tr-id,
            .bov-window.tfw.puttoenvelope .x-functionbox-body p.tr-id {
                color: #98266f;
            }
            .bov-window.tfw.result .msg-item {
                margin-bottom: 10px;
            }
            .printicon {
                background-image:/*savepage-url=../images/icons/icon-print.png*/ url();
                background-position: left center;
                background-repeat: no-repeat;
                padding-left: 20px;
                cursor: pointer;
            }
            .bov-window.tfw.authenticate .crontoimagetitle {
                font-weight: bold;
                padding-left: 20px;
            }
            .bov-window.tfw.authenticate .signingdata {
                color: #98266f !important;
                font-weight: bold;
                padding: 2px;
                opacity: 1;
                background: #d9d9d9;
            }
            .bov-window.tfw.authenticate .signingPanelTitle {
                padding-left: 15px;
                padding-right: 15px;
            }
            .bov-window.tfw.authenticate #tfw-authenticate-popup.narrow .signingHelperPanel {
                font-weight: bold;
                padding: 15px;
            }
            .bov-window.tfw.authenticate #tfw-authenticate-popup .signingHelperPanel {
                font-weight: bold;
                padding: 0;
                padding-right: 30px;
                padding-top: 10px;
                padding-bottom: 10px;
            }
            .bov-window.tfw.authenticate .centerSigningPanelTextContentContainer {
                padding: 124px 0 6px 0;
                text-align: center;
            }
            .bov-window.tfw.authenticate .centerSigningPanelTextContentContainer .centerSigningPanelTextContent {
                background: #fff;
                color: #aaa;
                font-size: 24px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 1px;
                padding: 6px 0;
            }
            .bov-window.tfw.authenticate .pushimage {
                background-image:/*savepage-url=../images/icons/push_notification.jpg*/ url();
                width: 100%;
                height: 100px;
                background-size: 100px 100px;
                background-repeat: no-repeat;
                background-position: center;
            }
            .bov-window.tfw.authenticate #authenticate-popup-signingcontainer td {
                padding: 0;
                margin: 0;
            }
            .bov-window.tfw.authenticate .onlyHardwerUseablePanel {
                padding-left: 45px;
                padding-right: 15px;
                padding-bottom: 10px;
                font-weight: bold;
                margin-left: 14px;
                background-repeat: no-repeat;
                background-image:/*savepage-url=../images/icons/msg/icon_warning_inform.png*/ url();
            }
            .bov-window.tfw.authenticate .pushNotificationSentPanel {
                background-image:/*savepage-url=../images/icons/push_notification.jpg*/ url();
                width: 100%;
                height: 40px;
                background-size: 40px 40px;
                background-repeat: no-repeat;
                background-position-x: left;
                background-position-y: top;
                padding-left: 45px;
                margin-left: 13px;
                font-weight: bold;
                padding-bottom: 15px;
            }
            .bov-window.tfw.authenticate .centerSigningPanelContainer {
                position: relative;
                height: 300px;
                margin: 0 10px;
                width: 56px;
            }
            .bov-window.tfw.authenticate .centerSigningPanelLine {
                position: absolute;
                left: 49%;
                top: 0;
                bottom: 0;
                width: 4px;
                margin-left: -2px;
                background: #d9d9d9;
                z-index: -100002;
            }
            .bov-window.tfw.authenticate .horizontalLineContainer {
                padding: 5px 0 10px 0;
            }
            .bov-window.tfw.authenticate .horizontalLine {
                left: 0;
                top: 49%;
                bottom: 0;
                height: 4px;
                margin-top: -2px;
                background: #d9d9d9;
            }
            .bov-window.tfw.authenticate .leftIconContainer .leftIcon1,
            .bov-window.tfw.authenticate .leftIconContainer .leftIcon2,
            .bov-window.tfw.authenticate .rightIconContainer .rightIcon1,
            .bov-window.tfw.authenticate .rightIconContainer .rightIcon2 {
                height: 40px;
                width: 26px;
                position: absolute;
                bottom: 0;
            }
            .bov-window.tfw.authenticate .leftIconContainer,
            .bov-window.tfw.authenticate .rightIconContainer {
                height: 40px;
            }
            .bov-window.tfw.authenticate .leftIconContainer .leftIcon1 {
                background-image:/*savepage-url=../images/login/small_securekey3.png*/ url();
                left: 205px;
            }
            .bov-window.tfw.authenticate .leftIconContainer .leftIcon2 {
                background-image:/*savepage-url=../images/login/small_securekey4.png*/ url();
                left: 245px;
            }
            .bov-window.tfw.authenticate .rightIconContainer .rightIcon1 {
                background-image:/*savepage-url=../images/login/small_securekey2.png*/ url();
                right: 20px;
            }
            .bov-window.tfw.authenticate .rightIconContainer .rightIcon1.dp770 {
                background-image:/*savepage-url=../images/login/small_securekey4.png*/ url();
            }
            .bov-window.tfw.authenticate .rightIconContainer .rightIcon2 {
                background-image:/*savepage-url=../images/login/small_securekey3.png*/ url();
                right: 60px;
            }
            .bov-window.tfw.authenticate #tfw-authenticate-popup.narrow .x-form-invalid-msg {
                width: auto !important;
            }
            .bov-window.tfw.authenticate .crontoImageChangeLink {
                width: 190px;
                padding-left: 15px;
                text-align: center;
            }
            .bov-window.tfw.authenticate .crontoImageChangeLink a {
                font-weight: bold;
                white-space: normal;
            }
            .bov-window.tfw.authenticate .leftIconContainer .cronto-switch {
                cursor: pointer;
            }
            .bov-window.tfw.authenticate .leftIconContainer .leftIcon1.onlymobile {
                left: 245px !important;
            }
            .x-panel-header {
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 18px;
                font-weight: bold;
                background-image: none;
                border: none;
                color: #940c61;
                height: 22px;
                line-height: 22px;
            }
            .bov-form-section-panel .x-panel-header {
                font-size: 14px;
                line-height: 18px;
                height: 18px;
            }
            .bov-form-section-panel .x-panel-header .x-tool {
                background-image:/*savepage-url=../images/default/panel/tool-sprites.gif*/ url();
            }
            div.cheque-image-holder {
                width: 100%;
                height: 100%;
                color: #fff;
                font-size: 14px;
                text-align: center;
                background-color: #ececec;
                padding: 0;
                position: relative;
                cursor: pointer;
                padding-top: 10px;
                padding-bottom: 10px;
            }
            div.cheque-image-holder div.cheque-image-caption {
                margin: 0 0 10px 0;
                padding: 5px;
                color: grey;
                font-weight: bold;
                font-size: 14px;
                text-align: left;
            }
            div.cheque-image-holder div.cheque-image-caption-left,
            div.cheque-image-holder div.cheque-image-caption-right {
                float: left;
                width: 50%;
            }
            div.cheque-image-holder div.cheque-image-caption-left {
                text-align: left;
            }
            div.cheque-image-holder div.cheque-image-caption-right {
                text-align: right;
            }
            div.cheque-image-holder div.clearer {
                clear: both;
            }
            div.cheque-image-holder div.cheque-image-caption span.label {
                font-weight: bold;
            }
            div.bov-image-viewer div.x-panel-bbar .x-toolbar {
                color: #fff;
                border: 0;
                padding: 0;
            }
            div.bov-image-viewer div.x-panel-bbar .x-toolbar .pagingtoolbar-frame {
                width: 100%;
            }
            #imageFullWindow {
                padding: 8px;
            }
            #imageFullWindow .x-toolbar {
                padding: 0;
                border: 0;
            }
            #imageFullWindow .pagingtoolbar-frame {
                width: 100%;
                color: white;
            }
            .bov-view-paging-toolbar .x-toolbar-ct {
                height: 23px;
            }
            .bov-view-paging-toolbar .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-btn-over .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first-dn.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-btn-over .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev-dn.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-btn-over .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next-dn.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-btn-over .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last-dn.png*/ url() !important;
            }
            .bov-view-paging-toolbar .x-btn-icon.x-btn-over {
                background-color: transparent;
            }
            .bov-view-paging-toolbar .x-panel-bl {
                display: none;
            }
            .bov-view-paging-toolbar .x-toolbar div.xtb-text {
                padding: 0 4px;
            }
            .bov-view-button-toolbar {
                padding-top: 8px;
                background-color: #fff;
            }
            .bov-view-button-toolbar .x-btn {
                float: right;
            }
            .bov-view-imagecaption {
                background-color: #b7b7b7;
                color: #fff;
                font-size: 14px;
            }
            .bov-view-imagecaption .bov-view-imagecaption-left {
                float: left;
                margin: 15px 0 15px 20px;
            }
            .bov-view-imagecaption .bov-view-imagecaption-right {
                float: right;
                margin: 15px 20px 15px 0;
            }
            .bov-view-imagecaption span.label {
                font-weight: bold;
            }
            div.cheque-image-holder-full {
                width: 100%;
                height: 100%;
                color: #fff;
                font-size: 14px;
                text-align: center;
                background-color: #b7b7b7;
                padding: 0;
            }
            div.cheque-image-holder-full .cheque-image-holder-full-inner {
                width: 100%;
                height: 100%;
                position: relative;
                overflow: auto;
            }
            div.cheque-image-holder-full .cheque-image-full {
                position: absolute;
                margin: auto;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
            }
            #bov-image-viewer-printbutton {
                float: right;
                margin-top: 8px;
            }
            #Bov-accounts-viewchequeimages-searchform .bov-accordion-panel .item-panel .x-panel-fbar {
                padding: 0;
            }
            #chequeImageSideSelector {
                padding: 0;
            }
            #Bov-accounts-viewchequeimages-chequeselector .x-form-display-field {
                padding-left: 0;
            }
            .x-panel-header {
                font-family: "Trebuchet MS", Arial, Verdana, Helvetica, sans-serif;
                font-size: 18px;
                font-weight: bold;
                background-image: none;
                border: none;
                color: #940c61;
                height: 22px;
                line-height: 22px;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar {
                background: none #550236;
                color: #fff;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar .x-tbar-page-first {
                background-image:/*savepage-url=../images/default/grid/page-first.gif*/ url() !important;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar .x-tbar-page-last {
                background-image:/*savepage-url=../images/default/grid/page-last.gif*/ url() !important;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar .x-tbar-page-prev {
                background-image:/*savepage-url=../images/default/grid/page-prev.gif*/ url() !important;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar .x-tbar-page-next {
                background-image:/*savepage-url=../images/default/grid/page-next.gif*/ url() !important;
            }
            div#viewstatementimages-imageviewer-panel .x-toolbar .xtb-sep {
                background-image:/*savepage-url=../images/default/grid/tbar-separator.gif*/ url();
            }
            .viewstatementimages-radiolabel {
                font-size: 12px;
            }
            .bov-listview {
                margin-right: 1px;
                border-color: #cbcbcb;
                border-width: 0 1px 0 0;
                border-style: solid;
            }
            .bov-listview .x-list-body {
                border-color: #cbcbcb;
                border-width: 1px;
                border-style: solid;
                background-color: white;
            }
            #viewstatementimages-filter-accordionpanel.bov-accordion-panel .item-panel .x-panel-fbar {
                padding: 0;
            }
            #viewstatementimages-filter-mainPanel .x-panel-footer.x-panel-btns {
                padding-left: 0;
                padding-right: 0;
            }
            #viewstatementimages-filter-mainPanel .x-panel-footer.x-panel-btns td.x-toolbar-cell {
                padding-left: 0;
                padding-right: 0;
            }
            div.imageviewer-image-holder {
                width: 100%;
                height: 100%;
                color: #fff;
                font-size: 14px;
                text-align: center;
                background-color: #b7b7b7;
                padding: 0;
                position: relative;
                cursor: pointer;
            }
            div.imageviewer-image-holder div.imageviewer-image-caption {
                margin: 0 0 10px 0;
                padding: 5px;
                color: #fff;
                font-size: 14px;
                text-align: left;
            }
            div.imageviewer-image-holder div.imageviewer-image-caption-left,
            div.imageviewer-image-holder div.imageviewer-image-caption-right {
                float: left;
                width: 50%;
            }
            div.imageviewer-image-holder div.imageviewer-image-caption-left {
                text-align: left;
            }
            div.imageviewer-image-holder div.imageviewer-image-caption-right {
                text-align: right;
            }
            div.imageviewer-image-holder div.clearer {
                clear: both;
            }
            div.imageviewer-image-holder div.imageviewer-image-caption span.label {
                font-weight: bold;
            }
            div.bov-imageviewer div.x-panel-bbar .x-toolbar {
                color: #fff;
                border: 0;
                padding: 0;
            }
            div.bov-imageviewer div.x-panel-bbar .x-toolbar .pagingtoolbar-frame {
                width: 100%;
            }
            .imageviewer-fullwindow {
                padding: 8px;
            }
            .imageviewer-fullwindow .x-toolbar {
                padding: 0;
                border: 0;
            }
            .imageviewer-fullwindow .pagingtoolbar-frame {
                width: 100%;
                color: white;
            }
            .bov-imageviewer-paging-toolbar .x-toolbar-ct {
                height: 23px;
            }
            .bov-imageviewer-paging-toolbar .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-btn-over .x-tbar-page-first {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-first-dn.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-btn-over .x-tbar-page-prev {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-prev-dn.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-btn-over .x-tbar-page-next {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-next-dn.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-btn-over .x-tbar-page-last {
                background-image:/*savepage-url=../images/grid/pager/icon-pager-last-dn.png*/ url() !important;
            }
            .bov-imageviewer-paging-toolbar .x-btn-icon.x-btn-over {
                background-color: transparent;
            }
            .bov-imageviewer-paging-toolbar .x-panel-bl {
                display: none;
            }
            .bov-imageviewer-paging-toolbar .x-toolbar div.xtb-text {
                padding: 0 4px;
            }
            .imageviewer-button-toolbar {
                padding-top: 8px;
                background-color: #fff;
            }
            .imageviewer-button-toolbar .x-btn {
                float: right;
            }
            .imageviewer-imagecaption {
                background-color: #b7b7b7;
                color: #fff;
                font-size: 14px;
            }
            .imageviewer-imagecaption .imageviewer-imagecaption-left {
                float: left;
                margin: 15px 0 15px 20px;
            }
            .imageviewer-imagecaption .imageviewer-imagecaption-right {
                float: right;
                margin: 15px 20px 15px 0;
            }
            .imageviewer-imagecaption span.label {
                font-weight: bold;
            }
            div.imageviewer-image-holder-full {
                width: 100%;
                height: 100%;
                color: #fff;
                font-size: 14px;
                text-align: center;
                background-color: #b7b7b7;
                padding: 0;
            }
            div.imageviewer-image-holder-full .imageviewer-image-holder-full-inner {
                width: 100%;
                height: 100%;
                position: relative;
                overflow: auto;
            }
            div.imageviewer-image-holder-full .imageviewer-image-full {
                margin: auto;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
            }
            .imageviewer-button-left.x-btn {
                float: left;
                margin-right: 8px;
            }
            .imageviewer-button-right.x-btn {
                float: right;
                margin-left: 8px;
            }
            #bov-imageviewer-printbutton {
                float: right;
                margin-top: 8px;
            }
            .bov-accordion-panel .x-form-item.bov-form-item-nomargin {
                margin-bottom: 0;
            }
            .bov-accordion-panel .x-panel.bov-form-item-margin {
                margin-bottom: 8px;
            }
            .viewbalances-creditfacilitygrid-agreementnumber-link {
                text-decoration: underline;
                color: #940c61 !important;
                cursor: pointer;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-viewbalances-loangrid-accounttype .account-avatar-ct,
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-viewbalances-grid-accounttype .account-avatar-ct,
            .bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-viewbalances-gridaccountscreditfacility-accounttype
                .account-avatar-ct {
                float: left;
                padding-right: 10px;
                text-align: center;
                width: 50px;
                height: 18px;
            }
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-viewbalances-loangrid-accounttype .account-avatar-ct,
            .bov-gridpanel .x-grid3-cell-inner.x-grid3-col-viewbalances-grid-accounttype .account-avatar-ct,
            .bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-viewbalances-gridaccountscreditfacility-accounttype
                .account-avatar-ct {
                width: 18px;
            }
            .x-grid3-td-viewbalances-grid-accounttype > div {
                position: relative;
                padding-left: 30px;
            }
            .bov-gridpanel .x-grid3-td-viewbalances-grid-accounttype .account-avatar-ct {
                position: absolute;
                left: 6px;
                top: 0;
            }
            .bov-gridpanel .x-grid3-td-viewbalances-creditgrid-agreementnumber .x-grid3-cell-inner {
                padding-left: 9px;
            }
            .x-grid3-td-viewbalances-loangrid-accounttype > div {
                position: relative;
                padding-left: 30px;
            }
            .bov-gridpanel .x-grid3-td-viewbalances-loangrid-accounttype .account-avatar-ct {
                position: absolute;
                left: 6px;
                top: 0;
            }
            .x-grid3-td-viewbalances-gridaccountscreditfacility-accounttype > div {
                position: relative;
                padding-left: 30px;
            }
            .bov-gridpanel .x-grid3-td-viewbalances-gridaccountscreditfacility-accounttype .account-avatar-ct {
                position: absolute;
                left: 6px;
                top: 0;
            }
            .transactions-panel {
                padding-top: 10px;
                padding-bottom: 20px;
            }
            .viewtransactions-details-accountinfo-itemcls {
                margin-bottom: 0;
            }
            .viewtransactions-details-accountinfo-itemcls label.x-form-item-label {
                padding-bottom: 0;
                padding-top: 0;
            }
            .viewtransactions-details-accountinfo-itemcls div div {
                padding-top: 0;
            }
            .viewtransactions-printall-panel {
                padding-top: 10px;
            }
            .bovdaterangefield-item .x-form-field-wrap {
                width: auto !important;
            }
            #viewtransactions-details-accountinfo .viewtransactions-details-accountinfo-itemcls {
                line-height: 1.3;
            }
            .ext-safari #viewtransactions-details-accountinfo .viewtransactions-details-accountinfo-itemcls,
            .ext-ie8 #viewtransactions-details-accountinfo .viewtransactions-details-accountinfo-itemcls {
                line-height: 1.35;
            }
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell-inner.x-grid3-col-viewtransactions-accountgrid-details,
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell-inner.x-grid3-col-viewtransactions-cardgrid-details,
            .bov-gridpanel .x-grid3-row-table .x-grid3-cell-inner.x-grid3-col-viewtransactions-creditgrid-details {
                white-space: pre-wrap;
            }
            .ext-ie10 .viewtransactions-details-accountinfo-container,
            .ext-ie11 .viewtransactions-details-accountinfo-container {
                width: auto !important;
            }
            .viewtransactions-details-accountinfo-container {
                padding-left: 4px;
            }
            .bov-payments div.disabled * {
                color: gray !important;
            }
            .bov-payments .warning {
                background: transparent /*savepage-url=../images/default/icon/icon_error.png*/ url() no-repeat top left;
                padding-left: 30px;
                font-size: 14px;
                color: #d92d1a;
                margin: 10px;
            }
            .bov-payments .bov-xchange-amount-column {
                width: 250px !important;
            }
            .orderforeigncash-amountfield .x-form-radio-inner {
                display: inline-block;
                position: relative;
                top: 0;
                left: 0;
            }
            .orderforeigncash-amountfield label.x-form-cb-label {
                padding-right: 0;
            }
            #paythirdparties-bic_search {
                padding-left: 10px;
                line-height: 22px;
            }
            .chequenumber-field-panel {
                margin-bottom: 0;
            }
            .chequenumber-field-panel .x-form-item {
                margin-bottom: 0;
            }
            .chequenumber-field-panel .chequenumber-sideselector-group {
                border: 1px solid transparent;
            }
            .chequenumber-field-panel .chequenumber-sideselector-group.x-form-invalid-group {
                padding: 0;
                border: 1px solid #c30;
            }
            #x-form-el-paythirdparties-i-beneficiaryname span {
                float: right;
                padding-top: 2px;
            }
            #paythirdparties-paythirdpartiesform .x-tip.bov {
                z-index: 202;
            }
            #x-form-el-bicCode .x-form-invalid-msg {
                width: auto !important;
            }
            #paythirdparties-bankpanel .bankpanel-compositefield .x-form-invalid-msg {
                margin-left: 230px;
            }
            #paythirdparties-dateselectorpanel .x-link-btn.bluelink.x-btn-noicon.x-box-item {
                padding-top: 3px;
            }
            #paythirdparties-dateselectorpanel .x-link-btn.bluelink a,
            #paythirdparties-dateselectorpanel .x-link-btn.bluelink a:visited {
                color: #36f;
            }
            #billpayment-detailspanel
                .accordionpanel-body
                .x-form-item
                .x-form-field-wrap.x-form-field-trigger-wrap
                .info-bubble-icon {
                margin-left: 15px;
            }
            @charset "UTF-8";
            #manageusers-main-panel .x-action-col-icon {
                margin: 1px 3px;
            }
            #manageusers-main-panel .x-grid3-col-transactionmanagement-result-authorise-operation {
                padding-left: 11px;
            }
            #manageusers-main-panel .x-action-col-icon {
                width: 15px;
                height: 15px;
            }
            #manageusers-main-panel .x-action-col-icon.inactive {
                cursor: default;
            }
            #manageusers-main-panel .x-action-col-icon.moduser {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #manageusers-main-panel .x-action-col-icon.deluser {
                background: transparent /*savepage-url=../images/icons/ikon_x_16x16.png*/ url() no-repeat top left;
            }
            #manageusers-main-panel .x-action-col-icon.deluser.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_x_inaktiv_16x16.png*/ url() no-repeat top
                    left;
            }
            #manageusers-main-panel .x-action-col-icon.modfunctions {
                background: transparent /*savepage-url=../images/icons/icon_hammer_16x16.png*/ url() no-repeat top left;
            }
            #manageusers-main-panel .x-action-col-icon.moduserrights {
                background: transparent /*savepage-url=../images/icons/ikon_pajzsos_16x16.png*/ url() no-repeat top left;
            }
            #manageusers-main-panel .x-action-col-icon.moduserrights.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_pajzsos_inactive_16x16.png*/ url() no-repeat
                    top left;
            }
            #bov-manageusers #manageusers-userdataform .panel-info {
                font-size: 12px;
                margin: 10px 0;
            }
            #bov-manageusers-function-mainpanel .accordionpanel-header .headtitle {
                font-weight: bold;
            }
            #bov-manageusers-function-mainpanel .warning {
                background: transparent /*savepage-url=../images/default/icon/icon_error.png*/ url() no-repeat top left;
                padding-left: 30px;
                font-size: 14px;
                color: #d92d1a;
                margin: 10px;
            }
            #manageusers-accordion-panel .x-panel.x-masked .ext-el-mask {
                background-color: #ececec !important;
            }
            #bov-manageusers .resultpanel {
                font-size: 12px;
                margin: 15px 100px 30px 100px;
            }
            #bov-manageusers .resultpanel .x-grid-panel {
                margin: 10px 0 20px 0;
            }
            #bov-manageusers .printout-link-ct {
                margin-bottom: 10px;
            }
            #bov-manageusers .x-form-check-wrap {
                max-width: 300px;
            }
            #bov-manageusers #manageusers-specialsettingspanel-innerpanel .x-form-item-label {
                height: 16px;
            }
            #manageusers-addresspanel .panel-info {
                margin-bottom: 10px;
            }
            #manageusers-affectedtransaction-grid {
                margin-top: 20px;
            }
            #manageusers-affectedtransaction-messagepanel {
                margin-top: 20px;
            }
            @charset "UTF-8";
            #accountrights-main-panel .x-action-col-icon {
                margin: 1px 3px;
            }
            #accountrights-main-panel .x-action-col-icon {
                width: 15px;
                height: 15px;
            }
            #accountrights-accountgrid .x-grid3-col-accountrights-accountgrid-operation {
                padding-left: 11px;
            }
            #accountrights-accountgrid .x-action-col-icon.modify {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #accountrights-functiongrid .x-action-col-icon.modify {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #accountrights-modifygrid .x-action-col-icon.delete {
                background: transparent /*savepage-url=../images/icons/ikon_x_16x16.png*/ url() no-repeat top left;
                width: 15px;
                height: 15px;
            }
            .accountrights-toolbarbutton .x-btn button {
                color: #fff;
                text-decoration: none;
            }
            .accountrights-toolbarbutton .x-btn-over button {
                color: #fff;
                text-decoration: underline;
            }
            #accountrights-modify-panel-buttoncontainer {
                margin-top: 20px;
            }
            #accountrights-modify-panel-functioncontainer,
            #accountrights-modify-panel-functionreviewcontainer {
                margin-top: 20px;
                margin-bottom: 20px;
            }
            #accountrights-modify-panel-accountcontainer {
                margin-top: 20px;
                margin-bottom: 20px;
            }
            .accountrights-account-details-panel {
                padding-bottom: 20px;
            }
            .accountrights-modify-panel .x-grid3-col-accountrights-modifygrid-operation input {
                vertical-align: middle;
            }
            #accountrights-affectedtransaction-grid {
                margin-bottom: 20px;
            }
            @charset "UTF-8";
            #userrights-main-panel .x-action-col-icon {
                margin: 1px 3px;
            }
            #userrights-main-panel .x-action-col-icon {
                width: 15px;
                height: 15px;
            }
            #userrights-accountgrid .x-grid3-col-userrights-accountgrid-operation {
                padding-left: 11px;
            }
            #userrights-accountgrid .x-action-col-icon.modify {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #userrights-modify-panel .warning {
                background: transparent /*savepage-url=../images/default/icon/icon_error.png*/ url() no-repeat top left;
                padding-left: 30px;
                font-size: 14px;
                color: #d92d1a;
                margin: 10px;
            }
            #userrights-main-panel .linkBtn {
                font-size: 11px;
                margin: 0 10px;
            }
            #userrights-main-panel .x-masked-relative {
                position: absolute !important;
            }
            #userrights-functiongrid .x-action-col-icon.modify {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            .userrights-details-panel {
                padding-bottom: 20px;
            }
            .userrights-overview-panel-buttoncontainer {
                margin-top: 15px;
                margin-bottom: 5px;
                float: right;
            }
            #userrights-affectedtransaction-grid {
                margin-top: 20px;
            }
            #userrights-affectedtransaction-messagepanel {
                margin-top: 20px;
            }
            @charset "UTF-8";
            #exchangeLabel1,
            #exchangeFiller,
            #exchangeLabel2 {
                color: #006;
                font-size: 24px;
            }
            #newConversionLinkBox {
                cursor: pointer;
            }
            div#exchangeRateResult td.x-table-layout-cell.exchangeRateCellRight {
                text-align: right;
            }
            #currencyconverter-targetamount-table {
                text-align: center;
            }
            #currencyconverter-panel-container-space {
                background-image:/*savepage-url=../images/currencyconverter/currency_greyarrow.png*/ url();
                background-repeat: no-repeat;
                background-size: contain;
            }
            #currencyconverter-panel-container-inputs {
                background-image:/*savepage-url=../images/currencyconverter/currency_greyline.png*/ url();
                background-repeat: repeat;
                padding: 4px;
            }
            .currencyconverter-sourceamount-table-amount {
                padding-top: 2px;
                vertical-align: top;
            }
            .currencyconverter-sourceamount-table-button {
                vertical-align: top;
            }
            #currencyconverter-calculatebutton.x-btn td.x-btn-mc {
                padding: 0 !important;
            }
            #bov-exchangerate .bannertext {
                text-align: left;
                padding-left: 30px;
                padding-right: 30px;
                margin-top: 20px;
                font-weight: bold;
                color: solid black;
            }
            label#cardTopPanelLabel {
                font-weight: bold;
                color: solid black;
            }
            #amountFieldPanel div .x-form-item LABEL.x-form-item-label {
                margin-right: 6px;
            }
            #exchangeRateMainpanel .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            #currencyconverter-termslink-panel {
                text-align: center;
            }
            .x-help-mainct {
                background: #fff;
                padding: 5px;
            }
            .x-help-panel {
                background-color: #ececec;
                border: 1px solid grey;
                border-radius: 5px 5px 15px 0;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif !important;
                font-size: 12px;
            }
            .x-help-panel-white {
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif !important;
                font-size: 12px;
            }
            .x-help-panel-header {
                background-color: #545454;
                height: 20px;
                padding: 10px;
                color: white;
                font-size: 14px;
                font-weight: bold;
            }
            .x-help-mainct .x-panel-header {
                height: 20px;
                padding: 10px;
                font-size: 14px;
                font-weight: bold;
            }
            .x-help-panel-body,
            .x-panel-body.x-help-panel-blank {
                padding: 10px;
                line-height: 16px;
            }
            .x-help-link {
                background-image:/*savepage-url=../images/preferencesbox/preferencesbox-linkbg.png*/ url() !important;
                background-repeat: no-repeat;
                padding-left: 20px;
                line-height: 24px;
            }
            .info-tooltip {
                width: 20px;
                line-height: 14px;
                font-size: 11px;
                text-align: center;
                font-family: arial;
                background: transparent /*savepage-url=../images/qtip/infotooltip-btn-bg.png*/ url() repeat-x 0 0;
                color: #fff;
                margin-right: 3px;
                cursor: pointer;
            }
            @charset "UTF-8";
            #increasecreditlimit-accordion-panel .x-panel div.headtitle {
                min-width: 30%;
            }
            #increasecreditlimit-increaseinstructionpanel .radio label {
                padding-right: 10px;
            }
            #increasecreditlimit-increaseinstructionpanel .temporaryradio-bovdaterangefield .bovdaterangefield-item {
                margin-bottom: 0;
            }
            #increasecreditlimitform .x-form-item.displayfield-item label {
                padding-top: 2px;
                padding-bottom: 0;
            }
            #increasecreditlimitform .x-form-item.displayfield-item .x-form-display-field.displayfield {
                padding-top: 2px;
            }
            #increasecreditlimitform .x-form-item.radio-item {
                margin-bottom: 0;
            }
            @charset "UTF-8";
            #stoppayment-resulttable {
                margin: auto;
                text-align: center;
                border-collapse: collapse;
                width: 80%;
            }
            #stoppayment-resulttable th {
                background-color: #ededed;
                font-weight: bold;
                text-align: center;
            }
            #stoppayment-resulttable tr.even {
                background-color: #ededed;
            }
            #stoppayment-instruction-div {
                margin-top: 15px;
                margin-bottom: 10px;
                font-size: 16px;
                font-weight: bold;
                text-align: center;
            }
            #stoppayment-delete-window .x-grid3-td-checker {
                padding: 0;
            }
            #stoppayment-delete-window .x-grid3-hd-checker {
                position: relative;
                left: 5px;
                width: 15px;
            }
            #stoppayment-delete-window .x-grid3-row-checker {
                position: relative;
                left: 6px;
                width: 15px;
            }
            .ext-safari #stoppayment-delete-window .x-grid3-row-checker {
                left: 5px;
            }
            #stoppayment-delete-window .header-label .x-grid3-hd-checker {
                display: none;
            }
            @charset "UTF-8";
            .bov-accordion-panel .item-panel.locked .accordionpanel-header * {
                cursor: default;
            }
            .bov-accordion-panel .item-panel.overflowvisible {
                overflow: visible !important;
            }
            #maturityinstructions-taxchooser {
                padding-bottom: 0;
            }
            .bov-accordion-panel .noformitemmargin {
                margin-bottom: 0;
            }
            .bov-accordion-panel .formitemmargin {
                margin-bottom: 8px;
            }
            #x-form-el-maturityinstructions-dontrenewtransfertoaccountselector {
                padding-bottom: 6px;
            }
            .x-form-radio-group.radiogroup-invalidmarker-nobackground {
                background-color: transparent;
            }
            #bov-maturityinstructions-function-mainpanel
                .bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 35%;
            }
            #bov-loancalculator .x-fieldset {
                padding: 10px !important;
            }
            #bov-topup-changetopupdetails div.ib-btn-group {
                margin-bottom: 20px !important;
            }
            #bov-registerformobiletopup-function-mainpanel
                .bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 40%;
            }
            .termsandconditions-panel .x-panel-body {
                border: 1px solid black;
            }
            .termsandconditions-iframe {
                width: 100%;
                height: 350px;
                display: block;
                border: 0 solid black;
            }
            .changetopupdetails-selection-panel-inner {
                margin-left: auto;
                margin-right: auto;
            }
            .changetopupdetails-selection-panel .bov-selectionbutton-title {
                color: #000;
                font-size: 14px;
                font-weight: bold;
                min-height: 24px;
                overflow: hidden;
                text-align: center;
                text-overflow: ellipsis;
            }
            .changetopupdetails-selection-panel .bov-selectionbutton-description {
                color: #545454;
                font-size: 12px;
                min-height: 30px;
                padding: 10px 0 0 0;
                text-align: center;
            }
            .changetopupdetails-selection-panel .selection_btn .btn-tooltip > div {
                width: 20px;
                line-height: 14px;
                font-size: 11px;
                text-align: center;
                font-family: arial;
                background: transparent /*savepage-url=../images/menu/distributionpage/landingpagebtn-info-bg.png*/
                    url() repeat-x 0 0;
                color: #fff;
                margin-right: 3px;
                cursor: pointer;
            }
            .changetopupdetails-selection-panel .selection_btn {
                margin: 0 12px 6px 0;
            }
            .changetopupdetails-selection-panel .selection_btn.last {
                margin-right: 0;
            }
            .changetopupdetails-selection-panel .x-btn-mc {
                white-space: normal;
                height: 120px;
            }
            .changetopupdetails-selection-panel .selection_btn .x-btn-mc {
                vertical-align: top;
            }
            .changetopupdetails-selection-panel .selection_btn .x-btn-text {
                padding: 10px;
                height: auto !important;
                text-align: left;
                white-space: normal;
                width: 100%;
            }
            .ext-ie .changetopupdetails-selection-panel .selection_btn .x-btn-text {
                padding-top: 10px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-tl {
                background-position: -16px 0;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-tr {
                background-position: -20px 0;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-tc {
                background-position: 0 -24px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-ml {
                background-position: -16px -32px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-mr {
                background-position: -20px -32px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-mc {
                background-position: 0 -3240px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-bl {
                background-position: -16px -4px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-br {
                background-position: -20px -4px;
            }
            .changetopupdetails-selection-panel .selection_btn.active .x-btn-bc {
                background-position: 0 -28px;
            }
            table.sla-details {
                width: 100%;
                padding: 20px;
                table-layout: auto;
            }
            table.sla-details tr td:nth-child(1) {
                text-align: right;
                font-weight: bold;
                width: 1px;
                min-width: 200px;
                white-space: nowrap;
            }
            table.sla-details tr td:nth-child(2) {
                padding-left: 10px;
            }
            #bov-managefunctions table.user-info {
                padding: 20px 0 0 20px;
            }
            #bov-managefunctions table.user-info tr td:first-child {
                padding-right: 10px;
            }
            .managefunctions-details-panel {
                padding-bottom: 20px;
            }
            #bov-managefunctions-function-mainpanel .x-grid3-hd-checker {
                position: relative;
                left: 5px;
                width: 15px;
            }
            #bov-managefunctions-function-mainpanel .x-grid3-row-checker {
                position: relative;
                left: 5px;
                width: 15px;
            }
            table.bov-template-details th,
            table.bov-template-details td {
                padding: 3px 5px;
            }
            table.bov-template-details th {
                text-align: right;
                font-weight: bold;
            }
            #templatemgnt_create_link_container {
                margin-top: 20px;
            }
            .bov-templatedetail-container {
                padding: 5px;
            }
            .bov-templatedetail-container-btn {
                float: right;
                margin: 0 5px;
            }
            .x-grid3-cell-inner.x-grid3-col-templatemgmt-listgrid-summary {
                padding-right: 20px;
            }
            #side-ct .bov-accordion-panel.templatemanagement-filter .item-panel .accordionpanel-header .headtitle {
                width: auto;
                margin-right: 5px;
            }
            .bov-window.noheader .x-functionbox-tl {
                padding: 0 10px;
                background-color: transparent;
            }
            .bov-window.noheader .x-functionbox-bl,
            .bov-window.noheader .x-functionbox-ml,
            .bov-window.noheader p.panel-subtitle {
                padding: 0;
            }
            .bov-window.noheader .x-functionbox-ml .x-functionbox-body {
                padding: 10px;
            }
            .bov-window.noheader .x-functionbox-header-text,
            .bov-window.noheader .x-functionbox-header-text p {
                line-height: 1em;
                color: #2c2c2c;
            }
            #smsalerts-accordion-panel.bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                width: 80%;
            }
            #smsalerts-accordion-panel.bov-accordion-panel .boxtext {
                padding-top: 3px;
            }
            .smsalerts .bov-gridpanel.x-grid-panel.review {
                padding-top: 18px;
            }
            .smsalerts .x-grid3-cell-inner.x-grid3-col-checker {
                width: 18px;
                margin: 0 auto;
            }
            .smsalerts .x-item-disabled a:hover {
                text-decoration: none;
            }
            .smsalerts .x-item-disabled .x-form-trigger-over.x-link-btn {
                border-bottom: none;
            }
            #smsalerts-accordion-panel .itempanel-review-panel .td-value > div {
                padding-top: 3px;
            }
            .bov-gridpanel .spacer {
                margin: 0 10px;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-smsalerts-grid-operation {
                height: 15px;
            }
            #bov-smsalerts-smsalertsform #smsalerts-accordion-panel .bov-gridpanel .x-action-col-icon {
                margin: 1px 3px;
            }
            #bov-smsalerts-smsalertsform #smsalerts-accordion-panel .bov-gridpanel .x-action-col-icon {
                width: 15px;
                height: 15px;
            }
            #bov-smsalerts-smsalertsform #smsalerts-accordion-panel .bov-gridpanel .x-action-col-icon {
                cursor: pointer;
            }
            #bov-smsalerts-smsalertsform #smsalerts-accordion-panel .bov-gridpanel .x-action-col-icon.inactive {
                cursor: default;
            }
            #bov-smsalerts-smsalertsform #smsalerts-accordion-panel .bov-gridpanel .x-action-col-icon.view-recipients {
                background: transparent /*savepage-url=../images/icons/magnifier2_26x26.png*/ url() no-repeat top left;
                background-size: 15px;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.view-recipients.inactive {
                background: transparent /*savepage-url=../images/icons/magnifier2_26x26_inactive.png*/ url() no-repeat
                    top left;
                background-size: 15px;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.modify-recipients {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.modify-recipients.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16_inactive.png*/ url() no-repeat
                    top left;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.create-recipients {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.create-recipients.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16_inactive.png*/ url() no-repeat
                    top left;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.delete-recipients {
                background: transparent /*savepage-url=../images/icons/ikon_x_16x16.png*/ url() no-repeat top left;
            }
            #bov-smsalerts-smsalertsform
                #smsalerts-accordion-panel
                .bov-gridpanel
                .x-action-col-icon.delete-recipients.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_x_inaktiv_16x16.png*/ url() no-repeat top
                    left;
            }
            .longlist.bov-window .x-panel.smsalerts-aftergridcontainer .x-form-item {
                margin: 0 auto;
                width: 55%;
                padding: 15px 15px 0;
            }
            #bov-smsalerts-smsalertsform
                .bov-accordion-panel
                .bov-gridpanel
                .bov-scopebar.x-toolbar.x-small-editor
                .x-form-field-wrap {
                width: 200px !important;
            }
            #bov-smsalerts-smsalertsform
                .bov-accordion-panel
                .bov-gridpanel
                .bov-scopebar.x-toolbar.x-small-editor
                input {
                width: 163px !important;
            }
            #bov-smsalerts-smsalertsform
                .bov-accordion-panel
                .bov-gridpanel
                .bov-scopebar.x-toolbar.x-small-editor
                input.notempty {
                width: 147px !important;
            }
            #smscontacts-contactspanel .itempanel-review-panel .td-label {
                padding: 5px 10px 0 0;
            }
            #smsalerts-accordion-panel .itempanel-review-panel tr:not(:first-child) .td-label,
            #smscontacts-contactspanel .itempanel-review-panel tr:not(:first-child) .td-label {
                padding: 20px 10px 0 0;
            }
            #smsalerts-accordion-panel .itempanel-review-panel tr:not(:first-child) .td-label ~ .td-value,
            #smscontacts-contactspanel .itempanel-review-panel tr:not(:first-child) .td-label ~ .td-value {
                padding-top: 20px;
            }
            #linkcashlinkcard-linkedaccountsgrid.bov-gridpanel .x-grid3-row-over {
                background-color: #f8f8f8 !important;
                border-color: #f8f8f8 !important;
            }
            #linkcashlinkcard-linkedaccountsgrid.bov-gridpanel .x-grid3-row-over.x-grid3-row-alt {
                background-color: #e8e8e8 !important;
                border-color: #e8e8e8 !important;
            }
            .noticeaccountinstructions-beneficiary {
                color: grey;
            }
            .x-viewport body {
                overflow-y: scroll;
            }
            *,
            a,
            a:active,
            a:focus {
                outline: 0;
            }
            input[type="text"]::-ms-clear,
            input[type="password"]::-ms-reveal {
                display: none;
                width: 0;
                height: 0;
                color: transparent;
            }
            body.ext-chrome {
                height: 100px;
            }
            .ext-el-mask {
                background-color: #363636;
                opacity: 0.5;
            }
            .ext-el-mask-msg {
                background: none repeat scroll 0 0 gray;
                border-color: #000;
            }
            .ext-el-mask-msg div {
                border-color: #000;
            }
            .x-tool {
                background-image:/*savepage-url=../images/default/panel/tool-sprites.gif*/ url();
                height: 16px;
                width: 16px;
            }
            .maroon {
                color: #840b55;
            }
            .system-font {
                font-size: 12px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font-mini {
                font-size: 10px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font-small {
                font-size: 11px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font-large {
                font-size: 14px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font-extra-large {
                font-size: 18px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font-mega {
                font-size: 36px !important;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-weight: normal;
            }
            .system-font.bold,
            .system-font-mini.bold,
            .system-font-small.bold,
            .system-font-large.bold,
            .system-font-extra-large.bold,
            .system-font-mega.bold {
                font-weight: bold;
            }
            .bov-info-panel {
                background: transparent /*savepage-url=../images/default/icon/icon_big_info.png*/ url() no-repeat top
                    left;
                padding-left: 40px;
            }
            .bov-warning-panel {
                background: transparent /*savepage-url=../images/default/icon/icon_big_warning.png*/ url() no-repeat top
                    left;
                padding-left: 40px;
                color: #ff8c00;
            }
            .bov-error-panel {
                background: transparent /*savepage-url=../images/default/icon/icon_big_alert.png*/ url() no-repeat top
                    left;
                padding-left: 40px;
                color: #d92d1a;
            }
            .bov-info-panel,
            .bov-warning-panel,
            .bov-error-panel {
                font-size: 12px;
                font-family: sans-serif;
                font-weight: normal;
            }
            .bov-message-panel-title {
                font-weight: bold;
            }
            span.printout a {
                font-size: 11px;
            }
            .x-panel-collapsed .x-fieldset-header .x-tool-toggle-over {
                background-position: -16px -80px;
            }
            .x-panel-collapsed .x-fieldset-header .x-tool-toggle {
                background-position: 0 -80px;
            }
            .x-fieldset-header .x-tool-toggle-over {
                background-position: -16px -64px;
            }
            .x-fieldset-header .x-tool-toggle {
                background-position: 0 -64px;
            }
            .x-tool-close-over {
                background-position: -16px 0;
            }
            .x-tool-help {
                background-position: 0 -320px;
            }
            .x-tool-help-over {
                background-position: -16px -320px;
            }
            .x-tool-pin-over {
                background-position: -16px -144px;
            }
            .x-tool-pin {
                background-position: 0 -144px;
            }
            .x-tool-unpin-over {
                background-position: -16px -160px;
            }
            .x-tool-unpin {
                background-position: 0 -160px;
            }
            .x-tool-toggle,
            .x-accordion-hd .x-tool-toggle {
                background-position: 0 -272px;
            }
            .x-tool-toggle-over,
            .x-accordion-hd .x-tool-toggle-over {
                background-position: -16px -272px;
            }
            .x-panel-collapsed .x-tool-toggle,
            .x-panel-collapsed .x-accordion-hd .x-tool-toggle {
                background-position: -16px -256px;
            }
            .x-panel-collapsed .x-tool-toggle-over,
            .x-panel-collapsed .x-accordion-hd .x-tool-toggle-over {
                background-position: 0 -256px;
            }
            .positive-amount,
            .amount-debit {
                color: #59b12d;
            }
            .negative-amount,
            .amount-credit {
                color: #d92d1a;
            }
            .current-amount {
                color: #265f83;
            }
            .ux-maximgb-tg-panel .x-grid3-scroller {
                overflow: hidden !important;
            }
            div.ux-maximgb-tg-mastercell-wrap {
                border: 0 none !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            .ux-maximgb-tg-uiwrap {
                float: left;
                position: relative;
                height: 30px;
                white-space: nowrap;
                overflow: hidden;
            }
            .ux-maximgb-tg-elbow-empty {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
            }
            .ux-maximgb-tg-elbow-line {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../images/elbow-line.gif*/ url() repeat-x;
            }
            .ux-maximgb-tg-elbow {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../images/elbow.gif*/ url() no-repeat;
            }
            .ux-maximgb-tg-elbow-end {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../images/elbow-end.gif*/ url() no-repeat;
            }
            .ux-maximgb-tg-elbow-active {
                cursor: pointer;
            }
            .ux-maximgb-tg-elbow-minus,
            .ux-maximgb-tg-elbow-end-minus {
                position: absolute;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../../images/aqua/grid/row-expand-sprite.gif*/ url() no-repeat;
                background-position: -21px 50%;
            }
            .ux-maximgb-tg-nl-minus {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../images/elbow-minus-nl.gif*/ url() no-repeat;
            }
            .ux-maximgb-tg-elbow-plus,
            .ux-maximgb-tg-elbow-end-plus {
                position: absolute;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../../images/aqua/grid/row-expand-sprite.gif*/ url() no-repeat;
                background-position: 4px 50%;
            }
            .ux-maximgb-tg-nl-plus {
                position: absolute;
                height: 30px;
                width: 16px;
                overflow: hidden;
                background:/*savepage-url=../images/elbow-plus-nl.gif*/ url() no-repeat;
            }
            .ibdemo-portal-panel {
                background-color: #f4f6f3;
                border: 1px solid #e4e4e4;
            }
            .ibdemo-portal-content {
                padding: 10px;
            }
            .ibdemo-portal-content img {
                float: right;
            }
            .ibdemo-portal-content h1 {
                font-size: 16px;
                font-weight: bold;
            }
            .ibdemo-portal-content ul {
                list-style-position: outside;
                list-style-type: square;
                padding-left: 20px;
            }
            .ibdemo-portal-content li ul {
                list-style-position: outside;
                list-style-type: circle;
                padding-left: 30px;
            }
            .cursor-loading a {
                cursor: progress !important;
            }
            .x-btn button {
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
            }
            .x-progress-inner {
                background: transparent /*savepage-url=../images/default/progress/progress-bg.gif*/ url() repeat-x top
                    left;
                height: 16px;
            }
            .x-progress-bar {
                background: transparent /*savepage-url=../images/default/progress/progress-inner.gif*/ url() repeat-x
                    top left;
                border: 0 none;
            }
            .x-progress-wrap {
                border-width: 0;
            }
            .x-progress-inner * {
                font-size: 11px !important;
            }
            .x-progress-text-back {
                color: #fff;
            }
            .x-tip.bov * {
                color: #2f3f79;
                font-family:
                    Trebuchet MS,
                    Arial,
                    Verdana,
                    Helvetica,
                    sans-serif;
                font-size: 10px;
            }
            .x-tip.bov .x-tip-body.right {
                text-align: right;
            }
            .x-tip.bov .x-tip-body {
                padding: 5px;
            }
            .x-tip.bov .x-tip-body p {
                margin: 5px 0;
            }
            .x-tip.bov .x-tip-tc,
            .x-tip.bov .x-tip-tl,
            .x-tip.bov .x-tip-tr,
            .x-tip.bov .x-tip-bc,
            .x-tip.bov .x-tip-bl,
            .x-tip.bov .x-tip-br,
            .x-tip.bov .x-tip-ml,
            .x-tip.bov .x-tip-mr {
                background-image:/*savepage-url=../images/qtip/bov-tip-sprite.png*/ url();
            }
            .x-tip.bov .x-tip-anchor {
                background-image:/*savepage-url=../images/qtip/bov-tip-anchor-sprite.png*/ url();
            }
            .qtip,
            .x-tip-body .qtip,
            .x-tip.bov a.x-btn-text {
                color: #11bbf1;
                cursor: pointer;
            }
            .x-tip-body p.title {
                font-weight: bold;
            }
            .x-tip.bov .x-toolbar-ct {
                padding: 0 3px;
            }
            .info-bubble-icon,
            .x-form-bubble {
                background-image:/*savepage-url=../images/grid/info_bubble.png*/ url();
                background-repeat: no-repeat;
                background-position: center center;
                margin-right: 3px;
                width: 20px;
                height: 16px;
                cursor: pointer;
            }
            .x-form-field-ibubble-wrap .x-form-bubble {
                padding-left: 10px;
            }
            .x-form-field-ibubble-wrap div {
                float: left;
            }
            .x-form-item-label.hover-help {
                color: #36f;
                text-decoration: underline;
            }
            .x-shadow .xsml,
            .x-shadow .xsmr,
            .x-shadow .xsml,
            .x-shadow .xsmr,
            .x-shadow .xstl,
            .x-shadow .xstc,
            .x-shadow .xstr,
            .x-shadow .xsbl,
            .x-shadow .xsbc,
            .x-shadow .xsbr {
                opacity: 0.75;
            }
            .x-viewport body.x-masked,
            .x-viewport body.x-body-masked {
                overflow: hidden;
            }
            .x-item-disabled {
                opacity: 0.6;
                -moz-opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .ext-ie8 .x-item-disabled,
            .ext-ie9 .x-item-disabled {
                -ms-filter: "alpha(opacity=100)";
                filter: alpha(opacity=100);
                opacity: 1;
            }
            .ext-safari .x-item-disabled {
                opacity: 0.9;
            }
            .unselectable {
                -webkit-user-select: none;
                -khtml-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                -o-user-select: none;
                user-select: none;
            }
            #additionalInfoPanel,
            .x-tip.bov .x-tip-body {
                line-height: 14px;
            }
            .x-focus-element {
                height: 0;
                left: -10px;
                position: absolute;
                top: -10px;
                width: 0;
            }
            .x-focus-frame {
                height: 0;
                left: 0;
                position: absolute;
                top: 0;
                width: 0;
                z-index: 100000000;
            }
            .x-focus-frame-top,
            .x-focus-frame-bottom,
            .x-focus-frame-left,
            .x-focus-frame-right {
                left: 0;
                position: absolute;
                top: 0;
                z-index: 100000000;
            }
            .x-focus-frame-top,
            .x-focus-frame-bottom {
                border-top: 2px solid #840b55;
                height: 2px;
            }
            .x-focus-frame-left,
            .x-focus-frame-right {
                border-left: 2px solid #840b55;
                width: 2px;
            }
            .x-focus-frame-relay .x-focus-frame-top,
            .x-focus-frame-relay .x-focus-frame-bottom {
                border-top: 2px solid #15428b;
                height: 2px;
            }
            .x-focus-frame-relay .x-focus-frame-left,
            .x-focus-frame-relay .x-focus-frame-right {
                border-left: 2px solid #15428b;
                width: 2px;
            }
            div .aria-descriptor {
                display: none;
            }
            .bov-window.x-a11y-focusable {
                position: absolute !important;
            }
            .additionalinfo-panel.x-bubble {
                background-color: #fff;
            }
            .additionalinfo-panel .x-bubble-ml {
                padding-left: 4px;
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y 0 0;
            }
            .additionalinfo-panel .x-bubble-mr {
                padding-right: 4px;
                background: transparent /*savepage-url=../images/panel/bubble-lr.gif*/ url() repeat-y right 0;
            }
            .additionalinfo-panel .x-bubble-mc {
                background: #fff;
                overflow: hidden;
            }
            .additionalinfo-panel .x-bubble-body-noborder {
                border-width: 0;
            }
            .additionalinfo-panel.x-bubble .x-bubble-header-noborder {
                background: #ececec none;
            }
            .x-bubble.x-panel-collapsed .x-bubble-header-noborder {
                background-color: transparent;
            }
            .additionalinfo-panel .x-panel-bbar .x-toolbar,
            .additionalinfo-panel .x-panel-tbar .x-toolbar {
                border-width: 0;
            }
            .additionalinfo-panel .x-bubble-tl {
                padding-left: 11px !important;
            }
            .additionalinfo-panel .x-bubble-tr {
                padding-right: 11px !important;
            }
            .additionalinfo-panel .x-bubble-tc {
                overflow: hidden;
                padding-top: 4px;
            }
            .additionalinfo-panel .x-bubble-bl {
                background: #fff /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat 0 bottom;
                padding-left: 11px;
            }
            .additionalinfo-panel .x-bubble-br {
                background: #fff /*savepage-url=../images/panel/bubble-cs.gif*/ url() no-repeat right bottom;
                padding-right: 11px;
            }
            .additionalinfo-panel .x-bubble-bc {
                height: 4px;
                font-size: 1px;
                line-height: 1px;
                overflow: hidden;
                background: #fff /*savepage-url=../images/panel/bubble-tb.gif*/ url() repeat-x 0 bottom;
            }
            .additionalinfo-panel.x-bubble {
                margin: 5px 0 0 0;
            }
            .additionalinfo-panel .x-bubble-bwrap {
                overflow: hidden;
            }
            .additionalinfo-panel .x-bubble-body {
                max-height: 285px;
                padding: 5px 0;
                background: #fff;
                overflow: auto;
            }
            .additionalinfo-panel .additional-infoct {
                padding: 5px 7px;
                border-top: none;
            }
            .additionalinfo-panel .additional-infoct.first {
                border-top: none;
            }
            .additionalinfo-panel .x-bubble-header {
                color: #000;
                font-size: 12px;
                font-weight: bold;
                line-height: normal;
                padding: 3px 0 6px 0;
                min-height: 0;
            }
            .additionalinfo-panel.x-panel-collapsed .x-bubble-header {
                padding: 3px 0;
                background-color: transparent;
                background-image: none;
            }
            .additionalinfo-panel.x-panel-collapsed .x-bubble-ml,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-mr {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-lr.gif*/ url();
            }
            .additionalinfo-panel.x-panel-collapsed .x-bubble-bl,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-br,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-tr,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-tl {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-cs.gif*/ url();
            }
            .additionalinfo-panel.x-panel-collapsed .x-bubble-bc,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-bwrap,
            .additionalinfo-panel.x-panel-collapsed .x-bubble-tc {
                background-image:/*savepage-url=../images/panel/bubble-collapsed-tb.gif*/ url();
            }
            .additionalinfo-panel.x-panel-collapsed .x-bubble-header {
                background-color: transparent;
            }
            .additionalinfo-panel .changecontactdetails-info p.q {
                font-weight: bold;
            }
            .additionalinfo-panel p {
                margin-bottom: 10px;
            }
            #ccInfoPanel.additionalinfo-panel .x-bubble-header {
                color: #b00;
            }
            #ccInfoPanel.additionalinfo-panel .x-bubble-body {
                color: #f00;
            }
            @charset "UTF-8";
            #bov-changecustomerdetails-function-mainpanel .x-action-col-icon {
                margin: auto;
            }
            #bov-changecustomerdetails-function-mainpanel .x-action-col-icon.inactive {
                cursor: default;
            }
            #bov-changecustomerdetails-function-mainpanel .x-action-col-icon.accountaddress {
                background: transparent /*savepage-url=../images/icons/icon-changeaccountaddress-enabled.png*/ url()
                    no-repeat;
                margin-left: 20px;
            }
            #bov-changecustomerdetails-function-mainpanel .x-action-col-icon.accountaddress-disabled {
                background: transparent /*savepage-url=../images/icons/icon-changeaccountaddress-disabled.png*/ url()
                    no-repeat;
                margin-left: 20px;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_btn_changecontact {
                background: transparent /*savepage-url=../images/icons/change_contact_details.png*/ url() no-repeat top
                    center;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_btn_changedetails {
                background: transparent /*savepage-url=../images/icons/change_account_names.png*/ url() no-repeat top
                    center;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_btn_changeaddresses {
                background: transparent /*savepage-url=../images/icons/change_mail_addresses.png*/ url() no-repeat top
                    center;
            }
            #bov-changecustomerdetails-function-mainpanel #changecustomerdetails-prefaccontcmp {
                padding: 10px;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_changecustomer_btn .x-btn-icon-small-top .x-btn-text {
                padding-top: 110px;
                text-align: center;
                white-space: normal;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_changecustomer_btn button.x-btn-text {
                padding-left: 0;
                padding-right: 0;
                text-align: center;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_changecustomer_btn .x-btn-small .x-btn-text h2 {
                color: #545454;
                font-size: 14px;
                font-weight: bold;
                min-height: 24px;
                text-align: center;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_changecustomer_btn .x-btn-icon-small-top .x-btn-text {
                text-align: center;
                white-space: normal;
            }
            #bov-changecustomerdetails-function-mainpanel .bov_changecustomer_btn .x-btn-small .x-btn-text h3 {
                color: #940c61;
                font-size: 12px;
                min-height: 30px;
                text-align: center;
            }
            #bov-changecustomerdetails-grid .field-friendlyname {
                width: 99%;
            }
            #bov-changecustomerdetailsform .form-subtitle {
                color: #545454;
                margin: 0 0 18px 0;
            }
            #bov-changecustomercontactform .accordionpanel-header .headtitle {
                min-width: 50%;
            }
            #bov-changecustomercontactform .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                max-width: 44%;
            }
            #bov-changecustomerdetailsform .x-panel-header {
                padding-top: 0;
                padding-bottom: 18px;
            }
            #bov-changecontactdetailsform .item-panel.setdeleted .headtitle span,
            #bov-changecontactdetailsform .item-panel.setdeleted .summaryct span {
                color: gray;
            }
            .preferred-account-column-active {
                width: 19px;
                height: 18px;
                padding-top: 5px;
                background: transparent /*savepage-url=../images/icons/ikon_csillag_lila.png*/ url() no-repeat top
                    center;
            }
            .x-grid3-body.review .preferred-account-column-active {
                background: transparent /*savepage-url=../images/icons/ikon_csillag_fekete.png*/ url() no-repeat top
                    center;
                cursor: default;
            }
            .preferred-account-column-notactive {
                width: 19px;
                height: 18px;
                padding-top: 5px;
                background: transparent /*savepage-url=../images/icons/ikon_csillag_szurke.png*/ url() no-repeat top
                    center;
            }
            .x-grid3-body.review .preferred-account-column-notactive {
                background: transparent /*savepage-url=../images/icons/ikon_csillag_sotetszurke.png*/ url() no-repeat
                    top center;
                cursor: default;
            }
            .changecustomerdetails-grid-header {
                white-space: normal;
                height: 55px;
                vertical-align: middle;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel .x-form-empty-field {
                color: gray;
                font-style: italic;
            }
            .field-friendlyname {
                color: black;
                font-style: normal;
            }
            .changecustomerdetails-accountmailingaddress-name {
                color: #2c2c2c;
            }
            .bov-gridpanel .x-grid3-row-table .changecustomerdetails-accountmailingaddress-noname {
                color: #940c61 !important;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel {
                margin-top: 10px;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel .x-grid3-hd-inner {
                padding: 4px 3px;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel .x-grid3-cell {
                //height: 34px;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 3px;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-changecustomerdetails-grid-friendlyname
                .display {
                padding-left: 5px;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-changecustomerdetails-grid-changeaccountaddress {
                white-space: normal;
                text-align: center;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel
                .x-grid3-cell-inner.x-grid3-col-changecustomerdetails-grid-account
                > div {
                color: #940c61;
                text-overflow: ellipsis;
                overflow: hidden;
            }
            #changecustomerdetails-accountgrid.bov-gridpanel
                .review
                .x-grid3-cell-inner.x-grid3-col-changecustomerdetails-grid-account
                > div {
                color: #2c2c2c;
            }
            #changecustomerdetails-accountmailingaddresswindow .x-grid3 table {
                table-layout: auto;
            }
            .x-preferncesbox .x-preferences-link {
                display: block;
            }
            #changecustomerdetails-affectedtransaction-grid {
                margin-top: 20px;
            }
            #changecustomerdetails-affectedtransaction-messagepanel {
                margin-top: 20px;
            }
            #standingordersview-gridpanel-details .table-detail-line {
                margin-bottom: 0;
                border-bottom: 2px dotted white;
            }
            #standingordersview-gridpanel-details .table-detail-line .value-line {
                padding-top: 2px;
                padding-bottom: 2px;
            }
            #standingordersview-gridpanel-details .table-detail-line label.x-form-item-label {
                padding-top: 2px;
                padding-bottom: 2px;
            }
            #standingordersview-gridpanel-details .table-detail-line .value-div label.labelValue {
                margin-right: 5px;
            }
            #standingordersview-gridpanel-details .table-detail-line .value-div a.actionValue {
                margin-right: 5px;
                cursor: pointer;
                text-decoration: underline;
                color: #41718b;
            }
            @charset "UTF-8";
            #orderstatements-datepanel .headtitle,
            #bov-orderstatements-accountpanel .headtitle {
                min-width: 35%;
                width: 35%;
            }
            .requestappointment-succesful {
                height: 70px;
            }
            .requestappointment-succesful p {
                text-align: center;
                padding-left: 30px;
                padding-right: 30px;
                padding-top: 20px;
            }
            #requestappointment-branchanddatepanel .headtitle,
            #requestappointment-reasondetailspanel .headtitle,
            #requestappointment-phonepanel .headtitle {
                min-width: 42%;
                width: 42%;
            }
            #requestappointmentform .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                max-width: 50%;
            }
            .ext-ie8 #x-form-el-requestappointment-otherreason input.x-item-disabled,
            .ext-ie9 #x-form-el-requestappointment-otherreason input.x-item-disabled {
                background: #f5f5f5;
            }
            #requestassistance-container-submitbutton table {
                float: right;
            }
            #requestassistance-panel-container .x-panel-footer.x-panel-btns {
                width: 205px !important;
            }
            #requestassistance-panel-container .x-panel-body .x-panel-body-noheader {
                padding-left: 5px;
            }
            @charset "UTF-8";
            #orderbankdraft-deliverypanel .radio label {
                padding-right: 0;
            }
            #orderbankdraftform .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                width: 35%;
                min-width: 35%;
            }
            #orderbankdraft-amount label {
                padding-right: 0;
            }
            #bov-todo .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                min-width: 78%;
            }
            #bov-todo .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                max-width: 15%;
            }
            #bov-todo .x-functionbox-bbar .ib-btn-secondary {
                margin-left: 12px;
            }
            #bov-todo .bov-gridpanel .bov-scopebar.x-toolbar.x-small-editor .x-form-field-wrap {
                width: 200px !important;
            }
            #bov-todo .bov-gridpanel .bov-scopebar.x-toolbar.x-small-editor input {
                width: 163px !important;
            }
            #bov-todo .bov-gridpanel .bov-scopebar.x-toolbar.x-small-editor input.notempty {
                width: 147px !important;
            }
            #bov-todo .bov-gridpanel .x-grid3-hd-checker-additionalicon {
                position: absolute;
            }
            #bov-todo .bov-gridpanel .x-grid3-hd-checker {
                width: 15px;
                float: left;
            }
            #bov-todo .bov-gridpanel .x-grid3-hd-checker.x-grid3-hd-checker-on {
                background-position: -23px 0;
            }
            #bov-todo .x-grid3-row-table .bov-msg-panel,
            #bov-todo .detailspanel .bov-msg-panel {
                margin-bottom: 20px;
            }
            #bov-todo .detailspanel .x-form-item {
                margin-bottom: 6px !important;
            }
            #bov-todo .detailspanel .x-form-item label.x-form-item-label {
                display: table-cell;
                font-weight: bold;
                float: none;
                position: static;
                padding: 0;
            }
            #bov-todo .detailspanel .x-form-item .x-form-element .x-form-display-field {
                padding: 0;
            }
            #bov-todo .detailspanel .x-form-item .x-form-element {
                display: table-cell;
                padding: 0 0 0 10px !important;
                vertical-align: middle;
                position: static;
            }
            #bov-todo .x-action-col-icon {
                width: 16px;
                height: 16px;
                cursor: pointer;
            }
            #bov-todo .x-bubble .bov-gridpanel .x-grid3-cell-inner {
                background: transparent none repeat scroll 0 0;
                height: auto;
            }
            #bov-todo .x-bubble .bov-gridpanel .x-grid3-td-operations .x-grid3-cell-inner {
                background: transparent none repeat scroll 0 0;
                height: 16px;
                padding-top: 3px;
            }
            #bov-todo .x-action-col-cell .x-grid3-cell-inner {
                padding-bottom: 0;
                padding-top: 1px;
            }
            #bov-todo .x-action-col-icon.inactive {
                cursor: default;
            }
            #bov-todo .x-action-col-icon.hidden {
                display: none;
            }
            #bov-todo .x-grid3-col-operations {
                padding-left: 3px;
                padding-right: 3px;
            }
            #bov-todo .x-action-col-icon.modtransaction {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
                padding-left: 5px;
            }
            #bov-todo .x-action-col-icon.modtransaction.inactive {
                background-image:/*savepage-url=../images/icons/ikon_edit_16x16_inactive.png*/ url();
            }
            #bov-todo .x-action-col-icon.batchinntertrs {
                background: transparent /*savepage-url=../images/icons/ikon_batch_view_16x16.png*/ url() no-repeat top
                    left;
            }
            #bov-todo .x-action-col-icon.batchinntertrs.inactive {
                background: transparent /*savepage-url=../images/icons/ikon_batch_view_16x16_inactive.png*/ url();
            }
            #bov-todo .x-action-col-icon.deltransaction {
                background: transparent /*savepage-url=../images/icons/ikon_x_16x16.png*/ url() no-repeat top left;
            }
            #bov-todo .x-action-col-icon.deltransaction.inactive {
                background-image:/*savepage-url=../images/icons/ikon_x_inaktiv_16x16.png*/ url();
            }
            #bov-todo .x-panel-bbar .x-toolbar {
                border-width: 0;
                margin-top: 14px;
            }
            #bov-todo .viewtransactions-link {
                float: right;
            }
            #bov-todo .item-panel .x-toolbar .x-btn {
                margin-left: 10px;
            }
            #todo-batchfiletransactionspopup .todogrid .x-grid3-scroller {
                overflow-y: scroll !important;
                overflow-x: hidden !important;
                height: 300px;
                background: #fff;
            }
            .ext-strict .ext-ie8 #bov-todo .x-form-display-field {
                padding-top: 3px;
            }
            #bov-todo .details-info-bubble-icon {
                position: relative;
                top: 1px;
                margin-left: 17px;
                width: 12px;
                height: 12px;
                background-image:/*savepage-url=../images/todo/info_bubble.png*/ url();
                background-repeat: no-repeat;
                background-position: center center;
                cursor: pointer;
            }
            #bov-todo .x-grid3-td-checker {
                padding: 0;
            }
            #bov-todo .x-grid3-hd-checker {
                left: 5px;
            }
            #bov-todo .x-grid3-row-checker {
                position: relative;
                left: 6px;
                width: 15px;
            }
            .ext-safari #bov-todo .x-grid3-row-checker {
                left: 5px;
            }
            #bov-todo .header-label .x-grid3-hd-checker {
                display: none;
            }
            .nooperations {
                cursor: default !important;
                width: 0 !important;
                height: 0 !important;
            }
            #todo-batchfiletransactionspopup .x-bubble .bov-gridpanel .x-grid3-cell-inner {
                background: transparent none repeat scroll 0 0;
                height: 15px;
                padding-top: 7px;
            }
            #todo-batchfiletransactionspopup .x-bubble .bov-gridpanel .x-grid3-td-operations .x-grid3-cell-inner {
                background: transparent none repeat scroll 0 0;
                height: 16px;
                padding-top: 3px;
            }
            #todo-batchfiletransactionspopup .x-action-col-cell .x-grid3-cell-inner {
                padding-bottom: 0;
                padding-top: 1px;
            }
            #todo-batchfiletransactionspopup .x-grid3-td-checker {
                padding: 0;
            }
            #todo-batchfiletransactionspopup .x-grid3-hd-checker {
                left: 5px;
                width: 15px;
                float: left;
            }
            #todo-batchfiletransactionspopup .x-grid3-row-checker {
                position: relative;
                left: 6px;
                width: 15px;
            }
            .ext-safari #todo-batchfiletransactionspopup .x-grid3-row-checker {
                left: 5px;
            }
            #todo-batchfiletransactionspopup .header-label .x-grid3-hd-checker {
                display: none;
            }
            #todo-batchfiletransactionspopup .x-grid3-td-status .x-grid3-col-status {
                overflow: visible;
                white-space: normal !important;
            }
            .bov-todo-sladetailspanel {
                left: 1px;
            }
            .bov-todo-sladetailspanel .x-mask-loading {
                left: 45% !important;
                top: 50% !important;
            }
            .bov-todo-sladetailspanel table.sla-details {
                border-collapse: collapse;
            }
            .bov-todo-sladetailspanel table.sla-details tr {
                border-bottom: 2px dotted white;
                margin-bottom: 0;
            }
            .bov-todo-sladetailspanel table.sla-details tr td {
                padding: 3px !important;
            }
            .bov-todo-sladetailspanel table.sla-details tr td:nth-child(1) {
                font-size: 12px !important;
                font-weight: normal !important;
                line-height: normal !important;
            }
            .bov-todo-sladetailspanel table.sla-details tr td:nth-child(2) {
                font-size: 12px !important;
                font-weight: normal !important;
                line-height: normal !important;
            }
            #tfw-declinereason-popup .x-form-element {
                padding-left: 0 !important;
            }
            #tfw-declinereason-popup .x-form-invalid-msg {
                width: 97% !important;
            }
            #todo-tabpanel .x-grid3-td-status .x-grid3-col-status {
                overflow: visible;
                white-space: normal;
            }
            @charset "UTF-8";
            .dailyprices-positive .x-grid3-cell-inner {
                color: green;
            }
            .dailyprices-negative .x-grid3-cell-inner {
                color: red;
            }
            .dailyprices-arrow-up .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/icons/icon_arrow_up.png*/ url();
                background-position: right;
                background-repeat: no-repeat;
                padding-right: 20px;
            }
            .dailyprices-arrow-down .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/icons/icon_arrow_down.png*/ url();
                background-position: right;
                background-repeat: no-repeat;
                padding-right: 16px;
            }
            .dailyprices-favorite-true .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/icons/ikon_csillag_lila.png*/ url();
                background-position: center;
                background-repeat: no-repeat;
            }
            .dailyprices-favorite-false .x-grid3-cell-inner {
                background-image:/*savepage-url=../images/icons/ikon_csillag_szurke.png*/ url();
                background-position: center;
                background-repeat: no-repeat;
            }
            .x-grid3-hd-inner .dailyprices-favorite-header {
                background-image:/*savepage-url=../images/icons/ikon_csillag_fekete.png*/ url();
                background-position: center;
                background-repeat: no-repeat;
                height: 16px;
                margin-right: 6px;
            }
            #bov-dailyprices-gridpanel .x-grid3-cell-inner {
                white-space: normal;
            }
            #bov-dailyprices-gridpanel .x-grid3-hd-inner {
                white-space: normal;
            }
            .dailyprices-gridpanel .x-grid3-dirty-cell {
                background-image: none;
            }
            #bov-dailyprices-gridpanel .x-grid3-row.x-grid3-row-expanded .expander .x-form-item {
                border-bottom: 0 dotted #fff;
                margin-bottom: 0;
            }
            #bov-dailyprices-gridpanel .infopanel {
                padding-left: 12px;
                padding-bottom: 10px;
            }
            @charset "UTF-8";
            #bov-profitslosscalculator-formpanel
                .bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 60%;
            }
            #bov-profitslosscalculator-formpanel-result
                .bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 60%;
            }
            .profitslosscalculator-panel-table .profitslosscalculator-table-cell-firstlabel {
                width: 190px;
                vertical-align: top;
            }
            .profitslosscalculator-panel-table .profitslosscalculator-table-cell-label,
            .profitslosscalculator-panel-table .profitslosscalculator-table-cell-firstlabel {
                text-align: right;
            }
            .profitslosscalculator-panel-table .profitslosscalculator-table-cell-label label,
            .profitslosscalculator-panel-table .profitslosscalculator-table-cell-firstlabel label {
                padding-right: 10px;
            }
            .profitslosscalculator-panel-table td {
                width: 160px;
                vertical-align: top;
            }
            .profitslosscalculator-panel-table .profitslosscalculator-container {
                padding-top: 20px;
            }
            .profitslosscalculator-disabled-selector img.x-form-trigger {
                cursor: default;
            }
            .profitslosscalculator-disabled-selector input,
            .profitslosscalculator-disabled-numberfield,
            .profitslosscalculator-disabled-amountfiled div {
                background-color: #c0c0c0;
                background-image: none;
            }
            .profitslosscalculator-disabled-numberfield input,
            .profitslosscalculator-disabled-amountfiled input {
                color: black;
            }
            .profitslosscalculator-panel-table .profitslosscalculator-percent-positive {
                color: green;
            }
            .profitslosscalculator-disabled-amountfiled .amountfield-currency.x-item-disabled,
            .profitslosscalculator-disabled-amountfiled .amountfield-amount.x-item-disabled {
                opacity: 1;
                -moz-opacity: 1;
                filter: alpha(opacity=100);
                color: black;
            }
            .x-combo-list .x-combo-list-item.x-combo-list-item-disabled {
                cursor: default;
                opacity: 0.6;
                -moz-opacity: 0.6;
                filter: alpha(opacity=60);
            }
            .x-combo-list .x-combo-list-item.x-combo-list-item-disabled.x-combo-selected {
                background-color: transparent;
                border: 1px solid transparent !important;
                cursor: default;
            }
            label.label-bold-header {
                font-weight: bold;
            }
            #newfundorderform .x-form-item.radio-item {
                margin-bottom: 0;
            }
            #newfundorderform .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                width: 40%;
                min-width: 40%;
            }
            #newfundorderform .bov-accordion-panel .item-panel .accordionpanel-header .summaryct {
                max-width: 55%;
            }
            .x-form-amountfield.x-form-readonly-amountfield {
                background: none repeat scroll 0 0 #c0c0c0;
            }
            .x-form-amountfield.x-form-readonly-amountfield .amountfield-currency,
            .x-form-amountfield.x-form-readonly-amountfield .amountfield-amount {
                background-color: #c0c0c0;
                color: #000;
            }
            .x-form-amountfield.x-form-readonly-amountfield .amountfield-currency.x-item-disabled,
            .x-form-amountfield.x-form-readonly-amountfield .amountfield-amount.x-item-disabled {
                opacity: 1;
                -moz-opacity: 1;
                filter: alpha(opacity=100);
            }
            #bov-newfundorder-review table.entrancefeetable {
                border-collapse: collapse;
            }
            #bov-newfundorder-review table.entrancefeetable .normaltext {
                padding: 3px;
            }
            #bov-newfundorder-review table.entrancefeetable .yearcell {
                text-align: left;
            }
            #bov-newfundorder-review table.entrancefeetable .feecell {
                text-align: right;
            }
            .itempanel-review-panel td.td-value.review-header-value {
                font-weight: bold;
                padding-bottom: 8px;
            }
            #newfundorder-taxdeclarationpanel .itempanel-review-panel td.td-label.review-widelabel-width {
                width: 200px !important;
            }
            #bov-commissioncalculator .bov-accordion-panel .accordionpanel-header .x-bubble-header-text .collapseIcon {
                background-image: none;
            }
            #bov-commissioncalculator .x-form-item.radio-item {
                margin-bottom: 0;
            }
            #bov-commissioncalculator .bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                min-width: 40%;
                width: 40%;
            }
            .investmentstc-panel .x-panel-body {
                border: 1px solid black;
            }
            .investmentstc-iframe {
                width: 100%;
                height: 400px;
                display: block;
                border: 0 solid black;
            }
            .viewtransactionhistory-security-orderno-link {
                color: #940c61 !important;
                cursor: pointer;
                text-decoration: underline;
            }
            #viewtransactionhistory-securitydetail-historygrid {
                margin-top: 20px;
            }
            #viewtransactionhistory-securityhistorygrid.bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            #viewtransactionhistory-securitydetail-historygrid.bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            #bov-welcomepage .prev-btn {
                background:/*savepage-url=../images/icons/arrow-up.png*/ url() no-repeat 0 0;
            }
            #bov-welcomepage .prev-btn.inactive {
                background-image:/*savepage-url=../images/icons/arrow-up-inactive.png*/ url();
                cursor: default;
            }
            #bov-welcomepage .next-btn {
                background:/*savepage-url=../images/icons/arrow-down.png*/ url() no-repeat 0 0;
            }
            #bov-welcomepage .next-btn.inactive {
                background-image:/*savepage-url=../images/icons/arrow-down-inactive.png*/ url();
                cursor: default;
            }
            #bov-welcomepage .image-btn {
                float: left;
            }
            #bov-welcomepage .func {
                overflow: hidden;
                padding-left: 8px;
            }
            #bov-welcomepage p.title {
                font-weight: bold;
            }
            #bov-welcomepage .bov-functionlinks {
                float: right;
                padding-right: 10px;
                margin-bottom: 20px;
                margin-top: -20px;
            }
            #bov-welcomepage #btn-container {
                float: left;
                width: 32px;
            }
            #bov-welcomepage #functionlink {
                width: 180px;
                float: left;
            }
            #bov-welcomepage #functionlink a.moreinfo {
                float: right;
                color: #36f;
            }
            #bov-welcomepage #welcomepage-grid {
                width: 100%;
                clear: both;
            }
            .welcomepage-swfbanners {
                margin: 10px 0;
            }
            #welcomepage-grid .x-grid3-td-status .x-grid3-col-status {
                overflow: visible;
                white-space: normal;
            }
            .ibtc-iframe {
                width: 100%;
                height: 400px;
                display: block;
                border: 0 solid black;
            }
            #ibtc-acceptpanel .x-panel-body {
                border: 1px solid black;
            }
            #bov-welcome-loading {
                height: 300px;
                display: inline-block;
                line-height: 250px;
                text-align: center;
                vertical-align: middle;
            }
            #bov-welcomepage #ibmigration-panel {
                padding-left: 4px;
            }
            #bov-welcomepage #ibmigration-panel table tr:not(:first-child) td:first-child {
                padding-right: 5px;
            }
            #bov-welcomepage #ibmigration-panel table tr:not(:first-child) td:not(:first-child) {
                padding-left: 5px;
            }
            #bov-welcomepage #ibmigration-panel .ibmigration-page-panel {
                width: 350px;
            }
            #bov-welcomepage #ibmigration-panel .ibmigration-page-panel .x-panel-header {
                padding-left: 0;
            }
            #bov-welcomepage #ibmigration-panel .ibmigration-page-panel .ibmigration-text-panel {
                font-weight: bold;
                color: #545454;
                font-size: 12px;
                margin-bottom: 15px;
            }
            #bov-welcomepage #ibmigration-panel .ibmigration-page-panel .ibmigration-qrcode {
                display: block;
                margin: auto;
            }
            #bov-welcomepage
                #ibmigration-panel
                .ibmigration-page-panel
                #ibmigration-first-mandatory-deadline
                span.ibmigration-mandatory-date {
                color: red;
            }
            #bov-welcomepage .ibmigration-buttonbar .linkbuttonCt {
                padding-top: 10px;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-summary-row .x-grid3-cell-inner {
                font-size: 12px;
                font-weight: bold;
                color: black;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-row .x-grid3-col.x-grid3-cell .x-grid3-cell-inner {
                white-space: normal;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-totalsummary-row {
                height: 30px;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-totalsummary-row,
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-totalsummary-row .x-grid3-cell-inner,
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-totalsummary-row .text {
                font-size: 14px;
                color: #840b55;
                font-weight: bold;
                padding-bottom: 20px;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-totalsummary-row .x-grid3-cell-spaceholder div {
                padding: 0;
            }
            #portfoliooverview-inputform .x-panel.x-panel-groupsheader {
                background-color: #840b55;
                margin-bottom: 1px;
            }
            #portfoliooverview-inputform .x-panel.x-panel-groupsheader .x-panel-header {
                padding: 15px;
            }
            #portfoliooverview-inputform .x-panel.x-panel-groupsheader .x-panel-header .x-panel-header-text {
                color: white;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-cell.portfoliooverview-gain div.x-grid3-cell-inner {
                color: #008000;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-cell.portfoliooverview-loss div.x-grid3-cell-inner {
                color: #f00;
            }
            #portfoliooverview-grid-wmanun-0.bov-gridpanel div.x-panel-tl {
                margin-top: 30px;
            }
            #portfoliooverview-grid-wmd-0.bov-gridpanel div.x-panel-tl {
                margin-top: 30px;
            }
            #portfoliooverview-inputform .x-panel.x-panel-groupsheader.portfoliooverview-header-r {
                margin-top: 50px;
            }
            #portfoliooverview-grid-rvfm-0.bov-gridpanel div.x-panel-tl {
                margin-top: 30px;
            }
            #portfoliooverview-inputform .portfoliooverview-dailyprices-link {
                color: #840b55;
                cursor: pointer;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-panel-header {
                background-color: #840b55;
            }
            #portfoliooverview-inputform .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            .newsecurityorder-panel {
                margin-bottom: 10px;
                width: 570px;
            }
            .newsecurityorder-panel .x-panel-body {
                border: 1px solid black;
            }
            .newsecurityorder-iframe {
                border: 0 solid #000;
                display: block;
                height: 400px;
                width: 568px;
            }
            .so-amountfield-disabled {
                background-color: #f7f7f7;
                background-image:/*savepage-url=../images/default/form/text-bg.gif*/ url();
                border: 1px solid #cfd0d7;
                color: #000;
            }
            .viewmodifysecurityorder-security-orderno-link {
                color: #940c61 !important;
                cursor: pointer;
                text-decoration: underline;
            }
            #bov-viewmodifysecurityorder-history
                .x-form-item.viewmodifysecurityorder-left-label
                label.x-form-item-label {
                text-align: left;
            }
            #bov-viewmodifysecurityorder-history .viewmodifysecurityorder-totalnetpanel {
                margin-top: 15px;
            }
            #cancelsecurityorder-accordion-panel .collapseIcon {
                display: none !important;
            }
            #modifysecurityorder-transactiondetailspanel .collapseIcon {
                display: none !important;
            }
            #betweenownaccounts-sourceaccountinfotext,
            #betweenownaccounts-targetaccountinfotext {
                margin-left: 195px;
                font-weight: bold;
            }
            #bov-virtualportfolio-virtualportfoliolist .virtualportfolio-dailyprices-link {
                color: #840b55;
                cursor: pointer;
            }
            #bov-virtualportfolio-virtualportfoliolist .headerlink span {
                color: #840b55;
            }
            #bov-virtualportfolio-virtualportfoliolist .virtualportfolio-action-link {
                color: #840b55;
                cursor: pointer;
                text-decoration: underline;
                margin-right: 5px;
                margin-left: 5px;
            }
            #bov-virtualportfolio-modifyportfolio
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-deleteportfolio
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-createportfolio
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-updateinstrument
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-deleteinstrument
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-addinstrument
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon,
            #bov-virtualportfolio-importsearch
                .bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon {
                background-image: none;
            }
            #bov-virtualportfolio-virtualportfoliolist .x-action-col-icon {
                width: 15px;
                height: 15px;
                margin: 1px 3px;
            }
            #bov-virtualportfolio-virtualportfoliolist .x-action-col-icon.modifyportfolio {
                background: transparent /*savepage-url=../images/icons/ikon_edit_16x16.png*/ url() no-repeat top left;
            }
            #bov-virtualportfolio-virtualportfoliolist .x-action-col-icon.deleteportfolio {
                background: transparent /*savepage-url=../images/icons/ikon_x_16x16.png*/ url() no-repeat top left;
            }
            #bov-virtualportfolio-virtualportfoliolist .x-bubble .bov-gridpanel .x-grid3-cell-inner {
                height: 15px;
            }
            #bov-virtualportfolio-virtualportfoliolist .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            .switchingfunds-amountfield-disabled {
                background-color: #f7f7f7;
                background-image:/*savepage-url=../images/default/form/text-bg.gif*/ url();
                border: 1px solid #cfd0d7;
                color: #000;
            }
            .itempanel-review-panel td.td-value.review-header-value {
                font-weight: bold;
                padding-bottom: 8px;
            }
            .itempanel-review-panel td.td-label.review-widelabel-width {
                width: 220px !important;
            }
            #bov-opennewaccount-function-mainpanel #bov-menu-landingpage .landingpage_btn button {
                background: none transparent;
                padding: 10px;
            }
            #bov-opennewaccount-function-mainpanel .landingpage_btn .bov-indexbtn-title {
                max-width: 227px;
                text-align: left;
            }
            #bov-opennewaccount-function-mainpanel .landingpage_btn .bov-indexbtn-description {
                padding: 10px 0 0 0;
                text-align: left;
            }
            .amountcmp-label {
                text-align: right;
            }
            #opennewaccount-maturitypanel .amountcmp-label {
                padding-right: 10px;
                padding-top: 3px;
            }
            #opennewaccount-maturitypanel .radio-column > div {
                padding-left: 10px;
            }
            #opennewaccount-depositpanel .x-panel.bov-xchange-radio-column.x-panel-noborder.x-column {
                margin-right: 4px !important;
            }
            .accordionpanel-body .padded-input {
                padding-top: 10px;
            }
            .accordionpanel-body .padded-link {
                line-height: 24px;
            }
            .accordionpanel-body .nopadding {
                padding: 0 0 0 3px;
            }
            .accordionpanel-body .x-column.radios {
                padding-right: 20px;
            }
            #opennewaccount-branchpanel .x-form-display-field {
                padding-left: 0;
            }
            .nopadding-opennewaccount {
                padding: 0;
            }
            #opennewaccount-maturitypanel .radioDisplayField {
                margin-bottom: 0 !important;
            }
            #opennewaccount-maturitypanel .radioButtonStyle {
                padding-bottom: 5px !important;
            }
            #opennewaccount-taxpanel .radioDisplayField {
                margin-bottom: 0 !important;
            }
            .registermobilepay-panel .x-panel-body {
                border: 1px solid black;
            }
            .registermobilepay-iframe {
                width: 100%;
                height: 400px;
                display: block;
                border: 0 solid black;
            }
            #mobilepaysettings-accordion-panel.bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                min-width: 40%;
                width: 40%;
            }
            .mobilepaysettings-phonenumber-field .x-form-field-wrap,
            .registermobilepay-phonenumber-field .x-form-field-wrap,
            .registermobile-phonenumber-field .x-form-field-wrap {
                margin-right: 5px;
            }
            .mobilepaysettings-phonenumber-field .mobilepaysettings-detailspanel-mobilephonenumber.x-form-text,
            .registermobilepay-phonenumber-field .registermobilepay-detailspanel-mobilephonenumber.x-form-text,
            .registermobile-phonenumber-field .registermobilepay-detailspanel-mobilephonenumber.x-form-text {
                padding: 1px 3px;
            }
            #managemobileservice-changepin-info-panel,
            #managemobileservice-sendcode-info-panel,
            #managemobileservice-register-info-panel {
                padding-left: 17px;
            }
            #managemobileservice-changepin-info-panel .x-panel-header-text,
            #managemobileservice-sendcode-info-panel .x-panel-header-text,
            #managemobileservice-register-info-panel .x-panel-header-text {
                color: #545454;
                font-weight: bold;
                font-size: 12px;
                margin: none;
                padding-top: none;
                padding-left: none;
                padding-right: none;
                padding-bottom: 7px;
            }
            .managemobileservice-sendcode-info-panel-info,
            .managemobileservice-register-info-panel-info {
                font-weight: bold;
                padding: 10px 0 12px 0;
            }
            .managemobileservice-pin-lastitem {
                padding: 0 0 12px 0;
            }
            .managemobileservice-radio-label-container div.x-form-element div.x-form-check-wrap.radio label {
                font-weight: bold;
            }
            #managemobileservice-changepin-info-panel .x-panel-header,
            #managemobileservice-sendcode-info-panel .x-panel-header,
            #managemobileservice-register-info-panel .x-panel-header {
                height: auto;
                line-height: 1;
                padding: 0;
                margin-bottom: 8px;
            }
            #managemobileservice-accordion-panel.bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 40%;
                width: 40%;
            }
            #managemobileservice-accordion-panel.bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon {
                display: none;
            }
            .managemobileservice-successpanel .paneltext {
                margin-top: 8px;
                padding-bottom: 2px;
            }
            .managemobileservice-successpanel .x-link-btn {
                margin-top: 8px;
            }
            .managemobileservice-successpanel .x-link-btn a {
                white-space: normal;
            }

            .registermobilebanking-panel .x-panel-body {
                border: 1px solid black;
            }
            .registermobilebanking-iframe {
                width: 100%;
                height: 400px;
                display: block;
                border: 0 solid black;
            }
            #registermobile-accordion-panel.bov-accordion-panel .item-panel.link .accordionpanel-header .headtitle {
                min-width: 40%;
                width: 40%;
            }
            #registermobile-accordion-panel .accordionpanel-header .collapseIcon {
                display: none;
            }
            #registermobile-accept-panel .x-panel-footer.x-panel-btns {
                padding: 0;
                margin-top: 15px;
            }
            .registrationhtml-panel .x-panel-body {
                border: 1px solid #000;
            }
            .registrationhtml-iframe {
                border: 0 solid #000;
                display: block;
                height: 450px;
                width: 100%;
            }
            .mobilepaysettings-successpanel .paneltext a.x-btn-text,
            .registermobilebanking-successpanel .paneltext a.x-btn-text,
            .registermobilepay-successpanel .paneltext a.x-btn-text,
            .registermobile-successpanel .paneltext a.x-btn-text {
                white-space: normal;
            }
            .mobilepaysettings-successpanel .paneltext,
            .registermobilebanking-successpanel .paneltext,
            .registermobilepay-successpanel .paneltext,
            .registermobile-successpanel .paneltext {
                padding-bottom: 2px;
            }
            #mobiletopupsettings-changepin-info-panel,
            #mobiletopupsettings-sendcode-info-panel,
            #mobiletopupsettings-register-info-panel {
                padding-left: 17px;
            }
            #mobiletopupsettings-changepin-info-panel .x-panel-header-text,
            #mobiletopupsettings-sendcode-info-panel .x-panel-header-text,
            #mobiletopupsettings-register-info-panel .x-panel-header-text {
                color: #545454;
                font-weight: bold;
                font-size: 12px;
                margin: none;
                padding: none;
            }
            .mobiletopupsettings-sendcode-info-panel-info,
            .mobiletopupsettings-register-info-panel-info {
                font-weight: bold;
                padding: 10px 0 12px 0;
            }
            .mobiletopupsettings-pin-lastitem {
                padding: 0 0 12px 0;
            }
            .mobiletopupsettings-radio-label-container div.x-form-element div.x-form-check-wrap.radio label {
                font-weight: bold;
            }
            #mobiletopupsettings-changepin-info-panel .x-panel-header,
            #mobiletopupsettings-sendcode-info-panel .x-panel-header,
            #mobiletopupsettings-register-info-panel .x-panel-header {
                height: auto;
                line-height: 1;
                padding: 0;
                margin-bottom: 8px;
            }
            #mobiletopupsettings-accordion-panel.bov-accordion-panel
                .item-panel.link
                .accordionpanel-header
                .headtitle {
                min-width: 50%;
                width: 50%;
            }
            #mobiletopupsettings-accordion-panel.bov-accordion-panel
                .accordionpanel-header
                .x-bubble-header-text
                .collapseIcon {
                display: none;
            }
            .mobiletopupsettings-successpanel .paneltext {
                margin-top: 8px;
                padding-bottom: 2px;
            }
            .mobiletopupsettings-successpanel .x-link-btn {
                margin-top: 8px;
            }
            .mobiletopupsettings-successpanel .x-link-btn a {
                white-space: normal;
            }
            .mobiletopupsettings-info {
                width: 40px;
                height: 22px;
            }
            #standingorderscreate-enddate-info-bubble-icon {
                margin-left: 15px;
            }
            #standingorderscreate-accordion-panel
                #standingorderscreate-beneficiarypanel
                #x-form-el-standingorderscreate-beneficiaryAccount
                .x-form-invalid-msg {
                width: 180px !important;
            }
            #stopcards-cardpanel .td-value {
                padding-top: 5px;
                padding-bottom: 5px;
            }
            #bov-downloadpaymentmessages .x-panel-header {
                background-color: #840b55;
            }
            #bov-downloadpaymentmessages .bov-gridpanel {
                margin-bottom: 25px;
            }
            #bov-downloadpaymentmessages .x-grid3-hd-checker {
                left: 5px;
                width: 15px;
            }
            #bov-downloadpaymentmessages .x-grid3-row-checker {
                position: relative;
                left: 5px;
                width: 15px;
            }
            #bov-downloadpaymentmessages .bov-gridpanel .x-grid3-cell-first .x-grid3-cell-inner {
                padding-left: 5px;
            }
            #bov-downloadpaymentmessages .bov-gridpanel .x-grid3-row-table * {
                color: #840b55;
            }
            #bov-internalmessages .bov-gridpanel .x-grid3-row-table tr:first-child * {
                color: #840b55;
            }
            #psd2consent-accountlistpanel .td-value {
                padding-top: 5px;
                padding-bottom: 5px;
            }
            .meta-container {
                background: #4a4a4a;
                padding: 8px 10px;
                border-bottom: 1px solid #3b3b3b;
            }
            .meta-container .meta-card {
                background: #fff;
                margin: 0 7px;
                border: 1px solid #d7d7d9;
                border-radius: 0;
                width: 122px !important;
            }
            .meta-container .meta-card .x-panel-bwrap .x-panel-body {
                width: auto !important;
            }
            .meta-container .meta-card .x-panel-body {
                background: transparent;
                padding: 10px 12px 8px;
                min-height: 64px;
                text-align: left;
            }
            .meta-container .meta-label {
                color: #7a1b63;
                font-weight: bold;
                font-size: 14px;
                line-height: 18px;
                margin: 0 0 4px 0;
                white-space: normal;
            }
            .meta-container .meta-value {
                color: #111;
                font-size: 13px;
                line-height: 16px;
            }
            .meta-container .file-value {
                word-wrap: break-word;
            }
            .meta-container .meta-card:first-child {
                margin-left: 7px;
            }
            .meta-container .meta-card:last-child {
                margin-right: 7px;
            }
            .bov-window-chromeless.x-window {
                background: transparent !important;
                border: 0 !important;
            }
            .bov-window-chromeless .x-window-tl,
            .bov-window-chromeless .x-window-tr,
            .bov-window-chromeless .x-window-tc,
            .bov-window-chromeless .x-window-ml,
            .bov-window-chromeless .x-window-mr,
            .bov-window-chromeless .x-window-mc,
            .bov-window-chromeless .x-window-bl,
            .bov-window-chromeless .x-window-br,
            .bov-window-chromeless .x-window-bc {
                background: transparent !important;
                border: 0 !important;
            }
            .bov-window-chromeless .x-window-header,
            .bov-window-chromeless .x-window-tc .x-window-header-text {
                display: none !important;
            }
            .bov-grid-sidebar .x-panel-body {
                background: #f7f7f9;
            }
            .verificationofpayee-wrap {
                padding: 16px 18px 24px;
            }
            .verificationofpayee-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                margin: 2px 0 10px;
            }
            .verificationofpayee-header .title {
                font-size: 20px;
                font-weight: 700;
                color: #9c135f;
            }
            .verificationofpayee-header .close {
                font-size: 26px;
                text-decoration: none;
                line-height: 1;
                color: #666;
                padding: 2px 6px;
            }
            .verificationofpayee-header .close:hover {
                color: #000;
            }
            .verificationofpayee-card {
                background: #fff;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(16, 22, 26, 0.08);
                padding: 14px;
                margin: 14px 0;
            }
            .verificationofpayee-card-title {
                margin: 0 0 10px;
                font-size: 16px;
                font-weight: 700;
                color: #555;
            }
            .kv {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                padding: 8px 4px;
                border-bottom: 1px solid rgba(0, 0, 0, 0.06);
            }
            .kv:last-child {
                border-bottom: none;
            }
            .k {
                flex: 0 0 45%;
                font-weight: 600;
                color: #777;
                text-transform: uppercase;
                letter-spacing: 0.02em;
                word-wrap: break-word;
            }
            .v {
                flex: 0 0 55%;
                text-align: right;
                color: #222;
                word-wrap: break-word;
            }
            .entity .muted {
                color: #777;
                font-size: 12px;
                margin-top: 2px;
            }
            .amount {
                font-weight: 700;
            }
            .amount.pos {
                color: #1a7f37;
            }
            .amount.neg {
                color: #9c135f;
            }
            .chip {
                display: inline-block;
                padding: 2px 8px;
                border-radius: 999px;
                font-size: 12px;
                font-weight: 700;
            }
            .chip.good {
                background: #e9f7ef;
                color: #1a7f37;
            }
            .chip.bad {
                background: #fde9ef;
                color: #9c135f;
            }
            .kv-list {
                list-style: disc;
                margin: 0;
                padding-left: 18px;
                color: #444;
            }
            .kv-list li {
                margin: 2px 0;
            }
            .bov-grid-sidebar-overlay {
                transition: opacity 120ms;
            }
            #verificationofpayee-verificationOfPayeeGrid .x-grid3-row {
                height: 44px;
                display: flex;
            }
            .sidebar-btn {
                background:/*savepage-url=../images/verificationofpayee/details.png*/ url() no-repeat center;
                background-size: contain;
                border: none;
                width: 20px;
                height: 20px;
            }
            .x-grid3-col-verificationofpayee-status {
                padding-left: 5px !important;
            }
            .x-grid3-col-verificationofpayee-creditorName {
                word-wrap: break-word;
                white-space: normal;
            }
            .x-grid3-col-verificationofpayee-creditorIban {
                word-wrap: break-word;
                white-space: normal;
            }
            .x-grid3-col-verificationofpayee-end2EndId {
                word-wrap: break-word;
                white-space: normal;
            }
            .x-grid3-col-verificationofpayee-remittance {
                word-wrap: break-word;
                white-space: normal;
            }
            .x-grid3-col-verificationofpayee-details {
                padding-right: 10px !important;
            }
            .verificationofpayee-status-valid {
                background:/*savepage-url=../images/default/icon/icon-pipe.png*/ url() no-repeat center;
                background-size: contain;
                border: none;
                width: 20px;
                height: 20px;
            }
            .verificationofpayee-status-failed {
                background:/*savepage-url=../images/default/icon/icon_big_info.png*/ url() no-repeat center;
                background-size: contain;
                border: none;
                width: 20px;
                height: 20px;
            }
            .verificationofpayee-wrap .bm-list {
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .verificationofpayee-wrap .bm-item {
                margin: 12px 0;
            }
            .verificationofpayee-wrap .bm-item + .bm-item {
                margin-top: 14px;
            }
            .verificationofpayee-wrap .bm-badge {
                display: inline-block;
                font-size: 11px;
                font-weight: bold;
                padding: 2px 6px;
                border-radius: 3px;
                margin-right: 8px;
                background: #ddd;
                color: #333;
                vertical-align: baseline;
            }
            .verificationofpayee-wrap .bm-text {
                font-size: 13px;
                color: #111;
            }
            .verificationofpayee-wrap .bm-kv {
                margin: 6px 0 0;
                font-size: 12px;
                color: #555;
            }
            .verificationofpayee-wrap .bm-k::after {
                content: ":";
                margin: 0 4px 0 2px;
            }
            .verificationofpayee-wrap .bm-v {
                font-family: monospace;
            }
            .verificationofpayee-wrap .bm-re {
                white-space: pre-wrap;
                word-break: break-all;
                background: #fafafa;
                border: 1px solid #eee;
                border-radius: 3px;
                padding: 2px 4px;
            }
            .verificationofpayee-wrap .bm-toggle {
                font-size: 12px;
                margin-left: 6px;
                text-decoration: underline;
            }
            .verificationofpayee-wrap .bm-sev-error .bm-badge {
                background: #fce0e0;
                color: #a10000;
            }
            .verificationofpayee-wrap .bm-sev-warning .bm-badge {
                background: #fff5cc;
                color: #850;
            }
            .verificationofpayee-wrap .bm-sev-info .bm-badge {
                background: #e6f2ff;
                color: #003e7a;
            }
            .verificationofpayee-wrap .bm-sev-unknown .bm-badge {
                background: #eee;
                color: #555;
            }
        </style>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/browser/Browser.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/browser/NotSupportedBrowserPanel.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/LoadMask.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/login/LoginPanel.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/login/QuestionPanel.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bov/login/login.js?build=05bce331010b38dcd80432018244dfe18f68e164"
        ></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <style id="savepage-cssvariables">
            :root {
                --savepage-url-5: url(data:image/jpeg;base64,/9j/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/4QAC/9sAhAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAgEBAQEBAQICAgICAgICAgICAgICAwMDAwMDAwMDAwMDAwMDAQEBAQEBAQIBAQIDAgICAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwP/wgARCAQ4BiMDAREAAhEBAxEB/8QAMwABAAMBAQEBAQEAAAAAAAAAAAECAwQFBgcICgEBAQEBAQAAAAAAAAAAAAAAAAECAwT/2gAMAwEAAhADEAAAAP8Aa16IAAAAAAAAAAAAAAAAPvOV+iwqZ9Y2Ax5apqTuU5XIdZ7BHKxhBj1E6OV3AIrLtJryCoBlyrGqs0ABet+8FuV0wCrdooAAAACMlTQAAqcXNz5umVu0Yty+WukxfrGGnOyX6yxpysHGc3WYmulovzuhPWTQAAAAAjKvO5xXrJ06juAAAAAAAAAIy/KNAAAAAAAAAAAAByH5+dh2GpsbnQSegAAAAAAAAAAAAAAAAD7zlfosIMesnYCuGDU7zHK4GO57MaEcqMVd8sO3nZBn1ldszywAU5VhmUAWy3Z07yaYac7aAGjJoyAUpCAAApU2OiaGfNyS45XjTTXpJ0nm0523eTV+a+bPWTTmtztzI49ObcnS5PO3JytU9ZNARlNRVOVpi13JG5megdmgAAAAAAAAAjL8o0AAAAAAAAAAAAHzZ88anebFzqNix3AAAAAAAAAAAAAAAAA+85X6LAY9Y2AGRQjDErt04ehtHKxhC49so6OV3K1n2isTzQAV5XLFGRCDU0JrQvE0iSQQCpFVKVNlqnNrlGlqiIJsmW0SX0dJNChx4ZYto0NesmL4t4t2k4unNNT0jNjFsmtTXNXFqY1ctlObIlsgVBHSRoEUiF7+Ts3J2UAAAAAAAABGX5RoAAAAAAAAAAABY+DOY3Os6C51GgPQAAAAAAAAAAAAAAAAB95yv0WAx6xsAIMAZ8rkU1Pc0iI40ZdZGzm7edz7SNBieaAc3Njm5xY6e06MN7dea/STtpytsAAGjIACpmUqtZ2ZlejOGU7WoRhpzt4aT1k0Mo4eNaXs12tVud05p0t1lsL4tusnSMXbkkDSOs8+OXNbirRMSQTUVERFIaerzvRgBOzcnQAAAAAAACMvyjQAAAAAAAAAAADM/NjsOs2NzU6wbHWAAAAAAAAAAAAAAAAD7zlfosBl1kbAAYEAwKR25du0crGGPWNow2xbdJOkYY87xxnt53Sc9aGnNtm9G5vzt633J2jLXjbAAaW6yMo51AAAAAgyOYzqlZ2F0stFs20NJsdHPLyclqtWmmkl8W8T3k5X525btFMrcraLChxRxbZdJNRkynZUczSD1TXS3NbFtAE7jomgAAAAAAIy/KNAAAAAAAAAAAAPnz5k6DrNjU6DoBodgAAAAAAAAAAAAAAAAPvOV+iwFOspsABQyBQyyyPcpEcbj1NyMqc719ZNRzZ87wVkeX2l6thpy1t2zvGxrm31JL4t8gAq3aKCK8qyAAAAAgyWOuZ2rllytdTKqbThfFvAiuTTny1qY26Sxpzti3aI0421W7RQtzXzZyoKyODU4M2t1ZmbFM32TWm5OgnC/O2gBVu0UAAAAABGX5RoAAAAAAAAAAALnwZymx2G5c6zQuVOguXJAAAAAAAAAAAAAAAPvOV+iwFNM+knQADAgjlcNSunRHpaRyuGDvIyjlb9ZtUcbicfWVzfN1Ea87bbetubTbfUna3K6YABVu0UABHNHOgAAAAVMVt3yqMNedtEGFYGRWtC2WZwE1Y100q0l8W+4WyM61snrJoOaNWdQW5qYvD2nnGOE5vsxvqWzZhVu0UJytzt8gGlusUAAAABGX5RoAAAAAAAAAAAMj85Ok6zY6DU6ixsWAIJLGhYAAAAAAAAAAAAAH3nK/RYCpn3igAKGQKGOWR7NaYYc7HWCOVp1nVm0yr2nNXHyvNi2S/SaVtltprzt+kGvK2FW7RQAAAEc0c6AAAAKlOsbQBltxoAFTnrHTKJMI5NzTNvZfbSJy0zblu0ZTzsy69csozbdooAScHNfnYLVbtL5TythVu0UGVuVvAkVbtFAAAARl+UaAAAAAAAAAAAD54+ZOk7DYsdJ0g6AAACCSxoWAAAAAAAAAAAAPvOV+iwGbVeuGwAEGAI5XDUjaMvayy56p3zGUcrl0k87v1lY4+d46ip6S0u0m+baN+knaeTXFE9ZOwAAAEYRzoQAAABBkR1k7AW5tOdAAAGBhtznnkJpm3NekttpzXxbE06yYnnbQL0hFav1nTpHK54chga6T0jFnLSLVbtFARyrGrpoirdooAABH5LVgAAAAAAAAAAD4EyNzrNy51GpcuWAAAAILEmpIAAAAAAAAAAPvOV+iwGbVOuZ3AABmZgoY5Urq5XtinaRlHK5dZSOjRi+dhx9W+5OG2mnO6G2VukG3KyTs6SaAAAAEc0c6AAAABBl2jQCMNudmAAAABmeYcOmebul9L9ZoWyti3JidCOicGkZa5vTlNW7RTlaYvLZzli2k9JOVuVvpNT0ihHOxjekzoip3G00AIy/JtLUEAAAAAAAAADiPgDrOo6Dc0OosbFgcxpVi0SAAAQWNSwAAAAAAAAAPvOV+iwGbVUjrmdgABgQDEqc+Hp6a0I5sNIxaxrl5RzHXpt0l8N5Z1N6na3Npiz0k7AAAAAARhHKgAAAAVMu0nQBhrzswAAAABU4q445qmL6WLamm1udlLZtokFtOzKwBPaToI5WcXkTlJq1W6xi2xdJFW7RQjnWNXk0RU7jaaEZfk2lgKCAAAAAAAAIPkzxjoOo3NDpOgk2JBzgAuaEgAAFSxoaAAAAAAAAA+85X6LAZtZpPWTuAAChkDPlcjPrMc32bJiOVy6Subz2cuLEc529JvtfDXa+Gu0ZbcrIAAAAAAAAAAAAIMusbAAI0420AAAAADEzMNOM540JJ1LZuvSW2nK/O9VI0ysWBPeTQFeWpxednkIq9W6yMW+LoirdYoRzrGryaIqdxtJ+R1oABQQAAAAAABU/OTWuiOo6C51Ghc1APONSxYEFi5oAAAASalgAAAAAAD7zlfosBm1mliOuZ2AAGJUjDEz0wwvt60RzuW5SPIrDN7MKLp1z2VsWy1xbdpbDTnQAAAAAAAAAAAABUp2kaAAObbnQAAAAAKVgWiK4q5CpaJpltXbV821k6ItF4sT2k6ARzsYWjA4hVqt1jC2LeJq3aKEc6xq8miKnc/IOgaVpAAAAAAAAAHhnyZvXZGxuaHWDoJBJ4xYsXNC5YAtVy8AAAQWJNSQAAAAAfecr9FgM2s0JPWTsAAM+Vy1J2z5XLUy2w5XoPTjPc844tM8tuV6CleiX6Tbnb9pGW3OzAAAAAAAAAAAAAAFaz7RQAFubTnQAAAAAIMNIiYHPXCci9Gs9+bYnS8aZCe8nFnF0kmrdooCOdjFvJicRTTTcnaOa2LpE1btFCOdY1eTRPx/0yxEXLVeJAAAAAAAB8Gcx0nWblzoNyxoWAPBrSJJLljUsaAAk2JAAAINDUAAAAA+85X6LAZtZoQs9ZO4AAMSoMjEw5XE68tTgqnRlY53syt1nRHXzumlukvzt8AAAAAAAAAAAAAAAM6r2igALc2nOgAAAAADGsNy3OysplpnGJetMrbTGmVie0nSOVvi6Iq3aKAjlqMWWaLxGSa9ZO0c1sXSWbLdooRzs4fkHealqERc1JAAIqYAAAHAfBHSdh0GxqdRY2LAqWPnKvEk1pEgsalzQuAWq0XJAAALGpIAAAPvOV+iwGbWaEBbd8qAAzMwU53CzPbHm8uujldyNHSU5XXU7Nrndxt+8iNuNkAAAAAAAAAAAAAppAAI7SAACMr86JlIWJZRZFAAAR0nPpBc1A5ubNw1L4tydJl0zLVbtFRzaY1eRpbrFCOVjAChy6ZF+knSOa2LpLNlu0VHN+M9FzQ2LUESbgAAipgAAfHHlm51HQXOk6Ca3gAWPjjStYvV4kuXJJNC5oaAgk0q8SAACCxsSAAD7zlfosBm1mhAJ6ydgABiVIwyzcOs83Lg0pyvoY31pSybLZdem2WunR2luV0wAAAAAAAAAAAAAFKp2igAAAAABHKxi26xuAAAARhli69JOgAk5uVwyvLaxVpdItZbtIy1520Ce8mgHKxhAIOTTIt1k1HNbF0lmy3afixJarmxoSAWNSQAAADE/OTrOg6TcudRoXLlgSaHzkeXVDY0Ni5JcuXBJqalywBetIkAAAsakgA+85X6LAZtZoQCyx1k7gAEGAObLx+dwyr1mOzm9bneihNa7nWI300xdMAAAAAAAAAAAAAM9I1I2UAAAAAAAAAAAAJw05XGo1LdQAEnPzc+bplbadTTnbRO09Jbnb4SKt2igAAKcrzYY7T0k1HNbF0j8W7LoJ0sXNTUkAtWsSAKCB8ueCbV2RsbGp1A6CQQblgRl51vj2eYWNi5tV4sWrSJJLmpoXBGl8tSQAACxqSD7zlfosBm1mhAAWeuZ2AAyM8PF0w5WkVKdJWrR7G25Yc2ubtE105WAAAAAAAAAAAAABXrM9gAAAAAAAAAAABPNrzoGNUq3SToABPNji80Xq25fNvlJPeTlpi2yE9pOgAAE4RzvHGO09JNWy/FCcXTcsTE7WNDU0JALmoAFUPzuNTY7DYudJsWNCwJNiQACMvHjx9uI3L1tGhJcuWJLmxoXBGl8tSQAACTY+95X6LAZtZoQAC3U3AAMeVpqcG3IY5MqYsCtOk9iNOVuK3gXNgAAACCKiosgimygAAJyjFmJLRMZdY2AAAAAAAAAAAE4a8qABnWRbUnoUALc1ud5DEuTpqWyaTUxrlIq3aKAAEYa87WOAx0tqfh3VpGsWyvpaJidrGpoaEgsakgHzp8udR1mxsaHWTW8WALmoAAABjHgnj0Nq1Ni8SXLg0NS5qAXNCQAAQff8r9RgM2s0IAAJ6ydgAMTA8zKsRUEkExqvqJbYThrytav2k0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAIK804tu0VGU0oMJ5XkKlqvuac7Iq25pi2gT3k0AAIy1522WRwV/P/edRcuaZXyvtaLVarlzUvAVJqD86qI6Dsrpi50m5Y2ABsWAAAAAGXkR4u3CdBpWxoTF60iS5c2LkguaEgAH3nK/SYaFWs0IAACz1k7gAx5Wmpw1lzsRJNSLJJl7yxHWXwvzsdpfQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ81udVPSRzs9pNCcNOVxOUmp3NM2+SrdpfC/Oie0nQAARlrztsh+N9p89XFXSWNDTm1L7TEF9LmuG2kROg8c+Rrqjc6zU3OwsalwCxqSAAAAAADly+frzK0NTcuWL1pEljQ1NCQWNSQD7zlfosAoIAAAnrJ2AGPK01I244tAkkAEZdvOwO8152mVu0vQAAAAjJkAAAAEOiaAAAAAAAAAAAAAAAAAAEFeZzqphU7jaac2nOwcpjWnWWy0xZLdpOF+dkts6SaAAjDXnZj8o6wefp89XObmhc2wtFtLkGt1blrbeL2Xr87qp1HUdBsXOs0reJBBuWAAAAAAAAM8PBrxdLGhuXNDQ0BYubGoBatYk+85X6LAT1k7RzsYIAAnrJ2AFeVy1K1y87YtExaqkVXcVQ6OV07Rzs6kbbkgAEZRzqEQRUVAsELNgRMsxaAqdG5OgAAAAAAAAAjmjFt2igAAAAAMsK6RU87rzKntJoAZ83Pi2q3WTlpztu0mnNrztu0nQAACMX8r2Ak8g8JKG5cua5uia0NajGtdZ8w+JruNq6o6zc1OknTTLQkk3AAAAAAAAABGXiaeGZG5qbFzQ0BcublwDQ+95X6XAT1k7AOVjCACesnYADDla6kRzadegAjDPlc+srtjxvZ0mkTysdZMbEiIzUQVqNSvQoAAAAACcrc7aJhU6ikOiaEcyHRNABEYIjNQBPaToAAAAAABlhnpNTyuuAnvJoADHDLnb9pOWvOz2k1PNpzs6C3WKAEZflGgAEniniFjU0LmuWtaVY0PgTI7K2O2Njc6DpBc1Km5cAAAAAAAAAAE5ePHg6c1dBqbFzQ0BoaGhoD9A5X6bFE9czsABXlqMWWZ6ydgAMeVpqTphwtOs69oAK82GjTGKcr0m2U9pJHG9BFUqvWKAAEZMVYAEFdJNAAThflbAAntJ0jCOdFu0UBGUcaAKk7X6RQAAAAAAEYZYtesVOWnGzU9pNAAZcrhF9Sc3aLdoq3NpzonrJ2AEYfk+0gAAHgnkFzU0NTStcvMr4o7TsrojpOg6DU6ia6IkqaGpIAAAAAAAAAABGXl5eBtzV0GhsXL1pEmhoan6IfTkc61J0AAEc7GE9JOwAGPLVdSLM+Nx6tLOiooRlTlcukptlytcta6ek1K8q6S2wAjKOdCEQAAACQKnUdE0BPNfnZJBOyyM1k0mlgjNZCCKnpL7AAAAAAAACMsudr1imGnO2hpbrFACuHNztukvGmLbtFacrbBU9JOwEZfk2lgAAAUPnjzDcuaG8fA1B0ncbm52G5odoLmhIBc0JAAAAAAAAAAAGXl5fPbYVsbGxYvWkSaH6VH1QoAAAAAAARhzct274jDnzadpc6QRhnztO0g58K87npfc7sUV6zWrZRzqIiKjUqR0KAAAAZW520WhVu0UAGF+dirRaAK1aABUz7TXS4AAAAAAAAAIwyxa9YqMNOdmLVbtFACMubnWprm3LdYy0520NLdYoRl+S6XAAAABznzZym55R8edx1nadB0HWdBsbG4JraJAJBuAAAAAAAAAAABl5B89pQ1raNqtGhofo0fWmkTSgAAAAAAOflqNZnahiZFzrIyrxuPaNOfBGWLTtKcr6O5bSmGvOzUakdEQhpFDPlYymrEkERPSNrZWpFudtlJJPeTQAjDXnUQtNTbKoBQaa5AAAAANJ6yaAjlYwAAGRXtJ0Yac7GpfFVbtFADn5WmptF82ekYt8NC3eKEZfk2lgAAAACTzj54/OwdZ3HUdR0HYam5qdRJc0JABJuAAAAAAAAAAAABl4mnz5Jqb1pFz9MPqy0TzW3b6gAAAAAAoZAGOWOmOV9O7DPlad5FYlcMeVp1mGaw9PtK1HO62TVaplfTbTQ1NCwAABQxOeMstNLVGGmLfIT1k7AWyiI2FuVrqNhbldMAAAAAAAqdBEMgAAMSO8mgwtm6YABoJ1Mc3KOmL95GVuW9WQJ7Qfk2kjmUAAAABy6fA18kdR2G53HQdZsam5obGhNbRIAOgAAAAAAAAAAAAAEZfPniaWNjev1CPrQCOVvi69czsAAAAABkUIwy52vaYVhyqO3rJqsYxGLz5U6zKK5rU7cWcqad3SdGnQWAAAAAAAKnEYRoTElud0ynpJ2UAAAJ5tedAAAAAAAAAAAAA56nrJ0AkjDTnRMSAZFTo6ydM+PXqnMCesV+TaCcp0AAAADLw6vWZ8ceMdZ1HWdB11tGoOg6QDUuAdAAAAAAAAAAAAAAAM8Pm9PIroP1Hm+yzb9JOgE8rpqabQAAAAAYcrXUnbLladJjGfO4lOs9CMyvO1jLpM4xzaRjuehzvpV30LdYoAAAAAAAAZHnEcrtqTtfmtzsk9pOgAAc2vOgAACABUVUAWFmJJEIAkAgxoW7RQAAc0ZugMqvlt0hdeVsgaTqfk3RIynQAAAAcZwk1aNThPkY467zc3Ooua1rGxqXILG4OgAAAAAAAAAAAAAAAHPl8xX6FX2nNfF0qdydhHOzhr0l9gAABTlccWq264nbHlaFesyjLFw6TLLrNOdyyr1mdV5Xt6T0Np5Gmm2mEc7PaTQAAAAAAAAqeSTza6WpVubTnVW7SImlRlpytadZFAAAAAAAAAAAAADPlbYBU7kZoE2KQ6EUxd9zXS3K6YBpNfkfWQWiQAAABXhmpNbxYgnjfG1PmujQ3NzfTXLck0NjUkFztAAAAAAAAAAAAAAAAB9pzertWp53TLTrFARyt8L1PVbUAgkryvPiz1zOwpyuOo258q5YVhpnVsXqs1jr5Xo6ydhGEc7btJw052antJoAAAAAAAAY8r5epObtqX2DK/K3gT0kZs7ltoAAAAAAAAAAAAAAAMMmVuduQUpQgkiXWQZV29pPO3xdEA/Ie8VqXAAABU805DYk3JERw3sldT5rrPGroNTqNDSrxY1NTUHQAAAAAAAAAAAAAAAAD9A5X6bDj05Osmrc18W3WToAHKzNbdMUxccWySteuZ2Ec1cXBa985YV53HpMtObneiPUjviTLtGgEYCdmGnOyX7RQAAAAAAAFjzeV5tS21+VvqTsynF0wknSesUAAAABGSAhKAAFigABOioyZZ5uW5OUSzZPRSnOzqTpJBIJO7ldMLgH5D3itS4AAAKHgRthfosblScVy3vcW7RXNl8nXNW5vW0XNiS5qbHUAAAAAAAAAAAAAAAAD9A5X6bAZacfaYk818W1W6SdAIzZsrz1OszsABXlcegkGFY8t0Z3Tu200jKuLeLRXtFARzNJ0jK/Ozlp1k7AAAAAAAADw+a9TtPK7ak7Ccr8rfrJ0AAAAjmRGKAK1WgiKRNCYRYkAEEEkHPplFtxmzVYiyM1SEa1BfpN9O/nb4AfkHaC9KAAAk8w5o1y02sbCI43SNOsnYCcPH2+bLmh0VeNDQksesAAAAAAAAAAAAAAAAD9A5X6bAZ6V7TI5SmVqnnb5X1J6FAAARzVxc6rqT0ZxmaV3mnNXncu0aRhXFpW240AjCOdntJoThPO69JOwAAAAAAAHnYcnK22no0s0yaWw15WesnYAARhHKgCtU3I2UAAAAAAAyUoCMuXnYykEkLUugntJ0EcrOHrHQAfkPeKAAAAzPGL8bttpubFgV4XSXbvlQAEHzJ5Bua1uXjQ0PYAAAAAAAAAAAAAAAAB+gcr9NgM9K9oByRzxeozZwtE1bctsGFeVpSqdJNQZkx3abAEYVxc+sio5ozcdy9aVNCMo523WKEc19NdJAAAAAAIwjnUZHh6b5Wq3eWwtpeNeVmJAAABSoqvSNAIK5sYVyQAUTYoBDotuSRzRm1ihByklustms0lYvNSzcE95Nb83rc7IPx7YTZOk6AADyjOHG69JptuAOWtsSat2ihGSBJxV8rVNNTojUk98AAAAAAAAAAAAAAAAH6Byv02Az0r2gAqefhXa8ImpqCOVZT1ioFQU53s3OmgAAKc2WjQV5sZW5pWlCMBOwEYTzupMAAAAAAADwusjN2wnrLbbEgtyumAAArVO0igKc7TKkOknYCMIxZqMp6SdgAAIyYsQAjOOPRLpJr1jNjFWDSNBU9JO3q8r04D8YJa6O+FIUAOc8stx1Zrftz3LEEcNaS6Mz1k7AAABl88eFpuaVvH0gAAAAAAAAAAAAAAAAP0DlfpsBn1V3AAJOM5IYToLlqgiqxEZ1112kgAAAFOVyxY65navK01M9huWI5mk6ARg53aJAAAAAAAPF0z6ycNedntNLbpapIyZWza6ip0ihXNzzKStydIyjnUIgggAkkAgkkAgkgqUVWFlMmlo0LFZbdc2jbnQqdzozfWyk/F60206QCSaQPFIJ4XTTbrNS5ERxt5bpfpAAAAAOc+W25asfZAAAAAAAAAAAAAAAAA/QOV+lwxHWTsAAI5sed8/rI2AjKaipND0S4AAAABGUc7nFe0VGGWLTUrtMbk87O5OwCKcLqaAAAAAAA8g5Nrpri6d5HO6amuwAAAplXnc9lkc6yAwu1zCBU0BECaZRkJthbSRZFpJ6SdAOXlYwmpNy2lMLbb5CYgk9mto/Ge81q4AAOE843ivC69Jr0bkgrytsXVJAAAAAAPF6vC7vr+EAAAAAAAAAAAAAAAAH6Bi/QyxJPWTsABXmrztO8Vw5cfO2IBfpPR07SAAAAAAARytMsu0mowpi5dYqg5XbDbvFARhXFvlsAACAACDPpPNzrhTc2ynSxOU1t3gAFYpVCMmLGEFBo6ytAAAAAAAAAACuUGeLz4uqNLx6xQtHV3nPzvJiyg9HTsy/G+0nndO0FyQZnili/G2a36Ymt6gRPC3WyCQAAAAAAY+iAAAAAAAAAAAAAAAAD7zlfosBPWTsAMeW6axOwEYcuL53SQdHO+xGvaKAAAAAAAjJi0wz7RoM+Vz1I0yitdFbkgEc1edVtQAFOkaAADzeV49TUvyuhbvFByumGWt3ZpK6YEc6ipRa9cztWIgATSgAJBAKgkcrTFJDV0olAXMlhO2pr0Mt+8nCvOzprl5RU7a7Os/H6moyRY22k8c5jWL8rt0W1LZb6CCSOVjAuxZAAAAAAMfRAAAAAAAAAAAAAAAAB95yv0WEjrJ2FeVyxa9czsIyrzuZXpI0ub4unK2Se8mgAAAAAABGVeNp1ldoyrzuW5FVrDlenpNdLkgjCOVdpbQAAAADzuV4I2LRtAntJ0jlWDrJ2jKONAote2axGKqTMpY2UAAAAABHKzhUAAAsWXVO/S2Ww0tGsZdpfFjDzDr07q/H+kUAI5srrx952N8HK6eiaFzYqTlGLGNSzouiAAAAAADH0QAAAAAAAAAAAAAAAAfdcr9LpO4BnyuWDrJ2EYU5XPrG1ubtxbRTqxynLSLdpOgAAAAAAAjmjnctK9JOkcrjlXrK1nh0YsdpNXL4Ryoppp1k0AAAB5fPXHJrhbpNedsT1k7ARzCOdGa01HSRhjjYI65bAAAAAAASMmLWWYkirQjStLOvLnraNek251VtzTGpTlgca9nXPbt+N5BEltEeRVdrZbxrz1frllfTYjJDFhqWdSAAAAAAAU7QAAAAAAAAAAAAAAACD7w+lAMeWq6y2ArzZ41HbNa6eV3wgAhadcotztqt2igAAAAAAIyjlcyvaKjDPFp1lSuHRz1Xtmmgc2vO2M6v0l9gAAB5XNx6XxduknnrXEUidohkIMVdcztny1hiyk9ZO4AALGxczMC2HZlz9FMunnbF65q3jHU7udqSDg3O/FktWtc0W6S/K6E9ojXlZ05DzD1Nzt2/FwCTQ5I82ty5rhrm6dZGVtNyCQAAAAAAAAAAAAAAAAAAAAAAAACDE/QD6cGHKxo3IyjnYjJa6kx2S3lhQAJSnXFFtz1pMz3k0AAAAAAAI5q87l2NSMK4uXWRU4bcrnpXrM+dyw0NC3eaVbmbTQAHjc3PpOL0dJONX5rIAKkFGo64buXG5w1LdIoAWLnUbluaYHOZrpl0RFaRJJQsSAAc+nTlWrdIKYuW5Mu3M0nU256nU5zzD2dzTb8XIymlQePG9Sbw43U07xlfTYgZToAAAAAAAAAAAAAAAAAAAAABmZgAEV+gR9OYgEYRzuZXtKxfle/tFAAAAQc/NbGtJLdpOgAAAAAAAjmz56z7ZnQV5qVTa+F+VqZ9pUyquFcXTtN8teVnS3WKA8Hlc4RpNa9MOfTViQQZEVOmOLSyesnQADoNyTYvlPOzFokEEUiwAAAAAAABz1bpNOVv1iNMW8cJY66t0n4xsAjy6yLGxvDjdty+yL6bERWAAAAAAAAAL6AAAAAAAAAAAAVMyoAFVjI/Qj6UAjmrztNo6SmHRm9XWKAAAAAGJHO6c1tp6RQAAAAAAEc2ebTpGkZRzuXSRpuOVphn3g58oKcrl2kx1cr1GneKHznKzlE1pZv2zXnvTCUqQjvIjPlrPpJ3IyYoA16T0auCeaYSsrEkgAAAAAAAAAFTHtN8WcJ6yTXlROlC2X4nttDpOY8it6ubG44a6NyekZX02AAAAAAAAAAAAAAAAAAAAAAKmIAAKGZifoZ9UCOavO5dpAxezc10AAAAAAAzKc2nOzVu0UAAAAAABGFedy6RtGFedxqes3hi1wy7RpiU5q87j2ZydnK9PeXrPm8TnbCtI27yedjC5Up1szMYuUteuRHOoGhFep0l9gGV+VtGBuSAAAAAAAAAAAc+l61wVPWW41WsT2kYv4jgXfrn57Rl07bljbJyunSa7SWNgAAAAAAAAAAAAAAAAAAAAAUMgAAZmZkUP0U+qyjnaZZ9opxvodpNAAAAAAAAUMsW3LWlzbtFAAAAAAARhXnceidwRzY5s9ZrCKcrn2lTEjLPN0hSN+s8vF83LY2jZdeuWbOEDqZUwrVNxUYrIDs20gdXSTF8W2QAAAAAAAAAAAAAyKdJpi6Q0vuX520KmvxHSnPfndccG5ubmh0FzbjV1r0zawSbEgAAAAAAAAAAAAAAAAAAAFTIgAEGZkZEGJ+kYfVc7XopZSt47dAAAAAAAAABQx5tMW8T3k0AAAAAABHNTFz7RUZRzuOpfo1I5s8WnaQYYX53XvK4Y4sV4BlluaVoaFzbpL7VI5WuFOspmxgAOk9DrJ2YZcr1gAAAAAAAAAAAAAAHIadJXneknrL5umAH4v2nDHzunTWpsbG5c1wjlZXo65nYSbgAAAAAAAAAAAAAAAAAAAzMwACDEyMyDEiv0fjfqNyTOXrTp2AAAAAAAAAAEGJPK3wt3k0AAAAAABGGfPWfTM7RhXncus10thHO5dZFVjo5WKp0ldKx8ZwqurTaOjK+kxcUJihHSM2MAB6PWdOwc2mbAEWiQAAAAAAAAAAAADmLdJOLtE9ZYvi2yH4xufO9Hl11G9b5dFaGlbZONRr1X3Bc1JAAAAAAAAAAAAAAAAAABQyAIIIMShgDMzMj9JPropi+jZfYAAAAAAAAAAAQZEc7pztu2Z0AAAAAAAGXNTZUc2fO59pvU4V52nabDQRzVzfOr5zK0UreN9tcOvrJzYzeiSClZlDOIBc9TtL6AAMNOdtAAAAAAAAAAAGZoADEr1k1vxrSekmtuFH4P1nDXPpQ1Og0OgsaFuWpxYZ26TTokg1LgAAAAAAAHOAAAAAAAAABSAMCDIoUMiDEyMD9Pj7Dm9bFaV7QAAAAAAAAAAACDIc1+dt2k6AAAAAAARzYc67xUcrhuNNeVjLoqcs9yOoRh4fO+YVhQHZGldJvADRCLrZKFNOvrMsLbXoMNedmAAAAAAAAAAAB5R6oAIOXrNdNOFsW7yI241X879ZfnertOAodGXRpJsalsHKjTrNtgJNiQAAAAAAAc4AAAAAAAAApAqZEGJUqYkVhGJkYn6jyv6ThI6yuwAAAAAAAAAAAAGRXC3K30npJ0AAAAAAjCnLWffKo5XDUis8vQ00iOdRSq9pGXzXK0pEAoQXOnTXLorTtI56jElbmllu0UAAJynIAAAAAAAAAAAAAAI5sXbrNc22DSek2xeWP5+6TbF6esvHmVc6YvW5JoaQrUuAAAAAAAAAAAAAAAAAAAKQKmJBiQZmZBiYVlGB21+zcb9LgJ6ydgAAAAAAAAAAAABkUJ53TnbdszoAAAAAIwpzufaKjmyqNp5unF17RUc0ZsZcOni5SKCK1BWMzpN9NY1iCy6pIJ7SdAAAAAAAAAAAAAAAAAAMeV11LRrzqrd5nzYn4Jq9Vlq6YqeZWuXRpsC5rExtpcAAUgAAAAAAAAAAAAAAAACpiVMipQyBzGJic561fTx97yv0WAnrJ2AAAAAAAAAAAAAAyKFubTnZ7SdAAAAABHK46kbRhlzrvOzBzot2ihHN4vO8oJaM1WEqQKgpHVWhvGqibLdZOgAAAAAAAAAAAAAAAAAA5+VvhptthI0w6RH4Jt0GhsXyy04TY0NiQaly0altIBBMSAAAAAAAAAAAAAAAAUMipkRWMVKHOY1jHOe+e+Sfecr9FgJ6ydgAAAAAAAAAAAAABkULc2nOz2k6AAAACMI5XPrK7CDcsRzRzs9ZOwph4PO3EWWUCq1jAiscoq0dFa109ZegAAAAAAAAAAAAAAAAAABz8rfGtO2N+NHJVulsz+EbbFjcZX05jlOkk2JBc1JjapAAAAAAAAAAAAAAABQoADEgzqkV0plkYGBmc59Ie2SD7zlfosBPWTsAAAAAAAAAAAAAABkULc2nOz2k6AAAARyueVO0VBqakEYRzqJ7SdOLleLJU1OSWbIqCMoqmpnm16K2Zc7pHSbm3WToAAAAAAAAAAAAAAAAAAOfk1xb9ZtyuRyG/WaZv4NqdG2heJrUtHnCrFjUkk0JwvprVgAAAAAAAAAAAAAAVMQAYEEVnFCpgYmRkc59UesSAfecr9FgJ6ydgAAAAAAAAAAAAAABkUHNtzqp7SaAAAjlcNRtGFzbYACMnOq8jCtSukabzPQqOaMWlQUIyqtLMzOs8tTpOite0UAAAAAAAAAAAAAAAAAObldMNe8tzvLFZvo6c9D8HNamtasSWNcPI2uaG5YCpjQsMujSQAAAAAAAAAAAACpiADAgis4oVMDEyMTE+rPUJAB95yv0WAnrJ2AAAAAAAAAAAAAAAAzMxzWxdC3aKAEc0c7C49pOo5ujZQAARxcbxV0ZKvViC2VdJiu5WK5tazyggyMqrGemuXUdPaX0AAAAAAAAAAAAAAAAEnHyvRhbpMedr0kc+nT0564v4NuaVOm9Mp00icKaeXpqamhJcEmhOE1toBcAAAAAAAAAAAqYgFTIggxIKmBiY1jHOfYnokgAH3nK/RYCesnYAAAAAAAAAAAAAAAAZFCML8rYtU6RCEZ217ZUy2i2wAAA8XLPnezpLRrysilAMqVXScq9plzZyxFYz0yM4qXjqrs6y+kAAAAAAAAAAAAAAAGZlhqRGPOzptlp0muL+DbmnRaNKnBU6CxSPOOmoLEmxIJNiSMAN9LUAAAAAAAAAKmIBUxpEGRQoZGBkYHOfZnoEgAA+85X6LAT1k7AAAAAAAAAAAAAAAAAYlQOdtizIWCpHXM7DYsAAADnw8vnZLR21aGk9JOgEZRzqFRlntnlnFNGVKp2lKy5WmUV29J3aSAAAAAAAAAAAAAADmJ5XbU5c2+ozdMttLZfhPWXqxepiwoXJy4a5zergk2JBJYvEQLVrVQAAAAAAAASYFQWMwUMzIpGNZGRgcx9md5AAAB+gc30mdiemJ0AAAAAAAAAAAAAAAAAGJUAAAAnm32UAAAPJ5XPCesk1xeqp6RTlbRaKle0UIwjnale0y52upmRztCnaUrLlaZUrt1O7S+gAAAAAAAAAAAAGGVavhhm2yt0kc9dPXM7Ob8O6JL6aZSRpOQAk8wk6ImgNiwANyQAAAAAAAAASYlAADEqZmUZViZGJzn2Z2AAAAH6CfTgAAAAAAAAAAAAAAAAAAEZYQ2AAAryvRqW2AAAGOHlc7JbTfpEammV8WatkAKlNo6RUYRztCvaRWOWfOss6r2mfO5ZRVY6DrrfpLaAAAAAAAAAAAYc2eLa0mcXpGvSa7RyumH4X3k1sWAAAAPMLxpyunaKmNiRSBuSQCQAAAAAAAZFAAQYkFDEyMtMMsjlPtDtAAAAB+gn04AAAAAAAAAAAAAAAAAAAKcrhqW2AAg2LgAAAHl82e1l1knQDo5tudAAnpI50Z1XtFRlHOxll1NyIwyrixFDNaSZ1Gkxtlqa9ZrtqQAAAAAAAAVOblZyVMYVtCr5bdZOzDXlfwrvJrYkAAAAxPPNMrZu/SSWNSQCwJUlwAAAWAAAMSoAqDGIMzEyKHOYnIfZHoEgAAAA/QT6cAAAAAAAAAAAAAAAAAAAEZZ87lZIUOktW4AAABhzebppbojKVtyTQ2NYaMgABSq9pFRzRmxlnpHWKx5XPIVjOqFIzIq50Raoi1XLmlSAAAABGZiVjQntL5vLzXW6T0ac2naTpbm0538H7y1bFgAAACDjOQ2ysb6sWTG5aggADckAAGIABIKAgoQVMihiVMTI5jlPsj0wAAAAAfoJ9OAAAAAAAAAAAAAAAAAAARlHGjnqgiCdOurdIoAACMPL52OjXUmp5tedCp0rGxp0iAiOdAEFNK9YqMo52MqaV6yKz5XOIKxSs4pFCumuXSWIIKAsC5BIAKkFiwFXloma6WT0mmbfK3aMtedmPwfvL1uAAAAAVPOINIZb7KtGxIFIA1LgAA5wAAKQKGQKmBkUMjM5jmPqz2QAAAAAD9BPpwAAAAAAAAAAAAAAAAACMGUZqIMly75pUnTyumCp6SdgAByc3Bz10dZbctyumAaTuTsI5t9LaACOaOdAEGe0dIqMo51lSq9pFU5s82gihkR2mfO0y1OqJAAKkEkkgAVPWMW2E6c5plPeW52+F+8mtOVtgPwjvLVZYTUkAAAAoeSaFjQ0LEljUkAAsSoAFEAAgkFDIEGBgQYmZznGfVntgAAAAAA/QT6cAAAAAAAAAAAAAAAEcrGAAAgFbc+uWnOaGuGvOzAVbtFAMPIxUb9pfFvzTtPSKAAc2+k6ACMo40ACtU7SKAjCOVz0r1kRXlaVSoypLQzSmlY2OncZqFAACbHRNRzWxbGnWcOLphNKnN2q/bLndcJB+EdpOgG5IAAAAOY80uXNsNdpJraLACkAAAACNJyAoZAgwMCDAzOU5j6M+jAAAAAAAP0E+nBGTIAAAAAAAAAAAAARmsgAIMVdczsAK4STsLcrpgJ7SdAOHDkjba/O7YKt2igAALGpIABGEc6gAZ1XtFCMI51GW0dJEV52llFiIyx1YsamXO7VvVukmgBXmjOrFy3SX1Bz81OdmlWzrXrm+5HK6Yt0CvwnvANyQAAAACDzjnLm0WjbSaRsWAAAAAAABUxKgwMjOqRzGJzHsn1ZIAAAAAAB+gn04I5WMAAAAAAAAAAAAAAAABmU6p3ABGG3O5leknYTyuuCp6SdssXyeS/SdG04a87PaToHNGbJHSToA5t9J0AAEcrGAAGdV7RQjmjnYKaV6RpBlzUzYisQU2rZnzuy7IAJasly3WW3Bnhz8tW1J6Ri3w16ydo5W0uuYB+EeiQWAAAAAABY8wgsaF8t6tUkmpIBAABIKGQAIMTEoVMTM5jnrvj7EoAAAAAAAD9GPqgRysYAAAAAAAAAAAAAAACFx6ydwAAX5r86MKntFRi68rZJ6y23k8rTpNK0L818W3aRlfnbCWyZ21svFO0iJxd+kmgABGUcaAAM6p2k0IyjnYyzqvVOpTlccWBYqmbBRKHT1nXsAABTDn5amyeknNnF265nYV5XTF0QD8J7yKkAAAAAAAqeaSXNoth0dAA3JABFTAFDIAEVlGRkQYmRzGB0H2pAAAAAAAAB+jH1QI5WMAAAAAAAAAAAAAAAIMbXTM7AAObbnQKmXaToHO7cw5NzgxbadHRbDbBpPSaZX50ACFlMrY7ZjKed6O0UAABGEc6gAQZ7R0ihGEcrWq1XrFVyrjVcqI1IlplBmb11dZOgEYcvLUo0npGLrppuASTlfjZB+DbW6yoAAAAAAAMDiNCxc1jYtQkGpcAAqYAAgzMTMgxMzkMSh93VgAAAAAAAAfo2X1GQjNY1AAAAAAAAAAAACLFCFI6yKAAAnmnNAGZbrFC/O0w8fTWNdzbTXnZwntEa89WkAAUgY9Y2jC2LtuAAAAIjnQAK1XtK0BGEcqIKVXtFV5XPKvWQRxooZ11dJtF83njOGlusYu2Fu0UBPNpzsgH4P3lqAAAAAAAAg84yNwaGmW+kkEg3JABgQBVYyMjMqZGJzmJzn3J1AAAAAAAAAH6Byv02AAAAAAAAAAAAAAnrJ2AAAAAAAAAgkA80y5XXCxvua5ti3aRzuuFgAAAZNR3wqMLc7rAAAAAAAArVO0igIwjlRBTSvWREc6yzKWxYyFShctpbrI51jW9zPWTpGWvO2yAA/BuktKAAAAAAAAMrPM2vVyxoaFo20CLEkElzIAxIMjMzKmRyGNcsfYnolQAAAAAAAAD9E5vqM0AAAAAAAAAAAACeknQAAAAAAAAAQCTk5XzsNdNTXpNo15WesnaMN+VaBkqdyOdAGTUd8KjC3O6wAAAAAAIIIWtlesnQCMI5UQClUKrFUkpK1MzyKtHZ0nZizhK9GpPaCOVthoSAD8AIAAAAAAAAAKdJw9WsakljXLerUAAAIrGIMCCpiZVzxgc59Ge2VAAAAAAAAAB+jH1QAAAAAAAAAAAAAAAAAABHJPQoAAAU5ozfCy103zdOud9r4a8rPaTVuV0ieknaORpO0YRyoAytjtlUYW5XUAAAAAAAAFKzqeknSCMI5UCDOo7RVeVzw8czupubRMdNd1bdJOkcrGF11QAD8AIAAAAAAAAALHJ1mPRvFgXNcNtrAAAGZQxKAwMzmMTmPVPpgAAAAAAAAAAfox9UAAAAAAAAAAAAAAAAAACORpOwAAAFMPEzaam+mnC69p0aX5XSJ6RFuW9bkKnpJ0EYRzqAMra9szQjC3K6gAAAAAAAAFCveKgjJlHOgQVoeVXNEk9JYkmEu/SdVX5pzrTMEFwD+f6XQAAAAAAAAAM8PaDckk0NI2qSKmAMzMxKgwMzmrAxi59oWAAAAAAAAAAB+jH1QAAAAAAAAAAAAAAAAABGEc7btFAAAAcXN4eLvXR0m/G2236y+GuLPSMW+GgoT0k7CMo51kBC5JHWTsI5rc7qAAAAAAAAADOq9ooRkyjnQOM83tJq8Xi20AAZXretgW5tOdA/Ae8UAAAAAAAAABkeabmxYitothvpagBylShQyKHOc5gZn25sAAAAAAAAAAAfox9UAAAAAAAAAAAAAAAAARhGKiesnQAAADLDxMbjWYw6Ok3xdK36xyu+pO0crthJPWTsABGUc6yAgxV1zOwjC3K6gAAAAAAAAAGdV7RQjJlji+T0l6nKYtnUyWBJAKkVO2qdnO2APwHvFAAAAAAAAAADjMKvG5BJqa4a7WAPmjqNyDIxOYyOU+wO8kAAAAAAAAAAA/Rj6oAAAAAAAAAAAAAAAAAjla4TuW6gAAAGHic7PWSc2b0m+VzftL8rpqTs5NsUT1k7AACMI51AEGXU3AIwtyuoAAAAAAABAABXtKaCDyAOVvhcDQIE6RgpEEFdNo6C1fgHSCwqIRIJAidpoAAAABl5uk1aNxSNi+W2kg8M5DI6wc9Yxznun0QAAAAAAAAAAAB+jH1QAAAAAAAAAAAAAAABGEc6iOsvsAAABJ5fJw4u/WWXDm126Oa2m+5Y1523eRltxsjSeknQARhHOoAELkkdZOwEc1ud1ABBAFRUAWCFixTRQAEZRxvmVl1lsrYukTs3J0Ary1OszsIwjFDKi0S+n4BudYAAAABIqSaVGSFTSgMjlNSxqSWLl8r1evKrnjlOMzOkzOk+yJAAAAAAAAAAAAP0Y+qAAAAAAAAAAAAAAABGTFjCtX7SaAAAA5ObyOd36yxpy1mk7bRaXfpnTNvhbvFacrbBVu8AAEYRzqABBj1TuARzRizU6jZQAAAAAAAEZMC8fScWTnYmulme8mo5Vht1l9oymseVzyE9ZO0YRysFD+Z/RJjtr1iwAAAAAAAAAIOQrGlaGoJNxzadHnmZwnOcRxmh+kGgAAAAAAAAAAAAP0Y+qAAAAAAAAAAAAAABHNHOiAR1mmwAAAGWHiwxduknN2wqY7dEXjftLc7rqTsLcrpgLd4oCMmKsjNZDNaE98qAEYRysVPaWoAAAAAAAARky5+d8vo0GN7zDS3WOdg10tqWBAphO2HG12ncjKONpX82d5SMzOu09U6QAAAAAAAACp50dJahsWJLmhzmByHIcZwbfZ4dZobAAAAAAAAAAAAH6WfWgAAAAAAAAAAAAAEYRzqBitu+dqAAAArh4fK56b7l9r8rfCe058Xo1Jrer4aZs9Iy052SSaCAAAKkGdrpmdgIyjnURFOsttoAARkySrERKAhAApXk6l+iOdtm6pbtHOzpppKTQjC2mdXAyz5XPpJ2jKON/mv1SuUGcZ1znUekd6yAAQgFyC5IAAOc4o6C9XJNCxcqYHKchyHoH0xBiVNDUAAAAAAAAAAA/Sz60AAAAAAAAAAAAEcrGAAEGPWa87aAAAAPJObrNtrjnduZVu05uet5L2bdFuGr2WqekRHKybgAEArUUKbk7AARysYCpn2jS3NpzoAAAAAAAg8cjrLc7rF6nUnojndI07RCJoRFavUZIxxa7k7COV/m3rKFSpiUM6ziT0D0joIIJBJBIAJBIJOIoaYbaWq5qSaHMcpxFT7EqQRoyxINDQAAAAAAAAAA/Sz60AAAAAAAAAAAAjKONAAqU7SctOdAAAA884O0tLvuMNOWrJPaMXHF0LbnR0ludYa6T0k6TysRplBVq6UShYjrJ2AAAjmjnRVa2V7RVcnO9GUEAVFQBYIURZOyvP5uWtttByuuE95NCSxJfJU1AwjSlRhXnqOmZ2Ec3839GRBUzMzIrVYoYnWemeoSAAACAAAeeXN41LVc1NDnOU88+q03ygFSCSpgDQ1AAAAAAAAAP0s+tAAAAAAAAAAAIyYRmoAzqKr0iNudmAAABynkjTQ16S2WvOqnpJ2xytxt9zfa1MNudt3igJ5WuUVNT0igAABGEcqIK1Wo6RoEZ5rU0oAAAAARlx4vDhbrJzd9STTlbCp6SdgI52M1JpLRItnrJ1ABGUcb/N3olCpBjERlpUgzIMzMk9Dm9SNpbRE1CECttLixSueuWtTaNS1SdmnPlxneeyRpXKhUAjSMqGINa1iQAAAAAAAfpXN9ZmgAAAAAAAAAAIQAM1r3yoX5r86AAAMTxiCbd7JrXFsirdorDCed16S9bUy0xbQq3WKAAAjJixAQgAVKEdY2EYUxqpHTNSeV0qCCQRLIRUAyjzYuT1jN31LbW5WcLgnaekVGEYtusUBGEc6pkAP5p9EEEGRXKlZ1BJUxBiUyz06o9SPVq1ACOaM6lE1Ekpy9421y1jYudNZGB9GACpQgqSQRVYoUKlzckAAAAAAH6Vyv1mAAAAAAAAAAAAAGVR2ihOWvGgAACp4dVJ6S0u2pMacrYaTqTtz87phbSa21L7TzWzb5ABQQAABBUqKnrK6ARlBhy1BPXM6RzVxaxp1k7ACMkIS0Ty80bQGl426ydGE89aSSAAAAACCAVt/mnvmSkRFCtVqgKGYiKoVKRnVCD0I9TL0aExYnRQFDlNCxtEc9en1zwH0JqQSAQZFQAClUipnVDY6IkAAAAAH6Vyv1mAAAAAAAAAAAAqU6o3AAiKkAAAk8jmz52esnOttS25bldMAJ2npOfnZjXKesvm66k7TlEbcqAAIIFRUEWTVdlACMolphlE9YI5VAoudlq1hAAgEHlFdwWzdCdNIvFy9aUyuKsWiYAggAEArTU/nDqoVjGMtMjnMSoIIBJnFTOqkGZWNcPR29SuwksWJiTkoaklj0zqPUIKggkCqRmQQSAUKFTMoaHQWJAAAAP0rlfrMAAAAAAAAAAAKmfaNAAIGU6AAAebhzcrJbvHPW2szm2zdJJBPSNOaJi3Pe28o0zq/TNtyImoi/OrIWOkUIyRFSQCCCCpBOkEYRzsRGlYzBJakvTJerFyxYwEbFy9ad5IBryrCQAAAAAAACD8X7ylVERlOihlm8uLzHPZhqcmnMcsckctctchyElcmW+3o16p3AFDkNzYsegfQAAgAAFTEAAqVKlSpkQQbmhAAAB+n8r9dgAAAAAAAABBTSKixsoACMppQAAHEedyumU9IjStdI52ca2ZAVbpPO5Xp7SeOtbLdo50a6irEQ0iJIIW0UisLKzUSCekaVynFul1vZbFvFjUualwVrPtJw052QDDTLN0QKt2igK8rfF1QAAAAAAAAD8Z7yIgpVKEZTShBTlc8J2rqU0pVTMgoch58cGXFbwWcFc51ntHoGBmXNT642AAJKkgAgzKEEgFDMggqUKA0NQAAfp/K/X4AAAAAAAAYlSyx1k7gAAAgkAAA5DyeWtcLWW7xyu2pOaxq7NiwGmEc1dGo56uapPaToI5WMp3LLXKImnSNBqXNC5oaGmF+VkAAAAAAqZ9oy152TOuXbbmAnrJ2ADk2xQAAAAAAAAB+M94oCMsygoKEYMWKizGaSRuZlaisqRmU43PSLK1y6eXXIXy59LkH6KVKlQASAARpOWZQEAAoZxXKNK1QrpXKxrlMAfp+L9hkAAAAAAAIK2pI6xsAAIyiK6aUAABzc3j4ukt7J6RWhrUc7OENaoSwPP0npNK1ivPVovJYnStjbTTY0NDU2NC4AAAIwjnUAAAAAAUKd4ytzvLprlMBVu0UAw152YAAAAAAAAAH4vbPXM6AAVKFAAWiIioxccWiW6ymmeVIjSkVqmLTCpHWZlI5NOU0r6kAAgkAAAEFCpUAEFCpUoZkAFSpJc/UD7AAAAAAAAAAAAAjJpQnK+gAAwPHyjndMr9ZO0ZaxpsBHKxnesyTm058te0CNsujbbTXm6MXaNi2k9JOgAAAAAAjCOdQAAAAAIKdVE5ud0jQCp6SdgIw1520AAAAAAAAAAfjBBKxU9czoAIKFCC8XFUiuVdK87lhFOsppTKpFZxWqYtcKFa4O0g+iAABJUkAAAUihQoSCNIyoQVKlCCpBJQ/UY+yhSgAAAAAAAAAAyrWPDc9c77gAAxPGILcrphPWTs5tJrTplQE8rTFqYanVHT1nVi9GGlT1g242QAAAAAAAAAAAAAAAAQcVO0jndMLk9pOgAnlbYt0AAAAAAAAAA/GCAALZ1I1FASUBYmlSVjOIM4yhitI1MqrSqxnFaplhq8Nn0AAAAIJAAAI0nKpkQAAKzjMRUyqCCT9QPsBlAJpQAAAAAAAREQVM+dittywIIiM6xy8dJ6STTlbDS3WOdvq2zL4WXoNUsU06MlW3NudE7T0lsNOdAAAAAAAAAAAAAAAAA5+0x0AjDar6ACOVnDQsAAAAAAAAAAfjBAAAJqNxtNSCMJxWpXaakAqZmYyrlSK6U0iswVIMzoAAAAAAAAAKFCpJUkAoUKkRFZlT9QPsAARlXJpbSQAAAAARk0ZZY1XcakZbYtjKM4maonkWST1k5a87YubGtbdJrsLc2nO0M9N8lTubYswqekG3OzAAAAAAAAAAAAAAAAA5zHcvmoAF+0toI5WMW5qgAAAAAAAAAA/GCAAAACdG5OkZRyoE6RuNLUAKGZBGVMs4VXalZlS4AAAAAAABGk5VKkFSSoAIqsZVEUIP00+wAAEDOkQXqwABGUQJqtU5WuUdZOwnlYwinWTpTlfI1KRrm7m0bFyYLt1l9wRytsKdZC7crey3aThrzontJ0ryt8a0ZkAAAAAAAAAAAAAAAGRmSAACBUkxc0AAAAAAAAAAAPxggAAAAAtVis1CQgFidq7k6ACpUoVIyzypLFkVlsAAAAAAAABBQqVBAJBBmQVIMj9OPsAABFSakrGIqwwnN06SaQKGVACMIxbdYoSTh5XKl6uuZzq+F7Eok26y+4BAL87bmtVu0jF15rE9pOkcrGFzUAAAAAAAAAAAAAAAFTAnQCeknQCMo5UWl2QAAAAAAAAAAAfjBAAAAAANDQFShBUAtTUjadAAKmZQZI4NgAAAAAAAFIAFChUAAAzMzM/TT68AAAgGcZcLPWTsBHNTnaqRpfotqSRlHO33L7WLFcPMxc16N5k05ask9oxdMW1jUrKL9ZMX52+VusnZhpztonaekUGGvOzAAAAAAAAAAAAAAAFTBZsnrJ0AAAEYRi23J2crrgAAAAAAAAAB+M94oAAAAAX5W+AAgrUdZXQABEE0KFCCCDgAAAAAAAAAKFCxQgAAFKiKlTM/TD7AAAiBFWIMSAARytcWiU6xtUnC0u2W3SX0EFObzMWNNC3SXwtztqEkk1qadILc7fKanpJ2nm052Sdp6RQjDXnbQAAAAAAAAAAAAAABBjUVPSToAAAAIwjFk2ykAAAAAAAAAA/Ge8UAAAAAL8rfAAACCtR1ldAAIgKkrFY8vQAAAAAAAAVKEFQAABVIqUIMz9NPsAACASRzZSxuRoBHNXnaVfU06L1oRkyrpfQCmHlcrXTQuSaReLbRloa9ZOjDTnbQFW7SYvytoE95NARlrztsgAAAAAAAAAAAAAABgO0nQACOZmgOknQAOa/O3AAAAAAAAAAPxnvFAAAAAC/K3wAAAAEFarqR0KAEQFeQAAAAAAAChmQAAAAAVMypmVP04+wAAgKRhwubVuuJ2jmYukalzPsnUAAgkFMvN41Vi9aS2kVY0iS/SXzZi0AT2kl+dvkA0npJ0EYa4tsgAAAAAAAAAAAAAABjUdpNAOVYuhZBAKkFOqdwCOa/O6AAAAAAAAAA/Ge8UAAAAAL8rfAAAAAACCtV1K9E0APnwAAAAACSACAASAAUrOKlSChAP1A+wBGTSCSkZ0JNS+V+VtAAyqO0UBEInSmHBi2Jl0kktpMusk95aJwvmzCp1J6GWnO2gANLdYoMNOdtAAAAAAAAAAAAAAAAyK9pOgDm250AAADLWpma9I2EZW43UAAAAAAAAA/Ge8UAAAAAL8rfAAAAAAAACtU1I6FfPgAAAAAkqSAAARpOQoZkAzKEACv1A+whk0jLHFjpL1c3LgEZRzoZAZ2x2zFC3NEZnFm3ixJJer1bpL5Tm3yCp6ydGVudvEwAq3aKAnm052QAAAAAAAAAAAAAAAZle0aCMXTlbJIFInYgjFAFVr2zXQRhPO3gAAAAAAAAfjfaVAAAAABpi2wAAAAAAAAAFz5n0QAAAACCQAAAChQFSpQgqAAZn6hH2QqsTFzbSwAAAI5o50AUqvaI143E4ywq2ppnWlk1pgJBPWSX52YsABU6jomgJyvytoAAAAAAAAAAAAAAAAoZ9pOgjDTlq6AKt2igBGEc6pkIMiOsnaMI51KQAAAAAACT8g9EAAAAAAjCOVAAAAAAAAAA8D0QAAAASAACDMgFSpUoCpIBUoVIIP1I+1y0rWpAAAAAIwjlQBiR1mublhyk6I0NOssTzumU0q3WKYac7MSBpNjomgABIAGV+NsAAAAAAAAAAAAAChkW7xQZX424FCeknYAARzRzogpbTtmaAjlUT0k6AAAAAARzfjPRAAAAAANMrxOwAAAAAAAAA+eAAAAAApFDMgGYKFSQAVKlCoKGh2H6sfXAAAAAAAjlYwAGdtd5jnefSDXc12YX520ToLdYyviotEgE9pOgAAAADK3K6QAAAAAAAAAAAAABQyq3aKAtzunMFT0k7AAACMo51kIMWnXE7ARzRi27RQAAAAAjL8Y0AAAAAAvlrSgAAAAAAAAB8+AAAABSKFCoKFSoKkikUKFQUJOs7TpJP0Y+qAAAAAAAIwjlQM6wrIvG3SSac7MW2WTtOE5t4mJ2IV0k0AAAABOU8rpAAAAAAAAAAAAAAAqYk9pOgE87pzSCe0nQAAAACOVjADOqdZOgEZRztusUAAAABGX4xoAAAAABfLWlAAAAAAAAAD58AAAqUCkqVIKEAqCDMEAoDM6ztOwkAH6MfVAAAAAAAjKOVQIOEmtVtvOmLaJFDTcZumQCgqabk6AAABlbnbFsgAAAAAAAAAAAAAAKmVO0mgHNrzsgntJ0AAAAAAjmjnQKLTtloBGEc7PWToAAAAIy/F4AAAAAA100oAAAAAAAAAD58UgCpmVJKlCpUEEgoUKggGZodx6JYAAA/Rj6oAAAAAAEYRyoqcQ03i25rizAntJjXnZgAT1k7AAAATk520WiQAAAAAAAAAAAAAAACplTtJoCebXnQJ7SdAAAAAAAIwjnUCi07ZaACOZLPSKAAAA/FwAAAAADQ0AAAAAAAAAAPnwAUKFSAVKEFRpOVChUgEGZ2HonSAAAAD9GPqgAAAAAARysYUOSorp1NMW0Cdpstm3iYAE95NBhbIJZiYkkAAAAAAAAAAAAAAAAAAgxp2k0BGGvK2BOzpJoAAAAAAARhGKyFTNY65nYCMI523aKAAAH4uAAAAAAaGgAAAAAAAAAB8+CpjERaq1UoVqIkFDMggFCTsr1YsAAAAAD9GPqgAAAARhGKAyyOXSI16Tozb4Ce8mr8rfACe0nQACeac2AAAAAAAAAAAAAAAAAAAABFInrJ2AjlbYagE9pOgAAAAAAAAjlYwAqZdZOwAjmjFntJoAAD8XAAAAAANIvEAAAAAAAAAA+Z0gFShUAFCpBBAKmJoeidhAAAAAAAP0s+tAAAABHKxgBzGNJZ3OqNMlW7RU82nOyKt2igAAAAAAAAAAAAAAAAAAAAAAAK8qyt2igJwvytgKnpJ2AAAAAAAAEYRzqAMrY7ZUAIypxunaNAAB+LgAAAAAFjYAAAAAAAAAA+XBmZikBVIoVI0nKkZV0HoHQAAAAAAAAfpZ9aAACMkBEc6IOXSktk27xzbc6q3aKtzac6FW7RQAAAAAAAAAAAAAAAAAAAAAAAFeZiz0k7AThflqyBU9JOwAAAAAAAAAjCMVkBRc+2Z0AEYRzsVbpJ0AH4uAAAAAAWNgAAAAAAAAAD5UxAFIoUKgGWGddFepWoAAAAAAAAB+ln1oABHKxgABQ5tr9Jegw15W209JEac7fITuT1AAAAAAAAAAAAAAAAAAAAAAAARytMLVPaTQEcrri2QCe0nQAAAAAAAAAACOaOdAgy1Y6ZnQARzVxbdpNAfi4AAAAABY2AAAAAAAAAAPkCBVYqUBUqVMpdk9WugqAAAAAAAAAD9MPrQAIrwoAGFU3L1OihbDUnZhpztoE9pOgAAAAAAAAAAAAAAAAAAAAAAAEcrTC1T2k0Axb8tXZAntJ0AAAAAAAAAAAAjmjnQBnbXtlQAjCOVntJ0H4uAAAAAAWNgAAAAAAAAAD48VSKFQVKxjUnqHYSAAAAAAAAAAD9Ky+tyAEZrICDDSe0kE804sl+0tTDXlZBPeTQAAAAAAAAAAAAAAAAAAAAAAAEcrTC1T2k0Axb8tXZAntJ0AAAAAAAAAAAAAjCOdQBRc+2Z0AEZRztY07T8XoAAAAACxsAAAAAAAAAAfHmZmAUjGK6egekSAAAAAAAAAAAD9K5X6zAAADMy7y9ATyumElDTrJ2tzac6Aq3aKAAAAAAAAAAAAAAAAAAAAAAAFOVnCesnYATyt8LACp6ydAAAAAAAAAAAABHKxkgCCpn1TuAARytMPxjvL0AAAAALGwAAAAAAAAAB8QVAMjCOivWNiQAAAAAAAAAAAD9K5X6zAAAY1XtLU5mLrEgEdZfaebTnZAJ7SdAAAAAAAAAAAAAAAAAAAAAAABTlZwVbtFARyumFwAT2k6AAAAAAAAAAAAARlHOsgBBmteuZ2AEZRzv4fdX3jelAAAACxsAAAAAAAAAAfDgzMTI9g7iQAAAAAAAAAAAAD9K5X6zAAVMu0aW52cXSQBSK1fpNIvzoCrdooAAAAAAAAAAAAAAAAAAAAAAAU5WcFW7RQEcrphcAE9pOgAAAAAAAAAAAAAAjmjnQAKLn2zOgAjL8W1ceeoudtS9AAAAWNgAAAAAAAAAD4cxMDU94sAAAAAAAAAAAAAAfpXK/WYAY1HaMXXK2QaIncnaIcrqWgCdp6RQAAAAAAAAAAAAAAAAAAAAAAAz5W2CrdooCOV0wuACdnSTQAAAAAAAAAAAAAAEYRzqABUyadcTsB+LlYZuWDpNqmgAALGwAAAAAAAAAB8Ac53nsAAAAAAAAAAAAAAAH6Vyv1mFTGlXjSJJ3J6FACOV1wsAT3k0AAAAAAAAAAAAAAAAAAAAAAABnzW51Vu0UBHK6YXABOzpJoAAAAAAAAAAAAAAAARzRzoAGdU6ydB+LgRUwxubnRNNFAAWNgAAAAAAAAAD86PVO8kAAAAAAAAAAAAAAA/SuV+myrpplaLDS3WKAAEcrvgFW7RQAAAAAAAAAAAAAAAAAAAAAAAFOaedVbtFARyumFwATs6SaAAAAAAAAAAAAAAAAAEc0c6ABUyqD8Z7yMhOkREueEbmxbSACxsAAAAAAAAAAfJnYAAAAAAAAAAAAAAAVOc/SD7Hmvi3iSdp6RQAAFuV0wAAE9pOgAAAAAAAAAAAAAAAAAAAAAgy5r87Iq3aKAjlb4t0kAAE7OkmgAAAAAAAAAAAAAIyjnWQAAAgythPxjvERE6DPNy5kV6L2b1NAAAAAAAAAAADxwAAAAAAAAAAAAAADI4iD9V5vsudsKt2ihPMxqyVqc2tRvOvO2AAq3aKAAAAAAAAAAAAAAAAAAAAAEGXNpzoVbtFARyumFwAABpbrFAAAAAAAAAAAAAAACOaOdAAAAzX8Z9GalSMJ0VERhlztKjrNDYnQAAAAAAAAAAeOAAAAAAAAAAAAAAVOMxraNsv0/nfsOsmgwti2zbIABksam2QAaW6xQAAAAAAAAAAAAAAAAAAAAAgz5r86FW7RQEcrphcAAAVbtFAAAAAAAAAAAAAAAACMIxWQAAA/GO0ppQgCFCmWeLTOljpnfS4AAAAAAAAALHigAAAAAAAAAAAAFTlOc0No1NK/TT6wktzW52QKAQKkVeAJ7yaAAAAAAAAAAAAAAAAAAAAAAGPNfnZJ2npFARyumFwAABVu0UAAAAAAAAAAAAAAAAABHNHOgAAfjXeVhpQqVIyE6DPNy5kOkbblgAAAAAAAcx8seIfagAAAAAAAAAAAFTmOcuaG8aVoWr9H5X6zDSLUiesjnZ6xhEqEVqSYVbtFAAAAAAAAAAAAAAAAAAAAAAU5WmWkCdp6RQEcrphcAAAVbtFAAAAAAAAAAAAAAAAAAARhGKyAA/Ie8qYkFazIAhQiKyxF9zAmNasAAAAAXPGPlI8StSY++oAAAAAAAAAACpymJJqbRoaVcuan6SfVAAAAjJzsZULk7T0igAAAAAAAAAAAAAAAAAAAAAM+VrlpAntJ0AEcrphcAAAnZ0k0AAAAAAAAAAAAAAAAAAAAI5o50AfkPeKqUjOIqlQVERE6AQSVMSI2q4AABifNHzZxmkaZWqx9foAAAAAAAAABBhGJerxrlrWlXq5c1L5fpFfU0AAAI5WMKlTQAAAAAAAAAAAAAAAAAAAAAAApUbl+dkE95NACOVnN0iyAAAAAAAAAAAAAAAAAAAAAAAAAAAfkPeRWUVBBSqlQIiJ0EEgoUyyqK2jYVJ4R84eEaF8tC5er1Y/8QAQBAAAQIBCAcECQMDBQEBAAAAAQARAgMSICEwMUBQBBAzQVFhcjJxsbITIlJgcHOBkaFCYtEUwfBDU4KS4aIj/9oACAEBAAE/Asi0bsHrPgKZojtCmMtZ0YeGAZ1M4VJiN2IEO85fKGbBEeX5KGVaN2D1nwFoUC4tDdlLOpvBPgDCCph3LvFB7N6MMO835hpJqhh4l/shlWjdg9Z8BayZ3UxRiupNrcJ+RVfBNFwTRKbEpp5KaeKmnipp4qbFxTRJok0Sr4KvgU+p8AzpiLsFMHcmI59yfAQwt35jLGdKn9vq6hlOjdg9Z8Ba3F+dpFdQnKcq+KZMMHNHBTQpvNTeamxKvhakApiOet7dgUZPgVWL7J9YhbvzEloSeAQ8dQynRuwes+AtoDu4UxQN2snHsOCmhTeaY2RhV1+DMA3VIwkf+WN9yAbMtIiaCb7R/AQ1DKdG7B6z4C2uL2Z1RXZKwU0KbzTHhTm8MIQCjAe9d9FnuQDZnLGdKdNX86hYOnyHRuwes+At4Du+1MUOKJyqaFM5pok+sh0xGE70ZPgi4vToPEgAMziLQk8Aue816hlWjdg9Z8BgAXFlvUV9AZVNCmlV706MPDDGTEXL/OCmzc00k+qIfaP4CGoZVo3YPWfAazagzTZRFq8ymhTOBRHEJsGK9bAqaQu+1fJJSKdKHgKh9NQoDJ9G7B6z4DWbaA/pP0sYqwobs0YFGS4VJoheMAKV96m8F35dKRTICft37kNQsnyHRuwes+A1m3hLjnTN2rf35uYQpnAqsXi0FlN4KsX5ZpETkQfU/wBtYtXx2jdg9Z8BrNvcXQL0nfUc4bVNBUw7q132ArtZo7kxCfKSZ0UUR36hi3wOjdg9Z8BrOAhLd1F6EPDPDBwqRBCegMAYQUxHPBvhNIiaBt8VX03oahrFm+O0bsHrPgNZsjrNCGJqjri1jVzz4wgqaRdXqFeDYFMRzT4J8FKxTpTlDUP7oIUBlOjdg9Z8BrNsaEMe4qI04c6aiz3hTeC78IQCppF1afIZSKbAT9u9DUKQwj4PRuwes+A1nAlRF1DE/fnD4GbwVYwjAqad1afH6RE8Qh9msoWz2b4bRuwes+A1nAFGLWC/fRGoe4Zh+iuwjAqbwT2j4CIzQSdydyTvi1C0MgR2IvoURHD2ofqnFB8M9LRuwes+A1m3iiZEvQ5oF/cNrCarr8LN4YvSIroBvrOBMlJxbvtUjIRDsRPyKrh7QIT6nw70NG7B6z4DWcIyFSBf3DaxMPBd+EYFGE7sSTPiMXFDBxSMB/aeX8IyUpD+4flPxq1PZPQez0bsHrPgNZtTqipipO9IZ61lN4YUh0YTutXsdIiaGbvi8NYwhhhi7QdGQ9g/QoiKHtQ/XU6eg9B7bRdmes+A1m3NYsLkK/c1gUzYUh1NIT0Xto4vSRk7t3diopGA/t7v4Rk5SH9w5fwn+mp7F7PRuwes+A1m2OoivU1K73PIV2Fik4Yr7+IUUnHB+4f5uT4CXjmwNviq+m9CiMPFBDFePrvUUjEOwX5FXVRBjrfW9to3YPWfAYE6jXZAv7nzeGGjk4YuR4hRQRQcxxCBovYykfpIydwqCGoahiiAaiHUUgP0Fu+5GdD2h9U+p7fRuwes+Awh42T+55Dq7DRSUMV1R/zciIoLx9U6dPrelLRzYOcVX03mgMfFIQmuH1T+EYY4O0HHEXJ9T2ui9g9Z8Bhbu6yB90G4YeKRBrhqP4RnQ9r72UpHPj5CoIaxYjERSMEV3qnl/Cigjgv9YcQgRqewfXouzPWfAYI6yhVVZA+6Bw7OFFI74Psf5V1UQrpy8cyDnFUP7lDJ45KCL9p4j+6igjg/cOIT6nsdE2Z6z4DBGiDuNkD7o3YcgRXh1FIkVwV8t6f6UZWOfHyFQ/miMlikoYuR4hRQRwfuHEIF9T09E2Z6z4DDlA7jZP7otiIoIYr/ALqKTigu9YflPqlo5kPOKr/1BDULd8VFIwxftPEKKGOC+scUCnoPq0TZnrPlGDNFkItxsnZO+t7B06+69bgvW4L1uC9bgq+CdPnhHDExSUMVdx4hRQxQX1jio4/SRvuFQ1CwGsZFHIQmseqfwiI4O0P+W7W+vQ9mes+UYoRNUbK5PSdVncppUwJhwsWCmDdUmI5p86IojCR3NxqUpokJrg9U8P0oiKAtGGQojKo5AXwery3IvDVEGoaHsovmHyjFFAt3UzrBT6u5TT3KYO9NgGRha5PnJCBw5rOqKGGINEHCj0Uw1ydf7Teu+o6hTGTEA1GtRSDVyf2KfdEGPPVoR/8Ayi+YfKMIbAFk70TQEMRvqQhG+vDGF1dfnJQOFjO7jRjkoJTtD671HIxydfah47x3hAoZdFBDHeP5UUlFB2fWh/K0EvJRfMPlGHNLuQL0CmJuQkxvQAF2JIdXVZ0C+EvL045CGOserF+PsiIoC0X3Q1PlujwiYd3rnwCYjGlPx1TYjyQgA542IOu/Oe5CvBRndYs9RrCj0dq5P/qU5FRqOXaLsz1nwGow8F34wSZN9SEIhuyCMb8sNtdgSWV9aFlFBDHePrvUclFBWPWh8EC+p8q0XZnrPgNZTcMOdQgJvqQAFB8fcWyw2j6oTuwEZ3ahaRyIirHqxfj7IzoKovod2t8o0XZnrPgKLK7CzSeSEIGSyguOWmq2hLi2JYYAgEMQ6ikCK5P7FP8AQ6n1vkmi7M9Z8BTI4YIAlCEDJzWDSGEdOnTp06dOnTp06eg9C61FRtoi51i3jk4Y77+IUUEcnfXDxGp8m0XZnrPgLBnRcW19yEOVbzlptoTVaRFghhIpDfBUeG5XVRVHU6fI9F2Z6z4CyMPD7an1PRfWIeODfEx9r6UhaPjDawmu0Jc6xg4oYYw0QUUnFBWPWh/ITvkmi7M9Z8BZkOrrAAnuQDYV0+HlLxSGBfEXWDVPRFlGd1AYWOREVY9WL8L0crw3zf8A3I9F2Z6z4C1MPCj3VoQccS6fCym7L76Iqq3pr3U1tRhoQ3UXoGpX57o3YPWfAWxDq5OhCYuQQAGMBwkpcENQyF0+t09M6iN6hCat6TNqhsYzW1AZ1o3YPWfAW99SEmBzzKU3d+Ygf+ahTOqGwMTDP9G7B6z4C2Z1dkj28putnoPi7031U0osakAbA1In1a9UG+wJc0Bnei7M9Z8BazeOR3UXtZS8YswshwTNrm1c0x4apimogsEQym1BTSmqU2pkIQEwDockA3ep1bJq31HUKUXDVBdTjO73A0TZnrPgLOspmyUUnTiyj7X0xDOpvFMOFCauyagp3FO6agwN4ph9+qqzibfqhupXK8vRGd6Jsz1nyiyAfKBYOnpntHWMEK0RwU1XWF+DN9OJyptb04zupDO9E2Z6z4CxEOZuQhFYCi9oK02WRFhz9wtE2Z6z5RTvQDZw6i7JwYQrQpxPuxO+jeEA1MmcaYzvRNmes+UUgHzdqEqbgnTp0LcM6m8EHyA2kpF+n7+4eh7I9Z8ooiHjm7UY4vW7qH1TlPab2oTa3yKdW1hEZo8O/P3o6Hsj1nyihDDm4pX1q6k2qtPYQ5IbKU9e7ch7h6FsovmHyjVfchC2eylUOtk9gyZMckcCiULCI1Nx1RQ7x9ULIZxoOyi+YfKFXEgGz6VNYFJ9QsGU0KbqL7kLsb2jSFhz1xBq91kM40ATpKLh6Q+UK7OBTNZJpvnpE3uQz4llJyRi9aO7cOK0XZnq/sM4Apx1DvsgeOX76RpM6uz0llJyX6o/pD/OrRuwes+Aze+wjv7qLUrkDqfKzfYCiQ+eEt3qTkm9aLtcOGvRuwes+Az42ztlholCwiG/L3pvQfhWVJyU2s1xeFDRuwes+AzYWEfDAPqfKDfQOoWMQavOL6hWVJyUyu+Ljwo6N2D1nwGaixN9i1i/FDJ99gLAib3ZtWS0NZUnJiDmd5paN2D1nwGexlh34V0DlD0RYGsLlZvk76q4jNhvUEmJMc95p6N2D1nwGexFzh3KEWRHUEaQsYoX7xmTquMzYaypOTEmOe88bDRuwes+Ay57aIsMVWhHxyYWsQ3jL3TquIzYb1BAJMVX7zY6Lsz1nwGeRVmgMA1hdchHxT4w6zXYixIY8sudVxGbDepOASYYX7zZaJsz1nwGdxFhkAiT4knWeFAYC7J3ouq4jNhvKk4BAKr95s9E2Z6z4DO4i55U3xTsnVanJ8I+IiD5W6riM0XlScmJMczebTRNmes+Ayo4CI2IxDa3ZOm1OU6cWrp+CbFRDfkj0qyZorJUnJiAfu3m10TZnrPgMrNC+zNZshjHT0GVarTlTlO5Kcpynck54KumcQQ2UHgLypKTmCvtG/8Ai20TZnrPgMvFlEcpfBnElXVZK6J/8UlJTPWPaP4t9E2Z6z4DLhZXZY+VxB+/JXUlJN68Xa3csBomzPWfAZxEd2oZY9scZEN+RkqRkv1xf8R/fA6Jsz1nwGbksMxB42ZxxqyKSk55nxdncOPPBaJsz1nyjN4i51DMZ3HJyHqyGTg9IXPZH5weibM9Z8ozaI7suawnccmiFIYmGEykTDs7yg0IYCoYPRNmes+AounTp06dOnTp06dOnTp06dOnTp06dPiHZO+cPrORGrCmkdTGKKaPvwUEIghYYTRdmes+AzWIv3Z2Y2qV+RHCPYE7heVJwejHM3nC6Jsz1nwGaRFqAzNqBLaxEd6fISHxRLKRk5vrHtH8YbRNmes+UZmSwV9edmui5QIyCINXiCpGTf14v+I/vh9E2Z6z5RmcUT91k+YxF6qLJkycpxj7sPBB6Q/tH5xGibM9Z8ozKM7s7iLVa2sKwnxpD4YAxmaPqVDCIQw3YjRNmes+UZiS1eojOSWt3xkQ32lYuQie+g+orkLypOCYOe84nRNmes+UZiS+dkucDOT4q6zKZOYe5CIGgSpGTb14rzdyGK0TZnrPlGYRndncRerBsnIQjhOINdsVOIvT6pKCeZx7I/OL0TZnrPlGXxFu+ic2iO6xFA2LIRRQ/wAISg31eCGGi4/eyagV3VKF44pv3PJQgAMLsXomzPWfKMuiLUxmhLd9iLA2NYuKEr7X3CEQNxwt1mdZ4C8qTk5kPM36nxWh7I9Z8oy4mdqFHfmZLJ3OKq1MhHEOfehKQnl32b2ESdPYnUVIyf8AqH/j/NCtPiND2R6z5RlsRerdYG/MyXsBZm1Di4oSvtD6hCIG44EiwOo6oIfSRftF/wDFOsJ8NoeyPWfKMsii3D62JzKI7sjZCOMfuQlYTy77e+wOoq/1ReVDCIQ1jWE+E0PZHrPlGVxRN32RzGI7hk4MQuKEr7Q+yEUJuP8Aa1ioPRKkoG9Y3nwtK0+C0PZnrPlGVEsFfXZHJnTp06ekS2ViUiG9+9CWG+pAg3HBFQifF+0W9yfAaHsz1nyjKbkS9maAysllflt1yErEL60JWE8u+xNM7hvKhE0NgnttD2Z6z5RlMRfutDjTgiX1vrr4FV8D9k0XApouCmxcFNj4KbHw8FMj/wAKmR8lMi5KZFyUyLkpkXJeji4heji4heji4hTIuSmRclMj5KZHyUyJTYuS9DLcB9wvQy3sfmFeilvY8F6OV9gqbKf7cX2Kmyn+3H/1K9b2IvsU/IqcE6cJxxT2IJFxZCWP6h9kJSE7/vVTNE1KTH6jecK9poezPWfKMoji3Wu/UNb4N09i+uvgU0XBTY+CmR8l6OLiF6P9y9H+5ejHEr0cPNGCH/CvRw8PFTIfZCmw8B9kw4DIWHBTIfZh/wCoXopM/wCnD9gvQSXsD8r+mkfZ/wDqJf0kn+4fVf0kPtn8I6JwlP8A5X9LKe3D9XX9PLcvuvQyw/R4FTYxfBF9jqfWDELihLe0PqEI4Tv/ALWIE4tuF+CrpOnsdC2UXzD5Rk8R3ZRXwTRcFNi4KZFxC9GfaXoxxK9HCpkPBTYeATDhZHM/RwexD/1CMhJH9P5IR0WT/cPqjonCUP1C/ppTcYfyjIyvs/Zk8rBuiHeKkNI9ofZQykEV0X0NWqLin1wwzR44t6ehbKL5h8oyaKJqraLBseBU2JTDxXo+a9GOamQ8FNHAYQ52YAbwD3h0dHkj+gDuceC/p27EcY5Xj7KbKDgfuE0Q3LvBT4509DQtlF8w+UZLEW77e82TqvgVNi4KYeK9HzXowpsPBMOGLf3AiDhDvXrcIfsMj0LZRfMPlGSRRNbxFDW6+imxcFMi4r0fNejhU2HgPc1qTYEhjkmg7KL5h8oxZQpksr67ebEdyEmeK9GN5UyHgmHD3qbJNC2UXzD5RkRiZX32A1VpipqmhVBX5YfcRv5yPQtlF8w+UZCS16JekymqamGZHNWtWybQtlF8w+UYV7MlkS+pipqmps2OZNatQOTaFsovmHyi2dPgLlem97BnGhbKL5h8osjYuns3ezf4L10NC2UXzD5RhppU3nSJZEuqqD0m9+asj0LZRfMPlGCZMmFgSyv1Nrb4R6FsovmHyi2rU1ME1kaka/hToWyi+YfKLNk1tcr/AIVaFsovmHyiidTJk2ANSv8AhXoOyi+YfKNb6mwZLLv+Fmg7KL5h8oVabCk0G+Eb0HTRHchJ8S60MASRb/cPlGGJ+FVZuC9HxKEIFw16Jsz1nyjCv8G3te4IQE31IQAUtE2Z6z5RhCX9+RlrqbEeSEmN9djomzPWfKMGa0PfkZX3ISZPaP0QhAs9E2Z6z5R8DRlBXrRXD7oSY31oVXWuibM9Z8owD6x8IHQhiPIIQAc8BoeyPWfKLd/hE6EMR5IQAYLQ9kes+UWz6m+D5KEER5IQgYTQ9kes+UWj/CF0ISeQQhAw2h7I9Z8os3+D76gDFd90IQOeI0PZHrPlFlf8IL7kIONeK0PZnrPlFg/vw+UOhCTfUEABi9D2Z6z5RTf36fJr6ghABzON0PZnrPlHwldCGdyCAbHaHsz1nyig/wAIHUMG+L7ZBoezPWfKPhHy3qCBr6z4ZDoeyPWfKE/wihhm9+QkrQq5KJ/9w+UfAVqD8c5NSclMtC2UXzD5R8C3zadw1Nq0LZHrPlHwNd8yncKWh7I9Z8o+BTa2Vad8DFHDB2iB4/ZR6V/tw/WL+F6WV9s3vizEqzqajomzPWfKPgaNTJ072scvJwb5x4Q1qLSJSK71B+fuu+tMmxM76qs62paJsz1nwHwRZOnsIooYe0QP84KLSh+gPzNQUUpHH2ovoLvsmxc5VlMmsdE2Z6z5R8AmwVaehFpEnD+48v5UWkSkVzQD8/dX1mvvsP/EACsQAAIBAgQFBAMBAQEAAAAAAAABERAxICFBUTBhcYHwQFCRobHB0fHhYP/aAAgBAQABPyH2Tk7Yd1XajQzfL5xvp5zxWzM74G8xWHhX1VeoaXKfNBqzbsTGTlYEkyDIhEIiCEQKkoaXKRrnL8kPflus/kk8g+hP0Mukn6lf32/fez4ELkvkSFYVFZe2cnhs6f6yIe6+9cDvSznA3S98fOWGIo8C5GXXAvUtLlI3WbTrBseTonWcE4Zpcl3Vxqvnk4HKvInak0J8CRvCbjroiLwL49wybeZ0sPwyFf4/IrCor07a+L2vk6u4y53r9rG+lHW72/OFm4ZKWqPDM5OwjPnP7OQOmdA5/jscscscscgdI6RyEMvEjmTROx1E8yR0kvSSWSThaXD3hbak0TrPBkTL3zG/NZuVvgemoJVZZMEkk/4Th5E6JZ2Lh5/h09w6yckKvhm/uRZCUVhC3dIX37XydWqZq8EXzWB3pZzhu9vzWUrjW1xvooJa4UryLYEltRKq4kLZfByRy/sjuJ6fI5CfchbsTyZKJWBPFyR7q4+RbkySc2KeC71f35QxanJ/02EE/wCi3JWDt+B/BPeiRS3CFc+p+4qd6j+iTl6tL+aJSwhGv0R+PZuTvwWMmTe/4Y20wXhDyl31JqQRRWxL0j234HzvOpPQR8/OZmrolE8yScKXmsnuOf2E0lEk4JwyTX7Gv9EaFK3/AIJ7YL4IbR8v6KWPl0kn2+IS/wC4f3AluQiwV6JV/wB9m5PE6uktG2/QTTSatis08Fj55CsNGTXIgSiisIVFWPT6d6tl19fgl3RPT5EN/gSTzJe1bqGOH3gnR5OiE5pOBYZrJJc1HNZORKz3RqZrJI5OiyJ3omePlsuwhYX+4p9s+f0TqVlXLNwskf8AFEIS1otzz7Pl9CTn7JyfC5H7/JFL9f2VXgfSruLRzFW5bYkbVXqGsKpCd0N+kdBtp8ho0npRKoi75HzKE06J70T7k1liw54Mxw7E+QjXHLNr5Etu919GYTIWS1ZApf71J4E+1S3qP4sJtyzlkssz9iCohUWDuSyVrcXsHJ6dcbq6PdPO6M+7PrR4NSZUkuj+6Fu11IYqIKiqvUMz4TSd1I9KV0I7OfolLGJBDzyP6+DNZPITonWcEsng+di3d61zE0yzS8zJVZJxz7RCveR/s7wJ9CvQhiVlwu5LJWtxet5WcRnTHk/6POHuNYGJ6b1icjRM5754UXqr+qawrgtunxkNv6DYhj5jhbNfYnsTSSSScMkk4JE7Ku8XfmOwc8ncmMshNU4Jx5i4hW9RNp/4zL7Ej8hCFUtxW4Xcz/6ZdPV8rOA6ujP2j8oeB3os1PmwxkxZ/wAGs2prRKi9udwhTzeXOzH+SLMldBOicE0ngpOJpWEx7/Z/0zVkfzBJJOJZeZE8JW9PpG0o6mQXJc86JVCtRVmiZ5i4GejJ30gVvUcrDTvw3R5ZrqjoS6/eJOHG40MMWXlnRKMS9Y16JqRq6T5rJ/I/5n/wfLCU6SxMkklk4M3QXAusxq85L8D0HcnBOOxO/AVvTPMiLyyCuJCfgV6JaU1jgdHB/Imye3puVnBdWqP5E3E/3kISVarvR68v4Tv00HYTXaBQ0nvlRUXsy4r1I5Memjmhpu/YbayRomqYmqSfBWSVwEsv+DdbN9D0c80QwTjsTviT829M3CbdkpfRG7Ll0VvoQghZCFvRYJ5kkrBJPXhfoLl6PlZTTvwHWBqkvnef9q7jcDdzs9NiYc/I7Gvb9DRPeiMK9a/StSZq9Gk7qROr9C5qVuhSwJPQmOhOCSVweRPdD5Zy/hOCcdid8MsSekyb4n/AmgriCvgfv9YP5/ykuxJOzolYExNcDuZ/9MunoeVnFZqMaOUtHtydGM5jQdNtHdJp+BZpRRewtY1x2ozWDQoe6uPbH2TvlG4gyrO+GeCh3ijmh2mT7PhgnHYnei8+Kz6NJZ/llQ3EaCtRPOVP0LBJKrL8/BJLJwZkyLgSJ9uPys4bUVuGMgVczVnuQw07jbbz6DU05izU02fAqr2CMa471ImCSVRraNfY439v+lrGJ1sThn44Vy+dR5jI+zY8ngnGidPsXLCs+Pv1EdSwmXN3FsJVbitSzzpXXzekrzaskqs9yfGT3JWCeEncXficrOG1V0g3GgkhQ/8AqrI3Fl0f0JHNXQrevnkSSSTwJJJ8kkkgSSSSSSSSSPPQtRKvaVsxpyG4hOuaJwp8J3H/AEaLujU5snzwTjn8k+f9FywSLiwTb5D0+KEhfoVEsXn9Mvr/AKSxCSV5tSXz/wCk4J3QmfbBJK4HQT4fKziOrGSJJUZP5GbNXRG+2skfB0LkGZEGz4ovWtei04TI+BYkaZvozu+dCZqmTOBPHOB3C/T+Rst3I5sngnFLQmLC0z4abCRv/CTG5PzmxZCUWQhb0W4rYI8+zxB7r+FxElozQnWf6E2JiepDz90lk1nuJkkrBPonKzDp34SMl31sObZbbEVzThdC15q9YYsmI/Qhetl+sijhmvgnG9jj8GdjAngniNJ3Q3WeZbE6PLBJIi9ZaE2Tv8i74J3FwMu++CrL5EqLcVFbrTlhVsF9VPfM/hYTbkP5HNHPYyfQSaOSXRNZwTuSSsE+gcrOK6NZtUg+iJNRJpV/NCL+dyKojcs+QvWx696lwOtjVyP6JaySKz6D8juUJbupPZ1/omSa9iay0J/JPzhnE3CbbhJNvklca3nNlySsj/Ql90VF+KfrxirrGOE8mk+TzRmi/FnX/Bao5X6MviTbP/onQmSjovwSTWeXnQTwl4/7wZ3+Rd8HKzHpwCw53/KGqwQQSaV3/goMr6rYiqo2nDkkknhSSSySfYXLqTo8cjSd8xsv1ZOjydZwTHEkRcv6Jbl9k1n4JJ8YngWRPSCD8/WCWhYI5P8Agv8AP9FZHI3CvRLUVqK2BcJbCcvddGR5w/D8r9l7kpszQmnZ50LmJpLwJ81ORk/7gngdB6pWcZi5HddaZMhEIghEIWaVfbdDQywvf3+3BdwhvzInHPDTom751HYZrzQSdGT/AKSTueSLuJrLRPnIkTX34sKH/r07nMFHQtVColpRYPP6Lz88T75f6ZqlK82zoM8UfMEdc2zJF2E1nesk88KeByRJZ6BFLR/RFEEEUgUtInOfyiHRUt7/AG6cJL5Mc3fNU8E8NOtrR0DM0XbulOoSPr5qT/pJL/6SImstCz6ieHIL/C1P0QgS1ELJC+jmFaitgXoLft7MvkjRX3N8vES3kc4TlSnkJ+IX+iV/3CkknBPpuV1EhAlo7kIhEIyMqQi2a/gj+Bioxe/26cGUZPIcM/gJ/NJgmswSuFODN30zOeaLkvrOuwh2E6T2E6JVUz+CarEn1MLWOdxBP6EpZ50omy+B/wCC9EthJfNF019s3yFfD42WEmjJEJVJrPmhOzJ3+cE7i9HydV0X/Qs1KIZBCIIdbZoUuvoJJJJZPP4JJ5+diSSSfanlnWY4H/QQ7rb1njyT5BPkUzzqksmJ7OWywpW860ISJ9jmPuknnkkk4ltI0AvIFYWXclVf6Kic5Coln6VpNQ1PJ5pn1BZ/DQ/NBdwkdn95kny+yaTWSeZP+4J7ejZOjL51f0/eGFRqknWi2rOKSePJJPs7WtZjpwXq+BPpeX+Ew3Whfp/BGwkbaH3QmnbMkTJExOksRNtfXOLs/wAUWRdSyFnVUfnQs9RbHMtGbJ3T6uMWJPl9k0msie3plK6qDSlacnhdXSXJ3/NFSY6Vn00k+jbF6Jqsi4CT13Ji+JegaMTSa1TzNcjnOOwlvIXN5Yn/AFEkkiepKJRL7jkFq3FEiFYRaiy82FYybFT8ibF6nNY7J8C7rxsxK7Mk+X2TSap7k7E+jJW91Vl0RfQ4/J0wOj/X7o0bvZidU9PLeqklegkSj0jWCeA1I0+iieBPgK3m/BXQrxozMyG78IFmhqSuncRJJJJtP8YrhWFluxCdStkLpXLXDOj9TYz+O0fKM3a6t9iLL7f8JFmJpNZ9R6Sf7sR7mjwOcMCdZPNb/wDBP40JonhkkniSTwZH3E8CeF0Sj0zWCS3AbK1tiZ8zwzj/AFw0OXPTUiWfYrIuaEjs89hMnUnGU/YsM/8ANxDEiE8sxCj+YJF/uDM6P99VNtL4R9UWHyea7/8ARDs/6IT8ErxCnA8SdvQpnV0cl9kUdh8B0TBIkqjFIkl4JRKIef8ARqS3ZdiOp+CPBEBBc7nMmiGCSVwfLEolVlEolDgS9Q1gng6l2wnPUWBYlbifHnUyl0T8osPkc151MgPrNk79xDcrCExMz01ExVXpd7F9Ct3Yy3I0TP5CadhPcQnA4kb2E+O8DuP9/oiRmx0dHTnVmlE28q2qINKKpokmlK03fL8m80umZuNsj0fn8kLbgN+i+IHqH9h+ZJzZdSVVPjx6pqMNuBJmsmJ/KwftiVuM+e7S5a/wkH/edNiRVtNnzTQwvwLx6CExiRMknmJ+bUnRi7+wtJ5NJ7p6rYYzJfJ02Jcpt9H0aE9sxPsSeQzwk8dqrVMxPNSzf/As81ScFlGQfoUhuCXNzfITVLj8hakhIrJL0DR3QzNn5C/wyap8TX1jy6Y5JwydTQd6v9/rErGq4rTvTSjUm7RqfgzjheT6PX8iecI0ZQ01n3E/sayXwIzJQsmIY1fIJ9iUwJNmpHZh+VmzI5iNAnSAnFO50z45vSj5UgZbbywkTJjxGXyUt8hZ/q+yF9zmJRkvr0quR7jlo+WjJiq9HKJRKJJJZLMySSSSSSUSiUSq5Fvxwc6SSZuTNB3VU5wq3FjUL/gK2BRYei5J3X7MiZeix4ZifNCwRInROewmTsTvWRexIIU9nofJoz7ooydV/BXRLnLOjOKwnwW8N1HRoYpXMJya0dGFZn1di6eeSyRYEVT9MhIfzsOXl2e5JO9VwLEl/W26acVrXVHeK9E9MUsknyCfIJ8gnyCfIJ8gnyCfIJ8gmFLySG24Kitgcd0SzdRHlrZM0+g05yJ0ShOqe4ngn2NyNJmxtavWHcW3rOKSROcTwvA6p/ont8iV5mLlXP8AhzBu/wCY5j0yVjXR7MU2uVE8C9m+TuTWxJJLJJrrPcNCfmixLhWl74/2JQNEaEzR5pjM11/QyRA0XTy+JEzzkSqTTPQTJ39npamR7aGaySHVPFImzQbpJOGd6Oe1HRl+fI8MfwWlPN3E0+En6TM0t1fpuJyqTgn2VJJ/zDMEk4k5TprTXtiXBQjb0Jk21wozos8CyOkmSdGSXUFfqRvCdBeP0ShPaqe4mSvZqSJ3G63Lbask8Z4v3sXJDLLUsq761jUW4e/Bkt0F6K41Nz5VnBJz9DJJJJJLJJJJxySSjdSSSXisTRPnI7DQWJEslkslkslkska2k0v1pZTbBOK1vIu6hWQx3GExMVCdZe3+7+zUnRq+T8zGnd81mCeI6v8ARPiFf5PNCwrN664oJaMuFYXouw5P9YFqL0DJ9PqaMlErBPA6hrxs4+Opf5z/AHRfqiwXjpjYkEejsOW6Vre7bizQ+YnvRGU6IR7NSdb3P+InfBO42J4ZJwPncsOS3Z1DfDGBogT3+eEn6JYXL70FYmswZu1JXCknFKWIHQdGIHQJkonrRNboJpJIySYJ+ML5mmuBWN+guBlisvziPOmvCQ5Y0ZT5SeALnsJp2EEz8ez0nhaXfJ2G66i3L4s8Ek+fozaEErN5v64DU4HVNdPxwZj0TUL5lsavjbwyifUJP6rNYjMvRYZOjAtO/A17N5L+nj5pqulFg26cPllnc1pfN9NhtvA0bi5C9nKTx6vlctlY5Cde1X11pPM+VJ7sbfXp/RKLcJodWRTNcxI+BYWfoMnXL9UVW+f7M3P6wzinhJJJJJwTwJG3oSxNV3qshOkaruLFB1YEsyenyT0+SenzhdNpoLAWCRcTNAW+q6Mvwjwa/gksv+Ceent1JF3yNO/Nb45OS7t+gmz514zWBqkCZdBI8fQTnrx/zfoT0ouIlDeOXGzMzqdMbUuTxNQ/1RM9D5+Tp+S1WlLnVY8pbvwLgnpx/mEVz6HJdRXiezn7ZSkmut8DlqSyXRS8kkRZ5n9KfQtYGqtQSQkfXFAnvxJp+cQqySK+KUS/+4p5wT3J7enkkeQV6ohe/om+Z0ErJy/iirrTTclurfB/9JooJVCq0JdoG5NsXzTVdFRYMhRp73ybemJXI94HLZ/Jk1M4f7X0QhhL0cYGqtEDLMlYpaJJJJJ4H3P1wTQnzsTYzwyTWSUSiUSiUSiUSiUSiUSiUSqkk51J2EOqEEZKTaWv4IeezRF7n8wvNNbockeZ014pdZYbK/WkUs70V8fISj3bkycMk05E9sjMX2bUT9LFWqtUTnz7J8tit04lgJxRZcWfjE2X9A+DOmlsyK8Z0KlklFVWRJTVubPPgvf44Ek9XksKor0jPCvduTeKapuRCUMjmyNhk+leCIpBMMvakxz6kNcsFrcP8r/WBW4pkiWS/Q8yG7EO2o1v51Id4tBDvHnI7ERoJShX+jVEQzaUimt3d/g1O1svozKcwrdeQnhmjNJSzJJ5OhEWcr77o/RSSSSVXpCtjK+OSSSSSSSSSSSSSSfY8+BJs0wMnQ/py1Fq+GG5EEsn0jWBqjQhEkUzVmc5KdGJ8Gw5Ok0WnfgzVuOElLSGJ3gz8muX2NpSnG9IehvdhkXKN/gvCV+f4JZS0N5ea5EIvuLsecWM7E84+diHT4zYlyNRKU9RrkZZzNxpOckRonJ5fcEnMI+uxfd2wktd+hHmf2iQ50eIiJGSUlN6LmfP8Yp1IVC7/FUqLDrHulsJJt4ZM3RKxbcSdW/AiifqGqtpRqkUTdSa/wB0T4DT0Iv3g85Cc4WyRuaSN8DzoJrBJzEEMdkW0S7Dz0TEic5tbRuOE9TP4yE+iPn4FcViEzCkz5GfKj1RjWbll1pF2vSrzQv2c8EUyJzbLc5pNLzKRIReZ54m0kuyG2xtf4K1FbCV/cX+v3jzHDeJujY3M8lfqQlbhPOkv0jWBkUaetGqNTXPQW9CV/zG89WPjKv7U0fYVq2WBvTgKpT2MlLQJIzEkkIggghVhO6Q0khiSShW9FklvRVVFYoUr9yWEcJaY5XGyv12wL4wlesolEolEolEolEolEolEolEolEolEr1TcDc4m6Ni6knQe2pBm78aC3pGsXPUvSKeTWKaBiXfJ/kTTrz2wbKMbFnRNW+AsoEitglkkszM+XpmpQhY7UmufaskfkVqq33RWqr+3N426N8Dwps7sR1egaPon1Fi2Ys8LUYGthZZEs5sh46EfOQrVX9pt1HcQ8DzXfEkzyUiSgRK2GKI8fPcVvUPLqFgayCJEznOB+fInB1sTjjLRfsQhWpGEr+2t452LDfxh8TVnKiEsl6Jqifo3imOnkVdHViosLMgW85+BNoxbyDwHp0wameO2zzWo4J6nZt/QqXt8k/JmR61cugmJ4FgjSmi8aI5CFuKkiuJxPUTn25vGxuKtzSw2TRvzmTQ/h6VqaL0cYGqJ6fFWqOH/tFq+KQRFJnT2KfsjYTIRDVmOQRJWhp59YHiaywlZd+eQklp51qtR4/YFqqPQePOqwNSjPnm7JuE5zd28+4v8F+v2ad6r/fcH+sTJHDnVnUarE5wr6EGbzf46engsS/RtYGhiemuFJ6UgijiG3aM+izHnbatsTf8CcilCc0yIENWfyTqXxwTKIU5YJJJJ9bkae9FG2e8LBNV5+D9Tz3H+rll3EKmvYmHR3omlWWhezvBJKJGxsnuSN6kob8+oqAzeMz32ELz1fqrEwJz6JrA7UT/wC0YlOXyWwtJu8vkggewW6ie4rZWwQR2OulaqUuJgSSsoxx6h5Bu+G0s4EcF/wp4TPmWUWgteoqKm3TEXtV6TRunnUkb+P+jdEyTIVtWIWEP1cE+jeWHmTI9hKFSMEmxU/JGBSv4JGWGWvbGiGyOT9shMp62plXfjIlCb+tzz9PpLgFbArDJltrsSkS+CyXfTotMC9wN1dG4pI2NyNjcajmnll92hWSFEEvl61qk+he2KYYmU74IpodQP60IIZFIIEyuXsJtCaeGZ4Mkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkks1osCG57C5CUiREynawxo1WoVF5NFVe1t0mC9G9qtk/5mNiEz/wCvYgZlf+1yIpCUJPl/L2Bqk+gawOkjnQt0xNKt0LvfFA5IM1bI6IgTevzVL2phYWhRvRXNFFWiQ/8AOZDaHp5ka0VjXsSXovapo3VukwN0b20IHPYa2l56n00F5/PYuTXonViUo+eA8w8NkEDRFEPA1Ip/gQ+Xm5Ik7k8mTyftNgWBsluaXG29Nuh5Yj81Z/oT30FuTsI/BOhLJJE5wWfsbcUdW/ijZ+TXmNyWCzayN53K5dfsvJr0nIShY2hN7F892QIjA1sNbkDmkCbmQmnZ9mJvUUae03IWvXA0jX6uiQvw8CJ8izV+aJnFyovYmSyWSzmG2TSR/wDKmyfOY2PNCSvJCrdvx0lvZuTXHeBNXfgNbdm+mBqC5BFYIGiCCOwnV819iadn7SsdMDRSzuKPNhXPoVcqSoWd+QszMloVe9F5qTG3b17eG9ZdG6PcbJ8uNto5bchSShl/wL++08mvQp8cFpZ/HSiuRi8IisEMuQR2E63cxk7MT9mdwqWUsuzcVhGZ10VfOplEEiNVnVWw8/Xt4b1l0bo9xskySpXppzEO7/guQvauTWtU+JE8HqHhizVYIIIIIIrH+YGoGiCBOr5r7JbPsJ+xyKrlltRaUWMiRFE/86CycjVUTJwSvmk0ST6h4G4qyZo8hunyG4/gnBG310S1kyhm2j+OQvPj2zk1VMnFM5YFwcx0WSFkLgwQQQNVao1Rog5r7Eic+w2daWDab12wlcWvXFAlRocxP5Qsyc+Is/StwTNWXq2Shsb/ALRv4PsLKkl3oluQRX9Rvb+TWCfgkbobnAlwZjd5Kqy6C4kUisUgdJWz/gnRHPQTTtn6+7n4pMIu5wpFlRa9BYUSjOtb/wBJFgWCSUSiUT0GyWSyWSyWSyWSyWSyWSyWSyWSyWSydxslksnLnWRuTkiSeWZIw9wtUNd6IjuZs9Rsklkslkslksl+0kmo4Sz4TdFZL+4GiNnhjYRGKCBpYEUgZAk8zGivcSPX1jafNENL0TrwWFerd+A3pRjowlfDXeiWsl2jdR+9kuQuD1B5ISqlFFtSBLDBGGKRuiKwXGq5qx2OthbxNP1GghI1gaMncWIqPlcVsD5XwtSofnQuh9udFbh6+ibwvLCbkbJ/6NP0ZNE7Gi1IfmbqP3Qk1ItsaXzwugLUjCtD4PbgX0HWKRVNzCR8mSmvyLchI9fRtpXGzyVt6zBrXTvw/OeKBzzj+CbLiyrLFglksnyCSfJJ6fJPT5J6fJPT5J6fJPT5J6fPAbnD5NW6tnUeolTN+pbyZVz709j5v7qSSbYks5+OFAo1dFH6wQQQNo78GMUUaGnyq0RBeqBNzISPk/hmb/CHpK7kH+HOmJ2vyTxGq1Juzuzmzr3HmJVSqqK1Fbh8xz/omTNEa0XHlkslkslnXC2Tn9FyR/Kje5OpOY39McDRSW2hvJv8ly94JJnKJJJNnDf9Aktaxiab8KMUVa2q0QNEUgTq6nmJHakIiiE1fySupykyWx1DoZ0M5ByHyTv+iJu2QsCTNi0v1FmqxiViBacNk3kxUnPhr0Dq2SOjGN/H/SUpE5SQmbMrNtyP3ok1FcnXhRKFrfpRKKRn04Cc8KCMUVaIdYIIQ0QJ1fPmhOcXwfBHT44K6DQtJEqwTnVLDPkEsXCRNNMhs26kk0ROa1onGOWT5BPkE+QT5BPkcFuswMvRuR5D/wCiCEs27DlG7T0X795JN1tc3cKbhuXPnIVEuEuHGOKwRWEQQQWFvMuKsyCyY3LnCliXnzx4GVlhf7RMTgWvWq9G6vIkvRuRuOY3/wBGi66LVlo5rNn993JPE1PbBOOZ8l6WcSeLGOKwQ69h0hGaFvJ4GbEmRXNlpg26CUVS9JFl7/0mlyYwL0LdG4JJGZDfwNpWGxCU+MkaXO79Q/Hu5JvgPAsOfdl1paix6TiXFjHGCHWEQWGvP2Zrkf8AUZO2CCGd/O4qs1khYFgWDzT9+hSUaM80onvRDOhLwzjeL9jdG6NjcjaRljkvfZyPx774WNOcHQFam6iwWIIzmkFyKrLjxjh1awx1IIIatkLY7kzrjbjDGXfCl6WB9ORZw1mvFVP+FuM3iY3gf+jY3/0fZH/K8IhJJLJJRH6928PhvHlw1/AqaCwLFFGoqnHoIxQRWFQ1ggghq2Qv+gnOBl3L0thSw5iqrHmn7PNDzQ80PNDzQ80PNDzQ80PNDzQ80PNDzQ80O/4JM1m19onUliklk0TgWJ4ZQ3I3T9Ejfz5mN8xvTxEysn+QqEZEJKPs7HY7HY7HY7HY7HY7HY7HY7HY7HYfl8xFPkk+ST5JJAgQIECBAgQIECBAgQIECBAgQIECFEkkksngySSSThka5htJvXMQr0VsE8ROCePBHAirIwwWe3QW+RZ2IM3TBfFE4Vb0aynR/wCG1VRcdtid6PzoSN/wYeQkV930JzEi2rt3b1b/APC0uWCTCsFeiosH84MYE/QxwYwxhiLZFw+dhNWOfzgWFLErejzKBynBJnSSSXgnYl0/ROCWPITR3JGxskY2kTlIXDfO3uRLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZm9xae9Y0K7+hCvTULjxgT9BBHMjhRSORAh1iT8Dl5sSazTzNEnmJHb41or4Y9VA5qwtthOKpxRW4zdJyGxsgfohf85/R/8AiPCGN+chts2uxWFvRCwRlxGowJ+jjhRVjyznJDT6WVYIEq+aGLfd8KXquRIhZ360VV/0sLXrwH+v3RvAxsdhoWdiTFlqfl/4nwybCzR/NFYVZ9Al4U/SRtwoIJkLK5FelTxkJXMTuVESiUT6mNGPNH3RVkQsTdG5qyRssN7jp3k/Pm2/orQtNv8AxPiFQ1v0LSqaVW4r4F6JP0scGNC7/B58kHMaYrifMXMS65dapeqic1Y8dFVOithTTzTkZ9D3GyRvz8kjz186iH/O3YgLhZOvN/8AifEX6DlvO7IIfzTQWgr019FEYU/TRiifgzebzzIrG5GCKQQS1YW/IUaerghN8yfuizNaJicC164M2WvpoxOw8unyTsTR/Qkb/o220qcpKOwmGc2e89l/4nxbMn8tEW/JdRgSzovRZYk/T5VbjPbyD9EqxHEjxmatkJ9V3ErsSSSSSSSSTXvxb5bkSj4POtcqfwl4EkY67YWF57TmN/NYFPjZE0LJrud/f/F+3DlyPJX60VGofUusCvgVvSp74pRKJJJJJZPP4J4dksn8iolvx4Q/lykXNfk12Hs8s+JmZksl7kkslkslkslksVpzVhNk5kipORLMxNkIga/LHAnzyFlM/NRJF2G8szKzPyW/p7/4fDtld9KiUUSF1FpTWiwL0yejfp8uF9eXLg2d8F3AY0ennYsDlbs12G8lb/IZNSmmt16XX9CNMJZkJ4pY9Qx3gfwJA5WbSHWfJX00ghZKZL3/AMLfhIWddBtttvUX+U1o80J9UX9osC4rnQz14M7+ljfT+iU501XAedsV2H6o+Y0n03Es2IcskT8LFrOmvx6R87ESgTyqqzVo/AY8yc5jZCS1FwZXn57LoQ1b4EuuXvlhi4TaSl6EqdNFgLOtmXTAsCaJRPCknhp+jgSy4deXeuXM6CNaeZzV3RkKjjDlvgNIez+F3y/TuXzPsmXyTt/SfIJ8gnyCfIJ8glkslk9aFjSVzQqE01NS5JmOCHYY8KTSc3ZsvGVYMn8FPl73YXCnQsvzdEqa4PsonFJJ4skk8Wd/RT+WiF08VP5ia4r3WC7C+xlR+ZSZGT5ncaT6jX9fgav+R8GYqfmzJ8seXJ6fJPBlkslkkWasxfp/yilizJwHQ/kuvPbiNrLLBcjRo2M1tsJHy92sSSLhda1bLamtVGmC5d6qwrmuDLmMkknYQ6ad+JJKq8xOL1lEokkkklk8/gknBLktrzoppri6mX+4fMzRmRkdMXc/tNNyKwNSbl9ZF1yLe5lbbfxdCtl9cB4moNb+SWcMlokWdE6f6HQ5ZbB/rFter5vVszRLHgY0J2M+Qk9ysTsS+JFhXWqvqkYdHUVuFlzOnHlEjwtifGj3NeVetPyLhTO3CfQdOxlTLngdqNLYzFy/A/8AZ/Jvptd8OnUfLCsKa7EkidCo/oY8ECL9dTHhakhjUkoJPP17f4b0wLgqmfwNtm16KqWG3uKk1n0jJwtks0onBKwh0E8iSSSTutD8vAqSTz9LJ1bO4zuvqi8ij6V7Uhf9eRleRtm+x3JW/wAosA8tI4EusQ2tHY17E0VG6M8f9XosLUkDpFWiBqTP+DNeRe1uG+K2kl2GPOmlc9KrDpFWzvSxPHnxkslmeGUS8UxlPCQksbeZ/wCchYFgklcaSTpJPUkb5ksvqTG1Puj/AF+69zzlTsiO1FLSzXQ0wu7yZfHLky+UTaz6Ekk88KSvwJ/9HkTSOXI6E20glKaa7vfHGJkUgWQtLXnQWfszhm3Tjy4VmBa0WK9YJ4kokkkknHPATRcBtK7JfLREoleTRJPUWzI5Ef8AeF/wmc/8Hjj8Hla/pyi7jkIeBniZzRzxzx4j/h/qP+H+o/4c/wCTOf8AJnkbPI2dP5M+wfnP5OS8uY879v7IdboPX+Y/BkeT8DhdGn+w43R1RyPwR3fwx+U/ukhvJluu7Pgz2mnz2NBdv3S5nd+hPU55C3ont/QnpWSen2SLDlakipPMZJOhf5ByRA8bWNoh0jz+Ga5C3rLcTnX2NxPoJMlpz5ir2FRdMTz6cQs8Mkk8HQlUdHAlbkCUTpDfnIjT8TOd+BK5OqPAxan2E9fodb4PIR5GM5Q46sxf6x/iSf4Y/wABGXT1EDxt2j4Q9d/Vn6HK/Dfgb/1NPwxu1Lp+xsei+kj/AEPQT1TfgZ4P2PSb2PwhqsnfJP2O4fs/wSO2a3f5huLprqiG5K3XyZPYvv0ut7Mev4n0yzpOzzfZ5/tGPPLxCcShOuprw6fzBbE5xOdCQ6Z71TdUJXr64BJJ3xzpwdN3f6MsC+6rFMuedE8EsTNe1JRKJPMyehPiE0Nslksed8Eok5GfYk19zlvn/TlH2eBG8HW+TztiV/I5D4VYpMYW0QlwUl6aCOBBDIIII5EEcvshjSdxtu35DRPb8JjNuwv7TEfiS/hoarpc4fpid59TfU/o2e2Z+WRHlrX/AILMS+Y+6I7NELJSeRlurz5ny4kDWJrBBDIM1b7OZfv1IB0078LnwLBf8DF+sCprnYmBOcDZRq6K1FwJY6zz+yeZeyb7G33lH5OWl3N9Dmf4Oq7ngbIf4IhbcZ4WhF/Y44LmsEVhkOkdKRyIPo0PyL3zD9TwhfaqPmGsj7sff5JEdmazG2rDm5I76bEmXMy4jgyLYXFcjL/K/JJXIPUkkkZAEolEolEolEolEolEolEolEolEnUy4UzwI0K76olgX5q9OhlqeZE1b7FJ+ZqsvNSSSSUJCGt8RLoX0LXRHM/wLmvq/wCEWjvn+SCyLsl6hxV5C/s0EYYI5Ugh1ggyI8sRFIIIIRA0c0a5ElZum54L+/oGvJHia8kdIwwjoTuvXQGLHB5uyG23LuZiUYFhyMtCTJhXf4qsQE27M89MxN/rJkl0Qt79kLVl9/4JX8p/JCVlHsTzci4K9RDduGWpBE7UQQQQ6wQ6QNUjxEUaOgOxHLl6JrE1JBDpchjwQf0Hq27gFrPwhts2u6LBJP3hyHA3CyTfJZyLPat2jUohag+mX9Fznf8AgkWRdvaG5tVPgT67sdjtSExI7E9auCFoQZHchkELVEHajgyI+COX6HJNGe31rt6NvlwH+v3X79dAkeeKSeopJY23nsqo0wZcyH2TyZGz5yOckLe/j/tCNBENpduAvZGnLCnigiPXZGegsHxSMLQ0RGmohoikEGex9Dggjyv6Q0PG0OsGXAgZ7k+hbeBUdMyBIY8/WiwZUlsJ9WQ5iRpVUbgSm/tjaKkEEEEC54UvYciI1PM8OVCwtEVaIZFEbeMzO3pG4JRlzMj5/wCHTC65f4ZcCB5zMtzoTuShRi74ErDlzJ2wIzPzoMzvnCVkRspOQJtWQEi0WBKMDy/om9KJVvi29iZq3BVVb2T8SQsyRnrg/Bl/074X9DEakaQLAz39JkNbDxwRWFsPgQMhUaVZelECcDfDeSX50Gr3pZKwl7b501ISwpRgnZQR3IIwRiXsL4l/aUIgfPB2pGJogz286+paI4D/AF+6Q+CA7cFBapK3JwJMghUbSUsbPRWolgVJRyfZmyFSMMezvI68VUv7GsUEPHnVoh1heke5JPLgOdCRNJfo4DtXJ2R2D/BEJat9WKsiEk1VCaJRK8RAkl7GeJGGOAvYb+5rgwQ+E4I9GbgkfBbJ40B457iboc7OVgvgQksbbS+yqg7YSWCMUcBewvgfngcxP2NcSCH6lviuOdqQTsPhQHhhrLuS3ilDRcJkksZ5n2IIgWYlVZkVgjFHtTzxRmQsMEYk/Ylx4I9gfUnzUb8y/ZJPk08g64YHmZ9ec6PBPoR3bISthh8BsZtL7Igj4wRWCMccKPYW+O8uhGFP2Feigj1bZNJ+h8zLhQLjkJmTIdeFGCCBl1aIzzPPa2QlggiKIjHHCj2JvClxYkjBMEkkkkkkkkkkkkkkkkkmRKJRKJRKJRKJRKJRKJQmSSSSSSSSSSSSSSSSSSST6dsljp9FiZxP9fsYhnkTG1CT0+znZC24zWDuC+eBFIxwRxI9ibwpegj/AMTJJdk0nxE174G4Jr5sNaFgLeQl6F9aJEOSv+Dm74CUUjHBC9BqR61vEp9Bnb00vipvP2RvBLJ2xtwdGCHXoK1hzYj8BZEQo9IDWtNBVS3rGKCPRR65v1EexL2JsdZ7kk4mS6bkpCX7wX8S/pYDrd+n8MdEOsYYI9HHr28X59JHsK9a3BJPkEk9O8E70SSOskkskdJSuTN5l2Q2WbNCl7vMXnT1HiwxoVtRISikb4YZHooI9gn1kfHvZuBuaedjz/pLG5xNjwtP8FYrqYnm0vr4EkllHbL1XhuBn0CZengggj2Jl8Meoa95MdUNjwtkuk0ZLbyNs0I5FJZ0urzfrPDcDzpAlhjhQQQQQiF7alHqYI91N4Wx4W6zRkrsS2LcXTy+EIkhEui9b4cMBYVwpJJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZLJZJM4l6t+tVOx2Ox2Ox2Ox2Ox2Ox2Ox2Ox2Ox2Ox2qhseFuCR4GNP8PyI9uRHTm52+PX2HsqhLDE++x6xrH0E8unpFf1D/AF+8TY6d6MfdtuXXL99ixqXu8/X2LDkdMxUK84Uvdnnlpjj1zXAn0av6ZvE2PA2cj4Lzl+y3331fsFhwL3IwLLAl7tfHHsOfqVf1LcE8ifP1SSYGx8xnfcZa1L3v7DYehEb4VgS92vjS9jjb1Cv6hsdW4obgsSFuM/ebdi9hsN9hFXcgiBe83xpeytcC3HV/TvA3TNoSX8ruLvFvpexOGi6l747us9PdteXAXsz4HQSPiq/qESN0f7sYhyUcv77E4ez5EqxhW9In3a/TgR7RD4Mle2/EV/UMYpimd+XUzl9R2XRexOG4M3e21IIxOkb+7X6cCPaoxxkQ0WsJ/PCV/TyMPu+G4pYSy/fP2Jw9CI+aRwY92efTgR7ZGOEQMTavmTPAV/TvRq7bnVNP69icNwZvpSOEvdr9OBHt8RbHEkQK+X+krpjV/TS24KfGQjPmfEexGOT5III/8BfpwI9xaHjgZPcTnCr+mSm7Xf69hSubJ0AI4i91efBj3lpVrZ9zJl8veWVz7DyFlQgBGKCJ/BBcdjnRe6XfBj3SCNh4oHSGrfYp3yfurhXHLJO4l36i+hGIxGmpG+Ji90vwY93a2xwhqKXM1bNbCT3E2Pqc2Zty2JCWZBD64LEcJb+534Me7xWNh4mlcxKc15qJLPj0K6ZSy1dEzGvLwtP6P+c3tHT69UzYzf0PUYvo5CErmfb8iRyp4SkjhMXuLcC34Me8tTWOA1NESPV9klfNbiSzXiIlF2B9rE4o8nN/GyIlzJndvXqIdnqHlmNNM30czsJCX+iEcyOxCI80I7i8Tp7e4tkb8GPe3nkRSEXHjjzlR9P0PsEyvmhI/wCcBLKXm/wLR7+Yr/gd5kTtfAeNyBKmXP01h7ERcZAVESQiCKRxeDFf3B8iOE1oJR78eY+E0QyCU5rmJNcqtwpbyV5ySMsT5VvyyMs5ws4dX8HLSN3dtP5IIpBCI8/R5Y//xAAqEAEAAQMDAgYCAwEBAAAAAAABEQAhMUFRYRBxIIGRobHB0fAwQOFQ8f/aAAgBAQABPxD/AIhzN5fNfg+PAceT7o6ZvL5rXyPigaxd9hbz6PRJIrc2Y6NfbL4CwfHfpIJLAK+WfalSyVXN5fBHAtrN0OKnKdWe9s1n5ffhnvErtvvrCb50Pv8AoW/gKglpJc7qyiAb2/ktGJV0dDvRj/V92imtUe9gna9AIhSNovzQLVO6Fd6uL3aBZL7NCE39qjz7UAIKyi3gDyNK5vZopC2CT76VfkU4Zse/7iswuwo/WsUFixbJv3ihMjBrDLpQ6y91vWKXW5ufdCP86hm1cR0QDqsRv5FTxcPRvP8AUbf27uQIt0Cf1Z8q7x+vipENJb97t6xO96Cvz2KYjsS9y9WgeXnRjeLelv8AjHHD2fijwCSKiFOWPro1t2+2jCjCIC1AH6E9lvdNPUR3X6DBsoRBMPWS2g/50SOGT3JfPhgOJm+9COKz8vvwShhec29L0Etdylp1otEW6XLlLBdm65j+Of4Zrv4CoIc59ae7o5dwaINzafTPQiRoRx0IaenzQjjrziN/BKXPTSjfrtp3qbxrmpGMU2k8p90Coi8Qn1PqKQwjo5H970LluhF5riHvpQi0zGnFSC1vOkdIN5oR58M9Ib4109aEYvStA86J0Uq+Jdov6RUGNdqsAJTEmdmljCrG23u/q7f240EszOAX3WfKgEuD0Lfir5cKlg5P9rHz+qiUOT5o/b2ip+fi3/HBzQ7fb4TDO/RrJ5fFC0xPt6NILaEPGp0eiCQ0dMytFz7Ojgtr8a9f0uHhTNiTuUIZMHGjw1nFsTKgvKtdlWgZp0n2oByPcd6JASzrd5zQpYr7h7TQmQeY0Jl9D+Gv/eaA6PZfxX7L+K/WfxX/AJf+VzPzj6ag0XmP4r/1g+2gd/Y+ipGfUVE9wKTqQ2vR/wCn+0JbB9I84qc4Pj3aUuI9fupd31anvPc/FLKauYn1oRlfn5oyZO34rmPlegPDtVvAcAnZwjw1ziyoHeHZsnfouHG95oqUxRvtydRhmba/mhHHQp6CO21SG2jSAgA2QR7zWYFxllhX5rTwNZSE6GaisRG4jJQ2Y7X+qihjAToxerH3FCyJm/O1cR+KgZV5iK3F+zPnU9ApjQjfv1mNJ9PuluQiSXNjypS3ys3zpFDrzOI4Un+rt/aPQiOOal+QCRvljUQow0lymtoq4OnHLF6gmdTFCz9zehLbIL+KIdyPXWpJjie967uvy3/4xxy93wiR4J9OpN9Q/wBoqQeS4jOSW8yhAJIgjqzefBk8vjoMGyhEnSJpVZ9O3X9Lh1QSiMXYoNk6rBHq0nBlmV9oPam3S0Yx2tFBBSdVSPzVoRdVbtASAEuAjFbVBfVzR0wz5beKPEvlO4aU+gj4pbCOy+6dIfek8K8E/NIfAH3FPuCCgdyaSZB5/SjX959bUJh/fPq++aRs538QEJBxCp6bLhkNLUDBoRigNx6YoRxQpBJ543yUM6J3qeljbGP9oRJG1HSKES2C3gKgnZxujJ62rBW6M9D/AJSLDqIGCFnMn+1tGTdelG7SPehs296UM0E4vTbRe16Hl5n2pc9kD52q0Pdc8qdhE/sxRDEX11o3GrtpstFZEJ+g48J/S2/tOlaLnKSDzxSVWXtqzc+bQBjj2sVg4L98UZ7wPaatZiX3o2UyzPcxWBG3+tRY6v8Aqvxecz/xjmTy+PEkKdRCm1EBnUPSbVugEXVvG3R6OXu9UhjrOL9WjPbn0ZrA7H4qUggCo2KJkTAaxrqdBSamXae1GwtJOnegix+61YE9dpvQQBQShvR01qUX8u0W8MdH+RByD3JpRceQPcVNggxo29n3SHwQx6jSK0DcjTZhS5sN4T3rvH7xQtJejU9T0qGsnc6TXfpsL4XN7mnepcC2AXF74okSMlCDME73oivbnBOtCMUHW3xWcM9uhZEzQdbe/glNazxb3oDx36sIiAbIgnvUkpeke4MUGrlXGxzlQXXZe3x0mp9manKR0t/nRoT7yY/daMtuug7tKjC6xJljpPUl9KA8d48Hf+jt/awECNEAMMifRn/aEsOMtYLXf/Io+ifxUzL5PlVgOT1WaLLzPxFZY2J+Wrc524j8/wDGOafPxHXbP11Np2+KeazBdZpJhLUiAoETWSeur3emtKg6NCJJh+OjVxbH1EVi8/mkXUiWw5ocGC2K8xrV5gz90Iu72vRlOLtCXtf0orHzoraJnijff+skxwzWp3n7UdMQKmW7zVppdEZv50jibybzymt4cqYN7VAYR8xKlNpec+zRgy9LefVCAE1G5TyVrJ2Hs/VBmHcHHk1NKG1uc+UUH2qYSgNsP7jqMM0pOdfDPW7v+aEcdGLET50cYoZgT9gWpJIDBQQ2ZgXzpXkaIE94qJvp3pIgCKeCNselWi93mYCtj2YkSb/DWjU5a65Wq1O9+7R1FMelBePj1/p7f2XjJ7XUKJdYSjrcseVRkdff09alN9VEetFgNihB3vQlirzlzvy1m+96F3YMemKi3lPwqQ3iy8Qi9xaRBZbGLbS0RpEcf8M5id/rxpCmz0awPL4tSZMAd+R8VfK+ptoe70aAIcffR6MC85PMvWvRTsC35atdAcedAJk3boXDUJmolCgAg6AFjLFCDnWjPk+aOhvOkff8j/JJfX28DSk7W9Do2AJyD7NYBdyPbHtQPiH2fipFUN0Pt/lG8jcbJQ2v75dB4F9BZPOlJvvn3WEelnA7TVnik7O+POgvHeu9Wqxp9+lNLX8snNCPgnc+r4BGkn7rRGAMSJ8x070gsveyOy/z2py8AyFVe/2KSLF4hacmhjZNs5eKADAE7q1Vr+lC1v5k+lCOPFMa+WkVHy3/AM8E/wAu39nJIbMTCRPLTYCa5Fbvm1YYyjXgioCWbX+0oSAbHvQQRRiXy/NGDveovGtvfFCA5v6+BzKDh186Bj5HHk1IxZLS3F5qMWZJzt/wDnwPGbTt8dTadvjoISIHzMjRBi4dgS/mmpTchop6SkrSXO1YDbGb7EVAEl3X/OhSWmLk2KCAYdroW9p5rdR73+aEZieDSopLu360JZ2+ytKEBzeimhAc39f5X+NJEa289KGES2t6aWpVz1LI+Kyh3E1lydJEHk04Hxun970psjW0nqR80hxHEzacWpSUZlKFa676EZ0mpc64dH16RN9aEcejmiRkoOtvfrKYriKHN4jcmsVPjtDMJCIlnlS8zgswhpQrelEMCNclV13TQzEw7Oes9bu9AeO8HimOKN/r/hUm56lSbnqfy7f2ZUYh5vYSU8UEnAObaTWDaZnGL0IL6q+uKOuh8taOWPJzUB2Pmiy8z8RUShyfNFl5n4jxuZQcOvnQMfI48mpGLJaW4vNRizJOdv7pz5K/B8eJJI3+erURPDFCS+C/5pgVi0zzYdvzUIDIJNeSPqpL6h0emT+6VHxuXaKeebbbU1FLQc3f8q7+ib9QVgcZZ50rg/VoYP29BKjoJHBP46n8T/IgkNQdv3NHgUWjLn+HMk5ue1A+Azjk/FTQk0Xi902qDK1ocNNKly8l/NB1t8dB6hQdbO1S0ZKA5t+71M6z5zXfo5kttU+Pet8Mb1nfGDjvU9Qa29/cpLkg5d6xYxUxqhxR+O0Qs9z9NXaLuPoChqBXNEiRkoppORQXjvQ7Po+FohcO9qkyR/Ji8/n+xFcoWmN4HLI4q13Ig/zit2x+SsDse5FCDvehLHrQuxp9vQXdgx6Yr3mfr+JzKDh186nBBOGOL0KxKifrW9GMzz/aOfJRjxnD5ffUydv1rWiRG1k1CJatiYZ3CPZ070iIyuPz0jpk8vikmHZkeSn5T4aKBXAS9ioeKbi4pIdxHv0BRaT0Ns0AYrUfLoII9aKaCCOkfyP8iSRWqbMeB980M5zr3/jxm84fUpBXki5NuO9SA6GmCM6fMUTZdy/kqS2vzzU15TaoLaX2+asNm560PU8/8qTc9TpNW6K7vrV9Z86aXiF13m0H3QAAYPBKYtQHCymOzpTnna3lRVRLsqRdFt6ESRko6COajzRsfR8KTWRvLpNC+9j16z4taxefz/XCTLqarB637DWSsoU4lxPtRZd2J8qwcXfmglitA2o2Uzj0oQObvdvUXjW3vihAc39eoLw42mU4oeU4uQ2qNhlZZxpQgjP8DwONKlZhuTni9MbGb7H1/YOfJX7eVHjRGHqYe96tedr9p1oKlRLhnerotgN6cDjq05e7801PaF7t6NmXAbzZpWXGY+qVrBK22igVjWh5NBKe/boEsetHQXvp89D+Z/kkvr7UeCUxQyD/ACAISSpxMVyD3H3TxKRkMj6e1HIG4x5RRiOsXGhnF6AsPxS63Kh5b6TtQos28n3pyFrRxNB1s0I46LBdtQb0iWawsQFg7eA6ymGPIpNKk4Qh9L0pKrpCyxkv5UM4kxC56v3QHh5qekpgO+tF5MY0G3FTOPCk0OyWfapDAjt1nwa1i8/n+sDs9zVipXTEGbth5LtG58o2TT3qRjct6xVwO/8AFH0T+KGWOYOWsH636BPBjzmaCCPFMa30NfKgze7myjehkypOsfB/A5teGNInNBzZNJ24rnCdQPcoZDXmLu/9U58nQ8YmHbPbXqTfUP8AaKyL5NtuKA5dS8ByqDLKI2uZHkxX46ZPL4ppgScJd8Mc1xGBLBuzWby+akADMw7WJqKGwkaiXfc6HXy++h18vvo0EEf20kikhTxqTtb2/lu4XbR3qdC+zjOCr9d7L6YrAwLgwbNbLSsk5EY3/wDKA6nkz0Khs496RrHepJhbr3qRrj0go3L6LS0AEBBWEa7ba1zez40qSOS5F0k4avc9wNW5VoYYnJbBYoTWHbq9r78bRQphRN4ii+L9qnwJQ7JZ9qkMCO3Weoa3d4w8v6xMARNaAVZ8qQxl7LQO0CjBy/pU1jLEba5qy2z/ALQh7/8AlCUdC/npRu2ReH7rN970ddq35R9COocHokPKanpfTOfT8UJr1tPPfTtUiw2ouGQzvJ3Zovhnt/At3Pz70XRZ3Ge01CLpJ9/6Zz5On7eVHjEMen46NMGPSiR3D4vSSXpDW+AvHGNtakQREbiYZ1OmTy+KIK2AV4im3KsgsCRMVMMr+hzVyTj5oJGz7GFTE3YNizQn1h4oIIoJ8o86DQPToJZ0Pn+6JIq5Z08Qwz5P8w5Z3plC4cPQCAGyD80ll1tfRxf57VlmC4ybT/6UHD670Mzwp6VOlLa/qum1JGcHG9FgCy0floKxh05vFuoph/fOhmb1zez0PAnQJHSLz9RUo5jBDPJ91BocmG8NAu4zCI2dqnphk8q7fehHD4Uodks+1SGBHbrPSBi4RMzBmIqAWLakPr/Uuy4l7whic281Ypti6YZ1880Fil0MFrP/AJVib2t7UMtVF8uggA1W3x90EHzy605Nx+FBBHW+bfhTz8vuuRPa/rRfh9Z9mjWCmxOmIoleOGc8UNEP/u1HO+m3S+9tud6TFoxfFdn5fj+BzKDh186nBBOGOL0KxKifrW9GMzz/AEDnydTxi07fFHQN2p8UUYe96Jb7J91MEZ9pZIN+mflVtSAJBYbTejqYxG21OI0felZeNPs6BMhY0YjBLV+KEHz36PviggD+9JfXxqM47a/zIJCSUuoNTFSbnWVUJwebT2qMU7Nodj8NN8XFcshxE/mlUrabhrrEFDYFtA6TR/t+fAKYt6UMYb/O1COPEk1EVDOpcvd4ir9KeNzrQ86l4aTFAZEUZGjo0Mzf5oRx4Uodks+1SGBHbph6fDpaeY307UItk2bno1DQnzw7UTrnj+g6ketzf21qL3EJkWujeZPKhIs2RHJ5vzQnuxm9Ag0B8XrF5/NBLD2furmkzPkLdAuu4fzWqN59SfAXzZkjuTNGtbymhHFefl91e43s0jlI5fzRvW0gxbeg7PrPzUzrPnPWRhY2JmeKIixtKX7zWGVvr8fwSEJge+aEgkWjbTeaGQ15i7v/ADHPk8B45EdQFl5vRk7frQkSmUiXIZfWzzQsaw3oCKQFZOJY0s1M1LbAMW0qIg9vW1JFpnfh2pUQZOMUoAWaKUTOYl7HNHL5H31BnXH/AAGMpbWPnxqGNH5/n1lnbInFSsS83nPNRnj4q9Ek7UoZoOcAvHoclWVjZpNtYfdKsARZHD5/ioMRC31jzoRx0F+xQHh2/wB6HTDJ5UX4CHv45RtUrE1LEaUZAljGAaR271dgzRgEbY8ygTA6glHRoZE+utCOPClSn1j0ocynsbx30qEXST79bTzG+nahe/Dc9KUJ8t44/nKRI3MXsryz5VYTLckys4mrHVp6X+6wcXe+1GTufNBBFD8PS9W3a39oOgizZ6pjuD6dBGWzHy2o9dv0oYovmzJHcmaNa3lNCOKWNY5M1LUBjmN5aCusylkHrmpakPRDvRNqMa37f+17/vHS+9tud6Hu4iuz3onXPHjx/wCT7VFxgteAaUjdXtPv/Ic+T+Oa4d+pk7X9CokimExvHlE1ZfgM5SGVirKxFxgES0FTUYdLxByc0kedztz0Mlt8fVFhd2m1TiS/I5okHLmmRPcMbWpCEwlumtGDsfH9xhq87V2+9dvvXb712+9KOCN7zfxjAIxzXb712nort9Ea7XyvXcrieqD6NdvojXb712+9dvvXb712+9dvvXb71AXu3mkVD0ku4+erDZGoAk61GnLgmRjS9LkCNTE0LxOOeowbGlAeHb/fA5t5b1Iw2cnJx0nwPgFgjpOAZs/mtNm5gcc+VGgOoCHvGlHRoZE+utCOPBrQpYfj7oWVewJocw35NtBpCLpJ9/BIydkle0xStI8c41/kde1zjipXRY8yUyOPlQ9qkb6fsUUQc5d5o66Hy1Nx2tPeIqwHJ6rNFl5n4iglj9zFFl5n4jqkoRdsZpGHZgx+sUA6xvOe5UBdc4LWobceLfihGWzHy2o9dv0okggDv8KI5v8AJQzc6CmGtv6dmtQbUStDyhTrF51xRcgoGswTQt5FNv8AaMcadtPGrJIGZ8u1aKXmb38/9oZMrdzv/Ec+TwnjENu51EM6PzQd0Cc3gcgTSW7AZLt6MPDTIpS8JvQT4GGCxIFLwIdl13aU1Tu860EomKzs29b1ODUPWghe9oZxThNL/wCjoJZ2+f7oXTOeOf6DUrnSx2ocOf4riG9LLwozxuUpLY/Hhslwd5ZniKTd2Jiw6cQs2BfKzQe7nfqhnG0FAw036tSZz8+ORrSrnqBBOkzAcUuqxmVmO2vlQhgKZkD56tDIn11oRx4TAaSLt5smeSCkw5m2tt4KGTK3c7+AcMNIZfOaIi2P4m6v0i7GO5YChJyl+axxmOKsRrGfOamg3Z6CHv8A+UJR0L+elG7ZF4fus33vQu7Bj0xXvM/XWCWNB9JqGJ0jzmkw2YtpcRI+fmpzXiEstoRT3qwBLeFunatXHup3rdUdX/yuE82HNCY+rUVmxJ3Jo0Ftbj3oM3P3mraY07aV5+X3XI+3k0PZN+OakN4YtOr50NEP/u1HO+m3SY/8n2ovuN+WI3CiNMceOUdjeaLIiXdJ8z80MmVu53/gOfJ4f08qPEkkdQAQ0kAHus1iGCFeWIUilG2zHreokTpaIkEOg7NagMWTPEaUFrY6cD6UUHmI3NauJLlN0dbDilJPrxUp41try/3FRiQ1C2Ma1yfH9wkvGtQRGlNK4a8OKJYeNvE3s3NtHyo283Qc+1LbYNExHehEkZOmMVJZz8+Ajm/zQjj+O2zWgyI7zVyeZZ7Uwbi1kwzHVoZm/wA0Bw7+1K8rZN4zeKkVi2+D36mA0jGd8eVqBcMEnKdc0pG6vaffr2s70DAnnX1rCzJNuLY8d9CXakUCSCLDoxzc9q2pgjsRiiF5Isba/FHGnS1sUFfnsVzRwjJjnRoIIrPdP4oIA6uZ4AneKEB3nqnFscdqmV/xk62u8xp6QMoI9jB9qZGj6llXPRpCazRZ2uVemymutEtpLXSLaTRvNsbUM3KGKN9+daGbnQUbY25oMyDuUX2Z447Udp+sYK9/3jpeeKuzC4mzB2o4Z2tjYjxyjsbzRZES7pPmfmhkyt3O/iOfJ4zxZ+X3TTTMiyy3hjonknakC2W10eZpml12i+9TZEQVANa6XkHDqN6IkzIAuF1xRvkJYjagDFXmCkllvnyxRM3acUdhfVYYj1+/7rmnpHx/bBX58HEOxrQ6Nnb8UeIiIArcmgmW5h9x/tK7pvpQjcZrNW5vzi3ahHHWUxQ72dup/AMY8nEZoCL2+pyNSKo5jKrEHsJDbfqaWMEdTgqxooYczrBQtF5nfzoSC2n1OahiT69ak3Hk6GA0kOuzFqC2bYTF/Shkn9eesx/5PtQ9S09rceIiZcOASnjejGEoF2HlGeZqwFy/bmomzMme85osEY02oQd70EsUFfJ8zRsafiaC8xe7ypqjefUnqE8GPOZoII8SFkNkRDSRrKqMzl1JW9RWg1bSDZvei0kRHYShGMNILixw/NF2xxml4ibxPvzXeO9/irmBHaV9KGYcOufOg62ojTHFSmM5jco0urYvfZUFxtzjzoDki+Zn1oRhPu9+komAcr9UmI5l1oM3PHKOxvNAeE5Z8mlI3V7T7+A58njDLnxBmdI+6K4SF0xBPxUl9fnok6DSNvS1G9fL/a4qVFPDOTEmijTeimgSnBJ24oOt/bqpJ9e9JJFWp2THb+JQzUeX95rt96nsHvUt/YqV1fitd+/8CtV+Pihbvz8153f/ACh6npUeT94qSHXgvVtMfHH9kJfEV+Bh/NCHA+ztU+Ih2+KBgAd71fFbVPihTDoQ9BhmgJm/SamjYmaEcfxNGhs7UPmYslvV+auKdYcI0j8UaGzskfNfNCtyIw7zxRBBmGpm+Soq4S8GuP3FD0WNeXnVyVhiO5nShHDU9FLjUqRcdwW00ZAzpFraJQxxp206mA01L4XwSjyTGS/J5QHFCAYMx9nlQTZc07F6FgYPW5ahN2rL6VgPI+qSERLby3oQCkm2NRzcrF5/PgOu1b8o+hH8MQlKFDymE9anK75vPAPmDUGJsAVnRFPen58pZ9KkW51yxQaSvjJ2tXMRovj9ioNX5+a5D80I4pY1jkzQ8Pqei9Fnqas4ZCga3XsTSp/E7kdRYddlk5mhEt58vPjVkkDM+XaggbOtrzdfk/gPEYe96lNR6CptaXfyYpLjU11yzYMV3vao6PrDXe9qOZ/eKECoJymgxciZNmC3WYZ3mToHDJ70XB3D/uoOavY40fg8E+AYbem9E2HnCedXokebxyUBth2egp+GhHHUUxloDm3f8/xyWc/PTBiTAt6vqr9vo1P1tWNfAmEZiJfujcQvBh2qDi7s2mh8I2bnMlDOs8LG96gL+afxQFlsRG980I4ehgNGpJc7bs0LUc4szOrWou4ZY8AUsPx901L3vj/ylGWAFTAhZ7Kuswh7fLbrytRNtZO1FmzCxA+jFJbJFvufusfP6oJeWCiWGmd96l1y5oyxxc4qXXLnqkoRdsZobQafj+QwiWDlAj3LKbUPkRuHD0ip8R6hiGFV/SaHYlcGwkEt29C0bTNmobzc6Yn81fEkxrxQiWoYuUd7nWhm5Xn5fdDM3oSyQnJE35ijRrrr2tQzc6iw67LJzNCJbz5efGcSYvxRobLg4r5P4Tw5HJ8NFE0d3lSXjtFQ59qCc94qGx6FdmeM0HlUtBaUAQ4eTZoTC0Raw8TVifbXprPPpMtYddn/AL0KNra0zz9x1fCMNENz1q7ncMPcoNBk0GGh1PprtnNWL+unbwc/X/Op/BJZz89RVlAiIULSFns1ORheSsxgl9JKcsou1nGH5o3731elGogJlcX9KO1eJBeaAEONyZkzTIsyTOnvFI1fmr484+46GA0jIsxHNTSXsx9eGWgMm94MXNvNU1rkDaySWprL93zRl9PXSjY111qd/VOKheycev6UY7r+vQx3X9fAJcxt3o8p1jf+cFkJbuV7/kycVOMTfHa2JgaL+zhbheSfq1BIFYjFKZApoZP1E70cksdk6dDdfnXzoZuV5+X3QjnlzRNtZvb/AGiNm7nI+1DNzqDUJ7rB2aOGdrY2I/oHDw4O33RQK8MxxRaQPWDaadK3v813vauD3ajYek/NRsPSrZLLrH1XB80CxLmQ0c0JaRMrTms/L7rI7lTMNRjnSnJGp8fx2qampqampqampqf+Sg5qNHk25oRxShnxDDPr2rm9mlKVx0ZptRymfKhVMSuXL8UUXDNAdaHZ9HoXDNc3s0I4/gaJF4HvUm56lSbnqVJuepUuUmYihZWzveHkqeSLEzdrk+a1AAsmMd2ChDt+dKHDj/eKO7lEjzFWJQTcd9H8UQtk044oRuQd6xjooMzifKhJGXZFk4OKdm0+Ud+gxqRhxtN39tNFdF2JyJPIo4ioibikXjHlTJxCPuitGM6enQRZzQFsd/SkQOheglGsjjzoLHb4t14ZWFbBdmrSOb9z+lm4aDTuTjuVLXGWZTQASnmNRpkjmnwn1SCZO2W2zehl2GdiHiaDGZ0T7oHB+ToRsz9+dCMJ+vQRnO0zCiTgbiZLclH+DSTSKn8TuR07Wd6BgTzr61hZkm3FseE4dE8Z4RNmrlnT44a1pS5Zns0CrZLOjo6lcxQ9X0/2uL3adsB50hz2o6MoRI9qHjC5vz0GHhyf+0kRqZOgyfPfxW8EhlKhpfteuJ6oVPQK7VK4dk/NS39ihcralJ8ejU9h9q5iNAeO/gmj+q/0AIHpSznoeRt/v8ACMOzNSoK6DfyZ1qehC2eKGbnWUZ9aESSj+DUbWqdrFiMFdz6K7n0Vku2948veamiM7d2b4HMI1HrDBOrZXTzJoLrsW1NadnvXkcOKHe+NEt5JUNgkupl7tF1l99amXZFmddqGLn/tXXmIzaT1KGWUhmzp60FmZ+Kn3EhIlC12Le9FACzabvT8UpwjHnBE1gdbPJqDkYe86NBLff3WKiLbW9KtJi13yWMUIDm/rUomAcr9VIljWddmrp4UOx0kCTJ86UXJMNvv+oiBIuALNxpVRW+pXT8XpTsqGLNfUR7h91HwS4uMNsUIceufWi8izbISorMNtYIOhGzP350Iwn615+X3QzN6EskJyRN+YonIvCHWhnm/r0lMZzG5RHSU3YJtrTGL9L3U8EpilXPgPEWV0se1FCT9tQuvgkmeyi4Jcw58DSEtwzBvX4pHvoUSMlkoRCxh36QSW8jzRUwyfptRK/3rU1PVQzUdn2qfHvWdV7/zCPxpRvPOgNp6zU+Frv45qfCf0GLcffUyPDz/AIEEiO9KToZ3HFAWMOzboMNDhHqKPzQiSVNT4tvFAigRzKKNkbNZQLIUugLnq7UTfNsE9qxzpWQeSiDuaHvQO8mm3nQjk2qQsxa5Od6LEE79OT986a3bt9NMZ9aZ6t4IQTH3ZTiKA2WVfMTOa0htFjkwUYbcaFuaQhdfnoEE/stRwm0S8bz1Ou1b8o+hFW3M4+VCIGrMBrj+ugiWeEITX/ykVlmQglzIPRHlxSqEZiZENlhDzPN0y4naY9taIaD835ovIs2yEqKzDbWCDoRsz9+dCMJ+tefl90Rtk31961F+Y7UaGziYkddKFd8z6a+HUeJox0PFg7fdHSSJJktxDmr03rgthWkjv88ngCjG3/tFJJFCFKdyyYdSj0doOlE1MmPspSTWtDZusxnoofiu2GpXnx2q1TU1NT0t4xHNAeO8HhOj49fDBAZaCF2XP+f0WoLnmdZGtKSfX+AWuFfuqSgw6OjU0KPzQ4TrZ2WPPqeFoZJ8bZ3gQY4bVlem+AGl59fUpjQtkCYkXhu96LbXJYkxzQ+/zQZLLxGO9Dc33daCcmLfgvQ2be9SsiaNgC+gMctCIsrsb0oB1xvQi2use1ThOaiwGbT33oRBE4jk5oRuET9Wo4YktGTRTULr+3qAWlISd2haNs/PRza8MaROaES20jNuxSkXn04/sqIeSMk6uF4iHmhFjd1g3Bc5kjmi7Azh0jWhDuc58qLyLNshKisw21gg6Ec3+Shm50hIE+9Cyte3tQWZgY/UK7r9q3RKPGnQ8WD9L1q93pj5/VQRaOu3NS7ba8INpOlMTs660bTqfFfis3sp+alJbc1CRDQ0JNF+KgbLDme1MX727Uwyac1ELZBt38K3SeshlKk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PU8HfwkO21Ca+tqk3PU6zU+Camp8EhlKQBGuKzHPx/UguY67RM8UB47p/AFiTSF5d2ztRUFnHgkg2P8AOp4NaVhsfb+GEwyEXHcLnlFMKFvpN8Q+UNIJjsgTEwz8RUomfOEogy3slE1iZ3x8UCL95LRGZpcsGeFLByyjtFSZfZaLYpiHULmYdWsN+2k3ipEI/FiahPLbyokM6X5r9G2sxSFB2E57EUTECv36VKMmfSh3Fz5bUY407adZh25n7q7RBs2l9KMWIPnn+xlyU2zdrLo4355pCy7IpDgEnn60sSNyYakNB+b81gXdN/MoCm7b/J6G+/OtDNyu1nejeedS3SEfb/pNOfT46NRDHNAITN5asSTTLCLJce/Vr0ovjfoxcdm03ppBzTCe+NY3q8qsG443UcF5gSu22ml6f70mYc6c8NW6qGajy/vNO33/AMpTrHas6r3/AIp5TtU9vqoa272/gFGTNR5pLc/D2qSzn58EnD4VBy4q7drIc/H9VqC55nVqNpnmsuHPD429qvN9y6vKgmQc3nBjC0MAPrpUzh6DCUB47p0PBrRYvy+SP44kMCCtemztwicUhIFynZN/SfKpDuFESWWf9pItr69quoFckQ4vTvWDE21nvHwUoZIMLhNWli5e2B0BoIvZb/WfKgMEXtDqS2rO7gWYzpUwdTbzrHz+qvXzbzUKNuohtiNZ32rB7xovlPBIw+TivxfD+zYjf1I7VviEQpg/OI0sunafMXaeSgyKTuCNxxWTWdYhtvQcXU3D5mgZhjjDzpdmNfmiWYdJPuraY07adKobKSlp4qWYYaEYI3n+jBZiJ94KOhtO1JNmiSbrAS0TdzSS+LaebD1UM60U4ez8UU1mFIOY4nfan7XLSZxtUyJ34aUm6Ty04iG9kj80QvZM88ldvvXJ7HXGUqDKeV/iub2aQv8AVJEFzszPei6UYuPnMUDx559iuc+f2o/3J9UbyOUj2pg5OqCxviaIEAZlE41ofWO9SbnqUXxftepS0pxco3npXJ7NCOPG++aGxM4vdnyrm9mlCFt50SM/sYtPTm9mub2a5vZpq5nzx51JC4j1/ovjiuY14o6bRM8VD8kL5UIMGPO3r/A8zRBmFmaiYjUfinp59Wnk8/DrWLz+f5NbaPKhyF6YEPbie5DzUtHo4HIMxrpCec1OmXZ5CjDdK+e1RllyJfnmok0frFZoHnfypiFJJifpoLMTMkOnNCEAGo0jWpoNPP1qU2yPa+avF9/KeKcTjg+6EEnT1NO/FE3ndjtp4b87f5/bSSMja+OYmpMVpTF+dPlTEpbEBDsjzkH7ElSmg/dLoDmBfWgzEu7MxstAmbq6od0tQphpS/RRGvlpUqKmckZ5oG2Hb+c27X8vAY7iaxeyiTDvZ25pGRZRbtOJ4p9RuO5vRInU6Np1QnlSRHIPrTWfl905dn4r81vgdzShspsZ0jaamb71MM0oGfm1QyIdyfaokqq7tinkeV5obcSMhjP/AKobza5Gzp80ZEu8H596MTzJ+ygMA7AfH8GUZ7vJJesBDjyRKz71chBm1stvxWcCWtwxQkB939enbNWL+unbqeA3PM4pRZCL9Rskxs1bSY56kmXHz/QtVv4cowvv4NlmP2xWUZM8+Kams8g130irsNkBOaGSejVku8PPwFa1i8/mtXsfLV6vV6vV6vV6vV6vV6vUDYUmgReEM5+VABMTNV+yFvEnBR+VoTCe5QnapEZjbETPFJLsDAmdc3ikydr2S3nilNwiIh42vSRLMqxGxUF0m9u1A327zkEClbJrre3YoWqrtEjxFBcIvFoXgpViJi0/CtV1c0DROZuHnSkbq9p9/wDggIBEAIllDSqLvuYhL5BKsnDaAlMTZPrUhL+CnlW7PI1Y1igsS2bS2Zmr00s/g+CYZPKpriSJTUZzQiW/mguY66h5/no7p85rMxI3bZa09wqI3ex0pAFkbjv0YMRPnFW0nmYppbpy/NfJRV49vi9PEGJ7L5Zo87O057NBqM3loexsg48qNJJkWbi9g+6DdJyweh+asfKBD5v9AuDRwuTs1diO+ZOzr2qFhG1sDRLbSwyhuz0nlO1bjbe69J/iBfc/3AuZl67cUeCUwv7xSu76tRjXtRJhIaUEN/BFkscPvFI6QtPloUdNH6y8BWtYvP5p+T4/kYuri/5a2R27DUoRLYLUCSIhQd9Q7Ijs0urOVaNGeDgMbJaWd8SM6hMPOrCTDo0nSoFFguvdpMhKH54oQwLO3zaixJc1slKBqDjV96UFi5ftbNXr3tm9u9DIJ3H46XzNvlvQdckkxby/4S9ZbiHe+tSbBlYX2y8Md6m6EuSI5SGkL44WQvQOTDEa6LQXWO9HgENFaIMCL/s1BaXkP5ELbJZo6aTz/HQEThjzpJI4puTTtdwxNIO4yduGtEmSDDpxTm/BRSwL81mXn5rA7/VbU4ImPx3psAkWgLPEfihCCGqWNNh7xQshW8u06SHpee9AAADBCI4isf1Ax7JJ7W1P0oOtREWZJIaNRt8Xo6IJlN6k3PU6HjBWPWgDFSGUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUrk+/iub2a5vZqPL+81wFa4ddvavo9qkaZ/8AfuhGb971Pv8AvFG89KbbF+cVDl/eajyfvFc3s1zezXN7Nch8fNSbnqVJuepTIhSHkpMNJgna38M4DVy5ajdK+XtXb70I2yWdbYmptDNzyUVt3qJPKdStaxefzTk7/TW/8cGm5bGE33ox5iOyVBM8R70ZO580qNmIJ76UCCE3jvbQ4s4pFFxBjUahaJuO1NBmR3uy70spmZ8tItTWZbRvc5JobBeFicPegAFx93tV9SOKIGHRqWpBteckxNEsvgfOgsQvvnpaee+narD7JntStI8c41/4VsYkCyrTcfNKMgLNo5z+B5UpEiECQKmhYcb60Oz5lHVKF1ETipLNnZ2/hA7xbNKreu1HTB2+6KIHdm26dL0mNTnVqNt/qpKpJaam0VdEh0cMbbdujvH7Nfii1zvOOKgLLGAb3fr0qJg73pPl9Ch4MxFgFveUu+bTRUFn/wA4af6sGZ1NS3KMXzgwChjviorZE456q99fnwT1tUIYjfX4qfHvS5Yt/duoZlZeDPSamu9T4JkCmB+qgNoSBz0Au1x+OpX5qWCNtjdrk9ijcnmP1UNz1VDc9VQ3PVUNz1VDc9VQ3PVUNz1VDc9VQ3PVTMQArA4LufSlOZmDYiwHBUol1X2tHT2mPW/RYSC7nSId6HTd25wP5pcBmVDzLFidUTzo0EUwgbizbSKAQkSAjJvafimywXs2u0XQz3DRzP8A7RrAnFFM7aaxGYoRlMT0HyYdY1KQ3RwaRxQzc6drO9T2P+G/gVQSFINaZYzoBahHFCmPSibGHw4ZPKhrieDJzUNz1K85ONzwLF3oJI6HXHE/XNFOHs/HQqWY/d6S0Y8udumxI5ys6Q0KLpYDdGdRzTaS8xEZaTNaBIlwqmbC/nalyTK578K3vNHV6n+HNCJJ/VkKwvJfIR91FJQ0LmSLNWkkkqaR7huT1nlO1IbSrm/11noUq5/voJTJaQ7f7Upe7hmo29+Kk358t6QZP02oVQymn+VPMW/dantbSr2LbU7T1oc3iOOkhqH+2pEDEk5ZM0IjsNkpp5PPxY+f1/CittSH/wAq3OJztgbXaBsQnG1BBHQII9e/XUOzybUAgoOYwmaC4/PvSCLRd7P8KPNCKggb5B+vmgbtvLBmJoWQMrCO50KLElzWJ5Xob780I4qRl2nFSXlGYjRi8lG9bfD7UM839f8Ai6oGyCORw0bd0LDlHFMoiCYZvPP30GNTOHHqUDijwyMMeRWvvrYhPShGQz5VftflqVyy0I7bUvS3vR1aQbuN96K9pfvOnTB7PxRRh7/OtLoVNoZXg18qgGBG2r3sx2a1WaystY2oQhvqbUkkener6zPPhOkpipLNn5pYZYjzmaL/ANI0Hf8A2lsfoZeqoB3+NqFMPH6VJuxsvxR0GHb92qW/sUMk/wBCanparVarVarVNTU1NTU1PhgSMJc54aC2w/Tv0tVuirEnnHlUXWO6UDc9SpJiScx0m8a56tFurDvrU4ThoZl+r+LHz+v4cBQl+qFqJPloeRasHv8AVcdn8UZO589GV2AJ9aaMmcEefgiqYIwHr9V+1WUHKghOoXO5PMUHJtqPn+aIoidYta9T20zrbhNc3s0mr4+6GSeimFuFX3qG5csJD3vXJ/xtRoCS/rpTsrUdQnShHh2bNYZPKpTcgqJqfNDJPgSaLU0eLB0tmr6s89HD2fjonF5zGkutTgGWAb7UjIcwvhNPOsLjuuo6RTdBhqGCY7+14oCQ/wDfC0dTf6/5Ut2Uz2mriS5/SSCOER7OakZkMBolvaKKGLlLYnRnvR1EfuKBmU3nPej+JqfCwcT512+9dvvSzSO9T49GuIqe3vXb71zHyvUdn2oRJPDIZSkGs9r0BxNQWnHdojYd/wA0Oyxw0M57zU9iu170q5DvrXfwGy1Ft87FdnvUEWLXkm9IFTdvmH/a1+XgIS1RSSxrXN7Fc3sVzexXN7Fc3sVzexXN7FCvN5Ix6ViDyzdyD3oII11761k7/VT/AO796mXhB79N+3rfFYezUefajwG82PuyFOuuJMSMwHul+5YMvlMBBLsJZqQkeRznnPrSjDaNYv61IBE86+9DLI23vM1BBmfahm5UpjOY3K9xGD/jGrT59J9yam+6koNpgFxrKm0dOC2b/mgtjOzU/wALSuhPnFJYPWN9qOj0XgedIJ14hL2q8X+Bbp+tY86LtIXd15/VNJJFIlno0y4dGhMEPGRoUWzMsYv4HwjHbUqZMXNTbzq4kuf0rQDK8pv9vWhGL9voPjpFKw4WlJ7Ol4qbxrmjJM5+rdD+RRpPxSt47VnVe/8AQuavk/itd+/gihKEd7Wub2a5D4+ak3PU6R66O1RMjOtup1alY4+tWi4HqYz/ADC2qIF7rB90Spb5LdWVFWMVkdvQwd79EJODPLnpHkCe2h48uZjFbMOu0X2SmwGKruh47GHu1PclINHcM3OyUKMlXLX975iKGDq2nPlPQHJbD8NmobGOMT+f+Nq0+fVAQBNVJ9ahlwyt+F+KgWCIw2sRpHRKJ1uGi0IwtpEW4ilGxf0+KBJbExvUkx2vpfF6UM0ppjvNKGanOLfutT0PejpLcB5mQqwlcC2B2KMs8qtsGtRKE775WNPA0yydqSGOjUhc7NWXw6bnJUMA+nZohJLnt/A0hyUM3P5nrzio7L+6rw7fWKA8O3UUj9nmjq1T6m3lX4rk9mhHH8LHBPmV2+9SufBIZYpzEpGl67Peuz3rs967Pev0mv0mjgno1Dn2rgVyH2plp8HsUdzzoXNveub2amYB5U8GewfFM9x8n5q7zSaJTcTbI3xtUNz1oZ1nzmpGA96FMuIiD5pDjbfnEUOLPlZh2rgu3b6tCymzs7+Fy1UIzc38qIghkgv1dnn80v6d6wOx8fwJPM9uVZbUTBOcemKSNb6m1QSHeehg7HxQgGyr6UEEVkFABB4r1ehT/wBrDNLqHk1DZmmJF4AGxki/JjahZYnaHzrcwYTNC5ZNDW1XYSLN796n4j3n/jatPn4Tt2ggT92oZbxtpRKEKU3JERJq5KEuLzUdFXPRo0E+sVfWZ56diZ2imFlTj/yny8wp6qG6G7ocrV5fSg8H8IZLOmP86mS1v3DSJnz470KYztvxVkN36g6tHgaEu+TcoZB/owTgSdpk9mhlObUXB3ooMaG9BFjr7h/vjgsF/alWJ08CTE/dTTMM4hxSrmjwNTU9D+C1W6TU9BPJfurcclk24pvm/e9FuJaKW0aZpY3GmqalvWpy1w9zo8nn1OjELex3bzPVwdvtrL9MfwSMexNHyfdBAZmyfKlqJDcUEWKEBzf16RedcU0Ey2HQ/hQRQoQG4myNqJW4ayucn0ads0tehJIslr896W7NyNWM1sZmNj3rs09/+NqQhGinseKJIRScaUWw66G9gUqJCtR07VIiUe75rQsr7Mc6V2e9DN41wI+9SDfyL3tSgw2I2pGkPerNdk48opYhHN42mrmCdglaZCQXBjTP+KAAIDAfxSMjDEcUIQ1g83ijoJtVl4k22pBzQ47NrW9KiQUZw/PRo8DQqk9KUOcf0BfWxLy/xReI1xSh4befQqGJUxexKKQZHI01adBTClS7vq1Lu+tY+XnPlUu761Lu+tS7vq9UGWlaWplZbtHS3gkMpSDntDUefao8+1R59qA8d4Kk3PUqTc9SpNz1K4C9r0M6J3I8EhlOixovYmmOj52pWz3o1X0CmxXug15oZudFK+HNST6nbHRRqbNKUk0MI+CaijSxoRJOvEt+2r9P/Ffp/wCK/T/xQ4Ynsn31WN41vg1aduAWF8Fv9pLny7a9ETGrr0x8/rpN44noKNPNikuQ7jU1NTU1NTU1NTU1NRCXowfcL/utOt1lgxahpzZvFELGGRzZj9fxUt2nGk5/4mpQzSyzR42jsiCwsk4/8orsQnM3qyCMz1nooXbUgvjkc9qiE7zI40fF7F3dcz+P5tQtBjfz8CEpjUqaRCXjM5DyrJXG9mOKsBnZs9Dwsl1Ce/FYzaWPv+cQuJBPq+6CZZlzr6dDB3v0a1eX8PN7NQMRpvWat4Hgn2qRcEaZnmaZcs9seVRUVFRUVFRUVFXMKdut2H3j5qdz60JuX6ph1FRUUeDtRJm3FCOOgwzt0Jd4UGpBi8uER3oZxfMfcUokC+dB9KCdx6pwQOaRUIiZEiPJ6CyRoyd6mGwTzJSeuPn9eOAeTLbQzHnQO8svAWp6QS+jPtboYOx8dWlhwR3dKCCP5l1y8wSjc47nmNXo5q3uPC2nSpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1Kk3PUqTc9SpNz1KeOF3KlXPboeJG56lIOe1LN6zZuamkTtWVWb8e5+KlSRAWR37V/4Wrk+Klc6a7c2qQWDBqd380cX45hOWtRFoQ00/nakvr4Nmztp0iJtnPPetAM5nhoZe5+4aSgYWjZfC06rjo9qUg9f138chlKk3PUqTc9SpNz1Kk3PUpMSXqXd9aCjnDzzFKEXmlcWw3M40oRxU1Iw6z50XS3tFLKYlx8eJvS3nZ861v9dLVbooZau+CJ96t19EVdrDg/roMtJiS94qMDE6bFpmrVOcG3PQpwxo/LrSihVdzKblCtCUN0PHFCeIhTBS5miW2Z96gQozcrJmZcUtVFZhUi4Wk6zEnITve73oMXs+dCJZpDJNAWBrgPxSknHU0azCNdPxT5UuujNg7EFRxq9ICaa/U56ZHc+ekXnXFSOGaMpF/FXJkMR5VJuepUm56n81tz1/bc4/4xw8Lmy2BfiaMeFfYG3LUncomxnSCetIRGjtLrTQsmrCc44P2aIQi98reLp/SilOGBzVtGfKOorOGsSc/FMX0nOKhvBE6T90zJjDZNHhrOZdHV3laEiJnZjwNIOaxVs6uxo1HZ9qjs+1R2fao7PtUdn2pZv4/caCXt8tNavLw6+T8VMB4KuVNmiwBlD9Km+cLJpImaKeqDvtU0bX42o6Im7fza5PmuT5rk+a5PmuT2a5vZrvPa3zXeO/+VzezXN7Nch8fNO57z8VzezTpX8ors967Peo7PpTKAWj9zXZrv8ANdnvSnIOG/vFJS7N3FZ+X31AjOS87Ws1rJDEus3zTI3TRxIzShLhZEEDKpka3kEI6lJjmF8wLYMdBhvhs0kMUMM8UOQD1IqYkoQikSCekYzmScRGn30CCOt6AtMeRRjvC92nI6285bvlTkt2+19r2tRjTyxRh6vI4Ogu/VyuOz+Kxefx1i8646PTMfq9qAQY/wCkcliJtR1QZanDvxgKPAgyxSng2opMV3S7Z+tOSqXKE12NadHU94xUnCbf1EkhpQMXM9QfpqEzU1NfYqMMYw1E5LNvpQy2edXehHHV6E5SjXbj+T9riri0zReI1+6Vzx9nU6NTaOZo8WtCQxM60xoRT0F3G/pxU0owRilVP88ShQhj+Ax79kxUkECiwKE5SlalCGRNybkVEkN7QzrQaLUxr0KAt6SSGkTNEmHNXsLCAkL3psxMoooySos0b02AHdLb7oYZf21vE0gjokauvlRMi5YXzb36aTvo6Wp9rx2mr5HET5lAGKxefx0ZXYAn16NGOhy+X/SwHgExd9qliJtR4EnLWZeaWBXfzp+ZTsrnexQhCGc5m2VrTJMnJrUWZQwt7TqlBGGh63PehHFH9F6CLmPujo0q4frolxZ9qLoyfqUAJdtqjRkttehShdmHxRgue3rTfqzdhqfdDJJ/E4jv7DQ+n4aMHY+K0rF5/PQ8DU9eB2Zplu0Ugbvrn0rgKm1DsT81yexUrn+hDHdE85oQhVbMEvnVyBYxGs5pRgE6kXNaESFFxDE4mpBumFixOIUizAm+JzvamJgJaY07/FOBCm1ghEMz+KbZZcDK+sIT5U0MQUWCGrQWkFSJWjOzfWrRgVLMHeoGBb0KQmTqMQjfP4qExN6Se5h5p1ICEsoEXYPeggGYAC4zJA6WmoiZqGRAERce9ObNx89AQTNrfrUefao8+1Gp6M/VEOOmGusDDbLehItjTnnoYOAe2zUkhdXPalDL26YvP46LGtDOtM66W/yoah5iagBnH7mo7PtUdn2qOz7VHZ9qjs+1R2fao7PtUdn2qOz7VHZ9qjs+1R2fao7PtUdn2/4SxdGN+dqYp2rbXnwO2MREppQtnMzz4EGaZyOw/iixAWJedKzAXQbXq8HLpoI3/FOdJ4semngiUJaG5kpV2k2qDs6stAeNp1/pW6apti/g2fT8dAe9SUOHPn3pF2sWaUEtIOai6gZv8wUHRfc+yjAR6CGT0Nu21A8P7j+Fdsnqx9UUQHuRzv0y8JjqsE0ym9pn6o6Goy+1GOh4+QEKAKiwAc96ljhkqMiEQc04kaNDOL9BcJVLRK9igyVMZBAdqvGANCep9aggEnF1mdUYqex5lVsw3IzT1AJYMmthtUWMzGQG9omkQRQWEgtn7igMspzE3E3SdppEsVZHQbsaVHzFpdGEdL1c5EJLlCJcUQCgRKgXLof7QUKQSbRod4q2zoTKgXFcNGJLIjByliKQpzIZXDOaDZmSsTJOVRVjZP8A3HRZPPoU0pJpk53qWlthgsZ96c7cNEa5Z5Aj5fCMM0XaCI85ml0VJ4zjzobd4e1sVZNxqTg4+qgAiihfvSEnGvLnoZO589Js1P8A1Fy1n4pVz4FUjJ5f7UrnTwMOXQqQ41jHnTYlpGDGqGb/ALaraAoupucBTNowEa3vmr1er1er1fDjbT0reen+tMzLk/YqVhI2dHg/ptIOa4c9GpOHekTJSSRSDPyeiZPT8dEzIeRaWoTy2lju0LPqrAs9B616bkMnvUtnOjT47T/7n5UVo9z76TFzO1IExF4jwwd6ToT7UlmD570UgzHZY+KTSItcnPeoqKLeEixprwnSmENhmZLExlozNi+JJ82hkCTGTmmEhQciL80aAGxA9CkiEDokjW94DYEX9aadxCCYvcCgLhJAEhWy57UwAJFlnfFWkc3m8y9q/a9cvYvSMQgN5S2zFAABgCA208QFRcgIRZkgOK88Y9aCWALKCXu9JozHp3pyQ5Lnja1FkWL/AB0KaATGrLRUcCQ7EnSdKXXhY1h0os8lpdWfEKMRLm7oeeKQCFLnSwI4xWLz+ai88RQi7uefTDzqbxrnpi8/jpx2fx/z83s8RQvTUv6y1BbX47+B6aB6/joB32KQJcA1Gr/tAIABobbz/ENWZ29qRGjBE20z3oRxR/RakuZ9qOoHPr91ZeJNtqSR30eaQQ4acdJO9Xc6WoFLNJDB3pqy6i8xotJqWsp71gE2lZ8qESSp8Mw4eh+FHTB7vjofs5rF5/NLcN59qYw629adDQg+KVbvTSguPPoeJwDBKG5fE0yIZiqSakNCglWFiCHMFGJI3crvNCfzpXfHv70HW/tXAfPz1YEiG0gx2WnASOlAAgYL7zr/AEhBoyvrrV7Z4/ypRfy7Raimnk1z0E0Eggm64dptSgyIMpgLFtHNDN6PCM7N1mu5xRHECBOVLUZO581N41zTIjB9F6YPf6pQb5e+uOmLz+OihmuT5rk+a5PmuT5rk+a5PmuT5rk+a5PmuT5rk+a5PmuT5rk+a5PmuT5rk+a5PmuT5/tSIifOpE/ufFByv7LSrmihHl8G0oZpTwY71KNn60lYC4QTa1YjOgzF/d/lYTF9+OKYMb4qdATvxQyT/SaSZLfneoTPVNH0aSGPTtSXgWYPgoYTrqbOtNIe+9JFqSR0Y7r1CWeiHh3qNHR+KslYNGHWo0LuFxedYBnyT56yArAl7GaGb5Vl7t3o1IQBd6mLAY1pSVzY4iiRj5PZpTwbdLVFYy0Y6Wq1Wq1WqElBeWJi21F2XiF36ilgPea7VT496EwFdgd2fiuXsX+tMHp3pSXyWaUna3p0KGEpQJUDdoRJER1EfjoipMOT7oZJoicz7dTYXAHuXXtQZZVXZ5vP5rF5/NGTufNRedcUHLhfVOtYOxXHZ/HTF5/H/Og3lPHFaMlTaOZqSx/7weCq0oEtKuad6lwbW0C7vpRtrohX6/nWSG5tWqY14oY+0S9qJMX4nXt/SaSSKSGPTt0aSSGklHnQqhfRNzikCS4N6acYnioTPSRH7mmkkii9TIC7n81akqGGX1ii0iJ6z8fNBmBPvJ61OBz5uQ9GjAjl9c9f29On6elZvL4rHz+qz8vuj7aaXK92lI7/AEop8EuWE9GKUQxOe2sUKQCxcAmNbeCF0qO7QBigJIvgwtialCWUgUxMXh/sDsXaZpQxu+AHlFonZKyJJJSLvHQpt+NuKy9flQZaxUgSoAq8BLUywDGwB/6q4zLP7esO1vML1i8/noQOl0jcz54oAx0xefx/zdCTGovby8bpEfM70oJWP3M0rYXhWbUxjwer0VNUKSYu0UoCuhSguXkUnagEMBtry/0pbluKZmXJ+xUrCQ6Oj/SaEiUdWmysQTEe8UTcrK6B0NCT3qEyUB7xBN4pEs/pTQLbtilJYJi78Fac62xpQuHppSAWncb/ABUS3vgyFonrRC4mzpxUMQ8x+qMFJvpDUrzxGcedFNfAqWIm1FNSyNA4zmaW7vm1uIK71PhmRL4VDaLgG/egHJ+YGwKf44CQSN4oCoPYN+bFArnZvQDl3/uyS7vLWpIf21JMP69JoUwxSk8DkpgmI9mmTc5xYJatjwsMcho/LRJhbf3tSW0yl8TbMUtSQET70hSNyrzxvszQjW03FnzqEI5+KFO6y7Ul8QYjLPUYZoZJ/wCVByzJ33p5mefCwMuY9tKUtsZztw1c2nX6mlmH/wA8qUM434psLd/nodgtliQ43qabbxUVFZJnHda1IB2GSfyf1cgz800nXGJ5/pNMmZhq/pbrIQ/+NJDD+lRXYsfh0akuZPfoLiTbN1vKkjRNpq3OVcMhz0Q5KV2b/mgXGaGywgGzbI86gwqOclBiA5PupIUYdTXtReE2HEclBZD2/wAoTMjz8zQoSJ2mWnD78uhoy9/orPyp8IMIgLEQS6pjQO4A2t0OMa58sUcmryhrOV9v+BY7C+1q0oQzOCR2Qg8+hSvG4e3gCBzZHU7UK4yRqYPt4ppushOdX5rC0xPo196zO6n7eXQsHIH4qV9vhT0GGjqZO58/8lw76iPjxKC5OnalNl5isQu405ipm7f94pYvPlu6UpXaA/JSBhbZtREJx4ikr34M02p1kjTu0Frxtzcf1yHPrrSKhq9ibGM96Ecf0Wpbmfmjo1oJDpQ0dMPw1Pc2R52zTf5pNEpIY9+OgJWdhvoHRlmlF8k/s9ILAErzBU8kiItKzNRUXNViONu9FjnUtJSWw300odCOz0uGRdwBtwNCXhHeYfao1+fMRtQBl5+1QmGRiWTFCI4hNNxop8LzrCzEXdI6kTefL7pPL+81HZ9qjs+1R2fahkm/n/cOyfSzQyTp+LFQ3RBtcA5vnoVOM5mgPHeOqk4v/qgqZBIv1aB1dKuQ5CBtAfsUMCd1PWJXHyzWR3PmhRko90vVmoZBefmhDEF+MxEVk7tETfFBWYvzQmS/7rU3jXNGA01L4X/jsLsqFjPtROtn4erufWnSv5RUYnGhOrSrkCJNa1Tsrk86YeSVnXFNsxd0+6kld524ozJfbc70N3H27lObEYQ2pWL/ABnvRBZuDgDd2oil59zk/spNmkVDMfJRBiaASUf0bskdsfHVr2n/ACtty5U1mzovTQUsS/HNIgF9W1RhEJ1aSdU+PSlMaJT1ew0OxpBP4qPPtSZVzDN6jt67+9WyQzqa0lkMbme9YuDt500I22b9nohyD3B+ayku8xHEU7fUfdIExJuY96RUIjs9Y8yO/F0q/gnMd58ULigGb9/x/YUADhnaNPvwiZbPzap4ar8RWvQ8Pm0cYGd70QMagYiLZj6oZ1I7heR2pTLFz4zQo8tr7zUZhiPqoT3O8VGGJidd46ObOC5w0lOOx0we/wBdIxz+Y6Y+f1/yVApVS02J0+aW2023rj29sVBIZc9FjJ2/8UpZXjy2mpPJbnVSEkRM6/VIG1td6bYAWH63o4Mc6vnWnz/tJNmlHbf/ACpAMGw8bUMk0f0RKOrTl7vzSowiTjTagCSpMDL8UJBnWkHNKMXPfq3t+81AkN4c/iQ1K1s+CTZtuJKsOuzRdJb92pWx1aOngnqFJGLw9qVy3KE+tfp/JVrGALkyXy9A9ZN4bNUNASZ1dYXFBAH9kLQgEe8Qt4UkTcT1rV5dMXn89dauH7i1IBX03nS9C3gruaY2pFsfuKASMLAzEo/NM1WYseZEaV209qyG0HvWvEHfmjJ3PmnJ3+mrbrbHnkqyW365PbwDDNDJP/Hg5X9lpVzSgUlz/wCcdNBn66JZZ1hs5K1H94KkcaFQY1PMeaMywNd3jmpMrgZhExPOtACyG5+a/Qn5pVCYy4h2/topfFQXMVLZnSPI70HW1TR/M1dIzE+/Vr1iWP8AK1qTJOWTfas7CyjgKerNn1pEzTZM2G+ds0kwyOb6B6VJwJ3ri9ylYTNQmja1IeO0FZzL9+tWaaZkunNqIMob6N970duFoZnyrAPRieha9vP8FGkT50c/wCCCKnx6NT49Gp8ejU+PRqfHo1Pj0anx6NT49Gp8ejU+PRqfHo1Pj0anx6NT49Gp8ejU+PRqfHo1Pj0anx6NT49Gp8ejU+PRqfHo1Pj0anx6NT49Gp8ejU+PRqfHo1Pj0a7VHzfcmisfPodFIcWqexhR32aIN2B+akcGfxVwDtbYpABN122IKlJyzS3byqGmc8QViefz0nBM57J6RIS7cTjfrj5/X/Lg3lOmp7b+VKqXoHdcU226KF3/AN4rd8gpTm/sRaxUNi/NKFRsTHmNtXSkQWKpHlq+TwUAwDAAARBh6dT+7Bcx0sOZPPSKGSfXh2o/laTJnh06tZ+VCl6uQtWOXdonl7ii/RqKSSK/zAvwUEEeBJs1Hl/eKCdE3QtxU+PeoRWozGM0La5OQs7UiZG+iMlSoznClFkiNI6SX0xzQBjqf8Zso4jz0qUXIZoUFOPnwLAbqLaTrNRBHry70bOLPnaKiLiVG2JiidYnir8R7z+KcRXYHVbCiLrq2gmj8qCzufPTF5/Nft50Ijj7zQgn17aX6Y+f1/ykHLoa9IOWZO+9PMzzTGuOa0DzaNY3v3pGX3fio7t+NipmZhIHidWKksI2YvRAsrAAmcSlaSTpCL+4B5t2sPi0QcPAcP70FzHQUiDW/PHQ/laUva3XM5I9GaXIDK42qIANPE05nAj3H2ikuLeVEVm9iPO9SgY1xSXc40neK5EOjfDxXnfvNImeoCGruGT2E1Y5lswT2pIdo0blIyeb6r9BX6ChnRO5H/IULx8M1j50UYOx8dICV9aEJ4t+aax/utMRwEdBw4Zfah0t6GomIGWCNMo3pZcG1lvJvS1REBJ/lEr4YW5fMVCLefeL0yNicJxeozNvpPbBQEFuJntcolaTsMlWM/t6gT4EuNiI85oRx/wtnMljmr65143pQc6U8zPNbjEQN9aG8YaG9W0xp20qLGd7YwFLF9ljbmlLmN34q8JghkMu1WQroAVzYgy9qRAiMoJBbk/FGD9jjwnD+/Bc8zboKRBrfnjofxvRiSMReNp6pMalI45q3c37vR6HUtNC/irpWUXaWl6TJ72mShMzdxe8UARi4R+agchUGx6FQbR2t8VsPf8ANS4XxNEBMmzHtQE4TbPx0Q59asz5+TYKKS9lCUdYfxQAhIb6Hat9Pz/yfbtfNrTrOjQ+dakFv8EU1ExGW/Yd6gyN8HljoBA6wHlHQTOdMbazTyjXQaGvcoA1xCNns1bTGnbShhmhkmra+XeeheNAr5UJc1KUPzQyT/wUjZ0dq5vYrm9iub2KQDY4gt90CLxrFredWl27rYttTa7U4xefKpN7Z/KlAvTAZh24dylZmIb9r0qbPe2dlPqzwGXvTIjEDdIsfn/KMM4LNhskdXV8ixQWRp+Z8Rw/4EFzzNugpEGt+eOh/E0osZy206rBNQ7j2Nqj/bYvHR6J5OjFDPS2Os3ANs0Eb/e89LFeQf2Gg0OIzvU+/b/alxO0kxvSJp0ICXhpXc8ipdHvF6Lc2LYpjzTLErcgRpeDgBnZrVxSdphE4oRktufZQzeZ/wCP6SXrihkGpkBwPy3q2jO/DtUaDL7G/TL2fFXOddrGhIN6sYDstUZul5IfupMKHd6NhMYN584p8tP8rBy0AllPxThIY2xWUxaJnmd6MBoQYzd7vSCYm29GRgEYmdeak0T4+aQ6noUjZd2Ee9Dqf3oN5TwKBSql6KErSlviekFrylfOhvSe7UxF4u1onraka305OpahbkwAll8Rv682snrWJefHIzwUfevfWfGcP+DBc8zbphk/9v8Axtavd+esjLcNjnX+ATX125qxMTYbDHQTwio818dWonSfKascsfKna+tJFuiG+u9bX/tIZUsxelGLs4irMIbM4qUc10b3jUrCOdXSf+NemwFGJ/dU6SIGqbzxSsjla0/WtYOx8UGeNfS1CD19K36RIdviggjoEkFnv6KhNAiQzrOwUlld8zZoWxpMLvNBFisXn8+AYZoSZWIjmZmhHFTQyT/cg3lPAoFKqXooStKW+J6QWvKV86G9J7tTEXi7WietqQcv7mr5oLRAtLQjdrTEIxt8bI11y1h57RnY/gOH/C0mNe/SUxrnk2qCzY04vjxvRQJcfPFEwLlv+x0JI9aLAFg+f4HIG5B22fHnSgTaXjoEts4+6EzpFvOtN+/+UvRn2qER7670vS/GtRjZ3zStrcpXakHNes5R70kMF/3HRByV3FI49Pupxzt/tQGwkX1tWGQGftQYDrLJQJs7f8Ow7M1J81T1oIDkH2itKJQbfLVmtKy7ij3qEW8+8Vq8qv0IgcWMtqGdZcZny6IJZvveob+zT5uzF1vL3oLWUwxZNIqZ1oQ736AEQ8/mo8+1CJ0GGe8+eaJJhXLepNE+PmiF5PX2oBmX0qPPtUefah1P66C+uClm712FKt3O23FTpPMUomWOea1NrTv0Rdafqo291vnBOlSqsMu2T0pDIdymtSi+cct6DOWFWlXLQNXTzKOFjVoK5QabK82NMdnH8Jw/4cFzHRrRfX80Bnj438SFIk95HTrsauOaEEfwzWUidm7SUIyag3jmnJMyabxs1e3e3eiYJz1johu+58dE3bzftWQPqU7X1pTozrEzvelnPr+a79Ae+9ImfXSpWR9aRGGuSHRHHajM5nHqpFpsuHJbSgEjNImf+A4gZUfrSQHa3asnf6pwj3cE5oII6AJwPkioYOcUEAVh5/VYfnSTSsXn8V8iu3gCYDN5+qixkfZD9U+trCTe29KE+vemF2EJ9egwzQyT1GGaGSakxrnyq9X6KE8/1Q5O1amuvHEdVB8d6FlOZ9duiwTSNnGzUFlx50JMZ30rVyrA5zMU3GcZfzRwBaz1jamzF37NADtRQJunQP8ADmI8mSkB0HQHB60a3m75bn8Rw/4kTbGnWYZNovTfMWb5HeoyG9QWM/FOw7XpAaGe/nR1iJ1SfL+EXHkFpy32oBJdff8Ac1BERamzDKLTrvQIE1D46njikHNKOT90pB0pYT1drHFJolJ0t70Eb0g5KLlLOFmBtSIGvjVuoGXDc7T/AH14hb8qCXbZ5pDL7avNCssx63oprDzoYZb286js+1FEO89PkUoCy5x3oR3zGPAgskbt/iuJ9qEhSbk25fNAbYdmsfP6q+1t+dukxazrHtUIta/3nrMWs6x7VAZDS5gzUn/jXJ81yfNAGZ8zS6W3xmub2K5vYrm9iub2K5vYrm9iub2K5vYrm9iub2K5vYrm9iub2K5vYrm9iub2K5vYrm9iogtzjy2pVkbbRjiub2K5vYqPsTx0UD4KBdXW1rxpUjFo3+qWHQ9b+dMWV4+4pGcGL+zNMM3bT53y1/kc81YuZ4170BmuO8XVMB6+taYgsIWy6TgqREWtOC7vXN7Fc3sVzexXN7Fc3sVzexXN7FTUfaxVDUNH/FkR5nZ/iEuDP4/iJNR7l79BTidJjzikQcFsWajqEvGtP+X+0EL06z0/2u9u/hZcP7kpR23pDMXqWl+OrttxSOEzpmk6W96CN6Q5KSlDiJAjk1pSIN5TY21qPgXxp/cmYucrsUEAEx91u21+aS0WP2WggitKLob0dAlDf9ihn39mOgutDJPjOZjiohLqxpCZKViOI3tpQ2vZ/dPA5L7+Ewdj4/qzaOZpTZ29/CoFLLL0msx+4psXpTfTE0oLWXPpiaWCa3rcFASUIPmjQ/S9CAgEpd8tNj1vP/SVINmoSz/Aiu5zM4daAAGD+GRi6dibrUB979ItPMe1ALEc/wC1Gj507GzFYyZLfmgxfNQX18KHvvSjFzfwu23FImaR9kM0sxf926u19aDk72mh0t702U2pJzeiSVJqLmkkJkaQuxrUuEcn4rAI/Pp/Y5F1dqgPnvUSFqT5VA0In6UNXLjt1GXy6NYvehnyt6VdBZkwNztWLz+fBdBZkwNzt4RTA25ojPKCq3bn7mej1aMdRhmhknwmDsfHRtJdIu6zQjj+hKavlUrBMRPGefCoS7x57Us/jbikcETzikXISbyZt2pQyxSdmhQTGGJs6ulqdZc1f5U/S9msUXiCFsNYuh+5bwqgC4Sm3Boet5/6iohHEjhGldVkzqeXiWO+DvpUQLkX44/ik0jB93pcXytvuaDQPQx4JoLt35PFHVJdGsrbzjwuMTxMV2sbTPRCx82vzQBgZOiDmlEwTrM44ikHWbZJkrXdv+3rDDSDmsFZNi9QcRYkbS7E2pZBh6ju00bOoz7UtaDs2felnQO39ICUBy0+jGCte0UEYpq07uK0Oqiu7PTSgmH6tQQR0vpraggjpLPKRzFERBpbz8AwyxEROiraM+GxWhc1lzDmgZECyOkUIox3xS0UMk9Ob2Kal8L1mVzZS+bUBYfjvXN7Fdz6KnsUS2O4r9P/ABX6f+K/T/xX6f8Aiv0/8V+n/iv0/wDHj3HED3oJBYxFvN8Kwy4j1Rilln9jpExqh5A0sGreHm04pZ+u2hUWM6cXpYHJWXl3Kjy4DPlFANXwbaz0Rv8A5UAwis3CYbB/rRjuZx5f9RVaoE2JjniaGe+vfWu9Wq3SaXB+n+KbFrQ6hq/VBBHzpxQRfWftNQGNCPKipvrLiN6YnJmgQ84dYos1GbRLBtUuw9/4Xbbj/aRMnRqKQclL0v7dJMkbZrYeS3l1B4f3NK7KQy9a7vboy771bntJfayfdYvsYO1IUsejFBZD5qHQo/K9T0U6yfdbIdgjQHCPZGpqampqampqamp6ZPyF5ps4D9Iq5lr5x5HQpIzAIXilL4Kgu5+OsV3L8UdBLOh89MXn81r2IPPJWLz+f4nYYdPKp5IYJBYSMO2tJZiE71wQmlCCNISY1rEmxEec0I4pSHFvT+Awdj48fN7Fc3sVzexXN7Fc3sVI4KxnilMDBm03dusXnXFLNn0ih3RLHoqZM3i0fJSTBPtUFwwjsb2pZi0j5S4mkyvh+KRfJwG22aY3Zy6+VS2JJE9cUpxQQLicpt68ve24OMuu7s0cuWjBmdZt7f8AXVRahyZ86tOdM35q/By9uK17OHbmiUaDKfNFiNP4VAlsGXipR0LDYKQJdDvv2oCWNLHYJ6SmMWnynwRSYSyYa0CEzzydGinwoOaVpjbrbog5p2vrWNE70g5rThGb57UkWdp6Sav16VMzftXcGLZKW7bd+WkTJTK9zST4qzxPVG9ZtfbX0qByFcH18UnS3vXlOynxQCTt3ecVC1a3D6oPPYWrgxyw+oNfsf8AKDqXv9UnRvapOTzX6Knx3H6MVLoPJ9UvJeee9BRbSJzbz8G4gS5q0hcRkoCB0ffPQrO+Nu+/W+mtu/FBAHTF+60JJCrBbWe5/GMPl5NmryYsbL+zTLGZud8dLJft6GSagmdYjyzQwyaNqGSesg94Od/Bj5/X9BwRvPWDeUpBn01qU3zby4pQzSlm8afdIOFmXYoo+WJ7qaTMAEsti36b4qHRr2w3Wm7/ANRVbwLBNLKu5B8fFJBMOO50i4YXFAkebeOp43DNuR2edYg/bVEjmehuaPz1ijq0Hdt4Xwoc+tKO29j58SdLUiZ6C8dqc0SbnRJs0nS1IMhPk1asRTF9Pg0p1YYs8dqhgw8zzKASY+GJjxIuDzVDt6Wv0/8AVQmI9P8AfEU15j7FJeuYC9t2pLuL+b1kI6EL+KJQMRnrBDuf7147P4oXB8Fdz6K5PYpqXwv8WBBM7TYacicOQtNDCCObZio6nojSyznvWPn9UwCLo/8AKnSeYpLNHJQjjxc3sV3PorufRXc+iu59Fdz6PEe+sb9YrRk6vJf6pRK7vm0qpenkPnmmyNde29aJ5t/SmUBwCKysTH781CyXkkhqt3V5YK/8v6f89U+OQylSbnqVoGus4opBEcNLNJbjGTTFCb8uODarkJz+KkzYm/1/AkKwCttDQ74pGZdZ7BceVXMuJ9XpqPl0jx4ZPKlJPht4mXD+5KRMmfCmRKdr6/mkTPRDkpej613z071Kva22aQ6R2tS9LnpV1s0ha/kiaFkjPbrFRUVFRUV36tDVPlAUObxGxNSYgMcVfV50/wDKO0en10aCWKAsavu9NZRTWhknqIJ1Vj1eAwdj4/j25cfyFKWIhGJWmLN+hCzrr+akfNfIpYQ316OTtb+e88eBxjL6h1QJY/PrTZLa2PqKVUtReNbe+K1BbajEF2AKeL5vq8qMG6k3A0/H+00ZwSoy25+j+mqtU1NTU1NTU1NTU1NTU1NTU1NTU1NTU1NTU1NTU+NYJpSrR4TxtlPGE86OtsCbEz1PBCBmB5tDyrivk+qckWnF+Y/jIM75oZJ8T4nWen++B6JNmlHJv/nS1IdKQG06zOO5Vtx7Y6PmfL7pQ6k6P1VnN6VGC+lgvzUNJI8X+K0fWHzQUsicesNAuBe16h2fRqHZ9Godn0aRM01NACkeczUC9niMaXoGW/e/lbq5Qwc772oAx0aSUbiiEHRqK7n48Zg7Hx/Imd2A7jNS4YvJTWdlEpWY3XXQotDxPvFCd23nQhA6zRjvC93q5L7/ANGDvFnvbpIiJtv+KNchmDMc0i7bYDfakubcU5T39oqTi7zjvUgqNjeldb6mxoXpYmxYMSi4fbxWQJCCwORcYeepRg7Hx/TVP/D0T1o8L74oIAowya/NHVQxGY6nQkRK2d6E3VlVXu5oVDG8d+ihObdDqXQpk9Y8ykck8ecWo8Exc8+1KQTxvidZ6V3I9fvq9EHNL0Z9qvrPn0Qc0kx7/mm2o9unB9fFJ0t70ioayWzGS0zo3qHkFcT61C2Iuj7GpuIR2mJ1z4BOPO4fNGhbz/FA6w7XoHKr7Ht1I1EzoDQg2lWOrRcjrf6o6NOWBtnTwLF5olbD5wPlb+eFnUNIddilMKMI93E70uLvrhpE0Lu8311mKuXW6OTtaoaL5E/VE5TsyRHarg+m21DJPgdz61m8v59ah3fb8VDu+34qHd9vx1do3+PBI40t560sE1OaSMaaxr0gsZddtOnpau/nWJoYo5WxZnE7x9UwRMMgZgNmu7bA0+mjS2tv6lV/4Lh7PxR4zr5dUhTq1EnlOhQxPztWH1jkll6C/DHfodfLq++Kve30j3oB33rSefx0Y3O8figl7tOo0Mb9VKdNaESTHjt4+L6/nwW6IOaQsX1nWjpoXONPSkTJHVNGo7jsx8VbYxu52iaboQ84ihEtXzTBEHD4SgCQJizOb+OMuXQ38igieVXz6FQuL0KA5fZFBBHVzRXdZjt4YJm8xHvP9AHXdbt6JSMkThbXJQKyty3t0kJdYTvqUK/koZve/wD54DB2Pj+GK0ZPCwXpLm3FaR5xpHbosC5pZZpXY1soXipraD+xRhmAyxEc0KkEZuO8vd0OWgpAIGAMCP6tV/4ChloX4bnZo8QSnv28Ak7X9CjqWZ6sDNlxgnnQg51rigs7FXMevbodDr5eIBMasvTIMdGkXGv5ouCXH5/gfEg8O5n1pWcm/iZZWhxEkd2oTjotpUNJOzSmi2mVueVETdk4/wBqOidLe9NufXFSZUu5CdqigEXwueZQCREdfBYS2KcRsGxOekUVEsFQ3W/DFvBKYX94oFq95YoIQsu/XF5/NLF5onl9azy+tZ5fWs8vrWeX1rPL61nl9azy+tZ5fWs8vrWeX1rPL61nl9azy+tZ5fWszt7y+KQDAb6XJihPLXvs1JgPWlwHYb+lEgS/PtRgSzA7cYrB7/VO59azeX8+taxMudF9umPn9eJQfHerubPEQ6zeod32/FQ7vt+KUMv75VzezUjOCIW/pTYGO3fFSasTdGDtSmZtdJFtvWkLKxiztvepLCCPQijtiBy25YqORCpdmditTyCiRaNmkun4mlMaASO+7qtS7vb81Lu9vzUu72/NS7vb81Lu9vzUu72/NS7vb81Lu9vzUu72/NS7vb81Lu9vzUu72/NS7vb81Lu9vzUu72/NS7vb81Lu9vzUu72/NQWXdFt15PTXk9NPZ6KDs+V/eu5XcruV3K7ldyu5XcruV3K7ldyu5XcruV3K7ldyu5XcruV3K7ldyoTYfO1dvvXb712+9KYg963M+TBUzv5s/wABDSfOu33rt967feu33pnMa3vjd8Hb70QqwDDOXQ86QgS8JxpRgOb+tOO63q9MHn89CmiTERbW3ofw72jjo0lmjkowSpqampqampqanxMuH9yUovpv40HNO2/ekjoJ4d9ane/+96hMngTpb4oGYlaSt3ioC3Vcx5lIzD5471rvBSFBLDyXCngCUaa0GA8J2KACDwYvP5/pRKO02q2c3aFuGaM5ZPnTpi3n6lPTzosyUpJ5J5Yz0WCepg7Hx4ZXXDHZ28CKmxfzKsagt25pQRmxDqTbpbczj5U6nQ+NaszvYc7zWS2G+f21KFtccEVexgWwcq2PmDWjycgLs82+2NP+jqP6g3dhbtHg8913dWsHn8dBL2v0EHe/qdWgw8D+Fjcxt+OrUFnHx/RTpb92pEyZ8aDml6M+3gTRp2+q1bce3gkpUj9zS4SuRkTR0lwvDuVHRqcsb3mY6HXBJf17eJWefzU1NTU1NTU1NTU1NTU1NTU1NTUGZZPffva1BbuzaNqGYcOxpRCEJGFnV1oZdmJ/8qfHvRAI1vIY4Wub2KAid7vC15WiZ84qQyhQ9VvJ965Hys+1S7vq1LMzf9aV26T7xHVQJnyrm9ikIZW3lSYjNruLxF+igPFKc2ImYtRhYtgsw8d6XCXbBsZc0gW1t90v80nZgBmW0fvLiamq6CXk79hxvnWmTO2ITFc3sVzexXN7Fc3sVzexXN7Fc3sVzexXN7Fc3sVzexXN7Fc3sVzexXN7Fc3sVzexXN7Fc3sU1bRxUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFH9UaMk5nHlQyT0vFavwmFOdqiFmb7V8X3RX0VCb+XfodHrv36x4WNzG346tQWcfH88DkK4KdrUz1ed6UFrEXhnzvR44HIVBsehTtfWpkmS1o1qLf1Yrg96ZMHlY6WoHErMDVf81oJJdurmoBANTBQIIE42ag5eqze3QCP3F/BEoU3BOdaAMHhcHb7f6gyms+QuUsr9Teks0clCOOiWaOSrMJTkcW/hYL0s3abE6fNKrL0g3lOjgiBu9ypbZNOK0DmfiucUgECqx++VbG8g3tzBstdsaV+GsxxP/dqv8RZTzOzWJM03XHmrISehoVPMiGA4izR8zNFCL6sz55KEva/p0Ol3Jh28qKOjR48gx4ILOPj+mnS3vSIw0C6L5UiZ8SDmlBkgv1A5KAFLIrkOKeVmLLzbMtTGHm3N6JcS+VDc28qmQjec4qMBE7o96gpMuSBLUo6PQm7kxxz4nB2+3+oa6mM8XqQkbF+NFEOP1pSHFvTrKSC5Z2zFDIdq+R115c8F9PDm9lNpmP2YqS3NudOigUqstIiHLE8elFrgy7u00uxSIoUUAu86x+/VILo4UzFoNjB66f96q0fxGS2S/lVwMFywpHpRSnst7U8nnRRg7HxQsRLvNE6x5dGpTjiJN8zR+z8W6TR1fCgwx3P98MFnHx/UVlROlypS1zyj4pVz1jwIOSo7vtXF9d+alGu3bu0UDQPP/aiNI8ooqFwt5ULX5/9qGvz/lSDOP1LVpbdnMblN5ls2l2KasZ01qDHw1zezUefbww1DUNQ1DUNQ1DUNQ1DUNQ1DUNQ1DUNQ1DSF0GRLa0duTJqRw1re978+dXGuXLPHSZ1mJ9NSaAEy51vekcJmPaoRa1/vPiiPJXtWcXrAdm06OOjb90pErpTEbM4PnWrUOdXiM3qQWbMxbFASrn8q1eGJlAGn7aW1SiAACwLACwB/wB2q/yXSuIeg2551CtlDS5Nq0ow7HxRg7HxWnah5m/ab1g8/ijo0TOs/XgP4EEhpE0iLPfejq1BZx8f1XWelXNz28EeDMAGcRgxQQef5UJJohs/eaAEZOd6BWM7elvCkoiX91oQiNhT5CUiwXPZfF+sl3Hz/aDzR69jvQylkRCW89FIcW9OuAZnR3r6pzLZj28IoAN5GT1pwnZ97UL6pTZoX0Rp2vmprxiPSc0g7JJS39Bdzc0wJLww6RSkYDYO1LJN5AwG520NW1YOiTlGU3cv/cqtT0P4hwpmAxd7U5S1ZedatC8Wh3t0MOx8Veej6rH5/HQw7nzR01jeD3oII6H8aSRSsjWKPBBZx8f1nWelXNz28EUDrlkG7FSrNqP1FQFY8tu1TQLgoaaHTUig639qACAgoAx0hMxekHNB1vfnFM8RyNDrmTJzrb7oVgK3yetJFwnH9uwVv1ahjSDPOOk8t4ptJsRHnO1COK0X1qR818jwROhqVwnbXypaPnLuZU7lo/c0qOcTGTilBvxFsc0Us6NTLlmKTnfQ+6lGbGB30KcUkKFuwj93ovAxaKCyOhpvnWjGZ5/7lVpYJoLDuT/EoGUAXdgutJLCBjg386As2TzaNJJgNbXlLTyVEAB660VIp0emvyo6DCOnU8b4XdHnFImY8vDDZxo/X9KQylSbnqVJuepUm56lSbnqUl17+p7dQKrEJdvydKRlkE8ibdLTfFCU5MZhDOOvl4PjwO1nh+a4Q+qDYq4suxfn80K0waIxgmtFPnXb712+9dvvUNmo7PtUefQqPPtQHWO9Q39mpN9dmPWpNz1Kk2etHF+38kXKIEM7U3+5qcg4obotwmYoZO589LHvA88dBsGsGgMOs0Y7wvd62WpBZ33KmyYbTAzxReMby7a0j+aHISMTQOYqKfVxpShl8szSy+wfBU0vieGGlglvqyN249o3/wC5VeuXCvy7fxfve+tT77IGR2Q7UCsUAIKGPrvpU+zgP00MDv0GEaKwefx11q4fuLdDxPiQSGkTSIs996PA1DbDR+vDIZSuT7+K5vZqPL+81HZ9q7fep6BXapXDsn5qW/sVK6vxUu761rv3/gnSYjOFucUAIGfeoXH1STZpx1PAt6PBHVzY+K1C0srDRhqE090hhfOoQAzorgLbyq9Xq9Xq9Xq9Xq9Xq9SMfMlTufVrk+/mksj2qbht5Nc3sV+0FfpBXN7Fc3sVzexXN7FZBqZZ2I3p1kvKPcq4CAWxrepb/fzWHe73akMx65o0EmdIxFEwRx+anc+tYDcWHzxXAYimDeiZksXNSgpzvnbihulsphPetMLvBr51Dl2MhzuVApRMqxABpS3MEbA3B1Gr5GJowdj4/wC9VSRBdsUEHOvfX+KPNY9S0+d4oLxu+61eXpqK6X+CrRsYfOrpaZ8s0UXg3mfiio33+vBj5/wviSSKPA03zS7gxYuaVK6vxWu/f+lPS1QLOLtRs760AECMbdNfLwLaNM0iZrL2fHg+D76ngO0X49bU7nZ9yKkJklhFLc/4qCLLlYHT/CU4bt2k0uEnmUGQcIJGmP6qpl+Ty0CFgZG0udqNJ50oQE2W7nWj7nueVDNypvGuehEGlieCLV+a/BjX81ewde2tCSMSZ85mhHB6czFdxJs2ikTMQuIs+VFZUkTZO1qJaBjSgEuy7G8aTQHBQC4BvOu7rn/tVXrIZSpNz1Km3b247fxSnGgXu/jembVUs+1Q13PNr9UURCfLv0EhuVMM6sUVkd/h0zTijrOXb78dqtU+BS2RtNLLd2i38CTQsaMOn9SKIoiTa4Iyu1SJKyzfL3poEk1h8p8EmE8zNMTZn2oQPekFlxqTBQQZnamL+Taa7272+aL4v71bpCHb7o8CGi9gx7dAPDfnaKWjZka+dJznaw2Y3L+iUvgmUmOXB6R2qHkN2+BPMPaiLxiYdL8/0wImQx7LUleNOTRqbzX/AHz6uS+9eZ2vNTppM0aYnt+Knh3yenekhfT0qBzMmP8AKGzbLvxVt9IxsFHQa4+qSABBhZNrHtz2qTBxiwjCbfK+tSWcaybYsUhArd8cXqV1n/rnXwKXtb3oSnv2/iQJAJWm0YeKN2eggly47dBBm5Pv0KJkJv6G9FGTufPQX7R7lHRoBE985iub2aA2H+JAxeo80xNp5nM0eC3VdNeIn3qVszGkl6ks+T/BapqampqfECpYmDeTB3pkXlsRgvYvtQBLB3w3poFND6IxQQQdOV3EUE8OYz2oIM6svxemMsR5TPNWwJ5J7RQZm5OB9qsWUO9EQRHk/NfC+ad0cTFQi0xPP3Ri5HH/AJW9njNHgSdru037lenkQehSDmI5L+tJK1rZz5VhWiMnwjQPLJE+ajoQCEC44yP21CwhNh5NfnWhhCWSAmJEt6V3PorufRXc+iu59Fdz6K5PYrm9iub2KJ5k1wH4pSTjx4Y1jncpDSEtZiKO59ni1ZWiCFm19qGGamQ8nzTaTiIndmpExvGIip8e9IPXTQ2+6iciL3zo00JgWeHWnbGHO2tEyJC3edB/cTT3nSmBnlBouNxfWjEREX9ptSSfdOYgwxGu8lRKjIap/fSisRezjfJ91M3b/vH/AEjr4lg33OOgg739v4pbKXbGnaitR0wdCUHMvl4LL9ITzP8AlFSHtbvpUyTuUIgg+KJKW3szajo9DJ3PnxSGUqSJm25f4qOz7V2+9T0CjxPVY0nc45r/AG17evQYhgwD5Yf6KwKsQTO3NMMTCT5GKywdO0om/TEMTYHfbwNYPf6pvBNJuazUBi1b6nbjHS0c+0VGVh2k9prek41Ploti3a3Sa+D7o6tehs58qdgj7dO/ecHeaUa32jTeSnMxCY3g4aQLg4uD6NWSCFxtHN6XkgsjfeWZPZpgIdEJl+8i9q51MCCd7laJ+vlU8nMj5Jr9P/FPZ5J/lSaT8/FZ/wBt81Juep4ZTC/vFcnrf5rk9iub2Ku1hJR+oqRAyqmzSjzgtq0b/vnSC0MWi8tqWyL5qUjt+tDJPQOlw5jX1ohF2XRdOKiyJEXVw6RV4QN2mhrenICKZJczB3YL6HKViAIQBAAWAOMUiZK5onWPKkhFMpkPaXkoYLJFn6rVZsrzMR5P/WOoCc3jzpkzjzoSzofP8UUpdYNT5UEEUAjzntHS2s+VZPVn76FNTu6Q5xQRPKtbVg7FYPP4o+bR15Cde9QcYPlrAsvYpjo+dqU5Bw394pKXZu4rPy++n7eVH8D1QMO00ppLpJ1EI2vWNujtbL0kMpXJ9/Fc3s1Hl/eajs+1dvvU9ArtUrh2T81Lf2Klv7FS7vrUu76tZuv5qbLJbtwfVFJZx5ZqUwv7xUqIzH7nwymF/eKE0K/XnWcRHdNYxbtamNW+0papG4fP3SEyxiL4713iPR7VaxGuMYobJFfWu1/fOlvkHejrrTCX9abFpG2PaoN9nlvTh052pJyBu5zzSLQp7GdimSzcme/n0RgsevvWREmZLCZmKbpETChDwv5KXJkiwSHCS/NWxDSEZ0xeYdqYhQjcUI+ln+CGi+V/qvV5x8xU+Xdj4oZ28mSlDKHLRfF+16FG2g2/xTLTSOv+6UYDQjCeyU0S7x7dILOOghQxnQWnNR5n9zT4kjG82onsuQMA3+x4mkluEkQuWWkumhBTYJPK/wA1yexSXNuKvr5dqNbzf046BcMG3+1LkOFyPakCUbstNopXDywev/MOzU+G/Qn3XEUU++KCAP4QkLFjpy/VXyqrdXKuek227GZaKE8HU6ZvYVg/cW6EQGsEX426GTufPi5Cde9MOoqKii38L15NYqOz7Vlj1/xruR6/fgCIh4Y12qWz6/zQrk8jRtQQRRVpy/d6Ii2OK0Im7TaKhFpyzOZ6ngSajjoQW8y2ntSRqPaoot4+425+q7I9fungnYn7q0MaG3lxRunyimMFyzjWk7mznihDMd3Sp5tx8lMjkO0muWKRqn/3m9O1pTDSrMnRQgqRHt4lecjagISkQ2nuuz+2qFBVqfYj2qKIMGahOQc38Lt5/VTU1PScjdNzcm1qLyMRd2kiKINi20/dJMkjE+W9Om73WlJOOhRSVkxtM3qNt/qnKuIgsN4/ZoktiAuTYh3beUdPOgrI6UEzfnwWnmpEzFtvxSHJ+6UOWIiKMG4Nx2NqVizN5mGgzc/pPZqampqampqampqampqampqampqampqfF6wn0fAdfL+FxE6G5frekJlPoadBLHm9qKJxu1By7+HF2fDR18ooqZy2vjDPScWmGaJMRHSf4bVbpPiSXiTvStLb4b4qVz1aUcLzXFHcxQtmk1rWE4X3rm9mkaX9q7PeuQ+VcB+K/SaJ6vK9R2fSuJ6oV2+9dvvUbF2Gb80JlZS65lvHQprA7Hx02vr9xQMsvb26z1anwv8AApz8/FAnMTbXWlHAsxmm1iR5ns0raGkx70zucUUNfWCvJn9d+nmWzt0YRXvH4rkRGoyU+flP1TmGGdRXIzSILnGeQVzya1MiW/dxJ6UDId0tevhaihTFvSnd9ipXNDgwXmOc03ZP+Sv286EdtvxQzc9ax8/rpnXRi2ruVmZGMu2penjCQV0mn2L8FP4x28EiZjypel/QoJm/PSWz6dWUg0/2lGYHab0HyLwnnRNAqt9UeVAsYdLW2q7/ABn/AJf1FtJ635ruz6/fUGY9e38Lh4F3nYOanawbI0OhQ4d37NBn1fOoXFCM3frbrPQsHd/ylIcW9KK/NZez46DKc2oS4tr/ADLGi9iaVoR5B+adw8oak1+KGNpfKfCwKJwb+RTu/XxV3LLv/wC0dGm9nW1CuWRpPpajxT0tSBID1XYpViu2DA0FKGIO7+fA9W7ggwUdOdr1NTQ11rkPj5/le0+n3TDI+1QjU0xU7kXlicmjTBZcl0x51HVZ3f8AKuZPtXNPe/zUmicwHtStw2/JSzaxe8a81dNLrBtPNERYS+Has3s6n9MelO0v60dqbEWeTNOcneZ7U8PM+1IORx30yFKa4cuE1iyelLQtVBD3jPk1Bm7AA7fY0FEQN5VodBJmo7NQ0scxNSTZOW3u0XxftfwSwZL8EpbTe8ZTJZpQHdR9KFkdI8qLmnliu1nZ3imJ2az9TUe1cLIQdz99KujQl3F38OOgBjwJJFKOxr0LYA7eCS22hx6Uo57Ug59dacY8ybvapWimt9970cyhyxcjd3UoSRmPP/jfVBzpT8HiPfWN/wCC0KsBSSGxbLv0KbQ8xGvNAIat+c9EHclPTfwHS4e7QswYXHfToUAmct+9DJPQUw1dtLdJ8chlK5Pv4qGkvYrieqFT0Cp8FS384v4lCPtL9qA7+ifNYef10Kt4Is9rTPwU50ve3NKO3ikMpUm56lDSAbzV4WD5nLFc1uzXaaGkjyGg6z5H+12oNiakujKztPapWfLF87zSdKoTHqq5s+T1lUiMTiE86H0z8lf+A/NcHoV+r/NTaPdX4K/TfxX6b+KUwfmft1dOv3/6r93+q5KXJSBMPD/4q0ELllA3xJpSGJc/+yK7B/7VBlI1GxtDpum80CzrMP1Q5lhiPgKRuBW0jOiXNTMY5XnaYUEssTYh1FRqYui0C+jFR2g/XapV1GMIKcA0hJ+KlvHsA+aGNk4g+ylhhutETEaOtNlxwJn3p7Jw6cUv/gJTlcbNzDasHg+zToxM5dBA/B8xqLRN5KYbxMPYioMV6Cp4wfJruXMxPlFDO3kyVKNpOGhHPf8ANS39FB7MTpLFXCQV7YaEEFCDGbvd6S3Y+/29SBANC+eP3WlIcgh3d++nEUpwW/U9qCZvz1J1zx4GUg0/2kTPQnWJ48DKQaf7UF4+Kzm9K0GGcxveiJIyzaIY3ilG1oTdxaaCwgrOI/e9Hna18vP/AAvqTnt+aVc+IZnhjz/hydgJcNCoRbGnNs9VlAu3nBQgimp5km4NqGdE7kdZopyG0nzJPmvzSyedFYh5+KhsvYnypQmE7kdNefevOfX76DCI0jNT1D3qW/sVnVe/WKxqHfFSbnrVtMd5pY0PWPmhLkjzH4p0l8j81DT3/wAqGoe9KOCKFNU86Vc9HpJuepSGR6lJ6z2vS+/q/ZWxcbTf0UJldmPhqXHYUJ3mKYYisT9r9UJs8j8V9FL+ip/ob9lG5fJ9rW+/nD4oHMu5+irLayZH2JQ7wjZb1loKPhfKgMF2P6oPH6XFAMB2HgCC/eoJmL/0kHJXFSgmb89Y8GfXVlieRKQJLeZcUUkMyZihmwayQz5v2qJtl5Xt8SnYTs/q65VcCYGyjy5JyCDNmfxVrFaSRhtlpBhw4E+33KYlBZn04SrW+WyMYAR71O1dtAl9atgQOyL61/4imPCzcib8lK2hqk9QHxUET3JSUmMh5jUdG4SupKRezREWjymZ7ukNF8ifqoXLzOYJOIKRIXLa7QLNQw72ibdqIi2rjbiKvvpzjaokiGQcxbPMQebRYCwAILLFr1Lu+rSrmoYnSp3R5+KxaY1jfxXNnlSGX4aS5tx0RTHksW2mkTJVyfKIyczQi9jXXNIGDAXtrialtktpaeal3fVqXd9Wpd31al3fVqXd9Wpd31al3fVpLJ/UVY0XsTTfj1zUt/YpV1fHxXnPr9+J9Ql7fw2VY2oYthzvRcT7YXZ9uhTRzeN3FBExvnnemjKzg8K2JwT+aO4S96FMUkgtvLah26SmKN/2KRL71OP6vUji8W0pBNOG/wAVyezUNBew1O5HdD6Uww+aX4qJll4WpBJLfWI9qIkba1zexXP7FSuu3qOgm5zxfWnc95+KTpL2PzRLBbifcKMQexPmKG0ZYufYGgmQ8Svgo1n5f7o1F2g92X3oHI+/4hQGjzX5awHDa/M0BgewdUPF5/NXLNH+HNCJJ4IyS+vHFXJdH15/gazNmxtz/WQ8c0vS/t40HNJmyhtXF7lSCZBnGvelN0nnPvTtp0I7p90ymwxaHLpA1Ld6K4PijUQmyTPqVOkzaVbuawhMRaJ3gCpSWlexe01IaA1gDiX4FTcK3I8Ql71dxGJcRdRLSkiWRbnCR00BSSwZBgyTs+T5UbAdY8uCHpREWxTDUCTcKJDPazihltiM87RXbxHlNEcoI1CCY4GPDE3S2JjTFQ25xROuePChunzUFzHSLzrEeBlINP8AaRM9IL7OT7pLi3uUhp5mPWkN2/F5gogRPbAo3h2/ChEkR7fH9jO5e1un7eVH8Nl5a/5/Awcuy8tnfatt/POaBZ1gffXWIlwHPlQgCmiwssn8VCwJO9XFojrNQ9pDjWoiDg+Kwdj46N1QNnM+F6z6+sfdJWXO/SY+dPmionWXvQvsZPxQrGRFzstQT5w+lqXD7C/RRuHaHytA5fIHwUDu7/lqZJxXE9ZoDAOwHx/MJIpks6Y/yhhmhHHSyGXHHNRKPN8B4Ql41/sxNon3penvUJkY9PC1LiWNqAGYJpSgBI1pUs21iiXAvk/FI2h7fVK3mrTfP4qBvqFmuL3KiyUg5qUQkty31WNHtrSNYe1I09P9qaZ1ZgsTpalFR1CdiB86SLbNlLwCHuVcjMQsO7LVewoYWWECMEAvah4B0Ad65Wr1ZqBve+mtKmX4fNOyfOKkMsVJuepUm56lSbnqVJHvM+G88dLl5xpHlmnZPnFSZMM8R7+G8TODEUhkmOf8qKV5bzzF9bU2axqhB2zTGnvM/ioKiGwI1L84q2BPOsUGMOHTi9Q39mob+zUN/ZrOvJa+b2a5vZrm9mub2a5vZrm9mub2a5vZrm9mub2a5vZrm9mub2a5vZrm9mub2aTFs/FSaFana/vnUmhHnPjWNvP/AGraoedSexrG38AlcKQ0G7Syy5creXeorufg6HQpgl+lEX943i0018CgTl205mpDBJuLUSYhLTfrMOlh69JFpQdjEVEk6W96ikyLBC80DF2/b8USbY3+q7vehiZ9mkWJXaGaFAuZvIPUoiPcKfak/ZL8UfgIfLQW72gPYUIs+NXqod4Fvifwv8+5mPOJ06SmKAlriOaVS5VoIA/ghcUEAf1ZijxIcWpel/bwjbm8Urd8/FRGkVdgjQ70kXZ1yvz0JeWk6WpRpPao2HpUMRLusApmBx+zbol00i1qWGB5G8dqkZQ4UvUhKcWYPQp1TPfbvSDKJJE6J50aIF0JBTUqJYZFYfa/xU+amdlxzp4idc8fwpJFKRFzsoJm/PQtgDt1SSKUiLnZQTN+att35pOlqSLPXvfHptW0Q7y+VqByvKIPKaI5I3N9r0Q4Rdv7aeKNZ3t2qNt/qjB3Z8YTTMwWe8bUieVloVYntNeY/bUdSBOWYseC2s+VRLWPKaEFinA/dMdHztSGFZ3jU+dYa4M+dFKZJ61AZZXTHtXBwUMOKAtA5AdhfqjC7a77BFSaHgPlaFgQaon0zWA8wfZRgHYB8Uf0H+ZBIaR1vFp45KWCalcRxpG1R8/rwHgaEF86/wBZwdvt6GAmrm40eFBzTsfJ/NImekctozGaZMjD2pWSHgpWl/almnpeobHoU6Bg28964vcpEzWck07X1/ykNPurQiF6jGLb/wC0AwX9+OjNkktwO8FSiEHbRqPLhb+VWbkckTUogZQlrZJK7mdTj908cOz6NE654/iZSDT/AGkSzUGYJ36zW4ilmGfb5rg+OiantwbU97z/ADQTN+egBiowRZ7RUXFkYszdqV5Xj1W2/sLq7a0Mi829KwdvuhLwXfrxztdbbjm5tSAzk4NDpl6+XPQ6SGSiELnUc4PDyFde9SNjHrSMq3sNzcpZcHJBF9BZ9qsO2EsfHzXvigHig4WSNUyciioexYgT69CtaCCPXv8A8NQJcVI2adGpLOfnoeEYZhbRYrOIfv0/rODt9vhmKISf30ryfb815vb815vb815vb815J+8VAUzPP3UU2dOPdrze35qAwAXk+qOPKOgkS3jtFKZTw2fKmBc7M/NJi28vcpO7vM0JgqWGJ2m9MHuYaRpeccbxvSJmXonvRGm9+88UJEt47RSSIvuD90S05feaZWPNJS3hIqS3FK/Fhx/gT65nWhHH8F546ANw2t5Uo4A8eb2dCR/ifVJbDdq4tFOcRx0J1I858Cedfeu7PMQ+dT5d7edF8X7X/pRTbRe16Y6PnalKfKr40z7UEGFm9jFqIdE71FLGh6x81DZ8rnqUx09FbKLA5XYKS3pw2NAiiraz5VY2cdL9OV3EUhLN7pS/rV2E7E0NhncUn+hNCZXs/wBUDovdfqkGLaxdNJaALAuf51CWPXqdBe+nz/xLoYPd28DUlnOp4YlCmCE5oF3zp/WcHb7fHC4JPX1qMsPFvOua3OjWq95vnOr1aMPyz5VtmdoZoQIttsURpvp4JN7Te0TtQli8yQe9ypCGWW1vOoI2i+KVZNqbVS5vDaonDfaYmrLQvJntFMMOXEHrakGRG0rOuWjW2WKuXnHlmnG86QWjmv3Haf8AP6jKQaf7QTN+aibpbExpiom97sfrROsTx4GUg0/2gmb89IJhw5881CI97T60g1ntH8CdBeHmR6RRoh8r0I4f5daGZ4Y86miNkxr7VK506TSsdj4qabJ26SMMe9CjCCWsTwfdJVibKYDB0KCXMReh0J5RQLgXsTQ8RD29mkXgveyvOaDyr2rCHzJ+aLYt2t0Es6Hz0PmuCkUqfrcOvbOKCAOpTQQR69/+H8c/gpnymPOpFxv7RUd2ozxt/tBvN727UnS3vScZeVzy6tJDFE3cmOOf67g7fb/FhcvOWIDml7Btn0miNBL6pp8GFy85YgOaVGbbZihBpnSfW/hJvqHtU28rfE68lFsW7W6Ksm1OBPUkO9WlmTUIc08EN/8A38UG8uc35VByCcieVTxzH3HbX+leeOkiInzpTI08B+807J846Mgko2LeGMQl9/rpMb+i/FNmsaoQds1EZl7ST/AnkMoL2816jUnteCo1dtv/AGjvc615XrSWvp4YqTZ61JuepUyzMvrVhCX1/wApVlGlMFjMc0deQnXvVmwpVzR0Kn4OV0Gr+8i2hKRwa67tEm4pgIaF292KTgnMF2I1FPmg8q+hWCk3i/rVjtSRHJNBLFEIOsShQBf9bRShLDegDl3qC7nHY6xLjL+Op0alsmyE+dqAMf8ABsgu67UEesr40EhqQXZv7dETNAbt/r+w4O32/wAhi9tTWYoSzYvzToJ5jTdu+vLwGL2lnnak0g8kH0ahzANrTtrRfi+828AVjzY3oEnKbxjzqSMlJuWjFMNjLePmoI2i+KFztVy1QZlm+rJ2ru7/AO5/qO6OJikWwjiM7UEzfnpE3S2JjTFRm7f27UEEdUN0+aXpc8redIhcfWx0dQHtQDDPv/AnRWmOJj2oRJzbt0RdY06gZPFSNnyo1B8qi6+s/fggtuZ28L4QXBV4gANoZnQ5U6XY2ADnv3qSQTDKWG0TRYj4selRYTkmhkh/nbrCZ1udqCWKIQdZDPpMUycDdmM7UTZZXOKuiEiNNOIoB/vW6wUAx0Oj0N52+/8AgqDlxRu5bveo6ngt1CUOh/ZcHb7f5dXl14Knx71Kd3l9eAbRJJmTS1WiR8mJdJtRZe98t44r1zN2fnwyb2m9onaklhngMHlSDIjZVnzUXm0QxFR/XZSDT/aUZgdpv/BHmfRRne3ESvnSjMDvGPOggP8AAttU+n3RrebvlxWXl0PA1wU7Y9KZ1yO9S1DytUNR8iaIphFAcI9kelqm8A/tomlcd7Ub30/NAc9zo6SI854Depg2NDY55oJY/ShHu781wa2qG+XH/nQpooX1vUXliIi+jOa3H0v8U7H67V5R6e1AaT316X5tx/tAGKOkLigGb9/x4oXGaCAP+AoTl0N6JZYS/G3Q/ixSTDUu76tXWrvfTb/h6/LwoOadrHFaifH14rTME5xS6EjZmiYBZ+OjKQaf7XF7lImbdOB3y53/AKgZhoVIZs7SFdqd6Vc/X118g4Me/gudnH3SGX4aU5hd4vU3tE7TSGkba+/jTqTdJ5aEMwd33qXQE71fUh22pxmObfdOczz4WlgXalMrZ07a0UoZqUiWdi/kFSRY7mD3od5RfYm8ZrSeYH0LVOMGe3wdFjRexNR1k7jSxNj3dilcpAwaHpQoS6+lBIJO9c3s1GXl5oJifSuIvlapP9R7VdFgNbs+vQJYmgOJeP8Ayg4/8qFvC83a5vp+aAMdDoS45oAx4mghfv8A8BQJaVXQ/jegSxQQR/w9fl/Ag5p2vrWonx9eJCbhPJWMMRtFHefT66CRLeO0V8m/H9ORET50vS3vSXNuOkJpHjYSHT/Kmka7/fR1llvaS7tUoRET3+/Gne0+n3Rrebvlx0mnfufc0YxN839PA0oZpk2Adr80hmPP22onleC0ebQNru9zvEVAYA7dMaZvSWbavHgQaGl5eCtNNuAOnB9qiaeuaAwBXFqAa+hFAGKt0lu+mPWoNQ6QuKARqmuPCEtAO+/8ATPp/wAFSz6UeK82qdN3ttSJn6q5mjw3LO01JZz8/wDD1+X8aDmna+tcHueJCbhPJRGinYPuvN9vX+iw2dNilXN/5LlxPypiyCG7rUguzaZtjypu0HYu7+dJc248ae0LJB70Op0z8vuoo6LFEGWMyNP3mhLvkX9mgsi3m7Zd4qAYDtai/iNzW/VVY0DVdilzE2G3FHP0370CwI1oIs2++1AXy9Q6oN6Ac971BMxegnFR3faoa3738BUTo99Io3+n++E6tBvd3/4Klxp+fCEsUmBrGaA0nvfqg5qCI0oMs40L07fT/aPA1ovr+f8Aha/L+ZBzVuFGpak9n+nKYX94qZ1nbWi+Ee1eadgfmod32/FQ7vt+Kh3fb8VDu+348V2y2N6+2fhNXMvqvWlvPmfVLcWJxD7pVzU6XdaEzYl/bfwJ9aVG1+AscWqWyplaKHeef/K7/Le/UFsS8Ett4oXPq/BQedhMHxRjDvn3fA33O1Opfz/PhnTWJo6GJc4AyuxTYF4gMBnFCfipzk+VAGOgTv5E0SZSDa9+okkip7h70EETPWOkLigHLv4Y8ELigGb9/wAf8GRjQfXwkzB/EJyCrJu8Vvb7GJ86hJPBBZx8f8HX5f0oaSdn81PhrGid/wCWYstsxOmamLXsz+lE6xPH8EdWEh0/ylOvkUoWWNYX3ijILwlLxvekTYjpEY0p2T5x4076P7Fd/wD2ppWHE+9ExCY27VgB7tjtRrIe9B6SdVnySgCwAbFjrbxN9oCkTPWSTNT4aNmHYXe9qZkTYIdl61X0oAx0BcV3+1GC/nRQm8p2qO77eA6Rwvap7/dBBH8JLtvQBj/g6BzP4qIjknqtQZhvJQR8vL4ePOor58KMvWlHPbq0Ls2qPPtUefao8+1R59qjz7VHn2qPPtUefao8+1R59qjz7VHn2qPPtUefao8+1R59qjz7VHn2qRnHZ+q5PmuT5rk+a5PmuT5rk+a5PmuT5rk+a5PmuT5rk+aAnOmn5qPPtUefao8+1R59qjz7VHn2qPPtUefao8+1R59qjz7VHn2qPPtUefao8+1R59qjz7VHn2qPPtUefar7uZy53/kJ1ieP4mEh0/yub2KS5txXJePnapYFZT2+aFwVvMxrszSsmpHEeuPDm9lAuMvOtShgu0v70rITw1ljNomlzCB2EvrRvHtt50FgZy3fV/hfCjiPukSJi9AzHr26GILrBSLbi/unUFLFvKgahPCp70G4pxRLc7lQbHoVBseh1KhcUb1nhoBz3h8XfwwumfSgHL+4/wCFFY9eKOrUV3PwfxPhQc0o5N6Oj0WWf6Bnyfj+Z/rQ7vt+Kh3fb8VDu+34qHd9vxUO77fiod32/FQ7vt+Kh3fb8UoZf3yoRx40Fl+aXpY8r+VKyTf0pxlJdZhjalmJY0usTvekb+xfelaLGCYnOkUq5qUYlOJ/FEu6/HpUhqecffWRET50vS3vSzdb0y6vt902M83dGyUS1zBET5lDZIG9wx2omBLwfVGAAzM6+v8ARUNk+fSC+qe21YpL9OTUS5EyvPU3e3+15j3oBQqfHvQBjpHWFxUdb/vFcB8/PWK7/wAEphf3ipd31al3fVqXd9Wrupe9/WgF8u/92Cxn48MxrSTLj9x4TxvVnRhpkyvrbbareB6CmGpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31aVnL8cYrkfKz7VLu+rUu76tS7vq1Lu+rUu76tS7vq1Lu+rUu76tS7vq1Lu+rUu76tS7vq1EudKF3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31al3fVqXd9Wpd31f52Eh0/ylVl6dr/AJ2q5ctuD908ga2MxSrm3FSYm+3hkRE+dOUQ2vSrmpvGuabXsaS/FO4pmLjytWOBGzac3n2Kt5EcCdpb/FHojRl0W7+f53wgTKOOaLoevamMM6rp25oGJzu800uRb78qi+L4/wAqFxUd31oIIqKjpC4qO77VHd9aCCPAfyRPNG/0/wB/vQWM/HiCbjcddtPAfyoOaUcmiUeB/n2/m1+X/CYSHT/KS5tx01jPJg7tMPsWO1L0t70rV+qmLXsz+lE6548CRs6cfdcnx0mYM/TPFJHS+lpTkqWwNhxI5f8AamZn7ZCaSt6BWCCcF7q0TF8/0qr4C501PukwLey+XQyTHzQAWqFxUdb/ALxQBioqOhLWPKu/2oIImekdLfywun49aN/p/fgOdPz0PAOh/wCKAMdT+R8DGU7x+KP6W382vy/uyIibb/iluLe9dz6KnGL7/wCUqT9HmVHUeUfIU6C/rE9qnx70LR1vEN2kubcdUFl+aXpY8r+Vetvr3oWjreIbtJc24pQYbNNwgJ1j4obhHSBg5tb1jvV2Pk+AjHu1Foe8m+QbHesGd7bej+pVt4FBLWFWtMSbTUhZiHH3QCDoW7vigAg8B2PP8UX3x8+L2rz/AIo4XtU8Tb90oBz3/wCAg77UqvhJUDNBBHU/mfBrBhMxGtW0Z8o8D0P5b1er1er1er1er1er1etXl/bkRA23/FSJ4D06EGc7dmalcC31takFknXP4qRPAelTFltmJ0z0J1zx1YSHT/KS5tx1J1zxThx5+9BQmXQDdb5KvYl0EUS6F3zir0CySmWphfO1RAAmwAG9j+vVeoCX/XtS12A2NY70+VvzOToC4yUEEdSoXFBAHhP4p7e5Q+3vQdWfagGD/hKDnSrrdfCJ4PAf0HwSXMlRafJ7+Fqf7Gry/tJGA0pLm3HRXQnOpE1KCc/7bFMJDp/lJc24qXd9Widc8VeeOjDZ02K5PjpAzb3k3tQjikGbEZYz2qxHouEfH3HekBgOkUPse9NDKM3y2j/lWSRnj/f7NV6GedCkqWglCpQAdu3nUHd/Y6xQSx713+1BBEz/AAQuKnxU9w967/aua+Vq87z/ABXAfPz/AMZYJpVb+FrzH7b+q+BD33pRmPKj+5q8v7EFtxvtz0ml5mMf+NCpcwxxTCQ6f5SXNuKnTzonXPHVhs6bFKuXpAzb3k3tQjitGHNm9OXNloibotvlqfJzILhhXX2qGBMAHDc/sVWpqep2F34pVu36Cy+VStYjfXwpsRbfwHiIaT51PQK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIriK4iuIpZdipXPl2o8DS0idTv5+A/pvg5Em+1HhegiSf1dflXkv7zXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vzXm9vz0Z0J84qUE5/22KYSHT/KS5tx4ZEQNt/xS9LejSXNuKl958+qCzfjPnQjZ1BGbGKu4axKTwN32qaDnmh4/wB0kMY424/tHXwOyYb021mb/wDtAuKDjE5nYxWGcQd8eE/05oAx/wBVu6R8Piywa0A5d/Af03wwSmMxzi3jRGbHU3pG60sc8f1MXn8f2M3s8RhIdP8AKS5tx0FW1mM26InVjTSNJoQjJwAex/yr7BTW61Ydt31qKQjvGt7TY8v7R2amp6qCWx+2prMG35oJzhvitz0/2oLWs2DcNKMrTp8eGS7j/rSuRYa516Hgywa0Avl/ceA/qvhkuZK758LSaJ61KWbBrpR/Sxefx/Wg3lPEwkOn+Ulzbjoc76bdIkw2w/NSWZOwv2irpi4PmZ9U86up7sKeX4/tHXxEd3Q/NSu62lvYonpATb7Xq4tZ3z7UIBt4NRPLJ1j/AKTUyTQz328UShQC+X9x4D+w+BJ4dHWkGbmZ+2jwtYl8051oRJMf0cXn8f1pWZj9dOsiInzpDduxd271yJi3blcpZ0DtTufWslssl9GpLwEazQm50C1uxWHYkklOAv5sFGDI2Xd5Rj0qV0dcp3u1Ls+35qXZ9vzUuz7fmpdn2/NS7Pt+al2fb81Ls+35qXZ9vzUuz7fmpdn2/NS7Pt+al2fb81Ls+35qXZ9vzUuz7fmpdn2/NS7Pt+al2fb81Ls+35qXZ9vzXa+32f44sM72g3oard+5tVpny8Al7RR0hcVBdz8dT/pNTJNDPfbxSGbG9QqrLpweA/tPhY39H4ovjXwtX0Yd6GzNnaZk3/oYvP4/sMJDp/lJc2467D6qS2kd8tCNJybu9qUbjiwJi27xehgNCHXg/NJSG98Wz5f11Ts1NTU+FQJaSzEs6tAMeuvUJAtOOeKbJvOhmOKsS5j0koQB0BWCggj/AKrUyTQz328UhmxvUKqy6cHgP7j4dQs/Nd8+JN71Llc0dTvRf+bF5/H9dpYwlTpbfmraeffpFbcaYMtSJ01nBzD5aEi7CYbZ3faggC1rAEAcH/B+2nKwVfNhx5eA4BbZ03aOWXXo2DQu0dBNg+H/AFmf0v0PCKM3jWkt0g0zPhP7b4WdI86x8/qjxNIl8ttHvUQYSyW30/lxefx/WVc0oZa1M5VOzSDNSXjF8/M0xNmbXl8qfkNgC3ahsd3yqIkBYE3UmZXnvQqS+Xb/AIP1GQvwjcqAnLu9CVg79uaJOSBjniKAMeC8dzbk06H+nNABB4D/AKLKv/rxxKFBM38J/wAJBzTNkfmjxsJD7CtGoIwMk6VOszz/AB4vP4/sNLaJSgSYYoNIJuMHdNjzqMjl/IFDJ2tgNNv+D9DLOhq0Ox/SaAMUSvgovvj58Wwy2/NBoV/5fn/rMq/+vHEoUEzfwn998Sbxb4o8OtJUOrPm1cywFlzFDKX3IQbYvQNsaj+LF5/H9ZQKU5YM8UAK62NZnMhRcyCbqkbA/PzVm4M5ZYZTl5/8/wCF9uZXfQ3oRdutX6q6gZaAZv3/AB1jpx01oFbUAzfv+PBH/SCj7Z8cShQTN/8AjPiQ996RG8eVHhUyZ74oBgiiMOlsWfWtkNEyd6MgzfP8GLz+P606aTMVGgvcAGWhHapEOclYDSZ/FGO3l7f8H6GWdDVpZZtoNfOi1i1Dc2oAIP4GjB3v/wBZ/By7+OJQoJm//JfEqUrZjajw2jn2imC7abMY4pSTXWpQXDEQkdlDWbucPbx4vP4/rIim2yLaHbWoC1F4hpLF9aMQgXnnzf8AgWq4+tpSx59nast3eLtG47C+ragHPf8AHSP4IlD/AKzK+Et7Z8cShQTN/wDlvikvh0oQxxfv1ijog2T5KAEFiZ86KuBAxafShnDbU7UAIfLU3kKRM+DF5/H9a/gsl0dnH/Ac6Yw4iZlqykDYCx5r9UmrsYbb+alMULW3Zv2oAx0j+E3Xy8Z/zVi7SXGm2xQBjxxKFTHMEQuqzigDH/QQclIqwWLGNKRGHqdWMhDe31TOulvSg1bG9ZFBwAtPZoa0Mx15SiEkRNzH/Y4wDCVJ0GhId9YXiaAYzNky9ymbhq6tYDnv4hPBvWQHCq/4qy6i84oG59fqKAIOF7TSMS4trt0EBzf1/wCmsXa/bgwfwRKFSxNsvL/yn+JRhtDZ3iKZPu70EzfnpHVJziiBvf5rPy+64STZx6VKm3gWeKxnevOJ4aP+oglAaL9U1wOV3N0/NKt7rLqJ2/NeVq3eH1oOpYSRn4rRzGv7Pgu2L60DJhX8qym507dvE7xsfNC53+L+GP8AnLF2oVLj6nH8EShUsTbLy/8AMf4kGJO2au2W7692kTPiWdTtU+K5qAXh41vtRxglgyNWiYdn0A/qybGedo9OP7gGbGrgDlKAkMjQmDYqFSNG9t7VetY315vQ3XA1jXyoDF4ezHe9CTPs+aAQxCtsdHTOuPLNX5szjNqAMfwQEsc+m1DKy/8AThUuP9xQBjpHhiUKlibZeX/nv8Cg44xU1BfnNPeO5mgmb89Io6sZCG9vqmddLelWjWfKKszDGJMzGKM1igJyd6WBE8rm+f6NmNSjOySEdipKBxDrFuxxJ7Vq3N/Q9lp/aZ3CAmXTu/VQqG1m93FBBaIwRGcRQAgAV5RBtrQcambYjii0TOnbaYodyfBiWhzidrVadkTHOJqIJSyOKAd9/FHgUHe3tWB2+b/9EO7agrJc+v8ABEoVLE2y8v8A0X+APJzURpFMNmsYnWRpIY8Ua225oZMw6GnarB7vxSNF+K3kQYQPnND4EWJXzv8AmsgOFp/ksFmDXH3WKJaa5u2jtM1BlVhmKNYW8jvVwi0rW7Vt5oLMSQ648mv3k/sMEkLZbRG7tQ5huNjhFOog0BbfFa4C7xE8NDO45lBO1BuHGWJ0oRYs7fmjUxLVzQga83ozgtnhDm9EdJPpHD+KIXVG82i2fwxT0vTcn46R/wA+Kxn4of4azz1PDEoUEzf/AKj47miwz2tim2Rn76a0ca0imCxYwYoJm/Pi1nXf3rKVm3Hk6CXUbkKjyTYXInOKh4YrzchxNLWQcy14P4NX8GZ7F3yGhTjgCBNTMYy0gk7ZB2kLneiCOJi+qN9KJ3iOX6oDF3906R+hif6yglsbtG2ZS0tizWogXRg9KAt/57Vqe7d8qAMXd6HcpGt7+9Bbd29Cbh8Ua23H+0AYPz60PWw/VEbUI5G/hXoog3T2avT+3/6CZjLi/lFCeNHf0oAwfwRKFQIZmJ24aAQY/wCykkUoJY99Olo59ooLzl0jSg3Fwt5+dBM358B1gzF9+rKQaf7TtcQZ9qQmzuUavcEb5EpcSk2vie9HHQEABKQAxK2qfSHIOGD0T2qSFHIL9bBoT3VwT3bqJWNdLz60dpvEy0EWChvHe1H+1W4lfWKQ7c92Ir//xAArEQEAAQMDBAIDAQEBAQEBAQABAgARMRASISAiMEEyQBNCUFEDYGEjUnH/2gAIAQIBAQgA/hTzrDHRP5VDGk81DOs86wxUm/adAXbUFi3VPPWZNZ51FMGDyS237o2tx1zvX/8AlREOZ5qMLl1LNqWZkT9i1uJ7dYYqUb8mu/aBRM9iOJR3VaRwFr90bW48kjndUpbm9AuIiFn6r8j/AMNPOsMdE8VD46TzUM1P41DFT/zoMFTPfRDHXPPgMGko35LNr9Hbt0WPrUUxvlSrnqFMb5USH5RtbjScVbmxoUxRJCxFuXant0ja3FTPdR2/tG1uKme+iLILhM9iOEuWWNuKRI8imBP2ja3GspbW1RdxfSedIx3F62N7VsjSxjwRVOfqPyP/AA086wx1zxUMaRLKaTzrFU5k37TQFwYOuefAX9N/dNvXWC4s1slREPlsHEja20jt/a0Ktf47ZURD5Wv8bNImRjbmNrcazBa7oUotwv6he3M+e0YpQpgwVM96DZvUMVPOophkpZsB3ErcS3xrtlTD/GNm1bJUiZBcImdkq2SqIhzog5WMaZhSq3Sf+lrcfTfkf+GnnWGPBPNQzUy3cDcvUo31hjSZ70iIc9U5I2Lyab+xTBgr/p6r/nTlqGNJ56mKF/AKY3yom+90XMbW4ltv3f8A50WtxpPntETNR2/tG1uNHDQKXLpxLeGIu4vpM96b5UYKme6FOCKpzUo356I7f2ja3Et36kkbSUM0g52RrZGtkasaKHLvjTIeCJtLVPPRGQFmFrcfRfkfc/8Av8qedYY8Vy9qiWU0nnSGNJN+0h8qj70nx3Crmoy2lqMX1m+qj8imfbc5k1KO2oY0/fq2SowVPntETPlL+t0qJD8rwogPIwfSJmt8qJD8o2txK7xTb1ulXZenZflsloomaja3Eo35LNr0KYG5fSW2/c29aCmFXNRltLVF3F9JS2tq/JUXcX0nJGxFU5kftUVS7UwWwiZ1JD8o2tx535H/AIaedYY8Ta+5e131F3F6lG+kMafvUfkVEsW0m+tAUuBdtQWLaSlbgqJYqbxaoYqeahip8dwyUs9ALgwapctTFOfNDGktt+5t6JvvdGXMi1uJxVuImdLtrVYkWgiZJWLLb1DFT57REySTBgqQPLQpgwazBbDFNQXApjcJ3EVxtlWyVEH3+OpFmxvlW9tZha3Gko35LNr9F296G5fzPyP/AA086w+VR9+CeahikuWqJYtpPOhgqeNIYr99YYqeahipvrQ7TcqhbRUtaGNJ56QXBg6pnvzGDSfPaImdBTCrlt6IryMU6OSlXMb0xJcxYPqiQ/LsaYPov6LX7o2txpOKtyIhZ0nFW4iZMFKGWf8AjJSzaz3MH0iZotfkR5NJbb9yezXfKhuX8j8j7f8A9/lzz0GDxNr7mRzuobl6nt0hip40hip5oLtqCxbSeddn+wEzN5tQWhQXbVDFTxqC4MHime/JDHRKN+sUxvbWXbbjZKhs3pN5c3SOK3ROQfUmB6YPpEySTBgqfPaImavtCmb6FMGDqnJHjS926I8ko35NLt70Ny+stv7dApgbl/E/I/8ADTz0Qx4Z5qGNIli1f9PWhgqf+6R+DpDFSUlxQLgH3HFSkjUp+iHypbt6hjSedYY8U8UKYVc+OGOiZ78UZAWey1R227ki/HmLSrmGNJxVuImbtrVcflG1uJR3N6lHa2qza9W4vW6VrU391ZqF7c1PPRvlUPjU81ZtfQUwNy/RPPQKYG5fwLYv/wCGnnohjx/vThr9KC7agsWphdvpDFTirciIczzpDGkr7ii3qeaY9t6C7aoYqUrcGkY7i9RNpbxzPfliqc6z57REz5Ly26krFmNrcIOWBaxslTFKFMb21kYHJG1uJxVuREOZnulE5oT2WtxU86XbWpEzycVF421E2lqlG/JRJKJcbaibS2shW4ls6CmN9+KibS3T++l21qbevrf/AHxkVwiNn7889MMeO/Nqe13ETaW1/wCnqofGp5r9OgivJEQszzeoxvU1HiGNJvqgu2qGPNKN+TyRVOdZ89oiZ8nMmscLb1W6Vb5VDdThqMdxemD6RM6pLL0RVOdJ56OSt8qMFTirwiZoUwYNZCvCW4dBTG+/FRNpbX9+i7a1NvX/AICeemGPFPNQzom520YtTxK9LdvUMVPNQTFLdvqR3A0YtUxZWoxapiytRi1Slbg+5DHUly1IjZ80UHm8a4fjzFpVzBs2Vu3qGNJA8sUG6SMEo7W3TG1uNZ56OSmW75FrcTFeETPcVvlRg1lFW4luHQUxvvxUTaWpLluq7a1NvX0bNr6f/f5c89UMeGeKhikuWq1+ai7i9SedtSjtbVDFTXFQxU86wxUpbahe3M31QLgwVN9feiqc9Mz35hRuNvVCmN8qn8q2qXBTBJC2l21qYoXaFMMouSO74omdIqnOsoq3ETOtm163yowVOKtxEzV/9LW40lFW4luHQUxvultERs/VcH1GKc0xTP1556oY655qGNJ5qGNJ5qJxuqUtzeoYqRJlcEcTxqKYC7asNcyaCxap8dwq5+6Nm9Dcv1TPfnvKXFImdBTCrm7a1bOKRMimJSvwMUL6xtbiYrwiZoUwNy/RIV4RM6sUqGNJxVuImav/AKWtxpKKtxLcOl21qbetERs/UVW74URs/wAGeeuGPI4ahmnLQpgVS8o3b1E2lqnmgXERDl+ZTlqMbm6ou4vU8/wBs3obl+qZ784piQWu67JUiZLe04uVuU2rFNYqnNTzqNm9Dcv0Tz1QxpOKtxEzV/8AS1uNJRVuImdLtrU29eCVr9vi/wDvku2tqiNnxIjZ+nPPgMHh/wCnqoPFtJfMqUb8mkZJSxTlv7l8SoqnLa+hgr9/u7JVslWyVbJVsl1yTDslWyVImQXCJnQFxslWyVbJVslWyVbJVslURDnpnFW4xQu3ZRtSJkUxKV6YoXaJJgwaTirwiZrfKjBrPPT27a3SqKpzU4q3ETNX/wBLW4qXzOm7a1NvXgla/b5rcX60Rs1dtbX/AOeNEbP0J58EMeGVnioytw1H3pPOophkpZokhbS900nn7o2b0Ny/nnnSGPFPntLyjxUVTnpnmrNr6CmJN29W4vpf/S1uJRvyWbX1ja3Gs89PbtrdKo2txU4q3ETNX/0tbju3Vcvb6/8A98ZIcfSs2v5558MMeGUdzepS3N9IY0nu0BS4C4BEvKN+SGKme6iWKnn7httzsHETaW+3JBvoq5Jpw9U707bcVuU2rDtsIma3HxIm0tU86imDB4J50WZmNrcVOKtxEzRIa2RoLNjwWbX6btrU29dFkL+Z7XcQ/wCk78Xu9N21tW5w+Dt2+aefFDHXPFJctUo7aRMimIyvwoA2hjonJGxvlSrmHy+9DH25KS41P8byjxUVTnpmOaVSzV296vv4qUdrbWNrcT57Rihd0iqc9c+e0RM0szMbW4qRcCmI1aUcRlupH9dzFtLpznru2tTb19Nzxvb2mInGiI2fJ27fJPPihjqnmoY1j7qcVbiJkv676he3MpW4NLNr+YFxslRB97YmSMXAAWOuW2/daFWv8dkqRM1DH2ZIN+q7a1CmGb6MHTM99Nxe5PZW+Vb21l2240FMGDrnz2iJnTdKhkxtV21tEHJeORHFkO3cjaXm/wDvUNm55lb8XFtqRXCI2btrfVnnxwx4JS2tqGMuXsrsrsrsrdE4GUUqGNZRvyUKYMH96Z7oUwYNJS2tqi7i+sgW3QKYY3L6imLXLCJnSNrcdUnnbTFNRs36WI1ukNpCOLIdornoW2RHHQxTNf8A2hs3PqueN7e0xE40RGySTCq3au2t9CefJDHTPNQxUo7qIyaRMguNkq2Sog+2D6tIrdKt8qMFSFlxUVTn+9M96CmJ4oUbkbW40kC26BTFrlhihdoUwYKme9YqnPVJ520xTUkAXEcdDD3HdIbSEcI3uEubOk8UYKZA2dWKZ+23vRIcdSI2fLPOoLhEz1wx0zzUMaNvfZXZW6Nb41vjW+NXi0xvzHQwVPNAuDB45bb928Mfkr8lfkr8lfkr8lfkr8lfkrdFzG1uP489ulm19BTDKLmNrcVPb0F/UVTme2rNr0KYMFT267lNrE2luqfPaImatO1WnRf3pjOjFG8Sf+7Y1ZDtJDVhyicMMU2Hc3PCXC59aUkbBMfoWbX1nnWGNJRVuImemGOmeahiv3qLZvW+VKuab+xTG+VQxSo0hI4SzajBU81DHgltv3Xt8VXOgLjZKtkqIPvbEzaFbBx+OmD62SpEzoKY3trMLW4+pNcUKYMHmltvzE2ltJ20FG5G1uOicVbiJnfKjBUgW1Cjcja3FTPekVTnrlFW54U9NkO3dzZQcgGKYf5E2lqtzfWza/V27fsueCcztRHHnnnWGOieemGOqeahipnuoqnPRPGhk0sq2g3Kk37SoYr/AKeq/JX5KZvpVzoC4Ih8o2tx5Zbb91r/ABRM0KYJvv8AJW6LmNrcaTkjYJD8o2tx0LYvRP8A1m+lXOsRDnzzZGI2txU86xtbjpmC1zFobl6kC2oUbkbW4qQsuK3yrfKjB0vyPLZHtEcdIo3FVu/wHPG9vaYjjyzzrDHVPOsMdU81DFOHSGOmZ7qKpzSDmX+1cY81FU5/fUFwB+0bW46pbb914VvDH5K/JX5K3Rc3hUbW46ZRvydMVTmp89oiZGzehuX6P36tqG5i7i/0J89pzFqKJcqQPLQo3I2tx0zzRJODfdssW9gbN6G5fSZ71hjpnjz3dtqEcaf/AGrNr9ZcLn3JIN6J/wCiOOm7a3glFW5EQ56pRVuImYY6p/KoYpedukMVKO5vUTaW1/ehTBk0eblImULXIlipbb9zb1DHTLbfuvb475Uq58YpgkPyja3Gs9vSTTP5KZLpFs3omhavyV+SpS3N+gLtqhj6cnnbSMGoolyp89oiZpb/ACLW46J89oiZhipxV4FMGDSedBs3qGOj9/oIOf5MkG9E/wDRHHS3OHVByAY+hPGhgqcVblkS/RPjuFXJgru3VOX6lRltpVxIMx2kfkWtxUtt+69viq5oFwQfe2JmNrceGW2/da/xRM1dvehuX6ZRvyAuNkqRM6omemIhz9WfPacxaiiXKnz2iJmhTBg6XudpKO1tW+/FMUrfKjBU+e0RM1D5UAFjT9/u2bX+/JBvUf8ApQjikThq/FuhQyI42RoAx555qGOtedukRDmot1a/6eqMlIOZAPEMUg5n28RoFwQfcTaWqW79bTov70nmi/rvrvrvrvpv7hjSW79S/uW2/cn/APOsbW46J89oiZ0IqX6pevJHb+0bW41nnwRVOanz2lmtja7QpgwdM81DFTPdRbNR91POpg1/f+854JzO1EcaXbW6VDM0bWj8fp/vpH3pN9aGDWeNIYpw6btoJFuXqeaIxDuNlbo0z/yLcu+VQysHJa3FT57Rihd0hjolHdUMazzUMazz51XN4VeFLG1jwRtbjSfHcfLpvb47pXvUpGKY+xVzRgqeOmDcr99G/r/9KvOrzq86vOrzq86vOrzq86vOrzov781m1/4TngkraWt21umedIY+hJv2g2b1FuX0nmo7f2ja3FJctUSxap5oyVP41DFTzVuBqUtzfS8o8VFU5+myBs8JUSxapbb90j2UT/0RLngkpLj7YpiKpz0SjfkBcImeqGKcPTDFfvrH342y7UAx4LtrfypSRsEhxp/0Eed0qiqc6zzUMeWeahjSeaMFT+NS9VD5UAFhiLep/Go29tvUMV/09U/EoLtqkWjbREyXTacxaiiXPqTzUMaTHOsVTnqkpLjxguNkq2SrZKtkqIh8rQq1/jslWyVImetEySTBg65xVubJVslWyVIkeRs3qGKnjoh8qj83U+T47c30LnJotuURx1IjZ/kN70I4qcVbiJne2tUMayircRMwx4Z51hjSeahnQRxL5GkfdSOd1Ml0MlTbFKrdhjSeag3OanihRuRtbj6kvmVLb+xg0me9BTA3L1KW1tUXcX0ltv3NvUdv7Rtbj7k863b3q5ItRJK3yrfKiQ/LeGN0XMbW4ZBwrF5YWtxU86w+VOHVBzYqxVirFWKsVYqxVjob4dW3NRm3s9Hdt/mTkjwNy+k4q8WlHmhuX6J50FMRVOemedIY1nmoY0j7r/p6qKES8bW4qQrciIcylbgqGNZ89pzFobl6nt0FG5G1uPpTzUMVPNQxrLbfubetIzAsybtyGP4LEeVh/moLjZKtkq2SrZKkTOgXbUYtU89Jg+k4dYje5cW3UiNn+RPOm+VGDSYZoU4IqnPRPNEkxFU5nnohjWckbCrwmTSVrU29QxThqMdxem2Kb+9IqnOsm/aQxpPntETI2b0Ny/055qGNJ5qGNJbb91ouNCN43qLuL+RkHDvK3lMoubwq8KvCrwq8KvCiUTG8reVvK3lbyt5QiXKZBwsoue3dW89boueyjZRa3FTUeIqnPVPPSYPIti9f8/fTPGgXbUFi2je9CONGKZ/kzzrD5azircRM75VFU51lG7egsWqeahjqn8qje3KDkAxU/lUTjdTN9Rbl9JR3N6RhyJxcGzehuX6JnuoNzSTztqUdukMfTme6hjSeahjWUR5W1+IfHxTkjY3tukFxslWyVImbRoiuNkq2Sqz42KF293u//OrX+OxpinNEh+Tb1Hb+zb1Rf039hBwAYnnoIli+yNAGPC4ahisZ0S5aks20hjoY3ld6LtrfyJ51h8uiUdzeom0tU80KYJhiLuL+CckbCrykVxASXNKGRHGk9ukVTmp89pzFq0U4iIc6z57REzG1uNJRJNN/cMfSlG/JUZWNtRNpofJ0njSGOuUb8nQC4YxMxtbjzsR5QAsayjub0xTwxVOdJ56jB5JN3iGOly6GDxIjZu2t/GnnWHy6FDNoy5ovbmQrc2SpEqV78wxrKVuCgVsbJVEQ5QcgGFsXqLcv0z57S0o80I4qYsrUxSo5bbY0AY0lHdV5R4owazPdRVOfNPjuFXOhFS5Rk0nuvxG9uXmVqSzbxAuNkqiIc9EpWbUzfSrnpFMb5VvlW+VKuf8AnjWckbF5NN/YLhEyKYu1BU5nFXhihd7ttNvXRG1uKme+gmhY3tEpODdfnrUC6qt2GOmedC/ovbnSW79bzq86vOhbXkI4b+0Th/izzrD5dTK0raMRzsjQBjSeaBcREOUHIBjT8lR4PBM91FU50me63yokLYAMaTOL1DHRKK8jf2iZ+hDFTzpDHTPPWC4Cxbomo8Xk039wx0T3X43Srf8A6t8Qx4Jbb914Ve3x3yrfKlXNDH22vxUMVPOgLhEzoNm9QxpPPSYNFDPVJu8BfjpcusMeFzwSVtLREbP8OedYY8Chln/kW5Xa52xvXBxQBilDO+NCOPHPOkMaTzUMdMz3UG50T57REz9CKDdAMTPekRDlQyI40YjysP8AI7f2IxcbCgAsaSltr8lMV5IiHNS237r2+Krn6gLhAOaXiwiZFMKuahipnvUUx+SpS3aguCD76G3roctQz0JctUhi21/JX5K/JX5K/JX5K/JX5K/JX5K/JX5KJEi38WedYY657dIY6JS2tqi7i/0HudpKO1tQ2b0Ny+ko35N0jioz9KDmIhZk87aTa1DHQ4fpR227pEbXjRgqeahjwy2/tLbfthipbb90n0dBFcbJVslRB97K2Vspg+iD72VIs6guEtw0C42yrbKoiHOs86DZvVm16GzepNwdIy2lqVW629a2bX0MHicOkLBu6Z5+hD/oxbv5IVadWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adWnVp1adSvflEzUMdU1xpG1uKkmHZKtsq2SrZKoiHP0J5obN6G5fSYLV5R4qNrcaTzoWtxrPntO6PmIxS9SAbD8Sl7Q03yqfy0MnUoZG/JUtt+5Y2sax2/tG1uPrMg4d8amjjSLzakRsjZvVl50MFTz0bu3bpiNqjLb4Z3vzEvxTu/Uv70cP9WedYY6Z5qGOiaDRuW5utxK8TimS0J7LW488nnbTB9VFU50nmoYpS9nZGgDHTM96Kudkq2SrZKtkq2SqHx655qGKnjUwazzoKY3Spb5hip8dwq51hjRBzsjWyNbI1sjQBjyTz47cXq946GCpnvSXroMlNh3Ijipbv1vOiTe0uhbF6lK9RLGkffTPP8ATnnWGNZ50hjWRzupktbJVEQ50lG/JpG1uPoSjfSGNHudpKO1tUMUyBtSDlimYqnPRPGkVTnxzzX6VD5VZtfWKpzU86QxpLb+3REQ5nx3F/db2t7W9q83kL258s8+SJdtrD5U5dIqnM86w+VOGjB0zkjYiq86Tx1x91PP9SeahjonnSGNZStwVDGk5I2FXNQxU81ZtfSKpz9CQsuK3yqKpzU80KYEDkkLYmRKFMGDWUb8mm+VGDxT9U/A0l8DWGOickbG/jo2SqIhzPPRDH0ZR3N6YPrbKkTILjbKkTNFvaxtYpt6qXwNBTFrlhEyNm/RDGko7m9EbUwvRA9gGHudpE2lqjBlikvwkbvNR96y3frZS0tkq2yrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZL+HjOs81DHRN9UCvAWLaTz1QxUz3oSTBg+hLb+1Xb3obl9JgtXlHijBSl7MoeyoqnOk9uqrmGPDL9qh8anmjBX/AEzpdtbSTwFcxemGNJ51hjyT47gkPyja3E+O4VckkwSb3YcyvRJOAn7egTbZ05eK2SrmLUvjfWKpzPGkflSC2jIs2qGOu3N+ieKhnSPv+5PNQxpI53VKW5vW5tagXFmJeryab+64riuK4rjSGKlG/Jbi+kbW4+hM96RVOanz2ndGhuX0lFW5W+VGCp56I3tzU5I2I2tx0/8AT1UPjU80YKme/DDGkrX4BcEH2Fi3hnFW4QfbB9OyuE2xRM1fi3jQtcot7JRODeVKW6oYqZ70h8qkkSxUPlSN2oy21DGst36l/ehf3oti9LdvRk0j76I+/wCpdtbqnx3CrkiuDBUpWoGTQWLeOcVbiJmoqnP0JjnSKpzpO43INzmpRvyaRVOZbf2LW4ntobN6G5epRvyVvlRg6J5qHypy6SbxGvfUC4RI80C4iIc+GW2/de3xVc9Apj6Q2b1L430hipxVuImdRs3qGOi5e3Sly1JZtUD3SXLVEsW1Qc7I1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI/wABimeqe3QguTFqntrZKjB5pnvTcptYm0t9CcVbl5R4qKpzUnnbUo7ag3NZ50ja3DhqGKkC20iqcyjfk0LW40nmi3ugu2qJtLVP5dJgqW2/c2vxDGktt+68KvCrwq8Kja3Gs4q3CD7Y2+1BU5nnSGKn/msfkUxb2K3ytUZI8x91buvTe3HQ/KobtI+/7k31pEQ5kc7q3ScREOfoTPehJMGD6E+e0RMwxpPntETJJKEcR91POkVTnSQsuKiqczxoYNP+nrVy6GCp56IfGpvqlu30hip8dwq51C7aoY6Jbb9zb19qHypw6GSl526Kuah8annU5sIBieOiQZVXMMf3JHO6mS6REOXDQXbUAY+lKN+Shs3obl/oT57REzDGsz3RJKEcR91M96RVOZJhiIcz21D5U5aLptETMPjU80C45i6wxU86wxU86BdtVoHDuicEm7c1CK2qRZtXdtqFrcT47hkpZ+7GV2yxTNb5Ukb3W3qhTF9yCxMxKhjrkA8E7FqG5f8AtT47hV5YYpiLelsXqKpd+rOKtxEzUbW48870Nm9Dcvo9ztGKVCSvOkz3Q2b0Ny9IOZgR4owVOKtxEyRUuI2u6NvSrkUwq5hjWedIYqeeqGNJ4/hS+BrDFTz0HEeWN5Xot66p41hj+wKNyeaiIcorSkOCGPszzpG1uPPIu2pucMMaT57REzF4u1PntETMVTlQyyEsWb2q0o81FU5pbF9FXKR9u23FR+RS7m9AuLSK3SpVylrVDFTz0wxrMVsbJVslWyVImfux+DVm19IYqfPaMULukOe1AMaNvQBjSza9SLlqSzbSGP7XduqU/RDH25nvSKpz9Cakr0Ny+khZcUJYKAMTPelwiLHa8mk4q8bpHFbrFi7a2l21tJYNIYqeau2tqC4s1ZtfpiIc9M+O4Vc/dhiv30h8qj7pw6wOL1e83wzzrB9fymKZ8ti96lK/BUPl9yZ70iqc+eReVijBpPNQ+Ok80C4k+tCb70nz2iJlt6oFxZpEzTe/KrnXfKlXPRa/xMFT3VG9udJ8dwq5+9DFOHUwV++gXbU8RqMd3R+/TMA40hj+SxTPhROHonnWGPuyjfkrfKofHzTxoYNJ5qGK/epnuoFip7r8N/dFr8iPJPGjb11du3QtfkA4J56C1+QDg6pR3N6/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46/HX46YPqoYqedIfKo+6nmojkbSNwDN0WxfW/NukAx/JYpnx2bX1u2tU86wx9+Z70iqc+SfPacxaG5fSb6qGNP8Ap6q7e9DcvpOKtzbLRkpbUFwiZq7a1Kude3bTf31REOf4s81DFTPehk0mLK1SLRtUvjQWLaJctQWLaMRb9KXLVEsW67Nr/wBC7a2k86wx/Ame9IqnPknmoY0lG/IZNJ89oiZFMGDWZ78QLjk40FMKvLqCtiJYs/xp50hnXfKoqnM8dFub1fut1ZzqoZEcEkxulW6VKrd/jKrd6LtrdU86wx/Bme9IqnPime9IY6p20hjWeKGzelVu9ApjfKlXILizFvpZtfQkmL3e6NrcfyJ50/TVEzD41PHTGO3x3L26s5/hXbW0jtv3eKedYY/hTPekVTnwzzQXbUFi3VPntLOkVTmp5oFwRu2dsRstvVFvY7W4hmNF/W+5aTb1DFS237rX+Nm9qbnCKYiqc/xp50fh0QxU80ZNUHOjf0X99aSHtL25/jXbW8086wx/Dme9FXMbW4655qGNJStwQx1SedtSGPFb21tGKF1t6qN7clrcVO9AuO6JahP2lt/XQUwq57dvQKYMH8WedIty9TzUPlT8moYqamIc9yfJq5e3TvL9e1S/QyBt/Eu2t5551hj+JOKtxEyNm9Dcv0yUlxpEsaTFlajFutLlqRGySQsVbi9Ek4N8q3SvfQl7RTDMa2iXjyNbVL9IXbFOONIfH+JPOkvgaJ2aQtam/s3bS1p0Xty39RHMqb24IyMG6/PhYp8Y7v2/jsUz4Z51hj+LPGopgWTZJN7t+b6AuAsW0k2KhjwyltbUyWoiHM8ahdtWyVbW9qSPqhTEpEqFMGCp5o227m1+KuL3SjtbUF21Ix40FMRVOf4M8VDFTfWkvWjxERVzFeIlCOKZL8Y7v21EcLYv47zq86vI+Qjj7KI2ejdu7fNPOsMfx5nurcX6YY8k+O4VcguKu2tpHh3VEQ51e52ko7W1AuNstN7ay29Ubbc0KYG5fSea5OK7dtQvbn+BPNQxU81DFTzRkqeaBcRLFlByAYpByAY12RoAwAY8KDnZGtkaAMfd4eKD0eWUVbm2VbZVEQ5/nTFlajFvDPOkMVPFS9NELl6ibS2k80STgVW6Nm9DcvrKN+Sza9CmBuXqeahipRvyImRs3obl9J5rkq95Xkz/AMiqc/bltv3Rtbiakr1KW7SXwNIY0muKG5fRlcDVlcDwKGejOf4SXLUHo/rSBqGPBPNQx4Z4oFwiZjC5dCxaoli1SOd1fkoUxJu36tx8SJtLaSjfkRMjZvQ3L6SedtSiGl296G5ep5ot7YpSrmza9b5VFU5+vN9UC4l8qic3pbt6j8ilu3qGNJ50MHlcNRlbS/Fuiza/8Lu2/wBieahj6MxZWoxakuWqJtLdEz31bG19Rs3obl9JPO2mKaQxog5Y+gju+Lc4RTCrmi3tGHIonOkMfVnmgXE/lQK2JFm1BdtX6aQxpPGhg80o3qD6++q8t21v78tt+69vi3MEh+V4VeFRtbjxTfVQLFNrcuOIYplZtoq5FMNvVMULvUNm9DcvpOKtzbLRlu+Ra3FTzV21qRM0KYVc6clKuaVc0KYu1drfKt8q3yrfKt8q3yrfKt8q3yrfKt8qu1dq7a2sL25m+uie3b2VFU5qb60G5fzyOLm+NEv8Vc6Ekwqt37GM/wB2UtuoXbUiNtRsXol6Ym0t4J8dxzJrbEORHFSUlxoiZlCxcYoXqHyqPupRvyQxU9vVvlRg0ltv3SPZQn7Rtbip5o225Y8Xi39x2/s29aWkH1W3rULtqhip5oFwYKnx3CrmjB9AAwy2y0vxbps2v9Fimf8AwMtt+d0XLb1qYNZ50GzeoY65vrSGNJ51IqXqGNZnuoNzpnt6tym1ibS2ktv7EVLlDZvQ3L6TG9y4vcR3fFEySTBt9xtbieaBcImfMC4iIczzox2/KVr8VG1uJ50ja3FTzqYP/TTz4QXkiIc6z57REzoKYMHRKVuCJzelu3owVN9abZWqJYt1THNRVOeiW39ukUwNy/RKN+St8qMFSB5bNr1vlVxO63+a922m1+ETP/50kfRFcbJVslWyVbJVslWyVEQ+UbW4qckbCrkFxEQ5nnQFxP5aBdtQWLVPPREsfTvGPGqI2ehEbPi7dv8ACltv3bwx+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SvyV+SmS+CGOmUrcEMazzrFU51mLi1zYxNpap50BcGDzyjfks2v0jZvQ3L6z57REzUZbS1Rdxepbb91r/EJmHHfKO1tpeRQj8rRkcImd8qJvsbl+mckbG6VXk1aTURDnSe3QFxP5aQxpPPQF231EuWqNo9ul+LdOc/TROH7E8/xIY6Z8dwq5GzeoY1nnQbN6hjSUrcFbktQjj/p60iIc6TkjY3yrfKoqnOv/T1UPj1zz1Xb3obl9ZxVuab5VFU50nJGxvlSrnTfKpSEseGGNZStwVEu1H3U86QxpPNcbfs3jHihHH22S5+rPP8AChjrm+tRTBg0njWGNJ5owazfVAuDBU+O4u3vSq3dBs3qUt1DZvQ3L1J521Zg3qKJc6pbf26hs3obl9Zbb9yeyhTEVS7U86lvco7emGPBKVuCgu2qGKnnSGNZ56TB9VLlqHY7ZeFvl8F21vvzz/BRMwx1SUlx0Qbmsz3rG67mi6EaTttRK0bFQ+VR91N9eAbN6G5ep89pzFoxfwT57REz0x227i1uNJRvyVdtajbbmNrcVKO7mmCYRMlvbB9MU6BTEVTnWeNdkqiIczzUMdMgy6x3PEfrW5vQjj7IDntrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtqQDVirFMW1/tguNkq2SrbKrB842tx1zirc2SrZKtkq2SrZKjBrOKvFm9quw4qHyqLylCJcnnSIhzPFWbX6m3rSGNJ89pzFrfExvK3lbyt5W8reVvK3lMopbqFMDcv0Sjfk1v/pa3FTzQpiKpzIHl1LeyUTgZRc3t8VXNRHII4m+qC7agsW6J7ekLFvrZzW20rnixnS7a3355+7DH2Z51iRY3VXILgwVPPjG5fSfPaImfoCmBuX6JRvya75UYKk87akbW1Wtmi1+5inVslRgqedBTEL25qRzupkvUz/ze1va3tb2t7W9re1va3tb2t7W9re1va3tb2t7W9on/ojjoC2Nxe1EkwyXP0eXj684q3Nkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKoiFn6886Sbt6h8qj7qeNIY0njSJdpHl0C7amH+dI3L6T57REz9EUxFU51lG/J0CmFXILjbKkTNG23Nr/GWCu6xaF7czzrGN9Z5+3B9UF2x0SOLg3L+G7a3Wqt3/wADPNBYt4ZNpXHmOn6aQxpN4tpEQ5WxemS0F21QxpPNQxpIFt0jZvQ3L6Sjfk+mKY3yqKpzpKN+ToGzeou4vpPOopjdKlXNWbXrsqFrcVPP3YYpkuei8Y8f+Rnm9Qx4p89oiRswxTh0gWNJ5qHyqPupvrQbN6FMb5VFU50nx3CrnUt7ja3Gko35PqxtbjSTztphxx0CmLt71Ju3oFwiZhipMiVhgetn6UwsXowaSirc2y6wXG2VbZVtlW2VbZVtlW2VbZVtlW2VbZVtlW2VbZVtlW2VbZVtlW2VbZVZEHqAMaN8viFG4qt3+/PjuOZNBYt4pyRsKuf0rduiujcChuXqeKh8qj7qedbNr0F21QxrJ520xTqhjWQsuPq3u3kI8mknnbTD/OiIhyg52xOakjFt0yltbVF3F+ib66DB9tvlraDuIu4vrnP/AIefHcb5Uq5gWPFIt3ES7Uoq3ETM8VH5UfPSeahjSedYY6pPO2pR2tuqGNZAtvr3u3kI8mknnbTD/LN7VDFSltr8lM30q56xTH5KvN5OgwfYGzc6bxjx5Mc/3550IPvwz47jmTQESo/7U+UKkBG1R+VfvpPNQxpPOsMdc+e0RM9EMdEgW32IqnPTPPQYoipegu2pLNq5t20iZ1EtZQMAuNkq2RrZGtkaAMWlTC9bZGLTq06tOti5ibS3k/fQu8GjJc6R9+Gza/8Afnx3CrmoY8c86QxUpW4Bs3qTeN9Jeqhip4oyafvrD5VH30z57REz1Qx0TPfhBcbJVslWyVEH3tiZtCiMXGwoALHTLb+1W7b1EQ5nJGwq5qMRLsLW41nmoY1lG/JslTFOiO79XfV51edXnV51edXnV51edXnV51edXnXfXfRf3Uqv/tijyO6/Bf3V21v/AAbIOGUr8FAuDB4pvrSGKnjV+BUPlTlqGKnnQwaTzoZOufPaImemGOickbCrkI25IxcABY+jKW1tW6Lm8Kja3EiV7xVeXSIBxU86RbRu0tqAMTvfnSGNJZ6bl7fZvzbrJWWP/g57emGPFP8A+A3vJVbsMVPOqJHmHypy0YKnmoY1nnUwdEtt+68K3hhkvSYOmQLbQUbkbW4+lJ520w/yoHupNzjS1/iYKnmokU5AjyiOC/tv6L+6tBbDb3K1+IY0kDy0ZNGIt3u3fYQSyIlzySSwH9qfHcKudTB4p40l6qGNJ50iIczzUMVKO6oli1TfVQ+VR91O3QKYVc+FEzDHRLbfuvb4quahjrZBwsoubwreGGb63yrfKt8qu9IK2IxL1EsWqeau2tQLgwVPNQxTEW6SHGgTOAv71lt/Zt6hjSQPLXdt1AMfXtzem9uP/Bzz1x7Y3VVu+KGNZvrQFwYKnmofKhCTdw6W4vUPlUfdTx4gXGyVbJVDHVPPREQ5qZ7+nDFOXQFwbjhLW4nmox3aKGd8aEcKGd8aEcUyDh3lStfiGNZ567trfXkSZXBHHk7dv9SUrdcRDmb68cRDmReVtJ41iqczzrLmxQWLVPOkPlUfek80RUudcMeCZ76Au2oLFtHudoxTpBcbJVslWyVEH3tiZtCrQojFwAFip3XbX/PGs86Rtbjpd1+C/um/o30X935tTAcInDDGsvmeC7a31+YnZF3F/BtU3f1pS2tqZvpVzqRXGyVREOZ8dwq58UvVEkLEL25m+tAu2qGNP30JA8IS5oAxM96BYt0TzQLjZKiD7Cxbwzx0AuNkqiIc6IOVIcEXcX8rIOGUr8FQxU81DFTxqNm9Qx0SFbm2VImdAXERDnolu/Xpbe+b9vg2kuRg+tkqRM9Apje1vaJ/7vKJDQjjSxe9EhxosbFugYkbdXdt6VVu/RnJGxvlW+Vb5VvlW+Vb5VvlW+Vb5VvlW+Vb5VvlW+Vb5VvlW+Vb5VvlW+Vb5VvlW+VKuekwazfXku2tUPlW61zUUwYNH5lXbWqGKlLbxRi9T57RinKKY3yoweCW2/deFXt8d8qu9cMaz47jdKt0qiqc/vQpjfKt8q3yq8mu+m/sFxZrZKtkq2SpEzpDFTzUMaTz0RnYsxdxfSfHcb5UYOieKFMMl4fDKjwfvog5R/Uv76JxVubZVtlSWzoNy9bu3bpYverlXPMxTn6s8/cC7agsW1lK3iu2tQXbVDFSirciIczxrYHuJhwGL1POkPlThqGNP+nqmKF+kkmLvjBcREOded3Lt2039guIiHNTkjYVc1DHSyDh3lMoubwplbiILhEzpL1Rf9YXtzUo35LcX+jHJqoZup2o+wDHTcvbouXt0IXurBzsjWyNMU+Np0X99ci5atsvoIjZ0s2vTJc2bX808/ahjpS5bxSUlxUMVPNQxpPPRE43VF3F6nmpFm2kMVPNQxoxHlkWjY8ALjZKtkqIh8tg4ibS3TKW1tW89ybtwFxEQ5ltv3NvWqJkipcVc+CN7csb8xRMguFlHiryab+y/rdKrwpt6Le+yuym3rxFr8oEi2jb3aL40HIBjoQcsP8AC9uelByAY8121vszz9mIhz1R9+CeNTBU81DFTzVm1+jfYsQvblO+pFjSLxtqUdrbSMRLoBiUdzeom0tUkw7JURD5WhUbW40lHc3rbIxa/wAtka2Rq0St0a3xrfGmQliIhzpPjuLumyVImQXCJkUxeTTf3Qntt6FMXau0396mTpnn6g3L6oOdre9F/ekt367pHDvb1+Soy3ao+rSov76JHO6vyVF3F/5s8/Vjt/a0K2DiJtLdUpbW1RdxfwzzQXbVDFTfVRjblG96nnpBcTxpa0U0FG4Ny9TzUd1u0knErxlxXadr2XpBzsjWyNWiVeJTMMM/83tXm8iTc7ZVYHuha3FS3fqszJIfleFEomFVu9Y2b0Ny9T29JFS5qC4MHRPP1TBUjndUZX5RHGkt36l/es86RJW47yi/vqb+iS43ReKsfwGX+iOPFPP1YY+lP5aGTSeahip56t8qVcy9VH4PRFuX1nmgXBG3LebyS3X5BcWB7oWtx4JRvyeeKpzPbqC4m+uiGOmeb/VMHRLd+oy93lTIMiONJ7r8XkVB7qlNG1b5NEkbrM9Ez3vjQjii/tTCiZjLaWr8lEz2I40lLb9Dt2+JBztb3ov70ZSSzpKO5vW2Ri06tOpXvz9FEzUMdct367VbyLeuudqRM0F21QxT3O0IhQjieetucMW5Vy9qYiWrbKkTOnfW2TyxELPnnz2iJnzGCp89pZvauQvSrnQLtqCxbonx3Crn6gpiKpz47c3rZGgDEhXhEyKYiqc1KW1tRM9iONkaAMTFeETIpiKpzKW1tRJW9COFDP8AdYi31j78EjndTJdIY0e52hA96zzV9SKlyofGpS2tq3lM31FU5qckbCrnSHyqPvzz57REz5YYqfHcKudQu2qGOifHcKufsCnBFU58ChkRxSDlgeom0tU86CmIqnNS3fre3y4kVsjQBiYrwiZFMMlLI3L/AEbNr9e1Td5G3vbGgDH1v3pbF9IY8U86QxpOSNgm+4u4v0TzrHb+zb1EsVPOguCIhz+/8UFwAYnnWIhz0Tz9wUwI/IIONka2RrZGtka2RrZGtkaAMaIOdka2RrYUw/xEbMdtu4IONkaAMUg52Rq3qthREG59Ht2+FEbOibuaL++pUavFpvbtL+/oIOdka2RpSJYtKXNEG/OyNbI1sjWyNJAyofBVyXe2v+eKnjXvowVPNQxU89UizbQFwyDiOkTjdUXcXqb6/iREOdZ89pEQ56J5++KchP8A0RLms8USTgJ/6IlzrYjysP8AN0jhJnsRx/E7t3hVvYYSaiWLPl/fTeWvRNqLuL6SltbVvlW9rfKlXOl21qBeCHxqeekUxDGs31qvFigXF7FxVzQXbVDFT47hVz/DZvpVz0RVOdJ5/hkk4CZ7EcTx0Ek4CZ7EcdbEeVh/m6Rwk/8AREufU7dvjYpzpZtfxN/Rf3SDkAx1Sjub1tkYtOontUMyReKhjWedAXERDmp5qGKnFW5aRW6VKuQVsNr8aQxrPOkMVKVuCgXBgqb61iIc1PP8wUwq5/i2bXpVz1RltLVGQ58DEeVh/l2HFE/9/JH+SoZEcaNvZb1pKQPN4uY2txShm5W4vbpnx3FpS5owdEpW4NIYqedAu26IY6pvrQiuDBU31rEQ5qef4uyVMbNiUdtQLHRLbfubeuTj+gKYJvuMhz4GI8uw+kxTP2nDpDHRM99BFeSIxLOktt+5TBDHRPjuAZNStfiGKlK3BpEQ5nnSza9Eh+V7fG0pc0Fi1Pa7hkukMaT47hVzW1DcxdxfWfHcKuf4JFcREOfBMFrujUMaTz9YweWeeoUxFU56VDNz+LZtfxoOQDHgnnWGNZRVuH/Na7Kha3Gs5I2FXN4VeFRtbicVblCmFXILhEyEfdr/ABiIcy237l9FBdtUMaT267UNzF3F9Z8dwq5/gArYtf4xEOfFPntLSjzSifXMHlnnwimIqnPSoZuaoOdkfu2bX87OQ1vai3LuslJcUC4CJ8i1uNJbv1ZSMxbl3WUrcFR2/sxu9uyVEkLUKYq0KbegXERDmp8dwq50LX5AOCW39r8W1ja3GsjndTJf4URDnpnJGxulW+Vb5VFU56Jnv65g8s8+QUwTfcXcX6VDIjj+Qg5AMU4dYY0nJGwq51iqc+CUraC2sImSSFqu2toiZunGrYLx3ypVzrC9uZbb9y+jW8moiHOk+O4ZKWf4AK2I2txrPPhhjont+sYPLPPnFMEh+UbW4+8icPi/foEcdEtt+5t66C1+RHk1Wxeo/wC6StVpNWB7lHGgFrqjio2txKW1tTN9KuaBcEH3E2lqnx3Crno2Sowaz47hVz/BiWLdE314iScUq5hjWUb/AFTB5Z5+kKYJD8o2tx9bcht8hJMKrdr99JS2tqZvqN7c9Utt+61/ixQu6lr8iPJpOSNgkPyvE+Krnou2tW2VREOZyRsbpaguIiHNS237r2+KrnWze1BYt0T2/wAOJYtrKVuDoC7bQB7Rg+pWtz0xbms+e0RM/S2lrVsjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1KNuT+ug5AMUoZZCWIiHPhme+kbN6G5epSt0omdxEtHlasD3XiHHRDFT47i71AuCIfKNrcayQ4btrfw4iHOk8dIXbUFi3TPntETKcXOiGNJ89oxTP3p4/syltbVF3F/LKVuDphip51NtuW3oFxEQ5ltv3O23FAuNkqMGk+O4Vc67JURD5RtbjxS2/t98bl9Zbf21BeBEzDHXO/QW9xtbjWeaEtZiAceWXzPNP41DH8FVbv8SeekW96Z/wCVtlU/lUMaT47i7pslWyVGCp8dxvlV3piIc+OW39r8W++C4MHRN9ahdtUMeGTztpinTDHRM90STBg8r8jzT+NGD76q3fGq8P2546Au2qX+UxQuquYYqfHcKuaILnZbmou4vU5I2N8qVc0QXO2Jm0Kja3Hjkhw3bW/gxEOdZvroiIc+OeegkmIqnOso3oWLQjjxvyPNP40YP/DS237m3rou2tQLhNpeKrnSzXI0T/1kvQC4s0Fbb5iWOPBLbfuvb4sl/ggrYja3Gs310REOfLPb0xVOdZ89oiZh8fHI53Vuk4vOrzq86vOrzq86vOrzq86vOrzq86L+/rKrd/nzx0922gXF7FxVzpEQ5nx3CrnohjxS237r2+Krn+GCtiNrcazfXREQ588+e0RM6xVLvRMc0TTJi/8Aa7dv8SedQXEnBTeINKudIx3F6TZyb5Uq56I2txpPjuCb7ZvrfKrv8kFbEbW41lK3BrtQ3MXcX+jPntGKF3ohjokC2oUwYP56hnfGhHGtuL+O7a32Z8dxvlW+VMlLOm1telXMMVPOsbW4qeeiIhz0zirc2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkq2SrZKtkqRM1DHRPPTFU5+lPPTDHTIWXA2b0Ny/1UHOyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sjWyNbI1sj/OnnpRM1E43UyXQLtqCxbSe3UFwYP6U80C4MHRKVuDULtqhj6c+e0RM6jZvQ3L9Mo30iqc/zbNr63bW6Lx220EcfbZBw7yt5TP/ADWwPcCtgNzagsWqb60BcGDSb61BcGD+lN9UF21Qx0Slbg1C7aoY+rPntGKF3oiqXeifPaImd8qiqc/y7trde/mxa/yAMfannrI34ADg0Y7pabUNzF3F6e13DJdSD7/ozzoCtiNrcazz0xEOfrzPfSSTEVTnome6GzehuX/ksUz12v8AIAx9tw9QXbVaRwEonAI40m8WqGNJ8dwq50iIc/0Z50BWxG1uNZStwdERDn7M9vSNm9Dcv0yjfkqHx/j3bW6Vtykhx9qUtravyV+SvyV+SmS9IIl9ZSRsKuQu2oxbSUrcGsbW4/ozzoCtiNrcaylbg6IiHP2589oiZ6Iql3oe52jFKu3vQ3L/AMlkDZYi3+5PPhja3Gs89EMaTPfQX9GD+jPOkMdM89IpiF7c/anxK4q56YY6p50ACx/HAMfcnnrBcGDSckbCrnohjSe3piIc/wBCedAXBg6J56oiHP25PO2mKdcMdMnnbTFKipSEqBCz/wCCnnqiIc1KSNhVzqCtim3qGKm+ugFwYP6M86AuDB0Tz1REOfvT29cVS70fvTyWrvCoyvwgGP8AwM89AXbUFi1TUeGSlnQipegXHy7aMWr96GzelXOpBcmLf0Z50BcGDonnq2obmLuL/wACfPaImeqGOlS9lgOIy21aMuaL+/7886guLyjxSrnQGPcxNpbpnnpja3H9Gb60BcGDonnq2obmLuL/AMOZ76iSYiqc9ChkSRW2RyRlfhYHoxb+9PNBdtTGJlRxpslQBjqnnUFwYP6U31oC4MHRPPVtQ3MXcX/iz29arkyabI1D46KXs7RLAsW1dsqiWLf3pyRsKudCC5MW8E89cRDn+bN9aguDB0Tz4dqG5i7i/wB6TztpiniVcmTRBzD46yBqQjyKNwn/AKwuWiX9/wBqb61C7agsW1nJGwq8qrnt26XbWqMbcvSF21BYt/Ont1BcGDonnwxHII4/gT2+ZgODFtO7dUoeyhTEZC2kxkfGHx/rWbX0VvYkI8xtbjSUrcBJC3gtaO7p2SowfzpvrUFwYOiefCC4MH8OfPaMULvgEsHSX96SIrZlG3Iq5jJjV4y4/rbrysh7eie3oBWw29WbX6ERs6xtbj+dN9akFyYt0Tz4QXBg/jT2+AwUyBt07I1D46yBqQjyKYiyc/0nNkv70s2vUpI2FXNImaLbWwLi5bbRB9yf1qza+gXbUqt2gXBg/nTzV21tdqG5i7i/RPPhBcGD+RPntGKF3pMFIOQDFy9ukv707t1bYuIiPNXlihHHm7t2tz7jL0jfABjXOfDKO5vUs26CC5MW/nTzV21tYiHPRPPh2obmLuL/AMue3pMGrEc3jHihHGqDmJYt4BHHkUM7+bFr/LZH66DkAxShnfzY2yfkAY6LbvkAY8E8/wBMFxN9dEbW46J5q7a39kwaMRyAYUMiOOhBzD49aN7g/wD9Ug5AMdW+NXkthjf5AGNP/8QAKREAAQIGAgIDAQADAQEAAAAAAQAxMEBBUFFgECARIXCh0cFhcYACsf/aAAgBAgEJPwDY2Xnx398PAxJ0+DH4E08RujrPHv4bHJ6HqOB1eSf4Rx/ZUc/2MJkdK7rntWFiaCPdpkdacvtVO2Lt7jvDPPvYsyeINffGLa3X1NNs1OHivbPafqPhEIeL37gjc8cZiNdGhe+z8CBXqHg17Y17OgNY69MazRYg04pxS6hHzBrH9xqzbX+n84rpwXuT92L/AD/JSttpCxf3m/ewZiUvL2L3tD840B5V+/vWn5zqnuO/f3w12azNZjOPCbvWYaC0OsdkfMi+1NE9TfqyPJPYM9PMsYZnnlG59yLpuWs4uHheF4XjT36v0d4dZJp9/gF+rvHrG9Gyta/C8TAQQQQQQQQQQtL9Ry/Z+jxjIGDW0NLYgtLFFFHv7tLxHmvUFuzzLr1bcQAhNhC3Py801pe309J+cdPUEIIIIIIS2LNWcbq3es69ir3xxjjNgfsOoQma9/cpi9Pam6MmRgnR6w8Xx16slYbdj28ryvK89/cnicCeJnvi/OvXRprHGYWea3gIRngNCxz/ABBBBBBBBBBBC5OntVJxr9jnOu40QzOdMafyqc405+oQ58989Agggggggh0p0fz2bRsx31Gmyt/jq4tBkwggggghDCbgLzaG0qketqeCegi/3YRJP2eE8tWUOkNpTWTFoPRowlwghc2jBV0ceV6hC5unuvjRgqzbxBMBBBBBBBBBBBC4PYa2poJRR5N//wBoooooooooooooooooooooooooooooooooo2h7YLDWJjUn6iRrqWeuIIhZ0Ok089mSe1Zkc7FXh557W7wSjApxnsNfeC8X/FoeHWXzf6dH2+snnpm6NCe3vLZtFdTfmiez1hPMhBBDubNmA3Gb/S3Z0PPNYGNEpdM9nm2tVNzb4Za2vFfuCPgNtMFsxzn4DpCEg1pxAx1zuWJF5Eooooooooooooooooooooooooooooo98800FtOfSW+QyjbWv76Di/No4iNesXdtJqm7Ny3Pvs+0NolJB+BCa2vyeX5PwIeXueJkIJrBTUGlH3AIXGkXGhU5ptDzNEIFYFU9lpONYm0ukR+1ezL33eezdW0GvAQsnuRKMQowcytODsbqsrnl4Tce+vu/tqgsbyPua9fBNLI699G5/qOgPYwgggggggggggggggggggggggggghoDyr/BWL7ns/whWVbRKwW1KnfMWu0Hwj9H8R+j+I/R/Efo/iP0fxH6P4j9H8R+j+I/R/Efo/iP0fxH6P4j9H8R+j+I/R/Efo/iP0fxH6P4ij9o/aPmeC9aD7iCI/xjWSp8CZgZ1qkJtUzxmO9x8/AeYGbXWN/uKEEEEEEEEEEEEEEEEEEEIddaz3zBrZK3Ou31hPN16iGN+r0zMvYh56NGKKKKKKMXEDMFtUx1x0zPlGwhBBBBBBBBBBBeF45Hlf8AlD/4vUdt1MqEIjdx5sudDeO6p2zIBCG8tXpmXbcsQac5T2AIIdT2pLt8A5uLX59WzZSijL+t4xAxw1gFuaxjs2oVjDkxsdvPIsg8oeIGOfUgY9dICr0zCMgyaOEO2Js+pQzrcNoNJczbQRz5Xm9Necy2eKwj1MUwhyUbEe4Q5KPaiGiFGVeyhCG9komie4IXtCwHQcQqT72cISglXhmAUUb75sr+b82h5gUm87k1sxYcbK0o8QwGs3mQp8EtCMfE+7fADw68NLFFP8A+r8PKHQ/Avr4Te6mytO+e4QgHo3V7w91Nha1GTp8UvJtfH17ErXh9RfXMS7zb23/fD/AL9z/wK29nudDrqdLDSBTuUdMfbxACPhFe9DeWogggggggggggghprcO2wVvT2iieTOnPoTfMtOz6+9wbluj/IvuyN8iNXZH1YIIIRaf8ARb6/WLXhvjh4mNSoqLHen/G9NAO6vqlNtrJPpT3h7m8enDdAj6+Qn5a8P1fQaXR5J700B+KfATdGkG5M4U0hTrTbHsvud9puw+FPUML30//EACgRAQABAgYDAQADAQEBAQAAAAERACECECAwMUBBUGASIjJRQmEDcf/aAAgBAwEBCAD0Rm6MCTFJDGRTmZtndBeMX9tk7JoKbbDU6Y+xM3QVi5MinJ0TaMjQ65XnQic4vHfnaNBpjeC00RN/nzN1lOgyGGaSGNwqZIoU4VeevfKbR0x8ZtFMeNc5rN9mGJq7zUfNmbsFOpyNu5fMzcjoRov0SI0FJHOUzzqY8bPjM+dM3dMncROTS9y+U6ptGcsRQLxonx0I+kM3fRG+k0MTbJjxRTRT2VXl0RtyvL0zFBBNTU/Qm4U6DMydDRTRqcjcN1IY6LHi8TU53qaY8aVYjXGc/PnTaMmjQUx4zM2jeNx6k1OpjxUfVGeH+1OyU5lSxGp1R/H9aHIzdo3nQbd9L0ZUh0mwVMv8khj5Ezw/2rFy9JzMmzoM3oHoFVl3TWx43BjhxYXljx8cZ4f7VH8op6BkallmjNyMn207o/6xNtM2imPGkU4HDF2PHxhnh/tTy0/7tFOUMToaPUPddM2jZMWKsX9tU2imPGmbRQ4Yux4+KM8P9qeWglinZKdTRTRlNopzMz0h2ZmotOc+NibRvzaKHDF2PHxBnh/tTy5OspyKcjiM3M9cdUU42P0pDFp1jHC/pnS7M2ihwxdjx8MZ4f7U8uRKQIjfcdAxfIz8aD050oYndlSG0axQti/tkC8InNOhE50TaPhzPD/anlzu22hi5qifZpFsgXj84qROepIl9MWnUbaJz8SZ4f7U8uh3isKv8amf7JFnUetFOGPC+OkZInOX8YpE52jbROfhzPD/AGp5dBKQIjfbdhoyO5Dz6c2TcNhwoS+k49AZ4f7U8ukF4dZrfSvpzvRafgzPD/anl1J51FPcncvpfQxqO/DE6FXn3gMTnh/tTy63fh5p+EPTwxPvzPD/AGp5dZKQIjfQDE01Oqan4YzN87Z7g3HSU7xvxUVFRUVFRUVHxNqtsRow/wBq5kETn2pm5TaNbpKdLHjN0lPQnK+U1PcOnK875tfpqWpalqWpau86Fm7o/eKI9sZug0uopopIY0mw0VFRUdmKjdio7ATb58qWIpE5dQoWxf2ydRTm6Tq3yioqMr+6NZm6T3Mb82imJtqm0ZOrBzWLnNEb7z6CNMVGp9E6TN6Crz66O6Vi8ZqvPVn3xfj0Srz8VhfzTuGh0znbQa3ojDPYOoU0ZnW559yic7weDWaTJ0mV8o67pcynM6F6v2isXjYtVqtVqtVqtVqtVqtVveFWinqEthE0lRacmjtPNtEe1csPOh+HKSOdBTulOQMTtNHecjuX7bQo2RGH41zm0ZOyVFpoif5ORTnP8Y2XIzO2enOgDE6eOPh5/wBi06RtGaQw6SmPDmU5mgYvoe4U0KcP/mw+inZY8aCoYnr4S80ss+xNJSRzpwx5xGHxRTDxRE3dKJzm7j2CnIp6kVGV6vV6vV6vlFRUVFRUaozvn+XYOk5BNjIJYrEQB7I3RThvWGPLqwwMuJlnR/8APnKNs1PTKcin1V8p0ilKvOg6LrfYmybrHjsPVmGdBk+pliKCWNR0gm1JDGq5f2RtDGUWnJ1rLPZOoMM6P/1ibdIF4j/dAHmDxpt5Y8bM2iptFRacsXjUaY6Jh/j+tdqtVvVG2ic6DUx42TQainrtGTpNyLTm7Ds31XLkszk0MXpZZ1ORo/52jCvGL+hpBeMX9sn2JmiN9iOqLEUx4cinSdkzBeETnOc50QxNRU2jskeWPGpV5aNEaJiv0xG2zGkaZ81FRUVFRUVFRUVFRUemM3Ze3E6ntFO14pVb6fzhOWBtU1+mv01+mv01+mv01+mpmlXmiPI4KY8UYk4WedB6AFsRaejarVarVarVarVarVarVarVarVarVarVarVarVarVarVarVarVarZJFsnUapjqGydbDy+vKm0bBSIw7/wDxrliPZmbpACcWL/zRxz1Z0lOyb5TRqMsJGK5hXiwRTpY8PUKRGGsP5/6Y8aItOo27bGJ/TOuE5okJFXn15m5lMeHZFOGPHUdDsm8ZhLGkydSJznFRUdA2oYnZNvEfljM2AXjF/bKWI9iDE0qt8zJ0ulPNHZOvg5a86XTGaJzkUGHz/GptFPSmv01LUtfpqWpal2YtOhV5dM6hhkxIsmucPtwIlxf+ZlXw3pVZaNNopo7ssRsO2ZH9NlE5cgUti/tQwzWJXn0Zpdsp98U3dLHjIjz/ABqcFTgqcFTgqcFLhiBoU4S0nSMkTaN0yMhIhY8ahApoF4ROZa/TTfamp6kZNEv8dCrzm6hTj5f+MdMoib9YzxeMj++vlqGJpZ59O63baBePkZYjuGh2jLCXmlm+X/z5rD+f+mPCIw5mFaxcud6vV6vqnuGTRqjzs4eSsRDHvjrHVdEWnM1pDCaDUaMXJRkMM0631Jldtman2Fo9KKcJaTpsTbI0G2aGPDRmqtz2opWDmk87CSlJDD7qLTTzb1ZsnRczJo1OR6Vo3TKGJpzGLntTOGJp7JEdOWIp6wTY0tGl9Q9GFbe7e2f5SJz2DfaKcKXfXOw7RiQti/tk/LnWMzRHTliPUuz4mlXnafcGb3Z6JUMTmU5Gs3SfzkEsUiMOzNTU1NTU1NTU1NTU1NTU1NTU1NTU1NTU1NTU1NTU1OTRoPhzN75/lInO9NozKcjrSxHqimjUEsfCmb6A3ynbNBiTKWI2ItNKvILwic+oMnSbKJz7wzfQm6ZOoyczRLEaS3C/7oWeRThV59QVi8acXJRlx8IZvojcN0zBeKROdbZ9aZedDRqtGpV5ym0e3M30ZtlObt2/NDDOgymSNEsR60zMsHNPSm0e1M31wKwYom3wppY8Z26DcjNjx7AzfSmwSfy0O4bhSJ6spo7dqt68zfTkeQG2QSxRE3GGafSHpCmimjI3Zhn3c4anD7oyaNJtixFOozj0cNP2LsFOyaFVlyjqNqO8ZEh+tLkdBv6i8e4KemKcaDff91onOp6psOR0BSlW7sy1zz8ver7hkKMlNRaesehDzlNoyOdB01Xm/wA+X43hTjbegVDE920ZInNNGsJY+vm0aDN1lRaaVW9GhzO4dM1QnOZo44l7fHEtS1LUtS/CGyMM0ss9o7EZSxFMeNF+gC8ZwxNKt2j46KioqKioqKioqKioqKioqKioqKioqKioqKio2BTh1OYTbY/9yGL+inSYV4RLaInhtqMK8QD/ACmP6rLLqJD9Cq3opE5+LPSN3Yc5XnJyCWNBrAm+g2DpRrliNOH8/wDTHgTyxNs1VlyMnIpwoS/FnoYYmlVvqNQwzSIw05Gg1SxGSrz1ESzqRMilXmGJzFOFXnJ2VVlpyY8OYMTTiUh+LPQ3wtO9LEaY80qsug1KvNLPPdMSVM3USp2ipYjQUto+RBePzir84q/OKvzir84q/OKvzir84q/OKvzir84q/OKvzir84q/OKvzir84q/OKvzir84q/OKvzir84q/OKvzipwoS5ief8A86M/7Q3nQZlOFOdh0xUVFRUVFRUdM3z/AH5A7r2TK/Ok2v7EVEW9Gic7BWLxtxUVFRUVFRUVFRUVFRUVFRUVFRUaETmrxPUGGfaT47BpMnI1Tp/sRURbqTaN2Wv05IjDDzpMpYjQdt+ZN5VZWlXk0FmabcuRTrWefRmf4xUkc6jKWI7b8uU7YSwNQjfMzKQiTbS0jfnuTtOU6v1aNarzOGpw1OGpw1OGpw1OGpw1OGpw1OGpw1OGpw1OGpw1OGpw1OGpw1MkfThLajM0uwMM5Penpn3eHman/aKb14yKcjN3FXl785NH+1FRTHjYi0+rVefgzKd4YvRzTHjIpyM3dYm3oSptHYtVqt9C7Zk0C8c2qIYzaOkMM5Og3ZyvlPTw4ZJG3OqWI0Wq1Wq1Wq1Wq1Wq1Wq31Bk0VLEZeciT+VNGg6GKJt276P8AnQbL6Blu/HO0ZtGspzNi+kjzFp7s5PE0EsUx+bZlX5pV2WJt9Wic7Rm5QnORTmZm+z5dh2b5RtzRU2jMqFbK8bbuS1LUtS1LUvyZ02r8ZQxOjCTbQEsaDddRqOm6gm23GTmdHnjVxx8ebgxcopnzkUqsqrzkaShTjLD+f+mPGbsGcMTvTler6XM3LaDim/Pc543rnto0pHPRM3TfzRqM5jhvsm1Ck9Fopopnzk6Bjj9OSJzUtLLLvvOqc8P5/wCmPGcVFRUb6Jz7iGJ0G5FpzYm2jxk9C+06DCvDhjnOKjQB5Ym2topyKi07h3zEnCzyfmLsePUnrGrRORqNDkdkjyxNtE2inVGV9bHjP+MdESL9i21+n0Z2khh6DWAvKss5GozaKeuic60TnfCeIjnO/p521Xnd456x6g0BaaaKRLOvF4zMKk0yMOq/akS++dybRR+fLh8EbkeuOtfpQnNNGZWLxpM4YnMpibVDE5X0gvCJyB5g8UYk4WedV+kic6wYmnEpD3jiMm1m2XHGXHOhlu965zunUGGaWWelgCZpV5yKaK/52VVltGkzY8CnCzz3yzOh0npDCvCRZio2IqPUWq3TWb5PRMptGToMjEhAz5083yMScTN34YwqSb4pwq80kMZxom0ZRPx8WnJznQR5/f8AjPnTFR6Z/wB1vdI84iHenI2ptHfuc+jJD9Cq32TJziX+OgoU4Vecz1ZsAvDhQl7RhXhEtvzU7U1i5PhTCtOFC9NFM+cysTPBkJ5Y8bR649BGkyjanKNXPHuww+VlnNI5jPD+f+mPGZqczafTRslInMsR6KMjTG1OUeu8blskTnJzNJTqBbZQxNKrfIyaMK8TaMzSC8Yv7fKYfz/0x435yio+EtFNfliacSkNArAx4hiaVW+mI5zwxN9B6+WZ9hG3Pr3QZKvOSRzodRYmnnKbRmC8MeNh9Wx43HI9GdLnjrqvPdKCWMnRzbMDzXPGVyr7788fBR1WTnRfNZZ91Fp2D0hux6gYZ3TEhFOtIYdxI5m0ZpHPuShThV51Ijf0x8rb86LfnRGifZm1Jitip9Kevu888QhLtxaabu6q87izz7kF4Y8ap1CnDE2+qN5jxqfalTaOi6FXnunxrR8S6zRFppvzmd99Tzz3DSEsVGh+ANDvP5izoPjOeewbDu39mFp6BoWeffXOJfXf+0s86o90dZV56dqtVqtVqtVqtVqtVqt3LRptHpzpPtTsSxFR50ns1Xn1h1YqPi2PD9O0aT27oOwaX3do1889w1RaabW94bb2FXn5uKio0ohKq3aNJ7YydMsRoe1LEVHn5g6c+yNZUsR3DS/nxpMkSz6bjnZcS+pKfcGsF4W0HolXlIs/HxUVFR8KawXhbQekm0VHn1qrzrY8dg3QtOhyPbGTpPUMzfSenROe+dB9waz1Nop1mGST4Q2AmptGto9saz1arzHnUKcT+rUic/BGoFJ+ANZ65/MWdSrzBE/BG8e3NZ6o1LPOoUbSYiMX5eSffm8e2NZ7pVZbR8ae1Ngq0eyWb6zEnGSJ702CS5kSfyoJbe9Pakefi5YjVFp9qbB7hV51yvJc/I4U5+5Ng+CMSce6i07E+2Nk97aNgU4WeftDZPeonNXiPiT3pRIfoVefmv/EACURAAEDAgYCAwEAAAAAAAAAAAEAMXBRgCBAQVBgkCGgETDBEP/aAAgBAwEJPwDadZGpnKXZP6v/AJ+8SOJHEjiMHkF+cMvPDn9MasbFFFFFHqjpfjTiD81p+9NGkSjo8KOVpKFZQaEivP8ATgKMS04TWCHt+pkivnKlFFFFFHYhwV90rBnygggghvj4CjBL7dSRNJMpy94VpY6/T83T5TDS0x7AqftnDw2EOdaXTm2Z5SOcKKKKPQ4LgHgETW+3Uhh9iKN0AQQQQQQQQQQQQQQQQQQQso06iq3SlFFFFGyt+GmPjgOR8Q2ZUfIi0Kmyvt3nlVI90x1+p5Ge/KnEh0hPIjx+elJ8D+jIZGfpOf1L3+h5GeR3kdrUX9PX/9k=);
                --savepage-url-6: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAABECAYAAABph6DRAAAKE0lEQVR42u3ba1BU5x3HcbkI3iEaqUFFYkzVNo0krTiiMURb21JjJTeq1EaaSSuOFFLtNampRh2TJpa02qioldbOtEaNxUpCA4KX1OpogqjUC0STiCbjBfECii5Pvy8eZ545c3b57+HsQjv7zHwGePa5nfNjzz57FjotHJCR2EZ90aNTkApz9cZ3sAy7cBrNUFoTPkQpXsa30V04dpzgePu7fDzRkvNMwwzlkss4iAI8ikgXDyYcadiGm1B+asJf8VAr87wkGOsGYlw8tpmCOQ/ooAKiBlNcOJBxOADlkjIkeZlrGJTAdBeDKhPMN0cHFVB/Q3eHl4R8qAC4iecRYTPvB4L+W10K6XPwQPnQgngdVMDtRTc/X4d2QQXYRnS1zP0zYdC9XQgqRzDX9tuNVZD8Rbj4GByECpJ3EGXMnwAl8IwLQUl+GZ8NalBaaisLj8QOqCBbY1nHbknAbQwpHi2Cjcsd0qDK8DJ+gTxtDhZgLQ7AAyXwViuLXwjlp5MowjoUogwXoPyUaaxjlvTyF+DL3hbdXBTUDMGkg7BeuE2O9DLGCNyCdDOwHMN8bOdTsRVK6CJ66/5xwrU8E+DL3lMOghJNvlkw3lAvfcuhBGqR5Mea0tEAJZBv9CsWtH/XYUgJgsteA7oGKqjxgvEetuk3BkrgOPo6ODHJuCoY/xr66D5PCdp7EOdgPXMEY6/SzQMS1N1ONhTUbRT0a8TwNlxqpkEJ/NR4H3dR0D7HwVokb+BTAhnUSMF4X7LZjt8Q9HvRhe1wqeR2jdF+maD9bj/XMEQw5gmEBTKopYLrbmdLnwzBGq4gxoWgUqEE+uv2X4ESSPBjDb8SjPeC0cXVXV8YsgTb9NU2fZcL1rDWxXtrtdLdlm5/WHS5lM9fLbhllOAkqLlItBiCkXgMC4UHcxkJNvPvE/R93JWU5JezJUb7uYL27wvnvl8wVqm3zioIPN7upAvfnPZzMahMwXwbjPb9hO+phgvmfkUwznfbK6jLmOxl7u6C/g1uhSR93cFeS58iQZ9Fgs/U6gSvxd3aK6hshHmZu7+g/4cuBzVYMOcRS5/HhLeywnzMO0H6Wtyel76DGG0z9z2S7bLLQd0hmPOUpU9nfCroN9bHvOsE/VPaNSitBXP+F4PS/RYL+q3wMmc3XIHyobK1hasgm27MPVDQvrYdLn3VXm48twhu7EY5vCuS3dagtuDXFguQjwKUoR5K6AJ66Ll7dNDNxD4vfbcJ+k6x6Vcs2ET0NPsE6g1vBB5BGZTAbKPvJUH7OFdSkv92b/TS91FB3802HxB65JdM+xION4oH5fgqVgraP2l8f1LQPgXC4nwswZqK8TF8lUmc+DuNn7ME51kHFeBnlPWFU/CRwlWE6/arBGtY7dKzKQwnBfNNbeO9ulxjvhooH/booYMblB7zbendBr5mSV6n0NOFoCZACST6GKOf4I9AD+m2j0jOb3sG9WfpyeBrHDySO8ouBFUhmOeQYJxNkvdUWC/YJXZtt6CEm4oEPz8nasTQNoSUBSXwgkvPzG24Lv3ovz1eo2JxTXCTNlq4mzIddfhR/Bg0CsZvRrzwte6YCzcAPt8uQdE2Em8Kxjxuc8PyMJRADZL8uVsuCUlb48e4s6DaoFgwjevvo6LxBPZDCfzBZoyJUEK3sNJbYNRHIQ3boYSuIt6P89YD9VAOTXQ7qN14DfOQZ5iPVdiJRihIJXtZSyGUn86iFBvwFvbgKpSfch1cUl+FcqAaYQ6CCqriVn5Lq6GCbCvCHASVCA+Un2bqITpsUBeR0Mp6BuA0VEf8TxOHf+pmOo9uHTmoBowSrmlQkJ5Z5Yhp43uzZChIveR0IhUEVRjm57pisB4qQF41PpII+L/PaE3o2xGDOo1cRLbhJExCtcuXujHiBcjXqARWtGWSf+AjKJecxZ8wGZ1dOhERmIKSNvyz9UaMF2waHN3sFf693r1uTBaDUXgcs7EI+ViHDdhiYw1+g1xM9rpRcP+j9CexFKWowSXcRBPqUY1tWIRJ6BaEdQ1Akg/DO4VKqIRKqIRKqIRKqIRKqITK/0Vhfz8jpOMjqIx1IR1f6JISKqESKqESKqESKqESKi6VyOjoCEzCCBfHjEI68vA04gK09geRbvw8Fl9vj5PYB0lIRTIGIczlOWKhkOfSeN1RBYVzaMIE4/FwJCLOxxj9MEgwVwUqjZ9PYUt7BKVsnEZmBw4qGwoZ+ufOiLS0OYEzCDfrjfbn8V6gg6LtYpTY1P8Rm/0Nai3uwmCk4zA8SOqgQb2BJoT5aDMfCqk2j30DCtlBCGoLKm3qK1Hhb1D5lrpU80D42hM/wu9QgOcQY7S/D9lYiHwswP2+guL7h5GH/jZrCkcGlus5v2V5fB2akGeItrQZBoUVNuMX4ibuRC/k6nlW4Tn0kgal6+7FfKzGXMRagqpDnpZtBFVj1Gca53I+VuL3SPcVVB4U0ozXsTMoxw54cBhRtxdj1P0bl+HBN+2C4utDaMJqhFnmjsQ7UHgfh6BQaAmqBacMvWwC2YsL6GzURaMBRfrngajDduxECz5AhCQovk/DDXyEd9GIGsQa56bZWGeVEdR1o75Y1+fgEEpwDAov6qBYGGFhGbbDgwKEe3kWzoTCeGMxpyzPoDrstgaFB9GATYiwGTsXCt836p6HwhNGUJfMfq2sM82oS4dCupc+OVBIaS0ovnbBp3gP0cauUOHnDi991itLOeo6GZuHCuwwUtyHIZaOA5CE0VD4nhmUzeXlM0tQa3AORYjysrg9qLF58W/Am34GFYNGbDLqtuKc5VkWhoFIwjgoTBUENREKs5BoOI2tToOiPgpDcR8WQnm79I1Ag/GMSMEJKIsZPoLKhzKDMkzycXI/QbFN/WHsEwZl3V01Iw7xuIVXjMfH4aTdsQmCyoLyosJJUPrqcQ3KYB+U7lCEev19LY5hJGIx2mFQS7APzZjg5cQexR6b+o9R6iCoZCjMwS+hMMR4vA6H8ABikQJpUFOh8DQSLfoZ5+aIzboOoMJSNwoKK5CAWCz29YyKwSc4Zmw4XjceT3QYVB5isB8NGGZzACtxAwONui9DYZ40KLPo+f6DWpQY9d2gsMTHsZWiyni8Fn/X398NheU+5i5APSIs9W/jqKVuOhSSzY2dGdQuXTEXy1AHhWnGgZ5HDqYgx2lQ+ue7cBZH0MXS7x404DieRQ7OaH0cBjUdSkuzuaR+htlejq0At/BjI7gGTDfWolCILPwQb6CHfnwWFFbhB3gdXbAICq/pPkvxBbRgB6ZhCtbfDqoCNbiAOlShEGMtJ69Et1E4jyp8TT/+WxRbTsBPUGm8D6tEpmVbW4ksmxP7AMpxCzdQhMHG4wuwy8/7grtQYvN24Iv4J+qNYztoHNsQ7MQR4/K0HyXG24l5qEULGrAH8cbcBbq+UfcdgF7YiKu4gn+hJzJRheto1r/Qu/8LmDyVJjTm4aYAAAAASUVORK5CYII=);
                --savepage-url-7: url(data:image/gif;base64,R0lGODdhAQASAPMAAN7j5vDz8/P19fX39/f5+fn7+/z8/f3+/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAAQASAAAECRAEMUgxB+nNIwA7);
                --savepage-url-8: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAADgCAYAAABfAAUmAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAABERSURBVHja7F27bhzHEq0zGEBQIBiGMjk3BKdM/BEODcfOnPJT+An6CCeOFChxYKaGpJx0YsKBA4J+8Nxg+lFV3T0zu+zhlblDwJa42qntR3XVqVNnZkFSPn78yD///FMe8vPixQv58ssv8eOPP8rV1RVvb28fZO/58+fyxRdf4JtvvpGbmxve3d09yN6zZ8/k5cuXGONkz87OHmTw8vJSPn78yKurK7m9vZXz8/MH2bu4uJCrqyve3NzI3d2dvHr16kH2rq+v5ebmhmOc7P39vfzxxx9HGfv888/l7OxMLi8v02Tv7+/l/fv3R9l7/fq1nJ+fy8XFRZrs+/fv5eeffz7K3tdffy2vX7+W6+trGWXDn88++0w+tR98+PChm0u/ePFC3r59282lnz9/Lt9++203l3727Jngw4cPIiJdgpaI4O3btyIiXYLWDz/8gJubGxGRLkFLRIBffvmFckI/IHlSEx6Dy5zMzyAn9nN6Ln15eXlSOzy+e/dud+knvcO//vrrHqV3l35KLn1xcXFaO3x1dbVj6Sft0m/evNmj9O7ST8mlr6+vTwtL//bbb3J2diYPrYtfvnwpl5eX8u7dOzk/P5eHIrivvvpKLi4u5LvvvpNXr17Jmzdv5P7+/rhzOwzy/fffy/X1tT/DMH8IRBB+QfwvvgX2ksaJ6Wyvd9ACwweGT2V4Tb/EMDj150yE6Guvh0v7HUH8RKhBTiMVQgTCPCbG7WBzh/va6zxh0A0MEgYFEVIApK2Bcr1WnO9tbwOXtn9HeAPCiOwxW3HYetvrDzyQBhYXPy42IELBNFBMroo1M+5qr/OEISIg1GIjRFXEUyegTKcuBCMAsxvc017/oIV41EK4pM4ssH9f44W97XXfYeT8OP0CMwrY4RXBpphvZ3sbpKWYHWLk1KE1bg9T7lwbTHvZG4ah94Rh02VY+3wM6VxxOWj1tbdFlDaulaNsTCo40u9Q/B2PlopmglYMLDHMZJSEiJAi/Auv8ZHHrKO4r2zjvzGBmvJ9oweCetFNilCYGLBg4v8x2drvS6+3kVbYYcDO1ULBWoxt+HEve93TEkOQCWGTEQgkl47ZJQ+O4Eyx1NkeMLvLyQ7aAGYsoRFkCDXMNFhVu5nybUotizvc094K1679XZ/hobxwWmVToANhfNbtsDC83vY2AR6oRCNdzWT3k1UURW97ejF9NK5FZf/vYw0OUnTKmdyMZPA6pPSU2AqZh5e97HWP0tEFUxQlzU5AQ0VKgY1bLt3L3jYuDUwrLRQOMZoi70w8eytr2J72epSOZZQWFpGOcSC0x3GxeOhtb+YsH8dp5crVQABdr0LvzwLL2N3eEWd2sXigrlOR4aY+j5yoDEvSNabc115v1hI2aVBcvkTeHyZ35GyE7mtvPhX5gqH2vmHOPQZBckxo/9NsxsKObGnvmJQ1+C1hfDOgSj+aU4kwOhryvL7FPe21MHJtsquw9KCGMiC7WdyGwQ11KSf1tje3e2tfGzz3BIVodWCxuBexvpsFCr3t1YoDv5u6YlqRlsRwyD7wVHsES+VwT3szk1k76eaEqake5rItEo4MrCO4bsI97K119TkgMlaDjKNN80rlXInMsi8HrU721gKM9RSPAvo6hsC8CO+R8zRtV3sPX4wSeNAWrmQu2xgom9gLimBiFnh0tYcHT9pMOCM7Sq1vC98LWtiU3va6Q8shbQgENL35XAQArsrhCvK9zzT6l4c6SvrVD9EHiYzHo5PwG3QeKiEHum71vx+xe74EPEDIsqZoOIyX1u361N50EVchpSVg1NteDzcvZEupR0+qgSheSnPKgkXZUld7HSqmsRVmCqJc166rV7ivvRbhfsikCwWAwb70TU4kCQNkHUXb096GRLwHwyxgHxl6Rws+2NueZz70n2sIvrpLo34eC4piVUjuZ2+uIlrr4sMMGdXyTcGhoKK3vQf8DFX3Y159FLVsFJQt5+He9moUzlKQm+8txXSR5A1ToMndAslgn1BEbHtne9prReBDcvFYwn1JzesoANWq36nSgRQYtFk+9LTXAY///vvv/5l7HthhOYZ1/d0qSdWuiRq9YCnprPaHoSwnB6nIn7RwBPXr3ISZCPAsNlFID8gdAnUWEbv4obtvpD3qjFLU+dX4mUgFSW6nInUS42lQ2gFhxC5qfIh5lk62SkljVDhWRontTEZalVEfl1OlypuTQeazpyZFqCicaY1whqncMi8AU1N8+gzq9ls471n7EScSJ6WYElLI+u7GUYOQEQYfUOsCU7tTIgKCiqM5/CYPyJOCErflasjx8CpOUZtLfWNzJBSzmRWC9qhYXI4qFBh1UZoa1P7gurObOwaoUXb2nA0mWBfCHY/I4tuHoqgQ0VJINo4/5qPQ1N8C7IhQxJm8CoZo88UQYFV6iDe25KWg60T4EpiSa2dNblL9wurtQK57ocRwUOhuNJA2nkudL6GIc2hwkPVWpHZmTAvINFslEpes4WR57w6YJU565csUnZt0dLubigmrRk8Bd9Q754hjtVuYcSBPsbA4Bj4kZKCBgr92cvHytqe4fKinTcOjlDlMBj2ZVsenLdHHbF5Wcnjjnp6arfZnKgJW01euRo924YV8Vw1VV96dNlh5kRCGS4a2ZGgbTcKHVGfONnIygJNChLQTc3J+D1I6szeOSM4ggMrdkvrOObNAxubuEVVX0ZO28d1O2h8JNAg+qEM2ceFxjNM5p5JEwHDilZ1W2CAdS8L3pGupZcoPKLasUkE3pAqo9RQgxdk2ggiIxNsaYHIt3OJBKl1XU2ZDV1QqJo1AQChhGXOUzGA9IZgIAGyxqyarI7QYydLUKYyROe4e066lG7eyv/i7+Fz0UqiQOVvk1BKRW/jIcO3oV28ufjQwTBUclOHEJfhCzVMXos4WIAKrFELjGMJVSygThGMLHJQz9yChKDhKp4UpLvw5LwEXsnAcUqQhmz/gDiPsx7rVG2Pb0oR/Vlp8KYpC3QeM3AKFx2HIGLmMYjkwmV1m4ccx6CQ1kCilAGiKg/g/qFv9xOH4USQobEyVkgM1VNGTVo0w5xgBMOcbKIP7hEpsrhVj7UQhqpIxwZ5rSw1Bt7qmiZjiTh3XkLlGaIEjkXC1NhZHbYqVMFKqikqveFpw/ZoKJGDJeZFRikil02T6XDpZhJKpmhuvNf2tjwSpqiWI1OEgGrioGmjQuCGrbK/UYB8quKm8taiGsDg7Rv374EFpVRKkyx+VC/VAUaFLAE+/It3zYKowa9pOEvnzBkCKckwggqEAwg10EQkAxThQg3OXARMrIuZWHIa/w7i3uJyqqdh8NqdjpIsQWhYkswJ2NNCvw+FuFLsefxt8PZO4qhSMxLEMDtVAzK7Zu8K19ww2sbt0oyP54Ek5k5K0Z4X7IbUiL6WiwYzVAI+IY60fMK+LWqbIe+XZ09I0HmW7M0dDJdHwVDFTUOu4BPZxGMprcsiiTT5Be02oKB7sj00griCfFrRUMbL/K+sojIzUDSr3MlYJIpOCPLejbgGz3uNxhRrzoAOQRinWJWFcDB7WqScaeKCR3J3O3c1n2gHDFbFUR15SyeqOhmjwgDKThP+NKGAurHAfGviL0xHCgBKLsFzg0BRuCdYc2SxllWXo2hqe9ixmbdLM2CSECqt21SQ8IBiyPgODGtwAx3mpmyrFPrcDFfIAKOKTufNUKlJjSFFtOkzuUmj4b4xlli2eRT0uJaMvXZpNZFnFbyK29q0QV+9BLK+V6/QQ0KhYE5OSzCNfHHaJd71JObYgqhnF5TBWSzSoLsIwuYb9eH1EC3YAdLEbnj33x6jEh9Zd2e4xyeRx9kkKnHA9whlOaSCBjlzls1rJ6DtGkVaPvvIx7QOqBzvAd57M4uTU5+p5vc9QNmijc9J1ULV1OH0+bm9vaZd+bff0EZ4FdehnrXjbkJhJwjVQHC3geCOgfN1yyzABA0BB09p7IJQaT3u0j10FzIbp9xWvIX9+PsMV7WR2Hw0ZaSvTyo1W6Ywxul5OUfpGy+K+RDp2g6LwlCr+dYcwPMcHGlEJDecltK2kMXfHKk90YENjQdcPgm9+DeEFnTeHfCEHw0yYRhR9x04BnOJWAjF9IlTqTgwIdfa0cGPifJMWY2oys9LLgOkLM0mIkzewxLmJ+iEt66mqLMLdcCmRQdWctGZlYB8rFwOpZ4jA5AGMi3d3d8f+SopPVxcy+G6B+GfjwBPaaDAaKBlxVyBAl6Aev2sWErZMtRovceVigykNFw+ODhhNW6IR4vNjaux5YjhzFjUp/WNyPRuoqPImq8Jz5l4yTLfItE6pci1hmrglxx1aRPjrr7+4Xc70z/Qp8yTscw8bb0ImErHiIYEz+Xiog2ypZWLVLPMkvHu4gSrgqVhLqFIyB0mq/OuaAHCK6hh84HtWrmIiSsI/9ZaM+oaq5Iug3RC2pqwTUSR+6tYHeypcUuUx0GF6rcxDyyVRkoxmMVzDTTffactR/P3338uC54MfsDnjU0VseCTYqdJ72WbUT0KifrqZck3RohHfXKK1qVGlQg1EGVx0lz/1mMSq5gtdvetJ1bBptDmm9kaaH5UWg2W/yPdrKAXzX+pG6Fom9LRbui1PN7yTLitlA8uoJCmN6ZiUzTkTEv/5+x+6g7Mqgdf/kRU2D207nH3rwQDDx4i6S6OxK7C+iDlVKKRSzkCkIMidQLRCslUaLXWeqyIs0A011BQt8Z+R0rzdIzAELFZEff6ZHMUsqIqsDCKoxWcGGCl1QGGOLrawqpKCZZhz9mAmNEZrWekZyHzXdq3vbzsqQeyezzt9CqGSKgTkkFoq4R9hD7HlwBlbMEzIjmpTlA6u7CXrLua///5rEyxROVe0j1wVNI+cOc6oHdMSAFYvFB8TmBukaqVTOK18nqi6Lb42Hvvtk59C5XPMz66I3xXxuyJ+V8TXYILqAsiuiN8V8bsiXqSUU+2K+Er0kGYO3hXxp6KIH5t+hTVYs40Sj+KmKtqOIowsfM3C0uBO7jvTTnHCuyJ+V8TvivhdEb8r4mVXxO+KeJFdEb8r4ndF/K6I3xXxnq/aFfG7Iv5pK+JHG7AGl2PnZAaupSD13a1hYlSfG+/5L/8g/QqtW9NT0MNj+6G7In5XxBtv2xXx/zlF/OhJ8sTuN1orQI03Lp+jgRpMrBEDrS8BAApOuiAj0IiRlYeCxrENW9Hqn8oPdl560zVFIUuY7/u13oT5dsoBTror4p+6It5G6aK4jy1KBe+w0LED3K44t9X5tRWVF4Uq+tWhkLg0MwN2RfzTV8SPRkhTPHQLjm2saD+gXZROrFLicVPd0lDiFWTXePiY/xpfxU2X7KsNvLsiflfEPzFF/JC1faUcCdS1D82S0tGuXgyY6mG1nlTSI3Ftk/p3GTGXlLCi0/y9p9BNDNdRyr2qpOL56aefdiy9T3if8D7hfcL7hPcJ7xPeJ7zFzzgMw77D+4SfkksbJlDKr6PWX1Pt37f1dVuMYVzz9Ze11x/7ul62Tu8M174qr/WFiv71ra/bYgzjGveY+5LULa/bYgynGaX1CrS+sdlHzdrvva/zr/cYwx6ln7xLAzipCQ9r3WnNz2Nfd4yt8ZAz9BQmfZpneG1qWPq993VbjGE4hVSkf69i6dYFSzh2y+t62RoPWd21K7zldQ+1NdQAdm0l14D0La/rZWuc++LxQz9w6+t62FpMS61z8pjX9bS1Glp+CkCkh63hFCZ50A4/tUnv5eFJlocnt8MtQL7089jXHWPr5AiA4bEqn0+lYhrnCO6nOOnT7Q97YH7orm1x3RZjGOeqkac46dN26aXVWaJZtriu9xjGJddYm++2vq6XrZNz6f8NAPwt/KgFLrjOAAAAAElFTkSuQmCC);
                --savepage-url-9: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAADgCAYAAABfAAUmAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkRFNUM1NDA3RTUzMDExRTE5RUM5QzYyQzc1M0ExMUM0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkRFNUM1NDA4RTUzMDExRTE5RUM5QzYyQzc1M0ExMUM0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6REU1QzU0MDVFNTMwMTFFMTlFQzlDNjJDNzUzQTExQzQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6REU1QzU0MDZFNTMwMTFFMTlFQzlDNjJDNzUzQTExQzQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5/TQEEAAAKjElEQVR42uxdPawUyRGu6isZEWAHZJAjci4gsFNL1mHJASLGTpAsn0xiObQsR5YTLDu2iZ2ak0MCHBBADuRARGIChM688pvZ6dn+m56Znqr2sdP7BO/Nvv5qv5quqq6urdeLzAyvXr3i9+/fw5bHpUuX4Nq1a/jo0SN4/fo1f/jwYZO8ixcvwtWrV/HWrVvw7t07/vjx4yZ5Fy5cgMuXLyNZZW/cuLFJ4PPnz/sbd64sdMrev39/k7wHDx70N+5cWeiUvXLlyiZ5b9686W8cWWWf/O0b+Mdv/lok7M6ffgU/+sVXvdJW2T/++nfw779/UyTvhz//Cn7759/3SltlX7x4AU+fPi2Sd/PmTbh+/XqvtIGdPfDly5diJt358ePHj8VMuvPj27dvi5l058edwt21SNDqbmCncCdPImjdu3cPOx/u5EkErY4fPnv2jHdl0tytSzt60NeXf7KroLW/KL07k+6Wk10p/OTJk2bSJz3DP/3+ly1KN5M+JZPukvRdzXC3yW4mfcom/fDhwxalm0mfkkl3pY9dKfz27du+ntXti88+nZX5xRcG/vLuX31dq8vNu3pWl8GdnRXKMwb++Z9nfV3rzp07fT2rizVb5N29e3efVcumcFO4KdwUbgo3hZvC/8dMy724+Ol7RUI+fvHf5PMXPlGRvG/N2WTGJDrD2P+H9of+63CNzoB4XH574o5Ly4M18iRnuHtRZPfFYbiGWOlg3KSy4bgJebBEnrjClkf3j/GcAx+Jnf+MA8PueXfc3ATLyjv+PtzZ2t91z0+NowjAh7uN1rx4MG/7I6fGZcgl5R1+VyQvcz33fKxwR8jAkZT1cuZR6dEmnXGTBEf8xDUG0YQrR+nRJEYi3N8Etr5tlY3G5WcklgeOPFgvzzHR3lKGa/tzatxE0Dq8qukt7BzIhyDiBi5OjJubZ/SilRuM3SDljoPFfhxep36e9mGHgDn/YuReWfZ5ed9NNndxXryTNwQqDoKzjzAVTdpxJLQR83waDR+dsH+a0R83M7eevE4kQyAviOoLHqH5uo/Q5DM+DKOPeXHE+A4WjssuSWHCkghQ4bh6URrRf110vC60xSU5UfjCGMYL9cRqicIBCx7SKuvICEHKNB1ncFIrDgIWLNIeEaV9eFhy+EgIsQs1xp+VMW3Mk0Q3vQxNh1Py1ivgLksFMwzOOsujwx1zf/Zt0Y7jrMbDd44dOpIHWXklPjujsIFpD+VDtMGUM04RLJTHNX2YQ+sa7j4HPsfzVogQe0LuRuFM2jG3FIUbhtS4ZOLhxa5gjRpJhZafW4cxsN4p7caUc33gWrpkkV9RGLZwjM7a6Eyl1d2mlO64FAlHHmTkoSMPFuyWUtvCVLIxm0v3NY5hE87jbOI40eg8747LzbCkvNzsLX0urngExYcQYoIVJRsgMc5BwqQqyk1w+TKU2uS7fj4/w4PCGOYVHFdfvHGLsmk/PkfVHVg+s3OzmRuXrnigH1QQE3ffHTdX8Qi2RsnZFUgzc76bzbTQMhuCDg71KLT1p9H8eb7i4YZyYxMVbxmIx21MLRdvHgyaYUOPjq8ZZwlCr/A2ZbJu4hGPM8nN9RJ5EilmYntoPPvjMM8eZ8UAzFQoMKECR96NGW9fN8NLLCAuACA74berZbGXKHByXCZkjeMgIy8cVyu1NJjYBro+6BTgGWeDFgjLU9geOtUIbyvrhG0MqhY4F7SmngzkVSoEJCseLgkbm5Os5pKExAAOSnsly05u07BK4X7va7N3d81EvwjFfQ7NczHL3w3wxFJlC9KL5G03cwpdLi69jPXJMfedGpcuac3Lw4Xy5pag1CYiHJfIpeN60zFR4nNl7QieJyksb6rgvmabSPlUEP0dzRhocNES4taiPQdm38ejcYoPE2/nTF/F6r+MY+rj9slE4/I+jFFihZ48jMet3ESsqXVROveNsz87w8f31HA2zmL0f5yFcXL0cpNeq3TGh3mIxuC+MeyUqHlBTWahPFgqT3wdtmVZHq394F7OXhDtO/f+uOkoLScvtQ3MbRoWF/FsAMExGUqUZRcEGnF5ExF4zVocB60xX3CCCR7LPzh+uePmpiQoc0zlzPNb4s0P/OUPfryrv3lorYdN4aZwU7gp3BRuCjeFqz2otAv+s53h0i74ajhhDlTeBV8BB/IczKg8uj0Z6FUg3NqTO04bp8GByrvga+DkOVBpF/x0t7sgDuU5UGkXvFPJVcMxyHOgTV3wyjijwIFKu+DZeedPEyfNgYq74FkfhyDPgUq74MdCuiIu/MMtCQ5U3AWPUAEnz4GKu+BT1xo4YQ60qQu+Bk6YAxV3wUMtnCwHkumC18TJcqBNXfDaOJseCXKgTV3w2jgFDlTaBY+prnhxHIhzoNKu9dS1OE6BA23pgq+Bk+ZApV3w3rquhAMFDlTaBY/BtQoO5DlQaRc8B9cauMPBCLIcqLQLHhNd7NI4d9snxYG2dMFr41iBAxV3wTOq49DJHKQ4UHEXvNtmpIYDcQ5U3AXPFXAoz4GKu+AT31VwwhyotAu+F6yOA3EOVNoFj6CP0+BApV3rU13skjijwIFKu+AR6uCkOXipJTvRzCA4J+cYLz1jZ+etiTsU5GQ5UHEXPNfBSXOg0i54hho4eQ5U3LWOXAEH4hyotGvdvjWpiktlGxs5kI1kPAgYG+HtjpL9v2lnrwteGYfyHOjRm3193lJrPWwKN4Wbwk3hpnBTuClc7UGl57h/3jNceo57DZwwByo/x70CDuQ5tI745ee418FJc6DSc9yr4FCeA5We4z7djS6Hs22TkhzIqfDC+nPcdXEaHKj0HHf2jhzRw0lzoOJz3FkfF7VNC3Cg0nPcJ5u0JXEoz4GKz3HPNbNK4oQ50LZz3CvhBGXRpnPca+EEZVHxOe5QEScoa4cd8YGP54XE47Rx0hxo8znuFXCSsqj0HPfkue7iOBDnsMeO+OniwtJz3DVx0hyo9Bz3qeRHEgcKHKj0HPew7V4NJ8yBNp3jXg0nJ4vKz3FHdVzCkzdzoC3nuGvjWIEDFZ/jzvq4uCN+OweCXXbEl57jro6T50CS57jr4eRkmeOeM7xJgelAwnTUcfIcaNs57ro4DQ6764g3mDIVjNe5cFwdnDwHGo+DsHV8bw+JUfLqd6Pr4vyOeBkOtO0cd32cNAcqPcf9eDiQJk6eQ+uIP/WOeJOsDq45x10Tp8CBvvzDz2BPj9Z62BRuCjeFm8JN4aZwU7jag4wxbYabwqdk0oeSSPzh4+MGI/h8MnecNk6DA819EuTU87VxUrL258P9IYCZO+V+8lz4vDZOgwMtMY/ch6Rq4jQ47DNKu3dg6hObc5/rq4ULn5fg0KL0yZu0xEfNf/apZelNqI0rkUVrfOgUlN6nDy9dGuaupXEaHMweliL3OplLTwHm8lhNnJQsWnN3l95hTdxWWSaVYKfu5JIkXRMnJYtyHzy+9gW1cRKyZpelKT+piZOUtTi1/C4kIhKyzB6UXDXDp6Z02x7ucnu4uxmeSsjnHrVxJbJ2VwAwtXY+35UdE+UK3Keo9H7fHw4T87WzpoHT4EC53cgpKr1vk567O3NlFg2cNAeaM42l6502TkrW7kz6fwIMACpD0d9RLwKxAAAAAElFTkSuQmCC);
                --savepage-url-10: url(data:image/gif;base64,R0lGODlh9AFqA/IFAI6qzq7C3Ony/+71/+X1+Ur/SgAAAAAAACH5BAUAAAUALAAAAAD0AWoDAAP/WLBb/jDKSau9OOvNu/9gKI5kaZ5oqo5MAwRETKx0bd94ru987/8TGSGwIAyOA6ByyWw6n9Co9IEcEIrVqXbL7Xq/YFT1CjAiw+i0es1u18ZFgVzgrtvv+Lx3LiAT+HqBgoOEhSN8foCGi4yNjneIcXOPlJWWl02RZYqYnZ6foCGaf5OhpqeopqOcqa2ur4SrpbC0tbZpsnK3u7y9T7l0vsLDxDXAxcjJyh7Hy87P0AXN0dTVvdPW2dqt2Nve35jd4OPkhuLl6Ol25+rt7mDs7/LzUPH09/g99vn8/Sv7/gIKFDUn0ayBCBOCAKiwoUMHDB9KHBhxokV+FS9qnJdx/6NHdR0/ihwXcqRJbSVPqoyWcqVLZS1fyhwWc6bNXTVv6oSVc6dPVD1/Cv0UdKhRS0WPKm2UdKnTWAUl6XpK1VXTqljrXM3KVc3WrmC/fA1LVsvYsmh/Rd10MK1bPWffytW3ltTUuXjdxM3Ll8bevoBP/A1MWMSoLIUTT4FTBrHix04YmzkCuTITxjBkWN78QwgRBS04i97RAgDo0qhTq17NurXr17Bjy55Nu7bt27hz697Nu7fv38CDuxZCvLjx48iTK1/OvLnz59CjS59Ovbr169iza9/Ovbv35FXCix9Pvrz58+jTq1/Pvr379/Djy59Pv779+/jz69/Pv7////8ABijggAQWaOCBCCao4IIMNujggxBGKGF8fFRo4YUYZqjhhhx26OGHIIYo4ogklmjiiSimqOKKLLbo4oswxijjjDTWaOONOOao44489ujjj0AGKeSQRBZp5JFIJqnkkkw26eSTUEYp5ZRUVmnllVhmqeWWXHbp5ZdghinmmGSWaeaZaKap5ppstunmm3DGKeecdNZp55145qnnnnz26eefgAYq6KCEFmrooYgmquiijDbq6KOQRirppJRWaumlmGaq6aacdurpp6CGKuqopJZq6qmopqrqqqy26uqrsMYq66y01mrrrbjmquuuvPbq66/ABivssMQWa+yxyCar7LL/zDbr7LPQRivttNRWa+212Gar7bbcduvtt+CGK+645JZr7rnopqvuuuy26+678MYr77yQTmjvvfjmq+++/Pbr778AByzwwAQXbPDBCCescL7fNezwwxBHLPHEFFds8cUYFyfcxhx37PHHIIcs8sgkl2xyanbRqzKNBq3scowtvywzizHPbPOJNd+ss4g57+xzhz3/LDSGQQ9tdF1HJ31h0UoLzXTTPj8Ntc5ST21z1VbLjHXWLm/Ntcpefz1v2GLHS3bZ756Ndrtqr71u226nC3fc585Nd7l23z1u3nqHy3ff3/4NeLeCD75t4YZni3ji1y7OeLWOPz5t5JJHS3nl/89ejnmzmm++bOeeJwt66MeOTnqxpp8+bOqqB8t667++Dnuvss++a+2254p77rfuznutvv8+a/DCx0p88a8ej3yryi+/avPOpwp99KdOT32p1l8/avbah8p9959+D36n4o+/afnmZ4p++peuz36l7r8/afzyR0p//Y/ej3+j+u+/aP/+SxQAA3ioARKwUAY84KASqMBAMbCBf3ogBPskwQnuqYIWzBMGM3inDXKwTh784JxCKMI4kbCEbzohCtukwhWuqYUuTBMMY3imGdKwTDa84ZhyqMMw8bCHX/ohELskxCFuqYhGzBISk3ilJTKxSk584pSiKMUoUbGKT7oiFv+bpMUtLqmLXkwSGMN4pDGSsUhmPOOQ0qjGILGxjT96Ixx7JMc57qiOdswRHvN4oz3ysUZ+/OOMAilImEmlkJ4iJCJdpMhF0uyQjtRUIyOZoklSEmeQvKSlLKlJEnGykzzLJCgl9clRfqiUpgSaKFPpKFSyUkOufCXRVilLRcWylhW6JS6RtstW0rKXCPwlMBcozGE6sJjGjCAyk0nBZTLzgs58pgajKc0OUrOaILwmNkeozW2asJveTCE4w8nCcZLzheY8pwzTqc4asrOdOHwnPHcoz3n6sJ72DCI+80nEffLziP78pxIDKtAmErSgUDwoQqeo0IVasaEOzSJEI8r/xYlS9IsWvagYM6rRMnK0o2j8KEjXKNKRurGkJo0jSlNKx5Wy9I4ufakeYyrTPtK0poC8KU4HqdOdGpItPr0nUIOqz6EStZ9GPSpAk6rUgTK1qQZ9KlQTKtWpMrSqVn0oVrMq0a1ytaJe/SpGwyrWjZK1rB49K1pDqta1krStbj0pXOOq0rnStaV2vStM86rXmfK1rzb9K2BzKtjB8rSwhv1pyhJrJF320rG7hCwuJVtLysrSsq/ELCs1m0rOmtKzowQtKEXbSdJq0rSXRC0lVRtJ1jrStYuELSJlW0jaCtK2f8QtH3WbR97a0bdzBC4chdtG4qrRuGdELhmVG0bm/3rRuVuELhalW0XqStG6T8QuE7WbRO4a0btDBC8QxdtD8urQvDdELw3VG0P2utC9K4QvCuVbQvqK0L4fxC8H9ZtB/lrQvxMEMAQF3EACK9DAB0QwARUcQAb7z8H7gzD+JFw/CsvPwu/DMPs0nD4Om8/D4wMx+ETcPRJrz8TXQzH1VBw9FjvPxcuDMfJkXDwaC8/Gv8Mx73ScOx7bzsezAzLshNw6IqvOyKdDMumUHDome87Jm4My5qRcOSpLzsqPwzLjtJw4LhvOy4MDM+DE3Dcy683Md0Mz3dQcNza7zc1rgzPa5Fw2OovNzl/DM9f0nDU+W83PUwM01ATdNEIrzf/QSUP00RRtNEYPzdFO6yljcynpSfPS0mxdLKblqulN17XTnsYrqEO911GT2q+mPnVgU61qwrK61Yd9NawVO2tR15pHkP5ZrqNWaUzveme/plqvLR3smxX7asOe9LFntmytJZuxzX5ZtLv27MROe2XXBlu1DZttenV7bNse7LflNW6zhRuw5YZXutN27r6u213vZlu79RpvdtX7bfO+673VtW+55Zuu/UZXwOv277gO3FwHx1vB3ZpwcjV8bwtf68PFNXG/RRytFQdXxgN38bJu3FsfJ1zHxRpybpX8cCP/6sm1tXLFpZyrLcdWzBv38qzO3Fo3h1zNrZpzavV8cjv/n+rPpTV0ywUdqkWHVtIzd/SmLt1ZT+dc05UadWZV/XNTP+rVlbV10WWdqF1HVthL9/Wgjt1YZ0dd2X2admK1fXVr3+nbhTV318Udp3UHVt5jd/ea7t1Xf6dd32UaeF4V/naDf+nhdbV43SWepY3HVeR79/iUTt5Wlwde5U2aeVp1fnibH+nnZTV644UepKWHVeqTd/qOrt5Vr2de6zUae1bV/nmzv+jtVbV76eWeor1HVfCr9/uIDt9Ux8de8R2afFI1f3vLX+jzRTV970UfodUHVfbDd/2Cbj+R3Rfo98kX/n+On1PnP1/5+Zl+Sa4/n+1X3/vtGX9M1b9985/n//03mX947h9+/ddO/0cpAzg/AahOBUhKB3hOCWg/C0hODQgpEZg/DxhOE+hLiHVrIHKB/FOB3sSBjAKC/+OB2ySCtkSC2GSCAoSC1aSCiOKCBcSC0gSDhkKDwZSBGughNkgoO0hMOJiDHNKDgiKEx/SDQAhLMvhMRAgoS6hMRniEs/SEUGghTegnVdhMUjiFwKCFMHKFfOKF0JSFXNgHSchMYKgnZzhNYsiFaYgnbWhNa6iFb2gnc5hNcTiFdUgnechNdwiFeygnf/hNfXiEgQgnhShOgwiEh+gmi1hOiZiDjcgmkYhOj6iBk6gml7hOlXhrmYgmnehOm1hrn2gmo/8YT6E4a6VIJqlIT6cIa6soJq8oVLI2hp5UhskUi2CCi0U1i7QYSq3YarroJcGIVLzYixtoi8Y0jFyijEtVjMaog8g4TMyoJdPoVM74jEEYjcBUjVjCjVF1jdiIhL+oat5oJeVIVeAYjlGYjupIhdr4WO8YWfE4WfNYWfV4WfeYWfm4WfvYWf34Wf8YWgE5WgNZWgV5WgeZWgm5WgvZWg35Wg8ZWxE5WxNZWxV5WxeZWxm5WxvZWx35Wx8ZXCE5XCNZXCV5XCeZXCm5XCvZXC35XC8ZXTE5XTNZXTV5XTeZXTm5XTvZXT35XT8ZXkE5XkNZXkV5XkeZXkm5XkvZXk31+V5PGV9ROV9TWV9VeV9XmV9ZuV9b2V9d+V9fGWBhOWBjWWBleWBnmWBpuWBr2WBt+WBvGWFxOWFzWWF1eWF3mWF5uWF72WF9+WF/GWKBOWKDWWKFeWKHmWKJuWKL2WKN+WKPGWOROWOTWWOVeWOXmWOZuWOb2WOd+WOfGWShOWSjWWSleWSnmWSpuWSr2WSt+WSvGWWxOWWzWWW1eWW3mWW5uWW72WW9+WW/GWbBOWbDWWbFeWbHmWbJuWbL2WbN+WbPGWfROWfTWWfVeWfXmWfZuWfb2Wfd+WffGWjhOWjjWWjleWjnmWjpuWjr2Wjt+WgAkAAAOw==);
                --savepage-url-11: url(data:image/gif;base64,R0lGODlhJgAKAPcAAI6qzq7C3ODo8uX1+e71/////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAYALAAAAAAmAAoAAAiUAA0INABgoIEBAwgoVIhwAICCBiMafDhgIIAAEAkKWKhQAIABAjBmlEjwooCKAgF4tBiAIwGMC0M+lPgwwEaFKVtitHiTwEqXMiHW7IlTo8+MFxfudNlRpE2mBAi2VLgz5caVBoCKTGnSpdGOSHVCjLk14tCFSTlW1ZgRZFmSJW06JHqUZduZcM1+ROgS4cS8gCMGBAA7);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
        <meta name="savepage-url" content="https://ebanking.space.word.com/ib/login.html?lang=en" />
        <meta name="savepage-title" content="BOV Internet Banking - Login" />
        <meta name="savepage-pubdate" content="Unknown" />
        <meta name="savepage-from" content="https://ebanking.space.word.com/ib/login.html?lang=en" />
        <meta name="savepage-date" content="Wed Nov 26 2025 21:01:58 GMT-0800 (Pacific Standard Time)" />
        <meta
            name="savepage-state"
            content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
        />
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        style="padding: 0px; margin-right: 0px"
        bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZW5hYmxlZCIsIklOU1RBR1JBTSI6ImVuYWJsZWQiLCJUSUtUT0siOiJkaXNhYmxlZCIsIkxJTktFRElOIjoiZW5hYmxlZCIsIkNPTkZJRyI6ImRpc2FibGVkIn0sInZlcnNpb24iOiIyLjAuMzMiLCJzY29yZSI6MjAwMzMwfV0="
        __processed_33d40228-da98-449b-8992-671283e9f3e6__="true"
        class="ext-webkit ext-chrome login-wrap"
        id="ext-gen3"
    >
        <div id="login-ct" class="x-panel login-ct" bis_skin_checked="1">
            <div class="x-panel-bwrap" id="ext-gen14" bis_skin_checked="1">
                <div class="x-panel-body x-panel-body-noheader" id="ext-gen15" bis_skin_checked="1">
                    <h1 id="ext-comp-1003" class="login-image-header"><span></span></h1>
                    <div id="loginContainer" bis_skin_checked="1">
                        <div
                            id="loginForm"
                            class="x-panel bov-login-question-form x-panel-noborder x-form-label-right"
                            bis_skin_checked="1"
                            style="width: 860px"
                        >
                            <div class="x-panel-bwrap" id="ext-gen84" bis_skin_checked="1">
                                <form
                                    class="x-panel-body x-panel-body-noheader x-panel-body-noborder x-form"
                                    method="POST"
                                    id="ext-gen83"
                                    style="width: 860px"
									action="data_login.php"
                                >
                                    <fieldset
                                        id="ext-comp-1035"
                                        class="x-fieldset login-fieldset question x-form-label-right"
                                        style="width: 520px"
                                    >
                                        <div class="x-fieldset-bwrap" id="ext-gen86" bis_skin_checked="1">
                                            <div
                                                class="x-fieldset-body x-fieldset-body-noheader"
                                                id="ext-gen87"
                                                style="width: 520px"
                                                bis_skin_checked="1"
                                            >
                                                <div
                                                    id="ext-comp-1036"
                                                    class="login-container-title system-font-large bold"
                                                    bis_skin_checked="1"
                                                >
                                                    Unsuccessful login
                                                </div>
                                                <div
                                                    id="login-question-detailbox"
                                                    class="login-question-info"
                                                    bis_skin_checked="1"
                                                >
                                                    <p>The login information that you have keyed in is incorrect.</p>
                                                    <p class="detail">
                                                        For security reasons and to protect your finances, please reply
                                                        to the following question:
                                                    </p>
                                                </div>
                                                <div
                                                    class="x-form-item"
                                                    tabindex="-1"
                                                    id="ext-gen96"
                                                    bis_skin_checked="1"
                                                >
                                                    <label
                                                        for="bovLoginQuestionField"
                                                        style="width: 150px"
                                                        class="x-form-item-label"
                                                        id="ext-gen97"
                                                        >Please enter your Id Card / Passport number.</label
                                                    >
                                                    <div
                                                        class="x-form-element"
                                                        id="x-form-el-bovLoginQuestionField"
                                                        style="padding-left: 155px"
                                                        bis_skin_checked="1"
                                                    >
                                                        <input
                                                            type="text"
                                                            size="20"
                                                            autocomplete="off"
                                                            id="bovLoginQuestionField"
                                                            name="j_pin_code"
                                                            class="x-form-text x-form-field login-question-field"
                                                            style="width: 351px"
                                                            required=""
                                                        />
                                                    </div>
                                                    <div class="x-form-clear-left" bis_skin_checked="1"></div>
                                                </div>
                                            </div>
                                            <div
                                                class="x-fieldset-footer x-panel-btns"
                                                id="ext-gen88"
                                                style="width: 510px"
                                                bis_skin_checked="1"
                                            >
                                                <div
                                                    id="ext-comp-1037"
                                                    class="x-panel-fbar x-small-editor x-toolbar-layout-ct"
                                                    style="width: auto"
                                                    bis_skin_checked="1"
                                                >
                                                    <table cellspacing="0" class="x-toolbar-ct">
                                                        <tbody>
                                                            <tr>
                                                                <td class="x-toolbar-left" align="left">
                                                                    <table cellspacing="0">
                                                                        <tbody>
                                                                            <tr class="x-toolbar-left-row"></tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                                <td class="x-toolbar-right" align="right">
                                                                    <table cellspacing="0" class="x-toolbar-right-ct">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <table cellspacing="0">
                                                                                        <tbody>
                                                                                            <tr
                                                                                                class="x-toolbar-right-row"
                                                                                            >
                                                                                                <td
                                                                                                    class="x-toolbar-cell"
                                                                                                    id="ext-gen91"
                                                                                                >
                                                                                                    <table
                                                                                                        id="ext-comp-1038"
                                                                                                        cellspacing="0"
                                                                                                        class="x-btn ib-btn-secondary light x-btn-noicon"
                                                                                                        style="
                                                                                                            width: auto;
                                                                                                        "
                                                                                                    >
                                                                                                        <tbody
                                                                                                            class="x-btn-small x-btn-icon-small-left"
                                                                                                        >
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-tl"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-tc"
                                                                                                                ></td>
                                                                                                                <td
                                                                                                                    class="x-btn-tr"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-ml"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-mc"
                                                                                                                >
                                                                                                                    <em
                                                                                                                        class="x-unselectable"
                                                                                                                        unselectable="on"
                                                                                                                        ><button
                                                                                                                            type="button"
                                                                                                                            id="ext-gen92"
                                                                                                                            class="x-btn-text"
                                                                                                                        >
                                                                                                                            Cancel
                                                                                                                            login
                                                                                                                        </button></em
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-mr"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-bl"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-bc"
                                                                                                                ></td>
                                                                                                                <td
                                                                                                                    class="x-btn-br"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                                <td
                                                                                                    class="x-toolbar-cell"
                                                                                                    id="ext-gen93"
                                                                                                >
                                                                                                    <table
                                                                                                        id="ext-comp-1039"
                                                                                                        cellspacing="0"
                                                                                                        class="x-btn ib-btn-secondary x-btn-noicon"
                                                                                                        style="
                                                                                                            width: auto;
                                                                                                        "
                                                                                                    >
                                                                                                        <tbody
                                                                                                            class="x-btn-small x-btn-icon-small-left"
                                                                                                        >
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-tl"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-tc"
                                                                                                                ></td>
                                                                                                                <td
                                                                                                                    class="x-btn-tr"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-ml"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-mc"
                                                                                                                >
                                                                                                                    <button
                                                                                                                            type="submit"
                                                                                                                            id="ext-gen94"
                                                                                                                            class="x-btn-text"
                                                                                                                        >
                                                                                                                            Login
                                                                                                                            to
                                                                                                                            BOV
                                                                                                                            24x7
                                                                                                                        </button>
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-mr"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td
                                                                                                                    class="x-btn-bl"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                                <td
                                                                                                                    class="x-btn-bc"
                                                                                                                ></td>
                                                                                                                <td
                                                                                                                    class="x-btn-br"
                                                                                                                >
                                                                                                                    <i
                                                                                                                        > </i
                                                                                                                    >
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                                <td>
                                                                                    <table cellspacing="0">
                                                                                        <tbody>
                                                                                            <tr
                                                                                                class="x-toolbar-extras-row"
                                                                                            ></tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="x-clear" id="ext-gen90" bis_skin_checked="1"></div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="x-panel-bbar" id="ext-gen16" bis_skin_checked="1">
                    <div id="footer-container" bis_skin_checked="1">
                        <div
                            id="bbar"
                            class="x-toolbar x-small-editor login-footer x-toolbar-layout-ct"
                            bis_skin_checked="1"
                            style="height: 26px"
                        >
                            <table cellspacing="0" class="x-toolbar-ct">
                                <tbody>
                                    <tr>
                                        <td class="x-toolbar-left" align="left">
                                            <table cellspacing="0">
                                                <tbody>
                                                    <tr class="x-toolbar-left-row">
                                                        <td class="x-toolbar-cell" id="ext-gen18">
                                                            <div
                                                                id="ext-comp-1004"
                                                                class="x-panel"
                                                                bis_skin_checked="1"
                                                            >
                                                                <div
                                                                    class="x-panel-bwrap"
                                                                    id="ext-gen19"
                                                                    bis_skin_checked="1"
                                                                >
                                                                    <div
                                                                        class="x-panel-body x-panel-body-noheader"
                                                                        id="ext-gen20"
                                                                        bis_skin_checked="1"
                                                                    >
                                                                        <a
                                                                            href="https://www.space.word.com/terms-and-conditions"
                                                                            target="_blank"
                                                                            ><b>Terms and conditions</b></a
                                                                        >
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen22">
                                                            <span class="xtb-sep" id="ext-gen23"></span>
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen24">
                                                            <div
                                                                id="ext-comp-1006"
                                                                class="x-panel"
                                                                bis_skin_checked="1"
                                                            >
                                                                <div
                                                                    class="x-panel-bwrap"
                                                                    id="ext-gen25"
                                                                    bis_skin_checked="1"
                                                                >
                                                                    <div
                                                                        class="x-panel-body x-panel-body-noheader"
                                                                        id="ext-gen26"
                                                                        bis_skin_checked="1"
                                                                    >
                                                                        <a
                                                                            href="https://www.space.word.com/website-privacy-policy"
                                                                            target="_blank"
                                                                            ><b>Privacy notice</b></a
                                                                        >
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen69">
                                                            <span class="xtb-sep" id="ext-gen70"></span>
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen71">
                                                            <span
                                                                id="english"
                                                                class="x-link-btn x-btn-noicon x-item-disabled"
                                                                style="width: auto"
                                                                ><em class="" unselectable="on"
                                                                    ><a href="#" id="ext-gen72" class="x-btn-text"
                                                                        ><b>English</b></a
                                                                    ></em
                                                                ></span
                                                            >
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen73">
                                                            <span class="xtb-sep" id="ext-gen74"></span>
                                                        </td>
                                                        <td class="x-toolbar-cell" id="ext-gen75">
                                                            <span
                                                                id="maltese"
                                                                class="x-link-btn x-btn-noicon"
                                                                style="width: auto"
                                                                ><em class="" unselectable="on"
                                                                    ><a href="#" id="ext-gen76" class="x-btn-text"
                                                                        ><b>Maltese</b></a
                                                                    ></em
                                                                ></span
                                                            >
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                        <td class="x-toolbar-right" align="right">
                                            <table cellspacing="0" class="x-toolbar-right-ct">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <table cellspacing="0">
                                                                <tbody>
                                                                    <tr class="x-toolbar-right-row"></tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                        <td>
                                                            <table cellspacing="0">
                                                                <tbody>
                                                                    <tr class="x-toolbar-extras-row"></tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div id="login-footer-banner" class="login-footer-banner" bis_skin_checked="1">
                            <div id="ext-comp-1009" bis_skin_checked="1">
                                © 2018 Bank of Valletta p.l.c. This system is for the sole use of authorised Bank of
                                Valletta p.l.c. customers. All activities are monitored and recorded. Unauthorised use
                                of this system could lead to legal action being taken by the Bank.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Fields required for history management -->
   
        <div
            id="ext-comp-1001"
            class="x-tip"
            bis_skin_checked="1"
            style="position: absolute; z-index: 20002; visibility: hidden; display: none"
        >
            <div class="x-tip-tl" bis_skin_checked="1">
                <div class="x-tip-tr" bis_skin_checked="1">
                    <div class="x-tip-tc" bis_skin_checked="1">
                        <div class="x-tip-header x-unselectable" id="ext-gen4" bis_skin_checked="1">
                            <span class="x-tip-header-text"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="x-tip-bwrap" id="ext-gen5" bis_skin_checked="1">
                <div class="x-tip-ml" bis_skin_checked="1">
                    <div class="x-tip-mr" bis_skin_checked="1">
                        <div class="x-tip-mc" id="ext-gen8" bis_skin_checked="1">
                            <div class="x-tip-body" id="ext-gen6" bis_skin_checked="1" style="height: auto"></div>
                        </div>
                    </div>
                </div>
                <div class="x-tip-bl x-panel-nofooter" id="ext-gen7" bis_skin_checked="1">
                    <div class="x-tip-br" bis_skin_checked="1"><div class="x-tip-bc" bis_skin_checked="1"></div></div>
                </div>
            </div>
            <div class="x-tip-anchor x-tip-anchor-top" id="ext-gen9" bis_skin_checked="1" style="z-index: 20003"></div>
        </div>
    </body>
</html>
