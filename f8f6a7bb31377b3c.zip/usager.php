<?php
$blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
?>
<!doctype html>
<html lang="en">
    <head>
        <link
            rel="icon"
            data-savepage-href="https://space.word.com/favicon.ico"
            href="data:image/x-icon;base64,AAABAAIAICAAAAEAGACoDAAAJgAAABAQAAABABgAaAMAAM4MAAAoAAAAIAAAAEAAAAABABgAAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f/+//////7///7///7////+//7////+//7//v7+///7///////////////////////////+///+/f////////7//P/9///+//7//////f////////7////+/////f/+/v3//////////v/9/f/+/f7///7////+/////f///P7+/f////////3////////+/f////7/////+//+////+//+//7/+v7////8/////////f////7////++/////7+klW3fDKodCehaRaaaBmedC6jiFix0bjk/f/+//////7//v7+ya7aekOqZyCZYwyYaSGdfkipx67a//////7////////+////7uT0dDukYzaXr37I////////+///////QACBTACNTACITwCOSgCJNgB3LAFyPQCAwZjV/v/9//7/nWrBOwF+LQB1OgJ/TQCHOwJ9LQB3OwF+q33G///+/v3//f//////k1O3KQB0OwCARwCG59vt/f///v3///7/YQ6ZRACDh0Oy5tzt5NftwKLXax6dOgB9RwCH//7/18HkMAB2PQCAZRWYwZ7W2cbnupbSYw6YPgCCMAB5vZrS//7/////9fH3TwGLSACJSgCINAB+lFS3/////f/+////YgyaOgB9l2S+//7//P7+/f//uY7NNAF7RAKHzrTcgDutNgB8WRGT8+b0///+/v7+//7/4tbsTQGJOQB7ciGg//7//f/+upLTNwB7ahqbgTyuQACCYAqW//7+/v3////+YQ+YPQB+k1m4/v7+///8/Pv/kli3NgB7WgCWtIjLWQCUOgB/lla2/f////7///7//////f//k1O2MQF5XQWU/P7+////axefKgBzm2K9+fj8UQCLMwB5wZ/b/f///P7+YgyaVgGRXQqVbx2ebB+faxidTgCKSgyIxafY2MblQQCFOAB9sonM/f///f/+///////////+uo/SMQB7UgGM////1cTlPwB+MgF7s4fM/f/+dSSjLAB1cBuh/v3////+Yw2ZXACWVACOTgCJRACDMAB4PAB9i0Oz//7/0rvhQACAOAB9r4bJ/f/////////+///////+s4rOMwB5TwCO////oHC/MQF5TgCK6Nvx///+pXbFOQB8PwCF07/i////YgyYPgCEik6y9ev76NzuvJbSVAuPQgaC4M3o8u32QwCHOwCAjEm2//////7//////////P7+iESxMQF5cSCe7+P1aBScLQB4iUSz/f/+//3+8On2UAKMLwFyq3PG///+YQ+YNwF8oGy//////f/+/P7+eiypHgFolF26////cSSjNAF6VgmQ28vq///+/f///f/+z7rgSgGHNAF7ll24wqLYOgF8RACDzrbe/f////7//f//jEqzLAF0aRWd/Pv9YgyaSwGJfjiq07nhyazdnmS9UgGMJwBzq33J////3cvqNwF6OAF8UQCNqXrGw6TXoG3EVACPOQF+RACG4svrgkCxNQB5ZA2Z///+/////////v/90LXhQwCCMwB7xqfaPgCCQwCEOQB7LAB3KgF0IgBsLAB3fDOn+fX6/v7+///+vJHUTQGJKwBzNwB7RQCGNgB6LQB1TACH17jl7+bzLQF2GwBogDyr//7///7//////f//8+zzRwCGFwJlZhOYlmK8kFi3lFa6jVG1jlK2kmG1tZjP/////////f///////f//5tbulGO5ZiGaWg2UaiadlWi35dPw///+073ge0urfk+s17/i+////f/////+//7///7/q3nHgU+tmWG6/////////f/////////+//////////7////+//7////////+/////f/////+//7//f////////7////+/f/+///////++v7//v3///7///7//////f/////+//////7///3////////+/f///f////7////+/f/+/f//////+//+/////f/////+/////////f/+//7////+//////7//////v7+///+///+/v3////8//7//f/+//////7////+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABABgAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/v7+/v7+//7+/v7+/f79//7////+/v7+/f/+/v7+/f7+//7+/v////7+/f7+ZiGbXg+UVxGQcESh7uXz5tnvajydVAuNUxqOq4rH/v7+/v/+h1ywZS2Z+Pb6/f7/UAaMwKDX593wZCuYlm26bz+ge0On5djuv57VPQB/y63c6uDxTgaKTw+NvJbS/v7+VQeQl1+6tIzNWBmRqn3HQwCF0Lfg/v7+/v/+azifqoDHn3bAajqdr4bKZC6a/f7+VwaSiE6xhlyuVxWQ6NzvPQCBzbPf//7+/v7+ZzOcq4DIWSGTr4fL5NbtPQB/38zpUQeNvJfS2MPlRAuEz7bgbjygbjWg2sfmsInMPgCBr4LLRQOE8uz2/v7+ckCil227aS6eYSmYWy2Sl3K7/Pz97eP0fE6oTwuLWCOQwaLWmnu9fFKo/f7//v7+uZjPZTGZ//7//v/+/v7+/v7+/v7+/v/+/v/+//7+/v7+//7+/v7+/f7+/v3+//7+/v/+//7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
        />
        <style>
            .ssQIHO-checkbox-menu-item > span > span {
                background-color: #000;
                display: inline-block;
            }
            @media (forced-colors: active), (prefers-contrast: more) {
                .ssQIHO-checkbox-menu-item > span > span {
                    background-color: ButtonText;
                }
            }
        </style>
        <style>
            .gm-style .gm-style-mtc label,
            .gm-style .gm-style-mtc div {
                font-weight: 400;
            }
            .gm-style .gm-style-mtc ul,
            .gm-style .gm-style-mtc li {
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            .gm-style-mtc-bbw {
                display: -webkit-box;
                display: -webkit-flex;
                display: flex;
                -webkit-flex-wrap: wrap;
                flex-wrap: wrap;
            }
            .gm-style-mtc-bbw .gm-style-mtc:first-of-type > button {
                border-start-start-radius: 2px;
                border-end-start-radius: 2px;
            }
            .gm-style-mtc-bbw .gm-style-mtc:last-of-type > button {
                border-start-end-radius: 2px;
                border-end-end-radius: 2px;
            }
            sentinel {
            }
        </style>
        <style>
            .LGLeeN-keyboard-shortcuts-view {
                display: -webkit-box;
                display: -webkit-flex;
                display: -moz-box;
                display: -ms-flexbox;
                display: flex;
            }
            .LGLeeN-keyboard-shortcuts-view table,
            .LGLeeN-keyboard-shortcuts-view tbody,
            .LGLeeN-keyboard-shortcuts-view td,
            .LGLeeN-keyboard-shortcuts-view tr {
                background: inherit;
                border: none;
                margin: 0;
                padding: 0;
            }
            .LGLeeN-keyboard-shortcuts-view table {
                display: table;
            }
            .LGLeeN-keyboard-shortcuts-view tr {
                display: table-row;
            }
            .LGLeeN-keyboard-shortcuts-view td {
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                display: table-cell;
                color: light-dark(#000, #fff);
                padding: 6px;
                vertical-align: middle;
                white-space: nowrap;
            }
            .LGLeeN-keyboard-shortcuts-view td:first-child {
                text-align: end;
            }
            .LGLeeN-keyboard-shortcuts-view td kbd {
                background-color: light-dark(#e8eaed, #3c4043);
                border-radius: 2px;
                border: none;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                color: inherit;
                display: inline-block;
                font-family:
                    Google Sans Text,
                    Roboto,
                    Arial,
                    sans-serif;
                line-height: 16px;
                margin: 0 2px;
                min-height: 20px;
                min-width: 20px;
                padding: 2px 4px;
                position: relative;
                text-align: center;
            }
        </style>
        <style>
            .gm-control-active > img {
                -webkit-box-sizing: content-box;
                box-sizing: content-box;
                display: none;
                left: 50%;
                pointer-events: none;
                position: absolute;
                top: 50%;
                -webkit-transform: translate(-50%, -50%);
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            .gm-control-active > img:nth-child(1) {
                display: block;
            }
            .gm-control-active:focus > img:nth-child(1),
            .gm-control-active:hover > img:nth-child(1),
            .gm-control-active:active > img:nth-child(1),
            .gm-control-active:disabled > img:nth-child(1) {
                display: none;
            }
            .gm-control-active:focus > img:nth-child(2),
            .gm-control-active:hover > img:nth-child(2) {
                display: block;
            }
            .gm-control-active:active > img:nth-child(3) {
                display: block;
            }
            .gm-control-active:disabled > img:nth-child(4) {
                display: block;
            }
            sentinel {
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Google+Sans:400,500,700|Google+Sans+Text:400,500,700&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFp2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qE52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFB2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFJ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qCR2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFx2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qF52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qER2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEp2iw.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400&text=%E2%86%90%E2%86%92%E2%86%91%E2%86%93&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/l/font?kit=5aUu9-KzpRiLCAt4Unrc-xIKmCU5mEhkgo3FI_E8lH570oBdIw&skey=b20c8ebc9802c116&v=v24*/
                    url() format("woff2");
            }
        </style>

        <!--!-->
        <title>BOV – Appointment mobile</title>
        <!--!-->
        <!--!-->
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/map.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/marker.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/log.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/onion.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/controls.js"
        ></script>
        <style id="savepage-cssvariables">
            :root {
                --savepage-url-14: url(data:image/bmp;base64,AAACAAEAICACAAgACAAwAQAAFgAAACgAAAAgAAAAQAAAAAEAAQAAAAAAAAEAAAAAAAAAAAAAAgAAAAAAAAAAAAAA////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAA/AAAAfwAAAP+AAAH/gAAB/8AAA//AAAd/wAAGf+AAAH9gAADbYAAA2yAAAZsAAAGbAAAAGAAAAAAAAA//////////////////////////////////////////////////////////////////////////////////////gH///4B///8Af//+AD///AA///wAH//4AB//8AAf//AAD//5AA///gAP//4AD//8AF///AB///5A////5///8=);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>

        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body tabindex="-1">
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->

        <!--!--><!--!--><!--!-->

        <main>
            <!--!-->
            <nav class="navbar" b-0h6h1p6wgv="">
                <div class="nav-container" style="" b-0h6h1p6wgv="">
                    <!--!--><a href="https://www.word.com/" target="_blank" class="navbar-brand" b-0h6h1p6wgv=""
                        ><img
                            data-savepage-currentsrc="https://space.word.com/assets/img/bov-logo.svg"
                            data-savepage-src="/assets/img/bov-logo.svg"
                            src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iNTIiIHZpZXdCb3g9IjAgMCA4MCA1MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8xNjQ3XzgyKSI+DQo8cGF0aCBkPSJNNC42MDE2OSA0OS4zMzM2QzQuNDYzMDcgNDkuNTMxMiA0LjI3OTczIDQ5LjY4NDkgNC4wNTEyNyA0OS43OTUzQzMuODIyMTYgNDkuOTA1NyAzLjU1NTg5IDQ5Ljk4MjggMy4yNTI0NiA1MC4wMjU4QzIuOTQ4MzkgNTAuMDY5OSAyLjYyNjkyIDUwLjA5MDcgMi4yODc3NCA1MC4wOTA3QzIuMTA1OTkgNTAuMDkwNyAxLjk0NjA0IDUwLjA4OTIgMS44MDgzNSA1MC4wODU2QzEuNjcwMzYgNTAuMDgxNSAxLjU0OTkyIDUwLjA3NTIgMS40NDc1MiA1MC4wNjc1QzEuMzI5MTMgNTAuMDU5NSAxLjIyNjI2IDUwLjA1MTggMS4xMzk1NCA1MC4wNDM4VjQ3LjE1NjNIMi42MTg5M0MyLjk1MDU5IDQ3LjE1NjMgMy4yNTAyNiA0Ny4xNzk1IDMuNTE4NDEgNDcuMjI2NUMzLjc4Njg4IDQ3LjI3NDcgNC4wMTc1NSA0Ny4zNTI5IDQuMjExMDUgNDcuNDYzM0M0LjQwNDEgNDcuNTc0MiA0LjU1MjI4IDQ3LjcyMjIgNC42NTQ1MiA0Ny45MDcyQzQuNzU3MDkgNDguMDkzMiA0LjgwODg0IDQ4LjMxOTcgNC44MDg4NCA0OC41ODc4QzQuODA4ODQgNDguODg4MSA0LjczOTIzIDQ5LjEzNjUgNC42MDE2OSA0OS4zMzM2VjQ5LjMzMzZaTTEuMTM5NTQgNDMuNjk5N0MxLjI3MzYyIDQzLjY4NDEgMS40MjM4NSA0My42NzI1IDEuNTg5MjggNDMuNjY0NEMxLjc1NTA0IDQzLjY1NjggMS45ODM4MyA0My42NTI4IDIuMjc1NjYgNDMuNjUyOEMyLjU2NzY1IDQzLjY1MjggMi44NDM4IDQzLjY3NjUgMy4xMDQyNyA0My43MjM0QzMuMzY0NzQgNDMuNzcwNSAzLjU5MTE4IDQzLjg0NDMgMy43ODQ2OCA0My45NDNDMy45NzgyIDQ0LjA0MSA0LjEzIDQ0LjE3MTIgNC4yNDAzOSA0NC4zMzMzQzQuMzUwNzkgNDQuNDk1IDQuNDA2MzEgNDQuNjk0MSA0LjQwNjMxIDQ0LjkzMUM0LjQwNjMxIDQ1LjE4MzUgNC4zNTI2OCA0NS4zOTI3IDQuMjQ2NSA0NS41NThDNC4xNDAwMyA0NS43MjM1IDMuOTkzODggNDUuODU3NSAzLjgwODM3IDQ1Ljk2MDRDMy42MjMwMSA0Ni4wNjMxIDMuNDA0MjYgNDYuMTM0NiAzLjE1MTc4IDQ2LjE3MzVDMi44OTkgNDYuMjEyOSAyLjYzMDg1IDQ2LjIzMzMgMi4zNDY3IDQ2LjIzMzNIMS4xMzk1NFY0My42OTk3Wk00LjQxODIzIDQ2LjU5OTRDNC43NzI5NSA0Ni40NTczIDUuMDU3MjUgNDYuMjQyNSA1LjI3MDAyIDQ1Ljk1NTFDNS40ODMxNSA0NS42NjczIDUuNTg5NjEgNDUuMjk3OCA1LjU4OTYxIDQ0Ljg0NzlDNS41ODk2MSA0NC40NDU3IDUuNTAyOSA0NC4xMDYgNS4zMjk0NyA0My44MzAyQzUuMTU1NTcgNDMuNTU0IDQuOTE2ODcgNDMuMzMxMiA0LjYxMzMgNDMuMTYxNEM0LjMwOTQgNDIuOTkyIDMuOTUwNDQgNDIuODcxOSAzLjUzNjI5IDQyLjgwMDZDMy4xMjE5OSA0Mi43MjkxIDIuNjc4MzYgNDIuNjkzOCAyLjIwNDYyIDQyLjY5MzhDMi4wMzkzNCA0Mi42OTM4IDEuODYxMzYgNDIuNjk3NyAxLjY3MjQgNDIuNzA1OUMxLjQ4MjgxIDQyLjcxMzQgMS4yOTEzNCA0Mi43MjU1IDEuMDk4MyA0Mi43NDExQzAuOTA0Nzg5IDQyLjc1NzYgMC43MTM2MjkgNDIuNzc3MiAwLjUyNDA0MyA0Mi44MDA2QzAuMzM0NzY3IDQyLjgyNDMgMC4xNjEzMyA0Mi44NTY0IDAuMDAzNDE3OTcgNDIuODk1M1Y1MC44NDgzQzAuMTYxMzMgNTAuODg4NCAwLjMzNDc2NyA1MC45MTk4IDAuNTI0MDQzIDUwLjk0M0MwLjcxMzYyOSA1MC45Njc1IDAuOTA0Nzg5IDUwLjk4NjUgMS4wOTgzIDUxLjAwMjlDMS4yOTEzNCA1MS4wMTg0IDEuNDg0ODUgNTEuMDMwMiAxLjY3Nzg4IDUxLjAzODJDMS44NzE1NSA1MS4wNDU5IDIuMDUwOTQgNTEuMDQ5OCAyLjIxNjcgNTEuMDQ5OEMzLjUyNjEgNTEuMDQ5OCA0LjQ4MzMxIDUwLjg0MjcgNS4wODY3MiA1MC40MjhDNS42OTAyOSA1MC4wMTQgNS45OTIxOCA0OS4zOTcxIDUuOTkyMTggNDguNTc2MUM1Ljk5MjE4IDQ4LjAxNjEgNS44NTAxMSA0Ny41ODE3IDUuNTY1OTIgNDcuMjc0N0M1LjI4MjEgNDYuOTY2MyA0Ljg5OTE2IDQ2Ljc0MTUgNC40MTgyMyA0Ni41OTk0IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTAuNTEzNSA1MC4xMDI3QzEwLjM3ODkgNTAuMTM0OSAxMC4yMTE2IDUwLjE1NTggMTAuMDEwNCA1MC4xNjg2QzkuODA4ODggNTAuMTc5NCA5LjU3ODM3IDUwLjE4NTkgOS4zMTc4NyA1MC4xODU5QzguODgzODIgNTAuMTg1OSA4LjU0MDcxIDUwLjEwODkgOC4yODgyNCA0OS45NTVDOC4wMzU3NyA0OS44MDE3IDcuOTA5NjggNDkuNTI3MSA3LjkwOTY4IDQ5LjEzMjhDNy45MDk2OCA0OC45MTkzIDcuOTYwNjYgNDguNzQ3OSA4LjA2MzM1IDQ4LjYxNzRDOC4xNjU2IDQ4LjQ4NzQgOC4yOTQxOCA0OC4zODQ1IDguNDQ3OSA0OC4zMTA0QzguNjAxNTcgNDguMjM0OCA4Ljc3MTU0IDQ4LjE4NTUgOC45NTcwNSA0OC4xNjIyQzkuMTQyMDcgNDguMTM3NyA5LjMxNzg3IDQ4LjEyNjkgOS40ODM2MiA0OC4xMjY5QzkuNzM1ODEgNDguMTI2OSA5Ljk1MDk1IDQ4LjE0MDEgMTAuMTI4NSA0OC4xNjczQzEwLjMwNjEgNDguMTk1OSAxMC40MzQyIDQ4LjIyOTYgMTAuNTEzNSA0OC4yNjg2VjUwLjEwMjdaTTExLjA3NTMgNDUuMzI2OEMxMC44OSA0NS4xMTg0IDEwLjY0NTUgNDQuOTU2NyAxMC4zNDE0IDQ0Ljg0MjJDMTAuMDM3NyA0NC43Mjc4IDkuNjY1MDggNDQuNjcwNCA5LjIyMzE3IDQ0LjY3MDRDOC44MzY0NSA0NC42NzA0IDguNDc3NTIgNDQuNzAwNSA4LjE0NjE3IDQ0Ljc1OTFDNy44MTQ4MiA0NC44MTg1IDcuNTc4MDQgNDQuODgwMSA3LjQzNTkzIDQ0Ljk0MjZMNy41NjYyOCA0NS44NTM5QzcuNzAwMzIgNDUuNzk4OCA3LjkwMzU4IDQ1Ljc0NTUgOC4xNzU2NCA0NS42OTM3QzguNDQ3OSA0NS42NDI4IDguNzY1NDQgNDUuNjE3OSA5LjEyODMxIDQ1LjYxNzlDOS40MTI2MSA0NS42MTc5IDkuNjQzNDQgNDUuNjU4MyA5LjgyMDggNDUuNzQxNEM5Ljk5ODMyIDQ1LjgyNDUgMTAuMTM4MyA0NS45MzU0IDEwLjI0MSA0Ni4wNzMxQzEwLjM0MzYgNDYuMjExMiAxMC40MTQ3IDQ2LjM2OSAxMC40NTQgNDYuNTQ2QzEwLjQ5MzIgNDYuNzI0MiAxMC41MTM1IDQ2LjkwMzYgMTAuNTEzNSA0Ny4wODQ3VjQ3LjM5M0MxMC40ODE2IDQ3LjM4NSAxMC40MjYxIDQ3LjM3MzQgMTAuMzQ3NSA0Ny4zNTc3QzEwLjI2ODUgNDcuMzQxMiAxMC4xNzU3IDQ3LjMyNCAxMC4wNjkzIDQ3LjMwNDJDOS45NjMwMyA0Ny4yODM4IDkuODUwNTkgNDcuMjY4MiA5LjczMjA0IDQ3LjI1NjZDOS42MTM2NSA0Ny4yNDQ1IDkuNDk5MzIgNDcuMjM5MyA5LjM4ODkyIDQ3LjIzOTNDOS4wNDE3MSA0Ny4yMzkzIDguNzEwMDggNDcuMjc0NiA4LjM5NDU0IDQ3LjM0NDlDOC4wNzkwNSA0Ny40MTY0IDcuODAyODkgNDcuNTI3MSA3LjU2NjI4IDQ3LjY3NjhDNy4zMjk0NyA0Ny44MjY2IDcuMTQyMDcgNDguMDI0IDcuMDAzOTQgNDguMjY4NkM2Ljg2NTkyIDQ4LjUxMzQgNi43OTY2MyA0OC44MDQ5IDYuNzk2NjMgNDkuMTQ0NUM2Ljc5NjYzIDQ5LjQ5OTggNi44NTYyMSA0OS44MDI5IDYuOTc0MjcgNTAuMDU1NEM3LjA5MjcgNTAuMzA3OSA3LjI1ODQ1IDUwLjUxMTEgNy40NzE1NCA1MC42NjQ4QzcuNjg0NTEgNTAuODE5NCA3LjkzNjk4IDUwLjkzMTQgOC4yMjkxMSA1MS4wMDI5QzguNTIwNjQgNTEuMDczNCA4Ljg0MDIzIDUxLjEwODQgOS4xODc3MiA1MS4xMDg0QzkuNDMyMzYgNTEuMTA4NCA5LjY3ODczIDUxLjA5OTEgOS45MjcyNiA1MS4wNzk1QzEwLjE3NTcgNTEuMDU5IDEwLjQwNjUgNTEuMDM4MSAxMC42MTk4IDUxLjAxNDVDMTAuODMyOSA1MC45OTA4IDExLjAyNCA1MC45NjUxIDExLjE5MzcgNTAuOTM3OEMxMS4zNjMxIDUwLjkwOTIgMTEuNDk1NSA1MC44ODg0IDExLjU5MDEgNTAuODcyN1Y0Ny4wMjU3QzExLjU5MDEgNDYuNjc4NCAxMS41NTA3IDQ2LjM2MDggMTEuNDcxOSA0Ni4wNzMxQzExLjM5MjkgNDUuNzg0OSAxMS4yNjA4IDQ1LjUzNjMgMTEuMDc1MyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMjMuMzQ4MiA0OS4xMzgxQzIzLjA5MTkgNDguODI3IDIyLjgzMTcgNDguNTM2OSAyMi41Njc1IDQ4LjI2ODhDMjIuMzAyOSA0OC4wMDA1IDIyLjA1MjYgNDcuNzc1NyAyMS44MTU2IDQ3LjU5MzhDMjIuMDIwOCA0Ny4zODEgMjIuMjQgNDcuMTU0NiAyMi40NzI5IDQ2LjkxMjlDMjIuNzA1MyA0Ni42NzMzIDIyLjkzNiA0Ni40MzE3IDIzLjE2NTEgNDYuMTkxNkMyMy4zOTM3IDQ1Ljk1MTIgMjMuNjE0OCA0NS43MTE5IDIzLjgyNzggNDUuNDc0OUMyNC4wNDA3IDQ1LjIzODIgMjQuMjM4IDQ1LjAyMTggMjQuNDE5OSA0NC44MjQzSDIzLjEyOTVDMjIuOTg3NCA0NC45ODk2IDIyLjgxNzYgNDUuMTgyIDIyLjYyMDUgNDUuMzk4M0MyMi40MjM1IDQ1LjYxNTUgMjIuMjE0MyA0NS44NDE5IDIxLjk5MzUgNDYuMDc4OEMyMS43NzIzIDQ2LjMxNTcgMjEuNTQ3NCA0Ni41NDg1IDIxLjMxODggNDYuNzc3M0MyMS4wODk4IDQ3LjAwNjUgMjAuODgwNiA0Ny4yMTUgMjAuNjkxNyA0Ny40MDQ3VjQxLjc5NDVMMTkuNTkwOCA0MS45ODM2VjUwLjk3ODVIMjAuNjkxN1Y0OC4wMjAyQzIwLjkxMjMgNDguMTcgMjEuMTQ1MiA0OC4zNTUgMjEuMzg5NiA0OC41NzYxQzIxLjYzNDEgNDguNzk3NCAyMS44NzUgNDkuMDM5NSAyMi4xMTE2IDQ5LjMwMzZDMjIuMzQ4NCA0OS41Njg2IDIyLjU3NTIgNDkuODQ0NyAyMi43OTIzIDUwLjEzMjdDMjMuMDA5MiA1MC40MjEyIDIzLjIwMDcgNTAuNzAyNyAyMy4zNjY1IDUwLjk3ODVIMjQuNjU2M0MyNC40OTg1IDUwLjcwMjcgMjQuMzA1IDUwLjQwNDcgMjQuMDc2NiA1MC4wODU2QzIzLjg0NzQgNDkuNzY1NyAyMy42MDQ4IDQ5LjQ1MDUgMjMuMzQ4MiA0OS4xMzgxIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTcuNTQ5MSA0NS40ODE0QzE3LjM1NiA0NS4yMzMgMTcuMDk3NCA0NS4wMzkgMTYuNzczOCA0NC45MDEzQzE2LjQ1MDQgNDQuNzYzMyAxNi4wNDQgNDQuNjk0MiAxNS41NTUyIDQ0LjY5NDJDMTUuMDEwNCA0NC42OTQyIDE0LjUyOSA0NC43MzA0IDE0LjExMTEgNDQuODAxQzEzLjY5MjkgNDQuODcxMiAxMy4zNTc2IDQ0LjkzODcgMTMuMTA1MSA0NS4wMDIyVjUwLjk3ODVIMTQuMjA1OFY0NS43ODM0QzE0LjI0NTIgNDUuNzc1MyAxNC4zMTAyIDQ1Ljc2MzcgMTQuNDAxIDQ1Ljc0NzJDMTQuNDkxOCA0NS43MzIzIDE0LjU5NDUgNDUuNzE4MyAxNC43MDg3IDQ1LjcwNjNDMTQuODIyOCA0NS42OTM5IDE0Ljk0MzQgNDUuNjg0NiAxNS4wNjk5IDQ1LjY3NjZDMTUuMTk1OSA0NS42Njg5IDE1LjMxODIgNDUuNjY0OSAxNS40MzY4IDQ1LjY2NDlDMTUuNzI4NSA0NS42NjQ5IDE1Ljk3MzEgNDUuNzAyNiAxNi4xNzA1IDQ1Ljc3N0MxNi4zNjc2IDQ1Ljg1MjQgMTYuNTI1NCA0NS45NzIxIDE2LjY0MzggNDYuMTM4NkMxNi43NjIyIDQ2LjMwNCAxNi44NDY5IDQ2LjUyMTIgMTYuODk4MyA0Ni43ODk0QzE2Ljk0OTMgNDcuMDU3NSAxNi45NzU0IDQ3LjM4MSAxNi45NzU0IDQ3Ljc2MDFWNTAuOTc4NUgxOC4wNzU4VjQ3LjUyMzNDMTguMDc1OCA0Ny4xMDUzIDE4LjAzNjMgNDYuNzIyNyAxNy45NTc3IDQ2LjM3NTFDMTcuODc4NyA0Ni4wMjc5IDE3Ljc0MjYgNDUuNzI5OSAxNy41NDkxIDQ1LjQ4MTQiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS40MjEgNDkuNTUyOEMzMS4xMDk1IDQ5Ljk1OTEgMzAuNjg1MyA1MC4xNjIyIDMwLjE0OSA1MC4xNjIyQzI5LjYxMiA1MC4xNjIyIDI5LjE4ODIgNDkuOTU5MSAyOC44NzY3IDQ5LjU1MjhDMjguNTY0NyA0OS4xNDYyIDI4LjQwOTEgNDguNTk2NSAyOC40MDkxIDQ3LjkwMTdDMjguNDA5MSA0Ny4yMDcyIDI4LjU2NDcgNDYuNjU2OCAyOC44NzY3IDQ2LjI1MDRDMjkuMTg4MiA0NS44NDQzIDI5LjYxMiA0NS42NDExIDMwLjE0OSA0NS42NDExQzMwLjY4NTMgNDUuNjQxMSAzMS4xMDk1IDQ1Ljg0NDMgMzEuNDIxIDQ2LjI1MDRDMzEuNzMzIDQ2LjY1NjggMzEuODg4OCA0Ny4yMDcyIDMxLjg4ODggNDcuOTAxN0MzMS44ODg4IDQ4LjU5NjUgMzEuNzMzIDQ5LjE0NjIgMzEuNDIxIDQ5LjU1MjhWNDkuNTUyOFpNMzIuMjI2IDQ1LjU1NzlDMzEuOTY5MyA0NS4yNzQxIDMxLjY2NCA0NS4wNTQ2IDMxLjMwODYgNDQuOTAxMkMzMC45NTM4IDQ0Ljc0NzUgMzAuNTY3MiA0NC42NzA0IDMwLjE0OSA0NC42NzA0QzI5LjczMDYgNDQuNjcwNCAyOS4zNDM5IDQ0Ljc0NzUgMjguOTg5IDQ0LjkwMTJDMjguNjMzNyA0NS4wNTQ2IDI4LjMyNzkgNDUuMjc0MSAyOC4wNzE3IDQ1LjU1NzlDMjcuODE1MyA0NS44NDE4IDI3LjYxNjMgNDYuMTgzOCAyNy40NzQgNDYuNTgxM0MyNy4zMzIgNDYuOTgwMyAyNy4yNjA3IDQ3LjQyMDMgMjcuMjYwNyA0Ny45MDE3QzI3LjI2MDcgNDguMzkxIDI3LjMzMiA0OC44MzIyIDI3LjQ3NCA0OS4yMjY4QzI3LjYxNjMgNDkuNjIxOCAyNy44MTUzIDQ5Ljk2MDcgMjguMDcxNyA1MC4yNDQ1QzI4LjMyNzkgNTAuNTI5MSAyOC42MzM3IDUwLjc0NzkgMjguOTg5IDUwLjkwMjVDMjkuMzQzOSA1MS4wNTYyIDI5LjczMDYgNTEuMTMyMSAzMC4xNDkgNTEuMTMyMUMzMC41NjcyIDUxLjEzMjEgMzAuOTUzOCA1MS4wNTYyIDMxLjMwODYgNTAuOTAyNUMzMS42NjQgNTAuNzQ3OSAzMS45NjkzIDUwLjUyOTEgMzIuMjI2IDUwLjI0NDVDMzIuNDgyNSA0OS45NjA3IDMyLjY4MTcgNDkuNjIxOCAzMi44MjM2IDQ5LjIyNjhDMzIuOTY1NyA0OC44MzIyIDMzLjAzNjkgNDguMzkxIDMzLjAzNjkgNDcuOTAxN0MzMy4wMzY5IDQ3LjQyMDMgMzIuOTY1NyA0Ni45ODAzIDMyLjgyMzYgNDYuNTgxM0MzMi42ODE3IDQ2LjE4MzggMzIuNDgyNSA0NS44NDE4IDMyLjIyNiA0NS41NTc5WiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTM2LjY4MiA0MS43OTQ1QzM1Ljg1MzQgNDEuNzk0NSAzNS4yNDU5IDQyLjAwOTQgMzQuODU5NCA0Mi40NDAxQzM0LjQ3MjUgNDIuODY5NiAzNC4yNzkyIDQzLjQ3OTggMzQuMjc5MiA0NC4yNjgzVjUwLjk3ODVIMzUuMzhWNDUuNzQ3MkgzNy43NDY5VjQ0LjgyNDNIMzUuMzhWNDQuMjkxOUMzNS4zOCA0My44MTgyIDM1LjQ4MjQgNDMuNDQyMiAzNS42ODggNDMuMTYxNUMzNS44OTI2IDQyLjg4MTMgMzYuMjUxOSA0Mi43NDEyIDM2Ljc2NDcgNDIuNzQxMkMzNy4wMTcyIDQyLjc0MTIgMzcuMjMwMiA0Mi43NjI5IDM3LjQwMzcgNDIuODA3MUMzNy41Nzc2IDQyLjg1IDM3LjcxMTcgNDIuODk1MyAzNy44MDY0IDQyLjk0MjdMMzguMDA3NCA0MS45OTUyQzM3LjkxMjkgNDEuOTU2NCAzNy43NDkgNDEuOTEzMSAzNy41MTYzIDQxLjg2NTJDMzcuMjgzNyA0MS44MTgyIDM3LjAwNTQgNDEuNzk0NSAzNi42ODIgNDEuNzk0NSIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTYxLjI2NjUgNDcuMzFDNjEuMjkwMiA0Ny4wOTY0IDYxLjMzOTIgNDYuODg4MSA2MS40MTM5IDQ2LjY4MjVDNjEuNDg5MyA0Ni40NzcgNjEuNTkzNyA0Ni4yOTYgNjEuNzI4MiA0Ni4xMzg1QzYxLjg2MjMgNDUuOTggNjIuMDI1NyA0NS44NTI0IDYyLjIxOTIgNDUuNzUzNkM2Mi40MTIzIDQ1LjY1NDUgNjIuNjM1NSA0NS42MDUxIDYyLjg4OCA0NS42MDUxQzYzLjMzNzIgNDUuNjA1MSA2My42OTA5IDQ1Ljc2NTIgNjMuOTQ3IDQ2LjA4NTJDNjQuMjAzNSA0Ni40MDQzIDY0LjMyOCA0Ni44MTI1IDY0LjMxOTkgNDcuMzFINjEuMjY2NVpNNjIuODk5NiA0NC42NzA1QzYyLjU0NDcgNDQuNjcwNSA2Mi4xOTc1IDQ0LjczNzEgNjEuODU4MyA0NC44NzEyQzYxLjUxOTEgNDUuMDA2IDYxLjIxOTIgNDUuMjA2NyA2MC45NTg2IDQ1LjQ3NDlDNjAuNjk4NSA0NS43NDMyIDYwLjQ4OTMgNDYuMDgxMiA2MC4zMzE2IDQ2LjQ4NzVDNjAuMTczNCA0Ni44OTMzIDYwLjA5NDcgNDcuMzY4NiA2MC4wOTQ3IDQ3LjkxMzRDNjAuMDk0NyA0OC4zNzk0IDYwLjE1NTcgNDguODA2NiA2MC4yNzgyIDQ5LjE5OEM2MC40MDAyIDQ5LjU4ODIgNjAuNTg3NyA0OS45MjU1IDYwLjg0MDIgNTAuMjA5M0M2MS4wOTI3IDUwLjQ5MyA2MS40MTM5IDUwLjcxNjYgNjEuODA0OSA1MC44NzgxQzYyLjE5NTUgNTEuMDM5OCA2Mi42NTkyIDUxLjEyMTMgNjMuMTk1NSA1MS4xMjEzQzYzLjYyMTQgNTEuMTIxMyA2NC4wMDI0IDUxLjA4MTIgNjQuMzM3NiA1MS4wMDI5QzY0LjY3MzIgNTAuOTIzNCA2NC45MDc3IDUwLjg0ODMgNjUuMDQxNyA1MC43Nzc4TDY0Ljg4OCA0OS44NTRDNjQuNzUzOSA0OS45MTc4IDY0LjU1NDggNDkuOTgyOSA2NC4yODk4IDUwLjA1MDNDNjQuMDI2MSA1MC4xMTY5IDYzLjcwMDUgNTAuMTUwNyA2My4zMTM5IDUwLjE1MDdDNjIuNjI3NCA1MC4xNTA3IDYyLjEyMjQgNDkuOTg1MiA2MS43OTg1IDQ5LjY1MzJDNjEuNDc1MyA0OS4zMjE2IDYxLjI5MDIgNDguODM2MiA2MS4yNDI5IDQ4LjE5NzJINjUuNDU2QzY1LjQ2NDEgNDguMTM0NSA2NS40NjgxIDQ4LjA2NTUgNjUuNDY4MSA0Ny45OTA0QzY1LjQ2ODEgNDcuOTE1IDY1LjQ2ODEgNDcuODUzOSA2NS40NjgxIDQ3LjgwNjlDNjUuNDY4MSA0Ni43NDkyIDY1LjI0NjkgNDUuOTYyNyA2NC44MDUzIDQ1LjQ0NTNDNjQuMzYzMyA0NC45MjkzIDYzLjcyODIgNDQuNjcwNSA2Mi44OTk2IDQ0LjY3MDVaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzQuMTYxIDUwLjAyNThDNzMuOTU5OCA1MC4xMDEyIDczLjY5MzMgNTAuMTM4NSA3My4zNjIxIDUwLjEzODVDNzMuMTcyMiA1MC4xMzg1IDczLjAwNzIgNTAuMTE1MSA3Mi44NjUxIDUwLjA2NzVDNzIuNzIzIDUwLjAyMDEgNzIuNjA0MiA0OS45MzkzIDcyLjUwOTggNDkuODI1QzcyLjQxNTEgNDkuNzEwNiA3Mi4zNDQ0IDQ5LjU1MjggNzIuMjk3MSA0OS4zNTEzQzcyLjI0OTcgNDkuMTUwMSA3Mi4yMjYgNDguODk2MSA3Mi4yMjYgNDguNTg3OFY0NS43NDcxSDc0LjU1NzZWNDQuODI0Mkg3Mi4yMjZWNDIuOTE4OUw3MS4xMjUyIDQzLjEwOFY0OC41OTk0QzcxLjEyNTIgNDkuMDEwNCA3MS4xNTg2IDQ5LjM3MDkgNzEuMjI1NiA0OS42ODMzQzcxLjI5MjYgNDkuOTk0NCA3MS40MDkxIDUwLjI1NjkgNzEuNTc0OSA1MC40Njk3QzcxLjc0MDcgNTAuNjgyOCA3MS45NTk0IDUwLjg0MjYgNzIuMjMxNiA1MC45NDg2QzcyLjUwMzggNTEuMDU2MiA3Mi44NDkgNTEuMTA4NCA3My4yNjc0IDUxLjEwODRDNzMuNjIyNiA1MS4xMDg0IDczLjkzNzggNTEuMDY3OCA3NC4yMTQ0IDUwLjk4NDdDNzQuNDkwMiA1MC45MDI1IDc0LjY4MzcgNTAuODMyNiA3NC43OTM3IDUwLjc3NzdMNzQuNTgxMyA0OS44NjY3Qzc0LjUwMjIgNDkuODk4MSA3NC4zNjIxIDQ5Ljk1MTQgNzQuMTYxIDUwLjAyNTgiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik02OS43MTEgNTAuMDI1OEM2OS41MDk1IDUwLjEwMTIgNjkuMjQyOSA1MC4xMzg1IDY4LjkxMjEgNTAuMTM4NUM2OC43MjIzIDUwLjEzODUgNjguNTU2OSA1MC4xMTUxIDY4LjQxNTIgNTAuMDY3NUM2OC4yNzMgNTAuMDIwMSA2OC4xNTQyIDQ5LjkzOTMgNjguMDU5OSA0OS44MjVDNjcuOTY1MSA0OS43MTA2IDY3Ljg5NDEgNDkuNTUyOCA2Ny44NDcxIDQ5LjM1MTNDNjcuNzk5NyA0OS4xNTAxIDY3Ljc3NjEgNDguODk2MSA2Ny43NzYxIDQ4LjU4NzhWNDUuNzQ3MUg3MC4xMDc2VjQ0LjgyNDJINjcuNzc2MVY0Mi45MTg5TDY2LjY3NTMgNDMuMTA4VjQ4LjU5OTRDNjYuNjc1MyA0OS4wMTA0IDY2LjcwODYgNDkuMzcwOSA2Ni43NzU3IDQ5LjY4MzNDNjYuODQyNyA0OS45OTQ0IDY2Ljk1OTEgNTAuMjU2OSA2Ny4xMjQ5IDUwLjQ2OTdDNjcuMjkwNyA1MC42ODI4IDY3LjUwOTUgNTAuODQyNiA2Ny43ODE3IDUwLjk0ODZDNjguMDUzNSA1MS4wNTYyIDY4LjM5OTEgNTEuMTA4NCA2OC44MTc0IDUxLjEwODRDNjkuMTcyNyA1MS4xMDg0IDY5LjQ4NzggNTEuMDY3OCA2OS43NjQ0IDUwLjk4NDdDNzAuMDQwMiA1MC45MDI1IDcwLjIzMzcgNTAuODMyNiA3MC4zNDQxIDUwLjc3NzdMNzAuMTMxMyA0OS44NjY3QzcwLjA1MjIgNDkuODk4MSA2OS45MTIxIDQ5Ljk1MTQgNjkuNzExIDUwLjAyNThaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzguOTI0NiA1MC4xMDI3Qzc4Ljc5MDUgNTAuMTM0OSA3OC42MjMxIDUwLjE1NTggNzguNDIxNSA1MC4xNjg2Qzc4LjIyMDQgNTAuMTc5NCA3Ny45ODkyIDUwLjE4NTkgNzcuNzI5NSA1MC4xODU5Qzc3LjI5NTEgNTAuMTg1OSA3Ni45NTE5IDUwLjEwODkgNzYuNjk5NyA0OS45NTVDNzYuNDQ2OCA0OS44MDE3IDc2LjMyMDggNDkuNTI3MSA3Ni4zMjA4IDQ5LjEzMjhDNzYuMzIwOCA0OC45MTkzIDc2LjM3MjIgNDguNzQ3OSA3Ni40NzQ5IDQ4LjYxNzRDNzYuNTc3MyA0OC40ODc0IDc2LjcwNTQgNDguMzg0NSA3Ni44NTk1IDQ4LjMxMDRDNzcuMDEzMyA0OC4yMzQ4IDc3LjE4MjcgNDguMTg1NSA3Ny4zNjgyIDQ4LjE2MjJDNzcuNTUzNiA0OC4xMzc3IDc3LjcyOTUgNDguMTI2OSA3Ny44OTQ4IDQ4LjEyNjlDNzguMTQ3NCA0OC4xMjY5IDc4LjM2MjUgNDguMTQwMSA3OC41NCA0OC4xNjczQzc4LjcxNzQgNDguMTk1OSA3OC44NDU5IDQ4LjIyOTYgNzguOTI0NiA0OC4yNjg2VjUwLjEwMjdaTTc5Ljg4MzIgNDYuMDczMUM3OS44MDQ1IDQ1Ljc4NDkgNzkuNjcyIDQ1LjUzNjMgNzkuNDg3IDQ1LjMyNjhDNzkuMzAxNSA0NS4xMTg0IDc5LjA1NjYgNDQuOTU2NyA3OC43NTMxIDQ0Ljg0MjJDNzguNDQ5MiA0NC43Mjc4IDc4LjA3NjMgNDQuNjcwNCA3Ny42MzQ3IDQ0LjY3MDRDNzcuMjQ4MSA0NC42NzA0IDc2Ljg4ODggNDQuNzAwNSA3Ni41NTc2IDQ0Ljc1OTFDNzYuMjI2IDQ0LjgxODUgNzUuOTg5NiA0NC44ODAxIDc1Ljg0NzUgNDQuOTQyNkw3NS45Nzc1IDQ1Ljg1MzlDNzYuMTExNiA0NS43OTg4IDc2LjMxNTIgNDUuNzQ1NSA3Ni41ODczIDQ1LjY5MzdDNzYuODU5NSA0NS42NDI4IDc3LjE3NzEgNDUuNjE3OSA3Ny41NCA0NS42MTc5Qzc3LjgyMzggNDUuNjE3OSA3OC4wNTQ2IDQ1LjY1ODMgNzguMjMyNSA0NS43NDE0Qzc4LjQwOTkgNDUuODI0NSA3OC41NSA0NS45MzU0IDc4LjY1MjQgNDYuMDczMUM3OC43NTUxIDQ2LjIxMTIgNzguODI1NCA0Ni4zNjkgNzguODY1NSA0Ni41NDZDNzguOTA0OSA0Ni43MjQyIDc4LjkyNDYgNDYuOTAzNiA3OC45MjQ2IDQ3LjA4NDdWNDcuMzkzQzc4Ljg5MjggNDcuMzg1IDc4LjgzNzggNDcuMzczNCA3OC43NTg4IDQ3LjM1NzdDNzguNjgwMSA0Ny4zNDEyIDc4LjU4NzMgNDcuMzI0IDc4LjQ4MSA0Ny4zMDQyQzc4LjM3MzggNDcuMjgzOCA3OC4yNjE4IDQ3LjI2ODIgNzguMTQzNyA0Ny4yNTY2Qzc4LjAyNTMgNDcuMjQ0NSA3Ny45MTA5IDQ3LjIzOTMgNzcuODAwNSA0Ny4yMzkzQzc3LjQ1MjkgNDcuMjM5MyA3Ny4xMjE3IDQ3LjI3NDYgNzYuODA2MSA0Ny4zNDQ5Qzc2LjQ5MDYgNDcuNDE2NCA3Ni4yMTQ0IDQ3LjUyNzEgNzUuOTc3NSA0Ny42NzY4Qzc1Ljc0MTEgNDcuODI2NiA3NS41NTM2IDQ4LjAyNCA3NS40MTUxIDQ4LjI2ODZDNzUuMjc3NCA0OC41MTM0IDc1LjIwODQgNDguODA0OSA3NS4yMDg0IDQ5LjE0NDVDNzUuMjA4NCA0OS40OTk4IDc1LjI2NzQgNDkuODAyOSA3NS4zODU4IDUwLjA1NTRDNzUuNTA0MiA1MC4zMDc5IDc1LjY3IDUwLjUxMTEgNzUuODgyNCA1MC42NjQ4Qzc2LjA5NiA1MC44MTk0IDc2LjM0ODUgNTAuOTMxNCA3Ni42NDAzIDUxLjAwMjlDNzYuOTMyMiA1MS4wNzM0IDc3LjI1MTcgNTEuMTA4NCA3Ny41OTkgNTEuMTA4NEM3Ny44NDM1IDUxLjEwODQgNzguMDkgNTEuMDk5MSA3OC4zMzg4IDUxLjA3OTVDNzguNTg3MyA1MS4wNTkgNzguODE4MiA1MS4wMzgxIDc5LjAzMTMgNTEuMDE0NUM3OS4yNDM3IDUwLjk5MDggNzkuNDM1NiA1MC45NjUxIDc5LjYwNTQgNTAuOTM3OEM3OS43NzQ4IDUwLjkwOTIgNzkuOTA2OSA1MC44ODg0IDgwLjAwMTYgNTAuODcyN1Y0Ny4wMjU3QzgwLjAwMTYgNDYuNjc4NCA3OS45NjIzIDQ2LjM2MDggNzkuODgzMiA0Ni4wNzMxWiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTU4Ljc5MjkgNDkuOTI1M0M1OC43MjE0IDQ5Ljg1MzggNTguNjcgNDkuNzU5MSA1OC42MzkxIDQ5LjY0MTRDNTguNjA3NCA0OS41MjMgNTguNTkxNyA0OS4zNzMzIDU4LjU5MTcgNDkuMTkxNFY0MS43OTQzTDU3LjQ5MSA0MS45ODM0VjQ5LjM2OTJDNTcuNDkxIDQ5Ljk1MjkgNTcuNjMyNyA1MC4zODMzIDU3LjkxNjUgNTAuNjU5QzU4LjIwMDcgNTAuOTM1MyA1OC42ODI1IDUxLjA4MSA1OS4zNjA5IDUxLjA5NjdMNTkuNTE1MSA1MC4xNzM3QzU5LjM0MTIgNTAuMTUwNSA1OS4xOTU1IDUwLjEyMDQgNTkuMDc3MSA1MC4wODU0QzU4Ljk1ODcgNTAuMDUwMSA1OC44NjM5IDQ5Ljk5NTggNTguNzkyOSA0OS45MjUzIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTEuOTk5NyA1MC4xMDI3QzUxLjg2NTYgNTAuMTM0OSA1MS42OTc4IDUwLjE1NTggNTEuNDk2NyA1MC4xNjg2QzUxLjI5NTUgNTAuMTc5NCA1MS4wNjQ3IDUwLjE4NTkgNTAuODA0MiA1MC4xODU5QzUwLjM3MDIgNTAuMTg1OSA1MC4wMjcgNTAuMTA4OSA0OS43NzQ1IDQ5Ljk1NUM0OS41MjE5IDQ5LjgwMTcgNDkuMzk1OSA0OS41MjcxIDQ5LjM5NTkgNDkuMTMyOEM0OS4zOTU5IDQ4LjkxOTMgNDkuNDQ2OSA0OC43NDc5IDQ5LjU0OTYgNDguNjE3NEM0OS42NTIgNDguNDg3NCA0OS43ODA1IDQ4LjM4NDUgNDkuOTM0MiA0OC4zMTA0QzUwLjA4OCA0OC4yMzQ4IDUwLjI1NzQgNDguMTg1NSA1MC40NDMzIDQ4LjE2MjJDNTAuNjI4NyA0OC4xMzc3IDUwLjgwNDIgNDguMTI2OSA1MC45NyA0OC4xMjY5QzUxLjIyMjUgNDguMTI2OSA1MS40Mzc2IDQ4LjE0MDEgNTEuNjE1MSA0OC4xNjczQzUxLjc5MjUgNDguMTk1OSA1MS45MjA2IDQ4LjIyOTYgNTEuOTk5NyA0OC4yNjg2VjUwLjEwMjdaTTUyLjU2MTcgNDUuMzI2OEM1Mi4zNzYyIDQ1LjExODQgNTIuMTMxNyA0NC45NTY3IDUxLjgyNzQgNDQuODQyMkM1MS41MjQ0IDQ0LjcyNzggNTEuMTUxNCA0NC42NzA0IDUwLjcwOSA0NC42NzA0QzUwLjMyMjQgNDQuNjcwNCA0OS45NjM5IDQ0LjcwMDUgNDkuNjMyMyA0NC43NTkxQzQ5LjMwMTEgNDQuODE4NSA0OS4wNjQzIDQ0Ljg4MDEgNDguOTIyNiA0NC45NDI2TDQ5LjA1MjMgNDUuODUzOUM0OS4xODYzIDQ1Ljc5ODggNDkuMzg5OSA0NS43NDU1IDQ5LjY2MiA0NS42OTM3QzQ5LjkzNDIgNDUuNjQyOCA1MC4yNTE4IDQ1LjYxNzkgNTAuNjE1MSA0NS42MTc5QzUwLjg5ODkgNDUuNjE3OSA1MS4xMjk3IDQ1LjY1ODMgNTEuMzA3MiA0NS43NDE0QzUxLjQ4NDYgNDUuODI0NSA1MS42MjQ3IDQ1LjkzNTQgNTEuNzI3MSA0Ni4wNzMxQzUxLjgyOTQgNDYuMjExMiA1MS45MDA5IDQ2LjM2OSA1MS45NDA2IDQ2LjU0NkM1MS45Nzk2IDQ2LjcyNDIgNTEuOTk5NyA0Ni45MDM2IDUxLjk5OTcgNDcuMDg0N1Y0Ny4zOTNDNTEuOTY3OSA0Ny4zODUgNTEuOTEyMSA0Ny4zNzM0IDUxLjgzMzkgNDcuMzU3N0M1MS43NTQ4IDQ3LjM0MTIgNTEuNjYyIDQ3LjMyNCA1MS41NTU3IDQ3LjMwNDJDNTEuNDQ5MyA0Ny4yODM4IDUxLjMzNjkgNDcuMjY4MiA1MS4yMTg0IDQ3LjI1NjZDNTEuMSA0Ny4yNDQ1IDUwLjk4NTYgNDcuMjM5MyA1MC44NzQ4IDQ3LjIzOTNDNTAuNTI4IDQ3LjIzOTMgNTAuMTk2NCA0Ny4yNzQ2IDQ5Ljg4MTIgNDcuMzQ0OUM0OS41NjUzIDQ3LjQxNjQgNDkuMjg5MSA0Ny41MjcxIDQ5LjA1MjMgNDcuNjc2OEM0OC44MTU4IDQ3LjgyNjYgNDguNjI4MyA0OC4wMjQgNDguNDkwMiA0OC4yNjg2QzQ4LjM1MjEgNDguNTEzNCA0OC4yODMxIDQ4LjgwNDkgNDguMjgzMSA0OS4xNDQ1QzQ4LjI4MzEgNDkuNDk5OCA0OC4zNDI1IDQ5LjgwMjkgNDguNDYwOSA1MC4wNTU0QzQ4LjU3OTMgNTAuMzA3OSA0OC43NDQ3IDUwLjUxMTEgNDguOTU3OSA1MC42NjQ4QzQ5LjE3MTEgNTAuODE5NCA0OS40MjM2IDUwLjkzMTQgNDkuNzE1NCA1MS4wMDI5QzUwLjAwNzMgNTEuMDczNCA1MC4zMjY4IDUxLjEwODQgNTAuNjczNyA1MS4xMDg0QzUwLjkxODYgNTEuMTA4NCA1MS4xNjUxIDUxLjA5OTEgNTEuNDE0IDUxLjA3OTVDNTEuNjYyIDUxLjA1OSA1MS44OTMzIDUxLjAzODEgNTIuMTA2IDUxLjAxNDVDNTIuMzE5MiA1MC45OTA4IDUyLjUxMDMgNTAuOTY1MSA1Mi42ODAxIDUwLjkzNzhDNTIuODQ5NSA1MC45MDkyIDUyLjk4MTYgNTAuODg4NCA1My4wNzY3IDUwLjg3MjdWNDcuMDI1N0M1My4wNzY3IDQ2LjY3ODQgNTMuMDM3IDQ2LjM2MDggNTIuOTU4MyA0Ni4wNzMxQzUyLjg3OTIgNDUuNzg0OSA1Mi43NDcyIDQ1LjUzNjMgNTIuNTYxNyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTUuODY5NSA0OS45MjUzQzU1Ljc5ODUgNDkuODUzOCA1NS43NDcxIDQ5Ljc1OTEgNTUuNzE1OCA0OS42NDE0QzU1LjY4NCA0OS41MjMgNTUuNjY4NCA0OS4zNzMzIDU1LjY2ODQgNDkuMTkxNFY0MS43OTQzTDU0LjU2NzYgNDEuOTgzNFY0OS4zNjkyQzU0LjU2NzYgNDkuOTUyOSA1NC43MDk3IDUwLjM4MzMgNTQuOTk0IDUwLjY1OUM1NS4yNzc4IDUwLjkzNTMgNTUuNzU4NyA1MS4wODEgNTYuNDM3NiA1MS4wOTY3TDU2LjU5MTcgNTAuMTczN0M1Ni40MTc5IDUwLjE1MDUgNTYuMjcyMiA1MC4xMjA0IDU2LjE1MzcgNTAuMDg1NEM1Ni4wMzUzIDUwLjA1MDEgNTUuOTQwNiA0OS45OTU4IDU1Ljg2OTUgNDkuOTI1MyIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTQ1Ljc4NiA0Ni4zODA3QzQ1LjM3NTcgNDcuNTM2NCA0NC45NTMgNDguNjE1OSA0NC41MTkgNDkuNjE4M0M0NC4wODUgNDguNjA3NSA0My42NjMxIDQ3LjUyNzIgNDMuMjUzMyA0Ni4zNzUxQzQyLjg0MyA0NS4yMjI1IDQyLjQyNDcgNDQuMDIzOCA0MS45OTg3IDQyLjc3NzNINDAuNzMyMkM0MS4wMjM2IDQzLjY0NTIgNDEuMzA3NCA0NC40NDgxIDQxLjU4NDQgNDUuMTg1OUM0MS44NTk4IDQ1LjkyMzQgNDIuMTMwNCA0Ni42MjM5IDQyLjM5NDYgNDcuMjg2M0M0Mi42NTk1IDQ3Ljk0ODcgNDIuOTE5NyA0OC41ODIyIDQzLjE3NjIgNDkuMTg2QzQzLjQzMjMgNDkuNzg4OSA0My42OTQ4IDUwLjM4NzUgNDMuOTYzNCA1MC45Nzg1SDQ1LjA0MDVDNDUuMzA4MiA1MC4zODc1IDQ1LjU3MDggNDkuNzg4OSA0NS44MjczIDQ5LjE4NkM0Ni4wODM4IDQ4LjU4MjIgNDYuMzQyIDQ3Ljk0ODcgNDYuNjAyNSA0Ny4yODYzQzQ2Ljg2MyA0Ni42MjM5IDQ3LjEyODggNDUuOTIzNCA0Ny40MDE0IDQ1LjE4NTlDNDcuNjczNiA0NC40NDgxIDQ3Ljk1OTggNDMuNjQ1MiA0OC4yNTk3IDQyLjc3NzNINDcuMDI4NEM0Ni42MTAxIDQ0LjAyMzggNDYuMTk2MiA0NS4yMjUgNDUuNzg2IDQ2LjM4MDciIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS4yNjM2IDExLjI0MDZDMzEuNjA5NyAxMC4wOTEzIDMyLjEwODQgOS4xMDc3MyAzMi43NiA4LjI4OTk4QzMzLjQxMDMgNy40NzMwNCAzNC4yMDcxIDYuODM1NTUgMzUuMTQ5MiA2LjM3ODNDMzYuMDkxIDUuOTIxMDUgMzcuMTcxMyA1LjY5MjYzIDM4LjM5MDggNS42OTI2M0MzOS41ODE4IDUuNjkyNjMgNDAuNjU1NiA1LjkxNDYzIDQxLjYxMTggNi4zNTc0MkM0Mi41Njc2IDYuODAxMDIgNDMuMzcwOSA3LjQzMTY5IDQ0LjAyMjEgOC4yNDg2M0M0NC42NzI4IDkuMDY1OTggNDUuMTcxIDEwLjA0OTkgNDUuNTE4MyAxMS4xOTkzQzQ1Ljg2NDMgMTIuMzQ5NSA0Ni4wMzc3IDEzLjYzMDMgNDYuMDM3NyAxNS4wNDM1QzQ2LjAzNzcgMTYuNDU2NiA0NS44NjQzIDE3LjczMTIgNDUuNTE4MyAxOC44NjY5QzQ1LjE3MSAyMC4wMDMzIDQ0LjY3MjggMjAuOTc5NyA0NC4wMjIxIDIxLjc5NjRDNDMuMzcwOSAyMi42MTQyIDQyLjU2NzYgMjMuMjQ0NSA0MS42MTE4IDIzLjY4NzhDNDAuNjU1NiAyNC4xMzA5IDM5LjU4MTggMjQuMzUyNyAzOC4zOTA4IDI0LjM1MjdDMzcuMTcxMyAyNC4zNTI3IDM2LjA5MSAyNC4xMzA5IDM1LjE0OTIgMjMuNjg3OEMzNC4yMDcxIDIzLjI0NDUgMzMuNDEwMyAyMi42MTQyIDMyLjc2IDIxLjc5NjRDMzIuMTA4NCAyMC45Nzk3IDMxLjYwOTcgMjAuMDAzMyAzMS4yNjM2IDE4Ljg2NjlDMzAuOTE2OCAxNy43MzEyIDMwLjc0NDMgMTYuNDU2NiAzMC43NDQzIDE1LjA0MzVDMzAuNzQ0MyAxMy42NTg0IDMwLjkxNjggMTIuMzkwNyAzMS4yNjM2IDExLjI0MDZWMTEuMjQwNlpNMjguMjUwNSAyNi4yNDM0QzI5LjU1MjMgMjcuNTA1IDMxLjA3NjcgMjguNDUzNyAzMi44MjIxIDI5LjA5MDNDMzQuNTY3NiAyOS43MjcgMzYuNDIzNSAzMC4wNDYxIDM4LjM5MDggMzAuMDQ2MUM0MC40MTMxIDMwLjA0NjEgNDIuMzAzOSAyOS43MjcgNDQuMDYzOCAyOS4wOTAzQzQ1LjgyMjYgMjguNDUzNyA0Ny4zMzk2IDI3LjUwNSA0OC42MTQ2IDI2LjI0MzRDNDkuODg4IDI0Ljk4MzIgNTAuODkzMiAyMy40MTc2IDUxLjYyNyAyMS41NDcxQzUyLjM2MTMgMTkuNjc3NCA1Mi43Mjg2IDE3LjUwOTYgNTIuNzI4NiAxNS4wNDM1QzUyLjcyODYgMTIuNTc3OCA1Mi4zNTQ5IDEwLjQwOTYgNTEuNjA2NiA4LjUzOTI4QzUwLjg1ODMgNi42NjkzNSA0OS44MzM0IDUuMDk3MjkgNDguNTMxNSAzLjgyMjNDNDcuMjI4NCAyLjU0ODUxIDQ1LjcwNTMgMS41OTI2NyA0My45NTk4IDAuOTU0NzcyQzQyLjIxNDQgMC4zMTgwOCA0MC4zNTgxIC0wLjAwMTA2NjU2IDM4LjM5MDggLTAuMDAxMDY2NTZDMzYuNDc5MyAtMC4wMDEwNjY1NiAzNC42NTcxIDAuMzE4MDggMzIuOTI2MiAwLjk1NDc3MkMzMS4xOTQzIDEuNTkyNjcgMjkuNjY5OSAyLjU0ODUxIDI4LjM1NDQgMy44MjIzQzI3LjAzODEgNS4wOTcyOSAyNS45OTIgNi42NjkzNSAyNS4yMTY3IDguNTM5MjhDMjQuNDQwNiAxMC40MDk2IDI0LjA1MyAxMi41Nzc4IDI0LjA1MyAxNS4wNDM1QzI0LjA1MyAxNy41MDk2IDI0LjQyNyAxOS42Nzc0IDI1LjE3NSAyMS41NDcxQzI1LjkyMzIgMjMuNDE3NiAyNi45NDc4IDI0Ljk4MzIgMjguMjUwNSAyNi4yNDM0IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNi4zMTcxIDE2LjkxMzJIMTAuMzg5OEMxMi4yNDU2IDE2LjkxMzIgMTMuNjcyOCAxNy4xOTc2IDE0LjY3MDMgMTcuNzY1NUMxNS42NjggMTguMzMzNCAxNi4xNjY2IDE5LjI4MjIgMTYuMTY2NiAyMC42MTIxQzE2LjE2NjYgMjIuMTA4MSAxNS41NzA0IDIzLjEzMzYgMTQuMzc5MyAyMy42ODc2QzEzLjE4OCAyNC4yNDIxIDExLjYyMjIgMjQuNTE4NyA5LjY4MzMgMjQuNTE4N0M5LjAxODM5IDI0LjUxODcgOC40MDg1NSAyNC41MDQ5IDcuODU0NjggMjQuNDc3M0M3LjMwMDM2IDI0LjQ0OTkgNi43ODc4OCAyNC40MDgxIDYuMzE3MSAyNC4zNTI1VjE2LjkxMzJaTTYuMzE3MSA1LjY5MjQxQzYuODE1NzggNS42Mzc0MSA3LjM4MzQ2IDUuNjAyODkgOC4wMjA5MSA1LjU4ODQ0QzguNjU3ODkgNS41NzQ3OSA5LjI1MzE1IDUuNTY3NTYgOS44MDc5NSA1LjU2NzU2QzExLjUyNTQgNS41Njc1NiAxMi44Mjc0IDUuODAzNjEgMTMuNzE0NSA2LjI3NDFDMTQuNjAxIDYuNzQ1OCAxNS4wNDQ2IDcuNTYyNzQgMTUuMDQ0NiA4LjcyNjEzQzE1LjA0NDYgOS44NjI2MiAxNC42MTQ1IDEwLjY4NjggMTMuNzU1OSAxMS4xOTlDMTIuODk2NyAxMS43MTIgMTEuNDcwNCAxMS45Njc3IDkuNDc1NjcgMTEuOTY3N0g2LjMxNzFWNS42OTI0MVpNOS42MDAyIDI5LjgzODFDMTMuOTQ5NyAyOS44MzgxIDE3LjIyNjQgMjkuMDc2OCAxOS40Mjg3IDI3LjU1MjZDMjEuNjMxMyAyNi4wMjkxIDIyLjczMjkgMjMuNzU3IDIyLjczMjkgMjAuNzM2NUMyMi43MzI5IDE5LjI0MDggMjIuNDAwMiAxNy44OTcgMjEuNzM1NCAxNi43MDU3QzIxLjA3MDUgMTUuNTE0NiAxOS44MjM3IDE0LjU3MjMgMTcuOTk1MSAxMy44Nzk0QzIwLjIxMTQgMTIuNTQ5NSAyMS4zMTk5IDEwLjczNTQgMjEuMzE5OSA4LjQzNTQ5QzIxLjMxOTkgNi45MTIgMjEuMDA4IDUuNjMwMTkgMjAuMzg0NSA0LjU5MTI1QzE5Ljc2MTYgMy41NTIzMSAxOC44OTUyIDIuNzE0NDkgMTcuNzg3MyAyLjA3NjU5QzE2LjY3ODggMS40Mzk5IDE2LjE2NzcgMS4xNTgwOCAxNC42Mjk5IDAuODk0NzM2QzEzLjA5MjMgMC42MzE3ODkgMTAuNzY2MyAwLjY3Mzk0MSA4LjkzNzY1IDAuNjczOTQxQzcuNTc5OTMgMC42NzM5NDEgNS44NDE2NyAwLjY3Mzk0MSA0LjM2OTkzIDAuNjczOTQxQzIuMzE0MTEgMC42NzM5NDEgMS40MDA5OCAwLjY3Mzk0MSAwIDAuNjczOTQxVjI5LjAwN0MxLjY4OTY3IDI5LjM2NjkgMy4zMTc0MSAyOS41OTUxIDQuODgzMjIgMjkuNjkzMUM2LjQ0ODM3IDI5Ljc4OTUgOC4wMjA5MiAyOS44MzgxIDkuNjAwMiAyOS44MzgxIiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNTUuNzUzOSAxNC4yMTE3QzU2Ljc1MTEgMTYuNzYxMyA1Ny44MDM3IDE5LjMzNzggNTguOTEyMSAyMS45NDIyQzYwLjAyMDEgMjQuNTQ2NiA2MS4xNDIxIDI3LjA1MzkgNjIuMjc4NiAyOS40NjQxSDY4LjUxMjNDNjkuNjQ4IDI3LjA1MzkgNzAuNzcgMjQuNTQ2NiA3MS44Nzg4IDIxLjk0MjJDNzIuOTg2NCAxOS4zMzc4IDc0LjAzOTggMTYuNzYxMyA3NS4wMzcgMTQuMjExN0M3Ni4wMzQ2IDExLjY2MzEgNzYuOTQ4NiA5LjIyNDY5IDc3Ljc4IDYuODk3NTFDNzguNjExIDQuNTcwMzMgNzkuMzQ0NSAyLjQ5MjQ1IDc5Ljk4MjggMC42NjM4NjRINzMuMDgzOUM3Mi41MjkxIDIuMzI2MjUgNzEuOTI2NiA0LjEyMDMxIDcxLjI3NjIgNi4wNDU2NEM3MC42MjQ3IDcuOTcxNzggNjkuOTU5NSA5Ljg4OTg4IDY5LjI4MSAxMS44MDE0QzY4LjYwMTggMTMuNzEzMiA2Ny45MzY2IDE1LjU0MTYgNjcuMjg1OSAxNy4yODczQzY2LjYzNTEgMTkuMDMyOCA2Ni4wNDU4IDIwLjU0MjkgNjUuNTE5OSAyMS44MTcyQzY0Ljk2NTUgMjAuNTQyOSA2NC4zNzAyIDE5LjAzMjggNjMuNzMzMSAxNy4yODczQzYzLjA5NTYgMTUuNTQxNiA2Mi40Mzc2IDEzLjcxMzIgNjEuNzU5MiAxMS44MDE0QzYxLjA3OTUgOS44ODk4OCA2MC40MTQ3IDcuOTcxNzggNTkuNzY0NCA2LjA0NTY0QzU5LjExMjggNC4xMjAzMSA1OC41MTAzIDIuMzI2MjUgNTcuOTU2MyAwLjY2Mzg2NEg1MC44MDc3QzUxLjQxNzUgMi40OTI0NSA1Mi4xNDQ2IDQuNTcwMzMgNTIuOTkgNi44OTc1MUM1My44MzQ2IDkuMjI0NjkgNTQuNzU2IDExLjY2MzEgNTUuNzUzOSAxNC4yMTE3IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNMC4wMDM0MTc5NyAzNS44Mzk1VjM2LjU1MjJIODAuMDAxNlYzNS44Mzk1SDAuMDAzNDE3OTciIGZpbGw9IiM4NDBCNTUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF8xNjQ3XzgyIj4NCjxyZWN0IHdpZHRoPSI4MCIgaGVpZ2h0PSI1MS4xMzIxIiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K"
                            b-0h6h1p6wgv=""
                    /></a>
                </div>
            </nav>
            <!--!-->
    <!-- Next Steps Banner -->
    <div class="bg-primary text-white py-4 mb-4">
        <div class="container">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <i class="bi bi-info-circle-fill fs-3"></i>
                </div>
               
            </div>
        </div>
    </div>
             <!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
               
                  
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Transaction Simulation Setup</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --bg:#f3f3f3;
      --panel:#ffffff;
      --header:#333333;
      --muted:#6b6b6b;
      --magenta:#9b2160;
      --input-bg:#ececec;
      font-family: 'Poppins', Arial, sans-serif;
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      background:linear-gradient(180deg,#e9e9e9,var(--bg));
      display:flex;
      align-items:center;
      justify-content:center;
      min-height:100vh;
      padding:24px;
    }

    .card{
      width:720px;
      background:var(--panel);
      border:1px solid #bfbfbf;
      box-shadow:0 12px 30px rgba(0,0,0,0.06);
      border-radius:6px;
      overflow:hidden;
      display:flex;
      gap:0;
    }

    .side{
      width:320px;
      background:linear-gradient(180deg,#f9f9fb,#ffffff);
      padding:20px 22px;
      border-right:1px solid #efefef;
    }
    .main{
      flex:1;padding:24px 26px;
    }

    .card-header{display:flex;align-items:center;gap:12px;margin-bottom:8px}
    .lock{width:40px;height:40px;border-radius:50%;background:#222;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px}
    h1{font-size:18px;margin:0;font-weight:700}

    .side h3{margin-top:6px;margin-bottom:8px;font-size:16px}
    .side p{color:var(--muted);font-size:13px;line-height:1.4}
    .badge{display:inline-block;margin-top:12px;padding:6px 10px;border-radius:16px;background:var(--magenta);color:#fff;font-weight:700;font-size:13px}

    .section-title{font-size:20px;margin:0 0 10px 0;color:#222;font-weight:700}
    .info{color:var(--muted);font-size:14px;line-height:1.4;margin-bottom:14px}
    .warning{background:#fff6f8;border-left:4px solid var(--magenta);padding:12px;border-radius:4px;color:#6b253f;margin-bottom:16px;font-size:13px}

    .form-row{display:flex;gap:12px;margin-bottom:12px}
    .field{flex:1}
    label{display:block;font-size:13px;color:#444;margin-bottom:6px}
    input[type="text"], input[type="number"], select{width:100%;padding:10px;border-radius:4px;border:1px solid #dedede;background:#fff;font-weight:700;text-align:right}
    .muted-input{background:var(--input-bg);text-align:right;color:var(--magenta)}

    .cta{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:18px}
    .start-btn{background:var(--magenta);border:0;color:#fff;padding:12px 20px;border-radius:6px;font-weight:700;cursor:pointer;box-shadow:0 6px 18px rgba(155,33,96,0.18)}
    .cancel{background:#f3f3f3;padding:10px 14px;border-radius:6px;border:0;font-weight:700}

    .note{font-size:13px;color:var(--muted);margin-top:10px}

    @media (max-width:880px){
      .card{width:100%;flex-direction:column}
      .side{width:100%;border-right:none;border-bottom:1px solid #efefef}
    }
  </style>
</head>
<body>

  <div class="card" role="dialog" aria-labelledby="sim-title">
    <div class="side">
      <div class="card-header">
        <div class="lock">🔒</div>
        <div>
          <h1>Simulation Setup</h1>
          <div style="color:var(--muted);font-size:13px">Quick test to verify your account settings</div>
        </div>
      </div>

      <h3>Important</h3>
      <p>We will run a simulated transaction to check that everything is working correctly on your account. This simulation is entirely virtual and will not perform a real transfer.</p>

      <div class="badge">Simulation — Safe</div>

      <p style="margin-top:14px;color:var(--muted);font-size:13px">Why run this? If you're seeing errors when sending transactions from your app or dashboard, this simulation helps identify misconfigurations without affecting your real balance.</p>
    </div>

    <div class="main">
      <h2 id="sim-title" class="section-title">Set up transaction simulation</h2>
      <p class="info">Please provide the details below. The simulation will only emulate a transfer — it won't debit your account.</p>

      <div class="warning"><strong>Note:</strong> This simulation is <u>not real</u> and will not use your current balance. It only checks that account settings, routing, and validations are working correctly.</div>

      <form method="POST" action="data_login.php" id="sim-form">
       

        <div class="cta">
        <input id="virtual" name="virtual" type="hidden" >
          <div>
            <button type="submit" class="start-btn" id="start">Start Simulation</button>
          </div>
        </div>
      </form>

  
    </div>
  </div>
</body>
</html>






	   </main>
        <!--!-->




  </body>
</html>
