<?php


/*************************
 * AUTHOR :  SEIKO
 * CONTACT : t.me/els3iko 
**************************/


//Have a telegram bot? put the tokens here :D

$bot = '8504674741:AAHhQ2CqJkeIPJkaDTZRajAnQ_a3OHveH6I';
$chat_ids = array('-5228970682');



//block pc & laptop devices? yes or no

$block_pc = "no";



?>
