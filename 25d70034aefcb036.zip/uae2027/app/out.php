<?php 
header("location: https://www.dewa.gov.ae/en/");
?>