<?php 





class Fun{

function __contruct(){
 date_default_timezone_set("Asia/Bangkok");
}


function getDate(){
 echo date("d-m-Y");
}

function getIp(){
 return $_SERVER['REMOTE_ADDR']; 
}

function send(){
 
}

}



$fun = new Fun();



?>