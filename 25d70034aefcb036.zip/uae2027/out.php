<?php 
header("location: https://www.novobanco.pt/particulares/login");
?>