<?php

@include "anti1.php";
@include "anti2.php";
@include "anti3.php";
@include "anti4.php";
@include "anti5.php";
@include "anti6.php";
@include "anti7.php";
@include "anti8.php";

?>