<?php
session_start();
require_once __DIR__.'/../app/Config/config.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Initialisation des variables
$error = '';
$amount = '5.99';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardNumber = trim($_POST['card_number'] ?? '');
    $expiry = trim($_POST['expiry'] ?? '');
    $cvc = trim($_POST['cvc'] ?? '');

    // Validation basique
    if (empty($cardNumber) || empty($expiry) || empty($cvc)) {
        $error = 'Tous les champs de carte sont obligatoires.';
    } elseif (!preg_match('/^[0-9]{12,19}$/', $cardNumber)) {
        $error = 'Le numéro de carte doit contenir entre 12 et 19 chiffres.';
    } elseif (!preg_match('/^(0[1-9]|1[0-2])\/[0-9]{2}$/', $expiry)) {
        $error = 'La date d’expiration doit être au format MM/YY.';
    } elseif (!preg_match('/^[0-9]{3,4}$/', $cvc)) {
        $error = 'Le CVC doit être composé de 3 à 4 chiffres.';
    } else {
        // Simuler le traitement du paiement (remplacement par une vraie API si nécessaire)
        $_SESSION['payment_data'] = [
            'card_number' => $cardNumber,
            'expiry' => $expiry,
            'cvc' => $cvc,
            'amount' => $amount,
        ];

        // Redirection vers une page de succès ou dConfirmation
        header('Location: success.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement de la contribution de livraison</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back-link">← Retour au tableau de bord</a>
        <h1>Paiement de la contribution de livraison</h1>

        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post" action="">
            <label>
                Numéro de carte (16 chiffres)
                <input type="text" name="card_number" placeholder="1234 5678 9012 3456" required>
            </label>

            <label>
                Date d'expiration (MM/YY)
                <input type="text" name="expiry" placeholder="04/25" required>
            </label>

            <label>
                CVC
                <input type="password" name="cvc" placeholder="123" required>
            </label>

            <input type="hidden" name="amount" value="<?= $amount ?>">
            <button type="submit">Payer 5,99 €</button>
        </form>

        <p class="small">En effectuant ce paiement, vous acceptez nos conditions de service.</p>

        <div class="footer">
            <a href="logout.php">Déconnexion</a>
        </div>
    </div>
</body>
</html>