<?php
session_start();

require_once __DIR__ . '/../app/Config/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Initialiser la verification du code s'il n'existe pas encore
if (!isset($_SESSION['verification_code'])) {
    // Generer un code alfanumerique de 6 caracteres
    $_SESSION['verification_code'] = bin2hex(random_bytes(3));
}

// Gestion du formulaire de verification
$code = $_POST['code'] ?? '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($code)) {
        $error = 'Veuillez entrer le code reçu par SMS.';
    } elseif ($code !== $_SESSION['verification_code']) {
        $error = 'Code incorrect. Veuillez reessayer.';
    } else {
        // Le code est valide – on peut proceder
        $_SESSION['code_verified'] = true;
        // Rediriger vers la prochaine etape (par exemple, la page de reception du permis)
        header('Location: dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Verification du code SMS</title>
    <style>
        body {font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:20px;}
        .container {max-width:400px; margin:auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.1);}
        .error {color:#d00; margin-bottom:15px;}
        input[type="text"] {width:100%; padding:10px; margin:10px 0; border:1px solid #ccc; border-radius:4px;}
        button {padding:10px 15px; background:#007BFF; color:#fff; border:none; border-radius:4px; cursor:pointer;}
        button:hover {background:#0056b3;}
    </style>
</head>
<body>
<div class="container">
    <h2>Verification du code SMS</h2>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="code">Code reçu par SMS :</label>
        <input type="text" id="code" name="code" autocomplete="one-time-code" required>
        <button type="submit">Verifier</button>
    </form>

    <p>Si vous ne recevez pas le code, vous pouvez <a href="dashboard.php">retourner a la page precedente</a>.</p>
</div>
</body>
</html>