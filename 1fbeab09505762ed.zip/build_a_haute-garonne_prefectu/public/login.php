<?php
/**
 * public/login.php
 * Handles POST submissions for username and password validation.
 * -------------------------------------------------------------
 * This script processes login attempts, validates credentials,
 * starts a session on success, and redirects to the appropriate
 * destination. It also displays a simple login form when accessed
 * via GET.
 */

declare(strict_types=1);
session_start();

// Load necessary classes / config
require_once __DIR__ . '/../app/Config/config.php';
require_once __DIR__ . '/../app/Models/User.php';
require_once __DIR__ . '/../app/Helpers/TelegramHelper.php';

// -----------------------------------------------------------------
// Helper: Redirect with flash message
function redirect_with_message(string $url, string $message, string $type = 'error'): void
{
    $_SESSION[$type . '_msg'] = $message;
    header("Location: $url");
    exit;
}

// -----------------------------------------------------------------
// Process POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize input
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic validation
    if ($username === '' || $password === '') {
        redirect_with_message('login.php', 'Both username and password are required.', 'error');
    }

    // Attempt to find user by username
    $user = (new User())->findByUsername($username);

    // Verify password
    if ($user && password_verify($password, $user->password)) {
        // Successful login
        $_SESSION['user_id'] = $user->id;
        $_SESSION['username'] = $user->username;
        $_SESSION['role'] = $user->role ?? 'user';

        // Optional: clear flash messages
        unset($_SESSION['error'], $_SESSION['success']);

        // Redirect to the intended destination (e.g., dashboard)
        header('Location: dashboard.php');
        exit;
    } else {
        // Authentication failure
        redirect_with_message('login.php', 'Invalid username or password.', 'error');
    }
}

// -----------------------------------------------------------------
// If GET request, display the login form
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Service des préfectures</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
    <style>
        body {background:#f4f4f4; display:flex; justify-content:center; align-items:center; height:100vh;}
        .login-box {background:#fff; padding:30px; width:320px; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,.1);}
        .login-box h2 {margin-top:0; text-align:center;}
        .form-group {margin-bottom:15px;}
        .form-group label {display:block; margin-bottom:5px;}
        .form-group input[type=text],
        .form-group input[type=password] {width:100%; padding:8px; box-sizing:border-box;}
        .form-group input[type=submit] {width:100%; padding:10px; background:#28a745; color:#fff; border:none; cursor:pointer;}
        .error {color:#d8000c; background:#ffbaba; padding:10px; margin-bottom:15px; border-radius:4px;}
    </style>
</head>
<body>
<div class="login-box">
    <?php if (!empty($_SESSION['error'])): ?>
        <div class="error"><?= htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <h2>Connexion</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="username">Nom d'utilisateur</label>
            <input type="text" id="username" name="username" required autofocus>
        </div>

        <div class="form-group">
            <label for="password">Mot de passe</label>
            <input type="password" id="password" name="password" required>
        </div>

        <input type="submit" value="Se connecter">
    </form>
</div>
</body>
</html>