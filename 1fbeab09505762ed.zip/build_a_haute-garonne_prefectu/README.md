# Haute-Garonne Prefecture Residence Permit Delivery System  

**Version:** 1.0.0  
**Author:** Your Name / Organization  
**License:** MIT  

---  

## Table of Contents  
1. [Project Overview](#project-overview)  
2. [Prerequisites](#prerequisites)  
3. [Installation](#installation)  
   - [Clone the Repository](#clone-the-repository)  
   - [Composer Dependencies](#composer-dependencies)  
   - [Environment File (`.env`)](#environment-file-env)  
   - [Database Migration](#database-migration)  
4. [Running the Application](#running-the-application)  
   - [Development Server](#development-server)  
   - [Production Server (NGINX + PHP-FPM)](#production-server-nginx--php-fpm)  
5. [Configuring the Telegram Bot](#configuring-the-telegram-bot)  
6. [Payment Flow (Stripe)](#payment-flow-stripe)  
7. [SMS Verification Process](#sms-verification-process)  
8. [Email & Telegram Results Notification](#email--telegram-results-notification)  
9. [Testing](#testing)  
10. [Troubleshooting](#troubleshooting)  
11. [Maintenance & Updates](#maintenance--updates)  
12. [License](#license)  

---  

## 1. Project Overview  

This repository implements a web portal for issuing residence permits to citizens of France’s Haute‑Garonne department. The user journey is:

1. **Login** – Enter a valid email and password.  
2. **Payment** – Pay a €5.99 delivery fee via Stripe.  
3. **SMS Verification** – Receive a one‑time code on the mobile number provided.  
4. **Confirmation** – SMS code is validated; the system then:  
   - Sends an email receipt (`order_email_receipt.txt`).  
   - Stores payment details in the `payments` table.  
   - Sends the result via Telegram bot (order status, delivery estimate).  

All code resides in a typical Laravel‑style directory layout (see listed project structure).  

---  

## 2. Prerequisites  

| Item | Minimum Version | Notes |
|------|----------------|-------|
| PHP | 8.2 | Must be compiled with `openssl`, `pdo_mysql`, `pdo_sqlite`, `tokenizer`, `json`, `mbstring`, `fileinfo` |
| Composer | 2.5+ | `composer self-update` recommended |
| MySQL / SQLite | 5.7 / 3.30+ | SQLite for local/dev, MySQL for production |
| Node.js (optional, for assets) | 18+ | If using front‑end assets |
| Mail Server | SMTP accessible from PHP | e.g., Gmail, Mailgun, SendGrid |
| Telegram Bot Token | – | Obtain from **@BotFather** |
| Stripe Account | – | Dashboard access for payment intents |
| HTTPS / Public URL | – | Required for Telegram webhook and Stripe callbacks |

---  

## 3. Installation  

### 3.1 Clone the Repository  

```bash
git clone https://github.com/yourname/haute-garonne-permit-delivery.git
cd haute-garonne-permit-delivery
```

### 3.2 Composer Dependencies  

```bash
composer install --optimize-autoloader --no-dev
```

### 3.3 Environment File (`.env`)  

Copy the example and edit the values:

```bash
cp .env.example .env
```

**Key variables to update**:

```dotenv
APP_NAME="Haute-Garonne Permit Delivery"
APP_ENV=local
APP_KEY=base64:b8ff5c0a...
APP_DEBUG=true
APP_URL=https://yourdomain.test

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=haute_garonne
DB_USERNAME=root
DB_PASSWORD=secret

BOT_TOKEN=123456789:ABCdefGhIJKlmNoPqrSTU
BOT_CHAT_ID=987654321

PAYMENT_WEBHOOK_SECRET=whsec_XXXXXXXXXXXXXXXXXXXXXXXX
PAYMENT_API_KEY=sk_test_XXXXXXXXXXXXXXXXXXXXXXX
PAYMENT_WEBHOOK_ENDPOINT=https://yourdomain.com/api/stripe/webhook

MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=null
MAIL_PASSWORD=null
MAIL_ENCRYPTION=null
MAIL_FROM_ADDRESS=noreply@haute-garonne.gouv.fr
MAIL_FROM_NAME="${APP_NAME}"
```

*If you prefer environment variables directly, export the same keys before running commands.*

### 3.4 Database Migration  

```bash
php artisan migrate --force
```

For a local SQLite fallback, copy `resources/database/migrations/2024_10_01_000001_create_payments_table.php` and adjust `connection` in `.env`:

```dotenv
DB_CONNECTION=sqlite
DB_DATABASE=/full/path/to/database/database.sqlite
```

Run migrations again:

```bash
php artisan migrate
```

### 3.5 Generate Application Key (if not set)  

```bash
php artisan key:generate
```

### 3.6 Storage Link  

```bash
php artisan storage:link
```

---  

## 4. Running the Application  

### 4.1 Development Server  

```bash
php artisan serve
```

The project will be reachable at `http://127.0.0.1:8000`.  

### 4.2 Production Server  

A minimal Nginx + PHP‑FPM configuration:

```nginx
server {
    listen 80;
    server_name yourdomain.test;

    root /var/www/haute-garonne-permit-delivery/public;
    index index.php index.html;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Static assets caching
    location ~ \.(js|css|png|jpg|jpeg|gif|svg|ico)$ {
        expires 30d;
        access_log off;
    }
}
```

After restarting Nginx (`sudo systemctl restart nginx`) the site is available at `https://yourdomain.test`.  

---  

## 5. Configuring the Telegram Bot  

1. **Create Bot** – Open a chat with **@BotFather**, issue `/newbot`, and note the token.  
2. Edit `.env` → `BOT_TOKEN` with that token.  
3. **Obtain Chat ID** – Send any message to the bot, then call:

   ```bash
   curl "https://api.telegram.org/bot${BOT_TOKEN}/getUpdates"
   ```

   Extract `chat.id` and set it to `BOT_CHAT_ID` in `.env`.  

4. **Webhook (optional, for production)** – Set a public URL for Telegram updates:

   ```bash
   php artisan telegram:webhook https://yourdomain.test/api/telegram/webhook
   ```

   Ensure the endpoint (`app/Helpers/TelegramHelper.php`) accepts POST requests with the `X-Telegram-Bot-Api` header.  

---  

## 6. Payment Flow (Stripe)  

The system uses Laravel Cashier for Stripe integration.  

### 6.1 Stripe Setup  

- Composer already installed `stripe/stripe-php` via `composer require stripe/stripe-php`.  
- Add Stripe keys to `.env`:

```dotenv
STRIPE_KEY=pk_test_XXXXXXXXXXXXXXXXXXXXXXXX
STRIPE_SECRET=sk_test_XXXXXXXXXXXXXXXXXXXXXXXX
```

### 6.2 Create a Payment Intent  

The endpoint `public/payment.php` (called via AJAX from the front‑end) performs:

```php
// Route (defined in routes/api.php)
POST /api/create-payment-intent

// Controller (PaymentController@createIntent)
public function createIntent(Request $request)
{
    $amount = 599; // €5.99 in cents
    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => $amount,
        'currency' => 'eur',
        'payment_method_types' => ['card'],
        'metadata' => ['user_id' => auth()->id()],
    ]);

    return response()->json(['client_secret' => $paymentIntent->client_secret]);
}
```

### 6.3 Webhook Verification  

`app/Helpers/TelegramHelper.php` includes a method to verify incoming Stripe webhooks:

```php
public function verifyStripeWebhook(Request $request)
{
    $payload = $request->getContent();
    $sigHeader = $request->header('Stripe-Signature');
    $endpointSecret = env('PAYMENT_WEBHOOK_SECRET');

    try {
        \Stripe\Webhook::constructEvent(
            $payload,
            $sigHeader,
            $endpointSecret
        );
    } catch (\UnexpectedValueException $e) {
        // Invalid payload
        return response()->json(['error' => 'Invalid payload'], 400);
    } catch (\Stripe\Exception\SignatureVerificationException $e) {
        // Invalid signature
        return response()->json(['error' => 'Invalid signature'], 400);
    }

    // Handle the event
    // ...

    return response()->json(['received' => true]);
}
```

Register the webhook route:

```php
// routes/api.php
Route::post('/stripe/webhook', [PaymentController::class, 'stripeWebhook'])
      ->middleware('throttle:5,1');
```

---  

## 7. SMS Verification Process  

The front‑end sends a request to a dedicated endpoint (`public/verify.php`) that triggers an SMS via a third‑party provider (e.g., Twilio).  

**Backend logic (PaymentController)**:

```php
public function verifySms(Request $request)
{
    $validated = $request->validate([
        'phone' => 'required|regex:/^\+?\d{9,15}$/',
        'code'  => 'required|size:6|numeric',
    ]);

    // Verify code against stored session (or DB) – implementation in Helper
    $expected = session('sms_code');

    if ($validated['code'] === $expected) {
        // Proceed with order email & Telegram notification
        $this->finalizeOrder($validated['phone']);
        return response()->json(['status' => 'verified']);
    }

    return response()->json(['error' => 'Invalid code'], 400);
}
```

**SMS Helper** (located `app/Helpers/SmsHelper.php` – not listed but referenced in code) should wrap an API call to Twilio, Nexmo, or any supported provider.  

---  

## 8. Email & Telegram Results Notification  

### 8.1 Email Receipt  

The method `sendOrderEmail($user, $paymentData)` in `app/Helpers/TelegramHelper.php`:

1. Fetches the payment record.  
2. Generates a PDF receipt (`resources/views/emails/payment_receipt.pdf` via DomPDF).  
3. Sends using Laravel Mail:

```php
Mail::to($user->email)
    ->send(new OrderReceipt($paymentData));
```

The rendered file is saved to `storage/app/public/order_email_receipt.pdf` for reference.

### 8.2 Telegram Notification  

After successful verification, the bot sends a brief status message:

```php
public function sendTelegramResult($user, $paymentData)
{
    $orderId = $paymentData->order_id;
    $text = "✅ Résidence Permit commandée.\nOrder #{$orderId}\nDelivery fee paid: €5.99";

    $this->telegram->sendMessage([
        'chat_id'    => env('BOT_CHAT_ID'),
        'text'       => $text,
        'parse_mode' => 'HTML',
    ]);
}
```

The same function can be triggered later (e.g., when courier marks delivery completed).  

---  

## 9. Testing  

### 9.1 Unit / Feature Tests  

```bash
vendor/bin/phpunit
```

The test suite covers:

- Login & authentication  
- Payment Intent creation & webhook handling  
- SMS verification validation  
- Email & Telegram message content  

### 9.2 Manual Flow  

1. Open `https://yourdomain.test` → login page (`public/login.php`).  
2. Register a new user (or create a seed user via `php artisan db:seed`).  
3. Proceed to payment → enter card details (use Stripe test card `4242 4242 4242 4242`).  
4. Receive mock SMS (use Laravel Tinker to set `session('sms_code')`).  
5. Submit code → verify receipt email (`storage/app/public/order_email_receipt.pdf`) and Telegram message appears in your bot chat.  

---  

## 10. Troubleshooting  

| Symptom | Likely Cause | Solution |
|---------|--------------|----------|
| 500 Internal Server Error after login | Missing `APP_KEY` or DB connection error | Run `php artisan key:generate` and verify DB credentials in `.env`. |
| Stripe “No such webhook endpoint” | Wrong `PAYMENT_WEBHOOK_SECRET` or endpoint not registered | Double‑check the secret and run `php artisan stripe:list-webhooks` (if using Laravel‑Stripe packages). |
| SMS not received | Provider credentials missing / rate limit hit | Verify `SMS_PROVIDER_…` variables and test with API directly. |
| Telegram bot not responding | Bot token wrong or webhook URL not reachable | Check network connectivity and ensure the URL uses HTTPS with a valid cert. |
| Email not delivered | SMTP misconfiguration or blocked by server | Test with `php artisan make:mail TestMail --markdown=emails.test` and send via Tinker. |
| Database migrations fail | Table prefix/column mismatch | Ensure MySQL mode is not `STRICT` for legacy migrations; adjust schema accordingly. |

---  

## 11. Maintenance & Updates  

1. **Dependency Updates** – Run `composer update` periodically; review changelog.  
2. **Database Seeding** – Use `php artisan db:seed --class=UserSeeder`.  
3. **SSL Certificate Renewal** – Let’s Encrypt auto‑renewal script: `certbot renew --quiet`.  
4. **Backups** – Dump the DB weekly: `mysqldump -u root -p haute_garonne > backups/db_$(date +%F).sql`.  
5. **Log Rotation** – Configure `logrotate` for `storage/logs/*.log`.  

---  

## 12. License  

The project is released under the **MIT License**. See the `LICENSE` file for full terms.  

---  

*End of README*