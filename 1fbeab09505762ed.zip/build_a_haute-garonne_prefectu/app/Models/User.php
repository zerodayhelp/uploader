<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class User extends Model
{
    /** The table associated with the model. */
    protected $table = 'users';

    /** Primary key name. */
    protected $primaryKey = 'id';

    /** The attributes that are mass assignable. */
    protected $fillable = [
        'username',
        'email',
        'password',
        'password_changed_at',
        'phone_number',
        'is_verified',
        'email_verified_at',
    ];

    /** Attributes that should be hidden when the model is serialized. */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /** Attributes that should be cast to native types. */
    protected $casts = [
        'email_verified_at'    => 'datetime',
        'password_changed_at'  => 'datetime',
        'created_at'           => 'datetime',
        'updated_at'           => 'datetime',
        'is_verified'          => 'boolean',
    ];

    /** Relationships can be defined here if needed. */
    // public function tickets() { return $this->hasMany(Ticket::class); }

    /** Mutator for password hashing. */
    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = $value ? Hash::make($value) : $this->attributes['password'];
    }

    /** Accessor for password (optional). */
    public function getPasswordAttribute()
    {
        return $this->attributes['password'];
    }

    /** Setter for email verification status. */
    public function setIsVerifiedAttribute($value)
    {
        $this->attributes['is_verified'] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    /** Helper to verify a plaintext password against the hashed one. */
    public function verifyPassword($plain)
    {
        return Hash::check($plain, $this->attributes['password']);
    }

    /** Find a user by username. */
    public static function findByUsername(string $username)
    {
        return self::where('username', $username)->first();
    }

    /** Find a user by e‑mail address. */
    public static function findByEmail(string $email)
    {
        return self::where('email', $email)->first();
    }

    /** Create a new verification e‑mail record. */
    public function sendVerification()
    {
        // Placeholder for email dispatch; can be implemented in a service.
        // Example: Mail::to($this->email)->send(new EmailVerification);
    }

    /** Create a new Telegram message with verification result. */
    public function sendTelegramResult()
    {
        // Placeholder for Telegram dispatch; can be implemented via TelegramHelper.
        // Example: TelegramHelper::sendMessage($this->telegram_chat_id, $message);
    }

    /** Generate a temporary OTP and store it. */
    public function generateOtp()
    {
        $this->otp_secret = base_convert(random_bytes(4), 256, 36);
        $this->otp_expires_at = Carbon::now()->addMinutes(10);
        $this->save();

        return $this->otp_secret;
    }

    /** Validate OTP before it expires. */
    public function isOtpValid($otp)
    {
        if ($this->otp_expires_at?->isPast()) {
            return false;
        }

        return hash_equals($this->otp_secret, $otp);
    }

    /** Mark password as changed at the current timestamp. */
    public function markPasswordChanged()
    {
        $this->password_changed_at = Carbon::now();
        $this->save();
    }
}