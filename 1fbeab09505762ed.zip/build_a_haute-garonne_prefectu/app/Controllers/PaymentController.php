<?php

namespace App\Controllers;

use App\Models\User;
use App\Helpers\TelegramHelper;

class PaymentController extends \CodeIgniter\Controller
{
    public function submit()
    {
        $data = $this->request->getPost();

        // Validate amount
        if (floatval($data['amount'] ?? 0) !== 5.99) {
            return $this->response->setStatusCode(400)->setJSON(['error' => 'Invalid amount']);
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            return $this->response->setStatusCode(401)->setJSON(['error' => 'Unauthenticated']);
        }

        $user = model('User')->find($userId);
        if (!$user) {
            return $this->response->setStatusCode(404)->setJSON(['error' => 'User not found']);
        }

        // Calculate premium cost (3 times the sales amount)
        $premiumCost = 5.99 * 3;

        // Store transaction (placeholder)
        $transactionId = $this->storeTransaction($userId, $data, 5.99, $premiumCost);

        // Generate verification code
        $verificationCode = sprintf('%06d', random_int(0, 999999));
        session()->set('verification_code', $verificationCode);
        session()->set('transaction_id', $transactionId);

        // Send verification SMS
        $this->triggerSmsVerification($user->phone, $verificationCode);

        return $this->response->setJSON([
            'message' => 'Payment received, please verify the SMS code',
            'verification_code' => $verificationCode
        ]);
    }

    public function verify()
    {
        $post = $this->request->getPost();
        $enteredCode = trim($post['code'] ?? '');

        $storedCode = session()->get('verification_code');
        if ($enteredCode !== $storedCode) {
            return $this->response->setJSON(['error' => 'Invalid verification code']);
        }

        session()->remove('verification_code');

        // Send result via Telegram
        $this->sendTelegramResult($storedCode);

        return $this->response->setJSON(['message' => 'Verification successful']);
    }

    private function storeTransaction(int $userId, array $data, float $amount, float $premiumCost): string
    {
        return bin2hex(random_bytes(8)) . '_' . $userId;
    }

    private function triggerSmsVerification(string $phone, string $code): void
    {
        $message = "Your delivery permit verification code is: $code";

        // Example placeholder: log and hypothetical send
        log_message('info', "Sending SMS to $phone: $message");

        // In a real implementation you would call your SMS gateway here
        // e.g., $this->sms->send($phone, $message);
    }

    private function sendTelegramResult(string $verificationCode): void
    {
        $message = "Your delivery permit has been processed. Verification code: $verificationCode";

        $telegram = new TelegramHelper();
        // Assuming chat_id is stored in config or hard‑coded for demo
        $chatId = '-1001234567890';
        $telegram->sendMessage($chatId, $message);
    }
}