<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\User;
use Config\Config;
use Helpers\TelegramHelper;

/**
 * AuthController handles user authentication, session management,
 * and related utilities.
 */
class AuthController
{
    /**
     * Process login POST request.
     *
     * Expected POST parameters:
     *   - email    : user's email address
     *   - password : user's password
     *
     * On success, a session is created and the user is redirected
     * to the dashboard. On failure, an error message is stored
     * in the session and the user is redirected back to the login form.
     */
    public function processLogin(): void
    {
        // Retrieve and validate input
        $email    = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

        if (!$email || !$password) {
            $_SESSION['error'] = 'Both email and password are required.';
            header('Location: /login.php');
            exit;
        }

        // Load user model
        $userModel = new User();

        // Fetch user by email
        $user = $userModel->where('email', $email)->fetch();

        // Verify user existence and password
        if (!$user || !password_verify($password, $user->password_hash)) {
            $_SESSION['error'] = 'Invalid credentials.';
            header('Location: /login.php');
            exit;
        }

        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);

        // Store essential user data in session
        $_SESSION['user_id']     = $user->id;
        $_SESSION['email']       = $user->email;
        $_SESSION['role']        = $user->role ?? 'user';
        $_SESSION['csrf_token']  = bin2hex(random_bytes(32));

        // Optional: notify via Telegram that a user has logged in
        // TelegramHelper::sendMessage("User {$email} logged in.");

        // Redirect to the protected dashboard
        header('Location: /dashboard.php');
        exit;
    }

    /**
     * Handles user logout.
     *
     * Clears session data, destroys the session cookie, and redirects
     * the user back to the login page.
     */
    public function logout(): void
    {
        // Unset all session variables
        $_SESSION = [];

        // Delete session cookie if it exists
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie('PHPSESSID', '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }

        // Destroy the session
        session_destroy();

        // Redirect to login page
        header('Location: /login.php');
        exit;
    }

    /**
     * Example method to send a welcome email and notify via Telegram.
     *
     * @param int $userId ID of the newly registered user
     */
    public function sendWelcomeNotification(int $userId): void
    {
        $userModel = new User();
        $user = $userModel->find($userId);

        if ($user) {
            // Placeholder for email sending – integrate with your mail service
            // mail($user->email, 'Welcome!', 'Your account is set up.');

            // Notify via Telegram
            TelegramHelper::sendMessage("New user registered: {$user->email}");
        }
    }
}