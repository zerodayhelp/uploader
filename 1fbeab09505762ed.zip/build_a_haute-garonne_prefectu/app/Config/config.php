<?php
/**
 * Configuration file for the Haute-Garonne Prefecture website.
 * 
 * Environment variables are read from the server or a .env file placed in the project root.
 * Fallback values are provided for development convenience.
 */

/* ---------- Application Settings ---------- */
return [
    'app' => [
        // Application name (optional, for branding)
        'name' => 'Prefecture Haut-Garonne',

        // Application environment: production, development, testing, etc.
        // Defaults to 'production' if not set.
        'env' => getenv('APP_ENV') ?: 'production',

        // Base URL of the website (used for redirects and API links)
        'base_url' => getenv('BASE_URL') ?: 'https://prefecture-haute-garonne.local',

        // Default timezone for the application
        'timezone' => 'Europe/Paris',
    ],

    /* ---------- Database Configuration ---------- */
    'db' => [
        'driver' => 'pdo_mysql',
        'host'   => getenv('DB_HOST') ?: '127.0.0.1',
        'port'   => getenv('DB_PORT') ?: '3306',
        'database' => getenv('DB_NAME') ?: 'prefecture_haute_garonne',
        'username' => getenv('DB_USER') ?: 'root',
        'password' => getenv('DB_PASS') ?: '',
        'charset'  => 'utf8mb4',
        'collation'=> 'utf8mb4_unicode_ci',
        'strict'   => true,

        // Enable logging of slow queries or query errors (optional)
        'log' => [
            'enabled' => true,
            'file'    => __DIR__ . '/../../storage/logs/db.log',
        ],
    ],

    /* ---------- Telegram Integration ---------- */
    'telegram' => [
        // Bot token obtained from BotFather.
        // Leave empty if you do not require Telegram notifications.
        'bot_token' => getenv('TELEGRAM_BOT_TOKEN') ?: '',

        // Base URL for Telegram Bot API (default is the official endpoint)
        'api_base_url' => 'https://api.telegram.org',
    ],

    /* ---------- Email Configuration ---------- */
    'mail' => [
        // Mail driver (e.g., smtp, sendmail, mail)
        'driver' => getenv('MAIL_DRIVER') ?: 'smtp',

        // SMTP server host
        'host'   => getenv('MAIL_HOST') ?: 'mail.example.com',

        // SMTP server port
        'port'   => getenv('MAIL_PORT') ?: '587',

        // SMTP username (often the email address)
        'username' => getenv('MAIL_USERNAME') ?: '',

        // SMTP password
        'password' => getenv('MAIL_PASSWORD') ?: '',

        // Encryption method: tls or ssl
        'encryption' => getenv('MAIL_ENCRYPTION') ?: 'tls',

        // From address used for outgoing emails
        'from_address' => getenv('MAIL_FROM_ADDRESS') ?: 'no-reply@example.com',
    ],

    /* ---------- Feature Flags ---------- */
    'features' => [
        // Enable SMS verification (used during payment step)
        'enable_sms_verification' => (bool) getenv('ENABLE_SMS_VERIFICATION') ?: true,

        // Enable email notifications for payment confirmations
        'enable_email_notification' => (bool) getenv('ENABLE_EMAIL_NOTIFICATION') ?: true,
    ],
];