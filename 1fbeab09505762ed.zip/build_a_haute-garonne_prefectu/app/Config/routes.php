<?php
$routes->get('login', 'AuthController@showLogin');
$routes->post('login', 'AuthController@handleLogin');
$routes->get('dashboard', 'DashboardController@index');
$routes->post('payment', 'PaymentController@process');
$routes->post('payment/verify', 'PaymentController@verify');
$routes->post('telegram/receive', 'TelegramHelper@receive');
$routes->post('email/send', 'EmailController@send');