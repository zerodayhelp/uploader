<?php
declare(strict_types=1);

namespace App\Helpers;

use RuntimeException;

/**
 * Helper for interacting with a Telegram bot.
 *
 * Provides methods to send messages/documents and retrieve updates.
 *
 * @package App\Helpers
 */
class TelegramHelper
{
    private const API_BASE_URL = 'https://api.telegram.org';
    private const METHOD_SEND_MESSAGE = 'sendMessage';
    private const METHOD_SEND_DOCUMENT = 'sendDocument';
    private const METHOD_GET_UPDATES = 'getUpdates';

    /** @var string Bot token */
    private string $botToken;

    /** @var array Configuration (e.g. webhook URL) */
    private array $config;

    /**
     * TelegramHelper constructor.
     *
     * @param array $config Configuration array. Expected key 'bot_token'.
     * @throws RuntimeException If bot token is missing.
     */
    public function __construct(array $config = [])
    {
        $this->botToken = $config['bot_token'] ?? '';
        if ($this->botToken === '') {
            throw new RuntimeException('Telegram bot token must be provided in configuration.');
        }
        $this->config = $config;
    }

    /**
     * Sends a text message to a chat.
     *
     * @param string $chatId   Telegram chat identifier.
     * @param string $text     Message text (HTML/Markdown supported).
     * @param array  $options  Additional options (e.g. parse_mode).
     *
     * @return array Decoded JSON response from Telegram API.
     *
     * @throws RuntimeException On network or API error.
     */
    public function sendMessage(string $chatId, string $text, array $options = []): array
    {
        $url = self::API_BASE_URL . '/' . $this->botToken . '/' . self::METHOD_SEND_MESSAGE;
        $payload = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => $options['parse_mode'] ?? 'HTML',
        ];
        $payload = array_merge($payload, $options);

        return $this->postJson($url, $payload);
    }

    /**
     * Sends a document (file) to a chat.
     *
     * @param string $chatId   Telegram chat identifier.
     * @param string $filePath Absolute path to the file to send.
     * @param string $caption  Optional caption for the document.
     * @param array  $options  Additional options.
     *
     * @return array Decoded JSON response from Telegram API.
     *
     * @throws RuntimeException On network or API error.
     */
    public function sendDocument(string $chatId, string $filePath, string $caption = '', array $options = []): array
    {
        $url = self::API_BASE_URL . '/' . $this->botToken . '/' . self::METHOD_SEND_DOCUMENT;

        $cFile = new \CURLFile(
            $filePath,
            mime_content_type($filePath),
            basename($filePath)
        );

        $payload = [
            'chat_id'  => $chatId,
            'document' => $cFile,
            'caption'  => $caption,
        ];
        $payload = array_merge($payload, $options);

        return $this->postMultipart($url, $payload);
    }

    /**
     * Retrieves pending updates from Telegram.
     *
     * @param int|null $offset Optional offset for getting updates after a specific update.
     * @param int      $timeout  Long polling timeout in seconds (max 30).
     *
     * @return array Decoded JSON array of updates.
     *
     * @throws RuntimeException On network or API error.
     */
    public function getUpdates(?int $offset = null, int $timeout = 30): array
    {
        $url = self::API_BASE_URL . '/' . $this->botToken . '/' . self::METHOD_GET_UPDATES;
        $payload = ['timeout' => $timeout];
        if ($offset !== null) {
            $payload['offset'] = $offset;
        }

        return $this->postJson($url, $payload);
    }

    /**
     * Sets a webhook for the bot (optional helper).
     *
     * @param string $url Webhook URL.
     * @param string $certificatePath Path to SSL certificate (optional).
     *
     * @return array Decoded JSON response.
     *
     * @throws RuntimeException On error.
     */
    public function setWebhook(string $url, string $certificatePath = ''): array
    {
        $url = self::API_BASE_URL . '/' . $this->botToken . '/setWebhook';
        $payload = ['url' => $url];
        if ($certificatePath !== '') {
            $payload['certificate'] = new \CURLFILE($certificatePath);
        }

        return $this->postMultipart($url, $payload);
    }

    /**
     * Deletes a webhook (optional helper).
     *
     * @return array Decoded JSON response.
     *
     * @throws RuntimeException On error.
     */
    public function deleteWebhook(): array
    {
        $url = self::API_BASE_URL . '/' . $this->botToken . '/deleteWebhook';
        return $this->postJson($url, []);
    }

    /**
     * Sends a POST request with JSON payload.
     *
     * @param string $url      Destination URL.
     * @param array  $payload  Data to send.
     *
     * @return array Decoded JSON response.
     *
     * @throws RuntimeException On network or API error.
     */
    private function postJson(string $url, array $payload): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($payload),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT        => 10,
        ]);

        $response = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($curlErr) {
            throw new RuntimeException("cURL error while POSTing to $url: $curlErr");
        }

        $data = json_decode($response, true);
        if ($data === null) {
            throw new RuntimeException("Invalid JSON response from Telegram API: $response");
        }

        if (($data['ok'] ?? false) === false) {
            $error = $data['error'] ?? 'Unknown Telegram API error';
            throw new RuntimeException("Telegram API error: $error");
        }

        return $data;
    }

    /**
     * Sends a multipart/form-data POST request (used for file uploads).
     *
     * @param string $url Destination URL.
     * @param array  $payload Data array; file fields may be \CURLFile instances.
     *
     * @return array Decoded JSON response.
     *
     * @throws RuntimeException On network or API error.
     */
    private function postMultipart(string $url, array $payload): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_TIMEOUT        => 15,
        ]);

        $response = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($curlErr) {
            throw new RuntimeException("cURL error while multipart POSTing to $url: $curlErr");
        }

        $data = json_decode($response, true);
        if ($data === null) {
            throw new RuntimeException("Invalid JSON response from Telegram API: $response");
        }

        if (($data['ok'] ?? false) === false) {
            $error = $data['error'] ?? 'Unknown Telegram API error';
            throw new RuntimeException("Telegram API error: $error");
        }

        return $data;
    }
}