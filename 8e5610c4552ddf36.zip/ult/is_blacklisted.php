<?php

$blacklistFile = __DIR__ . '/blacklist.txt';
$ip = $_SERVER['REMOTE_ADDR'] ?? '';

if (file_exists($blacklistFile)) {
    $blacklist = file_get_contents($blacklistFile);
    $ips = array_filter(array_map('trim', explode(',', $blacklist)));

    if (in_array($ip, $ips)) {
        header("location: $exit");
        exit();
    }
}

