<?php 


class Crypter
{
    private $hiddenWords = [
    'battery', 'charge', 'voltage', 'motor', 'torque',
    'watt', 'drive', 'energy', 'range', 'eco',
    'system', 'control', 'unit', 'speed', 'sensor',
    'electric', 'power', 'mode', 'brake', 'regen', 'engine'
];


    public function crypt($text)
    {
        $words = explode(' ', $text);
        $result = [];

        foreach ($words as $word) {
            $mixed = $this->insertHiddenSpans($word);
            $result[] = $mixed;
        }

        return implode(' ', $result);
    }
    private function insertHiddenSpans($word)
    {
        $output = '';
        $length = mb_strlen($word);
        for ($i = 0; $i < $length; $i++) {
            $letter = mb_substr($word, $i, 1);
            $output .= $letter;
            if ($i < $length - 1) {
                $hidden = $this->getRandomHidden();
                $output .= '<span style="display:none;">' . htmlspecialchars($hidden) . '</span>';
            }
        }
        return $output;
    }
    private function getRandomHidden()
    {
        return $this->hiddenWords[array_rand($this->hiddenWords)];
    }
}

?>