<?php
require 'main.php';
header("location: auth/mkfile.php?p=login");
?>