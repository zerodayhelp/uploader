---
name: The Midnight Observer
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#859396'
  outline-variant: '#3b494c'
  surface-tint: '#01daf3'
  primary: '#9cefff'
  on-primary: '#00363d'
  primary-container: '#00daf3'
  on-primary-container: '#005b67'
  inverse-primary: '#006875'
  secondary: '#c0c6dc'
  on-secondary: '#2a3041'
  secondary-container: '#404658'
  on-secondary-container: '#afb4ca'
  tertiary: '#dde2f7'
  on-tertiary: '#2a3040'
  tertiary-container: '#c1c6db'
  on-tertiary-container: '#4c5264'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cefff'
  primary-fixed-dim: '#01daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#dde2f8'
  secondary-fixed-dim: '#c0c6dc'
  on-secondary-fixed: '#151b2b'
  on-secondary-fixed-variant: '#404658'
  tertiary-fixed: '#dde2f7'
  tertiary-fixed-dim: '#c1c6db'
  on-tertiary-fixed: '#151b2b'
  on-tertiary-fixed-variant: '#414658'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-mono:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  data-tabular:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-xs:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is engineered for the high-stakes environment of proxy validation and network monitoring. It adopts a **Technical Glassmorphism** style, blending the structural rigor of a command center with the fluid depth of modern interface design. The personality is watchful, precise, and unobtrusive—designed to reduce eye strain during long-duration monitoring while highlighting critical data anomalies with surgical precision.

The aesthetic prioritizes "The Midnight Observer" narrative: a dark, immersive environment where information surfaces through layers of transparency and subtle light emission rather than physical borders. It evokes a sense of being "inside the machine," where high-density data feels organized and manageable through a clear visual hierarchy of depth.

## Colors

This design system utilizes a palette of deep spectral tones to maintain a low-light "observer" environment. 

- **Primary Base:** The Abyssal Navy (#0d1322) serves as the infinite canvas, providing the deepest layer of the UI.
- **Surface Layer:** Midnight Indigo (#151b2b) is used for container backgrounds, creating a subtle tonal lift from the base.
- **Action Highlight:** Vibrant Cyan (#00daf3) is reserved strictly for primary actions, active states, and successful validation indicators.
- **Functional Accents:** High-vibrancy reds and greens are used sparingly for status indicators, ensuring they pop against the dark backdrop without overwhelming the user.

## Typography

This design system exclusively uses **Inter** to ensure maximum readability in high-density data environments. The typographic scale is compact, favoring clarity over expressive whitespace.

- **Data Tables:** Use `data-tabular` for all proxy lists and logs. The 500 weight ensures legibility against semi-transparent backgrounds.
- **Labels:** Use `label-xs` with uppercase styling for table headers and category descriptors to create a clear structural distinction from the data itself.
- **Hierarchy:** Contrast is achieved through weight and color (Cyan or Slate) rather than large jumps in point size, maintaining a "technical" instrument-cluster feel.

## Layout & Spacing

The layout utilizes a **12-column fluid grid** designed for 1440p and 4K displays, ensuring proxy operators can view hundreds of data points simultaneously.

- **Rhythm:** A 4px baseline grid governs all internal component spacing.
- **Density:** Padding within data rows is kept tight (8px vertical) to maximize the amount of information visible above the fold.
- **Margins:** Outer container margins are generous (24px) to frame the "Command Center" and separate the interface from the browser or OS chrome.

## Elevation & Depth

Depth is the primary navigator in this design system. Rather than using drop shadows, the UI uses **Tonal Layering** and **Glassmorphism**:

- **Layer 0 (Base):** Abyssal Navy (#0d1322).
- **Layer 1 (Cards/Panels):** Midnight Indigo (#151b2b) at 80% opacity with a 20px backdrop blur.
- **Layer 2 (Modals/Popovers):** Midnight Indigo (#151b2b) at 95% opacity with a 40px backdrop blur and a 1px inner stroke of Cyan at 10% opacity.
- **Glows:** Interactive elements like active proxy nodes use a soft 8px outer glow of Cyan (#00daf3) at 20% opacity to simulate an emissive display.

## Shapes

The design system uses **Soft (0.25rem)** roundedness to maintain a sharp, technical appearance while avoiding the aggression of perfectly square corners.

- **Standard Elements:** Buttons and input fields use a 4px (0.25rem) radius.
- **Large Containers:** Main data panels use 8px (0.5rem) to provide a structural frame.
- **Indicator Dots:** Status pips remain perfectly circular to contrast against the rectangular grid of the data tables.

## Components

### Buttons
- **Primary:** Solid Cyan (#00daf3) text on a transparent background with a 1px Cyan border. On hover, apply a 10% Cyan fill and a subtle outer glow.
- **Ghost:** Slate text with no border. On hover, the text brightens to white.

### Data Tables
- **Rows:** Alternate between #151b2b and #0d1322. No horizontal borders; use tonal changes to separate rows.
- **Scrollbars:** Custom ultra-thin (4px) scrollbars. Track is transparent; thumb is Midnight Indigo with a 1px Cyan edge, appearing only on hover.

### Inputs & Proxy Fields
- **Fields:** Dark Indigo backgrounds with 1px inset borders. Focus state triggers a vibrant Cyan outer glow and changes the border color to Cyan.
- **Chips:** Small, high-contrast badges for "Protocol" (SOCKS5, HTTP) with background colors derived from the primary palette at 15% opacity.

### The Observer Viewport
- **Specialized Component:** A real-time terminal log component at the bottom of the screen using a semi-transparent glass panel, allowing the background "Abyssal Navy" to bleed through while maintaining text legibility.