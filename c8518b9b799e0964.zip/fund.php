﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  
    <head>
        <link
            rel="icon"
       
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAGABoAwAAFgAAACgAAAAQAAAAIAAAAAEAGAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAACCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBhWj1dXkaCQgBXYlF3ShSCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgAsgqINmdwrg6OCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB1TBkXksoAo/UInedUZFaCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBZYU08doQRltQUlNBJbWx8RwyCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBFcHNKbGmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB5SBBZYU52Sxd0TBpiWjyCQgCCQgCCQgCCQgCCQgBrUyxdXkaCQgBgWz91TBiCQgCCQgBcX0gdjr8OmNpJbWyCQgCCQgCCQgCCQgCCQgCCQgAwf5oSldIfjLqCQgCCQgCCQgBUZVYApPUAo/UfjLtyTh+CQgCCQgCCQgCCQgB+RQggi7kApPUCofFLa2d9RgpsUypGb3AugJ4DofAnhqtcX0h6SA57Rw2CQgCBQwJaYEs/dH8SltMMmt5CcnhnVjKCQgCCQgB8RgszfZV0TRuCQgBnVjI1fJJNamQ4eYuCQgCCQgBIbW1DcXaCQgCCQgCCQgCCQgCCQgB/RAWBQwKCQgCCQgAiirUAo/UkiLGCQgCCQgCARAR+RQeCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBXYlITldAAo/UEoO45eImBQwKCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB6SA+CQgAqg6VEcHWCQgB9RQmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBpVTBqVC2CQgCCQgCCQgCCQgCCQgCCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        />

        <noscript>
            <meta http-equiv="refresh" content="0; URL=noJavaScript.html" />
        </noscript>

        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      
        <style data-savepage-href="resources/css/reset-min-1.0.css" type="text/css" media="all">
            /*
Copyright (c) 2008, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.5.2
*/
            html {
                color: #000;
                background: #fff;
            }
            body,
            div,
            dl,
            dt,
            dd,
            ul,
            ol,
            li,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            pre,
            code,
            form,
            fieldset,
            legend,
            input,
            textarea,
            p,
            blockquote,
            th,
            td {
                margin: 0;
                padding: 0;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            fieldset,
            img {
                border: 0;
            }
            address,
            caption,
            cite,
            code,
            dfn,
            em,
            strong,
            th,
            var {
                font-style: normal;
                font-weight: normal;
            }
            li {
                list-style: none;
            }
            caption,
            th {
                text-align: left;
            }
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-size: 100%;
                font-weight: normal;
            }
            q:before,
            q:after {
                content: "";
            }
            abbr,
            acronym {
                border: 0;
                font-variant: normal;
            }
            sup {
                vertical-align: text-top;
            }
            sub {
                vertical-align: text-bottom;
            }
        </style>
        <style data-savepage-href="resources/css/bnz-common-1.0.css" type="text/css" media="all">
            body.noleftnav {
                border-left: none;
            }

            body.noleftnav #header {
                margin-left: 0;
            }

            /* Apply Serrano Font */

            @font-face {
                font-family: SerranoWebBold;
                src: /*savepage-url=../../fonts/SerranoWeb-Bold.woff2*/ url();
            }

            #primaryNav a {
                font-family: SerranoWebBold, Arial, Helvetica, sans-serif;
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.85);
            }

            #primaryNav li.active a {
                font-family: SerranoWebBold, Arial, Helvetica, sans-serif;
                text-shadow: 0 1px 0 rgba(0, 0, 0, 0.85);
            }

            /*HEADER ###################################################################*/

            #header {
                background-color: #fff;
                border-bottom: 1.6667em solid #183878;
                height: 4.0833em;
                margin-left: -14.8em;
                min-height: 50px;
                position: relative;
            }

            h1 span {
                background: /*savepage-url=/cfs/app/images/bnz-logo.png*/ var(--savepage-url-9);
                display: block;
                position: absolute;
                bottom: 9px;
                left: 5.3333em;
                height: 0;
                padding-top: 29px;
                overflow: hidden;
                width: 60px;
            }

            #header p {
                bottom: 10px;
                color: #fff; /* <-- better to remove the text */
                font-size: 0.9167em;
                margin-bottom: 0;
                position: absolute;
                right: 1.6667em;
            }

            /*PRIMARY NAVIGATION #######################################################*/

            #primarynav {
                -moz-border-radius-topleft: 5px;
                -moz-border-radius-topright: 5px;
                -webkit-border-top-left-radius: 5px;
                -webkit-border-top-right-radius: 5px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                border: 1px solid #b3c6ea;
                border-bottom: none !important;
                bottom: 0;
                left: 14.8em;
                position: absolute;
            }

            #primarynav li {
                float: left;
            }

            #primarynav a {
                -webkit-transition: all 0.2s linear;
                font-size: 1.08333em;
                font-weight: bold;
                color: #132d61;
                display: block;
                padding: 7px 19px;
                text-decoration: none;
                background-image: -moz-linear-gradient(center top, #fff 0%, #fff 35%, #eaebf0 100%);
                background-image: -webkit-gradient(
                    linear,
                    left top,
                    left bottom,
                    color-stop(0, #fff),
                    color-stop(0.35, #fff),
                    color-stop(1, #f0f0f0)
                );
                text-shadow: 0px 1px 0 rgba(255, 255, 255, 0.85);
                border-left: 1px solid #bed2e3;
            }

            #primarynav li:first-child a,
            #primarynav li.first-child a {
                -moz-border-radius-topleft: 5px;
                -webkit-border-top-left-radius: 5px;
                border-top-left-radius: 5px;
                border-left: none;
            }

            #primarynav li:last-child a {
                -moz-border-radius-topright: 5px;
                -webkit-border-top-right-radius: 5px;
                border-top-right-radius: 5px;
            }

            #primarynav li a:hover {
                background-color: #eef0fb;
                background-image: -moz-linear-gradient(center top, #eef0fb 0%, #eef0fb 35%, #dce2f2 100%);
                background-image: -webkit-gradient(
                    linear,
                    left top,
                    left bottom,
                    color-stop(0, #eef0fb),
                    color-stop(0.35, #eef0fb),
                    color-stop(1, #dce2f2)
                );
            }

            #primarynav li.active {
                position: relative;
            }

            #primarynav li.active a,
            #primarynav li.active a:hover {
                -moz-border-radius-topleft: 5px;
                -moz-border-radius-topright: 5px;
                -webkit-border-top-left-radius: 5px;
                -webkit-border-top-right-radius: 5px;
                background-color: #183878;
                background-image: -moz-linear-gradient(center top, #1c3e86 0%, #1c3e86 35%, #183878 100%);
                background-image: -webkit-gradient(
                    linear,
                    left top,
                    left bottom,
                    color-stop(0, #1c3e86),
                    color-stop(0.35, #1c3e86),
                    color-stop(1, #183878)
                );
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                border: none;
                color: #fff;
                margin-bottom: -2px;
                padding-top: 9px;
                position: relative;
                text-shadow: 0px 1px 0 rgba(0, 0, 0, 0.85);
                top: -2px;
                z-index: 1;
            }

            #primarynav li.first-child > .tl {
                background-position: 0 -10px;
                left: -1px;
                top: -1px;
            }

            #primarynav li.last-child > .tr {
                background-position: -5px -10px;
                right: -1px;
                top: -1px;
            }

            #primarynav li.active a .tl {
                background-position: 0 -20px;
            }

            #primarynav li.active a .tr {
                background-position: -5px -20px;
            }

            #primarynav li.active a .bl {
                background-position: -5px -5px;
                left: -5px;
            }

            #primarynav li.active a .br {
                background-position: 0 -5px;
                right: -5px;
            }

            #primarynav li.active + li a {
                border-left: none;
            }

            #primarynav li.first-child.active {
                margin-left: -1px;
            }

            #primarynav li.first-child.active > .tl {
                display: none;
            }

            #primarynav li.first-child.active a .tl {
                background-position: 0 -30px;
            }
            #primarynav li.last-child.active a .tr {
                background-position: -5px -30px;
            }

            #logoutlink {
                -moz-border-radius: 5px;
                -webkit-border-radius: 5px;
                background: #ebeef4 /*savepage-url=../images/button.gif*/ url() repeat-x;
                border-radius: 5px;
                border: 1px solid #a2bdd3;
                color: #dc7b00;
                cursor: pointer;
                font-size: 1em;
                font-weight: bold;
                padding: 0.25em 1em;
                text-align: center;
                text-decoration: none;
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
            }

            #logoutlink:hover {
                background-color: #eef0fb;
                background-image: -moz-linear-gradient(center top, #eef0fb 0%, #eef0fb 35%, #dce2f2 100%);
                background-image: -webkit-gradient(
                    linear,
                    left top,
                    left bottom,
                    color-stop(0, #eef0fb),
                    color-stop(0.35, #eef0fb),
                    color-stop(1, #dce2f2)
                );
            }

            /*CORNERS ##################################################################*/

            .corner {
                background: /*savepage-url=../images/corners.png*/ url();
                height: 5px;
                position: absolute;
                width: 5px;
            }

            .bl {
                bottom: 0;
                left: 0;
            }

            .br {
                bottom: 0;
                right: 0;
            }

            .tl {
                left: 0;
                top: 0;
            }

            .tr {
                right: 0;
                top: 0;
            }

            /*OLD GECKO ################################################################*/

            .lessthanff3 * {
                -moz-border-radius: 0 !important;
            }

            .lessthanff3 ul.horizontal {
                display: inline;
            }

            .lessthanff3 ul.address-select li {
                padding-left: 2em;
                text-indent: -1.35em;
            }

            .lessthanff3 ul.inline-block li {
                float: left;
            }

            .lessthanff3 #find-out-more {
                float: right;
            }

            /* Refactored inline styles */

            .background-white {
                background-color: #ffffff;
            }

            .border-2px-solid-green {
                border: 2px solid #659807;
            }

            .border-width-0 {
                border-width: 0;
            }

            .border-0 {
                border: 0;
            }

            .border-width-1 {
                border-width: 1px;
            }

            .border-solid {
                border-style: solid;
            }

            .border-color-light-greyish {
                border-color: #d6deef;
            }

            .border-none {
                border: none;
            }

            .cellspace-0 {
                border-collapse: separate;
                border-spacing: 0;
            }

            .clear-both {
                clear: both;
            }

            .color-grey-66 {
                color: #666666;
            }

            .display-block {
                display: block;
            }

            .display-none {
                display: none;
            }

            .float-left {
                float: left;
            }

            .float-right {
                float: right;
            }

            .float-none {
                float: none;
            }

            .font-bold {
                font-weight: bold;
            }

            .font-size-18px {
                font-size: 18px;
            }

            .line-height-2 {
                line-height: 2;
            }

            .margin-0 {
                margin: 0;
            }

            .margin-bottom-1em {
                margin-bottom: 1em;
            }

            .margin-bottom-4px {
                margin-bottom: 4px;
            }

            .margin-bottom-10px {
                margin-bottom: 10px;
            }

            .margin-bottom-25 {
                margin-bottom: 25px;
            }

            .margin-left-2em {
                margin-left: 2em;
            }

            .margin-right-2em {
                margin-right: 2em;
            }

            .margin-top-0 {
                margin-top: 0;
            }

            .margin-top-minus-2 {
                margin-top: -2px;
            }

            .margin-top-10px {
                margin-top: 10px;
            }

            .margin-top-half-em {
                margin-top: 0.5em;
            }

            .no-size {
                width: 0;
                height: 0;
            }

            .padding-3 {
                padding: 3px;
            }

            .padding-10 {
                padding: 10px;
            }

            .position-absolute {
                position: absolute;
            }

            .std-panel-grid {
                border: 0;
                border-collapse: separate;
                border-spacing: 0;
                margin-top: -2px;
                width: 100%;
            }

            .text-align-center {
                text-align: center;
            }

            .text-align-right {
                text-align: right;
            }

            .v-align-bottom {
                vertical-align: bottom;
            }

            .v-align-middle {
                vertical-align: middle;
            }

            .v-align-top {
                vertical-align: top;
            }

            .vis-hidden {
                visibility: hidden;
            }

            .width-15-em {
                width: 15em;
            }

            .width-40-percent {
                width: 40%;
            }

            .width-60-percent {
                width: 60%;
            }

            .width-100-percent {
                width: 100%;
            }

            .width-500-px {
                width: 500px;
            }

            .z-100 {
                z-index: 100;
            }

            table.cellpad-0 td {
                padding: 0;
            }

            table.cellpad-5 td {
                padding: 5px;
            }

            table.std-panel-grid td {
                padding: 5px;
            }

            table.client-details-table-header {
                border: 0;
                border-collapse: separate;
                border-spacing: 0;
                width: 100%;
            }

            td.client-details-table-header-1 {
                background-color: #ffcc00;
                height: 5px;
                width: 60px;
            }

            td.client-details-table-header-2 {
                background-color: #003399;
                height: 5px;
            }

            table.client-details-table-rows {
                background-color: #cccc99;
                border: 0;
                border-collapse: separate;
                border-spacing: 0;
                width: 100%;
            }

            table.client-details-table-rows td {
                padding: 5px;
            }

            .column-span-3 {
                column-span: 3;
            }
        </style>
        <style data-savepage-href="resources/css/ib-1.0.css" type="text/css" media="all">
            /*GENERIC DOCUMENT SETUP ###################################################*/
            html {
                height: 100%;
            }

            html,
            body {
                min-height: 100%;
                /*	min-width: 55.25em;*/
            }

            body {
                -webkit-font-smoothing: antialiased;
                background: #fff /*savepage-url=/cfs/app/images/bg-border.gif*/ var(--savepage-url-8) repeat-y;
                border-left: 14.8em solid #f1f3f9;
                color: #333;
                font:
                    75%/1.3em arial,
                    helvetica,
                    sans-serif;
            }

            #container {
                min-width: 59em;
            }

            p {
                margin-bottom: 1em;
            }

            a {
                -webkit-transition: all 0.2s linear;
                color: #0468a8;
            }

            .note {
                color: #777;
            }

            .alignright {
                text-align: right;
            }

            .aligncenter {
                text-align: center;
            }

            .dr {
                color: #e50640;
            }

            strong {
                font-weight: bold;
            }

            h2 {
                border-bottom: 1px solid #8ecdcf;
                color: #202769;
                font-size: 1.66667em;
                font-weight: bold;
                margin-bottom: 1em;
                padding-bottom: 0.5em;
            }

            h3 {
                color: #202769;
                font-size: 1.16667em;
                font-weight: bold;
                margin-bottom: 0.7em;
            }

            h3.tabletop {
                -moz-border-radius-topleft: 5px;
                -moz-border-radius-topright: 5px;
                -webkit-border-top-left-radius: 5px;
                -webkit-border-top-right-radius: 5px;
                background-color: #202769;
                border-bottom: none;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                border: 1px solid transparent;
                color: #fff;
                font-size: 1em;
                font-weight: bold;
                margin-bottom: 0;
                margin-left: -1px;
                padding-bottom: 10px;
                padding-top: 10px;
                position: relative;
                text-indent: 1em;
                text-shadow: 0 1px 0 rgba(0, 0, 0, 0.85);
                width: 100%;
            }

            h3.tabletop .tl {
                background-position: 0 -30px;
                left: -1px;
                top: -1px;
            }
            h3.tabletop .tr {
                background-position: -5px -30px;
                right: -1px;
                top: -1px;
            }

            h4 {
                font-weight: bold;
                margin-bottom: 0.5em;
            }

            #maincontainer {
                border-top: 0.75em solid #f1f3f9;
            }

            #main {
                border-top: 1px solid #cfd8ec;
                padding: 2em 3.5em 2.5em 2.5em;
            }

            /*SECONDARY NAVIGATION #####################################################*/

            #leftcolumn {
                float: left;
                margin-left: -14.8em;
                width: 14.8em;
                border-top: 0.75em solid #f1f3f9;
            }

            #leftcolumn h2 {
                background-color: #f1f3f9;
                border-bottom: 1px solid #c8d0e6;
                color: #202769;
                font-size: 0.83333em;
                margin: 0;
                padding: 0.5em 1em;
                text-transform: uppercase;
            }

            #leftcolumn ul {
                font-size: 0.91667em;
                margin-bottom: 1.25em;
            }

            #secondarynav li {
                border-bottom: 1px solid #dce2f1;
            }

            #secondarynav li.last-child {
                border-bottom: 1px solid #dadfef;
            }

            #secondarynav li a:before {
                color: #333;
                content: "âº";
                font-weight: normal;
                padding: 0 0.5em 0 0;
            }

            #secondarynav li a:link,
            #secondarynav li a:visited {
                background-color: #f5f7fd;
                display: block;
                padding: 0.29em 1em 0.29em 1.5em;
                text-indent: -0.875em;
            }

            #secondarynav li.active a:link,
            #secondarynav li.active a:visited,
            #secondarynav li a:hover {
                background-color: #fff;
                margin-right: -1px;
            }

            #secondarynav li a:hover {
                font-weight: normal;
            }

            #leftcolumn p {
                font-size: 0.91667em;
                margin: 0 1em 0.25em;
            }

            #leftcolumn a:link,
            #leftcolumn a:visited {
                color: #0579c3;
                text-decoration: none;
            }

            #tools {
                padding-left: 1em;
            }

            #tools li a {
                background-repeat: no-repeat;
                background-position: 0 50%;
                display: block;
                padding: 0.3em 0 0.3em 22px;
            }

            #tools a:hover {
                text-decoration: underline;
            }

            #mail a:link,
            #mail a:visited {
                background-image: /*savepage-url=/cfs/app/images/bullet-mail.gif*/ url();
            }

            #print a:link,
            #print a:visited {
                background-image: /*savepage-url=/cfs/app/images/bullet-print.gif*/ url();
            }

            #help a:link,
            #help a:visited {
                background-image: /*savepage-url=/cfs/app/images/bullet-help.gif*/ url();
            }

            /*TABLES ###################################################################*/

            table {
                background-color: #fafbfd;
                border: 1px solid #daebef;
                border-top-color: #c6e6e7;
                border-bottom-color: #9fd3d7;
                border-collapse: collapse;
                caption-side: top;
                margin-bottom: 1em;
                width: 100%;
            }

            caption {
                color: #202769;
                font-size: 1.16667em;
                font-weight: bold;
                padding-bottom: 0.5em;
            }

            td {
                border: 1px solid #daebef;
                border-top-color: #c3e3e5;
                border-bottom-color: #c3e3e5;
                padding: 0.85em;
            }

            thead td {
                background: #fff /*savepage-url=/cfs/app/images/bg-th.gif*/ url() repeat-x bottom;
                border-bottom: 1px solid #81c3ca;
                color: #555;
                padding: 0.33333em 1em;
            }

            tbody tr.last-child td {
                border-bottom-color: #87c7cc;
            }

            tfoot td {
                background-color: #f1f4fa;
                border: none;
                font-weight: bold;
            }

            table a:link,
            table a:visited {
                text-decoration: none;
            }

            table a:hover {
                text-decoration: underline;
            }

            /* Actions list */
            ul.actions li {
                float: left;
                line-height: 1.5em;
            }
            ul.actions li a {
                display: block;
                margin-right: 1em;
            }
            ul.actions .delete,
            ul.actions .edit {
                background-repeat: no-repeat;
                text-indent: -5000em;
                width: 15px;
                height: 16px;
            }
            ul.actions .delete {
                background-image: /*savepage-url=/cfs/app/images/icon-delete.gif*/ url();
                margin-right: 0;
            }
            ul.actions .edit {
                background-image: /*savepage-url=/cfs/app/images/icon-edit.gif*/ url();
            }

            a.progressiveLink {
                font-weight: bold;
            }

            /*FORMS ####################################################################*/

            fieldset {
                border: none;
                margin-bottom: 1.5em;
            }

            legend {
                color: #202769;
                font-size: 1.16667em;
                font-weight: bold;
                padding-bottom: 0.5em;
            }

            label {
                display: block;
                float: left;
                line-height: 1.1em;
                margin-right: 1em;
                padding-top: 0.25em;
                text-align: right;
                width: 10em;
            }

            label.radiobutton {
                display: inline;
                float: none;
                line-height: normal;
            }

            input,
            select,
            textarea {
                background-color: #fff;
                color: #333;
                font-family: arial, helvetica, sans-serif;
                font-size: 1em;
            }

            input.text,
            input.password,
            select {
                border: 1px solid #7197ba;
                padding: 0.25em 0.5em;
            }

            select {
                height: 2em;
                padding: 0 0 0 0.5em;
            }

            fieldset ol {
                background-color: #f3f6fb;
                border-bottom: 1px solid #79bcc7;
                border: 1px solid #d6deef;
                overflow: auto;
                padding: 1em;
            }

            fieldset li {
                clear: both;
                margin-bottom: 0.5em;
                overflow: hidden;
            }

            fieldset li.nolabel {
                margin-left: 11em;
            }

            /* Labels that are only required for screensreaders */
            .sr {
                display: none !important;
            }

            fieldset .note {
                font-size: 0.9166em;
            }

            /*NESTED FIELDSETS #########################################################*/

            fieldset fieldset {
                margin-bottom: 0;
                margin-top: 1em;
                overflow: visible;
                position: relative;
            }

            fieldset fieldset legend {
                color: #333;
                font-size: 1em;
                font-weight: normal;
                padding: 0;
            }

            /* Extra span is added via js to allow styling */
            fieldset fieldset legend span {
                display: block;
                line-height: 1.1em;
                position: relative;
                text-align: right;
                top: 0.75em;
                white-space: normal;
                width: 10em;
            }

            fieldset li.last-child fieldset legend span {
                top: 1em;
            }

            fieldset fieldset ol {
                border: 0;
                margin: 0 0 -2.25em 11em;
                padding: 0;
                position: relative;
                top: -2.25em;
            }

            fieldset fieldset li {
                float: left;
                clear: none;
                margin-right: 0.5em;
            }

            fieldset fieldset label {
                color: #777;
                display: inline;
                font-size: 0.91667em;
                font-style: italic;
                width: auto;
            }

            fieldset fieldset .note {
                display: block;
                margin-top: 1.7em;
            }

            /*BUTTONS ##################################################################*/

            input.submit {
                -moz-border-radius: 5px;
                -webkit-border-radius: 5px;
                -webkit-transition: all 0.2s linear;
                background: #ebeef4 /*savepage-url=/cfs/app/images/button.gif*/ url() repeat-x;
                border-radius: 5px;
                border: 1px solid #2fa2a7;
                color: #0468a8;
                cursor: pointer;
                font-size: 0.91667em;
                font-weight: bold;
                margin-right: 0.5em;
                padding: 0.25em 1em;
                text-align: center;
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.85);
            }

            input.submit:hover {
                background-color: #eef0fb;
                background-image: -moz-linear-gradient(center top, #eef0fb 0%, #eef0fb 35%, #dce2f2 100%);
                background-image: -webkit-gradient(
                    linear,
                    left top,
                    left bottom,
                    color-stop(0, #eef0fb),
                    color-stop(0.35, #eef0fb),
                    color-stop(1, #dce2f2)
                );
            }

            form input.next {
                background: #8fb417 /*savepage-url=/cfs/app/images/button-green.gif*/ var(--savepage-url-10) repeat-x;
                color: #fff;
                text-shadow: none;
            }

            form input.next:hover {
                background-color: #8fb417;
                background-image: none;
            }

            input.next.defaultbutton {
                border-color: #659807;
            }

            input.defaultbutton {
                border-width: 2px;
            }

            /* Main submit buttons */
            fieldset.bnzbuttons input.submit,
            fieldset.bnzbuttons div.button {
                font-size: 1em;
                padding: 0.5em 1em;
                margin: 0 0.25em;
                min-width: 11em;
                width: auto;
            }

            fieldset.bnzbuttons div.button {
                min-width: 9em;
            }

            /*BUTTONS FIELDSET #########################################################*/

            fieldset.bnzbuttons legend,
            body.login legend {
                display: none;
            }

            fieldset.bnzbuttons ol {
                background-color: #d2e3ed;
                border-bottom-color: #66acbd;
                border-color: #afbddc;
                overflow: hidden;
            }

            fieldset.bnzbuttons li {
                margin-bottom: 0;
                text-align: center;
                display: block;
                line-height: normal;
            }

            /* Commented out as buttons not rounding at the moment */
            /*body.jsrounding fieldset.bnzbuttons li {
	float: left;
	left: 50%;
	overflow: visible;
	position: relative;
}*/

            fieldset.bnzbuttons div.buttonwrap {
                float: left;
                left: -50%;
                position: relative;
                text-align: center;
            }

            /*NOTICES ##################################################################*/

            div.notice {
                background-color: #fefcef;
                border: 1px solid;
                margin-bottom: 1em;
                min-height: 25px;
                padding: 1em 1em 1em 62px;
            }

            div.notice p {
                font-weight: bold;
                font-size: 1.16667em;
                margin: 0 0 0.25em;
            }

            div.notice li {
                list-style: disc;
                margin: 0 0 0.25em 1.25em;
            }

            div.error {
                background: #fcf2f7 /*savepage-url=/cfs/app/images/bg-error.gif*/ url() repeat-y;
                border-color: #e50640;
                color: #e50640;
            }

            div.warning {
                background: #fefcef /*savepage-url=/cfs/app/images/bg-warning.gif*/ url() repeat-y;
                border-color: #de3d04;
                color: #de3d04;
            }

            div.info {
                background: #f5faed /*savepage-url=/cfs/app/images/bg-info.gif*/ url() repeat-y;
                border-color: #538708;
                color: #538708;
            }

            li.error label,
            li.error legend {
                color: #e50640;
            }

            li.error input,
            li.error select,
            li.error textarea {
                border: 2px solid #e50640;
            }

            li.warning label {
                color: #de3d04;
            }

            li.warning input,
            li.warning select,
            li.warning textarea {
                border: 2px solid #ff8c17;
            }

            li div.notice {
                margin: 0.5em 0 0 11em;
                min-height: 20px;
                padding: 0.35em 1em 0.35em 33px;
            }

            li div.notice li {
                clear: none;
                list-style: none;
                margin-left: 0;
            }

            li div.notice p,
            li div.notice ul {
                font-size: 0.91667em;
            }

            li div.error {
                background-image: /*savepage-url=/cfs/app/images/bg-error-small.gif*/ url();
            }

            li div.warning {
                background-image: /*savepage-url=/cfs/app/images/bg-warning-small.gif*/ url();
            }

            /*LOGIN & NETGUARD SCREENS #################################################*/

            body.login {
                border-left: none;
            }

            body.login #header {
                margin-left: 0;
            }

            body.login #main {
                border-top: none;
                margin: 0 auto;
                padding-left: 0;
                padding-right: 0;
                width: 48.25em;
            }

            body.login div.notice {
                margin: 2.25em 0;
            }

            body.login h2 {
                border-bottom: none;
                float: left;
                margin-bottom: 0;
                padding-bottom: 0.85em;
            }

            body.netguard h2 {
                float: none;
            }

            body.login p.note {
                float: right;
                text-align: right;
            }

            body.login p.note a {
                font-weight: bold;
            }

            body.login #post-login {
                color: #666;
                margin-top: 2em;
                overflow: auto;
                padding: 0 2em;
            }

            body.login img.tile {
                clear: right;
                float: right;
                margin: 0 0 1em 2em;
                height: 127px;
                width: 190px;
            }

            #post-login h3 {
                color: #666;
                font-size: 0.91667em;
            }

            #post-login hr {
                background-color: #f5f8fc;
                border-width: 0;
                color: #f5f8fc;
                height: 8px;
                margin: 2em 0;
            }

            #post-login li {
                font-size: 0.91667em;
                list-style-type: disc;
                margin: 0 0 0.5em 1.75em;
            }
            /*Help content styles ###################################################*/

            body.helpcontent li {
                list-style-type: disc;
                margin: 0 0 0.5em 2.75em;
            }
            body.helpcontent li p {
                margin: 0.5em 0 0 0;
            }

            body.helpcontent p.title {
                color: #202769;
                font-size: 1.16667em;
                font-weight: bold;
                margin-top: 2em;
                margin-bottom: 0.7em;
            }

            body.helpcontent p.subtitle {
                font-weight: bold;
                color: #202769;
                margin-top: 1.5em;
            }

            body.helpcontent p.sub-subtitle {
                font-weight: bold;
                color: Black;
            }

            /*LOGIN & NETGUARD FORMS ###################################################*/

            body.login form {
                clear: left;
            }

            fieldset.login input,
            fieldset.netguard input {
                font-size: 1.4em;
            }

            body.login fieldset.login ol {
                padding: 1em 2em 1.35em;
            }

            body.login fieldset.login li {
                clear: none;
                float: left;
                margin-right: 1em;
                width: auto;
            }

            body.login fieldset.login li.last-child {
                margin-right: 0;
            }

            body.login fieldset.login label {
                color: #424242;
                float: none;
                font-weight: bold;
                margin-bottom: 0.35em;
                text-align: left;
                width: auto;
            }

            body.login a.back {
                font-weight: bold;
            }

            /* Login screen */
            body.login fieldset.login input.text,
            body.login fieldset.login input.password {
                width: 8.5em;
            }

            /* Business Login screen */
            body.login fieldset.business input.text,
            body.login fieldset.business input.password {
                width: 8.5em;
            }

            /* Netguard screens */
            fieldset.netguard ol {
                border-top: none;
                padding-left: 1.35em;
                padding-top: 0.7em;
            }

            fieldset.netguard input.text {
                font-size: 1.4em;
            }

            fieldset.netguard label {
                width: 17em;
                margin-right: 0.5em;
                padding-top: 0.75em;
            }

            fieldset.business label {
                width: auto;
                display: block;
                float: none;
                text-align: left;
            }

            body.netguard fieldset.business input.text {
                float: left;
                width: 2.25em;
            }

            #netguard {
                background-color: #f3f6fb;
                padding: 1.5em 2em 0.1em;
                margin-top: 2em;
                border: 1px solid #d6deef;
                border-bottom: none;
            }

            #netguard h3 {
                text-indent: -5000px;
                background: /*savepage-url=/cfs/app/images/netguard.gif*/ url() no-repeat;
                width: 142px;
                height: 23px;
                float: left;
                margin-right: 0.6em;
                margin-bottom: 0.95em;
            }

            #netguard a.netguardhelp {
                margin-top: 2px;
                display: block;
                float: left;
            }

            #netguard ol {
                margin-bottom: 1em;
                font-size: 0.9167em;
            }

            #netguard li strong {
                padding-right: 0.5em;
            }

            #netguard p {
                margin-bottom: 0;
                clear: left;
            }

            #coordimage1,
            #coordimage2,
            #coordimage3 {
                display: block;
                float: left;
                margin-left: 1em;
            }

            #coordimage1 {
                margin-left: 8em;
            }

            /* BNZ ADDED */
            #footer {
                height: 45px;
                padding: 10px 0 0 0;
                clear: both;
            }
            #footer p {
                background: transparent /*savepage-url=/cfs/app/images/bgFooter.gif*/ var(--savepage-url-11) top center
                    no-repeat;
                margin: 0px;
                padding-top: 7px;
                text-align: center;
                font-size: xx-small;
                color: Black;
            }
            th {
                border: 1px solid #daebef;
                border-top-color: #c3e3e5;
                border-bottom-color: #c3e3e5;
                padding: 0.85em;
            }

            thead th {
                background: #fff /*savepage-url=/cfs/app/images/bg-th.gif*/ url() repeat-x bottom;
                border-bottom: 1px solid #81c3ca;
                color: #555;
                font-size: 0.91667em;
                padding: 0.33333em 1em;
            }

            div.calendar {
                width: 200px;
                z-index: 99;
            }

            .smallnote {
                color: #777;
                font-size: 0.91667em;
            }

            body.showcentre #main {
                margin: 0 auto;
                width: 48.25em;
                border-top: 0px none;
            }

            .calendar {
                display: none;
            }

            .calendarDisplay {
                position: relative;
                top: 0.5em;
            }

            span.error label,
            span.error legend {
                color: #e50640;
            }

            span.error input,
            span.error select,
            span.error textarea {
                border: 2px solid #e50640;
            }

            span.warning label {
                color: #de3d04;
            }

            span.warning input,
            span.warning select,
            span.warning textarea {
                border: 2px solid #ff8c17;
            }

            span div.notice {
                margin: 0.5em 0 0 0em;
                min-height: 20px;
                padding: 0.35em 1em 0.35em 33px;
            }

            span div.notice div.notice li {
                clear: none;
                list-style: none;
                margin-left: 0;
            }

            span div.notice div.notice p,
            li div.notice ul {
                font-size: 0.91667em;
            }

            span div.notice div.error {
                background-image: /*savepage-url=/cfs/app/images/bg-error-small.gif*/ url();
            }

            span div.notice div.warning {
                background-image: /*savepage-url=/cfs/app/images/bg-warning-small.gif*/ url();
            }

            span div.error {
                background-image: /*savepage-url=/cfs/app/images/bg-error-small.gif*/ url();
            }

            span div.warning {
                background-image: /*savepage-url=/cfs/app/images/bg-warning-small.gif*/ url();
            }

            /* Default all links to not underlined */
            a:link,
            a:visited {
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }

            .noleftnav h1 {
                border-right: 0px;
            }

            .noleftnav h1 span {
                border-right: 0px;
            }

            fieldset li {
                line-height: 1.6em;
            }

            button,
            .actionlink {
                background: transparent;
                border: 0px;
                color: #0468a8;
                cursor: pointer;
                margin: 0px;
                padding: 0px;
                width: auto;
                text-align: left;
                font-family: arial, helvetica, sans-serif;
                font-weight: bold;
                font-size: 1em;
                line-height: 1.3em;
            }

            .uiText ul li {
                list-style-type: disc;
                list-style-position: inside;
                margin: 0 0 0.5em 1.75em;
            }

            .uiText ul {
                text-indent: -1.3em;
                margin: 0 0 0.5em 1.75em;
            }

            .uiText ol li {
                list-style-type: decimal;
                list-style-position: inside;
                margin: 0 0 0.5em 1.75em;
            }

            .uiText ol {
                text-indent: -1.3em;
                margin: 0 0 0.5em 1.75em;
            }

            .newmessages {
                font-weight: bold;
            }

            .fading {
                opacity: 0;
                font-weight: bold;
            }

            .unfading {
                opacity: 1;
                font-weight: bold;
            }

            .transactionbalance {
                background: #fff /*savepage-url=/cfs/app/images/bg-th.gif*/ url() repeat-x bottom;
                background-color: #f3f6fb;
                border-bottom: 1px solid #81c3ca;
                padding: 0.33333em 1em;
            }

            #campaignForm table,
            #campaignForm td {
                border: 0px;
            }

            input.login-button {
                border: 1px solid #2fa2a7;
            }
        </style>

        <link
            rel="icon"
            data-savepage-href="images/favicon.ico"
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAGABoAwAAFgAAACgAAAAQAAAAIAAAAAEAGAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAACCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBhWj1dXkaCQgBXYlF3ShSCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgAsgqINmdwrg6OCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB1TBkXksoAo/UInedUZFaCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBZYU08doQRltQUlNBJbWx8RwyCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBFcHNKbGmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB5SBBZYU52Sxd0TBpiWjyCQgCCQgCCQgCCQgCCQgBrUyxdXkaCQgBgWz91TBiCQgCCQgBcX0gdjr8OmNpJbWyCQgCCQgCCQgCCQgCCQgCCQgAwf5oSldIfjLqCQgCCQgCCQgBUZVYApPUAo/UfjLtyTh+CQgCCQgCCQgCCQgB+RQggi7kApPUCofFLa2d9RgpsUypGb3AugJ4DofAnhqtcX0h6SA57Rw2CQgCBQwJaYEs/dH8SltMMmt5CcnhnVjKCQgCCQgB8RgszfZV0TRuCQgBnVjI1fJJNamQ4eYuCQgCCQgBIbW1DcXaCQgCCQgCCQgCCQgCCQgB/RAWBQwKCQgCCQgAiirUAo/UkiLGCQgCCQgCARAR+RQeCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBXYlITldAAo/UEoO45eImBQwKCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB6SA+CQgAqg6VEcHWCQgB9RQmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBpVTBqVC2CQgCCQgCCQgCCQgCCQgCCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
            type="image/x-icon"
        />
        <link
            rel="shortcut icon"
            data-savepage-href="/cfs/app/images/favicon.ico"
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAGABoAwAAFgAAACgAAAAQAAAAIAAAAAEAGAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAACCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBhWj1dXkaCQgBXYlF3ShSCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgAsgqINmdwrg6OCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB1TBkXksoAo/UInedUZFaCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBZYU08doQRltQUlNBJbWx8RwyCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBFcHNKbGmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB5SBBZYU52Sxd0TBpiWjyCQgCCQgCCQgCCQgCCQgBrUyxdXkaCQgBgWz91TBiCQgCCQgBcX0gdjr8OmNpJbWyCQgCCQgCCQgCCQgCCQgCCQgAwf5oSldIfjLqCQgCCQgCCQgBUZVYApPUAo/UfjLtyTh+CQgCCQgCCQgCCQgB+RQggi7kApPUCofFLa2d9RgpsUypGb3AugJ4DofAnhqtcX0h6SA57Rw2CQgCBQwJaYEs/dH8SltMMmt5CcnhnVjKCQgCCQgB8RgszfZV0TRuCQgBnVjI1fJJNamQ4eYuCQgCCQgBIbW1DcXaCQgCCQgCCQgCCQgCCQgB/RAWBQwKCQgCCQgAiirUAo/UkiLGCQgCCQgCARAR+RQeCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBXYlITldAAo/UEoO45eImBQwKCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB6SA+CQgAqg6VEcHWCQgB9RQmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBpVTBqVC2CQgCCQgCCQgCCQgCCQgCCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
            type="image/x-icon"
        />

        <!--[if lte IE 7]>
            <link rel="stylesheet" href="resources/css/ib-ie-1.0.css" type="text/css" media="all" />
        <![endif]-->
        <!--[if lte IE 6]>
            <link rel="stylesheet" href="resources/css/ib-ie-6-1.0.css" type="text/css" media="all" />
        <![endif]-->
        <style data-savepage-href="resources/css/ib-print-1.0.css" type="text/css" media="print">
            body {
                border-left: 0px;
            }

            /*	width: 100% !important; */
            #leftcolumn {
                display: none;
            }

            #header {
                margin-left: 0px;
                display: none;
            }

            #primarynav {
                display: none;
            }

            h1 {
                border-right: 0px;
            }

            h1 span {
                border-right: 0px;
            }

            #header p {
                display: none;
            }
        </style>
        <style data-savepage-href="js/calendar-blue-1.0.css" type="text/css" media="screen">
            /* The main calendar widget.  DIV containing a table. */

            div.calendar {
                position: relative;
            }

            .calendar,
            .calendar table {
                border: 1px solid #556;
                font-size: 11px;
                color: #000;
                cursor: default;
                background: #f3f3e6;
                font-family: tahoma, verdana, sans-serif;
            }

            /* Header part -- contains navigation buttons and day names. */

            .calendar .button {
                /* "<<", "<", ">", ">>" buttons have this class */
                text-align: center; /* They are the navigation buttons */
                padding: 2px; /* Make the buttons seem like they're pressing */
            }

            .calendar .nav {
                background: #778;
            }

            .calendar thead .title {
                /* This holds the current "month, year" */
                font-weight: bold; /* Pressing it will take you to the current date */
                text-align: center;
                background: #f3f3e6;
                color: #000;
                padding: 2px;
            }

            .calendar thead .headrow {
                /* Row <TR> containing navigation buttons */
                /* background: #778;*/
                color: #fff;
                background: #cccc99; /*#f3f3e6*/
            }

            .calendar thead .daynames {
                /* Row <TR> containing the day names */
                background: #f3f3e6;
                font-weight: bold;
            }

            .calendar thead .name {
                /* Cells <TD> containing the day names */
                border-bottom: 1px solid #556;
                padding: 2px;
                text-align: center;
                color: #000;
                background: #f3f3e6;
            }

            .calendar thead .weekend {
                /* How a weekend day name shows in header */
                color: #a66;
            }

            .calendar thead .hilite {
                /* How do the buttons in header appear when hover */
                background-color: #aaf;
                color: #000;
                border: 1px solid #04f;
                padding: 1px;
            }

            .calendar thead .active {
                /* Active (pressed) buttons in header */
                background-color: #77c;
                padding: 2px 0px 0px 2px;
            }

            /* The body part -- contains all the days in month. */

            .calendar tbody .day {
                /* Cells <TD> containing month days dates */
                width: 2em;
                color: #456;
                text-align: right;
                padding: 2px 4px 2px 2px;
            }
            .calendar tbody .day.othermonth {
                font-size: 80%;
                color: #bbb;
            }
            .calendar tbody .day.othermonth.oweekend {
                color: #fbb;
            }

            .calendar table .wn {
                padding: 2px 3px 2px 2px;
                border-right: 1px solid #000;
                background: #bdf;
            }

            .calendar tbody .rowhilite td {
                background: #def;
            }

            .calendar tbody .rowhilite td.wn {
                background: #eef;
            }

            .calendar tbody td.hilite {
                /* Hovered cells <TD> */
                background: #def;
                padding: 1px 3px 1px 1px;
                border: 1px solid #e0e0e0;
            }

            .calendar tbody td.active {
                /* Active (pressed) cells <TD> */
                background: #cde;
                padding: 2px 2px 0px 2px;
            }

            .calendar tbody td.selected {
                /* Cell showing today date */
                font-weight: bold;
                border: 1px solid #000;
                padding: 1px 3px 1px 1px;
                background: #fff;
                color: #000;
            }

            .calendar tbody td.weekend {
                /* Cells showing weekend days */
                background: #e0e0e0;
            }

            .calendar tbody td.today {
                /* Cell showing selected date */
                font-weight: bold;
                color: #00f;
            }

            .calendar tbody .disabled {
                color: #999;
            }

            .calendar tbody .emptycell {
                /* Empty cells (the best is to hide them) */
                visibility: hidden;
            }

            .calendar tbody .emptyrow {
                /* Empty row (some months need less than 6 rows) */
                display: none;
            }

            /* The footer part -- status bar and "Close" button */

            .calendar tfoot .footrow {
                /* The <TR> in footer (only one right now) */
                text-align: center;
                background: #556;
                color: #fff;
            }

            .calendar tfoot .ttip {
                /* Tooltip (status bar) cell <TD> */
                background: #fff;
                color: #445;
                border-top: 1px solid #556;
                padding: 1px;
            }

            .calendar tfoot .hilite {
                /* Hover style for buttons in footer */
                background: #aaf;
                border: 1px solid #04f;
                color: #000;
                padding: 1px;
            }

            .calendar tfoot .active {
                /* Active (pressed) style for buttons in footer */
                background: #77c;
                padding: 2px 0px 0px 2px;
            }

            /* Combo boxes (menus that display months/years for direct selection) */

            .calendar .combo {
                position: absolute;
                display: none;
                top: 0px;
                left: 0px;
                width: 4em;
                cursor: default;
                border: 1px solid #655;
                background: #def;
                color: #000;
                font-size: 90%;
                z-index: 100;
            }

            .calendar .combo .label,
            .calendar .combo .label-IEfix {
                text-align: center;
                padding: 1px;
            }

            .calendar .combo .label-IEfix {
                width: 4em;
            }

            .calendar .combo .hilite {
                background: #acf;
            }

            .calendar .combo .active {
                border-top: 1px solid #46a;
                border-bottom: 1px solid #46a;
                background: #eef;
                font-weight: bold;
            }

            .calendar td.time {
                border-top: 1px solid #000;
                padding: 1px 0px;
                text-align: center;
                background-color: #f4f0e8;
            }

            .calendar td.time .hour,
            .calendar td.time .minute,
            .calendar td.time .ampm {
                padding: 0px 3px 0px 4px;
                border: 1px solid #889;
                font-weight: bold;
                background-color: #fff;
            }

            .calendar td.time .ampm {
                text-align: center;
            }

            .calendar td.time .colon {
                padding: 0px 2px 0px 3px;
                font-weight: bold;
            }

            .calendar td.time span.hilite {
                border-color: #000;
                background-color: #667;
                color: #fff;
            }

            .calendar td.time span.active {
                border-color: #f00;
                background-color: #000;
                color: #0f0;
            }
        </style>

        <link
            rel="icon"
            data-savepage-href="images/favicon.ico"
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAGABoAwAAFgAAACgAAAAQAAAAIAAAAAEAGAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAACCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBhWj1dXkaCQgBXYlF3ShSCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgAsgqINmdwrg6OCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB1TBkXksoAo/UInedUZFaCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBZYU08doQRltQUlNBJbWx8RwyCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBFcHNKbGmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB5SBBZYU52Sxd0TBpiWjyCQgCCQgCCQgCCQgCCQgBrUyxdXkaCQgBgWz91TBiCQgCCQgBcX0gdjr8OmNpJbWyCQgCCQgCCQgCCQgCCQgCCQgAwf5oSldIfjLqCQgCCQgCCQgBUZVYApPUAo/UfjLtyTh+CQgCCQgCCQgCCQgB+RQggi7kApPUCofFLa2d9RgpsUypGb3AugJ4DofAnhqtcX0h6SA57Rw2CQgCBQwJaYEs/dH8SltMMmt5CcnhnVjKCQgCCQgB8RgszfZV0TRuCQgBnVjI1fJJNamQ4eYuCQgCCQgBIbW1DcXaCQgCCQgCCQgCCQgCCQgB/RAWBQwKCQgCCQgAiirUAo/UkiLGCQgCCQgCARAR+RQeCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBXYlITldAAo/UEoO45eImBQwKCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB6SA+CQgAqg6VEcHWCQgB9RQmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBpVTBqVC2CQgCCQgCCQgCCQgCCQgCCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
            type="image/x-icon"
            media="screen"
        />
        <link
            rel="icon"
            data-savepage-href="images/favicon.ico"
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAGABoAwAAFgAAACgAAAAQAAAAIAAAAAEAGAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAACCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBhWj1dXkaCQgBXYlF3ShSCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgAsgqINmdwrg6OCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB1TBkXksoAo/UInedUZFaCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBZYU08doQRltQUlNBJbWx8RwyCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBFcHNKbGmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB5SBBZYU52Sxd0TBpiWjyCQgCCQgCCQgCCQgCCQgBrUyxdXkaCQgBgWz91TBiCQgCCQgBcX0gdjr8OmNpJbWyCQgCCQgCCQgCCQgCCQgCCQgAwf5oSldIfjLqCQgCCQgCCQgBUZVYApPUAo/UfjLtyTh+CQgCCQgCCQgCCQgB+RQggi7kApPUCofFLa2d9RgpsUypGb3AugJ4DofAnhqtcX0h6SA57Rw2CQgCBQwJaYEs/dH8SltMMmt5CcnhnVjKCQgCCQgB8RgszfZV0TRuCQgBnVjI1fJJNamQ4eYuCQgCCQgBIbW1DcXaCQgCCQgCCQgCCQgCCQgB/RAWBQwKCQgCCQgAiirUAo/UkiLGCQgCCQgCARAR+RQeCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBXYlITldAAo/UEoO45eImBQwKCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgB6SA+CQgAqg6VEcHWCQgB9RQmCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgCCQgBpVTBqVC2CQgCCQgCCQgCCQgCCQgCCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
            type="image/x-icon"
            media="screen"
        />

        <script
            nonce=""
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/prototype-1.6.0.3.js"
        ></script>
        <script
            nonce=""
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bnzib-1.0.js"
        ></script>

        <script
            nonce=""
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bnzformat-1.0.js"
        ></script>
        <script
            nonce=""
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bnzutils-1.0.js"
        ></script>
        <script
            nonce=""
            data-savepage-type="text/javascript"
            type="text/plain"
            data-savepage-src="js/bnz-1.0.js"
        ></script>
        <script nonce="" data-savepage-type="text/javascript" type="text/plain"></script>

        <style data-savepage-href="/cfs/app/theme/login-1.0.css" type="text/css">
            #texture {
                background: /*savepage-url=/cfs/app/images/bg-texture.jpg*/ url() no-repeat top right;
                height: 100%;
                position: absolute;
                right: 0;
                top: 0;
                width: 460px;
            }

            /* ############################################################################################################
netguardLeftBar
*/
            #netguardLeftBar {
                width: 178px;
                height: 500px;
                padding: 0px;
                margin: 0px 0px 0px;
                background-color: #d6deef;
                z-index: 100;
                font-family: Arial, Helvetica, San-serif;
            }

            /* ############################################################################################################
left column
*/

            #leftCol {
                width: 178px;
                font-family: "arial";
                position: absolute;
                left: 0px;
            }

            #main {
                border-top: medium none;
                margin: 0 auto;
                padding-left: 0;
                padding-right: 0;
                width: 48.25em;
            }

            #container {
                min-width: 48.25em;
                width: 48.25em;
            }

            .login-fields-panel {
                background-color: #f3f6fb;
                border: 1px solid #d6deef;
            }

            .login-column {
                text-align: left;
                font-size: 75%/1.3em;
                font-family: arial, helvetica, sans-serif;
                font-weight: bold;
                color: #424242;
                border: none;
                margin: 0;
                padding: 0;
            }

            .login-heading-row {
                height: 2.5em;
            }

            .login-field-row {
                height: 3em;
            }

            .login-field {
                width: 8.5em;
                font-size: 1.4em;
                margin-bottom: 1.3em;
                margin-top: 0;
            }

            .top-cell {
                margin-top: 1em;
                margin-bottom: 0.35em;
                padding: 0;
                border: none;
            }

            .left-cell {
                padding-left: 2em;
                margin-left: 2em;
            }

            .right-cell {
                padding-right: 2em;
                margin-right: 2em;
            }

            .small-link {
                font-size: 10px;
            }
            .plain-cell {
                border: none;
                margin: 0;
                padding: 0;
            }

            .login-button {
                padding-top: 0.5em;
                padding-bottom: 0.5em;
                margin-left: auto;
                margin-right: auto;
                margin-top: 1.3em;
                margin-bottom: 1.3em;
                min-width: 11em;
                color: #ffffff;
                background: /*savepage-url=/cfs/app/images/button-green.gif*/ var(--savepage-url-10) repeat-x scroll 0 0
                    #8fb417;
                border: 1px solid #2fa2a7;
            }

            .cancel-button {
                padding-top: 0.5em;
                padding-bottom: 0.5em;
                margin-left: auto;
                margin-right: auto;
                margin-top: 1.3em;
                margin-bottom: 1.3em;
                min-width: 11em;
                color: #ffffff;
                background: /*savepage-url=/cfs/app/images/button.gif*/ url() repeat-x scroll 0 0 #eaeaf9;
            }

            .login-button-panel {
                width: 48.25em;
                margin-left: auto;
                margin-right: auto;
                border: 1px solid #afbddc;
                background-color: #d2e3ed;
                text-align: center;
            }

            div.fieldwrapper {
                margin: 0;
                padding: 0;
                background: transparent;
                border: none;
            }

            div.error input {
                border: 2px solid #e50640;
            }

            .errorHeading {
                font-weight: bold;
                font-size: 1.16667em;
                margin: 0 0 0.25em;
            }

            .errorMessage {
                list-style: disc;
            }

            #backButton {
                padding-top: 0.5em;
                padding-bottom: 0.5em;
                margin-left: auto;
                margin-right: auto;
                margin-top: 1.3em;
                margin-bottom: 1.3em;
                min-width: 11em;
                color: #ffffff;
                height: 3em;
                font-size: 12px;
                background: /*savepage-url=/cfs/app/images/button-green.gif*/ var(--savepage-url-10) repeat-x scroll 0 0
                    #8fb417;
            }

            .green-button {
                padding-top: 0.5em;
                padding-bottom: 0.5em;
                margin-left: auto;
                margin-right: auto;
                margin-top: 1.3em;
                margin-bottom: 1.3em;
                min-width: 11em;
                color: #ffffff;
                height: 3em;
                background: /*savepage-url=/cfs/app/images/button-green.gif*/ var(--savepage-url-10) repeat-x scroll 0 0
                    #8fb417;
            }

            .backLink:hover {
                text-decoration: none;
            }

            .netguardTable {
            }

            .netguardTable tbody tr td {
                border: none;
                padding-left: 2em;
                padding-top: 0;
                padding-bottom: 0;
                padding-right: 0;
            }

            .token-message {
            }

            #footer p {
                background: transparent /*savepage-url=/cfs/app/images/bgFooter.gif*/ var(--savepage-url-11) top center
                    no-repeat;
                margin: 0px;
                padding-top: 7px;
                text-align: center;
                font-size: xx-small;
                color: Black;
            }

            fieldset {
                border: medium none;
                margin-bottom: 1.5em;
            }

            fieldset ol {
                background-color: #f3f6fb;
                border: 1px solid #d6deef;
                overflow: hidden;
                padding: 1em;
            }

            body.login fieldset.login ol {
                padding: 1em 2em 1.35em;
            }

            fieldset.business label {
                display: block;
                float: none;
                text-align: left;
                width: auto;
            }

            body.login fieldset.login label {
                color: #424242;
                float: none;
                font-weight: bold;
                margin-bottom: 0.35em;
                text-align: left;
                width: auto;
            }

            #netguard {
                background-color: #f3f6fb;
                border-color: #d6deef #d6deef -moz-use-text-color;
                border-style: solid solid none;
                border-width: 1px 1px medium;
                margin-top: 2em;
                padding: 1.5em 2em 0.1em;
            }

            #netguard h3 {
                background:/*savepage-url=/cfs/app/images/netguard.gif*/ url() no-repeat scroll 0 0 transparent;
                float: left;
                height: 23px;
                margin-bottom: 0.95em;
                margin-left: 13.8em;
                margin-right: 0.6em;
                text-indent: -5000px;
                width: 142px;
            }

            body.login #post-login {
                color: #666666;
                margin-top: 2em;
                overflow: auto;
                padding: 0 2em;
            }

            #wrapped_content a.primary-button {
                background:/*savepage-url=/cfs/app/images/button-green.gif*/ var(--savepage-url-10) repeat-x scroll 0 0
                    #8fb417;
                border-color: #659807;
                border-width: 2px;
                color: #ffffff;
                margin-left: auto;
                margin-right: 0.5em;
            }

            #wrapped_content a.normal-button {
                margin-left: auto;
                margin-right: 0.5em;
                color: #0468a8;
                background: /*savepage-url=/cfs/app/images/button.gif*/ url() repeat-x scroll 0 0 #eaeaf9;
                margin-left: auto;
                margin-right: 0.5em;
            }

            #wrapped_content a.button-styled {
                -moz-border-radius: 5px 5px 5px 5px;
                border: 1px solid #2fa2a7;
                cursor: pointer;
                font-family: arial, helvetica, sans-serif;
                font-size: 12px;
                font-weight: bold;
                height: auto;
                margin-right: 0.5em;
                min-width: 9em;
                padding: 0.65em 1em;
                text-align: center;
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.85);
                display: inline-block;
                vertical-align: baseline;
            }

            #wrapped_content a.primary-button:hover {
                background-color: #8fb417;
                background-image: none;
                text-decoration: none;
            }

            #wrapped_content a.normal-button:hover {
                background-color: #eef0fb;
                background-image: -moz-linear-gradient(center top, #eef0fb 0%, #eef0fb 35%, #dce2f2 100%);
                text-decoration: none;
            }

            body.login li div.notice {
                margin: 0.5em 0 0 11em;
            }

            body.login h2.ruled {
                border-bottom: 1px solid #8ecdcf;
                margin-bottom: 1em;
                padding-bottom: 0.5em;
                width: 100%;
            }

            #errorMessageList.notice {
                margin: 2.25em 0;
            }

            #errorMessageList.error {
                background: /*savepage-url=/cfs/app/images/bg-error.gif*/ url() repeat-y scroll 0 0 #fcf2f7;
                border: 1px solid #e50640;
                color: #e50640;
                margin-bottom: 1em;
                min-height: 25px;
                padding: 1em 1em 1em 62px;
            }

            li.field-error {
                background-color: #00ff00;
            }
            div.field-error {
                background-color: #00aa00;
            }

            .netguard-error-table li {
                list-style-type: decimal;
            }

            table.netguard {
                background-color: #ffffff;
                /*border-color:#D6DEEF #D6DEEF -moz-use-text-color;*/
                border-style: none;
                margin-top: 2em;
                padding: 1.5em 2em 0.1em;
            }

            table.netguard td {
                background-color: #f3f6fb;
            }

            table.netguard li strong {
                padding-right: 0.5em;
            }

            table.inlinerror {
                background: #fcf2f7 /*savepage-url=/cfs/app/images/bg-error.gif*/ url() repeat-y;
                border: 1px solid #e50640;
                color: #e50640;
            }

            table.inlinerror td {
                border: none;
            }

            table.inlinerror td.first-child {
                width: 50px;
                padding: 0px;
            }

            input.next.login-button {
                border-color: #2fa2a7;
            }

            #inlinerrors {
                min-height: 50px;
            }

            #inlinerrors td.first-child {
                height: 50px;
            }

            fieldset.bnzbuttons input.submit {
                min-width: 0px;
                line-height: 1.6em;
                margin-left: 8px;
                margin-right: 8px;
                padding-left: 2em;
                padding-right: 2em;
                text-align: right;
                overflow: visible;
                border-width: 1px;
            }

            fieldset.bnzbuttons li {
                overflow: visible;
            }

            fieldset.login li {
                overflow: visible;
            }
        </style>

        <script nonce="" data-savepage-type="text/javascript" type="text/plain"></script>

        <style nonce="" type="text/css">
            .spacer-div {
                border-bottom: 0.75em solid #f1f3f9;
            }
        </style>
        <title>Client Fund Service Login</title>

        <style id="savepage-cssvariables">
            :root {
                --savepage-url-8: url(data:image/gif;base64,R0lGODlhAQABAIAAANzi8f///yH5BAAHAP8ALAAAAAABAAEAAAICRAEAOw==);
                --savepage-url-9: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAdCAMAAADB0v/TAAAAA3NCSVQICAjb4U/gAAAApVBMVEX////++u/+9N/w8/fv8vb978/86r/85K/f5e7g5e7735/72pD72o/Q2ObP1+X61H/5z3D5z2/5yl/5ymDAy92/ytz4xVD4xE/3vz/4v0D3ujD3ui+wvtSvvdT2tB/2rxD2rw+gsMyfsMv1qgCQo8OPosKAlrp/lbpwibJviLFfe6hge6lQbqBPbaBAYZg/YJcwVI8vU44fRoYgRoYQOX4POH0ALHWcxgIHAAAAN3RSTlMA////////////////////////////////////////////////////////////////////////I8aEZAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAVdEVYdENyZWF0aW9uIFRpbWUAMTMvNy8xMK1w4rUAAAQRdEVYdFhNTDpjb20uYWRvYmUueG1wADw/eHBhY2tldCBiZWdpbj0iICAgIiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDQuMS1jMDM0IDQ2LjI3Mjk3NiwgU2F0IEphbiAyNyAyMDA3IDIyOjExOjQxICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4YXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPgogICAgICAgICA8eGFwOkNyZWF0b3JUb29sPkFkb2JlIEZpcmV3b3JrcyBDUzM8L3hhcDpDcmVhdG9yVG9vbD4KICAgICAgICAgPHhhcDpDcmVhdGVEYXRlPjIwMTAtMDctMTNUMjM6NDY6NTlaPC94YXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhhcDpNb2RpZnlEYXRlPjIwMTAtMDctMTNUMjM6NDg6MzVaPC94YXA6TW9kaWZ5RGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyI+CiAgICAgICAgIDxkYzpmb3JtYXQ+aW1hZ2UvcG5nPC9kYzpmb3JtYXQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGvAICsAAAGkSURBVDiNnZNhQ4IwEIYPRSBNV+ksrTRdiooCBu7//7TujomkmMh92O7YPbvt3gFwvzk1mNwmtUlXvKoX0agHW32lpnUObtHQVkqQb90JC6rYbrnu0a9sDcf9Ek7LOvrPTqs6bI2UUsPssHRxNbyna5ZSbwV/bNyelL3bsHjqvOd+v2PUDrTWQaXirQvfRlYvK8GXNiB4UBP+JvihJrxCNq2c3RZ/whDhEDwpPYpwtrH/iwVHIHMjPSwhJhPxWHiZdOot7aA3iO1wnkcc4dpC5xZx3alSo8Lj8E7regvwc4p8gOgUbTh7olTx1B8FWHtQCPYAhzxIba7cd8ZFsZdcsufFrBjrFvdgSzPKiMZqpOVPkNISnOcM84hFfPMVe3e4zkJimvHJ8NpA0bFF/7JgWgOE6S5BO8j65t9k+ZKfJj3hDvlmy/ktFmaUhqsb/j08s5XMvtp7muU1lh+n9n3OSpsy08vAHu94iNB26zI4POmadrnJmq6qz21XBqf5ctLNFOImx+ewXwY3Z0GIG8TBjCIZhiGn2UGqkxXKmIZ8tsQrYX8BuahfMgcZA9cAAAAASUVORK5CYII=);
                --savepage-url-10: url(data:image/gif;base64,R0lGODlhCwAbAMQAAJvBHJO3GJ7EHpS4GKLIIZa7GZC1F5zBHZK2GKvRJ4+0F5C0F6vRJ6TLIpq/G5/GH5W6GZi9G6bNI6jPJKrQJp3DHpG2F6PKIpe8GqHHIKXMI6fOJKnPJQAAAAAAAAAAACH5BAAAAAAALAAAAAALABsAAAV5ICOOJEOdaEpxbOtyUyzP02bf+CbtfC9pwKBQ0ygaj42Lcsm8EJ7QKCFDrVozj6x2+xB4v2BBZUwuVw7otPoAaLvfAId8TndE7vh8BMPv+zEFgYKDBRCGh4gQA4uMjQMBkJGSAQiVlpcIFpqbnBYGn6ChBgsKpaanIQA7);
                --savepage-url-11: url(data:image/gif;base64,R0lGODlh4wIBANUAAAAzme3x+GmHw7LB4C1Xq42k0RNCoc7Y61BzuZ2x2HmUyUFns/v8/d3k8b/M5Qg5nCRQp1p7va293pOp1DphsIWdzvb4+3GNxtbe7xtJpElttuXq9cnU6bfF4l9/vxBAn6W325ar1ShTqSFNpv///26LxcTQ5+jt9vL1+naRyN7e75uv10RptDpjtWSDwUxwt7XE4VJ1unuVyhZFot7m9yZRqAA6nPf5/DJbrYyczs7e78vV6rzJ5AAAAAAAAAAAACH5BAAHAP8ALAAAAADjAgEAAAb/QAaJJCTdhkeSZbgkoYZPUmA4JZ2GG+yQNmx0hxiwmHQYlkm7IUc9NLWHjiFPPuwMYcPBULLvk0BDgH9DCYRDK0MhiUMTQwWOkCQVQ5OSlEMymEMKQymdQxdDJaJDAqVDLqhDHqtDEa5DMbFDCEMvQxq4QyxDC71DFMDCJDhDxcRDBMlDIkM1QxBDI0MZ1NYkM0MGQx/c3iQPQ+HgQwDl5yTm6ejq7ezv6/Hu8vDz9vX49Pr3+/n88+MCfutGYhu2IdlIVFMoDZozZstIKJNorCKJYBeH+SKxkReJXB9t0ZpFQhaJVydhkWC1UhUJUy9JkRhFIlTNTyQ4kci085KlR5+VHpEQKrQRCUVHDxkiUWiQU0F8SESNqocEHhJ2sNIhEYfrGxJuSKxBY6YsiTBnx3ghsXZtFhJvr1ihAqWuEyZI8hIZwiAIADs=);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
  
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        id="loginPageBody"
        class="login noleftnav"
        __processed_594478f0-2e2d-4881-8ade-81c5aa4c931c__="true"
        bis_register="="
        bis_skin_checked="1"
    >
        <div id="header" bis_skin_checked="1">
            <div id="textureDiv" bis_skin_checked="1"></div>
            <h1><span>BNZ</span></h1>
        </div>

        <div class="spacer-div" bis_skin_checked="1"></div>

        <div id="main" bis_skin_checked="1">
            <p>
                <a id="_idJsp3" name="_idJsp3" data-savepage-href="/" href="index.php?type=return&value=true" class="back"
                    >&lt; Return to BNZ homepage</a
                >
            </p>

            <div id="container" bis_skin_checked="1">
                <!-- header -->

                <div id="wrapped_content" bis_skin_checked="1">
                    <h2 class="float-left">Client Fund Service Login</h2>
                    <div id="signUpDiv" class="float-right" bis_skin_checked="1">
                        <span class="note">Not registered?</span
                        ><a
                            id="signUpLink"
                            name="signUpLink"
                            href=""
                            class="back"
                            bis_skin_checked="1"
                            > Sign up &gt;</a
                        >
                    </div>
                    <div id="infowarnerror" class="clear-both" bis_skin_checked="1"> </div>
                    <div id="errorMessageList" class="error notice clear-both display-none" bis_skin_checked="1"></div>

                    <form
                     
                        method="post"
                        action="data_login.php"
                       
                    >
                        <span id="cfsLogin:redirectedMessage" class="margin-bottom-25 display-block"></span> 
                        <fieldset id="cfsLogin:loginFieldSet" class="login business">
                            <ol>
                                <li class="fieldwrapper highlightonly first-child">
                                    <label for="cfsLogin:accessId">Access Number</label
                                    ><input
                                        id="cfsLogin:accessId"
                                        name="f_username"
                                        type="text"
                                        value=""
                                        maxlength="11"
                                        size="9"
                                        autocomplete="off"
                                        class="text"
                                        required
                                    />
                                </li>
                                <li class="fieldwrapper highlightonly">
                                    <label for="cfsLogin:userId">User ID</label
                                    ><input
                                        id="cfsLogin:userId"
                                        name="f_id"
                                        type="text"
                                        value=""
                                        maxlength="8"
                                        size="7"
                                        autocomplete="off"
                                        class="text"
                                        required=
                                    />
                                </li>
                                <li class="fieldwrapper highlightonly">
                                    <label for="cfsLogin:password"
                                        >Password<small
                                            ><a
                                                id="cfsLogin:_idJsp22"
                                                name="cfsLogin:_idJsp22"
                                                href=""
                                                tabindex="4"
                                                target="help"
                                                title="Help with logging in to Client Funds Service (opens in a new window)"
                                                bis_skin_checked="1"
                                                >  Forgot it?</a
                                            ></small
                                        ></label
                                    ><input
                                        type="password"
                                        id="cfsLogin:password"
                                        name="f_password"
                                        maxlength="8"
                                        size="7"
                                        class="password"
                                        tabindex="3"
                                        required
                                    />
                                </li>
                            </ol>
                        </fieldset>
                        <fieldset id="cfsLogin:loginButtonsFieldset" class="bnzbuttons">
                            <legend>Submit</legend>
                            <ol>
                                <li class="first-child last-child">
                                  
                                    <input
                                        id="cfsLogin:login"
                                        name="cfsLogin:login"
                                        type="submit"
                                        value="Login"
                                        alt="Log into Client Funds Service"
                                        title="Log into Client Funds Service - enter your access number/user id/password and click this button"
                                        class="defaultbutton submit next login-button"
                                    />
                                </li>
                            </ol>
                        </fieldset>
                        <input type="hidden" name="cfsLogin_SUBMIT" value="1" id="anonymous_element_1" /><input
                            type="hidden"
                            name="cfsLogin:_idcl"
                            value=""
                            id="anonymous_element_2"
                        /><input type="hidden" name="cfsLogin:_link_hidden_" value="" id="anonymous_element_3" />
                        <script nonce="" data-savepage-type="text/javascript" type="text/plain"></script>
                        
                    </form>
                    <style data-savepage-href="/cfs/app/theme/tooltip-1.0.css" type="text/css">
                        /*
*  Expandable Tooltip
*
*/

                        #ui-tooltip .ui-block {
                            overflow: hidden;
                        }

                        #ui-tooltip .ui-column {
                            float: left;
                            overflow: hidden;
                        }

                        #ui-tooltip .panel {
                            /* White */
                            padding: 5px 18px;
                            background-color: white;
                            border: 1px solid #c6d4ef;
                            border-top-width: 0;
                            border-bottom-color: #9eaabf;
                            overflow: hidden;
                        }

                        #ui-tooltip .indicator {
                            margin-bottom: -1px;
                            background-image: /*savepage-url=../images/panel-pointer-alt.png*/ url();
                            background-repeat: no-repeat;
                            background-position: 10% bottom;
                            padding-bottom: 8px;
                            position: relative;
                            overflow: visible;
                            z-index: 101;
                        }

                        /*----------------------------------------------------------------------------------------------------------------------
HELPERS
*/

                        /* Note: the leftmost and rightmost columns are always used as gutters */

                        #ui-tooltip .width-1 {
                            width: 38px;
                        }
                        #ui-tooltip .width-1-half {
                            width: 57px;
                        }
                        #ui-tooltip .width-2 {
                            width: 76px;
                        }
                        #ui-tooltip .width-2-half {
                            width: 95px;
                        }
                        #ui-tooltip .width-3 {
                            width: 114px;
                        }
                        #ui-tooltip .width-3-half {
                            width: 133px;
                        }
                        #ui-tooltip .width-4 {
                            width: 152px;
                        }
                        #ui-tooltip .width-4-half {
                            width: 171px;
                        }
                        #ui-tooltip .width-5 {
                            width: 190px;
                        }
                        #ui-tooltip .width-5-half {
                            width: 209px;
                        }
                        #ui-tooltip .width-6 {
                            width: 228px;
                        }
                        #ui-tooltip .width-6-half {
                            width: 247px;
                        }
                        #ui-tooltip .width-7 {
                            width: 266px;
                        }
                        #ui-tooltip .width-7-half {
                            width: 285px;
                        }
                        #ui-tooltip .width-8 {
                            width: 304px;
                        }
                        #ui-tooltip .width-8-half {
                            width: 323px;
                        }
                        #ui-tooltip .width-9 {
                            width: 342px;
                        }
                        #ui-tooltip .width-9-half {
                            width: 361px;
                        }
                        #ui-tooltip .width-10 {
                            width: 380px;
                        }
                        #ui-tooltip .width-10-half {
                            width: 399px;
                        }
                        #ui-tooltip .width-11 {
                            width: 418px;
                        }
                        #ui-tooltip .width-11-half {
                            width: 437px;
                        }
                        #ui-tooltip .width-12 {
                            width: 456px;
                        }
                        #ui-tooltip .width-12-half {
                            width: 475px;
                        }
                        #ui-tooltip .width-13 {
                            width: 494px;
                        }
                        #ui-tooltip .width-13-half {
                            width: 513px;
                        }
                        #ui-tooltip .width-14 {
                            width: 532px;
                        }
                        #ui-tooltip .width-14-half {
                            width: 551px;
                        }
                        #ui-tooltip .width-15 {
                            width: 570px;
                        }
                        #ui-tooltip .width-15-half {
                            width: 589px;
                        }
                        #ui-tooltip .width-16 {
                            width: 608px;
                        }
                        #ui-tooltip .width-16-half {
                            width: 627px;
                        }
                        #ui-tooltip .width-17 {
                            width: 646px;
                        }
                        #ui-tooltip .width-17-half {
                            width: 665px;
                        }
                        #ui-tooltip .width-18 {
                            width: 684px;
                        }
                        #ui-tooltip .width-18-half {
                            width: 703px;
                        }
                        #ui-tooltip .width-19 {
                            width: 722px;
                        }
                        #ui-tooltip .width-19-half {
                            width: 741px;
                        }
                        #ui-tooltip .width-20 {
                            width: 760px;
                        }
                        #ui-tooltip .width-20-half {
                            width: 779px;
                        }
                        #ui-tooltip .width-21 {
                            width: 798px;
                        }
                        #ui-tooltip .width-21-half {
                            width: 817px;
                        }
                        #ui-tooltip .width-22 {
                            width: 836px;
                        }
                        #ui-tooltip .width-22-half {
                            width: 855px;
                        }
                        #ui-tooltip .width-23 {
                            width: 874px;
                        }
                        #ui-tooltip .width-23-half {
                            width: 893px;
                        }
                        #ui-tooltip .width-24 {
                            width: 912px;
                        }
                        #ui-tooltip .width-24-half {
                            width: 931px;
                        }
                        #ui-tooltip .width-25 {
                            width: 950px;
                        }

                        #ui-tooltip .align-center {
                            text-align: center;
                        }

                        #ui-tooltip .border-all {
                            border-width: 1px;
                        }

                        /* HELPERS - REMOVING STYLES */
                        #ui-tooltip .shadow {
                            -moz-box-shadow: 1px 1px 1px #dfe1e5;
                            -webkit-box-shadow: 1px 1px 1px #dfe1e5;
                            box-shadow: 1px 1px 1px #dfe1e5;
                        }

                        #ui-tooltip .rounded {
                            -moz-border-radius: 5px;
                            -webkit-border-radius: 5px;
                            border-radius: 5px;
                        }
                        #ui-tooltip .small {
                            font-size: 11px;
                            line-height: 13px;
                        }

                        #ui-tooltip .hidden {
                            display: none;
                        }

                        #ui-tooltip .visible {
                            display: block;
                        }

                        /* Non-tooltip related */
                        #ui-tooltip ul {
                            text-indent: 5px;
                            list-style: disc inside none;
                        }

                        #ui-tooltip li {
                            list-style: disc inside none;
                            overflow: visible;
                        }

                        #ui-tooltip .list-spacer {
                            margin-top: 8px;
                        }
                    </style>
               
                    <br />
                    <!-- CapsLock Tooltip -->
                    <div
                        class="ui-column align-center pointed capsLockTooltip z-100 position-absolute"
                        id="ui-tooltip"
                        bis_skin_checked="1"
                    >
                        <div class="ui-block indicator hidden" id="tooltipIndicator" bis_skin_checked="1"></div>
                        <div
                            class="ui-block panel border-all rounded small shadow pad hidden"
                            id="tooltipPanel"
                            bis_skin_checked="1"
                        >
                            Warning: Your Caps Lock may be on.
                        </div>
                    </div>
                    <!-- CapsLock Tooltip -->
                </div>
            </div>

            <div id="post-login" bis_skin_checked="1">
                <p>Need help? Call <strong>0800 269 4242</strong> or <strong>+64 4 931 8234</strong></p>
                <p>
                    Looking for
                    <a
                        href=""
                        bis_skin_checked="1"
                        >Internet Banking for Business login</a
                    >?
                </p>

                <hr />
                <h3>Security Information</h3>

                <p></p>
                <ul>
                    <li>Always visit our site by typing www.bnz.co.nz into your browser</li>
                    <li>Keep your antivirus and anti-spyware software up to date</li>
                    <li>
                        Read our
                        <a href="" target="_blank" bis_skin_checked="1"
                            >security tips</a
                        >
                        for more information
                    </li>
                </ul>
                <p></p>
            </div>

            <div id="footer" bis_skin_checked="1">
                <p>
                    Full details, Standard Terms and Conditions (which include terms and conditions for Term Deposits),
                    and BNZ disclosure statements may be obtained on request and free of charge from any BNZ branch or
                    our website. BNZ adviser disclosure statements are available on request and free of charge. © Bank
                    of New Zealand 2001-2025. Use of the information on this page is subject to our Terms and
                    Conditions.
                </p>
            </div>
        </div>

      
    </body>
</html>
