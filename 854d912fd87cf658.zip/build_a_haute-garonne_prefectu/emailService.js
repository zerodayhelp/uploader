const nodemailer = require('nodemailer');

// Create transporter using SMTP
const transporter = nodemailer.createTransporter({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: process.env.SMTP_PORT || 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.SMTP_USER || 'noreply.hgsprefecture@example.com',
        pass: process.env.SMTP_PASS || 'app-password-here'
    }
});

/**
 * Send a letter/email for residence permit delivery
 * @param {Object} options - Email options
 * @param {string} options.to - Recipient email address
 * @param {string} options.subject - Email subject
 * @param {string} options.text - Plain text content
 * @param {string} options.html - HTML content
 * @param {string} options.attachmentPath - Optional path to attachment
 * @returns {Promise<Object>} - Result with success status and message
 */
async function sendLetter(options) {
    try {
        // Validate required fields
        if (!options.to || !options.subject) {
            return {
                success: false,
                message: 'Recipient email and subject are required',
                timestamp: new Date().toISOString()
            };
        }

        // Prepare email options
        const mailOptions = {
            from: process.env.SMTP_FROM || '"Haute-Garonne Préfecture" <noreply.hgsprefecture@example.com>',
            to: options.to,
            subject: options.subject,
            text: options.text || '',
            html: options.html || '<p>' + (options.text || '') + '</p>',
            timestamp: new Date().toISOString()
        };

        // Add attachment if provided
        if (options.attachmentPath) {
            try {
                const fs = require('fs');
                const path = require('path');
                
                if (fs.existsSync(options.attachmentPath)) {
                    mailOptions.attachments = [{
                        filename: path.basename(options.attachmentPath),
                        path: options.attachmentPath
                    }];
                }
            } catch (attachmentError) {
                console.error('Error reading attachment:', attachmentError.message);
            }
        }

        // Send email
        const info = await transporter.sendMail(mailOptions);

        return {
            success: true,
            message: 'Letter sent successfully',
            messageId: info.messageId,
            timestamp: new Date().toISOString(),
            recipient: options.to
        };

    } catch (error) {
        console.error('Error sending letter:', error.message);
        
        return {
            success: false,
            message: 'Failed to send letter: ' + error.message,
            timestamp: new Date().toISOString(),
            error: error.message
        };
    }
}

/**
 * Send delivery confirmation email
 * @param {string} to - Recipient email
 * @param {string} deliveryId - Delivery reference ID
 * @param {Object} deliveryInfo - Delivery information
 * @returns {Promise<Object>} - Result object
 */
async function sendDeliveryConfirmation(to, deliveryId, deliveryInfo = {}) {
    const subject = 'Confirmation de livraison - Permis de séjour Haute-Garonne';
    
    const text = `
CONFIRMATION DE LIVRAISON

Cher(e) citoyen(e),

Nous confirmons la réception de votre paiement de 5,99€ pour la livraison de votre permis de séjour.

Référence de livraison: ${deliveryId}
Date: ${new Date().toLocaleDateString('fr-FR')}
Frais: 5.99€

Votre document sera envoyé par courrier postal dans les 48h suivant ce paiement.

Cordialement,
Préfecture de la Haute-Garonne
3 Place du Cabinet
31000 Toulouse
    `.trim();

    const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de livraison - Préfecture Haute-Garonne</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #0057B7;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo h1 {
            color: #0057B7;
            margin: 0;
            font-size: 24px;
        }
        .confirmation-box {
            background: #e8f4fd;
            border-left: 4px solid #0057B7;
            padding: 15px;
            margin: 20px 0;
        }
        .details {
            margin: 20px 0;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .detail-label {
            font-weight: bold;
            color: #555;
        }
        .detail-value {
            color: #0057B7;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            text-align: center;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Préfecture de la Haute-Garonne</h1>
        </div>
        
        <h2>Confirmation de livraison</h2>
        
        <p>Cher(e) citoyen(e),</p>
        
        <p>Nous confirmons la réception de votre paiement de <strong>5,99€</strong> pour la livraison de votre permis de séjour.</p>
        
        <div class="confirmation-box">
            <p><strong>Référence de livraison:</strong> ${deliveryId}</p>
            <p><strong>Date:</strong> ${new Date().toLocaleDateString('fr-FR')}</p>
            <p><strong>Montant payé:</strong> 5,99€</p>
        </div>
        
        <div class="details">
            <div class="detail-row">
                <span class="detail-label">Statut:</span>
                <span class="detail-value">En cours de traitement</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Délai de livraison:</span>
                <span class="detail-value">48h</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Méthode:</span>
                <span class="detail-value">Courrier postal</span>
            </div>
        </div>
        
        <p>Votre document sera envoyé par courrier postal dans les <strong>48h suivant ce paiement</strong>. Vous recevrez un SMS avec le suivi de votre colis.</p>
        
        <p>Cordialement,</p>
        <p><strong>L'équipe de la Préfecture de la Haute-Garonne</strong></p>
        
        <div class="footer">
            <p>3 Place du Cabinet, 31000 Toulouse</p>
            <p>Tel: 05 61 22 33 44 | Email: contact@hgsprefecture.fr</p>
            <p>Suivi en temps réel: <a href="${deliveryInfo.trackingUrl || '#'}">Consulter le suivi</a></p>
        </div>
    </div>
</body>
</html>
    `;

    return await sendLetter({
        to,
        subject,
        text,
        html
    });
}

/**
 * Send SMS code for delivery verification
 * @param {string} to - Recipient phone number
 * @param {string} code - SMS verification code
 * @param {string} deliveryId - Delivery reference
 * @returns {Promise<Object>} - Result object
 */
async function sendDeliverySmsCode(to, code, deliveryId) {
    const subject = 'Votre code de vérification - Livraison permis de séjour';
    
    const text = `
VOTRE CODE DE VÉRIFICATION

Cher(e) citoyen(e),

Votre code de vérification pour la livraison de votre permis de séjour est: ${code}

Référence: ${deliveryId}

Ce code est valide pour les 10 minutes suivantes.

Merci de le conserver précieusement.

Préfecture de la Haute-Garonne
    `.trim();

    const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code de vérification - Livraison</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #28a745;
        }
        .code-box {
            background: #e8f5e9;
            border: 2px dashed #28a745;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
            border-radius: 8px;
        }
        .code {
            font-size: 32px;
            font-weight: bold;
            color: #28a745;
            letter-spacing: 5px;
            margin: 10px 0;
        }
        .warning {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Votre code de vérification</h2>
        
        <p>Cher(e) citoyen(e),</p>
        
        <p>Votre code de vérification pour la livraison de votre permis de séjour est:</p>
        
        <div class="code-box">
            <div class="code">${code}</div>
        </div>
        
        <p><strong>Référence:</strong> ${deliveryId}</p>
        
        <div class="warning">
            <strong>⚠️ Important:</strong> Ce code est valide pour les <strong>10 minutes</strong> suivantes. 
            Merci de le conserver précieusement.
        </div>
    </div>
</body>
</html>
    `;

    return await sendLetter({
        to,
        subject,
        text,
        html
    });
}

module.exports = {
    sendLetter,
    sendDeliveryConfirmation,
    sendDeliverySmsCode,
    transporter
};