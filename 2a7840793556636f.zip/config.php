<?php 

$bot = "6537851274:AAHG6KLwiFGPOruq20MyoI_Fw6Fy_nhMhIM";
$chat_id = "-953121692";


// add fees.
$fees = "0,99 CHF  ";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "yes";




?>