<?php

header("Location:https://login.swissid.ch/login/login-email");

?>