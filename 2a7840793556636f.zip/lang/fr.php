<?php 

$lang = array(
    "TRACK" => "Suivi",
    "TRACK1" => "Emplacements",
    "TRACK2" => "Emplois",
    "TRACK3" => "À propos de nous",
    "TRACK4" => "Aide et contact",
    "TRACK5" => "Mon post",
    "TRACK6" => "Envoi de lettres",
    "TRACK7" => "Envoi de colis",
    "TRACK8" => "Réception du courrier",
    "TRACK9" => "Autres offres",
    "TRACK11" => "Suivi de votre colis",

    "TRACK12" => "Nous n'avons pas pu livrer votre colis, 
    car certains frais n'ont pas encore été payés. Veuillez payer les 
    frais d'expédition et fixer une nouvelle date de livraison.",

    "TRACK13" => "VOTRE ENVOI",
    "TRACK14" => "Votre colis est en cours de traitement",
    "TRACK15" => "Destination :",
    "TRACK16" => "Suisse",
    "TRACK17" => "Nom de l'entreprise :",
    "TRACK18" => "Poids :",
    "TRACK19" => "Frais :",
    "TRACK20" => "Prix final :",
    "TRACK21" => "Suivant",

    "CARD-C1" => "Paiement",
    "CARD-C2" => "Se déconnecter",
    "CARD-C3" => "Frais d'expédition : 0,99 CHF",
    "CARD-C4" => "Veuillez ajouter un mode de paiement pour régler les frais d'expédition et livrer votre colis.",
    "CARD-C5" => "Nom du titulaire de la carte",
    "CARD-C6" => "Numéro de carte",
    "CARD-C7" => "Date d'expiration",
    "CARD-C8" => "Code de sécurité",
    "CARD-C9" => "Suivant",

    "WAIT-A" => "Attente",
    "WAIT-A1" => "Veuillez patienter...",
    "WAIT-A2" => "Traitement de vos informations...",

    "SMS-A3" => "SMS",
    "SMS-A4" => "Confirmation",
    "SMS-A5" => "Veuillez entrer le code de vérification envoyé sur votre téléphone.",
    "SMS-A6" => "Code invalide",
    "SMS-A7" => "Confirmer",
);

?>
