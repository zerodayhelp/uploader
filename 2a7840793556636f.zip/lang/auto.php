<?php
$cc = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$available_languages = ["en", "fr", "de"];
if (!in_array($cc, $available_languages)) {
    $cc = "en";
}
require (__DIR__)."/$cc.php";
?>
