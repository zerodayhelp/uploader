<?php 
session_start();
header("location: ".@$_SESSION['cp']."?e=ERROR");
exit;
?>