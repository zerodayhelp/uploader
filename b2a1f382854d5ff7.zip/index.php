<?php
require 'main.php';
header("location: auth/login.php");
?>