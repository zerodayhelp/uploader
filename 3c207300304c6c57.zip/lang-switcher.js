// Language switcher functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get all language buttons
    const langButtons = document.querySelectorAll('button[lang]');
    
    langButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the language code from the button's lang attribute
            const lang = this.getAttribute('lang');
            if (!lang) return;
            
            // Extract just the language part (e.g., 'de' from 'de-CH')
            const langCode = lang.split('-')[0];
            
            // Get current URL
            const currentUrl = new URL(window.location.href);
            
            // Update or add the lang parameter
            currentUrl.searchParams.set('lang', langCode);
            
            // Redirect to the same page with new language
            window.location.href = currentUrl.toString();
        });
    });
    
    // Update active button state
    updateActiveLanguageButton();
});

function updateActiveLanguageButton() {
    // Get current language from URL or cookie
    const urlParams = new URLSearchParams(window.location.search);
    const currentLang = urlParams.get('lang') || getCookie('lang') || 'de';
    
    // Get all language buttons
    const langButtons = document.querySelectorAll('button[lang]');
    
    langButtons.forEach(button => {
        const buttonLang = button.getAttribute('lang');
        if (!buttonLang) return;
        
        const buttonLangCode = buttonLang.split('-')[0];
        
        // Remove active class from all buttons
        button.classList.remove('active');
        button.setAttribute('tabindex', '0');
        
        // Add active class to current language button
        if (buttonLangCode === currentLang) {
            button.classList.add('active');
            button.setAttribute('tabindex', '-1');
        }
    });
    
    // Update HTML lang attribute
    const htmlLang = currentLang + '-CH';
    document.documentElement.setAttribute('lang', htmlLang);
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}
