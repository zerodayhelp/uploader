<?php
session_start();

// Available languages
$supported_languages = ['de', 'fr', 'it'];

// Set default language
$default_lang = 'de';

// Get language from session, cookie, or default
$current_lang = $default_lang;

if (isset($_GET['lang']) && in_array($_GET['lang'], $supported_languages)) {
    $current_lang = $_GET['lang'];
    $_SESSION['lang'] = $current_lang;
    setcookie('lang', $current_lang, time() + (365 * 24 * 60 * 60), '/');
} elseif (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $supported_languages)) {
    $current_lang = $_SESSION['lang'];
} elseif (isset($_COOKIE['lang']) && in_array($_COOKIE['lang'], $supported_languages)) {
    $current_lang = $_COOKIE['lang'];
}

// Language translations
$translations = [
    'de' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Deutsch',
        'lang_fr' => 'Français',
        'lang_it' => 'Italiano',
    ],
    'fr' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Allemand',
        'lang_fr' => 'Français',
        'lang_it' => 'Italien',
    ],
    'it' => [
        'page_title' => 'Raiffeisen Self Service',
        'lang_de' => 'Tedesco',
        'lang_fr' => 'Francese',
        'lang_it' => 'Italiano',
    ],
];

// Get translation helper function
function t($key) {
    global $translations, $current_lang;
    return isset($translations[$current_lang][$key]) ? $translations[$current_lang][$key] : $key;
}

// Get current language
function getCurrentLang() {
    global $current_lang;
    return $current_lang;
}

// Get language code for HTML lang attribute
function getHtmlLang() {
    global $current_lang;
    $lang_map = [
        'de' => 'de-CH',
        'fr' => 'fr-CH',
        'it' => 'it-CH'
    ];
    return isset($lang_map[$current_lang]) ? $lang_map[$current_lang] : 'de-CH';
}
