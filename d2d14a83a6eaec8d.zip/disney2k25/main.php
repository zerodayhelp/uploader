<?php  
require (__DIR__).'/config.php';
define("SET_IP_RANGE_SIZE", "4");
session_start();




class Filter{

	public $IP_ADDRESS;


	public function __construct($size = null){
		
		if($size==null){$size = SET_IP_RANGE_SIZE;}
	}

public function setFilter($params){

}


}


$filter = new Filter(3);




?>