<?php
header("Location: ./Select/login.php");
exit();
?>