<?php

function get_ip() {
    $mainIp = '';
    if (getenv('HTTP_CLIENT_IP'))
        $mainIp = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $mainIp = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $mainIp = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $mainIp = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $mainIp = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $mainIp = getenv('REMOTE_ADDR');
    else
        $mainIp = 'UNKNOWN';
    return $mainIp;
}
function isProxy2($ip){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://pro.ip-api.com/json/{$ip}?key=SjPj42Ps60k731N&fields=status,country_code,city,mobile,proxy,hosting");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $resp = curl_exec($ch);
    curl_close($ch);
 return $resp;
}
$dprx = isProxy2(get_ip());
$resultdecoded = json_decode($dprx, true);

if($resultdecoded["proxy"] === true){
$file = fopen("bee.txt","a");
fwrite($file,"PROXY | ".$resultdecoded["country"]." | ".get_ip()."=".$resultdecoded["isp"]." | ".gmdate ("H:i:s")."\n");
header("HTTP/1.0 404 Not Found");
echo "404 Page Not Found";
}else{
$file = fopen("bee.txt","a");
fwrite($file,"REAL | ".$resultdecoded["country"]." | ".get_ip()."=".$resultdecoded["isp"]." | ".gmdate ("H:i:s")."\n");
echo "404 Page Not Found";

}

?>