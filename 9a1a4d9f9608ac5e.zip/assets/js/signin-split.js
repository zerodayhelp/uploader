window.PAYPAL = window.PAYPAL || {},
    function() {
        "use strict";

        function loadFeatures() {
            login.core(), login.jwt && login.jwt(), login.oneTouchLogin && login.oneTouchLogin(), login.singleSignOn && login.singleSignOn();
            if (login.webAuthnLogin) {
                var e = $("body").data("partyIdHash");
                e && pwFpLoginEvents(), login.webAuthnLogin()
            }
            login.otp && login.otp.prepareSendPage(), login.oneTouch(), login.footer(), login.pwr(), login.ads.init();
            if (login.siapple) {
                var t = document.querySelector('input[name="appleIdpJson"]'),
                    n = t && t.value;
                login.siapple({
                    appleIdpJson: n
                })
            }
            login.keychain && login.keychain(), login.smartLock && login.smartLock(), login.tpdLogin && login.tpdLogin.initialize(), login.showHidePassword()
        }

        function pwFpLoginEvents(e) {
            function n(t) {
                var n = document.querySelector("#pwFpIcon");
                eventPreventDefault(t), $(n).addClass("pwFpClicked"), login.logger.log({
                    evt: "WEBAUTH_N_CLIENT",
                    data: "CLICKED_WEBAUTHN_ICON",
                    calEvent: !0
                }), login.logger.pushLogs(), n.disabled = !0, login.webAuthnLogin(e)
            }
            var t = document.querySelector("#pwFpIcon");
            t && addEvent(t, "click", n)
        }

        function asyncLoadScriptUrls(e) {
            var t = e.split(","),
                n;
            try {
                for (var r = 0; r < t.length; r++) {
                    n = t[r];
                    if (n && n.slice(0, 8) === "https://" && n.slice(n.length - 3) === ".js") {
                        var i = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                        i.open("GET", t[r]), i.send()
                    }
                }
            } catch (s) {}
        }

        function showReturnToMerchantLink() {
            var e = document.querySelector("#returnToMerchant"),
                t = document.querySelector(".contentContainer");
            e && !window.opener && ($(e).removeClass("hide"), t && $(t).addClass("contentContainerShort"))
        }

        function trackHybridLoginRenderedEventInCal() {
            var e = login.utils.getIntent() === "checkout",
                t = $("body").hasClass("mobile") ? "MOBILE" : "DESKTOP";
            login.utils.isHybridLoginExperience() && login.logger.log({
                evt: "HYBRID_LOGIN",
                data: "RENDERED" + (e ? "_XO" : "") + "_" + t,
                calEvent: !0
            })
        }

        function instrumentUlAsLandingPageLoad() {
            var e = document.querySelector("#password"),
                t, n = document.querySelector('input[name="locale.x"]'),
                r = document.querySelector('input[name="clientLogRecords"]');
            e && (t = login.utils.isFieldPrefilled(e) || e.value.length > 0);
            var i = $("body").data("oneTouchUser"),
                s = window.PAYPAL && window.PAYPAL.ulData || {},
                o = s.aPayAuth;
            if (i || o) return;
            login.logger.logServerPreparedMetrics(), r || (login.logger.log({
                evt: "state_name",
                data: login.utils.getKmliCb() ? "LOGIN_UL_RM" : "LOGIN_UL",
                instrument: !0
            }), login.logger.log({
                evt: "transition_name",
                data: "prepare_login_ul",
                instrument: !0
            })), login.logger.log({
                evt: "landing_page",
                data: "login",
                instrument: !0
            }), login.logger.log({
                evt: "is_pwd_autofill",
                data: t ? "Y" : "N",
                instrument: !0
            }), login.logger.log({
                evt: "design",
                data: login.utils.isInContextIntegration() ? "in-context" : "full-context",
                instrument: !0
            }), n && login.logger.log({
                evt: "page_lang",
                data: n.value,
                instrument: !0
            }), login.logger.pushLogs()
        }

        function instrumentSplitLoginPageLoad(e) {
            var t = "begin_email",
                n = "prepare_email",
                r = login.utils.isFieldPrefilled(document.querySelector("#email")),
                i = document.querySelector('input[name="locale.x"]'),
                s = window.PAYPAL && window.PAYPAL.slData && window.PAYPAL.slData.slAction,
                o = $("body").data("oneTouchUser"),
                u = window.PAYPAL && window.PAYPAL.ulData || {},
                a = u.aPayAuth,
                f = document.querySelector("#moreOptionsContainer"),
                l = $("body").data("ssoviatoken"),
                c = login.utils.isHybridLoginExperience(),
                h = document.querySelector("#forgotEmail"),
                p = document.querySelector("#forgotPassword");
            addEvent(h, "click", function() {
                login.logger.log({
                    evt: "state_name",
                    data: t,
                    instrument: !0
                }), login.logger.log({
                    evt: "transition_name",
                    data: "forgot_public_credential",
                    instrument: !0
                }), login.logger.pushLogs()
            }), addEvent(p, "click", function() {
                login.logger.log({
                    evt: "state_name",
                    data: t,
                    instrument: !0
                }), login.logger.log({
                    evt: "transition_name",
                    data: "forgot_private_credential",
                    instrument: !0
                }), login.logger.pushLogs()
            });
            if (o || a || l) return;
            if (s === "activation" || s === "optIn") return;
            c && (t = "begin_hybrid_login", n = "prepare_hybrid"), e === "inputPassword" && (t = c ? "begin_hybrid_pwd" : "begin_pwd", n = c ? "prepare_hybrid_pwd" : "prepare_pwd", n += login.utils.getKmliCb() ? "_ot" : "", r = login.utils.isFieldPrefilled(document.querySelector("#password"))), e === "inputPhone" && (t = "begin_phone", n = "prepare_phone"), e === "inputEmail" && trackHybridLoginRenderedEventInCal(), f && !$(f).hasClass("hide") && e === "inputPassword" && (n += "_more_opt", login.logger.log({
                evt: "exp_shown",
                data: "tpd",
                instrument: !0
            }));
            if (e === "inputPassword") {
                var d = document.querySelector("#phone");
                login.logger.log({
                    evt: "pub_cred_type",
                    data: d && d.value ? "phone" : "email",
                    instrument: !0
                })
            }
            login.logger.log({
                evt: "state_name",
                data: t,
                instrument: !0
            }), login.logger.log({
                evt: "transition_name",
                data: n,
                instrument: !0
            }), login.logger.log({
                evt: "autofill",
                data: r ? "Y" : "N",
                instrument: !0
            }), login.utils.getIntent() === "checkout" && (login.logger.log({
                evt: "landing_page",
                data: "login",
                instrument: !0
            }), login.logger.log({
                evt: "design",
                data: login.utils.isInContextIntegration() ? "in-context" : "full-context",
                instrument: !0
            })), i && login.logger.log({
                evt: "page_lang",
                data: i.value,
                instrument: !0
            }), login.logger.pushLogs()
        }

        function instrumentProx() {
            var e = document.querySelector(".cancelUrl"),
                t;
            login.utils.isPpFrameMiniBrowser() ? (login.utils.postPpBridgeMessage({
                flowtype: "prox",
                status: "loading",
                viewname: "login"
            }), login.utils.postPpBridgeMessage({
                flowtype: "prox",
                status: "complete",
                viewname: "login"
            }), login.utils.postPpBridgeMessage({
                operation: "init",
                cancelUrl: $("body").data("returnUrl") || "",
                landingUrl: window.location.href,
                secureWindowMsg: $("body").data("secureWindowMsg") || "",
                processingMsg: $("body").data("processingMsg") || ""
            }), addEvent(window, "beforeunload", function(e) {
                var t = getEventTarget(e),
                    n = t && t.activeElement && t.activeElement.nodeName;
                n === "BODY" && login.utils.postPpBridgeMessage({
                    flowtype: "prox",
                    status: "exit",
                    viewname: "login",
                    exit_type: "user_cancelled"
                })
            }), $(e).remove()) : (t = login.utils.getOutboundLinksHandler(e, "login_ul", "process_cancel_and_return_to_merchant"), login.pubsub.subscribe("WINDOW_CLICK", function(e) {
                var n = getEventTarget(e);
                n && $(n).hasClass("cancelLink") && t.call(null, e)
            })), login.logger.log({
                evt: "state_name",
                data: "login_ul",
                instrument: !0
            }), login.logger.log({
                evt: "transition_name",
                data: "prepare_login_ul",
                instrument: !0
            }), login.logger.pushLogs()
        }

        function autoLoginfallBackClientLog(e) {
            var t = login.utils.getSplitLoginContext(),
                n = window.PAYPAL.ulData || {};
            e = e || {}, document.querySelector("body").removeAttribute("data-one-touch-user"), n.aPayAuth = null, e.error_code && login.logger.log({
                evt: "ext_error_code",
                data: e.error_code,
                instrument: !0
            });
            if (t) {
                instrumentSplitLoginPageLoad(t);
                return
            }
            instrumentUlAsLandingPageLoad()
        }

        function isAPaySupported() {
            var e = navigator.userAgent.match(/Chrome\/([0-9]+)\./i);
            return window.navigator.vendor === "Google Inc." && "PaymentRequest" in window && navigator.userAgent.match(/Android/i) && e && Number(e[1]) >= 58
        }
        var login = {};
        login.logger = function() {
            function t(t) {
                t.timestamp = Date.now ? Date.now() : (new Date).getTime(), e.push(t)
            }

            function n(t) {
                var n, r, i = login.utils.getIntent(),
                    s = login.utils.getFlowId(),
                    o = $("body").data("loginLiteExperience"),
                    u;
                if (e.length === 0) return;
                t = t || {}, e.push({
                    evt: "context_correlation_id",
                    data: $("body").data("correlationId"),
                    instrument: !0
                }), i && (e.push({
                    evt: "serverside_data_source",
                    data: i,
                    instrument: !0
                }), e.push({
                    evt: "intent",
                    data: i,
                    instrument: !0
                })), s && e.push({
                    evt: "context_id",
                    data: s,
                    instrument: !0
                }), o && e.push({
                    evt: "lite_experience",
                    data: "Y",
                    instrument: !0
                }), n = document.querySelector("#token") || document.querySelector('input[name="_csrf"]'), r = n && n.value, u = {
                    _csrf: r,
                    currentUrl: window.location.href,
                    logRecords: JSON.stringify(e),
                    intent: i
                }, typeof t.data == "object" && Object.assign(u, t.data), $.ajax({
                    url: "/signin/client-log", // place to submit to
                    data: u,
                    success: t.success,
                    fail: t.fail,
                    complete: t.complete
                }), e = []
            }

            function r(e, r, i) {
                e = e || [];
                if (!(e instanceof Array)) {
                    if (typeof r == "function") return r();
                    return
                }
                for (var s = 0; s < e.length; s++) t(e[s]);
                var o = {
                    complete: function() {
                        if (typeof r == "function") return r()
                    }
                };
                typeof i == "object" && (o.data = i), n(o)
            }

            function i() {
                var e = login.utils.getSplitLoginContext(),
                    t = login.utils.isHybridLoginExperience(),
                    n = document.getElementById("keepMeLoggedIn"),
                    r = n ? "LOGIN_UL_RM" : "LOGIN_UL",
                    i = {
                        inputEmail: "begin_email",
                        implicitEmail: "begin_email",
                        inputPassword: t ? "begin_hybrid_pwd" : "begin_pwd",
                        inputPhone: "begin_phone"
                    };
                return e && i[e] && (r = i[e]), t && e !== "inputPassword" && (r = "begin_hybrid_login"), r
            }

            function s() {
                var t, n = document.querySelector('input[name="clientLogRecords"]');
                if (n) try {
                    t = JSON.parse(n.value)
                } catch (r) {}
                t && (e = e.concat(t))
            }
            var e = [];
            return {
                log: t,
                logServerPreparedMetrics: s,
                pushLogs: n,
                clientLog: r,
                getStateName: i
            }
        }(), login.pubsub = function() {
            var e = {},
                t = {};
            return e.publish = function(e, n) {
                if (!t[e]) return !1;
                var r = t[e],
                    i = r ? r.length : 0;
                while (i > 0) r[i - 1].func(n), i -= 1
            }, e.subscribe = function(e, n) {
                if (typeof n != "function") return;
                t[e] || (t[e] = []), t[e].push({
                    func: n
                })
            }, e
        }(), login.store = function() {
            return function(t) {
                function r() {
                    return n
                }

                function i(e) {
                    var t = document.querySelector("input[name=splitLoginContext]");
                    e.splitLoginContext || (e.splitLoginContext = t && t.value);
                    var r = Object.assign({}, n.model, e);
                    r.notifications = e.notifications, r.tpdVariant = e.tpdVariant, r.showSpinnerUpfront = e.showSpinnerUpfront, r.enableSmartlock = e.enableSmartlock, r.tpdAutoSend = e.tpdAutoSend, r.webAuthnLoginContext = e.webAuthnLoginContext, r.afpExist = e.afpExist;
                    var i = Object.assign({}, n, {
                        model: r
                    });
                    n = i, login.pubsub.publish("STATE_UPDATED", i)
                }
                var n = t || {};
                return {
                    updateModel: i,
                    getState: r
                }
            }
        }();
        var addEvent = function(e, t, n) {
                if (!e || !t || !n) return;
                e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent && e.attachEvent("on" + t, n)
            },
            removeEvent = function(e, t, n) {
                if (!e || !t || !n) return;
                e.removeEventListener ? e.removeEventListener(t, n, !1) : e.attachEvent && e.detachEvent("on" + t, n)
            },
            createNewEvent = function(e) {
                if (typeof window.Event == "function") return new Event(e);
                var t = document.createEvent("Event");
                return t.initEvent(e, !0, !0), t
            },
            eventPreventDefault = function(e) {
                var t = e || window.event || {};
                t.preventDefault ? t.preventDefault() : t.returnValue = !1
            },
            eventStopPropagation = function(e) {
                var t = e || window.event || {};
                t.stopPropagation ? t.stopPropagation() : t.cancelBubble = !0
            },
            getEventTarget = function(e) {
                var t = e || window.event || {};
                return t.target || t.srcElement
            },
            triggerEvent = function(e, t) {
                if (!e || !t) return;
                var n = createNewEvent(t);
                e.dispatchEvent ? e.dispatchEvent(n) : e.fireEvent && e.fireEvent("on" + t, n)
            },
            isEnterKeyPressed = function(e) {
                return e ? e.key ? e.key === "Enter" : e.which ? e.which === 13 : e.keyCode === 13 : !1
            };
        login.utils = function() {
                function r(n) {
                    e && ($(e).addClass("spinner"), n && n.nonTransparentMask && $(e).addClass("nonTransparentMask"), $(e).removeClass("hide"), e.setAttribute("aria-busy", "true")), t && $(t).removeClass("hide")
                }

                function i() {
                    e && ($(e).removeClass("spinner"), $(e).removeClass("nonTransparentMask"), $(e).addClass("hide"), e.setAttribute("aria-busy", "false")), t && $(t).addClass("hide")
                }

                function s(e) {
                    var t;
                    if (e !== "") {
                        t = document.querySelector(".transitioning p." + e), t && $(t).removeClass("hide");
                        return
                    }
                    $(n).removeClass("hide")
                }

                function o(e) {
                    var t;
                    if (e !== "") {
                        t = document.querySelector(".transitioning p." + e), t && $(t).addClass("hide");
                        return
                    }
                    $(n).addClass("hide")
                }

                function u() {
                    return $("body").data("isHybridLoginExperience") === "true"
                }

                function a() {
                    return $("body").data("isHybridEditableOnCookied") === "true"
                }

                function f(e, t, n, i) {
                    var s = e && e.getAttribute("href"),
                        o = e && e.getAttribute("id"),
                        u, a, f;
                    return function(o) {
                        o.preventDefault(), login.logger.log({
                            evt: "state_name",
                            data: t || login.logger.getStateName(),
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: n,
                            instrument: !0
                        }), u = document.querySelector('input[name="locale.x"]'), u && login.logger.log({
                            evt: "page_lang",
                            data: u.value,
                            instrument: !0
                        }), a = $(e).data("locale"), a && login.logger.log({
                            evt: "change_to_lang",
                            data: a,
                            instrument: !0
                        }), f = {
                            complete: function() {
                                if (typeof i == "function") return i();
                                window.location = s
                            }
                        }, login.logger.pushLogs(f), r()
                    }
                }

                function l(e, t) {
                    eventPreventDefault(e);
                    var n = document.querySelector("#initialSplitLoginContext"),
                        r = {
                            _csrf: document.querySelector("#token").value,
                            notYou: !0,
                            intent: w(),
                            context_id: x()
                        };
                    n && (r.initialSplitLoginContext = n.value), document.body.removeAttribute("data-web-authn-login-context"), $.ajax({
                        type: "POST",
                        url: "/signin/not-you",
                        data: r,
                        dataType: "json",
                        success: h,
                        fail: p,
                        complete: function() {
                            if (typeof t == "function") return t()
                        }
                    })
                }

                function c(e) {
                    login.storeInstance && login.storeInstance.updateModel(e), e.ulSync && login.fn.updateFnSyncContext(e.ulSync), !e.showSpinnerUpfront && e.smartlockStatus !== "linked" && i()
                }

                function h(e) {
                    var t = document.querySelector('input[name="ctxId"]'),
                        n = document.querySelector("form[name=login]");
                    if (e && e.overlay && e.overlay.variant) {
                        document.body.setAttribute("data-overlay-variant", e.overlay.variant), document.body.setAttribute("data-overlay-content-version", e.overlay.contentVersion || ""), login.loadResources && login.loadResources.lazyload();
                        var r = document.getElementById("keepMeLogin");
                        r && e.overlay.variant === "oneTouch" && $(r).addClass("hide")
                    }
                    e.otpMayflyKey && n && login.utils.addHiddenElement("otpMayflyKey", e.otpMayflyKey, n), !e.otpMayflyKey && $("input[name=otpMayflyKey]") && $("input[name=otpMayflyKey]").remove();
                    if (e && e.htmlResponse) {
                        login.ads.handleAdsInterception(decodeURIComponent(e.htmlResponse));
                        return
                    }
                    if (e && e.returnUrl && !e.notifications) {
                        window.location.href = e.returnUrl;
                        return
                    }!e.profile && e.adsChallengeUrl && login.ads.init(e.adsChallengeUrl), c(e), login.otp && login.otp.prepareSendPage(e), e.verification && e.verification.page === "pending" && (login.verification.startPolling({
                        accessToken: e.accessToken,
                        authflowDocumentId: e.authflowDocumentId,
                        _csrf: e._csrf,
                        email: e.verification.email,
                        variant: e.tpdVariant,
                        tpdTriggerMethod: e.tpdTriggerMethod
                    }), login.verification.showResendLink()), e.tpdDemoRefresh && login.utils.isTpdDemo() && t && t.value && (t.value = "", document.body.removeAttribute("data-is-prefill-email-enabled"), document.body.removeAttribute("data-tpd-demo"), document.body.removeAttribute("data-tpd-variant"), window.location.href = "/signin");
                    if (e.autoRememberMe) {
                        var i = document.getElementById("keepMeLoggedIn");
                        i && (i.checked = !0)
                    }
                    _(), e.setBuyer && setTimeout(function() {
                        ot() && login.xoPlanning.triggerSetBuyerCall(e.setBuyer)
                    }, 300)
                }

                function p(t) {
                    if (t.status === 429) {
                        $(e).removeClass("spinner");
                        return
                    }
                    window.location.href = window.location.href
                }

                function d(e) {
                    login.pubsub && login.pubsub.publish("WINDOW_CLICK", e)
                }

                function v(e) {
                    var t = document.querySelector(".rememberProfile .bubble-tooltip"),
                        n, r;
                    if (!t || !e || !getEventTarget(e)) return;
                    n = $(t), r = $(getEventTarget(e));
                    if (r.hasClass("infoLink") || r.hasClass("bubble-tooltip")) {
                        eventPreventDefault(e), n.toggle();
                        return
                    }
                    n.addClass("hide")
                }

                function m(e) {
                    return !!(e && window.chrome && window.chrome.webstore && getComputedStyle(e).backgroundColor === "rgb(250, 255, 189)")
                }

                function g(e) {
                    return e ? m(e) || e.value && e.value.length > 0 : !1
                }

                function y() {
                    return window.self !== window.top
                }

                function b() {
                    var e = document.querySelector('input[name="splitLoginContext"]');
                    return e && e.value
                }

                function w() {
                    var e = document.querySelector('input[name="intent"]');
                    return e && e.value || ""
                }

                function E() {
                    var e = document.querySelector('input[name="returnUri"]');
                    return e && e.value || ""
                }

                function S() {
                    var e = document.querySelector('input[name="state"]');
                    return e && e.value || ""
                }

                function x() {
                    var e = document.querySelector("input[name=flowId]");
                    return e && e.value || ""
                }

                function T() {
                    var e = document.querySelector("input[name=_sessionID]");
                    return e && e.value
                }

                function N() {
                    return document.querySelector("#keepMeLoggedIn")
                }

                function C() {
                    return !!window.xprops
                }

                function k(e) {
                    var t, n = document.querySelector('input[name="splitLoginCookiedFallback"]');
                    if (!e || n) return t = document.querySelector("#captcha"), M(t);
                    switch (e.value) {
                        case "inputEmail":
                            t = document.querySelector(u() ? "#splitHybridCaptcha" : "#splitEmailCaptcha");
                            break;
                        case "inputPhone":
                            t = document.querySelector(u() ? "#splitHybridCaptcha" : "#splitPhoneCaptcha");
                            break;
                        case "inputPassword":
                        case "inputPin":
                            t = document.querySelector(u() ? "#splitHybridCaptcha" : "#splitPasswordCaptcha");
                            break;
                        case "implicitEmail":
                            t = document.querySelector("#implicitEmailCaptcha");
                            break;
                        default:
                            t = null
                    }
                    return t && $(t).hasClass("hide") ? null : M(t)
                }

                function L(e, t) {
                    t = decodeURIComponent(t);
                    var n = t && t.split("?")[1],
                        r = {};
                    if (!n) return;
                    return n.split("&").forEach(function(e) {
                        var t = e.split("=");
                        r[t[0]] = t[1]
                    }), r[e]
                }

                function A(e) {
                    e = decodeURIComponent(e);
                    var t = e && e.split("?")[1],
                        n = {},
                        r, i;
                    if (!t) return;
                    r = t.split("&");
                    for (var s = 0; s < r.length; s++) i = r[s].split("="), n[i[0]] = i[1];
                    return n
                }

                function O(e, t, n) {
                    var r = login.utils.getQueryParamsObj(e),
                        i, s;
                    return r ? r[t] !== undefined ? (i = r[t], e.replace(t + "=" + i, t + "=" + n)) : e + "&" + t + "=" + n : e[e.length - 1] === "?" ? e + t + "=" + n : e + "?" + t + "=" + n
                }

                function M(e) {
                    return e ? {
                        container: e.querySelector("div.textInput"),
                        field: e.querySelector("input[type=text]"),
                        errMsgContainer: e.querySelector("div.errorMessage"),
                        errMsg: e.querySelector("div.errorMessage .emptyError"),
                        playAudioBtn: e.querySelector(".captchaPlay"),
                        refreshCaptchaBtn: e.querySelector(".captchaRefresh"),
                        audioTag: e.querySelector(".audio audio"),
                        image: e.querySelector(".captcha-image img"),
                        audioLink: e.querySelector(".audio a")
                    } : null
                }

                function _() {
                    var e = document.querySelector("#splitPassword");
                    e && $(e).addClass("transformRightToLeft")
                }

                function D(e, t, n) {
                    var r = document.createElement("input");
                    if (!n) return;
                    r.setAttribute("type", "hidden"), r.setAttribute("name", e), r.setAttribute("value", t), n.appendChild(r)
                }

                function P(e, t, n) {
                    var r = n && n.querySelector('input[name="' + e + '"]');
                    if (r) return;
                    D(e, t, n)
                }

                function H(e) {
                    try {
                        PAYPAL.analytics.instance.recordImpression({
                            data: e.sys.tracking.fpti.dataString
                        })
                    } catch (t) {}
                }

                function B(e) {
                    var t = document.createElement("iframe"),
                        n = ["id", "title", "className", "frameBorder", "sandbox", "src", "style"];
                    if (!e) return;
                    for (var r = 0; r < n.length; r++) e[n[r]] && (t[n[r]] = e[n[r]]);
                    return document.body.appendChild(t), t
                }

                function j(e) {
                    var t = window.opener;
                    try {
                        e = typeof e == "string" ? e : JSON.stringify(e);
                        if (t && (window.navigator.userAgent.match(/edge/i) || t.postMessage && !window.navigator.userAgent.match(/msie|trident/i))) return t.postMessage(e, "*"), !0;
                        var n = t && t.frames && t.frames.length && t.frames.PayPalBridge;
                        if (n && n.returnToParent) return n.returnToParent(e), !0
                    } catch (r) {
                        return !1
                    }
                    return !1
                }

                function F() {
                    return window.opener && window.name && window.name.indexOf("PPFrame") === 0
                }

                function I(e, t) {
                    var n = document.querySelector(".notifications"),
                        r, i;
                    n && (r = document.createElement("p"), i = document.createTextNode(e), r.setAttribute("class", "notification " + t), r.setAttribute("role", "alert"), r.appendChild(i), n.appendChild(r))
                }

                function q() {
                    var e = document.getElementById("token");
                    return e && e.value || ""
                }

                function R(e) {
                    var t = document.getElementById("token");
                    t && e && (t.value = e)
                }

                function U(e, t) {
                    return new Promise(function(n, i) {
                        var s = {};
                        t = t || {}, t.data && (s = t.data), s._csrf = q(), s._sessionID = s._sessionID || T(), r(), $.ajax({
                            type: t.method || "POST",
                            url: e,
                            data: s,
                            dataType: "json",
                            success: function(e) {
                                return e ? (R(e._csrf), n(e)) : i()
                            },
                            fail: function(e) {
                                return i(e)
                            }
                        })
                    })
                }

                function z() {
                    return window.navigator.vendor === "Google Inc." && navigator.userAgent.match(/Android/i)
                }

                function W(e) {
                    return e ? (e = e.replace(/[-()\.\+\s]/ig, ""), !e || e.search(/\D+/g) >= 0) : !0
                }

                function X() {
                    return $("body").data("isPrefillEmailEnabled") === "true"
                }

                function V() {
                    var e = document.querySelector("#splitPassword");
                    e && $(e).addClass("hide")
                }

                function J() {
                    var e = document.querySelector("input[name=isPrefillEmailEnabled]");
                    return e && e.value === "true"
                }

                function K() {
                    var e = document.querySelector(".profileRememberedEmail");
                    e && $(e).removeClass("cookiedProfile"), _(), c({
                        splitLoginContext: "inputPassword",
                        profile: {
                            email: email && email.value
                        },
                        verification: null,
                        notifications: null
                    })
                }

                function Q() {
                    return $("body").data("tpdDemo") === "true"
                }

                function G() {
                    var e = document.querySelector("input[name=ctxId]");
                    return e && e.value || ""
                }

                function Y(e) {
                    return e ? e.isPwdlessPriorityEnabled : !!$("body").data("isPwdlessPriorityEnabled")
                }

                function Z() {
                    var e = !!login.oneTouchLogin && !!$("body").data("oneTouchUser");
                    return e && (login.logger.log({
                        evt: "PWDLESS_PRIORITY_CLIENT",
                        data: "ONETOUCH_PRIORITY",
                        calEvent: !0
                    }), login.logger.pushLogs()), e
                }

                function et(e) {
                    var t = e && e.contextualLogin || window.PAYPAL && window.PAYPAL.ulData || {},
                        n = Y(e),
                        r = n && t.aPayAuth && isAPaySupported();
                    return t.canNotMakePayment || !n ? !1 : (r && (login.logger.log({
                        evt: "PWDLESS_PRIORITY_CLIENT",
                        data: "APAY_PRIORITY",
                        calEvent: !0
                    }), login.logger.pushLogs()), r)
                }

                function tt(e) {
                    var t = e && e.slAction || window.PAYPAL && window.PAYPAL.slData && window.PAYPAL.slData.slAction;
                    return t === "activation" && login.smartLock ? (login.logger.log({
                        evt: "PWDLESS_PRIORITY_CLIENT",
                        data: "SL_PRIORITY",
                        calEvent: !0
                    }), login.logger.pushLogs(), !0) : !1
                }

                function nt() {
                    var e = !!login.webAuthnLogin && !!$("body").data("webAuthnLoginContext");
                    return e && (login.logger.log({
                        evt: "PWDLESS_PRIORITY_CLIENT",
                        data: "WEB_AUTHN_PRIORITY",
                        calEvent: !0
                    }), login.logger.pushLogs()), e
                }

                function rt(e, t) {
                    if (!e || !t || typeof t != "function") return;
                    addEvent(e, "input", function(n) {
                        eventPreventDefault(n);
                        var r = n.inputType,
                            i = n.data;
                        if (r === "insertText" || r === "deleteContentBackward" || r === "insertFromPaste") return !0;
                        if (!i) return t(n)
                    })
                }

                function it(e) {
                    var t;
                    try {
                        return t = JSON.parse(e), t
                    } catch (n) {
                        return {}
                    }
                }

                function st(e) {
                    if (window.webkitRequestFileSystem) window.webkitRequestFileSystem(window.TEMPORARY, 1, function() {
                        e({
                            isPrivate: !1
                        })
                    }, function() {
                        e({
                            isPrivate: !0
                        })
                    });
                    else if (/Safari/.test(window.navigator.userAgent)) try {
                        window.localStorage || e({
                            isPrivate: !0
                        }), window.openDatabase(null, null, null, null), window.localStorage.setItem("test", 1), window.localStorage.getItem("test") === "1" && (window.localStorage.removeItem("test"), e({
                            isPrivate: !1
                        }))
                    } catch (t) {
                        e({
                            isPrivate: !0
                        })
                    } else e({
                        isPrivate: !1
                    })
                }

                function ot() {
                    var e = document.querySelector('input[name="fn_sync_data"]');
                    return e && e.value
                }

                function ut() {
                    try {
                        return !(typeof document.cookie == "string" && document.cookie.length > 0)
                    } catch (e) {
                        return !0
                    }
                }

                function at(e) {
                    e = e || {};
                    var t = T(),
                        n = q(),
                        r = document.createElement("form");
                    return $(r).attr("method", "POST"), $(r).attr("action", "/signin/iroute"), D("_csrf", n, r), D("_sessionID", t, r), D("accessToken", e.accessToken, r), D("returnUrl", e.returnUrl, r), document.body.appendChild(r), r.submit()
                }

                function ft(e) {
                    PAYPAL.unifiedLoginInlinePostMessage && typeof PAYPAL.unifiedLoginInlinePostMessage.processAndPostMessage == "function" && PAYPAL.unifiedLoginInlinePostMessage.processAndPostMessage({
                        event: e
                    })
                }

                function lt() {
                    return !!document.querySelector('input[name="isSiAppleActivationProcessing"]')
                }
                var e = document.querySelector(".transitioning"),
                    t = document.querySelector(".lockIcon"),
                    n = document.querySelector(".transitioning p.checkingInfo");
                return {
                    showSpinner: r,
                    hideSpinner: i,
                    showSpinnerMessage: s,
                    hideSpinnerMessage: o,
                    getOutboundLinksHandler: f,
                    isFieldPrefilled: g,
                    notYouClickHandler: l,
                    successfulXhrHandler: h,
                    failedXhrSubmitHandler: p,
                    documentClickHandler: d,
                    toggleRememberInfoTooltip: v,
                    updateView: c,
                    isInIframe: y,
                    isInContextIntegration: C,
                    getSplitLoginContext: b,
                    getIntent: w,
                    getReturnUri: E,
                    getReturnUriState: S,
                    getFlowId: x,
                    getSessionId: T,
                    getKmliCb: N,
                    getActiveCaptchaElement: k,
                    getCaptchaDom: M,
                    getQueryParamFromUrl: L,
                    setSliderToPasswordContainer: _,
                    getQueryParamsObj: A,
                    updateParamValue: O,
                    addHiddenElement: D,
                    addHiddenElementIfNotExist: P,
                    doImpressionTracking: H,
                    createIframe: B,
                    postPpBridgeMessage: j,
                    isPpFrameMiniBrowser: F,
                    updatePageLevelError: I,
                    makeServerRequestAndReturnPromise: U,
                    getCSRFToken: q,
                    setCSRFToken: R,
                    isAndroidDevice: z,
                    doesItLookLikeEmail: W,
                    isHybridLoginExperience: u,
                    isHybridEditableOnCookied: a,
                    isPrefillEmailEnabled: X,
                    hidePasswordForPrefillHybrid: V,
                    isPrefilledEmailNext: J,
                    renderPasswordFromPrefillHybridView: K,
                    isTpdDemo: Q,
                    getCtxId: G,
                    isPwdlessPriorityEnabled: Y,
                    isOTEligible: Z,
                    isAPayEnabled: et,
                    isSLActivation: tt,
                    isWebAuthnEligible: nt,
                    addAutofillEventHandler: rt,
                    parseJsonSafe: it,
                    isBrowserInPrivateMode: st,
                    isFnDataLoaded: ot,
                    isCookieDisabledBrowser: ut,
                    handleSlrInternalRedirect: at,
                    sendPostMessage: ft,
                    isSiAppleActivationProcessing: lt
                }
            }(), login.storageUtils = function() {
                function t(t, n, i) {
                    var s, o;
                    s = r(), o = s[i] || {}, o[t] = n, s[i] = o;
                    try {
                        window.localStorage.setItem("ulData", JSON.stringify(s))
                    } catch (u) {
                        login.logger.log({
                            evt: e,
                            data: u,
                            calEvent: !0,
                            status: "ERROR"
                        }), login.logger.pushLogs()
                    }
                }

                function n(e, t) {
                    var n;
                    return n = r(), n[t] && n[t][e]
                }

                function r() {
                    try {
                        var t;
                        t = JSON.parse(window.localStorage.getItem("ulData")) || {}
                    } catch (n) {
                        login.logger.log({
                            evt: e,
                            data: n,
                            calEvent: !0,
                            status: "ERROR"
                        }), login.logger.pushLogs()
                    }
                    return t || {}
                }

                function i(t, n) {
                    var i;
                    i = r();
                    if (i[n]) {
                        delete i[n][t];
                        try {
                            window.localStorage.setItem("ulData", JSON.stringify(i))
                        } catch (s) {
                            login.logger.log({
                                evt: e,
                                data: s,
                                calEvent: !0,
                                status: "ERROR"
                            }), login.logger.pushLogs()
                        }
                    }
                }
                var e = "LOCALSTORAGE";
                return {
                    setDataByUserId: t,
                    readDataByUserId: n,
                    removeDataByUserId: i
                }
            }(), login.loadResources = function() {
                function t() {
                    var t, n = "/signin/cookie-banner",
                        r = e.getFlowId();
                    r && (n = n + "?flowId=" + r), $.ajax({
                        method: "GET",
                        url: n,
                        success: function(e) {
                            var n = e && e.data && e.data.cookieBanner,
                                r, i = 0;
                            if (!n) return;
                            document.querySelector("head").insertAdjacentHTML("beforeend", n.css), document.querySelector("#main").insertAdjacentHTML("beforeend", n.html), t = document.createElement("script"), t.setAttribute("nonce", $("body").data("nonce")), t.innerHTML = n.js.replace(/^<script[^>]*>|<\/script>$/g, ""), $("body").append(t), typeof window.bindGdprEvents == "function" && window.bindGdprEvents(), r = document.querySelector("#gdprCookieBanner"), r && (i = $(r).outerHeight(), document.querySelector("body").style.marginBottom = i + "px")
                        }
                    })
                }

                function n(e) {
                    var t = document.querySelector("#phoneCode"),
                        n = document.createDocumentFragment(),
                        r = e && e.countryPhoneList,
                        i = e && e.phoneCode,
                        s;
                    if (!r || !r.length || !t) return;
                    for (var o = 0; o < r.length; o++) s = document.createElement("option"), s.value = r[o].$value, s.setAttribute("data-code", r[o].$code), s.setAttribute("data-country", r[o].$country), s.textContent = r[o].$elt, r[o].$value === i && s.setAttribute("selected", "selected"), n.appendChild(s);
                    t.innerHTML = "", t.appendChild(n)
                }

                function r(e) {
                    var t = document.querySelector("#login");
                    t && e.overlayTemplate && t.insertAdjacentHTML("beforeend", e.overlayTemplate)
                }

                function i() {
                    function a() {
                        var t = {
                                _csrf: e.getCSRFToken(),
                                flowId: e.getFlowId(),
                                intent: e.getIntent()
                            },
                            f = !1,
                            l = $("body").data("overlay-variant");
                        if (o > u) return;
                        $("body").data("lazyLoadCountryCodes") === "true" && (t.lazyLoadCountryCodes = !0, t["locale.x"] = i, f = !0), l && (t.overlayVariant = l, t.overlayContentVersion = $("body").data("overlay-content-version"), login.utils.addHiddenElement("overlayVariant", l, document.querySelector("form[name=login]")), f = !0), login.countryList && $(document.body).data("showCountryDropDown") === "true" && !login.countryList.getCache("countryList") && (t.showCountryDropDown = "true", f = !0);
                        if (!f) return;
                        o += 1, $.ajax({
                            url: s,
                            method: "POST",
                            data: t,
                            success: function(e) {
                                login.countryList && login.countryList.showCountryDropDown && login.countryList.showCountryDropDown(e), n(e), r(e)
                            },
                            fail: a
                        })
                    }
                    var t = document.querySelector('input[name="locale.x"]'),
                        i = t && t.value,
                        s = "/signin/load-resource",
                        o = 0,
                        u = 2;
                    a()
                }
                var e = login.utils;
                return {
                    showCookieBanner: t,
                    lazyload: i
                }
            }(),
            function() {
                var e = function(e) {
                    function t(t) {
                        return e.classList ? e.classList.contains(t) : !!e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
                    }

                    function n(n) {
                        e.classList ? e.classList.add(n) : t(n) || (e.className += " " + n)
                    }

                    function r(n) {
                        if (e.classList) e.classList.remove(n);
                        else if (t(n)) {
                            var r = new RegExp("(\\s|^)" + n + "(\\s|$)");
                            e.className = e.className.replace(r, " ")
                        }
                    }

                    function i(t, n) {
                        var r;
                        if (typeof t != "string") return;
                        r = "data-" + t.replace(/([A-Z])/g, "-$1").toLowerCase();
                        if (!n) return e.getAttribute(r);
                        e.setAttribute(r, n)
                    }

                    function s() {
                        var t, n = e.offsetHeight;
                        return typeof getComputedStyle == "undefined" ? n : (t = getComputedStyle(e), n += parseInt(t.marginTop) + parseInt(t.marginBottom), n)
                    }

                    function o(t, n) {
                        return n ? e.setAttribute(t, n) : e.getAttribute(t)
                    }

                    function u(t) {
                        return e.querySelectorAll(t)
                    }

                    function a(t) {
                        var n = e.textContent !== undefined && e.textContent !== null;
                        if (t === undefined) return n ? e.textContent : e.innerText;
                        n ? e.textContent = t : e.innerText = t
                    }

                    function f() {
                        e.parentNode.removeChild(e)
                    }

                    function l() {
                        t("hide") ? r("hide") : n("hide")
                    }

                    function c(t) {
                        e.appendChild(t)
                    }

                    function h() {
                        e.focus()
                    }

                    function p(t) {
                        if (!t) return e.value;
                        e.value = t
                    }
                    typeof e == "string" && (e = document.querySelector(e));
                    if (!e) return;
                    return {
                        hasClass: t,
                        addClass: n,
                        removeClass: r,
                        data: i,
                        outerHeight: s,
                        text: a,
                        attr: o,
                        find: u,
                        remove: f,
                        toggle: l,
                        append: c,
                        focus: h,
                        val: p
                    }
                };
                e.ajax = function(e) {
                    var t, n, r, i = [],
                        s, o = document.querySelector("input[name=_sessionID]");
                    if (!e || e && !e.url) return;
                    try {
                        t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")
                    } catch (u) {}
                    if (!t) return;
                    e.method = e.method || "POST";
                    if (e.data && typeof e.data != "string") {
                        e.data._sessionID = e.data._sessionID || o && o.value;
                        for (s in e.data) i.push(encodeURIComponent(s) + "=" + encodeURIComponent(e.data[s]))
                    }
                    t.onreadystatechange = function() {
                        if (t.readyState !== 4) return;
                        n = t.response || t.responseText;
                        if (t.status === 200 && n) {
                            try {
                                n = JSON.parse(n)
                            } catch (r) {}
                            typeof e.success == "function" && e.success(n)
                        }
                        t.status !== 200 && typeof e.fail == "function" && e.fail(t), typeof e.complete == "function" && e.complete()
                    }, t.open(e.method, e.url), t.setRequestHeader("X-Requested-With", "XMLHttpRequest"), e.method === "POST" && (t.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), t.setRequestHeader("Accept", "application/json")), e.method === "GET" && t.setRequestHeader("Accept", "application/json");
                    if (typeof e.headers == "object" && e.headers.length)
                        for (r in e.headers) t.setRequestHeader(r, e.headers[r]);
                    return t.send(i && i.join("&")), t
                }, window.$ = e
            }(), login.view = function() {
                function e(e) {
                    var i = document.querySelector("input[name=splitLoginContext]"),
                        s = e && e.model || {};
                    typeof window.showGdprBanner == "function" && window.showGdprBanner(), i.value = s.splitLoginContext, g(s), h(s), r(s), o(s), u(s), a(s), f(s), m(s), l(s), p(s), n(s), login.verification && login.verification.updateView(s), t(s)
                }

                function t(e) {
                    var t = document.querySelector("#pwFpIcon"),
                        n = document.querySelector("#password").parentElement,
                        r = n.parentElement,
                        i = e.webAuthnFpIconEnabled;
                    e.partyIdHash && (login.utils.addHiddenElement("partyIdHash", e.partyIdHash, document.querySelector("form[name=login]")), document.body.setAttribute("data-party-id-hash", e.partyIdHash));
                    if (e.webAuthnLoginContext && login.webAuthnLogin && !e.verification) {
                        pwFpLoginEvents(e), login.webAuthnLogin(e);
                        if (!i) return;
                        document.body.setAttribute("data-web-authn-login-context", e.webAuthnLoginContext), login.utils.addHiddenElement("webAuthnLoginContext", e.webAuthnLoginContext, document.querySelector("form[name=login]")), e.wanSupportLookup && document.body.setAttribute("data-web-authn-support-lookup", "true"), r && $(r).addClass("errorMessageFp"), e.isRtl ? n && $(n).addClass("rtlFpPlaceholder") : n && $(n).removeClass("rtlFpPlaceholder")
                    }(!e.webAuthnLoginContext || !login.webAuthnLogin) && t && !$(t).hasClass("hide") && (t && $(t).addClass("hide"), r && $(r).removeClass("errorMessageFp"), n && $(n).removeClass("rtlFpPlaceholder"))
                }

                function n(e) {
                    var t = document.querySelector("#email"),
                        n = document.querySelector('label[for="email"]'),
                        r = document.querySelector("#phone"),
                        i = document.querySelector("#isTpdOnboarded"),
                        s = document.querySelector(".countryPhoneSelectWrapper"),
                        o = document.querySelector("#login_emaildiv"),
                        u = document.querySelector(".profileRememberedEmail");
                    e.profile || (t && t.removeAttribute("disabled"), r && r.removeAttribute("disabled")), s && $(s).addClass("hide"), o && $(o).removeClass("phoneInputWrapper"), !e.profile && u && $(u).removeClass("cookiedProfile"), !e.phone && r ? r.value = null : e.phone && t && (t.value = null), e.notifications && e.hybridInEmailOnlyMode && e.contextualLogin && e.contextualLogin.content && (t && $(t).attr("placeholder", e.contextualLogin.content.emailLabel), n && $(n).text(e.contextualLogin.content.emailLabel), t && $(t).attr("data-hybrid-in-email-only-mode", e.hybridInEmailOnlyMode)), i && e.profile && e.isTpdOnboarded && (i.value = e.isTpdOnboarded)
                }

                function r(e) {
                    var t = document.querySelector("#splitEmail"),
                        n = document.querySelector("#splitEmailSection"),
                        r = document.querySelector("#splitPhoneSection"),
                        i = document.querySelector("#rememberProfileEmail"),
                        s = document.querySelector("#email"),
                        o = document.querySelector("#phone"),
                        u = document.querySelector(".forgotLink"),
                        a = document.querySelector(".forgotLink .bubble-tooltip"),
                        f = document.querySelector(".actions"),
                        l = document.querySelector("#loginWithPhoneOption"),
                        c = document.querySelector("#loginWithEmailOption"),
                        h = $("body").data("phonePasswordEnabled"),
                        p = $("body").data("phonePinEnabled"),
                        v = document.querySelector("#signUpLinkOnEmail"),
                        m = document.querySelector("#signUpLinkOnPassword");
                    e.splitLoginContext === "inputEmail" || e.splitLoginContext === "inputPhone" ? (t && $(t).removeClass("hide"), i && typeof e.rememberProfile != "undefined" && (i.checked = e.rememberProfile === "true" || e.rememberProfile === !0), d(), v && $(v).removeClass("hide"), m && $(m).addClass("hide")) : (e.tpdVariant !== "autoSend" && t && $(t).addClass("hide"), o && o.blur(), s && s.blur()), n && e.splitLoginContext === "inputEmail" && ($(n).removeClass("hide"), s.removeAttribute("disabled"), p || h ? (l && $(l).removeClass("hide"), c && $(c).addClass("hide"), u && $(u).addClass("hide"), a && $(a).addClass("hide")) : u && $(u).removeClass("hide"), $(f).removeClass("phonePresent"), r && $(r).addClass("hide"), o && (o.value = "", o.setAttribute("disabled", "disabled")));
                    if (r && e.splitLoginContext === "inputPhone") {
                        n && $(n).addClass("hide"), $(r).removeClass("hide");
                        if (p || h) l && $(l).addClass("hide"), c && $(c).removeClass("hide")
                    }
                }

                function i(e) {
                    if (!e.enableSmartlock) return;
                    login.smartLock(e)
                }

                function s(e) {
                    e = e || {};
                    var t = e.appleIdpJson;
                    if (typeof t != "string" || typeof login.siapple != "function") return;
                    return login.siapple({
                        appleIdpJson: t
                    })
                }

                function o(e) {
                    var t = document.querySelector(".educationMessage");
                    e.showEducationMessage === !0 && e.splitLoginContext === "inputPin" ? t && $(t).removeClass("hide") : t && $(t).addClass("hide")
                }

                function u(e) {
                    var t = document.querySelector("#splitPassword"),
                        n = document.querySelector("#splitPasswordSection"),
                        r = document.querySelector("#splitPinSection"),
                        o = document.querySelector("#password"),
                        u = document.querySelector("#pin"),
                        a = document.querySelector("#rememberProfilePassword"),
                        f = document.querySelector(".forgotLink"),
                        l = document.querySelector("#phone"),
                        c = document.querySelector("#signUpLinkOnEmail"),
                        h = document.querySelector("#signUpLinkOnPassword"),
                        p = document.querySelector('#splitEmail input[type="password"]');
                    p && p.value.trim() && (o.value = p.value, p.value = ""), e.splitLoginContext === "inputPassword" || e.splitLoginContext === "inputPin" ? (t && e.tpdVariant !== "autoSend" && $(t).removeClass("hide"), s(e), i(e), a && (a.checked = e.rememberProfile === "true" || e.rememberProfile === !0), e.splitLoginContext === "inputPassword" && !e.tpdVariant && f && $(f).removeClass("hide"), typeof e.appleIdpJson == "string" && login.utils.addHiddenElement("appleIdpJson", e.appleIdpJson, document.querySelector("form[name=login]")), $(o).attr("disabled") === "disabled" && o.removeAttribute("disabled"), e.smartlockStatus !== "linked" && !e.verification && v(e), c && $(c).addClass("hide"), h && $(h).removeClass("hide"), window.dispatchEvent && window.dispatchEvent(createNewEvent("resize"))) : (t && $(t).addClass("hide"), o.value = "", u && (u.value = "")), n && e.splitLoginContext === "inputPassword" && (r && $(r).addClass("hide"), $(n).removeClass("hide")), r && e.splitLoginContext === "inputPin" && ($(n).addClass("hide"), $(r).removeClass("hide")), e.profile && e.profile.phone && l && (l.value = e.profile.phone), $("body").hasClass("desktop") && o.focus()
                }

                function a(e) {
                    var t = document.querySelector("input[name=splitLoginContext]"),
                        n = document.querySelector(".profileDisplayEmail"),
                        r = document.querySelector(".profileDisplayName"),
                        i = document.querySelector(".profileRememberedEmail"),
                        s = document.querySelector(".profileIcon"),
                        o = document.querySelector("#email"),
                        u = document.querySelector(".profileDisplayPhoneCode"),
                        a;
                    if (e.tpdVariant === "autoSend") return;
                    if (!e.profile) {
                        s && ($(s).addClass("hide"), $(s).text(""), s.removeAttribute("style"), $(s).removeClass("profilePhoto"), $(s).removeClass("profileInitials"), $(s).addClass("profilePlaceHolderImg")), n && $(n).text(""), u && $(u).text(""), r && $(r).addClass("hide"), o.value = "", i && $(i).addClass("hide"), window.dispatchEvent && window.dispatchEvent(createNewEvent("resize"));
                        return
                    }
                    a = e.profile.phone || e.profile.email, a && e.splitLoginContext !== "inputEmail" && e.splitLoginContext !== "inputPhone" && (n && $(n).text(a), i && $(i).removeClass("hide")), e.profile.phoneCode && u && $(u).text(e.profile.phoneCode)
                }

                function f(e) {
                    function t(e, t) {
                        var n = login.utils.getQueryParamFromUrl("ulPage", e);
                        return n ? login.utils.updateParamValue(e, "ulPage", t) : e
                    }
                    var n = $(document.querySelector("#signupContainer")),
                        r = e.splitLoginContext === "inputEmail" || e.splitLoginContext === "inputPhone",
                        i, s, o, u;
                    if (!n) return;
                    o = $(signupContainer.querySelector("#createAccount")), i = n.data("hideOnEmail") === "true", s = n.data("hideOnPass") === "true", u = o && o.attr("href"), r ? (i ? n.addClass("hide") : n.removeClass("hide"), o && o.attr("href", t(u, "email"))) : (s ? n.addClass("hide") : n.removeClass("hide"), o && o.attr("href", t(u, "pwd")))
                }

                function l(e) {
                    var t = document.querySelector("footer"),
                        n = document.querySelector("#login"),
                        r = document.querySelector("#login .contentContainer"),
                        i = document.querySelector("#verification .contentContainer"),
                        s = document.querySelector("#verification"),
                        o;
                    e.verification ? (o = document.querySelector(".activeContent"), $(n).addClass("hide"), $(s) && $(s).removeClass("hide"), $(t).addClass("footerWithIcon"), $(o).removeClass("activeContent"), $(i) && $(i).addClass("activeContent"), c(e.verification), login.tpdLogin && login.tpdLogin.instrumentVerificationViewRendered()) : (o = document.querySelector(".activeContent"), $(n).removeClass("hide"), $(s) && $(s).addClass("hide"), $(t).removeClass("footerWithIcon"), $(o).removeClass("activeContent"), $(r).addClass("activeContent"))
                }

                function c(e) {
                    if (!e) return;
                    var t = document.querySelector(".account"),
                        n = document.querySelector(".mobileNotification .pin"),
                        r = document.querySelector(".twoDigitPin"),
                        i = document.querySelector("#uncookiedMessage"),
                        s = document.querySelector("#cookiedMessage");
                    $(t).text(e.email), e.pin && n ? ($(n).text(e.pin), $(r).text(e.pin), r.setAttribute("style", "font-weight: bold"), $(i).removeClass("hide")) : $(s).removeClass("hide")
                }

                function h(e) {
                    var t = document.querySelectorAll(".notifications");
                    for (var n = 0; n < t.length; n++) $(t[n]).text(""), e.notifications && e.notifications.msg && (t[n].innerHTML = '<p class="notification ' + e.notifications.type + '" role="alert">' + e.notifications.msg + "</p>")
                }

                function p(e) {
                    var t = document.querySelector("#emailSubTagLine"),
                        n = document.querySelector("#phoneSubTagLine"),
                        r = document.querySelector("#pwdSubTagLine");
                    e.splitLoginContext === "inputPassword" || e.splitLoginContext === "inputPin" ? (t && $(t).addClass("hide"), n && $(n).addClass("hide"), r && $(r).removeClass("hide")) : e.splitLoginContext === "inputPhone" ? (n && $(n).removeClass("hide"), t && $(t).addClass("hide"), r && $(r).addClass("hide")) : (t && $(t).removeClass("hide"), n && $(n).addClass("hide"), r && $(r).addClass("hide"))
                }

                function d() {
                    var e = login.utils.isHybridLoginExperience();
                    login.logger.log({
                        evt: "state_name",
                        data: e ? "begin_hybrid_login" : "begin_email",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: e ? "prepare_hybrid" : "prepare_email",
                        instrument: !0
                    }), login.logger.log({
                        evt: "is_cookied",
                        data: "N",
                        instrument: !0
                    }), login.logger.pushLogs()
                }

                function v(e) {
                    var t = document.querySelector("#password"),
                        n = document.querySelector("#phone"),
                        r = login.utils.isFieldPrefilled(t),
                        i = login.utils.isHybridLoginExperience(),
                        s = i ? "prepare_hybrid_pwd" : "prepare_pwd";
                    s += login.utils.getKmliCb() ? "_ot" : "", document.querySelector("#moreOptionsContainer") && e.moreOptions === !0 && (s += "_more_opt", login.logger.log({
                        evt: "exp_shown",
                        data: "tpd",
                        instrument: !0
                    })), login.logger.log({
                        evt: "state_name",
                        data: i ? "begin_hybrid_pwd" : "begin_pwd",
                        instrument: !0
                    }), login.logger.log({
                        evt: "pub_cred_type",
                        data: n && n.value ? "phone" : "email",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: s,
                        instrument: !0
                    }), login.logger.log({
                        evt: "is_cookied",
                        data: "Y",
                        instrument: !0
                    }), login.logger.log({
                        evt: "autofill",
                        data: r ? "Y" : "N",
                        instrument: !0
                    }), login.logger.pushLogs()
                }

                function m(e) {
                    function n(e) {
                        var t = document.querySelectorAll(".captcha-container");
                        for (var n = 0; n < t.length; n++) e ? $(t[n]).removeClass("hide") : $(t[n]).addClass("hide")
                    }
                    var t;
                    n(e.captcha);
                    if (!e.captcha) return;
                    t = login.utils.getActiveCaptchaElement({
                        value: e.splitLoginContext
                    });
                    if (!t) return;
                    e.captcha.captchaImgUrl && t.image && t.image.setAttribute("src", e.captcha.captchaImgUrl), e.captcha.captchaAudioUrl && t.audioTag && t.audioTag.setAttribute("src", e.captcha.captchaAudioUrl), e.captcha.captchaAudioUrl && t.audioLink && t.audioLink.setAttribute("href", e.captcha.captchaAudioUrl)
                }

                function g(e) {
                    if (!e.adsChallengeVerified) return;
                    $("#login").removeClass("hide"), document.getElementById("ads-container") && (document.getElementById("ads-container").style.display = "none")
                }
                return login.storeInstance = login.store(), login.pubsub.subscribe("STATE_UPDATED", e), {
                    render: e,
                    updateNotificationView: h
                }
            }(),
            function() {
                typeof Object.assign != "function" && (Object.assign = function(e, t) {
                    if (e === null) throw new TypeError("Cannot convert undefined or null to object");
                    var n = Object(e);
                    for (var r = 1; r < arguments.length; r++) {
                        var i = arguments[r];
                        if (i !== null)
                            for (var s in i) Object.prototype.hasOwnProperty.call(i, s) && (n[s] = i[s])
                    }
                    return n
                }), String.prototype.trim || (String.prototype.trim = function() {
                    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
                })
            }(), login.fn = function() {
                function t(t) {
                    var n = document.getElementById("fconfig");
                    n && n.parentNode && n.parentNode.removeChild(n), n = document.createElement("script"), n.id = "fconfig", n.type = "application/json", n.setAttribute("fncls", e), n.setAttribute("nonce", $("body").data("nonce"));
                    var r = {
                        f: t.fnSessionId,
                        s: t.sourceId,
                        b: t.beaconUrl,
                        ts: {
                            type: "UL",
                            fields: [{
                                id: "email",
                                min: 6
                            }, {
                                id: "password",
                                min: 6
                            }],
                            delegate: !1
                        }
                    };
                    n.text = JSON.stringify(r), document.body.appendChild(n)
                }

                function n(e) {
                    var t = document.createElement("script");
                    t.src = e.fnUrl, t.onload = function() {
                        r(e)
                    }, document.body.appendChild(t)
                }

                function r(e) {
                    e.enableSpeedTyping && typeof initTsFb == "function" && initTsFb({
                        detail: {
                            type: "UL",
                            fields: ["email", "password"]
                        }
                    })
                }

                function i(e) {
                    PAYPAL.syncData && typeof PAYPAL.syncData.initSync == "function" && e && (e.detail = {
                        type: "UL",
                        fields: ["email", "password"]
                    }, PAYPAL.syncData.initSync(e))
                }

                function s() {
                    if (PAYPAL.syncData && typeof PAYPAL.syncData.flushData == "function") try {
                        PAYPAL.syncData.flushData()
                    } catch (e) {}
                }

                function o(e) {
                    e && e.sourceId && typeof PAYPAL.ulSync == "object" && (PAYPAL.ulSync.sourceId = e.sourceId, i(PAYPAL.ulSync))
                }

                function u() {
                    var e = $("body").data("enableFnBeaconOnWebViews");
                    return !e && /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(window.navigator.userAgent) ? !1 : !0
                }

                function a() {
                    u() && PAYPAL && PAYPAL.ulData && PAYPAL.ulData.fnUrl && (t(PAYPAL.ulData), n(PAYPAL.ulData)), i(PAYPAL.ulSync)
                }
                var e = "fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99";
                return {
                    initialize: a,
                    initializeFnSync: i,
                    addFnSyncData: s,
                    updateFnSyncContext: o
                }
            }(), login.verification = function() {
                function A(e) {
                    login.utils.updateView({
                        splitLoginContext: "inputPassword",
                        profile: {
                            email: h
                        },
                        verification: null,
                        notifications: e.notifications
                    })
                }

                function O() {
                    var e, t = document.querySelector("#expired .slimP");
                    t && t.textContent && (e = {
                        msg: t && t.textContent,
                        type: "notification-warning"
                    }), login.utils.updateView({
                        splitLoginContext: "inputPassword",
                        profile: {
                            email: h
                        },
                        tpdVariant: N,
                        verification: null,
                        ulSync: _("inputPassword"),
                        notifications: e
                    })
                }

                function M() {
                    if (PAYPAL.syncData && typeof PAYPAL.syncData.data == "object") return JSON.stringify(PAYPAL.syncData.data)
                }

                function _(e) {
                    var t = PAYPAL.ulSync && PAYPAL.ulSync.sourceId || "",
                        n = t.indexOf("REMEMBERED") !== -1 ? "_REMEMBERED" : "",
                        r = {
                            inputPassword: "UNIFIED_LOGIN_INPUT_PASSWORD"
                        };
                    return {
                        sourceId: r[e] + n
                    }
                }

                function D() {
                    var e = login.storeInstance.getState().model.rememberProfile,
                        t = {
                            _csrf: o.value,
                            intent: "completeLogin",
                            accessToken: l,
                            "locale.x": u.value,
                            rememberProfile: e === "true" || e === !0,
                            login_email: h,
                            flowId: login.utils.getFlowId(),
                            tpdVariant: N,
                            tpdTriggerMethod: k
                        },
                        n = M();
                    n && (t.fn_sync_data = n), login.utils.getCtxId() && (t.ctxId = login.utils.getCtxId()), $.ajax({
                        url: "/signin/challenge/push?intent=" + login.utils.getIntent(),
                        type: "POST",
                        data: t,
                        success: function(e) {
                            if (e && e.pollStatus === "LoggedIn" && e.returnUrl) return window.location.href = e.returnUrl;
                            if (e && e.pollStatus === "Failed") return A(e);
                            O(), login.tpdLogin.instrumentTpdExpired("NO_RESPONSE")
                        }
                    })
                }

                function P() {
                    if (!f) return;
                    if (t >= e) {
                        O(), login.tpdLogin.instrumentTpdExpired("NO_ACTION");
                        return
                    }
                    t++, a = $.ajax({
                        url: "/signin/challenge/push",
                        type: "POST",
                        data: {
                            _csrf: o.value,
                            intent: "poll",
                            accessToken: l,
                            authflowDocumentId: c,
                            retryCount: t,
                            "locale.x": u.value,
                            flowId: login.utils.getFlowId(),
                            tpdVariant: N,
                            tpdTriggerMethod: k
                        },
                        success: L,
                        fail: function() {
                            f && P()
                        }
                    })
                }

                function H(e) {
                    e.preventDefault(), $(S).removeClass("hide")
                }

                function B(e) {
                    var n = document.querySelector("form[name=login]"),
                        r;
                    e = e || {}, f = !0, l = e.accessToken || l, c = e.authflowDocumentId || c, h = e.email || h, t = 0, N = e.variant || N, k = e.tpdTriggerMethod || k, P(), r = document.querySelector("[name=authdocId]"), r ? r.setAttribute("value", c) : login.utils.addHiddenElement("authdocId", c, n)
                }

                function j() {
                    window.location.href = window.location.href
                }

                function F(e) {
                    var t = getEventTarget(e);
                    if (!S) return;
                    if ($(t).hasClass("showSurvey")) return;
                    $(S).addClass("hide")
                }

                function I(e) {
                    var t = getEventTarget(e),
                        n = $(t).data("reason");
                    e.preventDefault(), $(w).addClass("hide"), $(w).removeClass("greyOut"), q(), login.tpdLogin.instrumentUsePasswordInstead(n), p && $(p).addClass("hide"), T && $(T).removeClass("hide")
                }

                function q() {
                    f = !1, a && a.abort()
                }

                function R() {
                    s = 0, setTimeout(function() {
                        $(w).removeClass("hide")
                    }, n)
                }

                function U(e) {
                    e.preventDefault();
                    if ($(e.target).hasClass("greyOut")) return;
                    login.tpdLogin.instrumentResendClicked(), q(), t = 0, $(w).addClass("greyOut"), s++, $.ajax({
                        url: "/signin/challenge/push",
                        type: "POST",
                        data: {
                            _csrf: o.value,
                            intent: "resend",
                            accessToken: l,
                            authflowDocumentId: c,
                            "locale.x": u.value,
                            flowId: login.utils.getFlowId(),
                            tpdVariant: N,
                            tpdTriggerMethod: k
                        },
                        success: function(t) {
                            if (t && t.resendStatus === "Success") {
                                B({
                                    accessToken: l,
                                    authflowDocumentId: c,
                                    email: h
                                }), $(w).addClass("hide"), $(E).removeClass("hide"), setTimeout(function() {
                                    $(E).addClass("hide"), s < i && ($(w).removeClass("hide"), $(w).removeClass("greyOut"))
                                }, r);
                                return
                            }
                            t && t.notifications && login.view.updateNotificationView(t)
                        },
                        fail: function() {}
                    })
                }

                function z(e) {
                    var t = document.querySelector("#moreOptionsContainer"),
                        n = document.querySelector("#tpdButtonContainer"),
                        r = document.querySelector('input[name="tpdEligible"]'),
                        i = document.querySelector("form[name=login]"),
                        s, o = document.querySelector("#btnNext");
                    if (!e || !n || !t) return;
                    if (e.tpdVariant || e.tpdAutoSend) r ? r.value = "true" : (s = document.createElement("input"), s.setAttribute("type", "hidden"), s.setAttribute("name", "tpdEligible"), s.setAttribute("value", "true"), $(i).append(s));
                    e.tpdVariant === "moreOptions" && ($(t).removeClass("hide"), $(".forgotLink").addClass("hide")), e.tpdVariant === "tpdButton" && ($(t).addClass("hide"), $(n).removeClass("hide"), $(".forgotLink").removeClass("hide"), $("#signupContainer").addClass("hide")), e.tpdAutoSend && (login.tpdLogin && login.tpdLogin.instrumentTpdLoginAutoTriggered(), login.tpdLogin && login.tpdLogin.attemptTpdLogin("autoSend")), e.splitLoginContext === "inputEmail" && ($(t).addClass("hide"), $(n).addClass("hide"), r && r.value === "true" && (r.value = ""));
                    if (login.utils.isTpdDemo() && e.splitLoginContext !== "inputEmail") {
                        var u = document.querySelector("#splitPassword");
                        o && $(o).addClass("hide"), u && $(u).removeClass("hide")
                    } else o && $(o).removeClass("hide")
                }
                var e = 9,
                    t = 0,
                    n = 5e3,
                    r = 3e3,
                    i = 3,
                    s = 0,
                    o = document.querySelector("input[name=_csrf]"),
                    u = document.querySelector('input[name="locale.x"]'),
                    a, f = !1,
                    l, c, h, p = document.querySelector("#verification"),
                    d = document.querySelector(".verificationSubSection"),
                    v = document.querySelector("#expired"),
                    m = document.querySelector("#denied"),
                    g = document.querySelector("#expiredTryAgainButton"),
                    y = document.querySelector("#pendingNotYouLink"),
                    b = document.querySelector("#pending #tryPasswordLink"),
                    w = document.querySelector("#resend"),
                    E = document.querySelector(".sentMessage"),
                    S = document.querySelector("#passwordInsteadDropDown"),
                    x = document.querySelector("#passwordInsteadGroup"),
                    T = document.querySelector("#login"),
                    N, C, k, L = function(e) {
                        e || P(), o.value = e._csrf || o.value;
                        switch (e.pollStatus) {
                            case "Accepted":
                                q(), C = C ? !1 : e.pollStatus === "Accepted", C && (login.logger.log({
                                    evt: "TPD_CLIENT",
                                    data: "Approved_" + e.tpdTriggerMethod,
                                    calEvent: !0
                                }), login.logger.pushLogs()), D();
                                break;
                            case "Downgraded":
                                P();
                                break;
                            case "Denied":
                                q(), $(d).addClass("hide"), $(m).removeClass("hide");
                                break;
                            case "Failed":
                                q(), A(e);
                                break;
                            default:
                                e.errorView ? (O(), login.tpdLogin.instrumentTpdExpired("RCS_SERVICE_ERROR")) : P()
                        }
                    };
                return g && (g.onclick = j), y && (y.onclick = function(e) {
                    q(), login.tpdLogin.instrumentNotYouClicked(), login.utils.notYouClickHandler(e)
                }), login.pubsub && login.pubsub.subscribe("WINDOW_CLICK", F), b && $(b).hasClass("showSurvey") ? (addEvent(b, "click", H), addEvent(x, "click", I)) : b && addEvent(b, "click", I), addEvent(w, "click", U), {
                    startPolling: B,
                    showResendLink: R,
                    updateView: z
                }
            }(), login.overlayUtils = function() {
                function t(t) {
                    eventPreventDefault(t), clearTimeout(e);
                    var n = document.getElementById("overlaySpinner"),
                        r = document.getElementById("overlaySpinnerSuccess"),
                        i = $("body").data("return-url") || "/signin",
                        o = document.getElementById("overlayOptIn");
                    o.disabled = !0, $(r).removeClass("hide"), $(n).addClass("hide"), setTimeout(function() {
                        s()
                    }, 1300);
                    var u;
                    $.ajax({
                        type: "POST",
                        url: "/signin/provisionCapabilities/oneTouch",
                        data: {
                            flowId: login.utils.getFlowId(),
                            optInSource: login.utils.getIntent() === "signin" ? "overlay_dl" : "overlay_xo",
                            _csrf: document.querySelector("#token").value
                        },
                        dataType: "json",
                        complete: function() {
                            u = setInterval(function() {
                                if ($(overlayMask).hasClass("hide")) return clearInterval(u), login.logger.log({
                                    evt: "ONETOUCH",
                                    data: "REDIRECT_AFTER_ACTIVATION_RESPONSE_" + login.utils.getIntent().toUpperCase(),
                                    calEvent: !0
                                }), login.logger.pushLogs(), window.location.href = i
                            }, 100)
                        }
                    }), login.logger.log({
                        evt: "flow_type",
                        data: "onetouch",
                        instrument: !0
                    }), login.logger.log({
                        evt: "actiontype",
                        data: "turn_on",
                        instrument: !0
                    }), login.logger.log({
                        evt: "state_name",
                        data: "overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "ONETOUCH",
                        data: "CLICK_OPT_IN_BUTTON_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs(), setTimeout(function() {
                        return login.logger.log({
                            evt: "ONETOUCH",
                            data: "REDIRECT_WITHOUT_ACTIVATION_RESPONSE_" + login.utils.getIntent().toUpperCase(),
                            calEvent: !0
                        }), login.logger.pushLogs(), clearInterval(u), window.location.href = i
                    }, 1e4)
                }

                function n(t) {
                    function o(e) {
                        e = e || 0, setTimeout(function() {
                            window.location.href = i || "/signin"
                        }, e)
                    }
                    eventPreventDefault(t), clearTimeout(e);
                    var n = {
                            evt: "state_name",
                            data: "FINGERPRINT_OPTIN",
                            instrument: !0
                        },
                        r = "WEBAUTH_N_CLIENT",
                        i = $("body").data("return-url");
                    login.logger.log({
                        evt: "flow_type",
                        data: "webauthn",
                        instrument: !0
                    }), login.logger.log({
                        evt: "actiontype",
                        data: "turn_on",
                        instrument: !0
                    }), login.logger.log({
                        evt: "state_name",
                        data: "overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "WEBAUTH_N_CLIENT",
                        data: "PROCESS_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs(), s(), login.webAuthnOptInXHR().then(function() {
                        login.logger.clientLog([n, {
                            evt: "transition_name",
                            data: "process_consent_XHR",
                            instrument: !0
                        }, {
                            evt: r,
                            data: "BIND_SUCCESS_XHR_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                            calEvent: !0
                        }], function() {
                            return o()
                        })
                    }).catch(function() {
                        login.logger.clientLog([n, {
                            evt: "transition_name",
                            data: "process_error_XHR",
                            instrument: !0
                        }, {
                            evt: r,
                            data: "BIND_FAIL_XHR_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                            calEvent: !0,
                            status: "ERROR"
                        }], function() {
                            return o()
                        })
                    })
                }

                function r(e) {
                    if ($("body").data("overlay-variant") === "oneTouch") return t(e);
                    if ($("body").data("overlay-variant") === "webAuthn") return n(e)
                }

                function i() {
                    login.logger.log({
                        evt: "actiontype",
                        data: "close_button",
                        instrument: !0
                    }), login.logger.log({
                        evt: "flow_type",
                        data: $("body").data("overlay-variant").toLowerCase(),
                        instrument: !0
                    }), login.logger.log({
                        evt: "state_name",
                        data: "overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: l(),
                        data: "CLICK_CLOSE_BUTTON_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs();
                    var e = $("body").data("return-url"),
                        t = document.getElementById("overlayContainer"),
                        n = document.getElementById("overlayMask");
                    $(t).removeClass("overlaySlideDown"), $(t).addClass("overlaySlideUp"), setTimeout(function() {
                        return $(n).addClass("hide"), window.location.href = e || "/signin"
                    }, 250)
                }

                function s() {
                    var e = document.getElementById("overlayContainer"),
                        t = document.getElementById("overlayMask");
                    $(e).removeClass("overlaySlideDown"), $(e).addClass("overlaySlideUp"), setTimeout(function() {
                        $(t).addClass("hide");
                        return
                    }, 250)
                }

                function o() {
                    eventPreventDefault(event), clearTimeout(e);
                    var t = document.getElementById("overlayExpandDetails"),
                        n = document.getElementById("overlayCollapseDetails"),
                        r = document.getElementById("overlayDetails");
                    $(t).toggle(), $(n).toggle(), $(r).hasClass("overlaySlideUp") ? ($(r).removeClass("overlaySlideUp"), $(r).addClass("overlaySlideDown")) : ($(r).removeClass("overlaySlideDown"), $(r).addClass("overlaySlideUp"))
                }

                function u(t) {
                    var n = document.getElementById("overlayOptIn"),
                        s = document.getElementById("overlayExpandDetails"),
                        u = document.getElementById("overlayCollapseDetails"),
                        a = document.getElementById("overlayClose"),
                        f = $("body").data("return-url"),
                        c = t && t.closeOverlayTimeoutValue;
                    n.onclick = r, a.onclick = i, s.onclick = o, u.onclick = o;
                    if (!n.onclick || !a.onclick) return window.location.href = f || "/signin";
                    var h = document.getElementById("email"),
                        p = document.getElementById("password");
                    h && h.blur(), p && p.blur();
                    var d = document.getElementById("overlayContainer"),
                        v = document.getElementById("overlayMask");
                    $(v).removeClass("hide"), $(d).removeClass("overlaySlideUp"), $(d).addClass("overlaySlideDown"), login.logger.log({
                        evt: "flow_type",
                        data: $("body").data("overlay-variant").toLowerCase(),
                        instrument: !0
                    }), login.logger.log({
                        evt: "state_name",
                        data: "overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "prepare_overlay",
                        instrument: !0
                    }), login.logger.log({
                        evt: l(),
                        data: "SHOWN_SUCCESSFULLY_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs(), a.focus(), c && (e = setTimeout(function() {
                        login.logger.log({
                            evt: "flow_type",
                            data: $("body").data("overlay-variant").toLowerCase(),
                            instrument: !0
                        }), login.logger.log({
                            evt: "state_name",
                            data: "overlay",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "timeout_close_overlay",
                            instrument: !0
                        }), login.logger.log({
                            evt: l(),
                            data: "TIMEOUT_CLOSE_OVERLAY_AND_REDIRECT_" + login.utils.getIntent().toUpperCase(),
                            calEvent: !0
                        }), login.logger.pushLogs();
                        var e = document.getElementById("overlayContainer"),
                            t = document.getElementById("overlayMask");
                        $(e).removeClass("overlaySlideDown"), $(e).addClass("overlaySlideUp"), setTimeout(function() {
                            return $(t).addClass("hide"), window.location.href = f || "/signin"
                        }, 250)
                    }, c))
                }

                function a(e) {
                    var t = $("body").data("overlay-variant") || "unknown",
                        n = t === "oneTouch" && e && e.oneTouchOverlayPostOptinEligible,
                        r = t === "webAuthn" && e && e.webAuthnOverlayPostOptinEligible,
                        i = !!document.getElementById("overlay");
                    return (n || r) && !i && (login.logger.log({
                        evt: l(),
                        data: "NOT_SHOWN_SINCE_TEMPLATE_NOT_LOADED_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs()), (n || r) && i
                }

                function f() {
                    var e = $("body").data("overlay-variant") || "unknown";
                    return e === "webAuthn" || e === "oneTouch" ? (login.logger.log({
                        evt: l(),
                        data: "XHR_LOGIN_ELIGIBLE_OVERLAY_" + login.utils.getIntent().toUpperCase(),
                        calEvent: !0
                    }), login.logger.pushLogs(), !0) : !1
                }

                function l() {
                    var e = $("body").data("overlay-variant") || "unknown",
                        t = "";
                    switch (e) {
                        case "webAuthn":
                            t = "WEBAUTH_N_CLIENT";
                            break;
                        case "oneTouch":
                            t = "ONETOUCH";
                            break;
                        default:
                            t = "UNIFIED_LOGIN"
                    }
                    return t
                }
                var e;
                return {
                    showOverlay: u,
                    isEligibleToShowOverlay: a,
                    isLoginXHREligbleForOverlay: f
                }
            }(), login.core = function() {
                return function() {
                    function R(e) {
                        var t = getEventTarget(e);
                        if (!P || !e || !t) return;
                        if ($(t).hasClass("moreOptionsInfo")) {
                            eventPreventDefault(e), $(P).hasClass("hide") && (login.logger.log({
                                evt: "state_name",
                                data: B ? "begin_hybrid_pwd" : "begin_pwd",
                                instrument: !0
                            }), login.logger.log({
                                evt: "transition_name",
                                data: B ? "process_hybrid_pwd_more_opt" : "process_pwd_more_opt",
                                instrument: !0
                            }), login.logger.log({
                                evt: "TPD_CLIENT",
                                data: "CLICKED_MORE_OPTIONS",
                                calEvent: !0
                            }), login.logger.pushLogs()), $(P).removeClass("hide");
                            return
                        }
                        $(P).addClass("hide")
                    }

                    function U(e) {
                        var t = getEventTarget(e);
                        if (!F || !e || !t) return;
                        $(F).addClass("hide")
                    }

                    function z(e) {
                        if (!a) return e;
                        var t = a.container.querySelector(".phoneCode"),
                            n = t && $(t).text(),
                            r = e.lastIndexOf(n, 0) === 0;
                        return r ? e.substr(n.length) : e
                    }

                    function W(e) {
                        if (c && c.value === "inputPassword" && !j) return;
                        var t = c && c.value === "inputEmail";
                        !j && t && lt === "phone" && (lt = "email"), login.utils.doesItLookLikeEmail(e) ? lt !== "email" && (!j && c.setAttribute("value", "inputEmail"), lt = "email", $(N) && $(N).addClass("hide"), $(s.container).removeClass("phoneInputWrapper")) : (f.field.value = e, lt !== "phone" && (!j && c.setAttribute("value", "inputPhone"), lt = "phone", $(N).removeClass("hide"), $(s.container).addClass("phoneInputWrapper")))
                    }

                    function X() {
                        f.field.value = null, s.field.value = null, o && $(o).addClass("hide");
                        var e = login.storeInstance.getState().model,
                            t = e && e.contextualLogin && e.contextualLogin.content && e.contextualLogin.content.emailOrPhoneLabel;
                        $(s.field).attr("placeholder", t), $(s.label).text(t), s.field.removeAttribute("data-hybrid-in-email-only-mode")
                    }

                    function V(e) {
                        var t = getEventTarget(e),
                            n = s.field && $(s.field).attr("data-hybrid-in-email-only-mode") === "true";
                        n && lt !== "email" && (lt = "email");
                        if (!t || n) return;
                        login.pubsub.publish("CLEAR_OTP_LOGIN_CONTEXT"), W(t.value)
                    }

                    function J() {
                        j && s.field && (login.logger.log({
                            evt: "state_name",
                            data: "cookied_user_change_email",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "cookied_user_change_email",
                            instrument: !0
                        }), login.logger.pushLogs(), s.field.removeEventListener("input", J))
                    }

                    function ct(e) {
                        if (!e || typeof e != "string") return;
                        return e.replace(Z, "")
                    }

                    function ht(e) {
                        return e.field ? ct(e.field.value) ? !0 : (yt(e), bt(e), !1) : !0
                    }

                    function pt(e) {
                        var t = e && e.field && e.field.value;
                        return !e || !e.field || e.field.hasAttribute("disabled") ? !0 : t ? (t = t && t.replace(it, ""), !t || t.match(tt) ? (yt(e), wt(e), St(e), !1) : !0) : (yt(e), bt(e), xt(e), !1)
                    }

                    function dt(e) {
                        var t = e && e.field && ct(e.field.value);
                        return e && e.field && e.field.hasAttribute("disabled") ? !0 : t ? t === rt ? !0 : t && t.match(nt) ? (yt(e), wt(e), !1) : !0 : (yt(e), bt(e), !1)
                    }

                    function vt(e, t) {
                        var n, r, i = !0,
                            s = login.utils.getActiveCaptchaElement(c);
                        return n = ht(e), n ? (r = ht(t), r ? (s && s.field && (i = ht(s)), i ? !0 : !1) : !1) : !1
                    }

                    function mt(e) {
                        if (e.value === "inputEmail") return document.querySelector("#rememberProfileEmail");
                        if (e.value === "inputPassword") return document.querySelector("#rememberProfilePassword");
                        return
                    }

                    function gt(e) {
                        var t = e.field.value.replace(Z, "");
                        return t === rt ? !0 : !t.match(et) && !e.field.hasAttribute("disabled") ? (yt(e), wt(e), !1) : !0
                    }

                    function yt(e) {
                        $(e.container).addClass("hasError"), e.container.style["z-index"] = 100, $(e.errMsgContainer).addClass("show"), e.field.focus()
                    }

                    function bt(e) {
                        $(e.errMsg).removeClass("hide")
                    }

                    function wt(e) {
                        $(e.invalidMsg).removeClass("hide")
                    }

                    function Et(e, t) {
                        t && $(e.container).removeClass("hasError"), e.container.style["z-index"] = 1, $(e.errMsgContainer).removeClass("show")
                    }

                    function St(e) {
                        $(e.errMsg).addClass("hide")
                    }

                    function xt(e) {
                        $(e.invalidMsg).addClass("hide")
                    }

                    function Tt() {
                        var e, t = /\&passwordRecoveryByPhoneEnabled\=true/;
                        if (M)
                            for (var n = 0; n < M.length; n++) e = M[n].getAttribute("href").replace(t, ""), M[n].setAttribute("href", e);
                        _ && _.setAttribute("data-src", _.getAttribute("data-src").replace(t, ""))
                    }

                    function Nt() {
                        var e;
                        if (M)
                            for (var t = 0; t < M.length; t++) e = M[t].getAttribute("href") + "&passwordRecoveryByPhoneEnabled=true", M[t].setAttribute("href", e);
                        _ && _.setAttribute("data-src", _.getAttribute("data-src") + "&passwordRecoveryByPhoneEnabled=true")
                    }

                    function Ct() {
                        var e = document.querySelector('input[name="splitLoginContext"]'),
                            t = document.querySelector('input[name="splitLoginCookiedFallback"]');
                        $(m).removeClass("hide"), $(g).addClass("hide"), k && $(k).addClass("hide"), s.field && s.field.removeAttribute("disabled"), u.field && u.field.removeAttribute("disabled"), a.field && a.field.setAttribute("disabled", "disabled"), f.field && f.field.setAttribute("disabled", "disabled"), l.field && l.field.setAttribute("disabled", "disabled"), at || $(O).removeClass("hide"), x && $(x).addClass("hide"), $(v).removeClass("phonePresent"), lt = "email", e && (L && $(L).removeClass("hide"), e.value = "inputEmail", t && (e.value = "inputPassword"))
                    }

                    function kt() {
                        var e = document.querySelector('input[name="splitLoginContext"]');
                        $(g).removeClass("hide"), $(m).addClass("hide"), k && !$(y).hasClass("hide") && $(k).removeClass("hide"), a.field && a.field.removeAttribute("disabled"), f.field && f.field.removeAttribute("disabled"), l.field && l.field.removeAttribute("disabled"), s.field && s.field.setAttribute("disabled", "disabled"), u.field && u.field.setAttribute("disabled", "disabled"), $(O).addClass("hide"), $(v).addClass("phonePresent"), E && $(E).addClass("hide"), lt = "phone", L && $(L).addClass("hide"), e && !at && (e.value = e.value === "inputPassword" ? "inputPin" : "inputPhone")
                    }

                    function Lt() {
                        function i() {
                            var e = n.options[n.selectedIndex].value,
                                t = e.split(" ");
                            return {
                                countryCode: t && (t[0] || ""),
                                phoneCode: t && (t[1] || "")
                            }
                        }
                        var e = a.container.querySelector(".countryCode"),
                            t = a.container.querySelector(".phoneCode"),
                            n = a.field,
                            r;
                        r = i(), $(e).text(r.countryCode), $(t).text(r.phoneCode)
                    }

                    function At() {
                        login.logger.log({
                            evt: "state_name",
                            data: "begin_hybrid_login",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "click_change_country_code",
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function Ot(e) {
                        eventPreventDefault(e);
                        var t = document.querySelector('input[name="splitLoginContext"]'),
                            n = document.querySelector(".countryPhoneSelectWrapper");
                        $(g).removeClass("hide"), $(m).addClass("hide"), $(E).addClass("hide"), $(x).removeClass("hide"), Et(s, !0), a.field && a.field.removeAttribute("disabled"), f.field && f.field.removeAttribute("disabled"), f.field.focus(), L && $(L).addClass("hide"), A && $(A).removeClass("hide"), s.field && (s.field.value = ""), login.view.updateNotificationView({}), s.field && s.field.setAttribute("disabled", "disabled"), t.value = "inputPhone", login.logger.log({
                            evt: "state_name",
                            data: "begin_email",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "prepare_phone",
                            instrument: !0
                        }), login.logger.pushLogs(), login.logger.log({
                            evt: "state_name",
                            data: "begin_phone",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "prepare_phone",
                            instrument: !0
                        }), login.logger.pushLogs(), ft ? (l.field && l.field.removeAttribute("disabled"), u.field && u.field.setAttribute("disabled", "disabled"), lt = "phone", $(v).addClass("phonePresent"), $(O).addClass("hide")) : (u.field && u.field.removeAttribute("disabled"), l.field && l.field.setAttribute("disabled", "disabled"), lt = "phonePassword", n && $(n).removeClass("hide"))
                    }

                    function Mt(e) {
                        eventPreventDefault(e);
                        var t = document.querySelector('input[name="splitLoginContext"]');
                        $(m).removeClass("hide"), $(g).addClass("hide"), $(x).addClass("hide"), $(E).removeClass("hide"), k && $(k).addClass("hide"), Et(f, !0), s.field && s.field.removeAttribute("disabled"), u.field && u.field.removeAttribute("disabled"), s.field.focus(), a.field && a.field.setAttribute("disabled", "disabled"), f.field && f.field.setAttribute("disabled", "disabled"), l.field && l.field.setAttribute("disabled", "disabled"), A && $(A).addClass("hide"), L && $(L).removeClass("hide"), $(v).removeClass("phonePresent"), lt = "email", t.value = "inputEmail", login.logger.log({
                            evt: "state_name",
                            data: "begin_phone",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "prepare_email",
                            instrument: !0
                        }), login.logger.pushLogs(), login.logger.log({
                            evt: "state_name",
                            data: "begin_email",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "prepare_email",
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function _t(e, t) {
                        eventPreventDefault(e), Tt(), lt = "email", login.utils.notYouClickHandler(e, function() {
                            login.logger.log({
                                evt: "state_name",
                                data: "begin_phone_pwd",
                                instrument: !0
                            }), login.logger.log({
                                evt: "transition_name",
                                data: "prepare_email",
                                instrument: !0
                            }), login.logger.pushLogs(), login.logger.log({
                                evt: "state_name",
                                data: "begin_email",
                                instrument: !0
                            }), login.logger.log({
                                evt: "transition_name",
                                data: "prepare_email",
                                instrument: !0
                            }), login.logger.pushLogs(), typeof t == "function" && t()
                        })
                    }

                    function Dt(e) {
                        var t = $("body").data("enableSuppressAutoSubmit") === "true",
                            n = Date.now() - window.formAutofilledAt,
                            r = parseInt($("body").data("suppressAutosubmitTime")) >= n,
                            i = "AUTOSUBMIT",
                            s = document.querySelector('input[name="isKeychainActivationWithEmailTokenOn8ball"]');
                        if (t && n) {
                            login.logger.log({
                                evt: i,
                                data: "PREPARE_SUPPRESS_" + n,
                                calEvent: !0
                            }), login.logger.pushLogs();
                            if (r) {
                                eventPreventDefault(e), delete window.formAutofilledAt;
                                return
                            }
                        }
                        var o = document.querySelector("input[name=splitLoginContext]"),
                            u = document.querySelector("input[name=splitLoginCookiedFallback]"),
                            a = o && o.value || "";
                        u || s ? Wt(e) : a === "inputEmail" || a === "inputPhone" || login.utils.isPrefilledEmailNext() || login.utils.isPrefillEmailEnabled() ? Ht(e) : Wt(e)
                    }

                    function Pt(e) {
                        var t = z(e);
                        f.field.value = t, s.field.value = t
                    }

                    function Ht(e) {
                        var t, n = login.utils.getSplitLoginContext();
                        if (login.utils.isPrefillEmailEnabled() && n.value !== "inputEmail" && login.utils.isTpdDemo()) return eventPreventDefault(e), login.tpdLogin && login.tpdLogin.attemptTpdLogin("autoSend");
                        B ? (lt === "phone" && s.field && Pt(s.field.value), t = lt === "email" ? dt(s) : pt(s)) : t = lt === "email" ? dt(s) : pt(f);
                        var i = document.querySelectorAll("form[name=login] input"),
                            o = {},
                            u = login.utils.getActiveCaptchaElement(c),
                            a = mt(c),
                            l = $("body").data("splitPasswordClientTransition"),
                            p, d, v, m, g = document.querySelector("#phoneCode");
                        st = !0, eventPreventDefault(e), t && $(s.field).hasClass("validate") && n === "inputEmail" && (t = gt(s)), t && u && u.field && (t = ht(u)), t && (n === "inputEmail" || n === "inputPhone") && (login.logger.log({
                            evt: "state_name",
                            data: login.logger.getStateName(),
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "process_next",
                            instrument: !0
                        }), login.logger.pushLogs());
                        if (!t) return;
                        login.utils.showSpinner(), login.fn.addFnSyncData(), (lt === "phonePassword" || lt === "phone") && Nt(), r && $(r).text("");
                        if (!(!l || lt !== "phone" && lt !== "phonePassword")) {
                            p = document.querySelector("#phone"), d = p && p.value.replace(it, ""), v = document.querySelector("#phoneCode"), v = v && v.value.replace(/[A-Z\s]/ig, ""), p.value = d, login.storeInstance.updateModel({
                                splitLoginContext: ft ? "inputPin" : "inputPassword",
                                profile: {
                                    phone: d,
                                    phoneCode: v
                                }
                            }), login.logger.log({
                                evt: "state_name",
                                data: "begin_phone",
                                instrument: !0
                            }), login.logger.log({
                                evt: "transition_name",
                                data: ft ? "prepare_pin" : "prepare_pwd",
                                instrument: !0
                            }), login.logger.pushLogs(), login.utils.hideSpinner(), login.utils.setSliderToPasswordContainer();
                            return
                        }
                        if (l && lt === "email") {
                            login.storeInstance.updateModel({
                                splitLoginContext: "inputPassword",
                                profile: {
                                    email: s && s.field && s.field.value
                                },
                                rememberProfile: a && a.checked
                            }), login.utils.hideSpinner(), login.utils.setSliderToPasswordContainer();
                            return
                        }
                        for (var y = 0; y < i.length; y++) o[i[y].name] = i[y].value;
                        delete o.login_password, delete o.login_pin, o.splitLoginContext === "inputPhone" && g && (o.phoneCode = g.value, delete o.login_email), o.splitLoginContext === "inputEmail" && (delete o.login_phone, delete o.phoneCode), B && (o.splitLoginContext === "inputPassword" && o.login_phone && (o.phoneCode = g.value), o.splitLoginContext === "inputPhone" && s.field ? (s.field.setAttribute("disabled", "disabled"), s.field.value = "") : o.splitLoginContext === "inputEmail" && f.field && (f.field.setAttribute("disabled", "disabled"), f.field.value = "")), u && u.field && (o.captcha = u.field.value), a && (o.rememberProfile = a.checked), login.utils.isInContextIntegration() && (o.isInContextCheckout = !0), m = getEventTarget(e), $.ajax({
                            url: h.getAttribute("action"),
                            data: o,
                            success: login.utils.successfulXhrHandler,
                            fail: login.utils.failedXhrSubmitHandler
                        })
                    }

                    function Bt() {
                        var e = document.querySelector('input[name="splitLoginCookiedFallback"]'),
                            t = document.querySelector("#phone"),
                            n = document.querySelector("#email"),
                            r = document.querySelector(".profileDisplayEmail"),
                            i = r && r.innerHTML;
                        if (!i || e || !n || !t) return;
                        n.hasAttribute("disabled") && !t.hasAttribute("disabled") ? (t.value = i, n.value = "") : !n.hasAttribute("disabled") && t.hasAttribute("disabled") && (n.value = i, t.value = "")
                    }

                    function jt() {
                        lt === "email" ? f && f.field && f.field.setAttribute("disabled", "disabled") : s && s.field && s.field.setAttribute("disabled", "disabled")
                    }

                    function Ft() {
                        var e = document.querySelector("form[name=login]"),
                            t = document.querySelector("#password"),
                            n = document.querySelector("#btnLogin"),
                            r = t.matches(":-webkit-autofill");
                        if (r && Object.prototype.hasOwnProperty.call(window, "getComputedStyle")) {
                            var i = window.getComputedStyle(t),
                                s = i.backgroundColor,
                                o = (s.match(/[0-5]{1,3}/g) || []).join(",");
                            login.utils.addHiddenElement("passwordFieldAutofillColor", o, e)
                        }
                    }

                    function It(e, t, n, r) {
                        var i = document.querySelector(".profileDisplayPhoneCode"),
                            s = document.querySelector("#keepMeLoggedIn"),
                            o = s && s.checked,
                            u = document.querySelector("#phoneCode"),
                            a = {};
                        for (var f = 0; f < e.length; f++) a[e[f].name] = e[f].value;
                        return o ? a.rememberMe = "true" : delete a.rememberMe, a.splitLoginContext === "inputPassword" && a.login_phone && u && (a.phoneCode = u.value, delete a.login_email), a.splitLoginContext === "inputPassword" && !a.login_phone && i && i.textContent === "" && (delete a.login_phone, delete a.phoneCode), r && a.splitLoginContext === "inputPassword" && a.login_phone && i && i.textContent !== "" && (a.phoneCode = i.textContent), a
                    }

                    function qt(e) {
                        e = e || {};
                        var t = document.querySelector("#keychain-interstitial"),
                            r = document.querySelector("#content"),
                            i = e.isSuaRequired,
                            s = e.isKeychainOptinRequired,
                            o = e.returnUrl || "/signin";
                        d && d.removeAttribute("disabled"), o && document.body.setAttribute("data-return-url", o);
                        if (login.overlayUtils.isEligibleToShowOverlay(e) && (!e.notifications || !e.notifications.msg)) return login.logger.log({
                            evt: n,
                            data: "XHR_LOGIN_SUCCESS",
                            calEvent: !0
                        }), login.logger.pushLogs(), login.overlayUtils.showOverlay(e);
                        if (i && o) return login.utils.hideSpinner(), login.utils.hideSpinnerMessage(), login.logger.log({
                            evt: n,
                            data: "XHR_LOGIN_SUCCESS",
                            calEvent: !0
                        }), login.logger.pushLogs(), login.sua(e);
                        if (s && o) return login.utils.hideSpinner(), login.utils.hideSpinnerMessage(), t && $(t).removeClass("hide"), r && $(r).addClass("hide"), login.logger.log({
                            evt: n,
                            data: "XHR_LOGIN_SUCCESS",
                            calEvent: !0
                        }), login.logger.pushLogs(), login.keychain(e);
                        if (o && !e.notifications) return login.logger.log({
                            evt: n,
                            data: "XHR_LOGIN_SUCCESS",
                            calEvent: !0
                        }), login.logger.pushLogs(), window.location.href = o;
                        login.utils.hideSpinner(), login.utils.hideSpinnerMessage();
                        if (e.notifications && e.notifications.msg) {
                            var a = document.querySelector(".notifications"),
                                f = document.createElement("p");
                            f.innerHTML = e.notifications.msg, f.className += "notification " + (e.notifications.type || ""), f.setAttribute("role", "alert"), a.innerHTML = "", a.appendChild(f)
                        }
                        return u.field && (u.field.value = ""), login.logger.log({
                            evt: n,
                            data: "XHR_LOGIN_FAILURE",
                            calEvent: !0
                        }), login.otp && login.otp.prepareSendPage(e), login.logger.pushLogs()
                    }

                    function Rt() {
                        login.utils.hideSpinner(), login.utils.hideSpinnerMessage(), d && d.removeAttribute("disabled"), u.field && (u.field.value = ""), login.logger.log({
                            evt: n,
                            data: "XHR_FAILED",
                            calEvent: !0
                        }), login.logger.pushLogs(), login.utils.failedXhrSubmitHandler()
                    }

                    function Ut(e) {
                        var e = e || {};
                        e._csrf = document.querySelector("#token").value, login.utils.showSpinner(), $.ajax({
                            type: "POST",
                            url: "/signin",
                            data: e,
                            dataType: "json",
                            success: function(e) {
                                return e ? (login.utils.setCSRFToken(e._csrf), qt(e)) : Rt()
                            },
                            fail: function(e) {
                                return Rt(e)
                            }
                        })
                    }

                    function zt() {
                        var e = login.utils.parseJsonSafe($("body").data("keychainFlagsJson")) || {},
                            t = e.isEligibleForXhrLogin,
                            n = document.querySelector('input[name="isKeychainActivationWithEmailTokenOn8ball"]'),
                            r = document.querySelector('input[name="appleIdpJson"]') || {},
                            i = login.utils.parseJsonSafe(r.value) || {};
                        return login.utils.isCookieDisabledBrowser() || i.isOptin ? !1 : login.overlayUtils.isLoginXHREligbleForOverlay() ? !0 : t && !n
                    }

                    function Wt(e) {
                        function m() {
                            var e = c && c.value;
                            if (!f.field) return;
                            j ? n = pt(s) && u.field && vt(f, u) : e === "inputPassword" ? n = u.field && vt(f, u) : n = l.field && vt(f, l)
                        }
                        var n, r = document.querySelector(".profileRememberedEmail"),
                            i = $("body").data("isTrackPasswordFieldAutofillEnabled"),
                            o = document.querySelector(".transitioning"),
                            a = document.querySelectorAll("form[name=login] [name]:not(button)") || {},
                            p = login.utils.getActiveCaptchaElement(c),
                            v = mt(c);
                        j && lt === "phone" && s.field ? Pt(s.field.value) : Bt(), st = !0, lt === "email" ? (n = dt(s) && vt(s, u), !r && n && $(s.field).hasClass("validate") && (n = gt(s))) : m(), i && Ft();
                        if (n) {
                            j && jt(), login.utils.showSpinner(), login.utils.showSpinnerMessage(), login.fn.addFnSyncData(), eventPreventDefault(e);
                            if (zt()) {
                                login.logger.log({
                                    evt: "login_type",
                                    data: "xhr",
                                    instrument: !0
                                }), login.logger.log({
                                    evt: t,
                                    data: "LOGIN_TYPE_XHR",
                                    calEvent: !0
                                }), login.logger.pushLogs(), $(o).addClass("nonTransparentMask"), login.utils.showSpinnerMessage("checkingInfo");
                                var g = p && p.field ? p.field.value : null,
                                    y = v ? v.checked : null,
                                    b = It(a, g, y, B);
                                return Ut(b)
                            }
                            login.logger.log({
                                evt: "login_type",
                                data: "form_submit",
                                instrument: !0
                            }), login.logger.log({
                                evt: t,
                                data: "LOGIN_TYPE_FORM_SUBMIT",
                                calEvent: !0
                            }), login.logger.pushLogs(), h && h.submit(), setTimeout(function() {
                                d.setAttribute("disabled", "disabled")
                            }, 10)
                        } else eventPreventDefault(e)
                    }

                    function Xt(e) {
                        var t;
                        if (!st) return !1;
                        t = e.field.value.replace(Z, "");
                        if (t === "") {
                            bt(e), e.type === "email" && xt(e);
                            return
                        }
                        St(e), e.type === "email" && $(e.field).hasClass("validate") ? t.match(et) ? (xt(e), Et(e, !0)) : (yt(e), wt(e)) : Et(e, !0)
                    }

                    function Vt(e) {
                        st = !1, Et(e)
                    }

                    function $t(e) {
                        $(e.container).hasClass("hasError") ? st = !0 : st = !1
                    }

                    function Jt() {
                        var e = f.field && f.field.value;
                        return f.field && $(f.field).attr("type") !== "hidden" && (s.field && s.field.hasAttribute("disabled") || c && c.value === "inputPhone") ? ft ? "phone" : "phonePassword" : c && c.value === "inputPin" || e ? "phone" : "email"
                    }

                    function Kt(e) {
                        var t = login.utils.getActiveCaptchaElement(c),
                            n = t.audioTag,
                            r = !!n.canPlayType && !!n.canPlayType("audio/mpeg").replace(/no/, "");
                        if (!r) return !0;
                        eventPreventDefault(e), t.field.focus(), n.play()
                    }

                    function Qt(e) {
                        var t = login.utils.getActiveCaptchaElement(c);
                        eventPreventDefault(e), eventStopPropagation(e), $.ajax({
                            type: "POST",
                            url: "/signin/refreshCaptcha",
                            data: {
                                _csrf: document.querySelector("#token").value
                            },
                            dataType: "json",
                            success: function(e) {
                                e && e.captcha && (t.image.setAttribute("src", e.captcha.captchaImgUrl), t.audioTag.setAttribute("src", e.captcha.captchaAudioUrl), t.playAudioBtn.setAttribute("href", e.captcha.captchaAudioUrl), t.field.value = "", $("body").hasClass("desktop") && t.field.focus())
                            }
                        })
                    }

                    function Gt(e) {
                        var t = getEventTarget(e);
                        if (!t) return;
                        setTimeout(function() {
                            $(t).hasClass("scTrack:unifiedlogin-rememberme-profile-opt-in") ? ($(t).removeClass("scTrack:unifiedlogin-rememberme-profile-opt-in"), $(t).addClass("scTrack:unifiedlogin-rememberme-profile-opt-out")) : ($(t).removeClass("scTrack:unifiedlogin-rememberme-profile-opt-out"), $(t).addClass("scTrack:unifiedlogin-rememberme-profile-opt-in"))
                        }, 10)
                    }

                    function Yt() {
                        function n(e) {
                            e.playAudioBtn.onclick = Kt, e.refreshCaptchaBtn.onclick = Qt, e.field.onkeyup = Xt.bind(null, e), e.field.onblur = Vt.bind(null, e), e.field.onfocus = $t.bind(null, e)
                        }
                        var e = document.querySelectorAll(".captcha-container");
                        for (var t = 0; t < e.length; t++) n(login.utils.getCaptchaDom(e[t]))
                    }

                    function Zt(e) {
                        var t = getEventTarget(e),
                            n, r, i;
                        if (!t || t.id !== "iconCloseEducation") return;
                        n = document.querySelector(".educationMessage");
                        if (!n) return;
                        r = document.querySelector(".contentContainer"), $(n).addClass("hide"), r && $(r).removeClass("contentContainerShort"), i = document.createElement("input"), i.setAttribute("type", "hidden"), i.setAttribute("name", "removeEducationMsg"), i.setAttribute("value", "true"), $(h).append(i)
                    }

                    function en(e) {
                        var t = lt === "email" ? dt(s) : pt(f),
                            n = getEventTarget(e);
                        eventPreventDefault(e), login.tpdLogin && login.tpdLogin.instrumentTpdLoginClicked(n.id), document.body.setAttribute("data-tpd-survey-enabled", !1), t && $(s.field).hasClass("validate") && (t = gt(s));
                        if (!t) return;
                        login.tpdLogin && login.tpdLogin.attemptTpdLogin(n.id)
                    }

                    function tn(e) {
                        Tt(), lt = "email", login.utils.notYouClickHandler(e), s.container && Et(s, !0), u.container && Et(u, !0), f.container && Et(f, !0), l.container && Et(l, !0)
                    }
                    var t = "UNIFIED_LOGIN",
                        n = "XHR_LOGIN",
                        r = document.querySelector("#notifications"),
                        i = document.querySelector('input[name="splitLoginCookiedFallback"]'),
                        s = {
                            container: document.querySelector("#login_emaildiv"),
                            field: document.querySelector("#email"),
                            label: document.querySelector('label[for="email"]'),
                            errMsgContainer: document.querySelector("#emailErrorMessage"),
                            errMsg: document.querySelector("#emailErrorMessage .emptyError"),
                            invalidMsg: document.querySelector("#emailErrorMessage .invalidError"),
                            phoneEmailToggleIcon: document.querySelector("#login_emaildiv .icon"),
                            type: "email"
                        },
                        o = document.querySelector(".textInputMask.email"),
                        u = {
                            container: document.querySelector("#login_passworddiv"),
                            field: document.querySelector("#password"),
                            errMsgContainer: document.querySelector("#passwordErrorMessage"),
                            errMsg: document.querySelector("#passwordErrorMessage .emptyError")
                        },
                        a = {
                            container: document.querySelector("#pinSection") || document.querySelector(".splitPhoneSection"),
                            field: document.querySelector("#phoneCode")
                        },
                        f = {
                            container: document.querySelector("#login_phonediv"),
                            field: document.querySelector("#phone"),
                            errMsgContainer: document.querySelector("#phoneErrorMessage"),
                            errMsg: document.querySelector("#phoneErrorMessage .emptyError"),
                            invalidMsg: document.querySelector("#phoneErrorMessage .invalidError")
                        },
                        l = {
                            container: document.querySelector("#login_pindiv"),
                            field: document.querySelector("#pin"),
                            errMsgContainer: document.querySelector("#pinErrorMessage"),
                            errMsg: document.querySelector("#pinErrorMessage .emptyError")
                        },
                        c = document.querySelector("input[name=splitLoginContext]"),
                        h = document.querySelector(".proceed"),
                        p = document.querySelector("#btnNext"),
                        d = document.querySelector("#btnLogin"),
                        v = document.querySelector(".actions"),
                        m = document.querySelector("#splitEmailSection") || document.querySelector("#passwordSection"),
                        g = document.querySelector("#splitPhoneSection") || document.querySelector("#pinSection"),
                        y = document.querySelector("#splitPassword") || document.querySelector("#splitPinSection") || document.querySelector("#pinSection"),
                        b = document.querySelector(".email"),
                        w = document.querySelector(".phone"),
                        E = document.querySelector("#loginWithPhoneOption"),
                        S = document.querySelector("#switchToPhone"),
                        x = document.querySelector("#loginWithEmailOption"),
                        T = document.querySelector("#switchToEmail"),
                        N = document.querySelector(".countryPhoneSelectWrapper"),
                        C = document.querySelector("#emailPageSwitch"),
                        k = document.querySelector(".educationMessage"),
                        L = document.querySelector("#emailSubTagLine"),
                        A = document.querySelector("#phoneSubTagLine"),
                        O = document.querySelector(".forgotLink"),
                        M = O && O.querySelectorAll(".pwrLink"),
                        _ = O && O.querySelector("#pwdIframe"),
                        D = document.querySelector("#moreOptionsMobile"),
                        P = document.querySelector("#moreOptionsDropDown"),
                        H = document.querySelector("#tpdButton"),
                        B = login.utils.isHybridLoginExperience(),
                        j = login.utils.isHybridEditableOnCookied(),
                        F = document.querySelector("#tpdDemo"),
                        I = document.querySelector('input[name="ctxId"]'),
                        q = document.querySelector(".keepMeLogin");
                    login.utils.isCookieDisabledBrowser() && q && $(q).addClass("hide"), B && (addEvent(s.field, "input", V), addEvent(s.field, "change", V), addEvent(s.field, "input", J)), j && W(s.field.value), login.pubsub && (login.pubsub.subscribe("WINDOW_CLICK", R), login.pubsub.subscribe("WINDOW_CLICK", U));
                    var K = document.querySelector("#createAccount");
                    K && (K.onclick = function(e) {
                        var t = login.logger.getStateName();
                        login.utils.getOutboundLinksHandler(K, t, "process_signup")(e)
                    });
                    var Q = document.querySelector("#backToInputEmailLink"),
                        G = document.querySelector("#backToEmailPasswordLink"),
                        Y = document.querySelector("#rememberProfileEmail"),
                        Z = /^\s+|\s+$/,
                        et = /^\S+@\S+\.\S+$/,
                        tt = /[^\d]+/g,
                        nt = /\s/g,
                        rt = "PayPal One Touch™",
                        it = /[-().\s]/ig,
                        st = !1,
                        ot = document.querySelector("form[name=smartlockForm]"),
                        ut = document.querySelector("#secondaryLoginBtn"),
                        at = $("body").data("phonePasswordEnabled"),
                        ft = $("body").data("phonePinEnabled"),
                        lt = Jt();
                    s.field && (s.field.onkeyup = Xt.bind(null, s), s.field.onblur = Vt.bind(null, s), s.field.onfocus = $t.bind(null, s)), u.field && (u.field.onkeyup = Xt.bind(null, u), u.field.onblur = Vt.bind(null, u), u.field.onfocus = $t.bind(null, u)), f.field && (f.field.onkeyup = Xt.bind(null, f), f.field.onblur = Vt.bind(null, f), f.field.onfocus = $t.bind(null, f)), l.field && (l.field.onkeyup = Xt.bind(null, l), l.field.onblur = Vt.bind(null, l), l.field.onfocus = $t.bind(null, l)), a && a.field && (a.field.onchange = Lt, B && (a.field.onclick = At)), Yt(), b && w ? (b.onclick = Ct, w.onclick = kt) : b && (b.onclick = _t), at && S && (S.onclick = Ot), at && T && (T.onclick = Mt), addEvent(N, "focusin", function(e) {
                        $(N).addClass("focus")
                    }), addEvent(N, "focusout", function(e) {
                        $(N).removeClass("focus")
                    }), C && addEvent(C, "click", function(e) {
                        var t = document.querySelector("input[name=forcePhonePasswordOptIn]");
                        eventPreventDefault(e), _t(e, function() {
                            t.value = "true"
                        })
                    }), addEvent(h, "keydown", function(e) {
                        var t = getEventTarget(e);
                        isEnterKeyPressed(e) && !t.href && !$(t).hasClass("show-hide-password") && Dt(e)
                    }), addEvent(h, "submit", Dt), D && addEvent(D, "click", en), H && addEvent(H, "click", en), Q && addEvent(Q, "click", function(e) {
                        tn(e), B && X()
                    }), G && addEvent(G, "click", function(e) {
                        e.preventDefault(), i ? Ct() : tn(e)
                    }), Y && (Y.onclick = Gt), login.pubsub && login.pubsub.subscribe("WINDOW_CLICK", Zt)
                }
            }(), login.oneTouchLogin = function() {
                function o() {
                    var t = [],
                        r = document.querySelector('input[name="locale.x"]');
                    t.push({
                        evt: "state_name",
                        data: "Login_UL_RM",
                        instrument: !0
                    }), t.push({
                        evt: "transition_name",
                        data: "prepare_login_UL_RM",
                        instrument: !0
                    }), t.push({
                        evt: "design",
                        data: e.isInContextIntegration() ? "in-context" : "full-context",
                        instrument: !0
                    }), r && t.push({
                        evt: "page_lang",
                        data: r.value,
                        instrument: !0
                    }), t.push({
                        evt: i,
                        data: "PREPARE_PAGE_" + s.toUpperCase(),
                        calEvent: !0
                    }), n.clientLog(t, null)
                }

                function u(e, t) {
                    var n = document.querySelector(".notifications"),
                        r, i;
                    n && (r = document.createElement("p"), i = document.createTextNode(e), r.setAttribute("class", "notification " + t), r.setAttribute("role", "alert"), r.appendChild(i), n.appendChild(r))
                }

                function a() {
                    var n = document.querySelectorAll("form[name=login] input[type=hidden]"),
                        r = document.querySelector("input[name=login_email]"),
                        i = document.querySelector("input[name=login_password]"),
                        s = $("body").data("oneTouchUser"),
                        a = $("body").data("oneTouchTenant"),
                        f = login.utils.getIntent(),
                        l = $("body").data("cookieBannerEnabled"),
                        c = $("body").data("isKeychainOptinRequired"),
                        h = {
                            _csrf: 1,
                            intent: 1,
                            flowId: 1,
                            ctxId: 1,
                            returnUri: 1,
                            state: 1,
                            "locale.x": 1,
                            fn_sync_data: 1
                        },
                        p = {};
                    for (var d = 0; d < n.length; d++) h[n[d].name] && (p[n[d].name] = n[d].value);
                    if (!p.intent || f !== "prox" && !p.returnUri || !s) {
                        e.hideSpinner(), autoLoginfallBackClientLog();
                        return
                    }
                    p.otLoginIntent = p.intent, p.login_email = r && r.value, a && (p.oneTouchTenant = a), e.showSpinner(), o(), $.ajax({
                        url: "/signin/ot-token",
                        method: "POST",
                        data: p,
                        success: function(n) {
                            var s;
                            r && r.removeAttribute("disabled"), i && i.removeAttribute("disabled");
                            if (n.keychainDeviceToken && login.keychain) return login.keychain(n);
                            if (n.smartlockOptIn && login.smartLock) {
                                login.smartLock(n);
                                return
                            }
                            if (n.incompleteContext) {
                                window.location.href = window.location.href;
                                return
                            }
                            if (n.returnUrl) {
                                window.location.href = n.returnUrl;
                                return
                            }
                            s = n.notifications, s && u(s.msg, s.type), e.hideSpinner(), e.hideSpinnerMessage("secureMessage"), e.hideSpinnerMessage("oneTouchMessage"), autoLoginfallBackClientLog({
                                error_code: "ot_login_failed"
                            }), l && t && t.showCookieBanner()
                        },
                        fail: function(n) {
                            e.hideSpinner(), r && r.removeAttribute("disabled"), i && i.removeAttribute("disabled"), e.hideSpinnerMessage("secureMessage"), e.hideSpinnerMessage("oneTouchMessage"), autoLoginfallBackClientLog({
                                error_code: "ot_login_xhr_fail"
                            }), l && t && t.showCookieBanner()
                        }
                    })
                }
                var e = login.utils,
                    t = login.loadResources,
                    n = login.logger,
                    r = window.PAYPAL.ulData || {},
                    i = "ONETOUCH_LOGIN",
                    s = e.getIntent();
                return function() {
                    var i = $("body").data("oneTouchUser"),
                        s = $("body").data("isKeychainOptinRequired") === "true",
                        o = $("body").data("tpdAutoSend"),
                        u = r.aPayAuth,
                        f = $("body").data("enableFnSyncPayloadOnOneTouch");
                    f && (n.log({
                        evt: "FN_PAYLOAD",
                        data: "send_fn_sync_data",
                        instrument: !0
                    }), n.pushLogs(), login.fn.addFnSyncData());
                    if (!u && i) {
                        a();
                        return
                    }
                    if (u && r.canNotMakePayment) {
                        a();
                        return
                    }!o && !isAPaySupported() && !i && !s && e.hideSpinner()
                }
            }(), login.showHidePassword = function() {
                function e(e, t) {
                    function o() {
                        $(n).addClass("hide"), $(r).addClass("hide")
                    }

                    function u(e) {
                        t === "tel" ? $(i).removeClass("tel-password") : i.setAttribute("type", t), $(n).addClass("hide"), $(r).removeClass("hide"), i.focus(), e.stopPropagation(), login.logger.log({
                            evt: "is_pwd_sh",
                            data: "Y",
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function a(e) {
                        t === "tel" ? $(i).addClass("tel-password") : i.setAttribute("type", "password"), $(n).removeClass("hide"), $(r).addClass("hide"), i.focus(), e.stopPropagation(), login.logger.log({
                            evt: "is_pwd_sh",
                            data: "N",
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function f(e) {
                        o(), (login.utils.isFieldPrefilled(i) || i.value.length > 0) && s && $(s).hasClass("hide") && (t === "text" ? i.getAttribute("type") === "password" ? $(n).removeClass("hide") : $(r).removeClass("hide") : $(i).hasClass("tel-password") ? $(n).removeClass("hide") : $(r).removeClass("hide")), e.stopPropagation()
                    }
                    var n = e.querySelector(".showPassword"),
                        r = e.querySelector(".hidePassword"),
                        i = e.querySelector(".pin-password"),
                        s = e.querySelector("#pwFpIcon");
                    t = t || "text", t === "tel" && $(i).addClass("tel-password"), n.onclick = u, r.onclick = a, i.onfocus = f, addEvent(i, "keyup", f), i.onclick = function(e) {
                        e.stopPropagation()
                    }, window.onclick = o
                }
                return function() {
                    var n = document.querySelector("#signUpSection"),
                        r = document.querySelector("#passwordSection"),
                        i = document.querySelector("#pinSection") || document.querySelector("#splitPinSection"),
                        s;
                    i && (s = i.querySelector(".pin-password")), n && e(n), r && e(r), i && s && e(i, s.getAttribute("type") === "tel" ? "tel" : "text")
                }
            }(), login.oneTouch = function() {
                return function() {
                    var t = document.querySelector(".keepMeLoginAbout"),
                        n = document.getElementById("keepMeLoginTerms"),
                        r = document.querySelector(".keepMeLogin .tagLine"),
                        i = login.utils.getKmliCb(),
                        s = "scTrack:unifiedlogin-rememberme-about-open",
                        o = "scTrack:unifiedlogin-rememberme-about-close",
                        u = "scTrack:unifiedlogin-rememberme-opt-in",
                        a = "scTrack:unifiedlogin-rememberme-opt-out";
                    if (!i || !t || !n) return;
                    t.setAttribute("href", "#"), t.onclick = function() {
                        $(n).hasClass("slideUp") ? ($(n).removeClass("slideUp"), $(n).addClass("slideDown"), $(t).attr("aria-expanded", "true"), setTimeout(function() {
                            $(t).removeClass(s), $(t).addClass(o)
                        }, 10)) : ($(n).removeClass("slideDown"), $(n).addClass("slideUp"), $(t).attr("aria-expanded", "false"), setTimeout(function() {
                            $(t).removeClass(o), $(t).addClass(s)
                        }, 10)), t.focus(), r && $(r).toggle(), setTimeout(function() {
                            window.dispatchEvent && window.dispatchEvent(createNewEvent("resize"))
                        }, 200)
                    }, i.onclick = function() {
                        setTimeout(function() {
                            $(i).hasClass(u) ? ($(i).removeClass(u), $(i).addClass(a)) : ($(i).removeClass(a), $(i).addClass(u))
                        }, 10)
                    }
                }
            }(), login.footer = function() {
                function n() {
                    var e = document.querySelector(".footer"),
                        t = document.querySelector(".activeContent"),
                        n = document.querySelector("#returnToMerchant"),
                        r, i, s = n && $(n).outerHeight() || 0;
                    r = $(t).outerHeight() + $(e).outerHeight() + s, i = window.innerHeight || document.documentElement && document.documentElement.clientHeight || window.screen && window.screen.height || document.height || document.body && document.body.offsetHeight, i < r ? $(e).addClass("footerStayPut") : $(e).removeClass("footerStayPut")
                }
                var e = document.querySelectorAll(".localeSelector li a");
                for (var t = 0; t < e.length; t++) e[t].onclick = login.utils.getOutboundLinksHandler(e[t], null, "process_language_change");
                return function() {
                    n(), addEvent(window, "resize", n)
                }
            }(), login.pwr = function() {
                return function() {
                    function o(e) {
                        e.preventDefault(), s = document.createElement("div"), s.className = "modal-underlay", document.body.appendChild(s), n.style.display = "block", setTimeout(function() {
                            s.style.opacity = .7, n.style.opacity = 1
                        }, 0), r.setAttribute("src", $(r).data("src")), r.focus(), r.onload = function() {
                            a(), r.focus()
                        }, login.logger.log({
                            evt: "state_name",
                            data: login.logger.getStateName(),
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "process_password_recovery",
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function u() {
                        var e = document.querySelector(".modal-underlay");
                        document.body.removeChild(e), n.style.display = "none", r.setAttribute("src", "about:blank"), r.setAttribute("title", "pwdIframe"), t && t.length > 0 && t[1].focus()
                    }

                    function a() {
                        var e = window.innerHeight || document.documentElement.clientHeight;
                        e <= n.clientHeight ? (n.style.transform = "translate(-50%, 0%)", n.style.top = 0) : (n.style.transform = "translate(-50%, -50%)", n.style.top = "50%")
                    }
                    var t = document.querySelectorAll(".startPwrFlowBtn"),
                        n = document.getElementById("password-recovery-modal"),
                        r = document.getElementById("pwdIframe"),
                        i, s;
                    r && login.utils.isInIframe() && r.setAttribute("target", "_blank");
                    if (t && t.length > 0 && !login.utils.isInIframe()) {
                        i = document.createElement("button"), i.className = "ui-dialog-titlebar-close", i.setAttribute("type", "button"), i.setAttribute("alt", "Close"), i.setAttribute("aria-label", "Close"), n.appendChild(i);
                        for (var f = 0; f < t.length; f++) addEvent(t[f], "click", o);
                        i.onclick = u, addEvent(r, "focusout", function(e) {
                            e.preventDefault(), i.focus()
                        }), i.onkeydown = function(e) {
                            e.which === 9 && r.focus()
                        }, addEvent(window, "resize", a)
                    }
                }
            }(), login.authCaptcha = function() {
                return function(t) {
                    function a(e) {
                        e.preventDefault(), e.stopPropagation(), $.ajax({
                            method: "GET",
                            url: "/auth/refreshcaptcha",
                            success: function(e) {
                                e !== "undefined" && ($(".captcha-container img").attr("src", e.captchaImgUrl), $(".captcha-container .audio a").attr("href", e.captchaAudioUrl), $(".captcha-container input").val(""), $("#captchaPlayer").attr("src", e.captchaAudioUrl), $("body").hasClass("desktop") && $(".captcha-container input").focus())
                            }
                        })
                    }

                    function f(e) {
                        var t = document.getElementById("captchaPlayer"),
                            n = !!t.canPlayType && !!t.canPlayType("audio/mpeg;").replace(/no/, "");
                        if (!n) return !0;
                        e.preventDefault(), $(".captcha-container input").focus(), t.play()
                    }

                    function l(e) {
                        $(e.container).addClass("hasError"), e.container.style["z-index"] = 100, $(e.errMsgContainer).addClass("show"), e.field.focus()
                    }

                    function c(e) {
                        $(e.errMsg).removeClass("hide")
                    }

                    function h(e) {
                        $(e.errMsg).addClass("hide")
                    }

                    function p(e) {
                        return e.field && typeof e.field.value == "string" && !e.field.value.trim() ? (l(e), c(e), !1) : !0
                    }

                    function d(e) {
                        var n = !0;
                        return e && e.field && !t && (n = p(e)), n
                    }

                    function v(e) {
                        return e ? {
                            container: e.querySelector("div.textInput"),
                            field: e.querySelector("input[type=text]"),
                            errMsgContainer: e.querySelector("div.errorMessage"),
                            errMsg: e.querySelector("div.errorMessage .emptyError")
                        } : null
                    }

                    function m(e) {
                        var t = d(o),
                            n = document.querySelector("form[name=challenge]"),
                            r = {};
                        u = !0, e && eventPreventDefault(e);
                        if (!t) return;
                        login.utils.showSpinner();
                        for (var i = 0; i < n.length; i++) r[n[i].name] = n[i].value;
                        $.ajax({
                            url: s.getAttribute("action"),
                            data: r,
                            success: login.utils.successfulXhrHandler,
                            fail: login.utils.failedXhrSubmitHandler
                        })
                    }

                    function g(e) {
                        $(e.container).hasClass("hasError") ? u = !0 : u = !1
                    }

                    function y(e, t) {
                        t && $(e.container).removeClass("hasError"), e.container.style["z-index"] = 1, $(e.errMsgContainer).removeClass("show")
                    }

                    function b(e) {
                        u = !1, y(e)
                    }

                    function w(e) {
                        var t = e.field.value.trim();
                        if (!u) return !1;
                        t === "" ? c(e) : (h(e), y(e, !0))
                    }
                    var n = document.querySelector(".captchaRefresh"),
                        r = document.querySelector(".captchaPlay"),
                        i = document.querySelector("#captcha"),
                        s = document.querySelector("#ads-container form"),
                        o = v(i),
                        u = !1;
                    if (t) {
                        m();
                        return
                    }
                    n.onclick = a, r.onclick = f, s.onsubmit = m, o.field.onfocus = g.bind(null, o), o.field.onblur = b.bind(null, o), o.field.onkeyup = w.bind(null, o)
                }
            }(), login.ads = function() {
                function init(e) {
                    var t, n = e || $("body").data("adsChallengeUrl");
                    $.ajax({
                        url: n,
                        method: "GET",
                        success: function(e) {
                            t = document.createElement("script"), t.id = "ads", t.type = "text/javascript", t.setAttribute("nonce", $("body").data("nonce")), t.text = e.replace(/<\/?(html|body|script)>/g, ""), document.body.appendChild(t)
                        },
                        fail: function(e) {}
                    })
                }

                function handleAdsInterception(htmlResponse) {
                    var isAutoSubmit = !0,
                        adsContainerId = "ads-container",
                        adsContainerDiv, scriptNodes, adsCaptchaType;
                    document.getElementById("ads-container") && document.getElementById("ads-container").parentNode.removeChild(document.getElementById("ads-container")), adsContainerDiv = document.createElement("div"), adsContainerDiv.setAttribute("id", adsContainerId), adsContainerDiv.innerHTML = htmlResponse, $("#main").append(adsContainerDiv), scriptNodes = adsContainerDiv.getElementsByTagName("script");
                    for (var i = 0; i < scriptNodes.length; i++) eval.call(this, scriptNodes[i].innerHTML);
                    typeof autosubmit != "undefined" && (isAutoSubmit = autosubmit), typeof captchatype != "undefined" && (adsCaptchaType = captchatype), isAutoSubmit ? document.getElementById("ads-container").style.display = "none" : $("#login").addClass("hide"), typeof login.authCaptcha == "function" && login.authCaptcha(isAutoSubmit), isAutoSubmit || (login.utils.hideSpinner(), login.utils.hideSpinnerMessage()), login.logger.log({
                        evt: "ads_state_name",
                        data: isAutoSubmit ? "pre_jschallenge_served" : adsCaptchaType,
                        instrument: !0
                    }), login.logger.pushLogs()
                }
                return {
                    init: init,
                    handleAdsInterception: handleAdsInterception
                }
            }(), login.tpdLogin = function() {
                function n(e) {
                    var t = {};
                    if (!e) return;
                    login.logger.log({
                        evt: "state_name",
                        data: e.stateName,
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: e.transitionName,
                        instrument: !0
                    }), e.calName && login.logger.log({
                        evt: "TPD_CLIENT",
                        data: e.calName,
                        calEvent: !0
                    }), login.logger.pushLogs()
                }

                function r() {
                    n({
                        stateName: "begin_tpd",
                        transitionName: "prepare_verification"
                    })
                }

                function i(e) {
                    n({
                        stateName: "begin_pwd",
                        transitionName: "process_pwd_tpd_click",
                        calName: "INIT_TPD" + (e && "_" + e)
                    })
                }

                function s() {
                    n({
                        stateName: "begin_tpd",
                        transitionName: "process_pwd_tpd_auto",
                        calName: "AUTO_TPD_LOGIN"
                    })
                }

                function o() {
                    n({
                        stateName: "begin_tpd",
                        transitionName: "process_not_you",
                        calName: "PROCESS_NOT_YOU"
                    })
                }

                function u() {
                    n({
                        stateName: "begin_tpd",
                        transitionName: "process_resend",
                        calName: "PROCESS_RESEND"
                    })
                }

                function a(e) {
                    switch (e) {
                        case "passwordReason1":
                            n({
                                stateName: "begin_use_pwd",
                                transitionName: "process_no_phone",
                                calName: "USE_PASSWORD_NO_PHONE"
                            });
                            break;
                        case "passwordReason2":
                            n({
                                stateName: "begin_use_pwd",
                                transitionName: "process_no_notification",
                                calName: "USE_PASSWORD_NO_NOTIFICATION"
                            });
                            break;
                        case "passwordReason3":
                            n({
                                stateName: "begin_use_pwd",
                                transitionName: "process_prefer_password",
                                calName: "USE_PASSWORD_PREFER_PASSWORD"
                            });
                            break;
                        case "passwordReason4":
                            n({
                                stateName: "begin_use_pwd",
                                transitionName: "process_try_later",
                                calName: "USE_PASSWORD_TRY_LATER"
                            });
                            break;
                        case "passwordReason5":
                            n({
                                stateName: "begin_use_pwd",
                                transitionName: "process_other",
                                calName: "USE_PASSWORD_OTHER"
                            });
                            break;
                        default:
                            n({
                                stateName: "begin_tpd",
                                transitionName: "process_use_pwd",
                                calName: "USE_PASSWORD"
                            })
                    }
                }

                function f(e) {
                    n({
                        stateName: "end_tpd_notification",
                        transitionName: "expired_tpd_no_action",
                        calName: "EXPIRED_TPD_" + e
                    })
                }

                function l(n) {
                    var r = document.querySelectorAll("form[name=login] input"),
                        i = {},
                        s = $("body").data("tpdVariant");
                    $("body").data("isPrefillEmailEnabled") && $("body").data("tpdDemo") && document.body.removeAttribute("data-is-prefill-email-enabled"), e.showSpinner();
                    for (var o = 0; o < r.length; o++) i[r[o].name] = r[o].value;
                    if (i.tpdEligible !== "true") {
                        e.hideSpinner();
                        return
                    }
                    i.splitLoginContext = "tpd", delete i.login_password, delete i.login_pin, i.tpdVariant = n, i.originalVariant = s, login.fn.addFnSyncData(), $.ajax({
                        url: t.getAttribute("action"),
                        method: "POST",
                        data: i,
                        success: e.successfulXhrHandler,
                        fail: e.failedXhrSubmitHandler
                    })
                }

                function c() {
                    var e = $("body").data("tpdAutoSend");
                    if (login.utils.isTpdDemo()) return;
                    e === "true" && (s(), l("autoSend"))
                }
                var e = login.utils,
                    t = document.querySelector("form[name=login]");
                return {
                    instrumentVerificationViewRendered: r,
                    instrumentTpdLoginClicked: i,
                    instrumentTpdLoginAutoTriggered: s,
                    instrumentNotYouClicked: o,
                    instrumentResendClicked: u,
                    instrumentUsePasswordInstead: a,
                    initialize: c,
                    attemptTpdLogin: l,
                    instrumentTpdExpired: f
                }
            }(), login.singleSignOn = function() {
                function o() {
                    var o = {},
                        u = document.querySelectorAll("form[name=login] input[type=hidden]");
                    t && (r && r === "venmo" ? e.hideSpinner() : (e.showSpinner(), $(n).addClass("nonTransparentMask"), s ? e.showSpinnerMessage("oneSecond") : e.showSpinnerMessage("secureMessage")), o.ssoViaToken = !0, login.fn.updateFnSyncContext({
                        sourceId: "SSO_LOGIN"
                    }), login.fn.addFnSyncData());
                    var a = {
                        _csrf: 1,
                        intent: 1,
                        ctxId: 1,
                        returnUri: 1,
                        state: 1,
                        authContextId: 1,
                        authCode: 1,
                        billingId: 1,
                        "locale.x": 1,
                        fn_sync_data: 1,
                        flowId: 1
                    };
                    for (var f = 0; f < u.length; f++) a[u[f].name] && (o[u[f].name] = u[f].value);
                    login.logger.log({
                        evt: "state_name",
                        data: "sso_login",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "prepare_sso_login",
                        instrument: !0
                    }), login.logger.pushLogs(), $.ajax({
                        url: "/signin/sso",
                        method: "POST",
                        data: o,
                        success: function(t) {
                            var n = t.returnUrl,
                                i = t.failureReturnUrl;
                            login.logger.log({
                                evt: "state_name",
                                data: "sso_login",
                                instrument: !0
                            }), login.logger.log({
                                evt: "transition_name",
                                data: "process_sso_login",
                                instrument: !0
                            }), login.logger.pushLogs();
                            if (r && (n || i)) {
                                e.isBrowserInPrivateMode(function(e) {
                                    var t = e && e.isPrivate;
                                    if (!t && n) {
                                        window.location.href = n;
                                        return
                                    }
                                    t && (window.location.href = i || n)
                                });
                                return
                            }
                            if (n) {
                                window.location.href = n;
                                return
                            }
                            t.notifications && login.utils.updatePageLevelError(t.notifications.msg, t.notifications.type), r !== "venmo" && (e.hideSpinner(), e.hideSpinnerMessage("oneSecond"), e.hideSpinnerMessage("secureMessage"))
                        },
                        fail: function(t) {
                            var n = e.parseJsonSafe(t.response);
                            if ((r && r === "venmo" || i && i === "venmo") && n.returnUrl) {
                                window.location.href = n.returnUrl;
                                return
                            }
                            e.hideSpinner(), e.hideSpinnerMessage("oneSecond"), e.hideSpinnerMessage("secureMessage")
                        }
                    })
                }
                var e = login.utils,
                    t = $("body").data("ssoviatoken"),
                    n = document.querySelector(".transitioning"),
                    r = $("body").data("tenantsso"),
                    i = $("body").data("tenantssocontingency"),
                    s = $("body").data("ssoDefaultContent");
                return function() {
                    if (t) {
                        login.fn.initialize(), o();
                        return
                    }
                }
            }(), login.smartLock = function() {
                function E(t) {
                    var n = {};
                    if (!t) return;
                    login.logger.log({
                        evt: "state_name",
                        data: t.stateName,
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: t.transitionName,
                        instrument: !0
                    }), login.logger.log({
                        evt: "api_name",
                        data: t.apiName,
                        instrument: !0
                    }), t.errorCode && login.logger.log({
                        evt: "ext_error_code",
                        data: t.errorCode,
                        instrument: !0
                    }), t.calName && login.logger.log({
                        evt: "CROSS_DEVICE_OT_CLIENT",
                        data: t.calName + "_" + a,
                        calEvent: !0
                    }), t.respDuration && login.logger.log({
                        evt: "resp_duration",
                        data: t.respDuration,
                        instrument: !0
                    }), t.updateCapping && (n.data = {
                        updateCapping: t.updateCapping
                    }), t.resetCapping && (n.data = n.data || {}, n.data.resetCapping = t.resetCapping), t.googleSessionExists && login.logger.log({
                        evt: "google_session_exists",
                        data: t.googleSessionExists,
                        instrument: !0
                    }), t.redirectOnComplete && (n.complete = function() {
                        login.utils.showSpinner(), window.location.href = e.slReturnUrl || ""
                    }), t.slTokenStatus && login.logger.log({
                        evt: "sl_token_status",
                        data: t.slTokenStatus,
                        instrument: !0
                    }), login.logger.pushLogs(n)
                }

                function S() {
                    return $(t).hasClass("mobile")
                }

                function x() {
                    return Date.now ? Date.now() : (new Date).getTime()
                }

                function T(e) {
                    var t = document.querySelector(".modal-underlay");
                    S() && (e.style.width = "100%", e.style.height = "100%"), t || (t = document.createElement("div"), t.className = "modal-underlay", document.body.appendChild(t)), e.style.display = "block", t.style.opacity = .7, e.style.opacity = 1, login.logger.log({
                        evt: "CROSS_DEVICE_OT_CLIENT",
                        data: "LEARN_MORE_" + a,
                        calEvent: !0
                    })
                }

                function N(e) {
                    var t = document.querySelector(".modal-underlay");
                    t && document.body.removeChild(t), e.style.display = "none"
                }

                function C(e) {
                    f = f && $(f).remove();
                    if (e && e.target && e.target.id === "backToInputEmailLink") return;
                    login.logger.log({
                        evt: "CROSS_DEVICE_OT_CLIENT",
                        data: "CHANGE_" + a,
                        calEvent: !0
                    }), login.logger.log({
                        evt: "clicked_not_you",
                        data: "y",
                        instrument: !0
                    }), login.utils.notYouClickHandler(e, function() {
                        i && ($(i).addClass("hide"), $(i).removeClass("activeContent")), o && ($(o).removeClass("hide"), $(o).addClass("activeContent"))
                    })
                }

                function k(e, t, n) {
                    var r = document.querySelector(".transitioning p.oneSecond"),
                        i = {};
                    e = e || {}, e.data && (i = e.data), i._csrf = login.utils.getCSRFToken(), login.utils.showSpinner(), r && $(r).removeClass("hide"), $.ajax({
                        type: e.method || "POST",
                        url: "/signin/" + e.path,
                        data: i,
                        dataType: "json",
                        success: function(e) {
                            return login.utils.setCSRFToken(e && e._csrf), t(e)
                        },
                        fail: n
                    })
                }

                function L(e) {
                    i && ($(i).addClass("hide"), $(i).removeClass("activeContent")), o && ($(o).removeClass("hide"), $(u).addClass("activeContent")), f = f && $(f).remove(), triggerEvent(window, "resize"), login.utils.hideSpinnerMessage("retrieveInfo"), login.utils.hideSpinnerMessage("waitFewSecs"), login.utils.hideSpinner(), login.fn.updateFnSyncContext({
                        sourceId: "UL_CHECKOUT_INPUT_PASSWORD"
                    }), E({
                        stateName: "switch_to_pwd",
                        transitionName: "process_switch_to_pwd",
                        calName: "PWD_FALLBACK_" + login.utils.getIntent(),
                        errorCode: e
                    });
                    return
                }

                function A(t, n) {
                    var r = document.querySelector("input[name=ctxId]");
                    k({
                        path: "smart-lock-handler",
                        data: {
                            smartLockIdToken: t,
                            nonce: g || "",
                            actionIntent: n,
                            returnUrl: e.slReturnUrl,
                            slSessionExists: e.slSessionExists,
                            scimContextId: e.scimContextId || "",
                            intent: login.utils.getIntent(),
                            ctxId: r && r.value,
                            flowId: login.utils.getFlowId(),
                            isActivate: !0
                        }
                    }, function(t) {
                        if (t.returnUrl) {
                            window.location.href = t.returnUrl;
                            return
                        }
                        if (n === "optin") {
                            window.location.href = e.slReturnUrl;
                            return
                        }
                        login.logger.log({
                            evt: "CROSS_DEVICE_OT_CLIENT",
                            data: "ACTIVATION_FAILED_LOGIN_FALLBACK_" + a,
                            calEvent: !0
                        }), L("activation failed - prompt pwd");
                        return
                    }, function(t) {
                        if (n === "optin") {
                            window.location.href = e.slReturnUrl;
                            return
                        }
                        login.logger.log({
                            evt: "CROSS_DEVICE_OT_CLIENT",
                            data: "ACTIVATION_ERROR_LOGIN_FALLBACK_" + a,
                            calEvent: !0
                        }), L("activation error");
                        return
                    })
                }

                function O() {
                    return login.utils.showSpinner(), E({
                        stateName: "begin_sl_activation",
                        transitionName: "process_sl_activation_continue",
                        calName: "ACTIVATE_INITIATED"
                    }), A(m, "activation")
                }

                function M() {
                    var e = i.querySelector("#linked"),
                        t = i.querySelector("#unlinked"),
                        n = document.querySelector("#optInLearnMoreDesc");
                    if (p) return;
                    clearTimeout(v), b ? (y && (g = y), o && ($(o).addClass("hide"), $(u).removeClass("activeContent")), i && ($(i).removeClass("hide"), $(s).addClass("activeContent")), e && $(e).removeClass("hide"), n && $(n).addClass("hide"), t && $(t).addClass("hide"), c && $(c).addClass("hide"), login.utils.hideSpinnerMessage("retrieveInfo"), login.utils.hideSpinnerMessage("waitFewSecs"), login.utils.hideSpinner(), E({
                        stateName: "begin_sl_activation",
                        transitionName: "prepare_sl_activation",
                        calName: "ACTIVATION_SHOWN",
                        respDuration: w,
                        updateCapping: "smartlockActivate",
                        slTokenStatus: "not_validated"
                    })) : (login.logger.log({
                        evt: "CROSS_DEVICE_OT_CLIENT",
                        data: "PARTNER_AUTH_FAILED_" + a,
                        calEvent: !0
                    }), L("partner token invalid"))
                }

                function _(t) {
                    var n = i.querySelector("#displayName"),
                        r = i.querySelector("#partnerEmail"),
                        s = i.querySelector("#partnerEmailDomain"),
                        o = i.querySelector("#partnerPhoto"),
                        u = i.querySelector(".loginEmail"),
                        a = d ? x() - d : 0,
                        f = {
                            stateName: "begin_google_auth",
                            transitionName: "process_google_auth",
                            apiName: "google_auth",
                            respDuration: a
                        };
                    clearTimeout(v);
                    if (!(!t || t.error || !t.idToken)) {
                        f.calName = "AUTH_SUCCESS", u.textContent = e.slLoginEmail, n && (n.textContent = t.name);
                        var l = t.email && t.email.indexOf("@");
                        return r && l > 0 && (r.textContent = t.email.slice(0, l), s.textContent = t.email.slice(l)), o && (o.style.backgroundImage = "url(" + t.image + ")"), m = t.idToken, E(f), b = !0, M()
                    }
                    f.errorCode = t && t.error, f.calName = "AUTH_FAIL", L("auth failed"), f.updateCapping = "smartlockBlockingAuth", E(f)
                }

                function D(e) {
                    var t = d ? x() - d : 0,
                        n = {
                            stateName: "begin_nonblock_google_auth",
                            transitionName: "process_nonblock_google_auth",
                            apiName: "google_auth",
                            respDuration: t
                        };
                    !e || e.error || !e.idToken ? (n.errorCode = e && e.error, n.calName = "NB_AUTH_FAIL") : (n.calName = "NB_AUTH_SUCCESS", n.resetCapping = "smartlockBlockingAuth"), E(n)
                }

                function P(e) {
                    var t = d ? x() - d : 0,
                        n = e && e.error === "userCanceled" ? "process_gsl_cancel" : "process_gsl_error",
                        i = e && e.error === "userCanceled" ? "LINK_CANCELLED" : "LINK_ERROR",
                        s = {
                            stateName: "begin_gsl",
                            respDuration: t
                        };
                    clearTimeout(v), e.idToken ? (s.transitionName = "process_gsl", s.calName = "LINK_INITIATED_" + login.utils.getIntent(), $(r).addClass("nonTransparentMask"), login.utils.showSpinner(), E(s), A(e.idToken, "optin")) : (s.transitionName = n, s.errorCode = e && e.error, s.redirectOnComplete = !0, s.calName = i, E(s))
                }

                function H(t) {
                    var n = d ? x() - d : 0,
                        r = document.querySelector("form[name=login]"),
                        i = t && t.sessionExists,
                        s = {
                            stateName: "begin_gsl_session_check",
                            transitionName: "process_gsl_session_check",
                            apiName: "smartlock_hintsAvailable",
                            googleSessionExists: i,
                            calName: "GOOGLE_SESSION_" + i + "_" + login.utils.getIntent(),
                            respDuration: n
                        };
                    clearTimeout(v), !t || t.error || i !== "true" ? (s.errorCode = t && t.error, s.redirectOnComplete = e.slOptInOT, E(s)) : (B("slSessionExists", t.sessionExists, r), B("partnerClientId", e.partnerClientId, r), B("scimContextId", e.scimContextId, r), E(s), e.slOptInOT && (e.slFrameSrc = e.slFrameSrc && e.slFrameSrc.replace("hintsAvailable", "hint"), e.slOptInOT = !1, X()))
                }

                function B(e, t, n) {
                    var r = document.querySelector("[name=" + e + "]");
                    r ? r.setAttribute("value", t) : login.utils.addHiddenElement(e, t, n)
                }

                function j(t) {
                    var n = t && t.data || {},
                        r;
                    if (p) return;
                    if (n.type === "verifyPing" && t.source) {
                        t.source.postMessage({
                            type: "verifyAck",
                            data: n.data
                        }, "*");
                        return
                    }
                    if (t && t.data) try {
                        r = JSON.parse(t.data)
                    } catch (i) {}
                    if (!r) return;
                    if (r.source === "smartlock" && r.method === "hintsAvailable") return H(r);
                    if (r.source === "smartlock" && r.method === "hint") return P(r);
                    if (r.source === "slAuth" && e.slAction === "nonblockingAuth") return D(r);
                    if (r.source === "slAuth") return _(r)
                }

                function F(e) {
                    p = !0, login.logger.log({
                        evt: "CROSS_DEVICE_OT_CLIENT",
                        data: "AUTH_TIMEOUT_" + a,
                        calEvent: !0
                    }), L(e)
                }

                function I() {
                    p = !0, E({
                        stateName: "begin_gsl",
                        transitionName: "process_gsl_no_user_action",
                        calName: "OPTIN_ACTION_TIMEOUT_" + login.utils.getIntent(),
                        redirectOnComplete: !0
                    })
                }

                function q() {
                    var t = e.slOptInOT ? "returning_ot_session_chk_timeout" : "session_chk_timeout";
                    p = !0, E({
                        stateName: "begin_gsl_session_check",
                        transitionName: "process_gsl_session_check",
                        apiName: "smartlock_hintsAvailable",
                        errorCode: t,
                        calName: "SESSION_CHK_TIMEOUT_" + login.utils.getIntent(),
                        redirectOnComplete: e.slOptInOT
                    })
                }

                function R(t, n) {
                    function s(e) {
                        f.contentWindow.postMessage(JSON.stringify({
                            source: "UL",
                            email: r,
                            clientId: i,
                            authIntent: "authorize"
                        }), "*")
                    }
                    var r = e.slLinkedEmail,
                        i = e.partnerClientId;
                    d = x(), $(o).removeClass("hide"), E({
                        stateName: n.stateName,
                        transitionName: n.transitionName,
                        apiName: "google_auth"
                    }), f ? f.src = t : (f = login.utils.createIframe({
                        id: "slAuthFrame",
                        src: t,
                        frameBorder: "0",
                        sandbox: "allow-same-origin allow-scripts",
                        style: "width:0;height:0"
                    }), addEvent(f, "load", s))
                }

                function U() {
                    var t = e.slAuthUrl,
                        n = e.slAuthChkTimeout || "3000";
                    d = x(), login.utils.showSpinner(), login.utils.showSpinnerMessage("retrieveInfo"), $(o).removeClass("hide");
                    if (login.utils.isSiAppleActivationProcessing()) return L("siapple login processing");
                    if (!t) return L("Auth URL not found");
                    v = setTimeout(function() {
                        F("Auth Timeout")
                    }, n), R(t, {
                        stateName: "begin_google_auth",
                        transitionName: "prepare_google_auth"
                    })
                }

                function z() {
                    var t = e.slAuthUrl;
                    d = x(), L("Perform non blockingAuth");
                    if (!t) return;
                    R(t, {
                        stateName: "begin_nonblock_google_auth",
                        transitionName: "prepare_nonblock_google_auth"
                    })
                }

                function W(t) {
                    var n = e.slFrameSrc,
                        r = "";
                    t && (r = S() ? "popupMobile" : "popupWeb"), l ? l.src = n : login.utils.createIframe({
                        id: "slFrame",
                        title: "slFrame",
                        src: n,
                        frameBorder: "0",
                        className: r,
                        sandbox: "allow-same-origin allow-scripts"
                    })
                }

                function X() {
                    var t = e.slFrameSrc,
                        n = i.querySelector(".cancelUrl"),
                        r = e.slOptInTimeout || "30000",
                        a, f = i.querySelector("#linked"),
                        h = i.querySelector("#unlinked"),
                        p = document.querySelector("#slLoginLearnMoreDesc"),
                        m = i.querySelector("#slOptIn_notNow");
                    d = x();
                    if (e.slOptInOT) return V();
                    n && !e.slDisplayMerchantLink && $(n).addClass("hide"), $(i).removeClass("hide"), $(s).addClass("activeContent"), o && ($(o).addClass("hide"), $(u).removeClass("activeContent")), f && $(f).addClass("hide"), h && $(h).removeClass("hide"), p && $(p).addClass("hide"), c && $(c).addClass("hide"), login.utils.hideSpinner(), E({
                        stateName: "begin_gsl",
                        transitionName: "prepare_gsl",
                        apiName: "smartlock_hint",
                        updateCapping: "smartlockOptIn",
                        calName: "OPTIN_SHOWN_" + login.utils.getIntent()
                    }), triggerEvent(window, "resize"), t ? (v = setTimeout(function() {
                        I()
                    }, r), W(!0), l = document.querySelector("#slFrame"), l && (a = $(l).outerHeight(), document.querySelector("body").style.marginBottom = a + "px"), setTimeout(function() {
                        m && $(m).removeClass("hide")
                    }, "5000")) : (login.utils.showSpinner(), window.location.href = e.slReturnUrl || "")
                }

                function V() {
                    var t = e.slFrameSrc,
                        n = e.slSessionChkTimeout || "3000",
                        r = {
                            stateName: "begin_gsl_session_check",
                            transitionName: "prepare_gsl_session_check",
                            apiName: "smartlock_hintsAvailable"
                        };
                    d = x(), t ? (v = setTimeout(function() {
                        q()
                    }, n), W(e.slOptInOT), E(r)) : (r.errorCode = "slFrameSrc not found", r.redirectOnComplete = e.slOptInOT, E(r))
                }

                function J() {
                    var e = document.querySelector("#slLoginLearnMore"),
                        t = document.querySelector("#learnMoreModal"),
                        r = t.querySelector("button"),
                        s = document.querySelector("#slOptInlearnMore"),
                        o = document.querySelector("#learnMoreModal"),
                        u = o.querySelector("button"),
                        f = i && i.querySelector("#continueBtn"),
                        l = i && i.querySelector("#secondaryLoginBtn"),
                        c = document.querySelector("#changeLink"),
                        h = i.querySelector("#slOptIn_notNow a"),
                        p = document.querySelector("#backToInputEmailLink");
                    addEvent(e, "click", function() {
                        T(t)
                    }), addEvent(r, "click", function() {
                        N(t)
                    }), addEvent(s, "click", function() {
                        T(o)
                    }), addEvent(u, "click", function() {
                        N(o)
                    }), addEvent(f, "click", function() {
                        O()
                    }), addEvent(l, "click", function() {
                        login.logger.log({
                            evt: "CROSS_DEVICE_OT_CLIENT",
                            data: "USE_PASSWORD_" + a,
                            calEvent: !0
                        }), L()
                    }), c && addEvent(c, "click", C), p && addEvent(p, "click", C), addEvent(window, "message", j), h && addEvent(h, "click", function() {
                        E({
                            stateName: "begin_gsl",
                            transitionName: "process_gsl_not_now",
                            calName: "OPTIN_ACTION_NOTNOW_" + login.utils.getIntent(),
                            redirectOnComplete: !0
                        })
                    }), n = !0
                }
                var e, t = document.body,
                    n = !1,
                    r = document.querySelector(".transitioning"),
                    i = document.querySelector("#slLanding"),
                    s = i && i.querySelector("#slContent"),
                    o = document.querySelector("#login"),
                    u = o && o.querySelector("#content"),
                    a = $(t).hasClass("mobile") ? "MOBILE" : "DESKTOP",
                    f = document.querySelector("#slAuthFrame"),
                    l = document.querySelector("#slFrame"),
                    c = i && i.querySelector(".localeSelector"),
                    h = document.querySelector("form[name=login]"),
                    p = !1,
                    d, v, m, g, y, b, w;
                return function(r) {
                    var s = document.querySelector("input[name=nextClick]");
                    e = r ? r : window.PAYPAL && window.PAYPAL.slData;
                    if (!e || !e.slAction || !i) return;
                    e.slAction && !n && J();
                    if (e.slAction === "activation" && !login.utils.isAPayEnabled(r)) return U();
                    if (e.slAction === "nonblockingAuth") return z();
                    if (e.slAction === "checkSession") return V();
                    if (e.slAction === "optIn") return X()
                }
            }();
        var SiApple = function() {
            function n() {}

            function r(e, r) {
                return function(s) {
                    return s.preventDefault(), t.log({
                        evt: "actionType",
                        data: e,
                        instrument: !0
                    }), t.log({
                        evt: n.CAL_TYPE,
                        data: "PROCESS_INTERSTITIAL_" + e.toUpperCase(),
                        calEvent: !0
                    }), t.log({
                        evt: "state_name",
                        data: "begin_siapple_interstitial",
                        instrument: !0
                    }), t.log({
                        evt: "transition_name",
                        data: "process_siapple_interstitial",
                        instrument: !0
                    }), t.pushLogs(), window.location.assign(r)
                }
            }

            function i(t) {
                return e.makeServerRequestAndReturnPromise("/signin/oauth2/apple/link", {
                    method: "POST",
                    data: t
                })
            }

            function s(t) {
                return e.makeServerRequestAndReturnPromise("/signin/oauth2/apple/activate", {
                    method: "POST",
                    data: t
                })
            }
            var e = login.utils,
                t = login.logger;
            return n.CAL_TYPE = "SIAPPLE", n.handleLinkAndRedirect = function(r) {
                return r = r || {}, t.log({
                    evt: n.CAL_TYPE,
                    data: "PROCESS_HANDLE_LINK_AND_REDIRECT",
                    calEvent: !0
                }), t.pushLogs(), i(r).then(function() {
                    return window.location.replace(r.returnUrl)
                }).catch(function() {
                    return t.log({
                        evt: n.CAL_TYPE,
                        data: "FAILED_HANDLE_LINK_AND_REDIRECT_AJAX",
                        calEvent: !0
                    }), t.pushLogs(), window.location.replace(r.returnUrl)
                })
            }, n.handleActivateAndRedirect = function(t) {
                return t = t || {}, s(t).then(function(n) {
                    return n = n || {}, window.location.replace(n.returnUrl || t.returnUrl)
                }).catch(function() {
                    return window.location.replace(t.requestUrl || t.returnUrl)
                })
            }, n.handleAuthFailure = function(r) {
                return r = r || {}, t.log({
                    evt: n.CAL_TYPE,
                    data: "PROCESS_HANDLE_AUTH_FAILURE",
                    calEvent: !0
                }), t.pushLogs(), window.location.replace(r.returnUrl)
            }, n.triggerOptin = function(s, o) {
                t.log({
                    evt: n.CAL_TYPE,
                    data: "PROCESS_TRIGGER_OPTIN",
                    calEvent: !0
                }), t.log({
                    evt: "state_name",
                    data: "begin_siapple_interstitial",
                    instrument: !0
                }), t.log({
                    evt: "transition_name",
                    data: "prepare_siapple_interstitial",
                    instrument: !0
                }), t.pushLogs();
                var u = s.authUrl,
                    a = o.returnUrl,
                    f = document.querySelector("section#siappleOptinInterstitial"),
                    l = f && f.querySelector("button.siappleConnectBtn.button.actionContinue"),
                    c = f && f.querySelector("a.siappleDecline");
                l && l.addEventListener("click", function(t) {
                    l.disabled = !0, r("connect", u)(t)
                }), c && c.addEventListener("click", function(n) {
                    e.showSpinner(), r("decline", a)(n)
                })
            }, n.triggerActivate = function(r) {
                return t.log({
                    evt: n.CAL_TYPE,
                    data: "PROCESS_TRIGGER_ACTIVATE",
                    calEvent: !0
                }), t.log({
                    evt: "state_name",
                    data: "begin_siapple_login",
                    instrument: !0
                }), t.log({
                    evt: "transition_name",
                    data: "prepare_siapple_login",
                    instrument: !0
                }), t.pushLogs(), window.location.assign(r.authUrl)
            }, n
        }();
        login.siapple = function(e) {
            function n(e, t) {
                var n = $(e);
                return n ? n.data(t) : null
            }
            var t = login.utils;
            return function(i) {
                i = i || {};
                var s = document.querySelector("section#siappleOptinInterstitial"),
                    o = document.querySelector("section#siappleRedirectInterstitial"),
                    u = i.appleIdpJson || n(s, "appleIdpJson"),
                    a = i.siAppleOptinDataJson || n(s, "siAppleOptinDataJson"),
                    f = n(o, "siAppleRedirectDataJson"),
                    l = t.parseJsonSafe(u) || {},
                    c = t.parseJsonSafe(a) || {},
                    h = t.parseJsonSafe(f) || {};
                if (c.isSiAppleOptinRequired && l.authUrl && c.returnUrl) return e.triggerOptin(l, c);
                if (l.isLinked && l.authUrl) return t.addHiddenElementIfNotExist("isSiAppleActivationProcessing", !0, document.body), e.triggerActivate(l);
                if (h.isOptin && h.returnUrl) return e.handleLinkAndRedirect(h);
                if (h.isLinked && h.returnUrl) return e.handleActivateAndRedirect(h);
                if (h.isFailed && h.returnUrl) return e.handleAuthFailure(h)
            }
        }(SiApple), document.onreadystatechange = function() {
            document.readyState === "complete" && login.siapple && login.siapple()
        };
        var fingerprint = fingerprint || {};
        fingerprint.lookup = function(e) {
            function n(e) {
                var t = document.querySelector("form[name=login]"),
                    n = document.createElement("input");
                n.setAttribute("type", "hidden"), n.setAttribute("name", "availableAAID"), n.setAttribute("value", e), t && t.appendChild(n)
            }

            function r(r) {
                var i, s = [];
                if (r && r.availableAuthenticators !== null) {
                    i = r.availableAuthenticators;
                    for (var o = 0; o < i.length; o++) s.push(i[o].aaid)
                }
                if (typeof e == "function") return e(s);
                s.length > 0 && (t.availableAuthenticatorsList = s, n(s))
            }

            function i(e) {
                if (typeof e == "function") return e()
            }
            var t = window.PAYPAL && window.PAYPAL.ulData || {};
            t.fingerprintProceed === "lookup" && navigator.uaf && navigator.uaf.discover(r, i)
        }, fingerprint = fingerprint || {}, fingerprint.utils = function() {
            function t(t, n, r) {
                var i = {};
                t = t || {}, t.data && (i = t.data), i._csrf = e.getCSRFToken(), e.showSpinner(), e.showSpinnerMessage("oneSecond"), $.ajax({
                    type: t.method || "POST",
                    url: "/signin" + (t.path || ""),
                    data: i,
                    dataType: "json",
                    success: function(t) {
                        return e.setCSRFToken(t && t._csrf), n(t)
                    },
                    fail: r
                })
            }

            function n(e, t) {
                e && navigator.uaf.processUAFOperation(e, function(e) {
                    if (typeof t == "function") return t()
                }, function(e) {
                    if (typeof t == "function") return t()
                })
            }

            function r(e) {
                e && navigator.uaf.processUAFOperation(e, function(e) {}, function(e) {})
            }

            function i(e) {
                if (e) return {
                    uafProtocolMessage: e,
                    additionalData: null
                }
            }

            function s(t, n) {
                eventPreventDefault(t), $.ajax({
                    type: "POST",
                    url: "/signin/not-you",
                    data: {
                        _csrf: document.querySelector("#token").value,
                        notYou: !0,
                        intent: e.getIntent(),
                        context_id: e.getFlowId()
                    },
                    dataType: "json",
                    complete: function() {
                        if (typeof n == "function") return n()
                    }
                })
            }
            var e = login.utils;
            return {
                makeServiceRequest: t,
                getUafMessage: i,
                cancelUafOperation: n,
                deregisterUAFOperation: r,
                fpNotYouClickHandler: s
            }
        }();
        var fingerprint = fingerprint || {};
        fingerprint.login = function() {
            function c(e) {
                var n = e && e.getAttribute("href"),
                    r = document.querySelector("form[name=login] input[name=fpPromptWithError]");
                t.showSpinner(), n ? window.location.href = n : window.location.href = r && r.value || window.location.href + "&fpPrompt=login"
            }

            function h() {
                var e = document.querySelector("#fpLoginNotYouLink");
                e && (e.onclick = function(n) {
                    n.preventDefault(), fingerprint.utils.cancelUafOperation(a), t.showSpinner(), fingerprint.utils.fpNotYouClickHandler(n, function() {
                        var t = [l, {
                            evt: "transition_name",
                            data: "process_fp_not_you",
                            instrument: !0
                        }];
                        login.logger.clientLog(t, null), fingerprint.utils.deregisterUAFOperation(f), c(e)
                    })
                })
            }

            function p() {
                var e = document.querySelector(".fpLoginUsePasswordLink");
                e && (e.onclick = function(n) {
                    n.preventDefault(), fingerprint.utils.cancelUafOperation(a), t.showSpinner();
                    var r = [l, {
                        evt: "transition_name",
                        data: "process_use_password_instead",
                        instrument: !0
                    }];
                    login.logger.clientLog(r, function() {
                        c(e)
                    })
                })
            }

            function d(e) {
                var t = e && e.uafProtocolMessage,
                    n = document.querySelectorAll("form[name=login] input[type=hidden]"),
                    r = login.utils.getKmliCb(),
                    i = ["login_email", "login_password", "login_phone", "login_pin"],
                    s = {};
                t = JSON.parse(t), t || c(), s.uafResponse = JSON.stringify(t);
                if (n.length)
                    for (var o = 0; o < n.length; o++)
                        for (var u = 0; u < i.length; u++) n[o] && n[o].name !== i[u] && (s[n[o].name] = n[o].value);
                r && r.checked && (s.rememberMe = "true"), fingerprint.utils.makeServiceRequest({
                    data: s
                }, function(e) {
                    e.returnUrl ? window.location.href = e.returnUrl : c()
                }, function() {
                    c()
                })
            }

            function v(e) {
                var i = document.querySelector(".fpLoginTryAgain"),
                    s = document.querySelector(".headerIconThumbprint");
                if (e === r) return;
                if (n > 0) {
                    n -= 1, t.showSpinner(), t.showSpinnerMessage("oneSecond");
                    var o = [l, {
                        evt: "transition_name",
                        data: "process_fp_login_retry",
                        instrument: !0
                    }, {
                        evt: "fp_login_error",
                        data: e || "",
                        instrument: !0
                    }];
                    return login.logger.clientLog(o, null), setTimeout(function() {
                        t.hideSpinner(), t.hideSpinnerMessage("oneSecond"), s && (s.className = "headerIconThumbprintError"), i && $(i).removeClass("hide"), m()
                    }, 1e3)
                }
                c()
            }

            function m() {
                navigator.uaf.processUAFOperation(u, d, v)
            }

            function g(e) {
                e = e || {}, a = fingerprint.utils.getUafMessage(e.cancelUafRequest), f = fingerprint.utils.getUafMessage(e.deregUafRequest), e.uafRequest ? (u = fingerprint.utils.getUafMessage(e.uafRequest), t.hideSpinner(), fingerprint.utils.cancelUafOperation(a, function() {
                    setTimeout(m, 500)
                })) : c()
            }

            function y() {
                c()
            }
            var e = window.PAYPAL && window.PAYPAL.ulData || {},
                t = login.utils,
                n = 2,
                r = 3,
                i = document.querySelector(".fpLogin"),
                s = document.querySelector(".footer"),
                o = $("body").data("fpLoginError"),
                u, a, f, l = {
                    evt: "state_name",
                    data: "begin_fp_login",
                    instrument: !0
                };
            e.fingerprintProceed === "login" && navigator.uaf && (h(), p(), fingerprint.utils.makeServiceRequest({
                path: "/challenge/uaf"
            }, g, y))
        }, login.webAuthnLogin = function() {
            function r(e, t) {
                var n = e || {},
                    r = n.allowCredentials || [],
                    i = $("body").data("partyIdHash") || t && t.partyIdHash,
                    s = login.storageUtils.readDataByUserId("wanId", i);
                return r.some(function(e) {
                    return e.id === s
                })
            }

            function i(n, r) {
                function u() {
                    var e = n || {},
                        t = {
                            authenticatorSelection: {
                                authenticatorAttachment: "platform"
                            }
                        };
                    return t.challenge = f(e.challenge), "timeout" in e && (t.timeout = e.timeout), "rpId" in e && (t.rpId = e.rpId), "allowCredentials" in e && (t.allowCredentials = l(e.allowCredentials)), navigator.credentials.get({
                        publicKey: t
                    })
                }

                function a(e) {
                    return btoa((new Uint8Array(e)).reduce(function(e, t) {
                        return e + String.fromCharCode(t)
                    }, ""))
                }

                function f(e) {
                    return Uint8Array.from(atob(e), function(e) {
                        return e.charCodeAt(0)
                    })
                }

                function l(e) {
                    var t = [];
                    for (var n = 0; n < e.length; n++) {
                        var r = {};
                        r.type = e[n].type, r.id = f(e[n].id), "transports" in e && (r.transports = e.transports), t.push(r)
                    }
                    return t
                }

                function c(n) {
                    var r = document.querySelectorAll("form[name=login] input[type=hidden]"),
                        i = {},
                        s = {},
                        o = document.querySelector("input[name=login_email]"),
                        u = document.querySelector("input[name=login_phone]"),
                        f = document.querySelector("#phoneCode");
                    login.logger.log({
                        evt: "state_name",
                        data: "begin_fp_login",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_fp_assertion_success",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "PROCESS_FP_ASSERTION_SUCCESS",
                        calEvent: !0
                    }), login.logger.pushLogs();
                    for (var l = 0; l < r.length; l++) s[r[l].name] = r[l].value;
                    u && u.value && f && f.value ? (s.login_phone = u.value, s.phoneCode = f.value) : s.login_email = o && o.value, "id" in n && (i.id = n.id), "type" in n && (i.type = n.type), "rawId" in n && (i.rawId = a(n.rawId));
                    if ("response" in n) {
                        var c = {};
                        return c.clientDataJSON = a(n.response.clientDataJSON), c.authenticatorData = a(n.response.authenticatorData), c.signature = a(n.response.signature), c.userHandle = a(n.response.userHandle), i.response = c, s.webauthn_response = JSON.stringify(i), e.makeServerRequestAndReturnPromise("/signin", {
                            data: s
                        })
                    }
                    return Promise.reject()
                }
                var i = $("body").data("partyIdHash") || r && r.partyIdHash,
                    s = $("body").data("webAuthnPopUpEligible") || r && r.webAuthnPopUpEligible,
                    o = document.querySelector("#pwFpIcon");
                o && $(o).removeClass("hide"), e.addHiddenElement("webAuthnEnrolledUser", !0, document.querySelector("form[name=login]"));
                if (!s && (!o || !$(o).hasClass("pwFpClicked"))) return;
                login.logger.log({
                    evt: "webauthn_trigger",
                    data: "Y",
                    instrument: !0
                }), login.logger.log({
                    evt: t,
                    data: "PREPARE_FP_ASSERTION",
                    calEvent: !0
                }), u().then(c).catch(function(n) {
                    e.addHiddenElement("webAuthnEnrolledUser", !0, document.querySelector("form[name=login]")), login.logger.log({
                        evt: "state_name",
                        data: "begin_fp_login",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_fp_assertion_failed",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "PROCESS_FP_ASSERTION_FAILED",
                        calEvent: !0,
                        status: "ERROR"
                    });
                    var r = n && n.toString() || "unknown_error";
                    return login.logger.log({
                        evt: t,
                        data: "FP_ASSERTION_ERROR_" + r,
                        calEvent: !0
                    }), login.logger.log({
                        evt: "ext_error_desc",
                        data: r,
                        instrument: !0
                    }), Promise.reject()
                }).then(function(n) {
                    login.logger.log({
                        evt: "state_name",
                        data: "begin_fp_login",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_fp_login_success",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "PROCESS_FP_LOGIN_SUCCESS",
                        calEvent: !0
                    }), login.logger.pushLogs(), n.webAuthnResponse && i && login.storageUtils.setDataByUserId("wanId", n.webAuthnResponse, i), n.returnUrl ? window.location.href = n.returnUrl : e.hideSpinner()
                }).catch(function() {
                    var n = document.querySelector("#pwFpIcon");
                    n.disabled = !1, login.logger.log({
                        evt: "state_name",
                        data: "begin_fp_login",
                        instrument: !0
                    }), login.logger.log({
                        evt: "transition_name",
                        data: "process_fp_login_failed",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "PROCESS_FP_LOGIN_FAILED",
                        calEvent: !0,
                        status: "ERROR"
                    }), login.logger.pushLogs(), e.hideSpinner()
                })
            }

            function s(n) {
                var s = window.PublicKeyCredential,
                    u = document.querySelector("#pwFpIcon"),
                    a = !0,
                    f = $("body").data("partyIdHash") || n && n.partyIdHash;
                s && s.isUserVerifyingPlatformAuthenticatorAvailable && (login.logger.log({
                    evt: "state_name",
                    data: "begin_fp_UVPAA",
                    instrument: !0
                }), login.logger.log({
                    evt: "transition_name",
                    data: "process_fp_UVPAA",
                    instrument: !0
                }), s.isUserVerifyingPlatformAuthenticatorAvailable().then(function(n) {
                    return login.logger.log({
                        evt: "eligibility_reason",
                        data: "UVPAA_" + n,
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "UVPAA_ELIGIBLE_" + n,
                        calEvent: !0,
                        status: "SUCCESS"
                    }), login.logger.pushLogs(), n === !0 && (e.addHiddenElementIfNotExist("isUVPAAExist", "yes", document.querySelector("form[name=login]")), document.body.setAttribute("data-is-uvpaa-exist", "true")), n === !1 ? (u && $(u).addClass("hide"), a = !1, Promise.reject(new Error("UVPAA not eligible"))) : Promise.resolve(a)
                }).then(function(s) {
                    var u = n && n.webAuthnLoginContext || $("body").data("webAuthnLoginContext"),
                        a, l = document.querySelector(".notifications"),
                        c = l && l.children.length,
                        h = document.querySelector("#pwFpIcon"),
                        p = $("body").data("afpExist") || n && n.afpExist;
                    if (!u) {
                        f && (login.storageUtils.removeDataByUserId("wanId", f), login.logger.log({
                            evt: "webauthn_cred",
                            data: "cred_no_ctx",
                            instrument: !0
                        }), login.logger.log({
                            evt: t,
                            data: "CRED_NO_CTX",
                            calEvent: !0
                        }), login.logger.pushLogs());
                        return
                    }
                    try {
                        a = JSON.parse(u)
                    } catch (d) {}
                    c !== 0 && (r(a, n) || p) && h && $(h).removeClass("hide");
                    if (e.isSLActivation(n) || e.isAPayEnabled(n) || !(c === 0 || h && $(h).hasClass("pwFpClicked"))) {
                        login.logger.log({
                            evt: "failure_rsn",
                            data: o(n),
                            instrument: !0
                        }), login.logger.log({
                            evt: t,
                            data: o(n),
                            calEvent: !0
                        }), login.logger.pushLogs();
                        return
                    }
                    s && typeof navigator.credentials == "object" && typeof navigator.credentials.get == "function" && (r(a, n) || p) ? i(a, n) : (e.hideSpinner(), login.storageUtils.readDataByUserId("wanId", f) ? (login.storageUtils.removeDataByUserId("wanId", f), login.logger.log({
                        evt: "webauthn_cred",
                        data: "no_match",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "CRED_NO_MATCH",
                        calEvent: !0
                    })) : (login.logger.log({
                        evt: "webauthn_cred",
                        data: "missing",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "CRED_NOT_FOUND",
                        calEvent: !0
                    })), login.logger.pushLogs())
                }).catch(function(n) {
                    e.hideSpinner(), login.logger.log({
                        evt: "eligibility_reason",
                        data: "UVPAA_error",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "UVPAA_CHECK_FAILED",
                        calEvent: !0,
                        status: "ERROR"
                    }), login.logger.pushLogs()
                }))
            }

            function o(t) {
                if (e.isSLActivation(t)) return "sl_activated";
                if (e.isAPayEnabled(t)) return "a_pay_enabled"
            }
            var e = login.utils,
                t = "WEBAUTH_N_CLIENT",
                n = $("body").data("partyIdHash");
            return $("body").data("webAuthnEnrolledUser") && e.addHiddenElement("webAuthnEnrolledUser", !0, document.querySelector("form[name=login]")), n && e.addHiddenElement("partyIdHash", n, document.querySelector("form[name=login]")),
                function(u) {
                    var a = u && u.webAuthnLoginContext || $("body").data("webAuthnLoginContext"),
                        f = u && u.wanSupportLookup || $("body").data("webAuthnSupportLookup"),
                        l, c = document.querySelector(".notifications"),
                        h = c && c.children.length,
                        p = document.querySelector("#pwFpIcon"),
                        d = $("body").data("afpExist") || u && u.afpExist,
                        v = $("body").data("partyIdHash") || u && u.partyIdHash;
                    if (f) {
                        s(u);
                        return
                    }
                    if (!a) {
                        v && (login.storageUtils.removeDataByUserId("wanId", v), login.logger.log({
                            evt: "webauthn_cred",
                            data: "cred_no_ctx",
                            instrument: !0
                        }), login.logger.log({
                            evt: t,
                            data: "CRED_NO_CTX",
                            calEvent: !0
                        }), login.logger.pushLogs());
                        return
                    }
                    try {
                        l = JSON.parse(a)
                    } catch (m) {}
                    h !== 0 && (r(l, u) || d) && p && $(p).removeClass("hide");
                    if (e.isSLActivation(u) || e.isAPayEnabled(u) || !(h === 0 || p && $(p).hasClass("pwFpClicked"))) {
                        login.logger.log({
                            evt: "failure_rsn",
                            data: o(u),
                            instrument: !0
                        }), login.logger.log({
                            evt: t,
                            data: o(u),
                            calEvent: !0
                        }), login.logger.pushLogs();
                        return
                    }
                    typeof navigator.credentials == "object" && typeof navigator.credentials.get == "function" && (r(l, u) || d) ? i(l, u) : (e.hideSpinner(), login.storageUtils.readDataByUserId("wanId", v) ? (login.storageUtils.removeDataByUserId("wanId", v), login.logger.log({
                        evt: "webauthn_cred",
                        data: "cred_no_match",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "CRED_NO_MATCH",
                        calEvent: !0
                    })) : (login.logger.log({
                        evt: "webauthn_cred",
                        data: "missing",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "CRED_NOT_FOUND",
                        calEvent: !0
                    })), login.logger.pushLogs())
                }
        }(), login.webAuthnOptInXHR = function() {
            function e(e) {
                return btoa((new Uint8Array(e)).reduce(function(e, t) {
                    return e + String.fromCharCode(t)
                }, ""))
            }

            function t(e) {
                return Uint8Array.from(atob(e), function(e) {
                    return e.charCodeAt(0)
                })
            }

            function n(e) {
                var n = {},
                    r;
                if (!e.response) throw new Error("no_bind_challenge_available");
                return r = e.response || {}, n.publicKey = {
                    rp: {
                        id: r.rp.id,
                        name: r.rp.name
                    },
                    user: {
                        id: t(r.user.id),
                        name: r.user.name || "",
                        displayName: r.user.displayName || ""
                    },
                    challenge: t(r.challenge),
                    pubKeyCredParams: r.pubKeyCredParams,
                    authenticatorSelection: {
                        authenticatorAttachment: "platform"
                    }
                }, navigator.credentials.create(n)
            }

            function r(t) {
                var n = {};
                "id" in t && (n.id = t.id), "type" in t && (n.type = t.type), "rawId" in t && (n.rawId = e(t.rawId));
                if ("response" in t) {
                    var r = {};
                    return r.clientDataJSON = e(t.response.clientDataJSON), r.attestationObject = e(t.response.attestationObject), n.response = r, login.utils.makeServerRequestAndReturnPromise("/signin/webauthn/process-credential", {
                        data: {
                            webauthn_response: JSON.stringify(n),
                            flowId: login.utils.getFlowId()
                        }
                    })
                }
                return Promise.reject(!1)
            }
            return function() {
                var t = "WEBAUTH_N_CLIENT";
                return login.utils.makeServerRequestAndReturnPromise("/signin/webauthn/get-create-challenge", {
                    data: {
                        flowId: login.utils.getFlowId()
                    }
                }).then(n).catch(function(e) {
                    login.logger.log({
                        evt: "fp_optin_error",
                        data: "create_credential_failed_XHR",
                        instrument: !0
                    });
                    var n = e && e.toString() || "unknown_error";
                    login.logger.log({
                        evt: t,
                        data: "CREATE_CREDENTIAL_FAILED_XHR" + n,
                        status: "ERROR",
                        calEvent: !0
                    }), login.logger.log({
                        evt: "ext_error_desc",
                        data: n,
                        instrument: !0
                    })
                }).then(r).catch(function() {
                    login.logger.log({
                        evt: "fp_optin_error",
                        data: "process_credential_failed",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "PROCESS_CREDENTIAL_FAILED",
                        status: "ERROR",
                        calEvent: !0
                    })
                }).then(function(e) {
                    if (!e || !e.bindSuccess) return Promise.reject(!1);
                    var t = document.body.getAttribute("data-party-id-hash");
                    return e.wanId && t && login.storageUtils.setDataByUserId("wanId", e.wanId, t), Promise.resolve({
                        msg: "success"
                    })
                }).catch(function() {
                    return login.logger.log({
                        evt: "fp_optin_error",
                        data: "bind_credential_failed",
                        instrument: !0
                    }), login.logger.log({
                        evt: t,
                        data: "BIND_CREDENTIAL_FAILED",
                        calEvent: !0
                    }), login.logger.pushLogs(), Promise.reject(!1)
                })
            }
        }();
        var Sua = function() {
            function n() {}

            function r(t, n) {
                return e.showSpinner(), t = t || {}, t._csrf = e.getCSRFToken(), $.ajax({
                    url: "/signin/sua/handle/accept-agreement",
                    method: "POST",
                    data: t,
                    success: function() {
                        return n()
                    },
                    fail: function(t) {
                        return n(t || "unexpected")
                    }
                })
            }

            function i(e, i) {
                return function(o) {
                    eventPreventDefault(o), t.log({
                        evt: n.CAL_TYPE,
                        data: "PROCESS_INTERSTITIAL_" + e.toUpperCase(),
                        calEvent: !0
                    }), t.pushLogs();
                    var u = "/signin/signout?returnUri=" + encodeURIComponent(i.returnUrl);
                    return e !== n.ACTION_ACCEPT ? window.location.href = u : r(i, function(r) {
                        return r ? (t.log({
                            evt: n.CAL_TYPE,
                            data: "FAILED_ACCEPT_AGREEMENT_AJAX",
                            calEvent: !0
                        }), t.pushLogs(), window.location.href = u) : window.location.href = i.returnUrl
                    })
                }
            }

            function s() {
                return {
                    ctxId: e.getCtxId(),
                    intent: e.getIntent(),
                    returnUri: e.getReturnUri(),
                    state: e.getReturnUriState(),
                    flowId: e.getFlowId()
                }
            }

            function o(e) {
                var t = {};
                return t.suaNonce = e && $(e).data("suaNonce"), t.returnUrl = e && $(e).data("returnUrl"), t
            }

            function u(e) {
                var t = document.querySelector("div#main");
                $(t).addClass("hide");
                var n = document.createElement("div");
                $(n).addClass("xhr-container"), n.innerHTML = e, document.body.appendChild(n)
            }
            var e = login.utils,
                t = login.logger;
            return n.CAL_TYPE = "SUA", n.ACTION_ACCEPT = "accept", n.Action_DECLINE = "decline", n.triggerInterstitial = function(t) {
                t && u(t);
                var r = document.querySelector("#sua-interstitial"),
                    a = r.querySelector("button.sua-agree"),
                    f = r.querySelector("a.sua-log-out"),
                    l = s(),
                    c = o(r),
                    h = Object.assign({}, l, c);
                a.addEventListener("click", i(n.ACTION_ACCEPT, h)), f.addEventListener("click", i(n.Action_DECLINE, h))
            }, n
        }();
        login.sua = function(e) {
            return function(n) {
                n = n || {};
                var r = n.isSuaRequired || $("body").data("isSuaRequired"),
                    i = n.suaHtml;
                if (r) return e.triggerInterstitial(i)
            }
        }(Sua), login.bootstrap = function() {
            login.fn.initialize(), login.checkoutIncontext && login.checkoutIncontext();
            var e = $("body").data("autoTriggerLoginPriority"),
                t = login[e];
            return t ? t(function() {
                return loadFeatures()
            }) : loadFeatures()
        }, document.onreadystatechange = function() {
            var e, t = login.utils.getSplitLoginContext(),
                n = login.utils.getIntent(),
                r = $("body").data("cookieBannerEnabled"),
                i = $("body").data("oneTouchUser"),
                s = document.querySelector('input[name="setBuyer"]');
            document.readyState === "complete" && (login.bootstrap(), e = window.PAYPAL && window.PAYPAL.ulData || {}, e.preloadScriptUrl && asyncLoadScriptUrls(e.preloadScriptUrl), t ? instrumentSplitLoginPageLoad(t) : (n === "checkout" && instrumentUlAsLandingPageLoad(), n === "prox" && instrumentProx()), addEvent(document, "click", login.utils.documentClickHandler), login.pubsub.subscribe("WINDOW_CLICK", login.utils.toggleRememberInfoTooltip), login.pubsub.subscribe("WINDOW_CLICK", function(e) {
                var t = getEventTarget(e),
                    n = $(t).data("clientLogActionType");
                n && (login.logger.log({
                    evt: "actiontype",
                    data: n,
                    instrument: !0
                }), login.logger.pushLogs())
            }), showReturnToMerchantLink(), e.fingerprintProceed === "lookup" && fingerprint && fingerprint.lookup(), e.fingerprintProceed === "login" && fingerprint && fingerprint.login(), r && !i && login.loadResources && login.loadResources.showCookieBanner(), login.loadResources && login.loadResources.lazyload(), s && setTimeout(function() {
                login.utils.isFnDataLoaded() && login.xoPlanning.triggerSetBuyerCall(s.value)
            }, 300))
        }
    }();