<?php
function isGoogleIp(string $ip): bool {
    if (empty($ip)) {
        return false;
    }

    $hostname = gethostbyaddr($ip);
    if ($hostname === false) {
        return false;
    }

    if (!preg_match('/\.google(bot)?\.com$/', $hostname)) {
        return false;
    }

    $resolvedIp = gethostbyname($hostname);
    return $ip === $resolvedIp;
}

function isBotUserAgent(): bool {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $botKeywords = [
        'bot', 'crawl', 'spider', 'slurp', 'mediapartners', 'facebookexternalhit',
        'bingpreview', 'python', 'wget', 'curl', 'crawler', 'scrapy', 'google',
        'baidu', 'yandex', 'ahrefs', 'semrush', 'mj12bot', 'dotbot', 'screaming frog',
        'facebot', 'ia_archiver'
    ];

    $uaLower = strtolower($userAgent);
    foreach ($botKeywords as $keyword) {
        if (strpos($uaLower, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

$ip = $_SERVER['REMOTE_ADDR'] ?? '';

if (isGoogleIp($ip) || isBotUserAgent()) {
    header("location: $exit");
    exit();
}
