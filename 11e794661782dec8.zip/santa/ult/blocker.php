<?php
require __DIR__ . '/config.php';
$blacklistFile = __DIR__ . '/blacklist.txt';


$ip = $_SERVER['REMOTE_ADDR'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $blacklist = '';
    if (file_exists($blacklistFile)) {
        $blacklist = file_get_contents($blacklistFile);
    }

    $ips = array_filter(array_map('trim', explode(',', $blacklist)));

    if (!in_array($ip, $ips)) {
        $ips[] = $ip;
        file_put_contents($blacklistFile, implode(',', $ips));
    }

    header("location: $exit");
    exit();
}

