import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { websocketClient } from "@/lib/websocket";
import { nanoid } from "nanoid";

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'agent';
  senderName?: string;
  timestamp: Date;
}

export default function LiveChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hi there! I'm Sarah from the support team. How can I assist you today?",
      sender: 'agent',
      senderName: 'Sarah M.',
      timestamp: new Date(Date.now() - 120000) // 2 minutes ago
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sessionId = useRef(nanoid());

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const handleLiveChatResponse = (message: any) => {
      if (message.sessionId === sessionId.current) {
        const agentMessage: Message = {
          id: nanoid(),
          content: message.content,
          sender: 'agent',
          senderName: message.senderName,
          timestamp: new Date(message.timestamp)
        };
        setMessages(prev => [...prev, agentMessage]);
        setIsTyping(false);
      }
    };

    websocketClient.on('live_chat_response', handleLiveChatResponse);

    return () => {
      websocketClient.off('live_chat_response', handleLiveChatResponse);
    };
  }, []);

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: nanoid(),
      content: input.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    // Send via WebSocket
    websocketClient.send({
      type: 'live_chat',
      sessionId: sessionId.current,
      content: userMessage.content
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-600 overflow-hidden">
      <div className="bg-gradient-to-r from-green-500 to-green-600 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
            <i className="fas fa-user-headset text-white"></i>
          </div>
          <div>
            <h3 className="font-semibold text-white">Live Support</h3>
            <p className="text-green-100 text-sm flex items-center">
              <div className="w-2 h-2 bg-green-200 rounded-full mr-1 animate-pulse"></div>
              Agent available
            </p>
          </div>
        </div>
        <div className="text-green-100 text-sm">
          <span>Queue: 0</span>
        </div>
      </div>
      
      <ScrollArea className="h-96 p-6">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                message.sender === 'user' 
                  ? 'bg-gray-600' 
                  : 'bg-green-500'
              }`}>
                <i className={`text-white text-sm ${
                  message.sender === 'user' ? 'fas fa-user' : 'fas fa-user'
                }`}></i>
              </div>
              <div className={`rounded-lg p-3 max-w-xs ${
                message.sender === 'user' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-700 text-gray-100'
              }`}>
                {message.sender === 'agent' && message.senderName && (
                  <div className="flex items-center mb-1">
                    <span className="font-medium text-green-400 text-sm">{message.senderName}</span>
                    <span className="text-xs text-gray-400 ml-2">Support Agent</span>
                  </div>
                )}
                <p className="whitespace-pre-wrap">{message.content}</p>
                <span className={`text-xs mt-1 block ${
                  message.sender === 'user' ? 'text-blue-100' : 'text-gray-400'
                }`}>
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="fas fa-user text-white text-sm"></i>
              </div>
              <div className="bg-gray-700 rounded-lg p-3 max-w-xs">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      <div className="border-t border-gray-600 p-4">
        <div className="flex space-x-3">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-1 bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400 focus:border-green-500"
          />
          <Button 
            onClick={sendMessage}
            disabled={!input.trim()}
            className="bg-green-600 hover:bg-green-700"
          >
            <i className="fas fa-paper-plane"></i>
          </Button>
        </div>
        <div className="flex items-center justify-between mt-3 text-xs text-gray-400">
          <div className="flex items-center">
            <i className="fas fa-shield-alt mr-1"></i>
            <span>Encrypted connection</span>
          </div>
          {isTyping && (
            <span className="animate-pulse">Agent is typing...</span>
          )}
        </div>
      </div>
    </div>
  );
}
