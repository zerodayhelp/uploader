import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest } from "@/lib/queryClient";
import { nanoid } from "nanoid";

interface CommandEntry {
  id: string;
  command: string;
  output: string;
  timestamp: Date;
}

export default function CommandTerminal() {
  const [commands, setCommands] = useState<CommandEntry[]>([]);
  const [input, setInput] = useState("");
  const [isExecuting, setIsExecuting] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const sessionId = useRef(nanoid());

  const scrollToBottom = () => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [commands]);

  const executeCommand = async (command: string) => {
    if (!command.trim() || isExecuting) return;

    setIsExecuting(true);

    try {
      const response = await apiRequest('POST', '/api/execute-command', {
        command: command.trim(),
        sessionId: sessionId.current
      });

      const data = await response.json();
      
      const commandEntry: CommandEntry = {
        id: nanoid(),
        command: command.trim(),
        output: data.output,
        timestamp: new Date()
      };

      setCommands(prev => [...prev, commandEntry]);
      
      // Special handling for clear command
      if (data.output === 'CLEAR_TERMINAL') {
        setCommands([]);
      }
    } catch (error) {
      console.error('Command execution error:', error);
      const errorEntry: CommandEntry = {
        id: nanoid(),
        command: command.trim(),
        output: "Error: Failed to execute command",
        timestamp: new Date()
      };
      setCommands(prev => [...prev, errorEntry]);
    } finally {
      setIsExecuting(false);
      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeCommand(input);
    }
  };

  const clearTerminal = () => {
    setCommands([]);
    sessionId.current = nanoid();
  };

  const quickCommands = ['status', 'ping', 'logs', 'help'];

  return (
    <section className="mb-12">
      <div className="bg-gray-800 rounded-xl border border-gray-600 overflow-hidden">
        <div className="bg-gradient-to-r from-orange-500 to-red-600 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
              <i className="fas fa-terminal text-white"></i>
            </div>
            <div>
              <h3 className="font-semibold text-white">Command Interface</h3>
              <p className="text-orange-100 text-sm">Technical Support Terminal</p>
            </div>
          </div>
          <Button
            onClick={clearTerminal}
            variant="ghost"
            size="sm"
            className="text-orange-100 hover:text-white hover:bg-white/10"
          >
            <i className="fas fa-broom text-sm"></i>
          </Button>
        </div>
        
        <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-6">
          <ScrollArea className="min-h-[300px] max-h-96 mb-4">
            <div className="font-mono text-sm">
              <div className="text-green-500 mb-2">Support Terminal v2.1.0 - Type 'help' for available commands</div>
              <div className="text-gray-300 mb-4">Connected to support.server.local</div>
              
              {commands.map((entry) => (
                <div key={entry.id} className="mb-4 animate-in fade-in duration-300">
                  <div className="text-gray-100 mb-1">
                    <span className="text-green-500">support@terminal:~$</span> {entry.command}
                  </div>
                  <div className="text-gray-300 whitespace-pre-wrap ml-4">
                    {entry.output}
                  </div>
                </div>
              ))}
              
              {isExecuting && (
                <div className="text-gray-100 mb-1">
                  <span className="text-green-500">support@terminal:~$</span> {input}
                  <div className="text-gray-400 ml-4 animate-pulse">Executing...</div>
                </div>
              )}
              
              <div ref={terminalEndRef} />
            </div>
          </ScrollArea>
          
          <div className="flex items-center space-x-2">
            <span className="text-green-500 font-mono">support@terminal:~$</span>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Enter command..."
              className="flex-1 bg-transparent border-none text-gray-100 font-mono focus:ring-0 focus:border-none placeholder-gray-500"
              disabled={isExecuting}
            />
          </div>
        </div>
        
        <div className="bg-gray-700 px-6 py-3 border-t border-gray-600">
          <div className="flex flex-wrap gap-2 mb-3">
            {quickCommands.map((cmd) => (
              <Button
                key={cmd}
                onClick={() => executeCommand(cmd)}
                variant="outline"
                size="sm"
                className="bg-gray-600 hover:bg-gray-500 border-gray-500 text-gray-200 font-mono text-xs"
                disabled={isExecuting}
              >
                {cmd}
              </Button>
            ))}
          </div>
          <p className="text-xs text-gray-400">Quick commands - Click to execute or type manually</p>
        </div>
      </div>
    </section>
  );
}
