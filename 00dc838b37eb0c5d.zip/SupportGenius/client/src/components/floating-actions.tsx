import { Button } from "@/components/ui/button";

interface FloatingActionsProps {
  onQuickChatClick: () => void;
  onTelegramClick: () => void;
  onEmergencyClick: () => void;
}

export default function FloatingActions({ 
  onQuickChatClick, 
  onTelegramClick, 
  onEmergencyClick 
}: FloatingActionsProps) {
  return (
    <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-50">
      {/* Quick Chat FAB */}
      <Button
        onClick={onQuickChatClick}
        className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
      >
        <i className="fas fa-comment-dots text-xl"></i>
      </Button>
      
      {/* Telegram FAB */}
      <Button
        onClick={onTelegramClick}
        className="w-12 h-12 rounded-full bg-blue-500 hover:bg-blue-600 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
      >
        <i className="fab fa-telegram text-lg"></i>
      </Button>
      
      {/* Emergency FAB */}
      <Button
        onClick={onEmergencyClick}
        className="w-12 h-12 rounded-full bg-red-500 hover:bg-red-600 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
      >
        <i className="fas fa-exclamation text-lg"></i>
      </Button>
    </div>
  );
}
