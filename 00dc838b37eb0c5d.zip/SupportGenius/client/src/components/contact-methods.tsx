import { Button } from "@/components/ui/button";

export default function ContactMethods() {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold text-gray-100 mb-6">Other Ways to Reach Us</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Email Support */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-blue-400 transition-colors">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-envelope text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-100">Email Support</h3>
          </div>
          <p className="text-gray-300 mb-4">Send us detailed questions and get comprehensive responses.</p>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">General Support:</span>
              <span className="text-blue-400">help@company.com</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Technical Issues:</span>
              <span className="text-blue-400">tech@company.com</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Response Time:</span>
              <span className="text-green-500">{'< 4 hours'}</span>
            </div>
          </div>
        </div>

        {/* Phone Support */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-green-500 transition-colors">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-phone text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-100">Phone Support</h3>
          </div>
          <p className="text-gray-300 mb-4">Speak directly with our support specialists.</p>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Support Line:</span>
              <span className="text-green-500 font-mono">+1-800-SUPPORT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Emergency:</span>
              <span className="text-red-400 font-mono">+1-800-URGENT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Hours:</span>
              <span className="text-gray-200">24/7 Available</span>
            </div>
          </div>
        </div>

        {/* Knowledge Base */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-purple-400 transition-colors">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-book text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-100">Knowledge Base</h3>
          </div>
          <p className="text-gray-300 mb-4">Find instant answers in our comprehensive guides.</p>
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-200"
            >
              <i className="fas fa-arrow-right text-purple-400 mr-2"></i>
              Getting Started Guide
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-200"
            >
              <i className="fas fa-arrow-right text-purple-400 mr-2"></i>
              Troubleshooting
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-200"
            >
              <i className="fas fa-arrow-right text-purple-400 mr-2"></i>
              API Documentation
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
