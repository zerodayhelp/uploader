import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface QuickChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function QuickChatModal({ isOpen, onClose }: QuickChatModalProps) {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !message.trim() || isSubmitting) return;

    setIsSubmitting(true);

    try {
      await apiRequest('POST', '/api/support-request', {
        email: email.trim(),
        message: message.trim()
      });

      toast({
        title: "Message sent successfully!",
        description: "We'll get back to you shortly.",
      });

      setEmail("");
      setMessage("");
      onClose();
    } catch (error) {
      console.error('Support request error:', error);
      toast({
        title: "Failed to send message",
        description: "Please try again or contact us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-600 text-gray-100">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center">
            <i className="fas fa-headset text-blue-500 mr-2"></i>
            Quick Support
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="email" className="text-gray-200">Your Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="bg-gray-700 border-gray-600 text-gray-100 focus:border-blue-500"
              placeholder="your.email@example.com"
            />
          </div>
          
          <div>
            <Label htmlFor="message" className="text-gray-200">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              rows={3}
              className="bg-gray-700 border-gray-600 text-gray-100 focus:border-blue-500 resize-none"
              placeholder="Describe your issue or question..."
            />
          </div>
          
          <Button
            type="submit"
            disabled={!email.trim() || !message.trim() || isSubmitting}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isSubmitting ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Sending...
              </>
            ) : (
              <>
                <i className="fas fa-paper-plane mr-2"></i>
                Send Message
              </>
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
