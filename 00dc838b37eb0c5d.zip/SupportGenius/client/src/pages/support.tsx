import { useEffect, useState } from "react";
import { websocketClient } from "@/lib/websocket";
import AIChat from "@/components/ai-chat";
import LiveChat from "@/components/live-chat";
import CommandTerminal from "@/components/command-terminal";
import ContactMethods from "@/components/contact-methods";
import FloatingActions from "@/components/floating-actions";
import QuickChatModal from "@/components/quick-chat-modal";

export default function Support() {
  const [isQuickChatOpen, setIsQuickChatOpen] = useState(false);

  useEffect(() => {
    websocketClient.connect();
    
    return () => {
      websocketClient.disconnect();
    };
  }, []);

  const openTelegram = () => {
    window.open('https://t.me/your_support_bot', '_blank');
  };

  const emergencyContact = () => {
    if (confirm('This will initiate an emergency support call. Continue?')) {
      alert('Connecting to emergency support...');
    }
  };

  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-600 sticky top-0 z-40 backdrop-blur-lg bg-opacity-95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <i className="fas fa-headset text-white text-lg"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-100">Support Center</h1>
                <p className="text-sm text-gray-300">We're here to help 24/7</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Online</span>
              </div>
              <button 
                onClick={emergencyContact}
                className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg font-medium transition-colors"
              >
                <i className="fas fa-phone mr-2"></i>
                Emergency Call
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-100 mb-4">How can we help you today?</h2>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Choose from multiple ways to get support. Our AI assistant, live agents, and technical support are ready to assist.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* AI Chat */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-blue-500 hover:shadow-lg hover:shadow-blue-500/20 transition-all cursor-pointer group">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <i className="fas fa-robot text-white text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-100 mb-2">AI Assistant</h3>
              <p className="text-gray-300 text-sm mb-4">Get instant answers powered by Google Gemini AI</p>
              <div className="flex items-center text-green-500 text-sm font-medium">
                <span>Start Chat</span>
                <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
              </div>
            </div>

            {/* Live Chat */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-green-500 hover:shadow-lg hover:shadow-green-500/20 transition-all cursor-pointer group">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <i className="fas fa-comments text-white text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-100 mb-2">Live Chat</h3>
              <p className="text-gray-300 text-sm mb-4">Chat directly with our support agents</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center text-green-500 text-sm font-medium">
                  <span>Connect Now</span>
                  <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                </div>
                <div className="flex items-center text-xs text-gray-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                  <span>3 agents online</span>
                </div>
              </div>
            </div>

            {/* Telegram */}
            <div 
              onClick={openTelegram}
              className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-400/20 transition-all cursor-pointer group"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <i className="fab fa-telegram text-white text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-100 mb-2">Telegram</h3>
              <p className="text-gray-300 text-sm mb-4">Message us on Telegram for quick support</p>
              <div className="flex items-center text-blue-400 text-sm font-medium">
                <span>Open Telegram</span>
                <i className="fas fa-external-link-alt ml-2 group-hover:translate-x-1 transition-transform"></i>
              </div>
            </div>

            {/* Command Terminal */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-600 hover:border-orange-400 hover:shadow-lg hover:shadow-orange-400/20 transition-all cursor-pointer group">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <i className="fas fa-terminal text-white text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-100 mb-2">Command Interface</h3>
              <p className="text-gray-300 text-sm mb-4">Execute support commands and diagnostics</p>
              <div className="flex items-center text-orange-400 text-sm font-medium">
                <span>Open Terminal</span>
                <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
              </div>
            </div>
          </div>
        </section>

        {/* Chat Interfaces Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <AIChat />
          <LiveChat />
        </div>

        {/* Command Terminal Interface */}
        <CommandTerminal />

        {/* Additional Contact Methods */}
        <ContactMethods />

        {/* Support Statistics */}
        <section className="bg-gray-800 rounded-xl p-8 border border-gray-600">
          <h2 className="text-2xl font-bold text-gray-100 mb-6 text-center">Our Support Performance</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500 mb-2">{'< 2min'}</div>
              <div className="text-gray-300 text-sm">Average Response</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-500 mb-2">98.5%</div>
              <div className="text-gray-300 text-sm">Satisfaction Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-500 mb-2">24/7</div>
              <div className="text-gray-300 text-sm">Availability</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">15K+</div>
              <div className="text-gray-300 text-sm">Issues Resolved</div>
            </div>
          </div>
        </section>
      </main>

      <FloatingActions 
        onQuickChatClick={() => setIsQuickChatOpen(true)}
        onTelegramClick={openTelegram}
        onEmergencyClick={emergencyContact}
      />
      
      <QuickChatModal 
        isOpen={isQuickChatOpen} 
        onClose={() => setIsQuickChatOpen(false)} 
      />
    </div>
  );
}
