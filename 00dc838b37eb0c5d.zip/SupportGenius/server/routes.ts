import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertSupportMessageSchema, insertCommandLogSchema, insertSupportRequestSchema } from "@shared/schema";
import { nanoid } from "nanoid";

// Google Gemini API integration
async function generateAIResponse(message: string): Promise<string> {
  const apiKey = process.env.GOOGLE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
  
  if (!apiKey) {
    throw new Error("Google Gemini API key not configured");
  }

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `You are a helpful support assistant. Please provide a helpful, concise response to this support question: ${message}`
          }]
        }]
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || "I'm sorry, I couldn't generate a response at this time.";
  } catch (error) {
    console.error('Gemini API error:', error);
    return "I'm experiencing technical difficulties. Please try contacting our live support or try again later.";
  }
}

// Command execution simulation
function executeCommand(command: string): string {
  const cmd = command.toLowerCase().trim();
  
  switch (cmd) {
    case 'help':
      return `Available Commands:
• status - Check system status
• ping - Test connectivity  
• logs - View recent logs
• clear - Clear terminal
• uptime - Show system uptime
• version - Show version info`;

    case 'status':
      return `System Status:
🟢 API Gateway: Online
🟢 Database: Connected
🟢 Cache: Active
🟡 Backup Service: Maintenance`;

    case 'ping':
      return `Connectivity Test:
PING support.server.local (192.168.1.100)
64 bytes from 192.168.1.100: icmp_seq=1 ttl=64 time=12.3ms
64 bytes from 192.168.1.100: icmp_seq=2 ttl=64 time=11.8ms
Connection: Stable`;

    case 'logs':
      const now = new Date();
      return `Recent System Logs:
[${now.toISOString()}] INFO User authentication successful
[${new Date(now.getTime() - 60000).toISOString()}] INFO API request processed: /api/support
[${new Date(now.getTime() - 120000).toISOString()}] WARN High memory usage detected
[${new Date(now.getTime() - 180000).toISOString()}] INFO Database connection restored`;

    case 'uptime':
      return `System Uptime: 42 days, 13 hours, 27 minutes
Load average: 0.85, 0.92, 1.03`;

    case 'version':
      return `Support System Information:
Version: 2.1.0
Build: #2024.01.15
Environment: Production
Node.js: v18.17.0`;

    case 'clear':
      return 'CLEAR_TERMINAL';

    default:
      return `Command '${command}' not found. Type 'help' for available commands.`;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Map<string, WebSocket>();

  wss.on('connection', (ws) => {
    const clientId = nanoid();
    clients.set(clientId, ws);
    
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'live_chat') {
          // Store message
          await storage.createSupportMessage({
            sessionId: message.sessionId,
            message: message.content,
            sender: 'user',
            senderName: undefined
          });

          // Simulate agent response
          setTimeout(async () => {
            const agentResponse = "Thank you for your message. I'm looking into this right away.";
            
            await storage.createSupportMessage({
              sessionId: message.sessionId,
              message: agentResponse,
              sender: 'agent',
              senderName: 'Sarah M.'
            });

            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({
                type: 'live_chat_response',
                sessionId: message.sessionId,
                content: agentResponse,
                sender: 'agent',
                senderName: 'Sarah M.',
                timestamp: new Date().toISOString()
              }));
            }
          }, 2000);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(clientId);
    });
  });

  // AI Chat endpoint
  app.post('/api/ai-chat', async (req, res) => {
    try {
      const { message, sessionId } = req.body;
      
      if (!message || !sessionId) {
        return res.status(400).json({ error: 'Message and sessionId are required' });
      }

      // Store user message
      await storage.createSupportMessage({
        sessionId,
        message,
        sender: 'user',
        senderName: undefined
      });

      // Generate AI response
      const aiResponse = await generateAIResponse(message);
      
      // Store AI response
      await storage.createSupportMessage({
        sessionId,
        message: aiResponse,
        sender: 'ai',
        senderName: 'AI Assistant'
      });

      res.json({ response: aiResponse });
    } catch (error) {
      console.error('AI chat error:', error);
      res.status(500).json({ error: 'Failed to generate AI response' });
    }
  });

  // Command execution endpoint
  app.post('/api/execute-command', async (req, res) => {
    try {
      const { command, sessionId } = req.body;
      
      if (!command || !sessionId) {
        return res.status(400).json({ error: 'Command and sessionId are required' });
      }

      const output = executeCommand(command);
      
      // Store command log
      await storage.createCommandLog({
        sessionId,
        command,
        output
      });

      res.json({ output });
    } catch (error) {
      console.error('Command execution error:', error);
      res.status(500).json({ error: 'Failed to execute command' });
    }
  });

  // Support request endpoint
  app.post('/api/support-request', async (req, res) => {
    try {
      const validatedData = insertSupportRequestSchema.parse(req.body);
      const request = await storage.createSupportRequest(validatedData);
      res.json(request);
    } catch (error) {
      console.error('Support request error:', error);
      res.status(400).json({ error: 'Invalid support request data' });
    }
  });

  // Get chat history
  app.get('/api/chat-history/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getMessagesBySession(sessionId);
      res.json(messages);
    } catch (error) {
      console.error('Chat history error:', error);
      res.status(500).json({ error: 'Failed to get chat history' });
    }
  });

  // Get command history
  app.get('/api/command-history/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const logs = await storage.getCommandLogsBySession(sessionId);
      res.json(logs);
    } catch (error) {
      console.error('Command history error:', error);
      res.status(500).json({ error: 'Failed to get command history' });
    }
  });

  return httpServer;
}
