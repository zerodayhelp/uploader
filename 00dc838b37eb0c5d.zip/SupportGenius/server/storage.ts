import { users, supportMessages, commandLogs, supportRequests, type User, type InsertUser, type SupportMessage, type InsertSupportMessage, type CommandLog, type InsertCommandLog, type SupportRequest, type InsertSupportRequest } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Support Messages
  createSupportMessage(message: InsertSupportMessage): Promise<SupportMessage>;
  getMessagesBySession(sessionId: string): Promise<SupportMessage[]>;
  
  // Command Logs
  createCommandLog(log: InsertCommandLog): Promise<CommandLog>;
  getCommandLogsBySession(sessionId: string): Promise<CommandLog[]>;
  
  // Support Requests
  createSupportRequest(request: InsertSupportRequest): Promise<SupportRequest>;
  getAllSupportRequests(): Promise<SupportRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private supportMessages: Map<number, SupportMessage>;
  private commandLogs: Map<number, CommandLog>;
  private supportRequests: Map<number, SupportRequest>;
  private currentUserId: number;
  private currentMessageId: number;
  private currentCommandId: number;
  private currentRequestId: number;

  constructor() {
    this.users = new Map();
    this.supportMessages = new Map();
    this.commandLogs = new Map();
    this.supportRequests = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
    this.currentCommandId = 1;
    this.currentRequestId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createSupportMessage(insertMessage: InsertSupportMessage): Promise<SupportMessage> {
    const id = this.currentMessageId++;
    const message: SupportMessage = { 
      ...insertMessage, 
      id, 
      timestamp: new Date() 
    };
    this.supportMessages.set(id, message);
    return message;
  }

  async getMessagesBySession(sessionId: string): Promise<SupportMessage[]> {
    return Array.from(this.supportMessages.values())
      .filter(msg => msg.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createCommandLog(insertLog: InsertCommandLog): Promise<CommandLog> {
    const id = this.currentCommandId++;
    const log: CommandLog = { 
      ...insertLog, 
      id, 
      timestamp: new Date() 
    };
    this.commandLogs.set(id, log);
    return log;
  }

  async getCommandLogsBySession(sessionId: string): Promise<CommandLog[]> {
    return Array.from(this.commandLogs.values())
      .filter(log => log.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createSupportRequest(insertRequest: InsertSupportRequest): Promise<SupportRequest> {
    const id = this.currentRequestId++;
    const request: SupportRequest = { 
      ...insertRequest, 
      id, 
      status: "open",
      timestamp: new Date() 
    };
    this.supportRequests.set(id, request);
    return request;
  }

  async getAllSupportRequests(): Promise<SupportRequest[]> {
    return Array.from(this.supportRequests.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
}

export const storage = new MemStorage();
