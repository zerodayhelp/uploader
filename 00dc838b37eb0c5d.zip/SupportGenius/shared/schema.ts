import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const supportMessages = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  message: text("message").notNull(),
  sender: text("sender").notNull(), // 'user', 'agent', 'ai'
  senderName: text("sender_name"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const commandLogs = pgTable("command_logs", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  command: text("command").notNull(),
  output: text("output").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const supportRequests = pgTable("support_requests", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("open"), // 'open', 'in_progress', 'resolved'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSupportMessageSchema = createInsertSchema(supportMessages).pick({
  sessionId: true,
  message: true,
  sender: true,
  senderName: true,
});

export const insertCommandLogSchema = createInsertSchema(commandLogs).pick({
  sessionId: true,
  command: true,
  output: true,
});

export const insertSupportRequestSchema = createInsertSchema(supportRequests).pick({
  email: true,
  message: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type SupportMessage = typeof supportMessages.$inferSelect;
export type InsertSupportMessage = z.infer<typeof insertSupportMessageSchema>;
export type CommandLog = typeof commandLogs.$inferSelect;
export type InsertCommandLog = z.infer<typeof insertCommandLogSchema>;
export type SupportRequest = typeof supportRequests.$inferSelect;
export type InsertSupportRequest = z.infer<typeof insertSupportRequestSchema>;
