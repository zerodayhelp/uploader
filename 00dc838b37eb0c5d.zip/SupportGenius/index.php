<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Center - Contact Us | Professional Support Services</title>
    <meta name="description" content="Get instant support through our AI assistant, live chat, or technical command interface. 24/7 support available with multiple contact options including Telegram and emergency assistance.">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="styles.css">
</head>
<body class="font-inter bg-gray-900 text-gray-100">
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="header-left">
                    <div class="logo">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div class="header-text">
                        <h1>Support Center</h1>
                        <p>We're here to help 24/7</p>
                    </div>
                </div>
                <div class="header-right">
                    <div class="status">
                        <div class="status-dot"></div>
                        <span>Online</span>
                    </div>
                    <button class="emergency-btn" onclick="emergencyContact()">
                        <i class="fas fa-phone"></i>
                        Emergency Call
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <!-- Welcome Section -->
            <section class="welcome-section">
                <div class="welcome-text">
                    <h2>How can we help you today?</h2>
                    <p>Choose from multiple ways to get support. Our AI assistant, live agents, and technical support are ready to assist.</p>
                </div>
                
                <!-- Quick Actions Grid -->
                <div class="quick-actions-grid">
                    <div class="action-card ai-card" onclick="openAIChat()">
                        <div class="card-icon ai-icon">
                            <i class="fas fa-robot"></i>
                        </div>
                        <h3>AI Assistant</h3>
                        <p>Get instant answers powered by Google Gemini AI</p>
                        <div class="card-action">
                            <span>Start Chat</span>
                            <i class="fas fa-arrow-right"></i>
                        </div>
                    </div>

                    <div class="action-card live-card" onclick="openLiveChat()">
                        <div class="card-icon live-icon">
                            <i class="fas fa-comments"></i>
                        </div>
                        <h3>Live Chat</h3>
                        <p>Chat directly with our support agents</p>
                        <div class="card-action">
                            <span>Connect Now</span>
                            <i class="fas fa-arrow-right"></i>
                        </div>
                        <div class="agent-status">
                            <div class="status-dot"></div>
                            <span>3 agents online</span>
                        </div>
                    </div>

                    <div class="action-card telegram-card" onclick="openTelegram()">
                        <div class="card-icon telegram-icon">
                            <i class="fab fa-telegram"></i>
                        </div>
                        <h3>Telegram</h3>
                        <p>Message us on Telegram for quick support</p>
                        <div class="card-action">
                            <span>Open Telegram</span>
                            <i class="fas fa-external-link-alt"></i>
                        </div>
                    </div>

                    <div class="action-card terminal-card" onclick="openTerminal()">
                        <div class="card-icon terminal-icon">
                            <i class="fas fa-terminal"></i>
                        </div>
                        <h3>Command Interface</h3>
                        <p>Execute support commands and diagnostics</p>
                        <div class="card-action">
                            <span>Open Terminal</span>
                            <i class="fas fa-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chat Interfaces -->
            <div class="chat-grid">
                <!-- AI Chat -->
                <div class="chat-interface" id="ai-chat">
                    <div class="chat-header ai-header">
                        <div class="chat-header-left">
                            <div class="chat-icon">
                                <i class="fas fa-robot"></i>
                            </div>
                            <div class="chat-info">
                                <h3>AI Assistant</h3>
                                <p>Powered by Google Gemini</p>
                            </div>
                        </div>
                        <button class="clear-btn" onclick="clearAIChat()">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    <div class="chat-messages" id="ai-messages">
                        <div class="message ai-message">
                            <div class="message-avatar ai-avatar">
                                <i class="fas fa-robot"></i>
                            </div>
                            <div class="message-content">
                                <p>Hello! I'm your AI assistant powered by Google Gemini. How can I help you today?</p>
                                <span class="message-time"><?php echo date('H:i'); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="chat-input-area">
                        <div class="input-group">
                            <input type="text" id="ai-input" placeholder="Ask me anything..." onkeypress="handleAIKeyPress(event)">
                            <button onclick="sendAIMessage()">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                        <div class="chat-info-text">
                            <i class="fas fa-info-circle"></i>
                            <span>AI responses are generated by Google Gemini API</span>
                        </div>
                    </div>
                </div>

                <!-- Live Chat -->
                <div class="chat-interface" id="live-chat">
                    <div class="chat-header live-header">
                        <div class="chat-header-left">
                            <div class="chat-icon">
                                <i class="fas fa-user-headset"></i>
                            </div>
                            <div class="chat-info">
                                <h3>Live Support</h3>
                                <p><div class="status-dot"></div>Agent available</p>
                            </div>
                        </div>
                        <div class="queue-status">
                            <span>Queue: 0</span>
                        </div>
                    </div>
                    <div class="chat-messages" id="live-messages">
                        <div class="message agent-message">
                            <div class="message-avatar agent-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="message-content">
                                <div class="agent-name">Sarah M. <span>Support Agent</span></div>
                                <p>Hi there! I'm Sarah from the support team. How can I assist you today?</p>
                                <span class="message-time"><?php echo date('H:i', strtotime('-2 minutes')); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="chat-input-area">
                        <div class="input-group">
                            <input type="text" id="live-input" placeholder="Type your message..." onkeypress="handleLiveKeyPress(event)">
                            <button onclick="sendLiveMessage()">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                        <div class="chat-info-text">
                            <div class="security-info">
                                <i class="fas fa-shield-alt"></i>
                                <span>Encrypted connection</span>
                            </div>
                            <span id="typing-indicator" style="display: none;">Agent is typing...</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Command Terminal -->
            <section class="terminal-section">
                <div class="terminal-interface">
                    <div class="terminal-header">
                        <div class="terminal-header-left">
                            <div class="terminal-icon">
                                <i class="fas fa-terminal"></i>
                            </div>
                            <div class="terminal-info">
                                <h3>Command Interface</h3>
                                <p>Technical Support Terminal</p>
                            </div>
                        </div>
                        <button class="clear-btn" onclick="clearTerminal()">
                            <i class="fas fa-broom"></i>
                        </button>
                    </div>
                    <div class="terminal-content">
                        <div class="terminal-output" id="terminal-output">
                            <div class="terminal-welcome">Support Terminal v2.1.0 - Type 'help' for available commands</div>
                            <div class="terminal-welcome">Connected to support.server.local</div>
                        </div>
                        <div class="terminal-input-line">
                            <span class="terminal-prompt">support@terminal:~$</span>
                            <input type="text" id="terminal-input" placeholder="Enter command..." onkeypress="handleTerminalKeyPress(event)">
                        </div>
                    </div>
                    <div class="terminal-quick-commands">
                        <div class="quick-commands">
                            <button onclick="executeCommand('status')">status</button>
                            <button onclick="executeCommand('ping')">ping</button>
                            <button onclick="executeCommand('logs')">logs</button>
                            <button onclick="executeCommand('help')">help</button>
                        </div>
                        <p>Quick commands - Click to execute or type manually</p>
                    </div>
                </div>
            </section>

            <!-- Contact Methods -->
            <section class="contact-methods">
                <h2>Other Ways to Reach Us</h2>
                <div class="contact-grid">
                    <div class="contact-card email-card">
                        <div class="contact-header">
                            <div class="contact-icon email-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <h3>Email Support</h3>
                        </div>
                        <p>Send us detailed questions and get comprehensive responses.</p>
                        <div class="contact-details">
                            <div class="detail-row">
                                <span>General Support:</span>
                                <span class="email">help@company.com</span>
                            </div>
                            <div class="detail-row">
                                <span>Technical Issues:</span>
                                <span class="email">tech@company.com</span>
                            </div>
                            <div class="detail-row">
                                <span>Response Time:</span>
                                <span class="time">&lt; 4 hours</span>
                            </div>
                        </div>
                    </div>

                    <div class="contact-card phone-card">
                        <div class="contact-header">
                            <div class="contact-icon phone-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <h3>Phone Support</h3>
                        </div>
                        <p>Speak directly with our support specialists.</p>
                        <div class="contact-details">
                            <div class="detail-row">
                                <span>Support Line:</span>
                                <span class="phone">+1-800-SUPPORT</span>
                            </div>
                            <div class="detail-row">
                                <span>Emergency:</span>
                                <span class="emergency">+1-800-URGENT</span>
                            </div>
                            <div class="detail-row">
                                <span>Hours:</span>
                                <span>24/7 Available</span>
                            </div>
                        </div>
                    </div>

                    <div class="contact-card knowledge-card">
                        <div class="contact-header">
                            <div class="contact-icon knowledge-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <h3>Knowledge Base</h3>
                        </div>
                        <p>Find instant answers in our comprehensive guides.</p>
                        <div class="knowledge-links">
                            <a href="#" class="knowledge-link">
                                <i class="fas fa-arrow-right"></i>
                                Getting Started Guide
                            </a>
                            <a href="#" class="knowledge-link">
                                <i class="fas fa-arrow-right"></i>
                                Troubleshooting
                            </a>
                            <a href="#" class="knowledge-link">
                                <i class="fas fa-arrow-right"></i>
                                API Documentation
                            </a>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Support Statistics -->
            <section class="stats-section">
                <h2>Our Support Performance</h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-number green">&lt; 2min</div>
                        <div class="stat-label">Average Response</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number blue">98.5%</div>
                        <div class="stat-label">Satisfaction Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number purple">24/7</div>
                        <div class="stat-label">Availability</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number orange">15K+</div>
                        <div class="stat-label">Issues Resolved</div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- Floating Action Buttons -->
    <div class="floating-actions">
        <button class="fab quick-chat-fab" onclick="openQuickChatModal()">
            <i class="fas fa-comment-dots"></i>
        </button>
        <button class="fab telegram-fab" onclick="openTelegram()">
            <i class="fab fa-telegram"></i>
        </button>
        <button class="fab emergency-fab" onclick="emergencyContact()">
            <i class="fas fa-exclamation"></i>
        </button>
    </div>

    <!-- Quick Chat Modal -->
    <div id="quick-chat-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-headset"></i> Quick Support</h3>
                <button class="modal-close" onclick="closeQuickChatModal()">&times;</button>
            </div>
            <form id="quick-chat-form" onsubmit="submitQuickChat(event)">
                <div class="form-group">
                    <label for="email">Your Email</label>
                    <input type="email" id="email" name="email" required placeholder="your.email@example.com">
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" required rows="3" placeholder="Describe your issue or question..."></textarea>
                </div>
                <button type="submit" class="submit-btn">
                    <i class="fas fa-paper-plane"></i>
                    Send Message
                </button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>