<?php
require_once __DIR__ . '/../database/Database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['command']) || !isset($input['sessionId'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Command and sessionId are required']);
    exit;
}

$command = trim($input['command']);
$sessionId = $input['sessionId'];

if (empty($command)) {
    http_response_code(400);
    echo json_encode(['error' => 'Command cannot be empty']);
    exit;
}

try {
    $db = Database::getInstance();
    $output = executeCommand($command);
    
    // Store command log
    storeCommandLog($db, $sessionId, $command, $output);
    
    echo json_encode(['output' => $output]);
    
} catch (Exception $e) {
    error_log('Command execution error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to execute command']);
}

function executeCommand($command) {
    $cmd = strtolower(trim($command));
    
    switch ($cmd) {
        case 'help':
            return "Available Commands:\n• status - Check system status\n• ping - Test connectivity\n• logs - View recent logs\n• clear - Clear terminal\n• uptime - Show system uptime\n• version - Show version info\n• whoami - Display current user\n• date - Show current date and time";

        case 'status':
            return "System Status:\n🟢 API Gateway: Online\n🟢 Database: Connected\n🟢 Cache: Active\n🟡 Backup Service: Maintenance\n🟢 WebSocket Server: Running\n🟢 Load Balancer: Healthy";

        case 'ping':
            return "Connectivity Test:\nPING support.server.local (192.168.1.100)\n64 bytes from 192.168.1.100: icmp_seq=1 ttl=64 time=12.3ms\n64 bytes from 192.168.1.100: icmp_seq=2 ttl=64 time=11.8ms\n64 bytes from 192.168.1.100: icmp_seq=3 ttl=64 time=13.1ms\n--- support.server.local ping statistics ---\n3 packets transmitted, 3 received, 0% packet loss\nConnection: Stable";

        case 'logs':
            $now = new DateTime();
            $log1 = clone $now;
            $log2 = $log1->modify('-1 minute');
            $log3 = $log2->modify('-1 minute');
            $log4 = $log3->modify('-1 minute');
            $log5 = $log4->modify('-1 minute');
            
            return "Recent System Logs:\n[" . $now->format('c') . "] INFO User authentication successful\n[" . $log1->format('c') . "] INFO API request processed: /api/support\n[" . $log2->format('c') . "] WARN High memory usage detected: 85%\n[" . $log3->format('c') . "] INFO Database connection restored\n[" . $log4->format('c') . "] INFO Backup completed successfully";

        case 'uptime':
            return "System Uptime: 42 days, 13 hours, 27 minutes\nLoad average: 0.85, 0.92, 1.03\nMemory usage: 68% of 32GB\nDisk usage: 45% of 500GB";

        case 'version':
            return "Support System Information:\nVersion: 2.1.0\nBuild: #2024.12.15\nEnvironment: Production\nPHP: " . phpversion() . "\nOS: " . php_uname('s') . " " . php_uname('r') . "\nServer: " . $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';

        case 'whoami':
            global $sessionId;
            return "Current User: support-admin\nGroups: sudo, support, admin\nSession: " . substr($sessionId ?? 'unknown', 0, 16) . "...\nTerminal: web-terminal";

        case 'date':
            $now = new DateTime();
            return $now->format('r') . "\nUTC: " . $now->setTimezone(new DateTimeZone('UTC'))->format('r') . "\nUnix timestamp: " . time();

        case 'clear':
            return 'CLEAR_TERMINAL';

        case 'ls':
            return "total 8\ndrwxr-xr-x 3 support support 4096 Dec 15 09:34 logs/\ndrwxr-xr-x 2 support support 4096 Dec 15 09:30 scripts/\n-rw-r--r-- 1 support support 1024 Dec 15 09:34 config.json\n-rw-r--r-- 1 support support  512 Dec 15 09:30 README.md";

        case 'ps':
            return "  PID TTY          TIME CMD\n 1234 pts/0    00:00:01 support-daemon\n 5678 pts/0    00:00:00 websocket-server\n 9012 pts/0    00:00:02 api-gateway\n 3456 pts/0    00:00:00 database-monitor";

        default:
            return "Command '$command' not found. Type 'help' for available commands.";
    }
}

function storeCommandLog($db, $sessionId, $command, $output) {
    return $db->insert('command_logs', [
        'session_id' => $sessionId,
        'command' => $command,
        'output' => $output
    ]);
}
?>