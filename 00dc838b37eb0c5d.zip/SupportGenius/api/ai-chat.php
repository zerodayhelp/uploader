<?php
require_once __DIR__ . '/../database/Database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['message']) || !isset($input['sessionId'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Message and sessionId are required']);
    exit;
}

$message = trim($input['message']);
$sessionId = $input['sessionId'];

if (empty($message)) {
    http_response_code(400);
    echo json_encode(['error' => 'Message cannot be empty']);
    exit;
}

// Google Gemini API configuration
$apiKey = getenv('GOOGLE_GEMINI_API_KEY') ?: getenv('GEMINI_API_KEY');

if (empty($apiKey)) {
    // Return error indicating API key is needed
    http_response_code(500);
    echo json_encode(['error' => 'Google Gemini API key not configured. Please provide GOOGLE_GEMINI_API_KEY or GEMINI_API_KEY environment variable.']);
    exit;
}

try {
    $db = Database::getInstance();
    
    // Store user message
    storeMessage($db, $sessionId, $message, 'user');
    
    // Call Google Gemini API
    $aiResponse = callGeminiAPI($message, $apiKey);
    
    // Store AI response
    storeMessage($db, $sessionId, $aiResponse, 'ai', 'AI Assistant');
    
    echo json_encode(['response' => $aiResponse]);
    
} catch (Exception $e) {
    error_log('AI chat error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate AI response']);
}

function callGeminiAPI($message, $apiKey) {
    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" . $apiKey;
    
    $data = [
        'contents' => [
            [
                'parts' => [
                    [
                        'text' => "You are a helpful support assistant. Please provide a helpful, concise response to this support question: " . $message
                    ]
                ]
            ]
        ]
    ];
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($data)
        ]
    ]);
    
    $response = file_get_contents($url, false, $context);
    
    if ($response === false) {
        throw new Exception('Failed to call Gemini API');
    }
    
    $responseData = json_decode($response, true);
    
    if (isset($responseData['error'])) {
        throw new Exception('Gemini API error: ' . $responseData['error']['message']);
    }
    
    return $responseData['candidates'][0]['content']['parts'][0]['text'] ?? 
           "I'm sorry, I couldn't generate a response at this time.";
}

function storeMessage($db, $sessionId, $message, $sender, $senderName = null) {
    return $db->insert('support_messages', [
        'session_id' => $sessionId,
        'message' => $message,
        'sender' => $sender,
        'sender_name' => $senderName
    ]);
}
?>