<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['email']) || !isset($input['message'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and message are required']);
    exit;
}

$email = trim($input['email']);
$message = trim($input['message']);

if (empty($email) || empty($message)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and message cannot be empty']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit;
}

try {
    $request = storeSupportRequest($email, $message);
    echo json_encode($request);
    
} catch (Exception $e) {
    error_log('Support request error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to submit support request']);
}

function storeSupportRequest($email, $message) {
    $dataDir = __DIR__ . '/../data';
    if (!is_dir($dataDir)) {
        mkdir($dataDir, 0755, true);
    }
    
    $requestsFile = $dataDir . '/support_requests.json';
    $requests = [];
    
    if (file_exists($requestsFile)) {
        $requests = json_decode(file_get_contents($requestsFile), true) ?: [];
    }
    
    $request = [
        'id' => uniqid(),
        'email' => $email,
        'message' => $message,
        'status' => 'open',
        'timestamp' => date('c')
    ];
    
    $requests[] = $request;
    
    file_put_contents($requestsFile, json_encode($requests, JSON_PRETTY_PRINT));
    
    return $request;
}
?>