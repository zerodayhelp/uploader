<?php
// Simple PHP development server router
$uri = $_SERVER['REQUEST_URI'];
$path = parse_url($uri, PHP_URL_PATH);

// Remove query string
$path = strtok($path, '?');

// Serve static files
if ($path !== '/' && file_exists(__DIR__ . $path)) {
    // Get the file extension
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    
    // Set appropriate content type
    switch ($ext) {
        case 'css':
            header('Content-Type: text/css');
            break;
        case 'js':
            header('Content-Type: application/javascript');
            break;
        case 'png':
            header('Content-Type: image/png');
            break;
        case 'jpg':
        case 'jpeg':
            header('Content-Type: image/jpeg');
            break;
        case 'gif':
            header('Content-Type: image/gif');
            break;
        case 'svg':
            header('Content-Type: image/svg+xml');
            break;
        case 'ico':
            header('Content-Type: image/x-icon');
            break;
        default:
            // Let PHP handle it normally
            return false;
    }
    
    // Read and output the file
    readfile(__DIR__ . $path);
    exit;
}

// Route API requests
if (strpos($path, '/api/') === 0) {
    $apiFile = __DIR__ . $path;
    if (file_exists($apiFile)) {
        require $apiFile;
        exit;
    } else {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'API endpoint not found']);
        exit;
    }
}

// Serve the main page for all other routes
require __DIR__ . '/index.php';
?>