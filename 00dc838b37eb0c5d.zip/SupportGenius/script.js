// Global variables
let sessionId = generateSessionId();
let isAILoading = false;
let isLiveTyping = false;
let isTerminalExecuting = false;

// Generate unique session ID
function generateSessionId() {
    return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
}

// Get current time string
function getCurrentTime() {
    return new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

// Scroll to bottom of element
function scrollToBottom(element) {
    element.scrollTop = element.scrollHeight;
}

// Quick Actions
function openAIChat() {
    document.getElementById('ai-chat').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('ai-input').focus();
}

function openLiveChat() {
    document.getElementById('live-chat').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('live-input').focus();
}

function openTelegram() {
    window.open('https://t.me/your_support_bot', '_blank');
}

function openTerminal() {
    document.querySelector('.terminal-section').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('terminal-input').focus();
}

function emergencyContact() {
    if (confirm('This will initiate an emergency support call. Continue?')) {
        alert('Connecting to emergency support...\n\nPlease call: +1-800-URGENT\n\nOr wait for our callback within 2 minutes.');
    }
}

// AI Chat Functions
function handleAIKeyPress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendAIMessage();
    }
}

function sendAIMessage() {
    const input = document.getElementById('ai-input');
    const message = input.value.trim();
    
    if (!message || isAILoading) return;
    
    // Add user message
    addAIMessage(message, 'user');
    input.value = '';
    
    // Show loading
    isAILoading = true;
    showAILoading();
    
    // Call AI API
    fetch('/api/ai-chat.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            message: message,
            sessionId: sessionId
        })
    })
    .then(response => response.json())
    .then(data => {
        hideAILoading();
        if (data.error) {
            if (data.error.includes('API key not configured')) {
                addAIMessage("I need a Google Gemini API key to provide AI responses. Please ask the administrator to configure the GOOGLE_GEMINI_API_KEY environment variable.", 'ai');
            } else {
                addAIMessage("I'm experiencing technical difficulties. Please try contacting our live support or try again later.", 'ai');
            }
        } else {
            addAIMessage(data.response, 'ai');
        }
        isAILoading = false;
    })
    .catch(error => {
        console.error('AI chat error:', error);
        hideAILoading();
        addAIMessage("I'm experiencing technical difficulties. Please try contacting our live support or try again later.", 'ai');
        isAILoading = false;
    });
}

function addAIMessage(content, sender) {
    const messagesContainer = document.getElementById('ai-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = `message-avatar ${sender}-avatar`;
    avatarDiv.innerHTML = sender === 'ai' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = `
        <p>${content}</p>
        <span class="message-time">${getCurrentTime()}</span>
    `;
    
    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(contentDiv);
    messagesContainer.appendChild(messageDiv);
    
    scrollToBottom(messagesContainer);
}

function showAILoading() {
    const messagesContainer = document.getElementById('ai-messages');
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'message ai-message';
    loadingDiv.id = 'ai-loading';
    
    loadingDiv.innerHTML = `
        <div class="message-avatar ai-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content">
            <div class="loading-dots">
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
            </div>
        </div>
    `;
    
    messagesContainer.appendChild(loadingDiv);
    scrollToBottom(messagesContainer);
}

function hideAILoading() {
    const loadingElement = document.getElementById('ai-loading');
    if (loadingElement) {
        loadingElement.remove();
    }
}

function clearAIChat() {
    const messagesContainer = document.getElementById('ai-messages');
    messagesContainer.innerHTML = `
        <div class="message ai-message">
            <div class="message-avatar ai-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <p>Hello! I'm your AI assistant powered by Google Gemini. How can I help you today?</p>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
        </div>
    `;
    sessionId = generateSessionId();
}

// Live Chat Functions
function handleLiveKeyPress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendLiveMessage();
    }
}

function sendLiveMessage() {
    const input = document.getElementById('live-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addLiveMessage(message, 'user');
    input.value = '';
    
    // Show typing indicator
    showLiveTyping();
    
    // Simulate agent response
    setTimeout(() => {
        const responses = [
            "Thank you for your message. I'm looking into this right away and will have an answer for you shortly.",
            "I understand your concern. Let me check our system and get back to you with a solution.",
            "That's a great question! I'm reviewing your account details now to provide you with the most accurate information.",
            "I see what you're experiencing. This is something we can definitely help you resolve. Give me just a moment to pull up the relevant information.",
            "Thanks for reaching out! I'm here to help you get this sorted out. Let me gather some details and provide you with next steps."
        ];
        
        const response = responses[Math.floor(Math.random() * responses.length)];
        hideLiveTyping();
        addLiveMessage(response, 'agent', 'Sarah M.');
    }, 1500 + Math.random() * 2000);
}

function addLiveMessage(content, sender, senderName = null) {
    const messagesContainer = document.getElementById('live-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = `message-avatar ${sender}-avatar`;
    avatarDiv.innerHTML = '<i class="fas fa-user"></i>';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    let messageHTML = '';
    if (sender === 'agent' && senderName) {
        messageHTML += `<div class="agent-name">${senderName} <span>Support Agent</span></div>`;
    }
    messageHTML += `
        <p>${content}</p>
        <span class="message-time">${getCurrentTime()}</span>
    `;
    
    contentDiv.innerHTML = messageHTML;
    
    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(contentDiv);
    messagesContainer.appendChild(messageDiv);
    
    scrollToBottom(messagesContainer);
}

function showLiveTyping() {
    isLiveTyping = true;
    document.getElementById('typing-indicator').style.display = 'inline';
}

function hideLiveTyping() {
    isLiveTyping = false;
    document.getElementById('typing-indicator').style.display = 'none';
}

// Terminal Functions
function handleTerminalKeyPress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        const input = document.getElementById('terminal-input');
        executeCommand(input.value);
    }
}

function executeCommand(command) {
    if (!command.trim() || isTerminalExecuting) return;
    
    const input = document.getElementById('terminal-input');
    const output = document.getElementById('terminal-output');
    
    // Add command to output
    const commandDiv = document.createElement('div');
    commandDiv.className = 'terminal-command';
    commandDiv.innerHTML = `
        <div class="terminal-command-text">
            <span class="terminal-prompt">support@terminal:~$</span> ${command}
        </div>
    `;
    output.appendChild(commandDiv);
    
    input.value = '';
    isTerminalExecuting = true;
    
    // Show executing indicator
    const executingDiv = document.createElement('div');
    executingDiv.id = 'executing-indicator';
    executingDiv.innerHTML = '<div class="terminal-output-text" style="color: #9ca3af;">Executing...</div>';
    output.appendChild(executingDiv);
    
    scrollToBottom(output);
    
    // Call command execution API
    fetch('/api/execute-command.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            command: command,
            sessionId: sessionId
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('executing-indicator').remove();
        
        if (data.error) {
            const outputDiv = document.createElement('div');
            outputDiv.innerHTML = `<div class="terminal-output-text" style="color: #ef4444;">Error: ${data.error}</div>`;
            output.appendChild(outputDiv);
        } else if (data.output === 'CLEAR_TERMINAL') {
            clearTerminal();
        } else {
            const outputDiv = document.createElement('div');
            outputDiv.innerHTML = `<div class="terminal-output-text">${data.output}</div>`;
            output.appendChild(outputDiv);
        }
        
        isTerminalExecuting = false;
        scrollToBottom(output);
    })
    .catch(error => {
        console.error('Command execution error:', error);
        document.getElementById('executing-indicator').remove();
        
        const outputDiv = document.createElement('div');
        outputDiv.innerHTML = `<div class="terminal-output-text" style="color: #ef4444;">Error: Failed to execute command</div>`;
        output.appendChild(outputDiv);
        
        isTerminalExecuting = false;
        scrollToBottom(output);
    });
}

// This function is no longer used since we're using PHP API

function clearTerminal() {
    const output = document.getElementById('terminal-output');
    output.innerHTML = `
        <div class="terminal-welcome">Support Terminal v2.1.0 - Type 'help' for available commands</div>
        <div class="terminal-welcome">Connected to support.server.local</div>
    `;
    sessionId = generateSessionId();
}

// Modal Functions
function openQuickChatModal() {
    document.getElementById('quick-chat-modal').style.display = 'block';
    document.getElementById('email').focus();
}

function closeQuickChatModal() {
    document.getElementById('quick-chat-modal').style.display = 'none';
    document.getElementById('quick-chat-form').reset();
}

function submitQuickChat(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    
    const submitBtn = event.target.querySelector('.submit-btn');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitBtn.disabled = true;
    
    fetch('/api/support-request.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            email: email,
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert('Message sent successfully! We\'ll get back to you shortly.');
            closeQuickChatModal();
        }
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    })
    .catch(error => {
        console.error('Support request error:', error);
        alert('Failed to send message. Please try again.');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('quick-chat-modal');
    if (event.target === modal) {
        closeQuickChatModal();
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // ESC to close modal
    if (event.key === 'Escape') {
        closeQuickChatModal();
    }
    
    // Ctrl+/ for help in terminal
    if (event.ctrlKey && event.key === '/') {
        event.preventDefault();
        if (document.activeElement === document.getElementById('terminal-input')) {
            executeCommand('help');
        }
    }
});

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Initialize session
    console.log('Support page initialized with session:', sessionId);
    
    // Add focus styles for accessibility
    const style = document.createElement('style');
    style.textContent = `
        *:focus {
            outline: 2px solid #3b82f6;
            outline-offset: 2px;
        }
        
        .action-card:focus,
        .fab:focus,
        button:focus {
            outline: 2px solid #3b82f6;
            outline-offset: 2px;
        }
    `;
    document.head.appendChild(style);
});

// Auto-resize terminal output
function adjustTerminalHeight() {
    const terminal = document.getElementById('terminal-output');
    const content = terminal.scrollHeight;
    const maxHeight = 384; // 24rem in pixels
    
    if (content > maxHeight) {
        terminal.style.maxHeight = maxHeight + 'px';
        terminal.style.overflowY = 'auto';
    }
}

// Call adjust function periodically
setInterval(adjustTerminalHeight, 1000);