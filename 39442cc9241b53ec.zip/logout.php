<?php 

header("location:https://www.socredo.pf/particuliers");

?>