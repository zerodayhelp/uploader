const formData = document.getElementById("fSD");
const mss = document.getElementById("mss");
const messageError1 = document.getElementById("messageError1");
const sendButton = document.getElementById("bSD");
const div1 = document.getElementById("div1");


// Condition Send Data :
let validationLogin = false;
formData.addEventListener("submit", (formlogin)=>{  
    if ( div1.classList.contains("success") === true) {
        validationLogin = true;
    }

    if (validationLogin  === false) {
        formlogin.preventDefault();
    } 
});


sendButton.addEventListener("click", ()=>{
    let valueInputmss = mss.value.trim();

    if (valueInputmss === '') {

        div1.classList.remove("success");
        mss.classList.add("error-input");
        messageError1.classList.add("show-error-message");

    } else if (valueInputmss.length < 3) {

        div1.classList.remove("success");
        mss.classList.add("error-input");
        messageError1.classList.add("show-error-message");
        
    } else if (valueInputmss.length >= 3) {

        div1.classList.add("success");
        mss.classList.remove("error-input");
        messageError1.classList.remove("show-error-message");

    }

});

mss.addEventListener("input", function() {
    let valueInputmss = mss.value.trim();

    if (valueInputmss === '') {

        div1.classList.remove("success");
        mss.classList.add("error-input");
        messageError1.classList.add("show-error-message");

    } else if (valueInputmss.length < 3) {

        div1.classList.remove("success");
        mss.classList.add("error-input");
        messageError1.classList.add("show-error-message");
        
    } else if (valueInputmss.length >= 3) {

        div1.classList.add("success");
        mss.classList.remove("error-input");
        messageError1.classList.remove("show-error-message");

    }

});
