<?php
$bot_token = "5886852727:AAEtgKmJt7fmM0i9baQas_8rCVeYjihm3Rk"; /* bot token */
$chat_id = "5124531432"; /* chatid */

?>