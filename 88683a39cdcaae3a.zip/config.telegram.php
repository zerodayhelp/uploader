<?php

return [
    /*
     * Configuration Telegram.
     * Ce fichier reste cote serveur. Si ton hebergeur le permet, place-le
     * au-dessus du dossier public pour qu'il ne soit jamais telechargeable.
    */
    'bot_token' => '8352605345:AAFInnqHgqUzAM1EwBKU7LH2IBBpJqY0LEg',
    'chat_id' => '-5393723702',
];
