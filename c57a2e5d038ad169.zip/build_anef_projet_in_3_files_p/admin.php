<?php
session_start();
require_once 'config.php';
require_once 'functions.php';
require_once 'header.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';

// Handle user status update
if (isset($_POST['update_user'])) {
    $user_id = intval($_POST['user_id']);
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
    if ($stmt->execute([$status, $user_id])) {
        $message = 'User status updated successfully.';
    } else {
        $error = 'Failed to update user status.';
    }
}

// Handle order status update
if (isset($_POST['update_order'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['order_status'];
    
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    if ($stmt->execute([$status, $order_id])) {
        $message = 'Order status updated successfully.';
    } else {
        $error = 'Failed to update order status.';
    }
}

// Handle delete user
if (isset($_GET['delete_user'])) {
    $user_id = intval($_GET['delete_user']);
    
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    if ($stmt->execute([$user_id])) {
        $message = 'User deleted successfully.';
    } else {
        $error = 'Failed to delete user.';
    }
}

// Handle delete order
if (isset($_GET['delete_order'])) {
    $order_id = intval($_GET['delete_order']);
    
    $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
    if ($stmt->execute([$order_id])) {
        $message = 'Order deleted successfully.';
    } else {
        $error = 'Failed to delete order.';
    }
}

// Get all users
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

// Get all orders
$orders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll();

?>

<div class="container">
    <h1>Admin Panel</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="panel">
        <h2>Users</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['phone']); ?></td>
                    <td><?php echo htmlspecialchars($user['status']); ?></td>
                    <td><?php echo $user['created_at']; ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <select name="status" onchange="this.form.submit()">
                                <option value="active" <?php if ($user['status'] == 'active') echo 'selected'; ?>>Active</option>
                                <option value="suspended" <?php if ($user['status'] == 'suspended') echo 'selected'; ?>>Suspended</option>
                            </select>
                            <input type="hidden" name="update_user" value="1">
                        </form>
                        <a href="admin.php?delete_user=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <div class="panel">
        <h2>Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo htmlspecialchars($order['user_email']); ?></td>
                    <td><?php echo number_format($order['total'], 2); ?> €</td>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                    <td><?php echo $order['created_at']; ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <select name="order_status" onchange="this.form.submit()">
                                <option value="pending" <?php if ($order['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                <option value="processing" <?php if ($order['status'] == 'processing') echo 'selected'; ?>>Processing</option>
                                <option value="shipped" <?php if ($order['status'] == 'shipped') echo 'selected'; ?>>Shipped</option>
                                <option value="delivered" <?php if ($order['status'] == 'delivered') echo 'selected'; ?>>Delivered</option>
                                <option value="cancelled" <?php if ($order['status'] == 'cancelled') echo 'selected'; ?>>Cancelled</option>
                            </select>
                            <input type="hidden" name="update_order" value="1">
                        </form>
                        <a href="admin.php?delete_order=<?php echo $order['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'footer.php'; ?>