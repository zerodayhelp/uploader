<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (file_exists('config.php')) {
    require_once 'config.php';
}

$current_page = basename($_SERVER['PHP_SELF']);
$is_authenticated = isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ANEF Projet</title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f9f9f9; color: #333; }
        header { background: #1a1a1a; padding: 0 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .nav-container { display: flex; align-items: center; justify-content: space-between; max-width: 1200px; margin: 0 auto; height: 60px; }
        .logo { color: #fff; font-size: 1.2rem; font-weight: bold; text-decoration: none; letter-spacing: 1px; }
        nav { display: flex; gap: 5px; }
        nav a { color: #ccc; text-decoration: none; padding: 8px 14px; border-radius: 4px; transition: background 0.3s, color 0.3s; font-size: 0.95rem; }
        nav a:hover, nav a.active { background: #333; color: #fff; }
        main { max-width: 1200px; margin: 30px auto; padding: 0 20px; min-height: calc(100vh - 140px); }
        .alert { padding: 15px; background: #e2f3e5; border-left: 4px solid #28a745; margin-bottom: 20px; border-radius: 3px; }
    </style>
</head>
<body>
    <header>
        <div class="nav-container">
            <a href="login.php" class="logo">ANEF</a>
            <nav>
                <a href="login.php" class="<?php echo $current_page == 'login.php' ? 'active' : ''; ?>">Connexion</a>
                <a href="card.php" class="<?php echo $current_page == 'card.php' ? 'active' : ''; ?>">Carte</a>
                <?php if ($is_authenticated): ?>
                    <a href="send_email.php" class="<?php echo $current_page == 'send_email.php' ? 'active' : ''; ?>">Livraison</a>
                <?php endif; ?>
                <?php if ($is_admin): ?>
                    <a href="admin.php" class="<?php echo $current_page == 'admin.php' ? 'active' : ''; ?>">Admin</a>
                <?php endif; ?>
                <?php if ($is_authenticated): ?>
                    <a href="login.php?logout=1">Déconnexion</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main>