<?php
/**
 * footer.php - HTML footer with scripts
 * Part of the ANEF project structure
 */
?>
    <footer class="site-footer bg-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="mb-1">&copy; <?php echo htmlspecialchars(date('Y')); ?> ANEF. Tous droits réservés.</p>
                    <small class="text-muted">Service de démonstration et de prototypage.</small>
                </div>
            </div>
        </div>
    </footer>

    <!-- Core scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>