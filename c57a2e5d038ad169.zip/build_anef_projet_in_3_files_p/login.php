<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = sanitize_input($_POST['phone']);
    $sms_code = sanitize_input($_POST['sms_code']);
    
    if (empty($phone) || !validate_phone($phone)) {
        $error = 'Invalid phone number format';
    } elseif (!empty($sms_code)) {
        $stored_code = $_SESSION['sms_code'] ?? '';
        $session_time = $_SESSION['sms_time'] ?? 0;
        
        if ($sms_code === $stored_code && (time() - $session_time) < 300) {
            $user_id = login_user($phone);
            if ($user_id) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['phone'] = $phone;
                $success = 'Login successful! Redirecting...';
                header('Location: card.php');
                exit;
            } else {
                $error = 'User not found. Please register first.';
            }
        } else {
            $error = 'Invalid or expired SMS code';
        }
    } elseif (empty($sms_code)) {
        $verification_code = rand(100000, 999999);
        $_SESSION['sms_code'] = $verification_code;
        $_SESSION['sms_time'] = time();
        $_SESSION['phone'] = $phone;
        
        if (send_sms_verification($phone, $verification_code)) {
            $success = 'SMS verification code sent. Please check your phone.';
        } else {
            $error = 'Failed to send SMS. Please try again.';
        }
    }
}

function login_user($phone) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
    $stmt->execute([$phone]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user ? $user['id'] : false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ANEF Project</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center mb-4">User Login</h2>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               placeholder="+1234567890" required 
                               value="<?php echo htmlspecialchars($_SESSION['phone'] ?? ''); ?>">
                        <small class="form-text text-muted">Enter your phone number to receive SMS verification</small>
                    </div>
                    
                    <?php if (isset($_SESSION['sms_code'])): ?>
                        <div class="form-group">
                            <label for="sms_code">SMS Verification Code</label>
                            <input type="text" class="form-control" id="sms_code" name="sms_code" 
                                   placeholder="6-digit code" required>
                            <small class="form-text text-muted">Enter the code sent to your phone</small>
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo isset($_SESSION['sms_code']) ? 'Verify & Login' : 'Send SMS Code'; ?>
                    </button>
                </form>
                
                <div class="text-center mt-3">
                    <a href="admin.php" class="btn btn-link">Admin Login</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>