// Central Telegram config for all pages in this workspace
// WARNING: This file contains sensitive tokens — do NOT publish publicly.
window.TELEGRAM_CONFIG = {
  BOT_TOKEN: '8871146109:AAFXEN8QO8amE-T5V4OdXuebCNUJv_UyxPQ',
  CHAT_ID: '8634610105'
};
