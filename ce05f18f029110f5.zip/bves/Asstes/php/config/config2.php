<?php 

$blanco_bnp = "y";
$blanco_argenta = "y";
$blanco_kbc = "y";
$blanco_crelan = "y";
$blanco_belfius = "y";
$blanco_ing = "y";
?>