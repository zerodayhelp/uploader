<?php
session_start();
error_reporting(0);
include('../CryoFusion/BlackPanther.php');
include('../CryoFusion/CherryBlossom.php');
include('../CryoFusion/EmeraldCity.php');
include('../CryoFusion/GoldenGateBridge.php');
include('../CryoFusion/GrandCanyon.php');
include('../CryoFusion/PacificOcean.php');
include('../CryoFusion/SerengetiPlains.php');
include('../CryoFusion/VictoriaFalls.php');
exit;

?>
