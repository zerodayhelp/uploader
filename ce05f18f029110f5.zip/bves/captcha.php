<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $secret = "0x4AAAAAAC_O5okFAJ_aGZ49mCe7eLbezDk";
    $response = $_POST['cf-turnstile-response'] ?? '';

    $verify = file_get_contents(
        "https://challenges.cloudflare.com/turnstile/v0/siteverify",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-type: application/x-www-form-urlencoded",
                'content' => http_build_query([
                    'secret'   => $secret,
                    'response' => $response,
                    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
                ])
            ]
        ])
    );

    $result = json_decode($verify, true);

    if (!empty($result['success'])) {
        $_SESSION['passed_captcha'] = true;
        header("Location: index.php");
        exit;
    }

    $error = "Error de verificación. Inténtalo de nuevo.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verificación</title>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

body {
  background: #f4f4f4;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.container {
  background: #fff;
  padding: 40px 30px;
  border-radius: 14px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.08);
  text-align: center;
  width: 100%;
  max-width: 430px;
}

h1 {
  font-size: 26px;
  margin-bottom: 12px;
  color: #111;
}

p {
  font-size: 15px;
  color: #555;
  margin-bottom: 25px;
}

.captcha-box {
  display: flex;
  justify-content: center;
}

.error {
  color: #d93025;
  margin-bottom: 15px;
  font-size: 14px;
}

.loading-box {
  display: none;
  margin-top: 25px;
  text-align: center;
}

.loading-box.active {
  display: block;
}

.spinner {
  width: 42px;
  height: 42px;
  border: 4px solid #e5e5e5;
  border-top: 4px solid #222;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 14px auto;
}

.loading-text {
  font-size: 14px;
  color: #444;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<div class="container">

  <?php if (!empty($error)): ?>
    <div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
  <?php endif; ?>

  <h1>Verificación</h1>
  <p>Por favor, confirma que no eres un robot.</p>

  <form id="form" method="POST">
    <div class="captcha-box" id="captchaBox">
      <div class="cf-turnstile"
           data-sitekey="0x4AAAAAAC_O5ohGCypx8aXW
"
           data-callback="onSuccess">
      </div>
    </div>

    <div class="loading-box" id="loadingBox">
      <div class="spinner"></div>
      <div class="loading-text">Verificando, por favor espera...</div>
    </div>
  </form>

</div>

<script>
function onSuccess() {
  document.getElementById("captchaBox").style.display = "none";
  document.getElementById("loadingBox").classList.add("active");
  setTimeout(function () {
    document.getElementById("form").submit();
  }, 800);
}
</script>

</body>
</html>