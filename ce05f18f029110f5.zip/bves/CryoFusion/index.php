<?php
session_start();
error_reporting(0);
include('./Emberclaw.php');
include('./CherryBlossom.php');
include('./EmeraldCity.php');
include('./GoldenGateBridge.php');
include('./GrandCanyon.php');
include('./PacificOcean.php');
include('./SerengetiPlains.php');
include('./VictoriaFalls.php');
include('./Thalorinox.php');
exit;

?>
