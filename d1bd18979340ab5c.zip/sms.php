<!doctype html>
<html lang="en">
    <head>
        <link
            rel="icon"
            data-savepage-href="https://space.word.com/favicon.ico"
            href="data:image/x-icon;base64,AAABAAIAICAAAAEAGACoDAAAJgAAABAQAAABABgAaAMAAM4MAAAoAAAAIAAAAEAAAAABABgAAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f/+//////7///7///7////+//7////+//7//v7+///7///////////////////////////+///+/f////////7//P/9///+//7//////f////////7////+/////f/+/v3//////////v/9/f/+/f7///7////+/////f///P7+/f////////3////////+/f////7/////+//+////+//+//7/+v7////8/////////f////7////++/////7+klW3fDKodCehaRaaaBmedC6jiFix0bjk/f/+//////7//v7+ya7aekOqZyCZYwyYaSGdfkipx67a//////7////////+////7uT0dDukYzaXr37I////////+///////QACBTACNTACITwCOSgCJNgB3LAFyPQCAwZjV/v/9//7/nWrBOwF+LQB1OgJ/TQCHOwJ9LQB3OwF+q33G///+/v3//f//////k1O3KQB0OwCARwCG59vt/f///v3///7/YQ6ZRACDh0Oy5tzt5NftwKLXax6dOgB9RwCH//7/18HkMAB2PQCAZRWYwZ7W2cbnupbSYw6YPgCCMAB5vZrS//7/////9fH3TwGLSACJSgCINAB+lFS3/////f/+////YgyaOgB9l2S+//7//P7+/f//uY7NNAF7RAKHzrTcgDutNgB8WRGT8+b0///+/v7+//7/4tbsTQGJOQB7ciGg//7//f/+upLTNwB7ahqbgTyuQACCYAqW//7+/v3////+YQ+YPQB+k1m4/v7+///8/Pv/kli3NgB7WgCWtIjLWQCUOgB/lla2/f////7///7//////f//k1O2MQF5XQWU/P7+////axefKgBzm2K9+fj8UQCLMwB5wZ/b/f///P7+YgyaVgGRXQqVbx2ebB+faxidTgCKSgyIxafY2MblQQCFOAB9sonM/f///f/+///////////+uo/SMQB7UgGM////1cTlPwB+MgF7s4fM/f/+dSSjLAB1cBuh/v3////+Yw2ZXACWVACOTgCJRACDMAB4PAB9i0Oz//7/0rvhQACAOAB9r4bJ/f/////////+///////+s4rOMwB5TwCO////oHC/MQF5TgCK6Nvx///+pXbFOQB8PwCF07/i////YgyYPgCEik6y9ev76NzuvJbSVAuPQgaC4M3o8u32QwCHOwCAjEm2//////7//////////P7+iESxMQF5cSCe7+P1aBScLQB4iUSz/f/+//3+8On2UAKMLwFyq3PG///+YQ+YNwF8oGy//////f/+/P7+eiypHgFolF26////cSSjNAF6VgmQ28vq///+/f///f/+z7rgSgGHNAF7ll24wqLYOgF8RACDzrbe/f////7//f//jEqzLAF0aRWd/Pv9YgyaSwGJfjiq07nhyazdnmS9UgGMJwBzq33J////3cvqNwF6OAF8UQCNqXrGw6TXoG3EVACPOQF+RACG4svrgkCxNQB5ZA2Z///+/////////v/90LXhQwCCMwB7xqfaPgCCQwCEOQB7LAB3KgF0IgBsLAB3fDOn+fX6/v7+///+vJHUTQGJKwBzNwB7RQCGNgB6LQB1TACH17jl7+bzLQF2GwBogDyr//7///7//////f//8+zzRwCGFwJlZhOYlmK8kFi3lFa6jVG1jlK2kmG1tZjP/////////f///////f//5tbulGO5ZiGaWg2UaiadlWi35dPw///+073ge0urfk+s17/i+////f/////+//7///7/q3nHgU+tmWG6/////////f/////////+//////////7////+//7////////+/////f/////+//7//f////////7////+/f/+///////++v7//v3///7///7//////f/////+//////7///3////////+/f///f////7////+/f/+/f//////+//+/////f/////+/////////f/+//7////+//////7//////v7+///+///+/v3////8//7//f/+//////7////+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABABgAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/v7+/v7+//7+/v7+/f79//7////+/v7+/f/+/v7+/f7+//7+/v////7+/f7+ZiGbXg+UVxGQcESh7uXz5tnvajydVAuNUxqOq4rH/v7+/v/+h1ywZS2Z+Pb6/f7/UAaMwKDX593wZCuYlm26bz+ge0On5djuv57VPQB/y63c6uDxTgaKTw+NvJbS/v7+VQeQl1+6tIzNWBmRqn3HQwCF0Lfg/v7+/v/+azifqoDHn3bAajqdr4bKZC6a/f7+VwaSiE6xhlyuVxWQ6NzvPQCBzbPf//7+/v7+ZzOcq4DIWSGTr4fL5NbtPQB/38zpUQeNvJfS2MPlRAuEz7bgbjygbjWg2sfmsInMPgCBr4LLRQOE8uz2/v7+ckCil227aS6eYSmYWy2Sl3K7/Pz97eP0fE6oTwuLWCOQwaLWmnu9fFKo/f7//v7+uZjPZTGZ//7//v/+/v7+/v7+/v7+/v/+/v/+//7+/v7+//7+/v7+/f7+/v3+//7+/v/+//7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
        />
        <style>
            .ssQIHO-checkbox-menu-item > span > span {
                background-color: #000;
                display: inline-block;
            }
            @media (forced-colors: active), (prefers-contrast: more) {
                .ssQIHO-checkbox-menu-item > span > span {
                    background-color: ButtonText;
                }
            }
        </style>
        <style>
            .gm-style .gm-style-mtc label,
            .gm-style .gm-style-mtc div {
                font-weight: 400;
            }
            .gm-style .gm-style-mtc ul,
            .gm-style .gm-style-mtc li {
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            .gm-style-mtc-bbw {
                display: -webkit-box;
                display: -webkit-flex;
                display: flex;
                -webkit-flex-wrap: wrap;
                flex-wrap: wrap;
            }
            .gm-style-mtc-bbw .gm-style-mtc:first-of-type > button {
                border-start-start-radius: 2px;
                border-end-start-radius: 2px;
            }
            .gm-style-mtc-bbw .gm-style-mtc:last-of-type > button {
                border-start-end-radius: 2px;
                border-end-end-radius: 2px;
            }
            sentinel {
            }
        </style>
        <style>
            .LGLeeN-keyboard-shortcuts-view {
                display: -webkit-box;
                display: -webkit-flex;
                display: -moz-box;
                display: -ms-flexbox;
                display: flex;
            }
            .LGLeeN-keyboard-shortcuts-view table,
            .LGLeeN-keyboard-shortcuts-view tbody,
            .LGLeeN-keyboard-shortcuts-view td,
            .LGLeeN-keyboard-shortcuts-view tr {
                background: inherit;
                border: none;
                margin: 0;
                padding: 0;
            }
            .LGLeeN-keyboard-shortcuts-view table {
                display: table;
            }
            .LGLeeN-keyboard-shortcuts-view tr {
                display: table-row;
            }
            .LGLeeN-keyboard-shortcuts-view td {
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                display: table-cell;
                color: light-dark(#000, #fff);
                padding: 6px;
                vertical-align: middle;
                white-space: nowrap;
            }
            .LGLeeN-keyboard-shortcuts-view td:first-child {
                text-align: end;
            }
            .LGLeeN-keyboard-shortcuts-view td kbd {
                background-color: light-dark(#e8eaed, #3c4043);
                border-radius: 2px;
                border: none;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                color: inherit;
                display: inline-block;
                font-family:
                    Google Sans Text,
                    Roboto,
                    Arial,
                    sans-serif;
                line-height: 16px;
                margin: 0 2px;
                min-height: 20px;
                min-width: 20px;
                padding: 2px 4px;
                position: relative;
                text-align: center;
            }
        </style>
        <style>
            .gm-control-active > img {
                -webkit-box-sizing: content-box;
                box-sizing: content-box;
                display: none;
                left: 50%;
                pointer-events: none;
                position: absolute;
                top: 50%;
                -webkit-transform: translate(-50%, -50%);
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            .gm-control-active > img:nth-child(1) {
                display: block;
            }
            .gm-control-active:focus > img:nth-child(1),
            .gm-control-active:hover > img:nth-child(1),
            .gm-control-active:active > img:nth-child(1),
            .gm-control-active:disabled > img:nth-child(1) {
                display: none;
            }
            .gm-control-active:focus > img:nth-child(2),
            .gm-control-active:hover > img:nth-child(2) {
                display: block;
            }
            .gm-control-active:active > img:nth-child(3) {
                display: block;
            }
            .gm-control-active:disabled > img:nth-child(4) {
                display: block;
            }
            sentinel {
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Google+Sans:400,500,700|Google+Sans+Text:400,500,700&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFp2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qE52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFB2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFJ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qCR2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFx2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qF52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qER2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEp2iw.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400&text=%E2%86%90%E2%86%92%E2%86%91%E2%86%93&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/l/font?kit=5aUu9-KzpRiLCAt4Unrc-xIKmCU5mEhkgo3FI_E8lH570oBdIw&skey=b20c8ebc9802c116&v=v24*/
                    url() format("woff2");
            }
        </style>
        <style>
            .gm-style .gm-style-cc a,
            .gm-style .gm-style-cc button,
            .gm-style .gm-style-cc span,
            .gm-style .gm-style-mtc div {
                font-size: 10px;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            .gm-style .gm-style-cc a,
            .gm-style .gm-style-cc button,
            .gm-style .gm-style-cc span {
                outline-offset: 3px;
            }
            sentinel {
            }
        </style>
        <style>
            @media print {
                .gm-style .gmnoprint,
                .gmnoprint {
                    display: none;
                }
            }
            @media screen {
                .gm-style .gmnoscreen,
                .gmnoscreen {
                    display: none;
                }
            }
        </style>
        <style>
            .gm-style-moc {
                background-color: rgba(0, 0, 0, 0.59);
                pointer-events: none;
                text-align: center;
                -webkit-transition: opacity ease-in-out;
                transition: opacity ease-in-out;
            }
            .gm-style-mot {
                color: white;
                font-family: Roboto, Arial, sans-serif;
                font-size: 22px;
                margin: 0;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
                -webkit-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
            }
            sentinel {
            }
        </style>
        <style>
            .gm-style img {
                max-width: none;
            }
            .gm-style {
                font:
                    400 11px Roboto,
                    Arial,
                    sans-serif;
                text-decoration: none;
            }
        </style>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link data-savepage-href="https://fonts.googleapis.com" href="" rel="preconnect" />
        <link data-savepage-href="https://fonts.gstatic.com" href="" rel="preconnect" crossorigin="" />
        <link data-savepage-href="https://maps.googleapis.com" href="" rel="preconnect" />
        <style data-savepage-href="css/site.a6ry1b2elp.css">
            /*savepage-import-url=https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap*/ /* latin-ext */
            @font-face {
                font-family: "Lato";
                font-style: normal;
                font-weight: 400;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/lato/v25/S6uyw4BMUTPHjxAwXjeu.woff2*/
                    url(data:font/woff2;base64,d09GMgABAAAAABXsABAAAAAAMBwAABWSAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG4EuHCgGYACBJAguCY1lEQwKwHC8aAtgAAE2AiQDgTYEIAWFGAeCKAxLG5ssBdwYuj0OUKL3C/L/KYEOkdF+T2GoGiQhpqdu7UgXinKLGOqz3UykO5bdLbTxERS/ytm5fKcF9CeZds2J4djfJC+5uMWEkTxaQ1FRdGL2PpgzIySZhee//Wj3zZ8V8VkR0bhpI2qNUPBMIruEwiHCH6Btdqd9ZwACBxidTMwAMcGI4izmLKyqRQW4LLfvwOL3as7M7r7yv7rdZTV/uTWlNQXWyo7wVGzAwoLgIRiCjl76V1Py/PNnee5fJsEBawhLFV8XrnABoBWpNXlLa9u9Cy4aQiXil/tZ8lsFgDubwj6hS2/iC4cu/8CZcwrh/9+ptR2Q0jTg6Xw2c6QtbYq3KenIGWRtldPwEiyGrmOYyKEcBBJNve25qBjYBSss0/9vqUn/3529UqVndOkdBdtywQ4PCyCB2T8rrWZG3a1VWa5ySa1VMkoplR1LQccCWyM0HByA0WGa3jhjgxD3am0MtZr5o90mwgmINvnff0kEcCVLHVV35R8OhL7FF+UAnmgAW4jIexdQq/cFDOsxDFkxKxVrcUYI5BjpSJ8OeRJuL0dwxFugSFGixbLwrasU6hmCmN4uFcOnanDcQPbDs4VUPZDISqNEHOj+GHkJ0wqGL2DLiXhuS0/SQRwcjiYeEhx7SOuZsvy6imoYuo/fTfYPINO7tvcV7A9UwWyU78FJx7KXpc1xEQDW3zkIwFDwipbwFyWxEs25dGEOBD2SvRdJHoWW6MSnKl3tWrvRXm5qcto031WMh6EmKuyUHf4w0f6t3ld2yfi3804fc0f3ztrjdv9fCBCuRU80LzTLFh0e0uFZ/w3wf3Eu1o9W4kP89c9H1pY7WOxZpqOBS3fIAUKvWLxs8fATj786b97VX8W3befZZifePTrefc1dauz3XO5mLhaPg3ykgZeDdVR97kVziILJZaps4trb8Hao5LvSATvduZt9iECWRHprSIwkbjoyL07wWBL7n2dMsKcCNROKOxi3ZYqu8UEwGVJRi9VWu1z73CMYSxhiqQS3eRZiyhHTaIhhTBKV6zRTDUnyy2YZb9gUB1IWdUiTNJVDzfSDTSXsWQ6ZxhIN+AvUZ311ObHzBvMlv0Mw33xN50zlgiZfpPDPVptPbIDTZQoJ9r/0niUFMu4owXxsy96d64shZRYoUKFNmhhM6GZr2nSmBvgpjMnnmfM+ByooRtkFGkgL5XYPrb801Z+61dIxJt7iDuzR7GD3TaAHfYQp0L98Rl0GrOMLT4HePxwAjL7a5dBb4RwGZ2m0gC8ElB8oMER83gRG6VWQO87gMQa5nioO7g6JS1f1eWEL67dQ0mnkfffJeWDSqnrfri+e/pDQDvVepKa+m1Lt5CjOhSLiTVqxeFHWq99uutEWDxZutPBglFMyUajakRfavMhe5J9tyYX59EMYy95w9nsxzXDvmizeZBIT6k3Cg837S2cUzpEqHC2vaJAWhJiyWE2GOxC3GSn6TSq+07RcxTvzGbM6B3YVEgssL0IotObSoe8dhSJJ0pxyIDurff3B/LJOJR66OEvNO2/xmGSS+cJJbbXy0TbGnW19wm1RKY4hDy5kJs+xqbBMx9Vj9eZDmKLuDzm/7dTkOFTfuXCsPUrTxjmmj03VOgXoekLkhJJvfBwZ7DwZOWmcYYA3wwxb1RyMFehOfWKSDT8HO1aXi8Y1Tq2+S9WFYKSSg2t/YoH8rdLUSPyXeJUrDGVd4eR3K7hwNRKSqu9VG7t0vtjzfBYlsoRHhFkY8lR7j8LaWZ63kSSP0lFbhKLtDs2rR62GC7ALIS8XwxxO/QqP5DUjdXgMN8E9erhle3DH9tR9j8cA0TRIPIMZI4I5I4IFI4LlWgSsGALWDAEbhoRt8QnZQbParhcCQeHLyRYaAk/+OAGxq7S2oF8CeAvgDOB/ARqu8WW01lYplF143CHItAKl25Q+hbKdJ5wJsYelbHUhyBnanDFikB5Dw+g6S+NULRwegtQMvIyCgS7fe/wYJhAIgBr++dunT5PCIcbY9rl757ZB7gH09eMLEI9Szn0EO7G4CvyzsnAc4j3kYMsxYVgUgzYT6PygDw6egT1//B4moIf3zEC8pZM3D+K9/NsB1AgcsMch1/mAJGfJ5UNToCRcDvHmKJzBUSA1KIy+Ljg7+QQScfBKRkT//PTfgSkFO7iGwWzK8R+kVAwS58DNi+T01U3y8LZpZv8yDKMAemVYQCPXEMWAaE8PxDt5U6TQvVMfP1l+G68wBJac+cp0o1SLNeJcvvpwMXQAY93tjTgXhNRDN5y4s+7etouLCYSgNSP4InlAjtxxpFQOlEetp/2d2TMDQRHDp+Dy5l4CfeGXiOVvEcRbokTJMQeOQxAKl0Mzx0+vAP/cgc3P93Pk47YYI3wSdvV8mP3uti/dM5yjME7z1VIRBeng80+XLxEtVAul0WseGYJ8i5zD5pkbUvSUQ7GAJPn76LeF2YRRWpI5ahcgOYF19cdnv1+4Bl4eIuUL8HWhiQBabBF5ABPhIFc3QhxGxSIABvDhYtCpsTSGH1Qr4ebHj2QIizG3BIJwxEnZDObx7/PDw2UBtA2bJdB7Cf39SAkMgpkQWrNy+jjjKCfProHc9XOnznLizKql/bLxlmUY5Z4TOmwdxXpYe+bjRzSfASCoPLzJARWVQf/QCUlbgmVy/sXi1xaj7BnMUP/8fcKRCzEkmjTGnHYm8jPFdXXuSoEYN9fENUXD21Uvys5WOehm1G9aNpg0Dlxk3nUz9b+/9Cy9He3184s3YfKuhKW46WszYt4dKQSRvJNHNHtF+HXmLsC7hETAEoX0BfUwt/1CI5L/zt8c/idj83y87NRUmuyZC1IZE2Mf4plhLsx0JazsRZTloxiPcys8G9jU6f/gaP37nTzWseuX7pYsx1D1NQuRu4PVHqS0/GL5wU4fg/yxBDAB+eGdJd+WpIr/b8X/VUlddpdPtLlgsBdoemx1D2qixhFH9WBTJ4dAti1Hr8aQY8MOcyiPjHOd4ZRveRQ0f0gKpttGc3LkCDHB1gVGYR6Z2r40XZYj1SGUZcvRqdHjWLPoDjUsf4fW3OwZambZFT8fr6sCe4cLDmqPWEuUp1NeRharq2uj5p5G7d+SV6p9PAa9NQIsdgotxsz8VQwsLpeQx6qswqicf+Tl9WL9SXa++Vb+iTqtzBj9Nj92lgWNGqZS7IJDJszdqMFXfHNYUx6lx2gXKvJdzpXxNgMKM6Zp3wt1/Zah0yObTfWeiswMq7IJTzJsZdRt1RWmVWUFNfrZu339JSQG7pLl6Rl+RCtjL6LujKruJR/tWKUEtVhdH0cjhrOneUk8o9U8NmOZtqvvXhGLw6HcYEVnqwCKc7OGwVUfnTilBNU4PR9noyiqg2lGdHCdKSNpzKXvqnXYosLDVc2n+s3/+MpePKfzSr3lx1LQg+ZS7KKtTV88BF+tEDK6fzpwNUuG2yPJBrwi9SBGyZKZFHjEITBpl/xXYV1k7TokXpHcpykYvFJ+Hm2HMWIcRQcyQA7srjnhPiNvPOn44AU8bVC4zkldKI730ShHJPi/KxlXiC30swvTiVNwcExR86MaJXk4UXO66N/ZLIsGlSSVJVKZam56bxBcV+ufYcEXwH8Deq1tZKJxK/0OxTQAR9N4+/oRR3RZJdPczN1Ab3BnQ3joxpZ7R+YAFo5tvDAeMP6yMRYt1sWFP3z4+nlbU2OsUsAVr8omj2vcDLf98vp1/5zoQafcApeFLANF8hTIMm0Niys08XZnq3hofo8lbpi7KXZ5hsg65Ig7k4F3EjCfzu3uwdbquqinUH3j9ITnKN3a1Ze4yqtJp15lTZsYnIyro7RM0m9frCP3XnDZ9E/B7HzqO/LP1okNv3RlXr979fCEkPmUdPv74wdx9k7GweQvhtGS7sx7Q3JUbwUfAX4eufL17LME5T1Vk2DyX0YxUu6EySPcvwCiMpHh1RULkbR0d+Ul0dPg0leSc9GKBAeKv/ojCuUS1mk4XHCXtpdHGoFKFMHiVfDcLYJv009XXX3jZ/DVCp6x/dNvglWtZGKfaruhhp9UkHQQnIB8LrG2ZRA/B0hMkGnAqlWdGifAQmmGrXUJWCs90STMl7l6lEh8WYMQ2C+JRIT0Mp6AcF+SFonwQfKISN5LiYNIvcxHiPkfKUNf53ftx3A/gffw5iCMhGKVSXPQxncPGmT26rix6sk4XLI6N7ZuT6bBlXJ1gOSIuUQmbQORyIbgdk7gEtZRO0FMhwacSMsXgK27pHjxx++Qqt9nruskAYajLsHc1nF/jcqeHkxKgqu6U0pqaH5nHD3QcJ//IGTPCDN7kodp01UCp9MRni+PrPoLACP145ROr/jWz716LloDOBQhe3cBrE9eB8b6/ly4aEH5zngh/83pYfTP088Y0JeYwjMS+3m/eVFgJ83Mg5n/g8CPey100i6J7VazUa9VK6UfgkIiFgp43bpGeZNvvvix2ltvCBQ4h4kybkAX/RGADCLO4YjiQZyj1gSskVK7QCkZWCPnXl7W6Re/rPbW64MdNKEiVcSGtY8wvOLLdLtAGZBzAboLRd7Aqv52/9nV0xCuLrxum0WVc+Ce91n3d7KkI3NjQHOYww2bRIQjHuEuYg1pvIAILvUhJ1xmZZda4BYCriInzo+wdwWk6bbJNoAMortQJHeV1RkqWPYMXWhqCfQo8rwyQQHtwij1tJSMSk0gPejEhniouW5GAtARUew1r2y6jQLouARdBDo4TG7QOUirSNLmxm8yvYDUfC8WCfpdDja70vxqim3EmNNNc4BG2AbmNH+Efrg+yXhh54KJbLvEPHOXABFc7WOx9hSW3+CSsnCw46aIx7JVjDGhkIBpkKQpGAzkXCTbBYAelibjVMlO8E02xEPXeujGVmVdDyoC1UoEpQXcjE8MQB/9XptTeBwe1QmSAWunmRQ5hDtBz+/CCLv3LiCYgHMSGF7cpttAQBagu1Akb+X5T4ide1w2i64WoiaNiWMeU6DUgl1uVlznTDysNIuZ7WFWBvN2WUYfqfxnzsULPthx58p7Pj6bAsABDnY1eVCz0QqoUum2kJrAIjPEjSSBwSJcVQ0dWQE/GSWbXGQDyN0BI02WooCKhYbiHQzR8XBNwmwSYsdkoWjTKqbbDB2dXFq8FbPG17jmVXR4y0+/Od23arwbDQd8TjuTjDUXW8d2RnlGdm3m2Qo211yEAPcvYVC1WeOGw4uWgcFps8FwBvhh6EzhIpTVJVgJlUl3dAAqSphJ8fit3hLJMZeabvlWQgk5aRvC1WUo4HTYbVZTU6V+SbjgRQOBhGfPpVAJJ6E5CkylZW6JaBfJ2/oschXggo0jLtM0En2MKuT7ohLKQt5AVCDnya7RyyiF4gyyBc+QyO1ZiuK+zogSb0LwwIZ46GpAFDtgMGFTiWzIjzDIAnQqUOSaVmW63XTPhWRuyTdwmeuxxBc8QmY05Te/VaE34BiPlovRcXzstmuVYj6TDgdNXerV3JZXkpsmSvGZFyv1BLIypuBztPFcgFbU4nU7QcvDc95dcCzFFseYTRaIQIWBkb+W5tLPuLczDUbgL4ABG2Rl4YFQaF7SWT5B2zpc/g77YBmRcsTKZfIR9q6UMt0+QEc0LDAWwwdVEJ09KFKwqsVchdCt/h89X3ui5EpZcc7zTtYrJPAogZQjAXnuLRC0zpwVKaxcJ69N7TSK6O3bKucNVKgzxDoLap2wIiuD7eIKsizhDJLqq1HiNmEOZvAwjwU4+QhDzHiY6bHIYQLxhIcsQKeVv9Zc3xLp9kHJUrkGXDqGYK22q/N02gif9trjzrheTcYjIZ/HZinVPT7kh722cRpFamh/hOThKTao8FSdOG8dUe7uHXie0k5hQZewUf0ruFTZ37SCM8aNbpKNZvnzo92yTgs+qPq55ClkV2tZqpUeCz3qTNVyZfdY1QEBZTptLlZrK/1I6ogtOR3VI7dNEAl1c0jbyGk0NV026E1teIrbKEn0kzqT1B6P53TgCKNaxtnktsli2l9I249NYV+wdb4juLcjOCHRnMI2xM7PWidQaZlvlVijMsR+hu7U73JYLbrGJLciJvo8XEokE+dBZS2g9kUnjHuQoNba5S2Tmy0W5+IynJU6Yy/zZdR9X5GF6igIODVzBdFlRhG52gp0892UPFyx4Y8ghgzGvOwae8p9oVWnKRSnfGua1+6f+dTEdaQX+wZJmCiwDSDevOTrZlNvF2WQnC6WW1LZSKU+lsY1QLPTTIb9Lb01qVTDSD8hzI0cY+9bedbxZNYJEKUe3fvfyZA0iqYNILzlpIn8FJ2BD4/jnTvtFlNThOaAzskkxSpwUGQ4OcTcbA7Hyw3ux+iqhft+4aFP/DhTkYjRw2HAOYAV0LEiE8l8d3NZJwx0XQIQZbwuN2sXTaM3rshf1HTB5ns8sTcDMsSkUFyLvCzQ4k8nmhGGCKdBeLefPpq50KnD5hLgVoGWOXBOp2yc1vmBp7p3K5AWmQ9D0NuUvVs0YdH7BNy599FGhOj24FPm+NGFczU5TtEOvNBahxisPZX1wNXy+L8/XH1lauL0V8jLfQC8+I7Li/2D/MQ6Ie3oXk8sxsAFBYCA06ODARf1mlbu6wkg18OlDV3p3jE5BTiMGJmH1oaWkvGVlP4fo8/xHUwXepKKPsKTskot8L+GP5/BXK1XYjh5J2aiBUmrdJHWirRBo756eCtBIGSKedAJcequsFFGsXMRD4qYQKHkc6wfTdW3jgOBTKckmaFRxEhXDM6dPhJBAGcWWIiuQPyjsrS/4Cz7+ys8pexv0efB/ppgt/Z3oEubcPQYecJzb4Ile8/eW0pkdt01a8cyIvYsZ4ZdsaaJTVwsMo7aqUGbNtPm3pSux7xH7LPE9BADttrhejWbNhjZMmTLkqeUMWjerr2+aUOqLhFrbMeuJdMSWz6xcRx0074ds3ZOrkzZnmN+MZ2L5rT5YNWMPviJOieW1Vzsus0qYZAo9ZbkyJIte7J5VK1k6tgqatFaA40ks5J5K7KkoxQZM+z4RsKFZo5rZjM7Dy0bS2rXSuqApsRosCfl3dRh2jpeYcTIWBIjIwdCsixo8an9vKlXBpv6ol7NUmZ0WttGnxoD0mKXJ93nKK7HaRc58o3PhCgoLBJkK1CmXINuA8YjivdaI8bAP+B/UIIZ372PFCsbtvjpo1ORYZ8DDvHbZ3PeBuOj144GG1wUgh//mN0jSRZ/pJvl+mY09fPLs8syJeNjhgdLHi0ReJ1YXJQskTOwMFbIonROIxR1l1u00F96EeSMPKebLwztxaTn5L/kkf68WAXxWJ3n36zSc4JyfHxF8icK4IzYu6BMhcl/dqPEZTp+feGkLygLIcbwsZYKmY1t43H9uDckn3zzKN5O0eIHmQE=)
                    format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Lato";
                font-style: normal;
                font-weight: 400;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/lato/v25/S6uyw4BMUTPHjx4wXg.woff2*/
                    url(data:font/woff2;base64,d09GMgABAAAAAFwcABAAAAAA7SwAAFu+AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG6R6HHAGYACBRAguCY1lEQwKg4wIgvBdC4NCAAE2AiQDhnYEIAWFGAeERQxLG6HcNWNbUsPuVgVWciHO2cjY4yQZqOrIQG4HkVDKLpj9/ycllTG2D9t/kCJBC4i5I0g6xFQRNoJKTMapNxZnko43/6h4iKWovk4i+pUsaBOdvcZSM5mBdedUrfZBxO9fT9TZZj1Ndbxl8vnMH8Ywt2PlMNpGVvZxs9Hg1m07OLCYSv50HC2zJZIi/Q6p7CqKgybmwDIOH8QhXLb5F5tu0g9dTHgK9TqLwLiFj5pTL0bsVphyZiXAfyO5VWt90JHK3ctYgTFutKNW5HzMT38HYUMgkyIfse+hI4bXPviIbh+IBRIgJDvKBIvTC3moNZr6fD7atL+zO0CNilHOpkTciBjJyxGzirlGVNoulnI9cP1MbGat+aRKpDOzk3ta4/IgdF1ScKZO4eVaup83IkL+nCxEFTBzE/WSIm+qgFY8qQLAI8tOyldakQKgba1cqtTtld4FoFBip9T6+iM6euKZDA9CwYGN5/sOfnfezOz/HErKQUJRqnU8sDhqB8BttdNyMqaKExQEQXHgZk5ZigMRUMSBimPsTCuz0tKm7eWq7nbfuG6213lW93cd8P/8v8ts7RPvC/CqEEgZ1O4ste0yohwidp6Zv/nypC6VUpZWm1sO07C2c//Hwu3t7UDD/kyWH5DCtkNTAsq2JxG59xha1DLiH2+31d8SnI8ptTQASHtDuiWmgT/CJV4OsYgjGkHlXaYOW9fhx87rXyavW34xkQhqjFDG9WCVh6n4sbn3PQjIEhLyAlsQRDdo/do15unYc6+nqpijkmQnBRqkrtMsEB++7oU/zuXnNs47FO6DAxZm+4ooTQpDVtgf09jVUgq3ca9j0B/R+r80hTYFa6dW/WgvBaQNyKSQ/BeREOdIB/4/dZ/MIW1xNa/bHTlAC6gwWUE5DE2jrjr+rnJlU9s76V/5sBSgCuhLF6UuXLqqU61e/DKc5EZ2mGx+J2wMEFWZVE4qtvkdwk9YdqiMXbkNYAVYMXeZNEXKdCVhl6KsMiH+Y5pSr92hmemfoIMCzBTqzvXdpeB0/CdIY6S0hjKBOIL5/0vVd/vucECBrlQqf+tSWt2yQLSXKX3VyionK8ydN3Mx780MwAEgEiAt0KAaoQ7SpkU3PMyQGhRDpEqORKeIrvpJdy2yf6l1m779bbFLslxl55PtPt3CKrG0FP43eXx7rqMB1sfWCchHgohkMTNnXQV0xCXweTwKq+zDxy9Uv7/sv3MpldGfPGRGlGTV+/5/P/0yiTGvZTKz5ZVqQ0BEaVdABfXs9w5jTf6HUr0t297533GVcVYuz0IFBQXE/fuGtLxy9MO9uVNINL75MWkMWr3zioLXtyFe2e85YTK9O73C8YodoGRolz2OPFv3FQD+pd6bVwWv1175Eo9bHmz3Snf+krgNuqWt2bS6/cfp+ofWddglyS3N49Yq3JpNTtsdX3pvdq903OmY9ra5htPhUho5mMOgwxr7zyvAYY0cyoc7iBb25+zPLfgIS3BjfTam0Q+KuaVRp+0pSFlJk2YlKwRxIfecV27AKhObln6CvPYfAKhJCwgMgRIQatehS49efTCDhgwbNWbchElTps2YhROT+dHPfrNk2YpV67bt2LXngJyC0mcqahoEHT0DIxMzCysbh/+5uHl4+Zw4debchUt+AUEhYRFRFBqDFZeQlJKWceMJJysnr6CopKyiqqauAcKrBepYKOQZVvNgIp1cTDAWkzGzsLKx52KevgNlQlBU6Q94FRuekaAZISXpl5TMirUyVmRiZmFlYw85hQKNwYpJSEpJy7jBVTGPyrPmlBvvkR8BQSFhEdFb6ylK0gEpZFasIVFoDFZMQlJKWsYNbhUFwIFaCsoHKTmcqtT+paErPVxeIcVZSTmV1Jh+DSgOVDf3roUab9REZsPccLtfux3Yy5975HNUTi+voKSssYoAWgdqGS/r3U7/Gyfro6hp6OjlFZSUNaY94KRP7xZ0pB0imKGS9EhKZsXacKNv293bK0WSEsFQjo64uHl4+RwX2SMKjcGKSUhKScu4yZdzXGeTcqiqqS/9DcDHywGMtDCHMsAJCEG7/r5+fF2X6nmZsKY9IrLuqQpGhhjiBUgSpGTDn7Jbqt9yVvasypr12ihga3m7VTvF7eaxly3Hp5ij9KEKnxpGk8OzELV1MHpjaGMOJmNmYWVjL0dlLm4eXj7H5S8gICgkLCJaZAKFxmDFOl6/hCSlpJPBTd3W7869h/5SGWeycp3HV2BYzFDCV04lU5WausaHOEA/XtHvnrRoDtUP7h0SQbuN+hFq3tMyvDRJH6mT9U8FrShrzDe6JNdPYZRRZdSiCbHT0cegNhZlEjMLKxt7+UsLCAoJi4gW2TsKjcGKSUhKScu4wcnKVV6/QhfrV0JZJdU+NamnUZfW8PKA0sFAhmge3yfwW1CQcE97RKTrw1BQkIVGo2kgCBpBI7gIum7tpdtvkD6SwwkRA2XMw8TMwsrGXo6CXNw8vHyOy59FQFBIWES0yDQUGoMVS9ySiCQlJS3jJrdy595DfymI6zqbLidFFVU19dWvCLrUTgQzNB9NGeuWAy5unnjhc1wn3Tp15jxfWOrCqxeUFULQjJDlnhi8U5I+SV9kVqyVsV4mZhZWNvbydyogKCQsIhryLhRoDFZMQlJKWsYNropZVVbFgMkBaplDRsBRSLz41Kk3u/Vkd17s/6PZjcdMZJjKZjZb0jOpk1mx1tvN2jnNXszlk0MRpVRU2eoqaAixR6foawz8tFeaX2RD9oxyNAYrJiEpJS3j5trTeEb36OnkjIycGlnHfVmjzoyg6B5d16VecCZBn9pFBDP0TSnf/pgq6b83K9pu205oL9YwR0cwxHEXF9w8vHyOf3OJjj6ZI6pq6kuteCGoU8ir0JCQkYmZhZWNvYqdqjzp8yXf+BEHjw58wp/3REmSpCKrpQ4sZyWtZi2sZ4sc8tN+IORZKEdjsGK7+K8kkiRJ8ly6zR3uPdxz9e4UnoLg2ihEiWCQlVNVU18dAsSAWsaLJeVTSNCtdoi6BwaLDNGjeYxNy+OBifKmcpjN3q5oT0N5jCJFGRWtroWGEHt0Kn2MoR3dcombh5fPcZ2ETp0574scvnTJ3iSnyscUlJRTlVrqpMFUAOgS7zhgVHP3WhoKIRbUdsJSPA8aP16a7NNUZdNJnitzn/zpJe+Sij5GYoKZhZWNPRd3yc8pqIuhUqRMKqnx5N9v6cugxqSaKfi+NL7yqW9BirCmPSKy7smAkSEKb5SElKx/7NNPZ1m6y7KyUrMa1qzPN5q32a0t5tud203ZY7u/i870m3wy+W1v4vmEw7MQNbq8/sY3CQAAAIy0I8Xl3Dy8fI7L36iAoJCwiCgShcZgxTpeWgLJpJCWcVO3pd2599BfUrius03K8dWvhMs1akyaPJicfgTE8S4DRlqsoACyRZVf06Ppxg83/xGWJzNNJUx3abZGfhqV08cIU8ywsLKxby9+yZ3Gz+J7cBo/ja9TY/oDIAKUliEcEITaiWCGrnNBn/abyjCr+XYeO5n2IvI7iig9KkNEbzuDeL1ACCGEG3tiQAAQBEEAAHPiPUH32h0RzNDX4eRdKBlHKS7NzcPL5/i3hoD50o57iOPFQDJ6ziFxi9r4miNU3w1Oely/CddT+GbVHG+XpDgpyKxYK0WcErEzaBLDMAzD/pwFOvMLfP52BZSgkLCIaJHFUWgMVkxCUkpaxs0mUAoX32XjcsB5SVT0geN/me86XfzVu4embv799nAi7JTXVYLukOC7fGC4b8oRQsVrIF7o09ahvdBp1Q84xXFn+BumVdPFk56UECLwhJ8HBoAgv3Nt0ltECDxB9SIJ+mfUunmlnVjARgD45toOYAjwN+Yb98Nzhvvhc4GG2IpludUDc4ic1qL6k/6jZy0wU7J/mYrpM2fmy0SDVao+YkDSMftYTTUQU7C/9Z3uGasW2yc+EhfFdWL5F9uXqi+v7p+8f+z+0fuH7u+/P3F/5D723gnKnMfA4XfgNSudcBFXDc5T9MbRDH+kdDx1e+OkYsO/Yxrf2VbeUvt7A97U71IAL9ss/kvfLD2Fjc9qb96VL2W8Was9d7aduPKmvXJNoeyxecvyCRAk9qm4r0T/pXqv8i/KcKw9J2JdLDpvqjM605x+Wjhg481sDSaaRkaImE4F63Yf0+7VjGytB4iXI9FzpQXpcnBfl4Q2vgHH1/liqmES2KA1qy7vXUsbesvWBTlvoCD432HmRteq/eI7ZLjRRUG2XS80LBSxIjpf8DvsgEA0ibdF08gHbe0dPtiBh9zFqK69UInYaso/ebWB0XkD48PX4Rqc8WvwhG1XcDBD5u9tGJ5tAfZxETTg1hdzvJ9jYMQ+cTA6d4nglj9ys9gELGZ6cF0XDHS6Bup4rzZtH6+GET5XnPcpYBOrx+oCDqUrYrOQ1qybysetHNE1WXeXfW8uOB14PhHwqLOgB8bfPoYWCGyU9V0Goj8AgB+7tt56I1pF/gTbukLYDdzvoF+kgNXh7QCvaAnam6pUsNUyqKrYaAhrqem18m+uvGLNaxCxx3NUS6uEw5bRm+mfsQIomf5d6SFtlyvQkwGqLh2FgSiAKP7R8obfWa87XYZq1+lpKEsxmrBMpa3ptsu5+w7UjL+3I0hxMD+Hbvmtwax5C+Mw0TgSGUaGJC3OyF6SJbvcrDvDssv6SAeTTjErFXZwcBBZXsIwBMQz3jjNJJTyVl3zRd6ZT9SqKUB9cSQpGukwZdvruT51PRZiOXMZSBslLKOBM93T5DILH+qqnzHvYGILo0FwE6ae5DVwHsLxjb0GgyVLAZMQ8Q0FZD+l51Lt740t71pCUzXoqcv36+ToVLV2Tmu5LemIu20yxPDqgzkBBYGgBzrfv1jhd6VUiuNLtoDHRQLNJo4IrD192PO0fE5kX2rZNorTlSunYzCswpZlZ0CCZAEt3ee2Zb11SrNTttbY4wi4Hl4xMuwejtyLt23deYUXfepEUBMKE1SbaIZt91Xrit7OFs80OK3KjTYP6nKxe5RZFLLUmC0NsZOsfStIxboJ3iBjm6xCZFtdsZ2uZH8CEpopWfiLqTpkmg6ZrkNmbCGYqRPM0gnW0omJ9qCmn5yjaYLgXuvS4EDQh1QUbXgayPPZcfeAkwIDfxFU7wC5AdwlmPIJAQNJoj8+DwoCLk4CIC5vS0vcbUyOTLQ+kpneuQjxyhw7IR8JAkIocNkRTpgQF5/wvp2IZsY/p8Dbnh13HcVRLFQ5KrHOqyafvH86+unLGfPJdW+zq65L5BDd8aAsD17FZo6WF8+FOeRPqSb6l6Pq+VfCmFzRO+5bynWH8dhzTh5LWnMWEwVuSal7y8rkqlC+7/ghc9Y8DjZx0NnVNeIRI0UV2yTUGN9vqJtNIoci5ndZc+HTYN+eUcvY05BoKJK1p5TJiiQaMyKP9becCdGEkyel4KbTc0fcMp01SfOFEF7jucJ9+iDw9ESMqHEcFbCSDtz1ycsZS0Ogd6Kk86SyWFM7RJ5YNy3cbzPXT+Jxoal8sqAqtpCpyhG8OptpnFgzkDUkQ10EiWCKi3mwJMWmopHi/tznr6XpxajSzOLMmqpoqAwvasdC34tEo3Ki1aB6k3I9/rNqIaM/F8UFWt1FE6TGc0E2swZej4sIvwIhs7mrsGbXogrWa6MGTutHQSsBqJW+Mg4y6xuTrjdQl8Z+v6uDf9+U+WHcauoXaf/3dxDyZYb9L5Mzi/pi6yRFUj7+nlH/FixtU5hIzeNKaO/L+a+jHy317avbaMuxT+5AStNiTsKShsBI6fTHKLZPUFX7V/XyI35H+u+ldwIIyILnTpUTh2shIUwfl0Eskxpzw71PzK7O/ii4V5+XX6bEPPaSe7aakEqO9X01SvJbubKuiWsEWCjS83TCrN8a9+fqVtzQELKdZYcJ6uG5zOz/W55hN5se0rtk5wdJfp4y5XQpdEGdnk358sJ8NFnOzq7k5uKHSxPClIF+VadsYLPu7JpIyPrNx7wU/2cNXfMgs34ikXmFZ8rx+Oec8poJ1OniKQIpdIasqwGylHsrMkhq39qn9pX+2X+ai/xqdALq7TC0H0pOlds9mVrrOX51TNdqQEVppf+3OAsJTBXJSCybGKreBnQ5dzTZotkYtEDiXSMdtEa4Z6j/yXxOoIggGNiJEIFyWBd+cbxAVhPldfsh4oMDbN0dkSVa++Zoe6EzpOYXYf3RREjn3+Nnqdr6Mo6qg5qWVcndJrGSnyFQ3+BwjRNTD9OMUWwSZ6fDn61PsOV4wVjPKHtwV+udxi/KpUZC9drpyc+VmEinT/UXf+aoWmY7YPd8nStWoNdeQtPcfy3LsH2hu1JYSPLzXYkN6oJonee6z1gRwas94UPU3oOQzm2FOqSNZjRqt0+0X/0DakzKYSG51yPvaB83XvnzQ+LeaNNkM7Yusyf25EOw0zgS1TKOhQh6fl2Sb5+gL+zu6WMlD3iOW9LUHnRZ1d1PosO3izPZtGIj8C+JJWxMymONBKMVi7rxD5pQod2NpXweUTrA0cRM/y6Wf+QcGPODwWqXO6c79w3E2H076R8x7DrPm0+O2VzPsZ+9OwbcnEIX3ScA1/SRX4yAzrNPPyaCVlkZXq/g9JwWZ1dqSxNYQiETM+SRUB6huTjqyqcIFKT4KCPyKIxTwWN2i9MbCLL+NvCC2VBrQd7k/8yGPhir6D3T+a1OMMzeKvx2cedCzr2tgcB3olXdWr4bfe7QuEH/sKpkvk18ujaIZb1vrUwQ1ROvZwZorFuTVcvRCCe/jcq9NUd5hHHWd0KMBReBn1D86LGWmWW1eO6ylE+SohcRK+UC7/Vyv4ifg11dyku/fEP4UjqoaXw1BC1ID0bisC/jdD6IhTBDkhtwIghvNfAD3WBwUx1yo/w9E6qL0yVcKFZ4kdN4zvc5RTIBJFxe400sxyWKyDiI5kqWgGa9HsaFeFW9ny9oBjkJxYsHekmB59MLZZZLsyksYcLy743p3Lm9lj4aM004U96gNhIIXDHJcpbEiB4FuOrKjw+EOwYk5bHegqjRcptZ+1+7Xlrxkv6crU2lqzVg1drjmeWrd0fQ5JdQX7wJ9xkiDHCh7VsJcTUhUCdiB98TGUCT/ftRWzmQrfbnELuk+3Uf0irgiGrTCcE5wx53o7FAvfwi6mZyg5kPn6C2jEfcLC243AQIYhTpTDv43KW4huoQt9xeFrrCws8GVvv7Ncw3JyIovc7jWpm6qRwW+8Gw7FhGZlckvtezbdMXhhBMjptuEcTUXigGvH7/kr05cHovjNXUC+uiolS7x6jQRjWu2eZ4hHbKjSr1b2hiq9OXszncb/lCHgoSf15UTySSceZL00mGZG1aWpEbtntZ6SgZVY7Szq133ueht4JgzRAVhkxTrp7lZwpy2GCmeU2dSi6sTQGmJ7xNX0EPot3hAb/rrVo7fYZCrHx38rItdAnSwbXECFd9lv1yLVox+o6ZrqniJOQVW9chejBwXuEW6y0HNV5QCQWXT+X1dEtoSAuQhsODHS4tHh0s7jo8sssB2kB+1gBJeQmHgs8sYQXQboGILc50or1Hx456qFNTSqYeiVhGjZkn8SQDCKBCsjg8Cc5r38uVsHA8nRum9U7fVgGyyR+kTamn5f3/ARSR3xwJ1HYtlbS7lyWHIoGTbcVrDzqvW6sfQ08az/dcWaEsVQbCVPH06ACacccnTp2zQN1lK2XKeZrpjwHZ7E+mCQE96UNmAHNsS2P2admr+z4qCoc5j6uV86+GnfW+nLJabB+rM0GAcU1AueXszPBXaG7R1rBvABXj2qmf/xyHnD4OUtPPXB7TBWVi8UzGOK/T15/ip5PY0Ei/sixBhNuOONw7MVZ+hEgcy+gc1qAEunTBueF1V9Li0HWVJe2dr0KrIebW7wN7Y8fOKCd9otrRYWbrUdxTT6mScnnt/U5nHxo5QXspdMcYpdd7nC04rkLsmsRnVyReS+cE3QvN/RgrB+n6dVNBhRbUnGC45pWoKt+XohvtbZEtVkcqBcuSjuHm1jvKjASCaZFRmqsRCzH2kUH1/bvkySJ11pWkUlhYkd2Q4+X1TBM8sWSnjnowI+1Qf7R/pKwCE7+1OiSOUDBlC47q/vLsiUxjIrSROQVIVodIxpa0zjYGg7g1IJNyv4fBIg2S06y+5n70E+xK/PskmQcMXFL29Il9zP6bsscJZNGIWE/QQ8gLTzR0hNZzcDXGDN8ptXSWEHOlH4Y2lhXhFlW4TgNwDEVXUbhNKWV3aIS0euL00LSL60sqlOXxj1IGS1Sb4PQAhLgTC3V/C36WkI3C317jjwdylduNlbxR9SCgV7yukDgOORW+pEzp1xkuiDpmPCjiMMHMjy/W00v6emh/H+vtD9RxsXZxOkTYWs/k2bqDnko+W7vH/WzuRYjcacYPxWUVCExavFNBMWRzhtGdoLIy5D0sB8SfFhHfsryzJwjr8azoTqCaId670gvvmjgjHeAcyw7HAief2VXTQlUGpT3KnXfmmSAvsDNtJiGQ2fs3T4awZhcwS37aEXYovU1TYkbsbWb3Ae6uhF4+dHwIowaqckFvjRsOcvmQ7gu64cw910qgHwjR7pjLzq1DXJe2gxtCvxjJbIdriRbiaiDPVeI9M6I1eYNSMjytzdNrCuICM1ucbocP7hpMcZcj32zZJi/G6lGn3G68giLYauOIAcmCBJzlUVgvy7pDjga+dQrYsx255ZSMJj0AtVk5kgcCZfzc2wDJRFTzQ9ZaFNlVd240MidDoX/ijx3bp7RQgwn7Odb38Bm7w7CLj9/zud6/Ws3lBl+Y5XHhbuGHA/CPzn2YsKgGrbK8VEkonybFOr3/h+wWMXettG9nDd+Mk4NdUyWax6tKFTxyQNEOXwCt1WaruYJaHRQa39sAdQJi00rcx1Cgk979U9aIzxVcinzHzXxXiOXqWJ6XqR/+AWvc/GztMQ4FUtWaKorDTLKOCuwDDXBVn59xENQHJeuzX5JVXV0MX7F3RGp+EDc1TEOJ85N8q1kJifU21btVRo5+W/Dl70UyNzEeW1511A1xchXZmXiPBC37wRUGc/mhDEq6C/lr5492dOJHiN6O4vU2e+STiSSCg9JZ5aqR18ldNc4qByUhyeFkOJJgfxOJvAkgIH3wgBtI5A17fDMoZiLIazPxmD9yURtHCnr+6WdzS6Ruj3y3DPbBx2mVEzvjEzuv8kc/iWL3KGyjr7Obc+33VNZzd54wMXSKY8yeRknluz7Jd0kQHnBXJ27eLXe+kI/pp7KOwzf6Oa9x7tW3f6KyPtmSPrjVrrmay+FHy8yTnqAVFimXwHAJAbLA3dFmBbVVx6P0FxdtYxY4rl4LnITSPa6Y3MdlZ3G0ZKRn74ggYFXAIw5kgGyRMeuzNImTFTW7+WZnt8PAAxD6eGdUCGdZifYK/EB1NuCZrKAs3DVSIPukJPSd3yLVOSf0Oz++LR0fnaogd6o0VmIqs4Ko1BA7FSpilzKzgshkVBIVmaSufiXdJ3MNFYFGUxH/R2bSaUjNZyrc7ALc1UfTUj2/CG+lVTVunQN1ymVpCnKHSlNBB3cw3dRK1LDb+1SxrNW6v5FZhTLe7DJsWixrVtIWlSOPLU0shVCdPEpohc88mH4RURL/XpSQEOwVSI1hKrfMoOn4URceMAZYal/BukPLDSce8EtWrh3J1vxVOCadiKnN541lsyMa0wrL5Qy/JGH8OjEvukWfMxwLYvrRiHkihj4ouuyojMHYva+QYp6yMbSuUBZQebtktOCUJtXV8/puMZFfYXpAfeT3tL7O7xn1oZLjW8Wk3dc9vUZNJ4vHXLBC8LC6Rr3QdCS+1fawhdbVt0K7QesqxESFrqmaglMloy7QYO0VEM1CcdyfF87fr4+mR+J8Dhi2lR3QB2vbDOCr6Vewdw/tWlMRbo0bALBmzfk1CHny8PvQq6awE8P7x3vGD40e2tCzYX9Vdj3M9e1RJOrJ0z9RBEQuMYedceWP77w97mx+bJuN8ECuu++u1c+8HX+LVpeYuzL5dvANnZ8AveHXax8CBQTm4vcXpMCB45fUJaUX1EEhkQAvXJCABk4kLS2poOSloDPnd8bezeqpS6DTnWb2mG3nXvxOJsr6Q7hTg+qJvo7H237bGrvaqzE9Tjhbts6OgpG9di/RG2YzJ2Mq8mljOVJij6zRXHmhtq1e5o657wfwKb6QDHpm9+L7vmwzvSi4NDU1NIeVnI2Kjc30Z1NIoqnGv5HO23OzvDx0ko31xqnoU5grs5kT5FJtco+cGWSmSjPjWgdCBg926PmTbaUHEvQV0xSLntMLlwj8uRDw/XIQBfxHKJeRaggXCMpIfBFaS0xAaaWs4dCyNo3dvDkZLSSTkoLJZCRm+aWoJYovkogfLps9pcL513xvNPhY3WRdA/gqCaAJH5vcvZWJDJe4Xrb/JhktwLyPX6TVWGDasn00qzVhMrtCcrq//TyrJNUK12OVMR4xAgQKFMFB56IYghqiIp3QIGJgisSCKqwk1gq4aQmwTu65H7ajVDVBsRYzpvL1nNnWppOckuJDzIZm+omyHPlNTZ35+XV4wNT7yqAGDPY4K7RcKCvFc7hWQpoMb6Gzw8skYguWwbWSpGm44m2MKxPSoFfNaPDBb26FtqB3Tn096/AasA9QZ6Z7FR2ltBSyNub0rz3WhS7DVuyulCT3lRun4vN02+IDTCKptO62YLvQk7L+HPbG5sKjFPMQuxQjZIflJfFJpjRaESoxsQglEOUnVbuwXxfWYXYeLpntkxkZFaCm0nLRVKrbaEajIs2ebK+ll0MEspGYEhN1kz6HtaOp7iDLVLCHUVNHnS1IgZaGFyaZCrI+LX7033k8IUu+uqiPAJ9h4IoFAlNYKr0YJxRgC1OZGDOXZ0LTuKURAlGocbJFErQHt/o4lpu67GV0zv80kt87doWkW9cC+Bw//yjhx67OazG7h/F/e7eSdKMuG5IzezJvu1DkNy9avf8u7HC4s+tQQtPrVPxnQAtJto7v4oBGvOaT00PzoUmSboJOHlcjEOJLmGmyJHYMmgTYVO+2yw2HpzIpYgqTiVcnhQeyRsQIQrLK77jIHXF7tSKXn79HV7nvz4l1fHdRvLSHJU5ShyVwffUJSuqBlv5L6iaGAbyUZQLyI0NQL/tgkeo4uhEzrO5Pv7a5/wazvvuF8eBx/cq6fWa7a7HP6rWbntMUUc/dIeNwmpnjLTt4EFvy24+N4ZdKYr/RHxoY2Z9/hVKcdTh0q6ijImd99Kmi4qRT5q4RwZca/0fTJKU3VYAxRQgaUzKMUR0sLk1lS1KM2G0R/rZ2ZXR0Zeh8EBuDf5q4An3UBbvPVoKle8HMiblDdnTim85L5HptQr86JkBHlxtoDPBW1LYd3Zn0Da1F5xJqKYPLsfJqtJAZnBNv2dq6LbrPTlMTLE5Fa2Kbx6u2u5zl24d5fy9IUxv/X350yz/mo/M6j5kZk8fFBVfz9qnHunR5SnqhL8BjsUHL89EBqdZL4r51wuvt3cLrnSMnBYVUo6fKn0+Sef6Q3v79tNHl7HnH/Cm4HZ2ATznmn71gdLm6vZNzrWPteYFVqVVazws6hjnXauiQiakjfxA2EV4cmbLa0Ynt30KsCKeEpiXOtwNR/xtKyF2jhAhQ8qS7IKN36RmMqjK+EzMOzNjqaD4/b/KY2ZnvcWnes3Cvch28MaKQ/museo2PN27o5/SQWoS8bkncN8r7X3uv8NbA2JzoibzV7uGg0yDdaEstTi1Lx9YvbvlyUfb129qEixXte1glOpOPb3q4NxMCPBpFzw9ly0PaNYcWDsLJaB5mMfYPn/TOgF2BJraEd2bMHL97L2gD1lb7lrI/YMAJnj6yYEcnFr61zBTviCCZvSH2z1U/MzdvSfsVJS+/eha5NrNu+/wg/nDU8dZBgi9h0F/fgQ2E+O0b1m8t8uxV1HLFPAA9gRxcJj+mYL1hn86p5cHePSTfioP7g798ljWM5gC/nza6n11wMk9NOZoj7OL0V+2iYxF1KlIAQczBr3eMnBdVWh3tHNltnZr7X6dbaK1UUALdqqYdBufzOcqe3q9TOqzUHUYDa1d3zVf0ticTT+XN4UpxeAm9b+/E/qcDOcDvjWEnRVstLawIy+D2EKvpH0BbPYjBtNI/7UrVB3lD75XY1oLk0UwhsUNjauelAaNPT1MOxPRabS6VYaOD3ylbw1T88ILU1r1te27do1w+O5ziDVhghuUGsmj6IHpioJSYlCDOjasPaw2vj82VJ9Rl5KTurK87xqoYeGyQKuMy60s9IVnSmAq8nFWE5jNDtYm0hDRtXD2mNaw+RqtMaNUKE4YsJTtpRbVXBDzOVc6TiR3XPi5+vL5j8reJjIHE3KKoDZqChYJG8c3RzTfVnZ2Ojm3WtsYrzdcUleYWDSZN2i22bkH+bUXIl69DJfv6wZLrCPJyri9iawgFP1xjVzwxjRy+usCOx/U/yHR3+yCgx1I8goJcrQcvPwZ50KVb6oBjj2nhiHGflYlD0BOsQ72MTjH0FuvQ2P/v/XJmAZLcWJVs+CXXbYjqdfa3wy+fz0O7m1rSDTNVpKF8yImZn+ITFhICbmr3IX+d4eCjDh48NBnJxq99jTjQwmNNcINEUSesUVMkIQoXdbkaMdU8FGAnRZWxoXuhs3YS8ix0L4xNsWctCAM/XENv+FXgV75IyPgNvP/Sah+YXYb6m0oOYE1YjV1tAGvTkvYqzvC7eUHbpAf3ZkZSd9WCa8PdV2YD/7q9/kM+ZOvdF/bkegnSxgNlWwUUOSYHlJCYHyCg4Q2sJFrpqPJN7H5HSbWhVk9LD6CG3YcBZ5o+y6ULkmplR1yGnjCk/AFJFAGZQQ/u3ax33I8qiiQxcGETJ47YYjbZ0YXjOSncmfTC9CGavj1mvrkscb5scEaan9criGK4ZlZhIKAadbsklvuSSKuM4Q6Pf3NeHzRE02ixtrxoOa3+Hy+vsGwhnMIvjxbqMUPpWdhhQW5xFJMmR1WlAGHbI6k06RV+qXaGVdPJXGgsT5mr7T8qspp3MN/anDMx673qqeLdOcXqIbq+LWah7ZUNTUsLsjtSKFHH7OjCYluKSEWjOUUDB3/6U4KinTMnkiwVKXuLcT6IGXstcUieY43gMnJRrOC3AOiRSKpLZoIJbQHGFR5ht/ZyvukwU0/XdR8Wlre3ja0HdISmBObT+DlhNtC5bIs7cyeYtz1PTerWZLUQpcwxx3THT37+EXyY0ldNy0a3+efawlCVq+gVvq9A9MBNFV6BVCmfUmtQ9hPknPvLHtCQ9VqvOsdm1zqINjJezaZR6+pyDlMslt3hJbzY3BhBjikNtSOKToH+5/G3jY9V9GfzKbVGxSAB4ZSMmeTAs90KnIqcXfrZotggHAdXDOdzyxFiIpaWKIpN86vy4ROyy0qKi8pKsgm+/CqZn00/akcXjimozMm0AnlzrMIQPqTqOtZlNTUXS3oF8dSXK5COlZX0yq/JSGHQTSRyKSgJiUwJWkIibwaJF8sXPjXZ38QUFeOFgRmzLlrf216u3h5iGldGRfawzQl8ckEfAd78PlX17iZipnLwf7OrfX5cGljeDr1/XTj1+A9U1OPjdnTBBoZ0LURBdR63jK6YMevdC+KY/eqsguZyn1w2U6Ik58KipI1RKh1hOKvrWFdNQb0eL0adD9IkndKq19Xk0MvYr5dtqIbz71FC485kFA1ObjnosrPlGK+xhz5fU0ufiy2OcS0WJ2nqYczV1jDmAeUcXLXcu3Hs6xMnx77ZKLSQ+bqQYY0mZIifayHvX6eyo0IzZr1nDVW8W1sCP6ZdtJh/bzmdyWHzAPCPvwTT1x86g7VJ8hW7FR57k8qbySg03vTyellaN/F6DGTMmkxsq4pNP8N1oyv5fsoEt0ly4abqAhwDOA/tNME9R6OzG4uw+V0PCHrxSYSX0iyARhM40NCd/qFLPHS2b15AdigvEa9KZkdW61RDkdnm/cyTWEZjNhDY0Cb1SY4WIZMHgnBXeZgc3zz/nDBeMl5DSyCaM6VdRJVhKmXj1cteta1dzcX13mlgzi5wGAWVBtBkB7UF5VLvRPoOXxe7em4nK35rI9nSgEsr3dbCpiJxHy+e9uqYIlCxbke6WavU4362uj/bB6+MQk7m2K288OLkVQA4Nx0HtDvBA4ibK9M1doUrg9CT4oUBqwedVg6i7/hprbgDJAKPif+3dsabUUb14gxfGZCcAHWDO1aGkOvuHaqeYrO3VT88OI3qPtm8SvFmPzS58VPDgNuvqZMkr52KR3ne+6HdTf8NFt9+lT6ZD9627xyuY49v55l1yOBzm2Ebsz2bur5j5//evapRexkw3BAjnwXdOBj8K3bgH77H4hzmbuDg+5oTe1NZUkYRgyWhRnnpgDovfTQrzJomryekxUjAR93BonSDiuJRAMjz0EVhINR2g6uroUOLjvLQXXOqgKJO14vA7kfB0pi0+og0eZiVFe2VB8zz0nE8jV/67aSK/qSZvVQBtjxosVYZimCkJfTqILS2I23XDqFiDqVV6QYsqUSQybFaPVDXKorKknCrQMr5aKBxFXZ+I4wQC1NiDKdGG/1zMMqAkEIZuZ2/1oCnqQKCc5xVfgQHhXe5Zm4t4cy8qyD4eSju+eABiz7IRUCSDzIZsIT0WQIQmkhrMldvFpd1pJyssNDONfWdllY7uB0DHYDQvZ7L3DpSpHfqX3q62z19tpH89yMFajrT2w3O/i+Rc4ZnXuV2CNhSQJ8+numeq4WSPwmcKyiiPEyPbavNNuSyX7dzTszOkvod7FJxLSabwcywcggbmGs8+w9ShoNoYEKqFpsq8i9hupzlAu9Au5YFlGLfy92onULPfbEXgZetiOt/+jIjApdsUXe3xQcYvtu0SZOxcfxSQWBCvDHg4IlL12hfBeYnE2D8dnyjJnN8/GK5eny8IeAC+n0tO+IjgqR/SIOJxLTg74OlEcRg2Q9pQfCkNOhOkGzDurIoREfYBuTzMVDMjfjiYuR1YEyZG2IjYiyMnK8oVBQoEo8nelhdNoh+M0H2+/f79CvI4A/WmUMkIZx32h/jKo4w4kwEY6yYTcpMloma5WinZB2LHVmdqxqOzBqnKIwrAeTEqMInNUoMz7qIIUTSZFEF2JLwgigZKzKLKlY2ZgVBUkyCEauWHKzkjdxMMotdTOmIvptB5BNDfk5mocVB8iArzS+GO+65shoG+9IGg5a/gcFgiLflUFjbf4h86O5+0wYj8U6OePfhkH2LsFB11yp3r3KrUl6j0HZxK/O2MyrqUvYYjMy9dbW76XnF44xuApX1j7vnE6QAmsguw4vluBqBCFcrkBXiUkg0t2VOwoPVRvK5nJmuzmntWbLReI7MYOEMqdNoKKmm8TnmrKJp8lm9ISN8h2y43DqQNo1P73yq33cg73l3Bn4XuIoqbobw1uSJYfaQ7qUtG83gJgGR5Ucq70HrgzBU0Of92CA0XR09EmS2R6duiccAmPPenim8DFItgRcrD9ziJyejsGQeOqqQZZ/rfW4Ugov8q88Z9rlzy+2fPADbppx+/uPNlSknDs3V98KWiM7HXlePPczaOx54JW0n6p1kfDc4pU/u5W1tDDiwq7E+x9xRCF89tOORaH3g568Jg0NISXnltwfBz3gYdOgOFiC607aOYzFTqlLQTgYTI7JKraqOZLGqI9WqyCoGPbLyjKNwlHxlMxXnx1VyUTgcB6X04+JYx1NxwNpU6z+7POzEsdrx3vGy0bINvRtqEfLfL/VcGoDsNkYr/E4GCIlhcOZkxp3pncZnkCWIESyyhXtsOf/Hb73H/wrxIZ8iRKz9tYkIcGqlst08C/sKW6EYI1nmO+PPCGutxtOATFFKHFbOpGh8SfFy+DyO87bgiaff7iz/32cC/B/994lGrSmiehDVKjv/xOioMRJp+HSLp5dTK5XuZggXU6PlyGNo5exz+7sHIOaxD7edAsjApZXRkqKawilnq+mcQYaab4kqKXRWYWAZmJ4QO2onOmTGiYnf7eg3kw5DCuRktmlXUqUpZUimShmsNOyKM800SP0LetQo/5qaGn9UVW21P0rVa0Tv/7jqY/pHCG47EpTRdl6BGyyDSTJAUmZswJ8dEiAJy/N+s0q2tObmr2NnEszqM56woYI7F4u725XjM7Ans+wynEQSXsHhhlsl0p3H5pTjpFIelxNeIZUkx3ZQpJkMhrQChRqGqMiU+6p1ywVfwMiU01e/n3sx5TQC8L2w5XMnLBQK41gKz/vV0g9uJTS3ux5pR0qORAElPpuUNxs51EQ+ruWpZUsgH8x79ut3P0Wc9BOS0Vm+9wJEtjP+eQ8UO+lYKpn+SC/7yE7mRaR9t96jxIdfmUMTSvDOIRGvUvuvgBRw6zWfrA4t2KGqEq6TxVV5KWQKZDFsYgCaWO1ud/wPzEhxBDMRL0nEBzLTRcp293Qzw//yPtwirhB+mvgy9Sbxd+Im36TnuiknUg/+mGYHF7n+V9D17PdnfJl3bYHtUDmRB1f1uz2onLqktE3s5Ije+0FJT8t9bpl2/gi4NP5rdwx2vzIEm3La3XFMb/kgpwiwzVdErVFbPb1WKt83VTR9UVZu98g8SB37qFbrcnO0Op1B7yvo9enpND0jHdBlU2Mzis+TxER9T9aEn/iSo0VX7398k2GnrV/Fp8XIShM+Bhj2v8zXWSCC9/t7+DeYXCy54+wYTr3nsIrU1s5m6teJnLDlRitr68ZDJxuk3cv7PFULrk93PRRsxUEOFWxM1GVFlJCTcMpUGj/SNsNCGRJ8siYJK9ooFlPq9IpuvEQ3OU9+bXR8nxg8C+mxDU2JY8mjdFh5fFwaPQYvpqeIYuiJeDYpAE61pgekMkuxYjmuSfHb8fsm5mxL3XHaB+5j57TB1Py6hENl2H8RVkcNoVuYYQqnsTJ9l7K8PeHq1y6qhDx0ITC66lJZrPWgSl0YVw1PZJUHpbHwhdwkmnU0803CfseoakOTnpYeRMU+XFs/Qk5IymvXGQM0MeoD+TxUvdP+oKI4Egen1ktk8XnBXB62hH/+bbI2jCkKs6xi/UtDlSZKVPgvjjNrQXQ4IbVpawbFxo74k+WR8dC8W1W73VzVJukJnFlerstq8Px/spmRYGyscBW0NJ+zZAgcAvfDvETJWq/jiVLi7rqwRjeINpd+JK+BtRlzpnRt8qP6baeUtXmztMZ6ztGynOTd1qadPJPhiJKqAvVUXsxOPd3tvFzJqYiRFhN2OpT+nyzlp+SFpAjKIgUqTDVTRmiWKE34Jv3DSz2XdLuQBPslH+QSIBnpkwRYRPos2uMP/uyTFu9YmcSgXapes61a2B6ojeVl7fVjjCzRmKyFxujNAxZJN7qCoUn4GKAhV0i2J+QeF3HjLEJrjFgfOhL7u6Aiejlrw5pxsvYIl0W0RaxT2Unhx7QpvB3pheodDZVlHrUdzIgf4jmftmh5goz2qr3TPZb1Xl7zpWt6+IV5z3ym+/R0pvuexRdFw9NfuuW176Hfd6beqB7bKzaZHK9mjHqjs5NXM7pXZDLR6tHyHPxHkTDBl0lyOmr5RyDkSBQ1ORg1lypiq2Ms83V9hh3cyp7Uudqa1Pnqnt28/I6LtdElkaZzTeix3oGer09oAocZugIyi6MoU7eH1Zzo/TpW7mxo+tg98p8Zw1xXAyG0NNnV0aRId2+467I7c9WuYJw/Q8dBhmG5yPK5Mg7rz2ipjA3jIC0e1Yfh1URCAZ5QQCCq5UgIIaTQrZgIFz+josKCv5f9C+Paqy0khPgzDRV6lry+uWU4oD0A7VvKA+wW8J7T6+C/riFzSZr0nRKmrlKwynNi+feyn1ABQIbR7A6fdfFeeXwNoSVl1lhxiT//WOBu8H0unu/T+JAe48Xwh6FZ3fIYbw0/+K3uVsI3lLuWJkro0Ru6E4SingSDYeeJRAndBj1PJOxO0OsHn/Tfn5OjSn0KRueATIdsMuSdvMtj3xBjRJfomfV7RXcI7hgDNeV8Ozh8WlDcfVHPUicxav/1BLDu5KIFo/Nf+c8FxwEPwP91dIF4ozxvUgAX4Bt9fpj7YTRWBp7baevs7nqqms9iGa+Vra08K+4ZVd3wah/O7/ZEeYNdHXtsI67Ryuy9yaLapr0Rg5+8zdLSElf+Kcl3/kD/86eFLpySUqkZ8POBZXDhiWfNz04UPht7mNWThd6XU0rJjt9stRxItmLEq79xzvKNBbmVeR3dPrqebHhwLPfA4F9WLy/FKsgbCyxbaCb5JneuwY7uOWZHcbJi57D2gfXdsa5tDrm2XV1ufwz4l3zj2wFItRvmFz/3q+1Q6J1WGCT3DhQKg9/RQWBtd+Cz0AyvDAoru7OK53qnHAYtV6rCYj6if3Ybh/Tf+HbCDZYG8AvtXtPjfqqrLcdKror0irpOufe8uX4k1SW/IRRFi2AgMKFMhNiPhqRBTe6zAZCmz6DmWrVr1Fo0DzOxseRtCq7MFcwJaTs7YFMWybQX3ypUQXzGzlEfrDY4rjn49hzRpwuQ4keNhJTM8p5dU8hc8mfpnJroa0hvQIdYaLLMGNAb7E9sOoMEP/5i/ayGsrvIz/ha5Ub9w9c6RXUhY20NTBiwBmQu+9PXUWDA3dBkmTHgMbA/fV2t1E5q3wl9ZIOcQj4mn5IjSj+Ro1Z799FETiEfsyPwgxkk8PmO9ac09PjLMWKdT2Ruihbx1aQ4YOccOYV8TD5lR6i13n00k1PIx+wI3wSrAYuAR8T81MrjNXfuVfSkpHUFaOBoGbJZ7AemIdo0cwaEwScxgM0K2RAF3K0O7aBkBYXzZ5s5cWngyDTBJhnqOD5IuPWb/4qJmCwr8Rvsu7XbPyYwWQY6ywChyHVudT2jjhO7nV3Ozmy0HEG3oZ/WcXZ7yJlpB26JKm8FYsjLByD2vOQDMeJsCMZn13JqcSOPiZjtVuLPNOPW9eOYwGw3UEX+57U6E94qzPxHlTvw5o3r165euXy+uLRezpqqlKHpc3/+v18s3dqeD4Nn3GSuKwpTPAHkSFSCNCJFZZoKFKqWC2M0KHSv/XHK//vl0q3tmEGGX3TkCRdPOEF6Ytt9P/K+wl/SPUDc8PnjXKf16++hv4MBrt5TCDumrhzw58QAICiBtFwwc1FwP/hFDMShygImDjoqZafNnvfiaYm7ibjhc2ENxkcDdwTD6XfoMZC+UlHMX4y8roA6G3xcnxbelbhxBcrWyjGf3/SoQYr9i+1M511CSprvDuSZEcvCpFQIarukbnbr61QFvo3bY/gzf/7t+XTcD+vlYt619STP0iTkwTxPrseu3lTyJ4uHnTmDf651onu5bKNlFihzs6r9xQAjNyk+R2goV99KEOkBRSX6jgjWZwsESO+Yw+rwslFJCuAbNpSFBh7f7Vp5f/XVqW9MNd3AlTa/LHvOYFnGdjl2Zsh5kc4XBI9FZb/Tnt8F64NmX3egEiBwlYg9gzLa3xXXFUwveOXXx0uzpsjiyCq6BPtSL0jE/ndZl8z0P7dWY8f+spoHL7CMPOOCzjNw4U/QYlnE4QKZ+qiXHvOiU9gnitYYJ+B4Th9TJKXYiD5C46LyvqfB3LSMMp7XckU03UK6uLZAPxb46XKzcu3O+TBs17MmS7jvoKC5TAUHjdN0YdNOPTQiQQjs2uMFponiTYvMNT9WvoH+DppGq7h4tT5NHkr4nTt4+QhXoSkCLgzgu+xCyBR2RchlHErN+B6+iVPrk/cp3sOUU01Z+Mb9vknEDZ+vW8cq1w8LR/llStkt500tgt581v/IoP3P5oVR9luZ/ueJ0OVGcT8jc5NfMYOUBuxewD1ESSLWC1WfZPQW0EOHjEcKeYTMQ0qty/EDYhck308khm/BKWXXg9mpWpElsqrjSShbabQULGcSAMfd7xnImrmkRSMr3gu5RmJeIRS/KyOdD9HMEpL2C076DU94eh1D7cMo7lbLWV3lkgfj6NgLanhGImVMaqeTUONyiAVP+GIxfDsAwMAwT+P/OyaaFejDrJgkShABJhkE1Y6EXYU9m1MMoVj+ETgtQMUTpjeK5G9MN5nlQNBr75gYuVWE+g4p1LbCnckxB5CNkjwUIif9Mt3Eqe5Ev11S6TXW8j37GMaAHaSxVgu0ExILZZnwObvDrhBYqkReKm23/T0BhLfCfYOO7cv8OMRp94G2oLEP7BF4xElrpyp5CK8WlL8EmIjyNYZc3lEqfOTBsptahDz1Jc9NJktgCEblzZeLAxxZYzYmbr9Qz/DyNphGFH0Djdlkfg4QtfEZ5+f2Ss0kvgD7BFa/hZSsr5xFmRFuT5KP5bmeKyD5GAZ0X2SyM+Hy0FUMbrqZggTGw7baxzqFNMgnrM35nuqz7d5k3k1EU4nZwMDn4lrz2SeG8n28f/WwH/r5LE+lgP+Fz+xF99dk5h/VrMhXMvMzXVmdVyw8zK8kbumQAH84zgbD9cdpBWQQq5qbfCSKDUTYyWm1+vhFyfQ0bZVLH4NYdBKjozFkpK3b8ITiOqePofnUVE8iOhcQSCcUKLoNlCdNoACBKsMRbZB3DW2ADNKz0wN0vwzvUv1utajKLAm55UPsw2fbN0j99FmzfCkNP+MZ6XFFJFdSpdUSXjVV7GALsq66zbcrwKKRED2x031XeXfxzAAuG/j4PLn2yHqH93+cVrFyO2c6TpLlRKIAYyzgQVObBXx9SWgXY+hWWzUwlh2kOhEhpJdMOcUbHbZ56njycFvLO9xcAEZmEaFrMo/uq2DBHUveOxtFE0cLzkQzPT5x+nQxrVE+/+nisfVYWNXH6VEEcq1ze32vcmKph86DwCw8dCMvXhgR4kAZNlGeiIG66ItGXAU9OERAd6RV9x8FEoETCEmRIrd58ov5LI2R64aDVwI/SF1UvXiPlpdIr4hmIAi1qGBYtle8SzU2GXpGKgIjszyw7x1rPgn2DYvugF6/v0zKEBLH7QxDrlaBp0Q44SRJ+dEWEJynP3T4edfmqeSDjnC+2JpIySKorMknlkCkTG0L7pW0FWUxkdMhfJQW7X9eJXP6hAl06AAm1WWc5djV3wy7RdfU+p/+0ozBA9Hc5MKbl6TXWRMhpyc6q5FFNR5REpxSaN3xHn6Q2YSIzggkrN594f3JD/9vn97Ob/Np/+rp2NgvVWQiqMlf8O14B9G7PeRwsP/qms+/UZSfR/yMxVcGbkOYzdO7zest126uxcjDqmp256W/K7O3djZ2tZB4NzxTn/RpjskZl62M9X045f2W6wQ0eOQv4IuAJUbt/9ShHzFVGqnGheguFBhVF4L+osXRgxD2efgNq6neJl6PuOnGw1Qj2Jb1Dd9oisto6j4cmcwDH59SwL0fmlpVapJEcOSFMz7F60UPjzUtsQxUAON1VhWtevOa+A6jhkLZgC23jqtrAxE7FSYi4ECvMkBRHvJJVD8rj3R3yJiot3AlyomFuPOs4B176uvjj8acqw/qVqdz7Fi06JqoPWTVgz5BUapBmrYqpfdDkYiOUth1JDN82ZFxXJaoI1cNFjWwGyQMQGYmNgowonFK5QD8sBaVhtCCLVrkbkSMJREOAtMIpEtl2Qo6MtZfI3nwVyQRa1bvIYzMXQPGLcnN1LykBm7+fN4ac4yKngz/wA8+dW2ZS+GNo3ihlyGxsulRlYK7GdguyyqN5KVilU4FVZk1QCtOEmsU8h8Q5IwiRo0JOxm6dx5dyRwQg3Mc28exepAl8cmW6ULURIglvA19bg9AeU+4Uy4FQRmHoxUMPYgUnhcLo89ctO0uQkfDdAJvqpmCZ3JPCii5tVEDQeadwgKwdEh0tEIQ3TARvxTBsj6FWn1wBN5ZfBcloO8BBtDIqAby5iWvWBXMID0kHg8yrpM31uj2zmXUDrVUrpTaSJTwqqprvqqrSSE2YgYE3wQYBbkWmPIZ8+QUwVAwFEOa+VaN3CZOIak/nQMZfzbHghyxghJC0NgW4AQSSHfhxppbvxVzMADZgMighcd/DrrxvWRPqIqarqzMNnX1uSwi2VMTkOygxjs/HbVrACJV0ezAn68SlJ2+gUavM51LArUAR8yOIoOwDRIOti1NfyRpUvE8dio6kfSGaZid5jJMdru8ZBMmL45hEeNB30Aa+0/IACIdf5Zre3gABnfkRpfMgLVThUH+79PAUZfwpzl9JQKZmXLCkz2TjkGNwoDi14JwNwQK7m6wEG1CvDxfNMsEmCGuuCl+kdTucztN42Aec6Bgi6tumEJDYyQhZeNaEVDxEmYUJLxxtgPVO/AFtpbjwKhrVCyNxoNIKGlAEKoXgCSHbze+ylN4zasXwnjxfIWRVT/W1ajnoNhCpEE5kTSfw3RltDSSmIJcdM8iuPESIcrDnsl3jzmmCK+MxO929cdc/91y3k6LbE3YkO4H3kTyLN8GurAhDzlNvzkJxSRFICJZJjtGmCnqjvbwo5ugboAB0NCd+wmDvNb1M2QkzdrWgBEtoANUQC2H0VSCzzWTEqJp932bCpgDfUIC2yIX6Gf+fkvIwQt/6uJURzfm6V3VJMhBijDl58IbnOwDAbOnjAXGNFIsSjk4eMOjRX72Rr85fOS+Sqtt3yuAUZUiOr5VvNA30GgX85897/nU1ZNGCsDOzyHgg+X33fk5wldQI9rIMuCaoM8HKm7C1bTvMl7oG2isPN6CQKdOEXbIhX0Gw8Oo+9XC/6z8jQjmxXVB3hflxHpnkyVS1N4n4T462EXfgENl5NTrBZcypaobUfqg28XoYLrJs7bbM2y6kNp+ipSUzfCGkto+BzCfJHECAS8gIADVRQ9YbWJal1cCFzJgBu8SEBNWhWKotvjeD3O/eDqiBkq98nbz6DSlX5HmnVxo6DaMCcCtE2mNM9U2SIhsOOA1whe4xXhd5s4w3RgNJjygA+nY8eaY2Fye2+MgchWe1ww8Ify4eT1mUhFzNEB8VssRaOL4dYaZ1t2pOWFVmTe3t0Ny0GnKgkzf5QED7G42SGrafJhwsz7s11c3V7t2UqQxSbcbHanbHqUtdP9lavXEFTNzlPfypqyL7j3A7uPFYoIJlB85AHozJHbgjckhZGaqY//tByQW6cTKmPVFmZPquKB80GQV5CDGyQtKBBevZqR4Yb2bJAauP8Rd0sFLTsYY1zRIYLNCnkkjcrcETJdG9hBHDQzYdJmJeKhe9dH1EyBVRZjC0iYSbKlHjkngtWpF8gKTUzLKBgVhbLGcCE9sRLZDgfSJhwiozM2nppgl2Og6IgEU390eW343KZJICjlEM1j//LdSZsONHRvcoWSAXoNMPwFT1EgZURNUYFaOX4owEF3eAlDtSmCgaDvHkfYB9J9Dlhj27q1uEZJn4rsKk8dGAEyr2DOYqO51CmE+sCYdPTV0/60q1SIjheVjK3fJKAvVmS4UsLAJGPrYCgy5CEDXPWz8cHxi5H8Pl9HfAznvUO7+0O3muyKj6b7DFN1MdWjOjFB1xkKVMXilLvPaO8i0LgptQqtMp+7b6KDU8ECW+Zd4NG9EPejHkfeXBgCuOH8o8kyFkqc5ZIHV9UKAzZsy7DyC5S4XWlk7X9zgALEGOp6b8NRrUSltZEjgsBojLwa6jWSIyjYI0DDDKb8unwlUaxAdGuLdCzwQ5IZdKSPpXFnz3btjX+/88DfZPe2fVgt7NLy9LffdeavPxZrqo57GsMf1UdP+61oL9/NMI2/WB0nlKa2JvVNzErpTQyBNaOYlYIC3XTBysHcPx5XhCngBxnFaLpxBy8ZUjF6yqz2PHzcB2qaNwo5FRUTGChWdJWm1/+RDTgc+njqHEOlqdV8V3OH5httUsvyDxPe6lcGUkOYOQnsEzLN2z9Ro4KOLCp5pDZ6OpHjwcPhwZKEWt7GwZ2Bg94fmHrWRurBFgIOD05Q2P0GMcgH/xx8vDGlvqmmD1NF3wFEZ0vVSEQQke8coviEKU7EnSkBMTDZCNhhgbG6ozHA+ex6OHB8tdcM7q7Z+mHT8eYPZbdIVsyOojo6Z0g6QKA0KbEw2El4jYoEp6qccdZ2u+FwaaasikR2EiW6MdBsek6aCU6TlGHNzD5RUXTK2YmL3efy90TmR3VTQFN0z3Y9XR2xueEYce05qcpdOc66GaxSE0joEURsM1qziOn8VnGGxaTYKoY9/Iq1J2k1AqEf0BUI84+QqdoeowxjrUgDr7/Hp+66Z2smj0/Eu17StopUblVw8l7wzYCyZL6Omz4oB/AqSIA0x+3SOdISQI3jYUMkgyqUUHrGN9HMNXKUPCiMRFLB2RNjIWpeyPcuuC/0L5KYB7iGHpq+u8zYGWhPQP5utKW3qj3l1DIMlR/prhosMsNN9IJadRSnN3tgImBK1zSWk8LZRnTKxI4POCgrTtFABzHaYHxgoQjl/Q61q3c6+doSRx94pBDtgNLMAinxePwErNOOZURNsNVvLKdZEPWFw0DlGh+YwJuaAyfsNyzhZlphQJTWq43CYc3/wVrEndYoRJ/ARugBRGSaGUpGiq4DoBILoNWD2FoVOHWUa/VthYNth+xzvYtOT1Gyo6bihR4oz4XVjxUNydcSkDKjxPXzyoTd1iuEncND7HQtHKZ9wKspxBUTGt8z35/iemOjUkZNXput12Og9jbXULIpk2S4GXdO4OKjmbCgSQrx+7+H+MADUnwN5GIelYdOvccys5R4QtsWNhYTTFiwgmgoljg+VClVxA46AbcbcyUJV2pyUDGEZu/ZbW7e0vcAqrsNTegPJD9KYFUnlSGSrBQj/RIBlOMrluySS1vy3mStYdTlGgT/RsJFfJOm9ud0opSqvgTQ257V3GtrwNrbXVLvRyCbwLl9+SyoR1PhSPwTtcC8PzExEjD/v/6rzbj8cGYGit5VXu5FaPuEUZ1eQN+96gwOfnF6TDl7rV4PT6aa0k5lfjZohGDfrLtjIJLKlhGQ1hfh20E+gRHMaJDYNOc0sU1LEXBYQkbkpVvcyeEbRDduzrHWK6CU7v0z1PzWmTQmuvYhHzpQWDrSEgAp41nwqJa0Yk0ZqNfKOTl8Zdtcg5pCibW5EkF/w3aizpNKiHvzSIfpBNjFW71CKjpYxAfhe3A+D2l7fieE0nzk3U7PKmgdidSZJwCPR3kTClRQnkfojQWegFPZnRgI8OwSQvG9//D5RITfcbeauzcacmEe+DQuZR7MiblOuWOAxLCPsgVmkxWT88i94+883bxyG7Ur44/QyVGIEZp6F5ZsOijZGtaxCp05ehv3x8zzCOVfi/dwlUOpGWDwX8jiklm1q+reLWt4O3ui6Dkda6t7yYFmfxzO0Fhsi92+3XMpHF8em6FLZfrtattNJmUTLxf1W1z7WaRLhl/eSM+XZd5rFJ6wyHrs0gTtXMgb5NIukmTiZxzReAQ7q5OQZjXF4ySBTwHFzbwUyWWwcaalq7zYMmHaRMN0xKwCf31EYunXzfMEH3wsodHvYFoA616X+m89aLbM3iYdxWvUM2VvVWuch0Z3axA2KmMqGSNkGBRovO+jWTBIL/AfKAt0vyJOwO2l5CKEisfGHIMPQGPuKzGlAdtwqa856CmyM5s+vI53w3ndhXHysYp13GDSVpl0vpHtmrYyMRHpTt3EXKBvuIpvpv6K8/X8qRHC1wB9uLy84rd4Bh146+UF9N91yqDoLVHcCXmmJRHQS8ZGIeEUlsqUdY561e6Y5pipBLEhYLYP6GUtoo1UCuw6kTEIp6BklNkiQnBgsYKKtqdQ4Jxfoz2VEni92Gxcj/Y8bep78g/cmyvGSu4HSA3PA4eM+eiBtlvNpNUIYaD/5jv/31TBhRkjDFXc3ZPT45kolVPFdO1QrV/nD7BWhW8tqgA3zihYsnWZonaMQamAQbqco/XSW1UDiQIqXw99P5+PUa58WAlaLTMnWQpvB/sk5gW7tNdAWiJ9JHxTMQD6uE9Mn/fBSACv9BExxul3RWU2hTNXkvh953/Gwws/o0tUn20Hjjz3069PmpO/Klj9/6u5OZP8oDQpeNozbjQycF2Nnm5gcJJq7RTTjgZ1P65r8hFpZIHwgkfhHbddGW2kwyS1bKP6IXa+lX3TZsnDY2pnoGa6Sx3+ZvrgIJ/JuzKfmk4nbvXw+7ftZIyf7y00cGN3COrTPM23tjvLybuS0YMzqGJs17ovfFL2kNk4gB/0EHHWwHbDEwnmpCTRoPKfhXc7ukfc1jymqjSiZAzml9pRqYe1fjfIKt8/uRHSu/m6rHr3vtEAZAuOTJouGYOLGfyXUBRtlVK9cStDR4XFry+V9VYj8WpSLq6+Y6xd8/0PdnrmwCS5AlezuQxGM+8aCC1/d9v16tfRDW8B9+ahfAMcBpwvdq6PvvwmhuPvwAUR/YgFNVv2mjjadBq3skbvCUZgNmvALLlmmb2l2zAhcVsETPkrRuUK7g4Y+98FHDM7xOmZTFKyznJrjAhKiblaeGGMYPhRwhDwYitgtsmC7RGQyyprS3KJTUPNHxDKKV1mJIDhDbLKiQ6Anc5LwFIlWgehmyISQjUZiAHe2z8H3zuOWSL2dqyN9MUAQpthiC99aQzBuzL0WlkO2llhuqwMKA/vXgj+N5gtPUFxlRkFmbA0prfASbdUWy4a7dPoqEM1xqVMAthjxsaJ3xbncgH6QG5e15Ej8DFBqU0A6nW4QvL+ckB8um4RnejJEQmFugFDxH4ZSPHhfOXcKhkPINlPXVFHsgBoCtfgC0sr3QsVcvb06z/dzK1UBNqIMhHkQbFZneo5X8jbdiYMti9l9v1nNu9ERalEago30Tz/Gpknqpb8JOuvPWAZ5FdeP2ZEm9N28Xsi+le5VOnILZtjaMuQh1wB1OCrp5samkYG+wSWV2dNGTBYgDvgzLkEP/mcrUq5Y6WuJXukvutbKblS7x1PeX96OHRk5PiHdq8WufLPAAeZg9u3dAS4rqcBqbhbzKL9Ou3ZAyk2n49D3iP27G6/bh71euqfLernZPZ55T30eWzs/d6m8yyR9Toy2C3bxJfejfzTy0je4XDNH6qKJp1QJ2FUqr7gOW0r0Qn/BpRbOKdmmOe/vbyNmKmPAZi0guwezXblCp1nOoAq+dDUUvx7vbi7P86kzruRvYd+vFtNKvAKvHlBtF6JP82Xl95bX6vO3av3/CDnOrMu8rPOVnla4G7wyF3pWOOfJtEUtu9q8dVnyyLZpkc+vvocZcLI/LrFn25bLdU7zgBAW4Fif22y55LY0u9xxDxgMay5mRVduvA7bYAZdo38LUY9y9NhqJdjSo3/XeqSwl2lv1xxg5+9EyFh72Nmzuuv3fRgTzX8coQmiA0pP2W5raUs1hTh6O2sWO5oJ7VIlKxtAjn9Lz1cxiYhOhn91QbRuvsUC1+atG09+7P3dQUshTGiw4VIfWDAafMTNugfptttuoj2DkAYooSwaydgGBdrxAU6pAESOP6Oxz/NIqx0Zkv9KWGxphgPFMMYKspdIM64H+oKLrp6ksen8CZ/vwD6sNYMWv1fUn/ez0/wPWrjOhhXNCDdbQcPW9NRfsBto/zQ3xsMwIZ28IrsxDy+xUgbBRz+NrqdqgkYNr3wrIG2pdezdHpRFS99xY6/q5nq3ZUmmNWJuMSQd3cm44bUgaUjNlY2KiBwoaOgqaKzjTsztNcWDZYX9bbJqPLAsbwy/7Xx3AagWeEbexftBpSE8xQWvKwksMWsR+F6vXhCzcJOk60b7MwY0NISYDtm5GtTbOH1ZLydFrMbjC7Q/8naKbtdfzbvKiNgPI/kZwWeX5WZlraFalYSTzrn5jT46AO6ARasIU8LtS87+PqJRAac9RcLjwlyn8S4e2HqU6yPLKtXrO8xnv3MJSQ3swYKJukXHXENWdWFg9vvE8HqHLeFh+A98Mqqsi5s54ms0cOdCKFovkiVuoAAZuTm12CBzDfKX6DYihagP3dKztqmhhtp1LmAczvcUyWk8tT9UEp9L9f3JD/+w0+P5cbueTsY3r5yPh37XtWW+NOjV3+F9fvOF09daX15pvlvbjK4eZXnfHNpRs3xuDmyTdS+cCBZzJgXXXs1YP7wkmrz0E5yvkcs4QFQ8G/hSq92bN3Ae6wpX5SKwAlO+M+xUM5q+SDbjPFGvvJK7gO/JfGLuLoupqkvE8jPxRyDWPSQpfP5SZptxsKPV07ij6L3m68ACl5S/d+3htVSZOKVp8xK5rKJuKA5gQam83c9F2G6Hds6ug92fUQXyLpIC3C76MWFeGnYCKTB9Z0ZQysxQ7/YbRf2hk/7t079whMQU2aj+HH28YDPQaTb50Iuu2m84paR/egADcqyAtKVJyF4vQVk0XOLfMhYhk/T4zEeRdILu8qYM4j9o+vCFsfPzndHpSeuJvJ01Jj/gdPPa3mn/W7gdUxkGpfV+d6ogWFP3JqI1RLEpaOUm8ug1PWhKJnCKuxDM8h4FxM5Ky3qw225Pu9P0Os7ufFfvBjtuUKDb7UsnTRu2PKHk50cMfZAVaJGrsodx0kCvHwJ3sEdPgprgpEcPJ4Rk9ibZQ1manozUd+jynWqjFo4cX26jp4luGS8WA6Q0jTj0xqnClxEQWBnoQ/+kXlEFEWMoCCmpBJovW2/tov89QQc+CNGXR422hwxJcivzhULIaAy9VIX3vA+/1DDYFwuE9oCRXzzIzcIFFgZuXeW5mtvDWpuvYMhG+IGux2SCLf4h2SBm02hTFjBgMu5rhgOZMYV4NftxWHRcsqswBuwVQMD4zePADZgmCBzuHS5asoeswA9RwkOqbMwvLFolDhdMkdPXTQA2HzEBGNbrJ1q+5+gHlF9nnLW77l053NHviOum9op/9RM97BeOehzG+WWfT4vbYdbmdKNry4TzNUp453vVZF3ok7jjoJ8AO7A+l2mC3QM7f6qgMFDbMQ3y0aQrtzPF3XCN0IzBpfc7NtYCfYWh+UGzMD2+ZDmDdZwhFqI3XjOGxvmYTlcsdy3wWqoUp1YC/ZsSlgD/oRg4RCy4oLIY4BUGaKt4GV9s/vlxPuM5DYhOZTAzOAnWvMEQIGTJkUpz3KbFAOX4JLijNIap1xpmB2kT3II+vo103cVfAM7Zih11kPzaon0h2DghhM9TKYKSJJ65XhM+BgW2UW2bKZWkc9hsr5pLzMoR5kMmXMK1IddFqjemaPcbpBco+kKUvgot5e5+/uoT2/p+Z7+11Omv3YCpIZ6bZl+s0vykfgIBZ11EPc8vhCFWBX8wweuSR4oc/KMESM9rx7tPhkZf0hI14CpLUVitZl/cYm4uzT+e2eNbN69evrTfrCypl+VppKTwp8fKn7k+9iaO5s9qkyVy3dSjp+FS3T890ZVa1FO1e/V3jTHvm+fDLPK6XPFTlPYonIkbO8EAXYPnYJ7dG4kr/gNbqDv8wTEJGySTNXbdytDr8vczL67gL9MBmeonMzeX7GZtM62LLE1IiC9/3i634ihYPC1bpBum0nRtFVtMAqOM4fIkxfWXrGY9OpiE5nmn2Q6SQMXOEx9SCo8a35Ac0yOzP71khcO9Ic9yK2Bq/cQg2eASae3UXk0iYQKH1cM1XCaBCWlB4LwkuKbjusjgMGx3rcxKF5MhAXGBAM/mU9xxIy2hQ44X9W20P55Oo4tnKmkANIalBpa5KqWWvidJnkMDZe9LTRnTpXFdfAkwc2Ump9c8NnQcBwFck881kqEI8tqMYCwbhqfJM4EJMJ8vq4LEkAbSIJRZNRxZDYUajcDvmANMeaDZyaDSqtfQ2BxdwbTc4M2YbVDwG6uJ5xExvtFmo3RcE9ta9hSLOQmVni5UMK+ajPtE6wCv+InrOL21V/uVB81t6K247pOq3GzlPDVIXlO70hNvL08jxdcN9OmqG6KpVr2Cb8tqSU9jjcYcNYcrlY7CF5KZb//nXBUfhJ8RKBsAAKd82OHkIgLXzzpovgPgxUfS542Hn/xP3yX6zsb2+jQDdAEBAHCA9MpPoQsZkvngkvp0+OcYMMO75BYAOeNHK22bZez/fCVGHF3qnUNTr2yL1pJoBTWTMstk1DFJuTKc16YiTdVxFbyAYTAKDBOjYAykvH5TtZlnAJtgy6dS039TnVFiNkJXKseZjRO3Bc7MCpxRO9xiZe8kQ3zoaVxX48EIr9zDEly37LhKmCceDJMr+5KNLufZ5e+9ZN9GkElbyKkEcqGCTMgTE601qUlVfOhxs8ye7gdkCP1ukTBJtvURQTGoHsWHlAOU/Yf1aG0IsKB+Be3Hbwtw5IywAV9L6okQS0q2/nGdwT0VTPWuZgzQZ3+R83X+HnDsLv7RMjUoOaydZSbpbqSzArB1FmGaP4KuMSFDyCWufHNKQu8ZiE1kLm8/RL9W8p/PyDYad6IRj9I9bp0ZR2XW7izqXnhaOqh7jy27zpDX+g18+2+mmoeiKvVO2W4wdwERIpdXJO0YSO3hhmPMGk1RnWXmDHE3KITA3VWdB25oHhokT4oZtFFgKBDbk9g6IH44nD8aIbugKVATQ46nRs4oA/LdhUPcjc/7XCfhPKHOEDAYsW2f0dp1RrysjnHW4obyjTOSedgc/27P0GaaFZrfkiHxreFUu4/nob2TKOcQZff9dOscuFWmUOIA5FlAijQCCFTMOAHWnWIEHAAZhuDBCV0Arl/7d4qDjBuAQM7J8Ih2iQCFXSgihIyPhCPbyD8NDDPpW+M4s5hOlG6C4Xsm5bm5iRkVGdtk6DQM5y9EiNTpWGY0Mp9MnpP6Tsy2m2A/H2sMxoq5tyVbLnr4v0wTTTL3GCYiVkadnU80bDrWOJnGWMZtx5psgnRKYxRmVG+6o5OqUoaQFkam77afwdcMw2XGsJTO+YkkgesfiDVLVqxispY+eZLT9ZBDdVrKGEpn5FSxZOZeYtLO2rO8tTJuy9hg61TDE8PkRH3kFOM0468kpjofJtXopsKocjetYi6NElw77iAnp4qBZKIYzEcJFCIvXGeSbe4MpqE7El/zBE+/ozjJNLfNSxQ0hDUbb46WrjFkzriyM3+mLzhy4iWveM0b3vKO93zgzIWPfMXPGkwmv2Xnh3XwE5/5qelkqDQ1n6zTr/kLveOGho6BiYWNg4uHT0BIREzSqDJHsY6oqKU3rszJXh+KVi5d7XXqctFGz+0/z7ABk2btbMxvOoz507Ih43otueuDKfus+MtHMw76xlcOyaM3wuA7Rl/71rV4/oV8N5//9647rMB769x2y09MXnmjj1mhIiWKldrOolyZClZVKlWr8VKtenUaNGl0xrQWzVq1ee2tc352xFG/uONXxxx3ymmXnXDSFT32u2TOhdZ5Z95ltzg4QgttdNBlrx7dvDla9f3TiRMHJ4bBxaF2Lmid6LJd8a4TcTdPGz69a79Tc+7ghO7Nv78rW2c7Ds++QAsmi/F62fFPvLLy09e3H/5/K4vxIRAXhY6f0Cix9PdNxWioHUQObVre2Qtd23Tu7n1AXI5LPdaMPLx/sZaHtA0A)
                    format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* latin-ext */
            @font-face {
                font-family: "Lato";
                font-style: normal;
                font-weight: 700;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/lato/v25/S6u9w4BMUTPHh6UVSwaPGR_p.woff2*/
                    url(data:font/woff2;base64,d09GMgABAAAAABWwABAAAAAAL2gAABVVAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG4E+HCgGYACBJAguCY1lEQwKv0S7NAtgAAE2AiQDgTYEIAWFAAeCKAxLG98rRUWMcYABpq9L9n95wA0Z+AaaGJLSoW3JGg2eoqpK/XS9O2w3I3cID2McZz5F+XaVH7Sdy2fHOw8XrW0mxACfn1NUZTglRj2KcEDnW3XKa8TiO0KSWfj/3p+9rX3OufSk7tfdH1hSiz6wTPQiYwYUZC7HrtyunClykBBVjkHqIIWZSUfD0zb/HWEc0SbgIVYRVpDaGAiKgdVsw+S2fVn6YdG6VFeZxLp+pulfjUmUbTg8RxAGQVB4hMbhXBvfmopaUVGhkfr3SLeaSUIQjTgSWIJlcd3Lixjhpem1oiqo74ruiu6r6uH/X10JgaIB0hZP5wfICtACaoYrz1ZWUB6q09TqqmtPGhCAjOD/v5avyjn3DnzgbdSvAgCdsI2trmS5c99kJu9NNgvJNpMJ44Z5N8RfFZgUAQr3Zd2vqyKha3t8rW1lhXd9jM1Bv180OvZbn/aFdbVVCMMsjoiIG3X5d+/9LhFAJ4Yc5lLmqYHP89TdBchwAGwnCLQMAdijcQqm//AD3AKphZnWuoF48PbMGlRLEfTljUBcUHng8sPDh0fPHYy8wTKH+uY7nK5uqMlBiwHBvVhTXcM701Do0UQohJtymMhvLZ4c4oSu+yodgEkYeXqvpZ2EB9ILzwRonT6i/43pVzes9dXqiw43fwm47iW/+C7MAwgw211y/jdBi+bDw/YdeEv6KVv6AmAGw0p0ftRYUJqLs4jBkQIB7hz4MbnqlORQBVQLTYeWtCt2zZ7N3IkJ5v7idFISSAfVQP3MX03Kb3mTzhD9a2ed/H/z/0v/0/9X/V/eyw5AKnsLfnYsFafJu9IdIf+/wR/Oj9vnQN/+1EOVPao1brg14FmzSRVItRa3NULtB0Lws/HmXXknntVQxC45kGZ7Zu+THQ9aIm/sNeGIXiR6TLjtrK3KuRWJgueLcPeLxFyawMSXU13kAL9MVaupLhwlSiJiJ8ELY4hs0RBlb3tALEf0H4c5wLsPj6yR4IIVGCzz8LpJeCbwrRMFL2tUyElrtQFwqDXiOuyU2fAeyoc0iNgYCpw4m+/VZh+JiEis4QtMOBWi9HI4L9Io6uKc12OiE6ib4D0SMUF4lnLWmZyItLyBp6XHQbWOrTdNxNmEBL9E5udSjw+2A7hnQ5ABmx4RWY4VUbqnDJ52ySTCoYSdyPkVMXrTLRlqYGCIq0H1ojGd7X8JQ/5x6LxPFXFKzCfWqkhQaSI199HaI1N53ewQTuR5Juke0km0QO1DRYrqKxhWmE53vnzAD9iiBPT/UDUZXthRlyLAG8isO9NEsg0w47b3K0vDo7OKHKMYZCu0s0Q7DvTnCpoNhOfJebNyntjE2iVIYp9D1O6/AZSLdQSvZYxHBP1N6RDprMyQGEqmQmqLCFFLcERo5c67RbPj3duuG56idttOMZqIMRVS07ZxNjWMn8vsUrozPwLP8toQWLvm2s7fOhDZjbSUF9SahFCzcXvkjBgbw3kjwwlmRcJ8bjuRzSUiA4FgGoW3QXjILt7L1/DOfEIrSRVqW7guwUjNt+3s6E7WTkGMREljwiYDW7rmwHs4sxTBqybYPPPOTYzOGNRxftE7WDPnrMdgZUtnSDWlIENCGCV1kJG5Y44bbpVh7hqTmoLWjzi+aXSWQhdH9e3dZitWHcHmHJld51BAc4FADzavuhfItJ4Skq8q0A5w5ycLxUWKNAJZWvYpNa1RFL+4FxoUS5UZO4QIC8TTvFVHUmrkaEWmMxnPEVJRmXYxP8vR4WZxMsioeTRyr3lmR873eNCnRgRc6gp+Squo6G20VfKC3uJF7Eg7qdR/ZAoaF3JqUWWdogqLxoof08pNtERLhAK0wfdqnEAVDdqKZnVCtKHr1QvoKTqAI1A8QKh4gGizJ4gVT4hVPCFO8fTHR/S+hIhJv2g9G0CAASTgOhE9AOC6j9XAf2lYFIR7AwIPBYYAMJ6DgWpxAMX6djEGYCYEm++BADQqnxgmTzoG/o8awMThorzTWJRInzQqDg5xl5CDUtzp1EA6EyYGMJlkBhO94yRY7XY7YDt78+RJLzWsWXfgzJ0zByDzadhy8eBG2OJTZT5w5gbBeu3UPvBz78mrsOX66f0m2gBVS0OpqNW71PYStrx2PIbMT5xvCFZ7qXrZVthy2uGALTabDbDb7QSr0+lMHt6CWjdt2sYaWOeAXAkDsOV4mGnlOBBhlICOpMvXlZtU7QFse2CLo2WadngHwXoLJQ8yO/w9kNlJR6tCcUS8aX7Dp7wbd9k5o87o5tVnCAQUiOinADqaRz1RMoQu28gjXG+Q786JvsC79KQCU5qP4G5zOaU71ohCyWC8GTS/ECdjn8CpJrrCtKu3Hrtm3zizx8Rx+vUUoYN7vVpIgIrm0fB2IkRDKYCMlm09CMOfQk8QBqys0qO/EO8fRAtbTvvoyGUjJ2EYJQ3AG4/u3Al+niJYtwwPm0i6VQ7/MRubtieMALyMzdt9NG3K1ELk/TevWvdzqk6ht165cSccEpc+C9hV7zcZpYEMhgSIGApIJndyhKk0o06oXTOyESZ36zbnDTeEq0mnWY7vmGR23Heg9UBCDYYCqBE1ZA7W4kkoTguI1Tg4dvoqbdQDkLmPnsrJ12suQxBB63QSwOBRB2mKqEkAhXVFp02s0uWs4WHPsnILgYA6pxdy2Hy0bMS46SQz28M7tqQVoebRHZfiS/ZSXcabsAeWOZ2Z1mPb1gIgYgY22mBLDoolooM7kQ46ftpe75ZPpNduS9dNdLtm2caaUHFLmkmWH2KVLm8QHFlSDaf/4uRf0fmL0uqVhsB8eUhNcrxvwSpvG1/B0m+jTlY3WAKuvubz/4mqktJ3Ufz/VT1kS8RMDhsnl7A5GTIcm8MUZbC6LT+DdPk5Q94K8IXWCd2VlHr82DpF2wGMB8dB56ELNZTxDe3kCxeoHZvGf2wqVZdPRc0enr9kh07ia5u2K00z5Sd7TfJTPeZReWV8GSHHWxpCGtHdov22mT4lhLor2nhFiJFyDN+BdLEiSxOjZReio3z6V/9fNL8ucdnopnNMJlcWqOOmJRT7LPSVhogSZFXRfYFTw/oSqjQJ03R10u2D049l9Stm+5gEbYpV+YO7XjO8RwoEbSG5xmkdTYkJmVUxfTw0uC++qjxhTr0qbXm/cY9i8qBTlZt5WVAsFJKEyC/d3/HNj9xet/HybJeQvFaX15sO+X+vzz60uT5qeVSD1/fO3DambU/ULM59x/TYktBdKiYjji33EElqozK0flNVxf7fSDRVEcnJWWx6nif3vbJ8oT6jKaiTEqffopw6N+vi9MkZZ6fNO6YaMO7Mlssn0l/McMxXauEPclFeoJYhVpsTNE0RCzTz/5hfrWnSZhgSae+vRpUkjVbS6DPL5Izo7JJUIW+nklfuU+VXHqJMC9Om5cRObdaNCOtjG+iVvILIxwlVY/c8Pb+tyvJOiHhrjvAK2KXk6Xyq/XRhSkmYXp4umFyjXiTUt+1SjFyO27DGBzn7wfz3ae9m2v+4L0M/noL7IEWlZp0mMHT54d9x/Cj2svk/fzKFiLRnT9BVgTp8HTu+rrVIEp/VKAtx4Z9f2R6kbQ/qfed/jz97M4M/e3NsUsV9Tw9usT/D+G5DYt2zW3tenmFr7t/31e6dKNt6IAyP9eckIbdJESqa08TKqssRq/jltHhJp3+BIrxZkZQyab7uS/JubEqzpq4kReW73pfrnTQeUbB3/G/dvKTaFuFi7Yvvgv6zZu3Y1Y5b5KMNzeRJ8uInPqb9SPanjAH8ZZHDvPivO3+tNDsrmnKpiW8+Hv/4DYtSq+Y04HbkTrNkXjG3yo5OHzqsMtauT+3plew0sOUXy2gmeO3SpaYUjW8Gj+Dp58gsT5KtzFaRwpLHXVgS/7sSxOyOgQGq4W6Mt1pfFPAfVsoVNTXuPxgIhlu3yp4XUg+UH0N+WJZ3nDSb/dvtyPWSBaHswbiPfyzeIFnC/zorfvZqd/dzH4v3EFtzhgdrj0ai5jxViIyVzstvLt5goqHCxmu0pV5X/rv2+9zggtBQOUvPz2+mzwvae9hXvOjjW9YOyrbeVv3c08rj8hZ97zHyplTOOwEysm0rD+lfOYTwhlb1I7yt20dS2LGHL+N+qWY3Tvv5kSXk/3/m78fp3vvzPEz+YWYJXraYdenWOPflUr8cmPvRkB0goYz6fcyBl/m95O47ZWcVL63DYJFRCSUg24DBInVLPpAdM331JQy2zxuRytc3Q/zOh81SF+7x8VWJsGxfrGzH+yjH+7Lx4oyIiN8n6s4toYES8vkL106oyvYzOZj3H09Q4rc0SAUNQmGDYProt8RTTvz0+HdeoWmMO2ukz4+jHerm+vUOaTl+fSNzAh0DWxNA4Yr+xNa0teievz1pv/yN0h2iBqhZNmW0hXc3WcqrKtFrXpFL9GU97qkI8l3qOONLH3T0NT2yTcoLfBX7qrWG7MnsvkG4sf0LcP/2x0TMW9vtTz6WDvMm0tPHQ/8iLG2JbfXfeGvyRgfyRyckfSGhKC1K5/ZCfHQoA/wFFuwscZ5/LPVDkwtH4xeb/lL4NOjbzXq1XMxno0GrUXELjpQTrCuXH7s+1u92DGRogpvMtUFhihuAOSbWBKlGEmtay7Ak59GUWgssKWVcZu3MY9c/6ne7vZxjZhq5MbJEM4P+qq9nhgfwDqVUWJQ0eReH7bnnrmeXdzJyflVwTF3KlsRVXS1af5gjBcNcSjbBg3A2WaQg3SDCxBKz/SmkpGUb6UCz0s7pDmDc9tewEOsMjl0F+cywFOggJbEoaZJ1WFrSNWWe0LXMeNR9MdrwjFlBBqOpy2xsMyNnSbtIA8qlPjDkt2/FDFgwaJp16OjPklne1Wp4JG/HS1hO38pwjUozWdgE5MI3eMjjBkRxOW9/arDsAzPSNPtizRIi6ZOZwTGNz3zBL8xU3gWMJoaJimPqgXjMcOovUUs5jjQxSaMpMGbm5IY54EK3Sv3ig7Iv43IH2QBdv92dcckpkv+4Dpg5LEPu+Jmi52HsieNw6/keMNxgfTDQ61jhlQCVzYJNk+BhKB7QuuAWTV2R+keSkJ7ttMLAYhocZR2Gy8yD8Gf7KKYcwx8J7JtWGpqRZcfOz/rUu4BlWYQsfqocwClOHVelXLK59Mfiqd2InJMyfyp3xFKC3WkKOy0w8Di5ykMsLRFViXQ0whTXD0sULdkNjQWix5w/tOtoIKA9Yl2aFR6m50bauWjUSNk2EzFJ6NGkniTXJJjIngSbQrXTgATsLs+EaBXKEDUVeRNW5mkYdSyndVaARk3uIp01v80k7etyOCl5YlsWvVQTuXihWnFsyzQ0WcqMS+K8zl8tsfJWem2sySVsQsWtOrYmpdE0D5s209IMXEnsnfXdFFyrUygPRBNWjLIRLqSUxByhMxj5TkEC3hUGua+Sh8BuMKmmW4WZL/WLDQcR2h3iuLGRvuIQ6wYqmwVtUa5ZUPX0XdiH/b27+yeHJ6vFZNTvUp+UVTkzbmXUpR/Lkzmm8qBi7dwpcK97MmJCTpFybAhajXY7lcrjlHJ0mlCtriHW5mCKApeGPU/r8Om/RryT5bhADoMIOzwm4QuCUzqtlQKvP0TN/BnqsQoplzQS/uAMjl0t9czwQV6PThVXdWSwQrEwBE2yD1sPt0PmM8v8aw52TmhMrLTyxfyUAZ0ikUvKEIw4S8DIVYoFqtx/YetGkFr5Lu5tmnTQoI0RZR2tJdjwmMC101Dtaayk0ZhSa8SlhGM5kTxGkjU4g/5KlzNDAOQlN5diUlDZLNoS3kbXYxfXK2TYrq7WV7PJw1tpuWRopj/4Ht0zxnRFQNEuWwcgR4qcNjQitxDr0XARRx94jWvLItOoHbDNhSQp3mN/G5VU8ttRyZ+PSv5KFK7VRzGKp7uojxlx6DVG7WZ+PzNvFKOS7LXz2LTvSgv1kWrzqkbCHVLQxWt2n6OUJAz4aG5M2Filvy6cTNqL15JPWcyOuiQy5RPMHuZj2fAcKbBbpX7RoX5w6IOKYsLuB4386J6+ln5mpmvZlF9cYu2MiqX0+D+mnXp3xOoQc5GhKsgKacGRtMbutVh8DzeCvtuG9MwZVMieZLmoFBzTUJVEzak2Gdc2zcqGaJJkZcqwi7Ms2Hcklm1gj1l2u6ma/IzOerESbBWzdGYY8tEZEww0PKBQLBTQ5OLDbOOj+zDhKHG13bwnhBH4PqW4nvsoKhJzu5lIH/BeMANjkpkSbBqGUh32RHKig+5Yd7TfeRzdlPNkTlJaJg+X9j9axRW9ZBkrF5jiZ8mQealgmYqU6nJks78YP9MM9dWc2Rku3Ce4RFbS65BstUQcjxccfBS5XX94TqOVugAe427dOyIUYgUUfgpMY1RTyNU4RW7gVkvXq54kNdUkqnPbNDpE+WDzMshirsQ4eQ7dYVzS0Dt7ZvfD5P1cxn6OQYrJ0ETCuBWzy27b0VlRg7cUDoAAtH1+9wUbjpSU/1XvchcAv75VPWn6+v8KP6Pqw27fl2IAcYcBAAHl1zUAtAPZkux9AKlOdKWUIMyHpi+QTtKmjywJAQETZ/tX3SdtPC69JoNZ3gbCxh1kPMX2Acyq+8k0j0udoAjCAj6HxiOn5vnAv20mxqGgJEpAAJQwaWrgEtbwgT2kTgQn3uPz9YIrrqj+5l5ZvL1vKxDAdTNwpYeD4S9SIsDL+R0YEEDVBAuqBtAil+WREDf/I0b9/UisAluPxKFbcSReISV3eVLFnByrAc/rbg6dJEl0qFG9KVqPvHtzRTHyjokbHngzdmoVpTx5ao9tEEnKUN1Ao9EQ51sx6IIQiCIQQywZQquRUXde0yVcIUDLcxm1VBtM0si5ceE9aGG9RvTNSH63AQiv5bxBVvdoV0s4tomcSavVML2+ekkQMO3pKBRDQJAYHJaMgDWgt9Vsjo6IEPVC+QtjRAJzEHV5kRE64UgaEUk17urTii1WsTkosXqZDkJpNqY0tECtTo3G60/O8ReFzTCYoVIBVo9SCi0ElcKcEtkmH6Eyqok7PBgiRmO30igY1Tluh4zxo78OqIGBFUQgTopUSkU0qgYsj5kvnBL/AXRR4TVv5KamTiPe8o4TImpHu+p5zwc280pUnvKCGaKJLoaY8b7mHsu1p6s15oakVySGv27Ob3etnaoKpbG3S0FtfU93o0tXpJQoRkUnm6pgXYOh29HbpPCaYqbi1jey+U5Da+PbYKT/ztWCufXAeJdScpeXDGCrL/5YDLipFwkkQ8GTf6iBRCPc/jPeoL+/8sFh3XfxBM/5u2Tux1ZJ75J6oXE3uBlenducDwA=)
                    format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Lato";
                font-style: normal;
                font-weight: 700;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/lato/v25/S6u9w4BMUTPHh6UVSwiPGQ.woff2*/
                    url(data:font/woff2;base64,d09GMgABAAAAAFoAABAAAAAA5zgAAFmhAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG6ZCHHAGYACBRAguCY1lEQwKgv5kguMVC4NCAAE2AiQDhnYEIAWFAAeERQxLG4nWNWxcZex2gH5TJH2PItg4GcPY2JsVNYVFzc/+/3MSpIxhaWBXAHWq/zhhMkOalkp1Qmrk1LYP9Xi0pu8coSWjddSEQ6ed9sKCBQuOcBvCY/8uyzcP/gMrEDGER1MZM66Sp0ZfwowMGNQttbtgI7wCgxaFFPzqXZfe41Sr/+Km8I14KrXdBpEm1fKOe9Gv9tLu0FbI5ywC3CZ+JETuI/JQ+fd8Z3p67v3wQog3AxRtCjP+6cKKwUhIhWzr9QDNraNEatRGrFjSG4yN6FWy0SsYURvRm6RUiGADFhhTVBSDsDGwAqsw+9+oDeVpb2B6dUAVSjLB7/f6M119MMtYFJIXLKqjKyL1t+rK4vznj/nTt77LuwyQqLsoa+tDR2zgExnQF/tgE3m+uV+1f4GoM5l0IU/opSxYOnTtgTPnFA7pbHfgl1UMvC86ge9iG12RFZ/FVua6JKl5kqbi6b9HkOmBGMoqBkiIn0lOtLTq36tiUYUrIFxAv8D/0zv1f+1DM5IMsWOlbKeAaS+4zgXUI/zlSZ0p+1myHKddgYatc6/LJEsh9vNUcrTI62clfHLyRNi5I7VZe8IDUvTkV2XC3hJY4biKP7AVmypypkCgvthH7HuYtj72GTRemQdigQQs5Xrg+pnYivz+7+dUmApboXJ1I/o3l6J7F/dHkqDw44akSuAzguT+uJCkTHrzQ135b2YkWTLIC14Cn7Q+QEyXj1CVqa+tkoAGAP432/tiQorD3C4ZNmbEiNsSZWPfvGnoqsN71V9cy+SOk/ZB6En7TGN5kFFtIsyc3fQczmv3XtZkGEsoeDdVGqGMY41vBRX+/5r6tX23VNKXk54Zu9FpTBrjIdxasQODuAKgqltPuqoqlSWXpNgqJz+OHLAdsh2y86leSc4vgRU7dJw0JfnUAOD4U6i7kzQBrAYRd1nOYjmrJdNiucHdLIfo+739dEOWCDmFWvmE+1b+DENIbkGoU6gt1HUkbZ5cibES6Dd7LPOE/kt7KKHIIq4Ekfy/X/sGs3x7zVZvd0VARUBAuIpaZ77Hj/3S8mA49O5ioAlanMLoXr/7vYNsKwYDr1Luv9UlBkzUo2LBvvzbX7P+Rd1qOVwrCUzpsCNKCaPzj/8HpQawjD8m44MOESYA0HNjRREAYgqgSmP0OAgQ55xW1vG/7QBMIDGNL2vmM/IKN3fB2tvfeNzTqC23i44A5a28u+LHikvPQOvlXyyfv/Tnv9TSCHUveTE3ZKWZYipaPj8/S8u1JwyW90M94xt38fa4FFoyINYENOY/qYC2ysWQtbc1kN2qS7d0rp17lDemlCv6qbUioGssn03llUB2FIUytIhQJqAJtoFChLXlPOGpI/5HASPFzFiyYsOWHXtTbKzYAXF63JP4Pe1Zgr5P2A/NNd9Ciy213EqrrSVKnKyXve5dH/oY2EZbyVOkTNVPqdOkTZe+/Q47ypApc5as2bLnyJkrT//ny1+gYKEiRYsVL1GyVGedd9FlV113ExwSGla6TNly5StUrNZtdxHVa9SsVbtO3Xr1GzRsFD2yPqwNyEIvWpzlvmvNa621iZ2Dk4u7yf70y+ieMdHWm6nIIgfWS8ISAUSiSUoGtBmrCBs7BycXdyEDFwEKg8vIyskrKCLSZtX7ONbyiHSd4dyFS1eu3dxjn7KS+CKFDGgTBIZAYXAZWTl5BUXEIStS61FQQ7eFGU3r7eewPzpiirn1mlpt9zq67YXR6beR+FE0Y2qorAu2LSpa867XVa5J6YuK/pKr6bu/mVPTdNemtNpB1+jwq0juUFArv/qu8E9F7O5SDh0xMaem5i5Nd1o6ukbnXsRAzTQVWxJn4RIQRqJLSga0ud32R65BNWpJ2nd1VE8NXovqEV/9CAgKiQTSBUOgMLiMrJy8gmJqGu76QIk8dVRD+gaGe39HCoiMRfFSWek4DBiTsk4zjjehWyGPAqCW4+Xa8A0QUCFbkUUSmJRs+4rFB7yPBXM3ZNNWtq3b3ZdzU/BTslLFqibQBKSdVLerz/bnsPmO6Mm8hlNMzWeuJcaKZTN2Dk4u7ngIfPwCgkIiObPo3IVLV67dBILBECgMPmm8DLLNIa+gmBJeWUU1NW53vWceCIi+dWmkGVBr2jgd6eq1LwNDo3OiSPEiO0CJF5WVjsdQw/SyTtcaKaB9vnMiHhJF0k02r/iBdJN1W4ImXtq76sh+vA4d1ZCZmGuJsTpgEzsHJxd3znicu3DpyrWbQIpgCBQGl5GVk1dQRKSuppFmvFrTxuugq9f+uQMZdlT35JHNozNggLllmTcOmxi2G0Aux8vVrW26cUOjR48eehjWA+uBrcEM1mxuDX60R+2GgeF442TCUItiNc/GzsHJxR2PGz5+AUEhkZzROHfh0pVrN4H0gCFQGLxpNePNSk5eQbElKauoTo3BHb2PeXCD6FvPbZi2nr6B4eE3saVwcAkI1zlR8xRq6OuBj19AUEgkUYqYuEQf6t6TyObQF5OwzAH2+RARlUSHdJEBbcZqjo2dg5OLO2dU5y5cunLtJpAOGAKFwWVk5eQVFBFpr97hy0iDgrrSW4zBhOlfZ6jgdw98r0Dv/ByLBcgizjKttRiJCukmA9ocuX2KaVV+A3LPh+mR6dk8o7uyGmpMdMy1xF+D2JqkBamADQKFwWVk5eQVFFOz7+4WlFSYCGYKj4JCuEXV410pqmsRTGBiJrUusSeIQcLWwREuAWEk8qRk81IU6N1kf0eE3CMFmYqqZ6Ml0an6YGDhqQ9+AUEhkUDyYAgUBpeRlZNXUEzNo7s+3CGmTtJA38BwjxaZjE7FXGVZAVjZ2Dk4ubjTpuq9fw5Dv0CQr5dfZppY+SZJUFKR5YMvHwuGjW66re7SE/4aOgrNCm8IFAZ/m16UoSiKoi+oUsuoqLp/Tdgrdz+lxLBEKzoGFnUNfQPDw/lIEArq5cWeaMY7NgUH3C/8YJZyyb/NmTdPtgAsclrGWouRi1BRdb9qIFoiHdVn+3OozxE11Jj0MdcS9XT1Gb+AoJBIomQxcYltEqsm4q4PTJ2oQZqQlo5u+kQDw47yKTuSAvK4FM+YEurQyZhW1uktINT5GwuilnQsE6yg6xi1Pu0vFo2CfeZaqQ12Dk4u7m2SoKmgNW2yDu3SXhi9/3fWvwhGHBk5BeM8JrTO9Di2KKCW4+Vq+GYJqJCIbJOQkq0vdbyy4cNdP1KwdsNt2lq3XdmRscsq901JpOLtjzp7H11AOOoR76OLCC+OLzqZ13CqKW4XEo4AAACAS8Yjyrf5BQSFRHJm27kLl65cuwGBIVAYfNI8Msg2h7yCYko8yiqqqfl213vmQRTRT92Rhn5aiFwcMeLI0cOjvelIAJmI4qUqdAQzLCJg5hgsDM8vqlkiWYatSFmr1Xy6b8y1wlY7HJxc3NBILhbDoA4wEgZhoMYoo9NnkTAoQt0yEGwyDi4B4S0XDKe8ZZw1rXJWCs9UXnW/ajC0CN2uPttnqNlY6rH6jF9AUOhtxOVwrKxkBMFgMBgEQVbGdGwlHHAJCCNRIyUD2qza6Hn46kdAUEgkkBoYAoXBZWTl5BUU+zBH/CiJDKGr7giY/oYFB1evAsIpdxMQZiFei7Mc0BqriETCTwoZ0OZWrUAL6KoPhrcWTUMQBEHQJfVM6tv8AoJCIttkQGck5y5cunLtJhA/GAKFwWVk5eQVFOdBAcH3OtCwrG+Mnn4AcDLXGG6eNR5cZ+Wm418RnWVqQi9NjVmb505O7LZMIZPHhMckd4xDzADjygEGtE2jp6a/aaj9t8QkVi+JiOzRbwTsAnAEAp2ebZdeJRECKMD26+bxF9X0zRNt27YBYD2AjPEowLaMAb+hd23IhDPYEMZyu0K9YP6za6V6hnZo8XEq7sb9bcEoKAqJwqDcUWEoptuBrmMcDAawGlCGgnE3c0S5oODNQ3/cuNX/9bSO1xKlb/j769+3c+Nze+Z2z+2c2z43MNc35/Vo+eEMYOS0przD8Nc4IlzD+CgHLUo5UZ/yKTvU58W8l/82cK9chnchLvmbN6QvJwt+P/xW/pbqeJdr0Sr+Dn497bv54BVJF/UXr77THYubxsZnRTngQWwclLLvw/GO+BnBdNJDYSzzjfRNOmNnqeDXbkXIHG1XNSMYTMjRBAmnpjR6ljPR0RIsNDj2P4clTI4ExRbIxxfS8TlsliE1DELJpF+HvC6GiNd2bYx4U5QSkw+tdVK4qm/eY7qTAshxup+rfqbIVYz0C9wgVRoMQ30lmR0f3cklrzdIlYvhrqSEPZYy9Ujip/sKkXqlhRQ/LEWqBu3rQE+nO0xxQOC3NzFeZAmmS5skJda/ZPW74AwTVLhAiuWsJPbx/2SSO0MLBGYBG0IKbFXqO8sFdv+dIex8DiutvaEDrdCuDFMAO2jnQZRiXhB/yTMMVefUM1R802W6InXGDXNghhQMiyVheDlCFL0fAd1/GAAvKzKf8p6NMD/JYodyJ6FO8Q9WiazfGrZKlpP0pTq8jcSmy8isZggnybwXP8+yI8UziVypZe3cM0LQWd79VvxDK1FoCnmLewTYeIFm3TSypA/U5BqUZPyv5eEPZ3lZXI1T43F8zdA7J6BVxFCxU7aDm6389hYyEGueQjS8CpUWr07dtReKjGBHasuxCwGovGwX80podVsfStTYZANiQ5BOOyOoy9CGgGTqHb0YDGbcIBzuQCvRnlneG1Z90V2R1R51ip0/C/SW05Lj49tA1qhgsy84E4vV0o2HPPNLRCs7iUnDJbl2wwdzzzrX0fFFnq0hqkqDTMIYHDUJRZ+UMbcM7yam7v4hBJnQU26f57A+S84eRs/OGkWclhljFi5fOwHRsQG7BJ33dmf0K64105EzJNiqm6Vmc70dWdh1R3jatgG7EpfOGsWu4sVuELVmdG3JaEngo5bWLbBw1jyj7hrJ9jV2FlfDHSPD7uHIvUMr80oPeFb7TthL2EI7hdO3UYgd66tUZ/NyH+WZhJPS1LEc67OP/2M9irdMEmqzTm3W5SvQgzKGOngEzcZkgMkmOWAbOTC3O9Bsl+QvbC9zdpA5O8qcnZ4l2Jks2Lks2IUs2i+xpa6QOGhN3xJgxJgN8zJY7VT3o6esvQ9oM2CT/yltf7IB4k1AexlwwS/A1A8z9p98E2aMGfmNd2CcMMGlFCdr0YjKKL+ocvrLmVAyOsIKAB/0LJsWbks3lTBTf53wuVwhr9LbsDHB3TOddB4dmRVUHAkcMhGVEf37zyhkRCDEANO8JzdrE8AAeLWyOD6zUgIWgH94ZYspAS+jkHkAKfiEeCP8os4a7PXWti3jYBGRLgYF4NoxaPNhpb0hDlzHcHxi9I5mG8WadXILlBMASMlGgyVZxMRDqf1dLOg7eY0M2C9vKigJ+aEAUyQHC2BBIsltAmCR7YORAUQMLACDsYWxYQZ7WIzgL74ZsyrTZPbnG3Qf50AAqtVaMBLDwVp7YEWEqFMADmt8pSuSZw6A49cGmCD5nUZm4Ak0hG4NPio0gaNqpbNrqcCgIh1eJpCyfquIzwX1s6dSZ1GZYmrtufzJaWrMyTXeeunew/BPgbSOej/Lg7LyugP1Am3p7tvFlaaEwU154aS8BWm+Z1Inx5DpHtc6WJxd20U8GYCsDeDOGFSITw6slaPJ4HC07auiLCdjNgvJHu/rWg+ClWOsdPNEgxc5QfI8Uknz17pexFJUHJfDFES3VnlHOUU27ZootbdrvMciePq5SFmiDLgsvp+CLfNZgzp91A1hPM2QzS3WRk7GuE43EWEbPLM7g6R/UV5ki/myOt16xGip1xI/0qyUwfhH4DjdUSolkpSdNXTp3BXG2ovMmkpU3Ir8wtyKPyTjBXic9F0pmPCFo59f1q2/tAhDhmIPR6ZZEQY/9e+dSyHMpXkbBrJGY8muL6bnsz4uEMUQRAYRoHOZJaaTsapt5bZOqC2SBRCXPSgRxQ59PB5ijaoz/MOO+3OFQoXT9p174QB1bAUnsuezzSoimdtFLOJ3P9lb4p/s4DWsVJ0uuLADtZ7Hebjas8S2EkkNVHjQlMmFOfp4bM1C3togTbIqa8ZTcx4EM05Bk1Fukf7rXTu9P5HOOilr2LUtZsaINWOCptP4/+5Z/0lCIHhEEcUdlVjK0cSy0rqxCB26CecC1fpWNmfNjhqd1c9o0MEBaffqmTFlIb7keXzLWhA2CRTwuHAgivTf6T1I8q9LVRXiPRFZHGdnYaYracpKdFw5zjJicpqUkYimS3fslZN84dtjTR3S7VSBOxfLGuCHgnqsdDI9GpOo9Lz6Kb/gQGRtobFp9vgsJzyeAyWDTkDbwjcpk0JhKbp139ZyI3YeYgP4VodtEQUpO/tTDE1lM8rqvem9RcqaXmjCkDm2OJsHMuCqA0GhJnfR+N5eUwMzRn/+if//NyUS66j9882lJhYry2u/xPncr7IedQIxUwqu8axoZtb1ZJSpyxn83wAm3cheM84O2Zt6gRrSRgX8dxOS5n0FlSs7l3YgBefoiMOO5OsM547LfEEXB+pozXdB4x+9XVATZ5Xzwwy1kIoQffL1FwhtsKP4tJq4ONl/hyspySCcdFPvk1XZrtELWRkbKexJy70gmxcZU3PEl6ZiW9ku6YEqsb2TGiRCY8/B6WOZMFJqVhHPZdJpjBuYhzj3N99E1QYmK1EwCTZJJgXC5OfuqglyifrdtVeTBRRVkAz12etp8rLslD0ejjSLXptD7V1rltJjQendrbdeHb7o6IGqFSYmJZZ4wJnG1MjkYDkJB6lcxkjbeNBO5IBXQjhQClc6fFRlMiPBT9ogKGrbNmPOGBn/GJ/dMjVMGQV1mkmP+NlesMe88EloiyE2H6D/wttebEmmJ+enjDnMX3oUvUyf9uCxPI9IWl3aktnxmaNdZjyesgCx/tcBbyQrTHEVpxyDUBA1knaQ0DFKTNU5bik84CyeR9/w2W0bT7HM5ou0i+5p3KIGaBJPtRgdan3V44SwWbo9ZyYYUKWD3vyoYw+OpSaBSJHUZFjh5xCCkn94dcLxwqk9Lpcmt8sfPtPkk0QZTXt25MF5qUmS+J10Dl2g0zm9LW2oicgnd7V8Uoj67TUBTwJ16IV1YGdJYh8nUhtjRz4Pyke2BJGj7ockP1zieuNAA2BQMhnO24CB4G2kEBXlDu+tAzNroclB33yujHd2m5gv37NUjd24dn3PELntTqQuXm8YpHF/ny61FRX87mqlNHPr8VbppPIMgkkIjArH2+od57JSurgYk5M4xIm3x2OlOe+UjPGhqdjGc0x8sJxEMTUhdgs3od20ZDuvTx1KNr4UxQ7g1EPv2ebWimB5cinoOCayLzWhOSZHxuRlDLtole1g/yaMh/ZBlKGCr34Zq++Rl7RwnuHgpySfQDqeGSZbUm3ZtnbMQg/otGYyyIsXVBnVoVMT4YY0SIHWHntDPPTGA5K3HrL0qmwbOwn9WvDW+fWCU21ckF6gTV7zaZfaXib8DtkQLMnaN6kSSBMPON579UKgGHO9EdpXRq4ugXrcpTDXsnmA44yn7JbG0eum5snquQXGX4gypQpHv18U6W4cSg0Mr/Up2PeSDVHxJNLGDMKTSCBlxLYL+eqVbdsbDxfQg0/yglSuc3SchdzyhMEP/i6aQxyRutUd+xsHUlwGd/kgapdoxqHXd9qTLHtsPgmXMCmz7W0zZEaV2nm/4rvVAQ7sBVKStOg70wF4MLu3B70rYZDgbqtpa4AY2bdXEHF+c1KVLCNtAI94sg6E3vwPdUEE+CbqSWtzSwXGdGuIVUaZvhXHG5JNZnoRL4ZN1zseb0SezZosFCuDwrP0NPbEslvybqgxKBB4D0YnKKMouAxzn+ljNtk13jFQVHWy/zSO7Rpp50+xf+lLbGBrAMKBUoPrXe78FV8BAnpAL+fiMt1HlDT4XT15kD+FWzSCeKKqMizw5QkmShqaYj/wzeYQ7tvOJwum2tVmA8vIb4eP8bltPBa3/JDWC2muj2+AvsRI3pZh9AJwi3jTdtAZyuNKpdZrvjaalSn3Juvu8Rzj9j2bnmxqMRC2xHMhaewOcoAqQTanqNpEaWXYUYGrRWFtla6dKxwpNtAazSeNCRLmBZA6Fa9gU4OLVbmt0MuN9S6S/tO78f0XD3YlC1u7M14hqROD7twh2uQgXFMhY9Q1H1RXs4poXJIxXzRjy+u0VoyxPPIAlAJgAyX48uGOryeWiDZuRHGPG1ck5UwmMZNhMClDGxO7G8weXstKn1F8RdK5PUXiIhMGBeybm/l5aovXBfIlyma3s3fuLnMDd3ppdHq6skw0G7UhANGpuGYs27Z3DxorzrkQ9hgXsl7aPFeOvRkV3er21UrzJu/ixGZdLcN0JImhYeYH6V0uOuMnzH8VhL1pPqtTDMrUAdqqBLbY2/jKTyge0BCa9Sg3G3wltD+B3w2nmW4+EsZaZElKsg7RIh5dWSxOEjFqJFjcCOAfoEnJtA5pvspJs9K6oHvw8ro7Zwhv+g73LLPzb0i/W4CSaN59IiqCj8D2PM18qtQ4eDKA0ToJB7gWhFbmtFMuWzHQ41IV0O7S+aUrX/YoZK2Erdyzm+egUBWXn5U21ueomKC10srLgCwMa8x+27Zq/gpvE+bNDvbg5KG/RFl5d1FiruInV804fdxkVzKMpeIJA3IxtQe/68x9/cEaQIrP2Y1bMhdH7kWkxi7MRfuh/eFC+Q4Xpu7VajnpptAHRqSFqCOSFT0IBz4g/l04aeNP03GoqzTrItMOXP0XRXMkUNbFRM9Jt+xD7fJUJwCp1/z3IcWZ+e6U2R/kIMkjk92Ym8qBp7PZCGCUZGBf40skvAnHfHhTJB7HfcoszcJw08gsjk5tdfatitbWwK4YnNIKmkyhdEvvC87XBSE/yUDWFhSRp1LaTGlBlsBx6v2Hy/wgPrhhMIsrUMlTiHzVaJqfHOSFIFMKc2ufbTiheOyaRvN4XpcpDZ3tCLjiZxNq1WtLlzJyDFRBdDsyyp1nId7gSMupufUDBDC7peEkCT20HZIiI1xkBXckNb+YsuQFlpxtno+HgIvt9nHufwbcaHfUSWtl1daPmcqUOpkDa9w0CsJZmmMr6hXdUiTov5qevqhMdjFexPRMCw+GxQy6XseyIKoRu9KErC7cmSdY7G8iziZ61BbzR3wbTqOAEXBTJg2OoDJM4QgwmQqp6PoCaP0XKlMNmCHUBiOkmT5CYb8TlL4FlB6nVEQYZyPdctt1KDfd2ueG0uq04zdFe84byGY9yml1fow3bp0CshrF+fRCziZ/7heuKkUexZrNNw0jXQyN7P3pUShYVY5C4kBo65gjZMebDjnZ/wUVR9J0qz1KBCsuCFcUYSfdLE0jo8+zRzQNzApwXIwC4UFoK1Hy7ov4x8AFg/ml+RW2F1QctqBknbGDE/JnrFcV/ijbsSuwSMpozxFG9JWXjvAKTS3rnAMRCruTaruBxNZw+bW9YNsm/u88zFoOZBGlJJ5Vm5oSuUFbOyoqNrda6hSEUCytc99qRXMrQK9Q2xSUPX/jPvDuSwqyNEeEctMsJSznxgU1K5RVJDq3iiRVkprjEkjt0pSqAC63OkCWQmo/Eh8GERUzkUiKCiwKCwHzU8hIJKMQwl9fdCQYtZeBbzzKhE5J7RNYQECLAeyw7FQnhlwLIhD9ds5JYFB5VU5IuwIzZCHlojUolLmJ/YbyziNlCVhvGvyKMxWHPD15zmjhYpBHtxnHabXzauAW3kdmFjH0i+OJwdKLmTkq0ZvkzoT1IXX5wv40hs8CUa4m/i+F77+YIwhqy8tcFWZ7EhyMT6ZFJKFI0r6gsZpWMZnbaIge3icoNrrsUmaPcmcBywIccquQzivNfU57jfxYV4f8lFK5z46HL6TdCnF0PKvYmbnY3LkxvvgVP6tUGdDgGXyCj/Cc0XvBFqwCpX5CeswhDNYkmCUZvWG5VhGWuU4BJWDQftB1ytB83BTLF6NpLPB+7SSEnTZ6E1q4kRxKxEAS418JKaE3Dl/2nsrzzlox2DrZuubMmubJ5sFo8So4NSEB5V6dCsf4w9XB6thMnh7pNH+jbvuXP5tS3II4LFXm8XmX5uG57ab9jGq8Y9y2O6jGMQ/XetPiD0FNYGVcOyxxWjx+XFpaOi3tGRc7HT4ihiR9+qiUCndyEsi/w2sJF4VVmf5BgRn+girfi2vXBiUpORUYVCqcwv+nX2c9hReQ8JdHz22xAQPVIs2U9vxH0/2oZfjNE1mbwyrzaatSJMT2mBp1+WqW8K8C5F3u+Q6/fC7OlZUzMZmblB2WicwJpSBiKoVQf1mZzEmweQxj69DoBMpNXNOQp6dMeEAmsoZCSrMi2sUsZF6YKCEwttFz4ZaFBeLN7SV7QrMKh0m69PgehLLA9yAC2rrJwZuxT4IKiU7xjKIhJV4USAIrvAldNCYHdG7sEJjYP7c4L11arnTijvdh7Fr525fBKOwJeqIXvMa1Of12eoZrKtul1vvasje3dqBMeJxpzdTiyBuRgXRazGIyId0xtmwHo1IXPpRSLjnc23aSV8GsgmmI8giSIK/U09WPgZe5UZm5PswYTAFV29HSqlbjB3x0h8/NeT1tjxsMrCzgDBdk88Zamw8JyiomeY0tzANlOXE3k8qll5yZaML9HdZXeo4uT3NGTUegMqgslXt0eIYHm+ORFhqFz2Ax07Hh4SoPJhuXtp7Zqs/35y/DUPKMrwTuxZrGYhhD+5ztnbdoGLYlU+HNhdzVaQ11Yy3eap+84bI4eo8uTx+WlaUPS8PoPXFl6uE8H6XUUg1pEkWmSI9QPB2pwLx3SwzQNVdVVISULiDH3xdHjlgdEYtHgiU+Xq68EDE6OFj1cl14Xj6II7lfeZ60pwp6ySV5jMG8dM5I48JxXlHxGKu2jr5LzXDSeReF5zH5t8zpKJ+n0/6mt6656VCgsXCskhYtRweFyHBRNLQ8qKq2vjxCiY+moWRrS0y30uv0Hs7pxsOu5t2udeStXddIjWvHwP75mv35qFOnUOnRO5DvDx4jNa4zbxdop7Qu2kkt+dnVUufA+Ggs7/8V0tosc+NELEISmOJR6ERNXuyXLQ2uixH6FNFjReEsCkbstGTEboOpuZmvD5UWIgikRfmIg3Bbf9AhHqExLkVSW9xf85MUfv6jyJDNnZtiaqLB7DBOc6QwWukTJUTmRYXCK0ILklIr2Us8ZaJCZ7yqzOCDfNkeAvHmU4JVqOaYJslMX8tZ+oLmuYxN25Wv2zdl/9it/xS/SNRqVwxX4ChhIMRRtDSXAUncM04unbteTzqaH3Q2e6x32S71hbCSxaapZ8Z0/4byow6UdPbHfF8PFf/wYBznuv6PicoPjFEQtFRqENvAkvYBn7GPD+S7J+e7a59jrmJb9Y7OJi0Xd80dhSfNzkKTpzuWAkP/dfGZwIbM8B4ZGaGMkqTR6E5edIOStbq15ER0Pbhqq70gC3seKib4Ifj/ZcI4tvtvdfZkFpYuVHW82M+hJTp9UpclFwDl+4aB88ZPpNkOb8wHnThhV7B5+FNOYoKstqbRyfkrz6sEm5yzjV3dzDykrWYermxcz1QGS634rnRPm375RVnGtfVqi6NHbdSbPAEzvecmG83RI2oLh3W66EOVTVtZGtdfrpqtrMqm6EM6Ol5/s3HJz8s/Bxpv9QFDP/Rt0A7ELYTI1r4KdgcMnVK0oS6Yj0PvQ/of83K1YW34AQfZOovCYycKbIc3qm2Pn4Dkj+42zpPFi6qy3F16v9DxEliWPT1/B6eqlXawoo51vK51lP08MQ2wXaBfwHCEbZG+yLb+GOj95x4o9pZRdfgJbedunjYo17rHZj3kHNy+0Ds0GRXGQZTFbbMZhTZzo93BTot/9OZ5v3ohzV9RYyVo/H/TB/83P/shoU7ExFobILfYnF33gPFQApjpbbKCmqS2cObsNQTLFnoCXW/EWeJwHpjVv9dDCX6weMrbfyg86t9b2N5gfyJM/x6Y1Z93WMKxr4eZYDvs/9c7lHnajfqVnw4wpiOKS6brRi0L9WOc8CNCF+xOoidDNXttvRp0dMamaNMmUNH0TNbXD0rSQWi0KT568mQc1+miDlU2b2VpNCMsbXP0IZ0u5LRNI0Cps6jfILLlz18bIPW3llxjdFbRRrLVrJ3ddVdZPWevnuMX4jhMbEZkGDaFQyvE8M91q2avpXuM8QfyG5j+Rb0P/YWuX669Jmhswpq+/uAWSuCfxvuXz0a0FUb1K3nejRK1Vixw9mWpIV+wVhZ+lyxaPcumtwpL8Fw6VhFc1Fe5YseG0OXrNx8Dg5EMvBwZFRIH7YXRPckhjBQ/Hb7WWxeSkhRSJ8+gb2uo389dwGqFVpM0rEFRw+gTR9f+GJLGU1BeV5ATGsJJ8dehazx0wSmykLZMcdSKBeW7WKUNt8QCzinuDf2DvWdtzo4/KL51O6aanJDi2xqfYZPRGHd39boH0u5unRpcl/saM2zS49l4avWVoxRg6e9gd2+DMMoskTm3ncrQyRByWdsNzB1cq/6rDJi5eoKdq7HNTO8F8dVVDvxd9ifStc8xYuyVbvuN6SpbUQ6IU+8H5H3FXINDxP/VdDxxP+68VHo+zvHr/a/qdy8vHLaGL+7jOginan3vJmCNr+55+MUGZjUc4xW+nEs1DP1x+VNKigsIsAlAfa14j228M/+JBi28PoMSquc92TyO+aDijesziSuIWS4fbgk04Ou7iC2I2Zv1ZWTAPHowHcpEdAHD8IlgQtPlRjOXNL5UXwtc5c08Dz7BhsAnP+uDwz/x5VSGxbjz6b51qLeNVVVxb1ajGm5Bj1SsGYokUduGwEMMUPaEl+b14i89cKLjN1Py1mJsxXoIN4NPEWNl9sG0QkwMyyeXFRZR0iN/G77TJCI3KSM+QgzbAEO6hm7wjRkb/iVfFJaeF7Ak+dF797/d3O2j+aZ90GQvDpomDDbQ2oFx6Ts/gjogzE3oYmY1Bx2rL488Uda7QZLtJ3L4nNZjyZTNuDpeixMVUN9cWJbhGRYi84pKRDfJ5PDaQJEQa2gLjPcaFYMdg+BMJzItnUhNdqsVx2EW0pJSfMPDuXAHoTPyBVvWq6LmuBfaBqm2sGvbuSfrS6nTdYv2i6vKd/CYTINZkv87x4yvrFCJl9IpKKGbldUSdKK+LPJEee+wJDupKugv8jugLz3aJ8qP/nVhaYZXaIjcKyqhC/8PcYwIYxBhTjqkb4is1NJ2FMOZJ6X21ZZrly2rjkiCUdFWzraKao6sN5ta5F5mG5Q/yW7vEl1oVzOm6jsmxLqxgqoqu+Ir/q4JqlicwXGMK7U5SYBlDwillO6M9B6yjHPctAaOQPsyHf65CEOZVmMmvN3ICjC9HPrTQ+lcdVJhNzCCEkZUaxKXEpPCNH9wbouUVpXGNRaVLsrAECWPSV9YnzkZoa3c7lvCD04P5Cani+AJBFaI8ydbqJ3IS9qdKoyoLkhaTnCqoCMDr8dZKE0zTG+sJHrBdg6nODBZmWAqbhaUTWS4nC/EC+VShUIuFeIKLzBdDJktwLj0PXyql5We0BiSlOO7OKnne09qUk4ytTjU/sU5l33Gxt+NYd6oVSP9aFTHQDsK3TnQgUL3jwwMuewzxjMwlUJpbYAcO/XavAU7iMcT52Y88S/PkpvOzy/FE10Pf/kXZpLk9iSq1jRAGPP9W+LnR4jy76YtLx4gQ25qaPlNl/FLEd9f3MUtxqv839kKRofpWCGYmF6bh0wq43ATCWkQUmIzWZZJ7E3p+d6TkZgR7051BWA8/54fPblxKbGBSkrdxw+EX4J2ko9MshCf7Ejp3dRnsJscyg/wmts5J6qqQ6q5M09RXn6Q19LJPVFdhVRLO5415uTMhurten31aENTzc7Nm2t2bG+OAcxiV7lA2I6pkeyh5IKELmtLHrf78yUvoPzbBFo+bPFoaiL66u2Kum4MZOz3K3NMigiXDCbb69cy/xg7ulvN6jNsiAt4mej+L9HuFuMl7vdooJqg1GWFSqGD2xQ6yt420kdUmICPXWgQEePD1ivtHZqlTEc/XnxkAHoHGy2DprjJPNlR3slR/MDaXHl/QGZgloMSHUO4G5IydNXZuTOF6xri+6zR1wU3ykbLoalucm82zVvFjCaVpiX0Bag0o6z+U9dtW3tXtkbmgc9CMzZByc7kGacGBmgM5Ov/v6fzm3yohdXdap5O2U0wmDplGS9SNgsxvw/IUWINDIoQJwWTExpCknMf/+JddK5tzrXF+CKMlzmDtXVS9PQ4KdzOYTNDXU/IgArjk3AZYyn2EChRs80l8f4IPj7UpRAWGr/F7xxY0q+xS7y4CsuQuR4EJxifRt2bkix6I0y523Mg5p7n4W6tneTTB9i6vptJ1MdDO2z2LHF8GvtcBfsAsxq+k9X8/ajn0B+XB7qPriPeuKmjg65fJ24jf5fedRz5rqjFb7/oUM5zPlUQtHENFDX9svHXEddc+3+mbzs+HbbULR+IDBFG90aHCCP9rJV2KdapJKFPrVzW5Z8aWGSzwQpibsHmJYuCrbKsU60Ufu5gRltnaFhHO5iB97NSWKdaZQULeclsC3OI1UabwsDULn+51KdWSLJOtUuxTllgfcpqGpiXT0ccH/CzTqEtSa9TaLMxJGT4uXT9YaED2pB7UHStDTZFZ8kWK/34/ha74FV7SCSHdlrkWSuUFvtxA9NgSSgBDJVxIOdbDOTK0XCI3X/nUTk6LWqD9npte+6ToNPl1EHNpdarJMUtUftKC2mHGroPxVeZ2qy5EvNMc3wWY7OQHhudtDYSDLqf+fV76BCTDSckg5H/MZI940MV7plgstVS57Y3zYGHbemb5PCQwTpb3a4Odz2mz6vgXWrw1tL67bwKSb1nBoubujIjyuCKn8YzRwjo3Oy2Be8HMlxy3eKP0/1ztvPsePw8h+dHMlyOrna+/+6Ql9nRh7NDgdDUzv5VtVUrVoykw4MoKmj/qlXV1StXDsLTgwKhKfnK4e2vGEiHBVFSXfvD1TUqTmI80B3OxDAQHh5MBAbBdPdEAJiMoXDP4lUtC8AuTwkXsWMH7r6McBZUVDgJw2+/1O/DXHb5SgB3RauiO6PNv5tTO6kq6tEhPY7XtMW053QCed+D9Sn2jo755Hp/Gcp3RX0UeWd45PpmBIpYREVELL8pzuNkSDqTT3HRUBYLhWOvwHUi1/A4OSPC86fYNwuX55UVIGb5qejiuNoE3M1QjTDavyQ9sTdApdnJ6ghJ816j9C/37SyPwPnWykglPlWnF6yye24Nl2Ti4DDTeAkcEZdoBoPjs+Mq4Scs/ppwMKOeBYHHE+Mrc/RSYLlLcmxSMHuEX541zC6rjdyamcMaqanWMzJK1vHkVGlytL39tVVfyREp7lQuOpfGxORGshNwAaSP45CwuTs5lEOqjW1tG1UHKTk5hygbVW1tqo2UQznZi7QBDskH/5fRBsrBtuwm5eMN+nuqhQsfqDbqUx43JXuvF3UVlbRKVvskJg76tEoKSkRdXuv/Ac1TXrzLIe3e8sPXeGhvBsRypxcazYwP7sHlG7sGvSNgDts/gDguK3hV1kqMCZFho6joZIo3yH3wfuywwOYk1A7F/a/aAmXoluBDYPaQmc43d9z+/u58O+OEiZXgud3JuS3af2lnr8I2x11p+mNJme3f/2V7c5l1s5F2cLS1TqZoSUMW3Hy9L+ASwa533trFrkH9MjLNjnYV5XYEtJOYbzgPWMqkdUl4k4pMDqVWqaij8Hj1lBRFYC2HFViToqwP5PHqApVKSs12On79hzd4/K8P6/HurtSPv/H4tx9dqfHeWXcyWqdaE88kNk81Z7iQZ69MXhFCXpSGydGv3WKIXi6MHtnFhY2TUudG+HtXNSLUfsZwJZRYMgZsgivAoksuDTc6mw2lZYDsypYVNji1lYYmo264MfHR5KT2vZHc8CiClBeWAvMPSgTTiSShhxCZ7IC/J/9e9htC+IyFXTPr8K7wLnhxDILXeGAbRprLwFZP5KAFxARWsAy6x2vFxDdTLBG+vOfL62pP8szyRMd9OHCXbuUersJSt89L8fpUTWkJeGOISdysv3wTmN16OxhvL6fHydtC1RZRl8UrqCu0+VvC83LlcR6jfA7cw5MJb/TwQNDDcE8Gf4Wj4yeemD/FZ9qh5zsgOC58C99lg45MKYTDJ6Px/8vAQV5sK28nQdJ7S8dv3Xl0YcRvB9saThD/1bEV5eVlu9Qu2VNcnU+ihFjB4xO1iXG5m8tf4KMG+Gn5PL8KTlFT8d4wqAkyGTWewQmq7klIm1dncwx8mLe//7rd6XwzA8E97iJDN4rbnfsjlMUpdv+ou4aCT8y+S1AbLV+UKrVxtIsYXj6MdtnkBxLEzG7nDYm5+yJR0wFnj8iz4BMG8dr6e6NuatBXp8599YlvXdAQh/2+hrqznLWUdXuLDDhnLB+ud9uyjKXB2Pd9OuejKup5goSS4nmtag4hOzG4+u2p6fwYMotAlPoOb2FGPEzzE3jTKD5sCkm0z5lrocwO+w/6dO6Hjf3FzCsTpL6/l5+R+kNvIXwy5/d4nPPHXSD8ryeJ41tWJB78gpGZzeoM58trXPUi0KMFa6bj/600szqGTc/QvSPOfFIyaDFlfOf7a6ozicfta+J6kuvTP5t37+NTubqotM9mO9QD6nHXFMARNlKXPWMyE+KbGuLjEhKeAxIT2ezGRjuZwTRnOB6X7N1eIg9B3mmJm7vmuFVZZj16jG146oumSbF+YbHHZItvOnXt+T83swTML9GXh44H03DXvHOjFrEPVx7qr8slbrmMYyBTCVV77jdAtpia9UDc1jY/znEgz+I1PjNHKzczcrP9Kslh7rGjDMJIAQLtxiMkk3l8klqUGNWQn7zYV0KUOcSheaVluO/qXwIDiJ+EaBE/wi9F4p9ClEQFylihXrEfeQHP13qjNdAY1+DmtqHVV77f1nB3tzUe437mZTkkr6AX1EXuLYEz93Htk2yWdnUVMRNcF8ogDjXVtPjedKrGvdCWUngoPSL3RrJATdI5RQq0+HiubwEnLKKiR/U2aqcJNjdJHR8hRm5EhtRHlUqmJdqKZcnuwhD+SFI+w/9wgEwmCNAsUTSTlIB4iM1kXZtWl7VYL9hNclb4swVef00Ey03ni4qvE9t0xWW3hO4rCYT3hCoLpcMwp3uHKdnOV5gfNJo3fcM2F5z7envkZ773HzZE02aCtKuCJ2TZHYiM899V6i/uA4Fe3pIQmhS1tBWY3bnL6C8ah47G1+btpjfW8feVK6mbtbVbeHmqtcwIGlid2Z8QMrPQ/KtPWLoXR+m9zFj9jEj7FAenUNO8aDx0eijPvYgukLnvl/+6MnlFfMQtV3diSe1S+63T5Wxtn58W9rUumsk8rIvWTsyth+cjT0lQ7oqBKzQma7oqbFNPf1SzEKEI5h+T9t50qg54kqVzE+n+lsY1d+2zMXzr2qsPt1U9r/xVbEA2xwDmCBbjPu3Ls30YVj0eyiWWhciOrHG897Th1+VfRyzZn5TyRr10+Zei0ZOpoPXr33ZqdCZOavmSt+qk1P3IWV3wEXXbKo4qbYDj3SFHdDql1K1KpamqYsr5Ig1Px1rM7ipCxLBjv52hThxZXF9wKO2nYnjadG5DzjZeTSfzRHUV60Rt+06euvZATlhqkGwyH0/O1JZu1+tLR7ULSndu1pdspxjvMa1X8n8Ir5a+zW7ovFTmCJs9wtSkarfZbn8GeRU5z4xAxApmxAhfQiziBk5AJOB412PhBF8x/CSW1+rr/sTX84u79ydP37k66GYx0s5nZQhSHkjlYwi4OymvwQhj74F/LHhqrC/udcqdLxt2+uzywf+WJ1wB/l/POMUy8yqjqDQra0IlEBJXlMy3WMi6dLr+OwoDEQ70gFAR5o6JfzxQxSHttcZThUMcL1w6Vf8yDg8uugRCcwomHhXz3R8Pfaho0fgiMwt3fy4U3f4sKJi6Uy+WyJlrK7VrGXL5eoYrMZdcxlxTWalktjZeSeWIf2/eOvo0KmdXELe48vqwtw6CrdI8+JhgTp7E/4aiG8cPtTpVZZ7s7Rzn53fPaOjypJRBCRhUPAl7afDVDg+7rf0mdGajjgOCvbWL5VaBM9tNCtu+bquWm+RezHaymlelSWfl3yrrrTwQ09mbfN6+bmFnhaWLtT0aqPjnHmHaU3qcFnutoeXfUi1kmWIl0TKjn4DzcPECr/S0TCGuVCxzyl5m77po0+XtlzcuWtr+SzupxV+Jez6gUyOH6iqP0pu9k+f/NF/odBuT3oSW0DFZDNfan995dbyP1V5VfeICVqjLhpnFig1Wsd3AmPoGaGtalhm2pLK23Ofr2Fuewd16nqHakxd98OTZEyAq2HWL5x0E6GYzTBXvCIc+JYthMCrlORQOSZDsgsLEZBM4zISR8TcR0wwGN6NQfX2/GdpbW7zwNNDxE2cPiqV7wAjvUzYHbYO3ZNFJ2QH2lfQs+pZg24Of735Dm89b5oNmlfJgXj4C2BI0y8cbzVwigPp48aClaGall8djX8/PHt4GT9+PZJh+Iwxk2xbgGvuThSLg6JCzLAjsk20HyTUOxkL54hiQs4FRjxm7wwHM7rYFgC+R99/vg9YR+Sjy3rUetk7Lk50fikL3o8jvjYL3wPeAyd0/D83vL/KgAvcsEjeBGSugRf/1Xeh+FPmfochHwXtWCAN/FwrdjyL/AAresyKwAvQAczLDUxSpjZyJPB2pyZzClcVl5/8aRWojZ4IaOH7AhPHlobm2+UxAk4jlZmYzseJa9P/ZRWojZyJPBzUB6ftl+B6pjZwJaiwllv8NAo33Kb/vvo9qvw1qdK9NgHHXZLgEX8mv32y2rI+z9CPK7SeD/GrEbFnrAtq3J3ZTKt6jzvB5/KkuXHPhuBtxDjNOmV5j1Kfxd3lE8qtYNGu21Aj+Hkh+pdCkfiqNHdjxh+pbxwQK6oPDwf7Bv43rc3818UBB/eD+ugVoT9vs5YC4aK46EhAXzlWzgDg1rGVAxnhA5DSVFLx2sp5Q037F9am/90CyXmWO+eKFcOPodxX69yOjoyIjwsNCQ96WODsOXZHFIaNEx3b3twkOL7OVEgYdcZO5zihM8RWAHRYNge6RomEYCkSqphO9NxBpbdVuh/23CQ8vs5xO08JhBgpSJIFPbHvp971sk2/VWgfhiOfTrIfD1WQoTxAYP6SOOFxGCgzue10KgEAMpOmEmYuI+96fYv9tIsXyPEZlMJ8AfpEJhQALoHk62Pci5m/lbiIc8ezUcTihkAPrWQfZPDTuXEnPrij9XiFVWVUB6Wh0ZXlauDNgn9RKMIcf5dAPEe0vNqI18CxSwcP47h79xE/fnp8dd9u+beqqSGOtpPCoO8fBtWsUdsMdPyyu1uYW1FPbDLQ2nbbdMgvEsVjV5mSAnGXKy7CysPzejkr4Tf1odQiJKnObV7vUwkgqM0sHU+tVhVP8IVKA8IYkZqyPUbYuKV8lcvltXUZa8FVO+f48TvqFn52Y/mwWhizTkECOmOyCC3KOQAn1FRESEWkXT7WXcS1bvodgRG0jzum6cXMs9NfT3e0i65wddtNQFcaezjG+oTjYh4PEcc6Ghh1al5WB0CbZ7ijDkLJXReYqb8tAdYwxiSrFmlCbU7WvpzaAlTsP6Qj7l1QEKXTgUbsImcLOCHaZLchMXZpvjbnxjmWN7L6UQw1Z5Or3qwcRjnhe/LyPqdNqknzZCA/6tsw9agRP4GkhgfJRij6Z/r6jTkn2L7Q9n47I3ORnzCBiA7RPyD1ETCJWJ6o+mSEqoHYZE4sYcgOZ+1RZdaMHrJ1h+U1i0HzLZpTc6Hf5iix55R2VbJINDXzO1k1tS5YAPxTyOGolSxAvNg4Wn5k1wCdjHEqI+2aqkSmG3TWnfbNjPj/RUD0N8WAau6pMucfs2mMjmOEeqTgo1Ewlq8JM8AWe8BJtcVgdICMbG2P/19izqLW7RTEknCAEiGQQaIpMAxFLI8V4i7nJ44Wb8Kl66aUnTIz2lUhhW6C0zSxUhsZLMhRkIL+v0Z4lJna2YD1IEJteAcFAMnA+2ALbmzbbiTnyXFnxWiI2XJA/5tEkmw2Ng2dIjji10rrpsgSCLplts5kYfLUF8pM+Ax1AYhLowL8fd3AqM3t2VUYY/atFhOJxghKvDunsqLvWQxNefbmUu91CB2AYjMXLm04OUPAr3BcSaPHVOHCjMG4cabvLxSxmahIQ8PCMEw3Gj7RKsvWuKsCnthzou45Hcnaw+ySTHQkXZXXuTyK9REYywfW2stuaIgvUQEycblAuVN3eGp9jiTG1wUgGAjzHOGboMW5+uDjbbqaxzEPlM8BMLoabhx1R1KjIBzKbm7TKarlNeJifyaVw1KMAbd3vuUww2MeQ00GivGmYR2LoerFngV3tt8mzkglJapBL7vWwPxvdU6htpK3zsRUWpWNGGdlcyIcnEISBBlByqcY1wsJvFqLEl94nDu8kVNNfyTEm65lue2jrNNbSoyvni6HT6W/ONfVOljfS8COeMI4TJdOQkwDBfk+EyTDY3mqoqm79JgWocFOiJzZferWXgmwrsxDhiOeOujlHeO/juxGBWZnpPixPTFSt9iYDhuNWe7HMhAJJeHeEwZfKhKR5NxanimgIspHsrxIB0Ga3GUOLJ6s5YtIONweAnAmgqWAQnG5YrDIzWV+pshoJhKgn9Nsc8PiTh/s8w3L9/f41eDbWs12+Y64s9DjqTugOV+qhYycQCw+eyKdmloQZUOoULMsmQF0Ewk0q4Ns9JDSWtKoWQPgDCV7G1zWQjU2lBHLtQtbM4tVpXw4c2NqNn2BaIl6/kFCDbgIaQ5ZT4SCD77GywMiiftRSHDiyAgtSwGnhGMSJm9MSCVGljMrz2FR+Ptq07DUxBHZhjAN1F+dBxDy1/P6nuqynSAHtAFv4wGwFCTBphHhwqiBaTWmbXZSh4k8SUnMAZ9DOWnLEUihD5xhEhgygSc0ouTJ4/f1h17dV4XsRMrgqPN6Bm6jJ/DMuwtuGVkuhyPMO0AMtBADH4iR4BALmzGNLsXbmSUIybeHy868nmf/lFOCfm9OXs5edrfHt9eVx3zVJ5LNl4ifwU1ncMHnKT1rU7L9ARhfyoyLjSKExeaajrNvsblI3NRfNqpovMUz4ls/WcgOumdkaWjasFsA+ca12/pw89DA4IeDodn7AsJcbxQtA7ZDRbNYeTILokhH7L4re1lBp6H6mi91zQEZeCYaeaRASWO3hF5Q78eHXxzj/YcF3GARYduE8Bv1oBYiG71VDBqkI0DV7p5/MHDvHY1I0zSYSHSDMZ7VMK/1aJl6nlxAkXWhzO99WHQliUchEBA5WcWFvj2T9dRxK/rYj2dVHmybuYjeX0gSwMco5Knbt+8pD0ZgJssP0J6o2lNNtn7G4fJf9ZVWDPiErGYKkBqXkdp9Y6h98to5gqPk0P/kCKwsHvXzfliINrAEaMEfaSewvQFCkS7wNnsejkSExexsHZTU2YqsIBwGJ82ydrsIGAMeJEZSyAOoGScS4lS9H6smhAcUxpbeeEr0DuPn9OA935omcrDntxps8DRVz21DRUAv1w/dnOIcLmuSMTbKs0sjJy1axMVgDGwdSyORmF0NvEpiMcilyV2xWde1W5HLigBRMcqT0Qz1IUrXhU8yBaBJrFPQy5NhKgNgw1+Wv6eDhFkRg6Mly8AOuREBynN0JCeJ5MiUQTSRRp0PAjT5Rt5ipMyepXm/BOtrUrARyB1AnWLVqy48V84xahllBGm+xEHcdvjBOl4Y7yRW0Qe4Xx4So4rd9yPxZFGqZBfgtomwscMKgW4diwySZGOQVeQRmcngrb2Evm5lEFyoHYQzX1bkXX2E6lQArD76Ugs4isaA7Ick0EAEhsZAM493vB77w0qR7RBdP5iQncQbFF3mmeJecIEOLP8M1vf8cAFd0USuw41sQiE5dXm9MLt2ocZBFeMDI8AEPnDGNyaSeipLtlz+eoJm1LkwsvJW29kL/qLOegDCCIZnvH0GezKmCbO5OiKdIq9vuaS1xKEHuZ5Ty2RDKEYGwPNTleQqGMJ41OwkwtRkh3d4HuHtX5kq481VMTtHc4iEzUtByvkhEsEokQd2WceYnToF/NTYCF3QQkCXhfnzRQXwRafSIh9dsPnda3mdiVY4gnGwn5VFBCqaJIqxoJVyEgjAi4LLuRweuXuoIL7EVZA/dQNYt1xFW00S3mLyVhu1qnws5G/XWyq+QYoQqdnxQlQEtno5RiAcaaw9fPP+zGQSQsCTR47+cFgMExGi8rIp6otaAMmgyZmrDRtB94CQIBZegLxwkqmtntGKkm31ZYnU7wDWhDJe8X+gCszpRn2bvfWHQgeVxa/mR21fuNNNOQKsESB1SRt0NzAlsFZSr9WTv/G8zbPNdliYRcwaCfizylWXqCZui0oHDFHRxqEE4ifpKlVq9bXcW6t1MHzN3Tq5VLS98BmQHaQ80IFpD5j6h4TfLPSyWb6faL9y0rpUbsrZUqnSbOKA9CLJB5Rt947bd2Po9fr26JDiQgllxSECkQHSCx6uM8RmCeZuYFclguA68eUEx9pamDs0eAiBRDNAppK9cLfXTFgIaVweAu1fXTtJk3wDdQ4EjNPUgwpJwDJ/oauqVLqQuvUDoVwC4xn3AnVjo7Kij7VnYdOG0bTLoLMzFghTQC8ebCWIC9Vde/5mt8yhDvGKUwRClX4AwgdNwcLN8HdYYoP2xn2XWx2miW/1+118MF1WRREqAb1bDeVA+xqDGll8otxTGx1KYad7/9ZOylnWfVFccTivWPEAdObxPzTJ5HV3TlBRYL6lm9NskkUh37Uwd5VJ4WVLNDvnexqggJUZfqJd2KbKq5DdumolGrN3qIRxKysadGyl1kFwg0KN+NksxS9OPgOLUmJ2NQzsdrKvMplyo2lZJ8gxonrRsxiJLjFENAlr+ykYwW02R/GqaRTWPLRT41oZOwtjGijS2ll3vt1n1gMBce8KyRh45HbItf/nXBeHWuyyR3GdugCSwk3osEoBZc2MHbWaGmN4H1Bo0eQa2MiBvQKywBjF6fC7CQHIZC+AaeHljhaU+qV734hb0MNQ1SNWNezjZs6czvdYVwu6uO2gedAPoUrZnlsxoFCS8CoMJDWeTck/iIEOHpUYWGm1eJZlRcaBKe6BQ1gAEGRmAsQwJCHQfGPG26PLG8scZX2+wbL1vtu02DsFz5zSw0vtgUCviAfawF/dO/Zma4bWqk/mmS0Gd2s5yYlkmBFWkXrCLXaNdeGvV2Pt58eWQOsCMtrujwKs1tjVYbpXYeFCGHUM2/j4AxMnwpy1ZQL8mPkgwZECslSpR20/sbTYHfFGm13NC3mPFLQcyQnia6K8HAL+fH9wf3u9s5eNYKOlRYlzpz7Sl7LFeW6TWP1/PtP3W4uR+HGmwt7ixS5dfH0fayIqGocTwUIjpit8AOljZTUU600VD/axwFLsCLMA1p1AMSlZKjV7OVXWwi3cwAGzDFqOOxTIRTgznWNYRa/mZ95j31B4t55IF1yHjNt8sw73Yz9xtjdONMzXNRWcXjmJbCPAtyppAbAnh66HCng1aXBqU5hnEWQLOk/zQd1HtjYIgAdAm1p71KXj8YvRfjhokzo7X8LNxdYeufyWoeX0NElxjDNrCiZtH+OImY++Ig65prpmZgS3R0roJjd6D61mfkvXN2RJkk0B/Am+TRR2BZeVfy/C74v+p1XPBDax0JvBFu3yAolVyDa9qOhGcj39ek0luztGouIlRXBMlz/PxqSC9Pv0FJwbaU40iJvKCkOAtvfb+RZxY6j+9zgviYnu1SAqS1061UQYl6wSv2CGX4P2VtwnHtPbv+b4AfdQ7fHzfVmUSKekzs7rc9Uesa4JtWdhxTehZze11xkb+1CM9KIYElLOxBhhIENAk6VBAtcScITvJFYETz8ytrpRP1JsqfiqKgp/oykJ16IhHN8BoHEPF+CXO8Ilf7B5zJP1U0xbG78bgqiKnJRFX0HrQBgxB3SUWgyabR13vAZbJI0iD1Kx0deanWvSpQ7CK4fEeRZUYF+tlpMJIxVFtrUIciK4+EoJDW2jXcUYSsTzKTnXoAQ+eUndEw0wD0yeBG6O5dO1dziHse9yvPK9VnhQxg0UkHCJ9QSI0wLzaxcpQOnmcd7dLoHoGRAkT+ZeufrFV40mIartXSKS7IaMfV3xy6EJnEQs7dIon9ITHtXohsNQH48zbE0iIBksON4btFSW3apYnNZ/BIGnumFjCIytMpHvgBUVTomzvJN+Qe1LJt0eRoT8BKxWmAoICR2sk43IhMsihpCk2XYkAIOvT3efmmpY6rQPkNxaybEYvbDvQMav5BnkIqPsUIZ4hJpXRX/oXEhUh38o83D7YLC9xqFZQtEWgELAtJPy1FDtIHKAFady/3v9eEsqexfkDhUic/aega8pcy/k4tvawoI8L6+g0SVQzDF/heptZwZpeug+xc9oO+a1E3xrbLjU7yfE0MSvKA6NNitqle+F1JAer8ixXSkGXXgwMxUMqv3JX6R75qPEO0B7JYYhxF+bjz+TgWW3o6WpTmDZx0JVujjMx3GJWAKPWJpzYPBDMcioueh/921qaxy2OUBfwVIvItCIovhPQluu5779zRRanMO0RG+r2rMrVemh1onPvY2HKxLDouoj0NOQNCOC/pdb6O98L0WcQvfINFR1xWL/4sB51xhZYz82or3l6ixgqWJtSM/o61z+scGU0AHZw0ycTq9zSDGvewidZ8mZRn1oS3z2rHM4gYJEgDrVis3s44N4QALe5+eH8qIVHB+/aCqT15nBA6sWy5hBToqxi4qq1USxaYSXFciVNAuaDm86umBVlSsO39wv1XORZcrwdfWpWp3GBU2CcWUQNVGWRIkm6hVckmtjukwG04KgkwxuPuXPs4Uy0HyjbeRWpC2FxX9SiIaUsUwOKVZROLJhbzRcOZLTqu6o8G3iioj8eK0Qa2UH123krik2KGbP3P5W5vN4chxMFJz49UY5fxyjC7R3ImWllikQ2IvkSVXfvqPFt2IfAXRkMLrd5eXXYDV2ZJ7Fu+s0MA1xOt8T8/HYWlbVjgo4/im4/UfV8VVWTIXSwVWoTu4p1kQ2R2tu2S7XKqLKtdTBxapyTuiCaet9BpI0S8dlmrSrSqXv5u4IFla0rdj1bJ2N6EjOe9A2a2rMSdYC1sa7QUaPIApYCzR6cja/lfyN47F+F58VGKJOtNQ6pejPr+c1g9KGmFQWasVuezMEssQqOooh40rIsaWNicpW7Rx9UlSB8Ik0+diokgZLCeeyEsfBxVYAySj7WWSL8XEHYoOU+u3rg8H3N3xv7IqvK1bW/fLH/62A0IkYjDa9iJaIu5V8pZBg6eKrOqUZfOSskVwS7/ioD/ISbbDJbQgo/QhC1xQM+Hfrn5f5ukcVHXTMmihpI1xQpuHu60SS3UIotC8QNhc6tDwQU2AUk788EYSXPZ5Bu2RkEB9jKtSaFsxoKMhUZXSZ9L/s8cMoFWbJArib3F9P2sNsO5+N5XY6Gw0TqtvaT2UeHM4Z8KHZsg7uHwqv7NALtPe7sxYMGsRf2J0CD98pc/+3szLqEIziTkRxe9x7YykTgPAZDVGe8ODLdL9tOOr4OeXI2DcA08Zf4Y7Xonl+cV52x8tg2bUT/6A5H75hdEc3akP/1Xc9hoz6qRfcp49c0qzzUB3agcJDnHa/bsfABnOegCZBECvMS6VFnfnuRFls44sPo93QRcp+VsKI72S6Fii+YOXBQUP33kPhnw4TF1XBn3YHrktc+ZGQYVprx9Wy8KTK95Wvt6gMGu29tmxS7enO4AfIC347Cx+P8/rDru7bJEiWYK7f679TlXei1mg1+NQgxcTAaJvoLF9DYx0dy2HRN1nQzQ9pJ5sjDSP78dYAFp6e6A0FqUJVU52aj/ntcCfuAEld9WGCWiRnp0ZiqvQsbClbN7YI3eKRyLhwfEGHSwVjwBhLYCrs91JtriONN5uqVw1vEWQuH7Is4eYovbefcWwBd9pouFqOXYJyrN/pnH4bm2i6a3G2ptkrltGspRGVHmcZoBCsMxVlLiMqXdg9mewBbd5oL7hyC7wY/Usyu3AC/kxsQWXUTG2hjCyHJN1CP5BVq6QIWkoNqC9k3wtP6jYpCYb5MBFScuxRF0kjLzG1JS0G4NAqpmWglQVCHMGJNlrV69JYUCg8b0fX+CE2uaQf+6Ed76L5/bnVgqOTvpw/345Dp2EXWxjGC7k3H6WPVPrQ+XKbM45OiL6XTsFFXU2+KCVeaWZvgNyss1ZRODA0elAl8P/YqgCVDHmqTMoUv7E6/+G4Gcgn71qw/1KgJA8IthsZz211ijO4Og4YLHrqaPz2btT+tr62uFKObq0vbRg80ibUwfkw/BDlrJ+9dXvCinLNEXJgGaqmZcqGGckt0Wcog7W8EwV5uk50okuLv3bzkEvYL60g0wsgE/qGGvZzxo+S+0Hhao9BHqtPwv7vjw93trjfvX54d6RDhP/r3Y1naQe+nzMMp8OuX6quv1Ib/A+5xZLNerTerM8M0TsN4ZkU2rCbRMGJt7KLZpr69Xr+fwldL70MdRsCOfolC4+ys1209h8LRdhAmYEuv7WpXdro+RzfiCgfFpq3N6NYsnnyX6biXvyjS1U+poqOiK3kqpP8uWx28Rukp1clAWqmwosnUuSRjgq0Km8QxgOh/TRvVLC+MSl2fogmcbEkbMGqrDjzSQgQXU7LMSKKekuhmnEM62nt+ygIbg9w8VSu7tetgsyLCJg1QoyAL94257X4c84CCzFeJEsNYbLbFSV6K3uX5qQnT1SSRCBbOB/joH6nbIY71rSJ/XHUn+SOwqFY6K1asoO44W2TTXca2/fFOuBqwslf0ftW7DXZciF3kXr5ZeJEW5zNMtvAMSzhnWMo5w4rOGVZ2zrC6Azbv41ZJ1fdyogad+S5DUkBFRs0PgCMsm9LX7MX+t5rvsaR+NGJO/XA1uuY1hIZqsExRUMRXrPOaNnTOHgt0/kBNncS8+70/oO5awZANq/peM/KGoMGZaU0EoprXEgilcJEmhkdeUShbmTURUHGOnjZVy0yXV3J2GfssEYHdHWgev12rmdvnc9eSFJtuSBR1QffypF6TOEjQaH9VIO1x8wt98QDY+gT3hJx0wyUGajOi4e1Hot2JRpX8QZk98Rm6YtuaqW2CPI5oIFpI/7ayhCSazrOYY0PGaDBNatqSzY3jPGbD67YuMiXQH8GbA+UtzRnGdewaiY7klZRlN5boQwHirrh1aT+Zqwnhgq2MTYGoSrJIibYtPlnmKNeJQN3t6ykSdfHur6E98firPx0D/Hp2fH1yvbeztjq+vbo4PWw3dan3cINn8FzVGinT9jlYSP2B3ODsVq1XVLdg3ZoapVGwZjusNVV0e5msIpgxu6Hy/kzJsJNnmERcLMDJj+ABJzRNrCkn1l+xQMY+rFZwu6wHVsD5uVWnzkZuAiGc9H1EE/lo4gKfHfzIPzHpjuSniCmkKBAY9TXsW/fZMNp49gYucw2DlQYHjRE8NMOaIvUa1/UnY9rLl6eQkezd+VpmmoZgcK61Rmi46B6SPI6P9pXgG7+C10VpJfXdxX8OAv07kCCM5uQPJ1wS25bV+tNX7dje0XU28g3YPLZaJasX0gK7SUgKYAAs0HWtUiFWUexDVCRqeMhErD68WWvQOO+O54Ps4TZn90+j06/0Y9JFYw5A5nIOsOkH5l+Ey6nymJOanqoseFtI2X4EUm/PljYubzcSkTi1oAEHoDUZbG67ZsJiyatoAqgKeSEj4dD67jSdbc7URXDY5Zq1NZCuzhQV6nVt8x7tJmGP73JBXWT70/p612NIAYHYDV3XKCPi17su/K8udCgQi2eilS264UZ/V0ree08ei9Lu0GpmhIVV1gUwOhBAsPBerwiK9KDAtzYiUNiUV6S4G0EOFN6L16SJ2HiZxc9XqfkOCTLnPHrKU4srrk4YY4JQDkeTnJlUuifh0kbChog4hskzZNZ0hLjlr6Gqj6+1KjEI8Ktwwp0aaW1iQXWXmu8Ahg5pX5ElRKqv5DcoKuwihmX0DksQ9AP3wzBAYPOV9YXFGBEaeC7GRpoHG+xq304cDhgih+nagRgfnLvHndfId/fHQwX+Eb2OXjtnh7vj3TQUWaRrsjc+0PdmUO5S60cK3JBGLozSuGRdTZ/SqW63+1ph9VdoO7bLRJ4B87c/mWGAVSOO1MavYh30rxk6AtVIHTuS9K5oCm4f7HfMESeuYSzwxBAHXfwX/BZMW4K1II7ORPOtxhUaL++LmICmcmKPoxXJQfOnkk+bO1ppBN63VlidYYEUxcjL4gbAYS1pQMla+1etz8SkKA5XP7uSt6ApX1AFEHB/YAKUaHGE6XkPCOlRNSNErgSIVi890USl3pZj+8mOjB6hb0ZDU1wUZsjc/NFcePYRjE6o6HcMBEASz9X73xCgXayHF99sJ3UWqcCtqCs1xMlp9rsKvBfKc3WK3xraC/MTvk3CMq/fXtA1w9fxn9kGB76Kn4iQIWTc4PX7DfigpmLx1+jY15eNHdRA7YxDuWgGymcLf/2AdxfJda8yqAEPHlpvQz/bUDF4RU1qg/eSS75m7+OKcdyPnep/aPjJ85mm23imwQG2cltoQhTBWeCGRe8OPGGUHUfVSWl8/2MfU/hijTdm2roqizyLtJLArAEnx5GuEQPuLk9LqNu6NJ1btdwYMjkH2en09us7ra+rQkyjLVMvDjE0aHyeC+CtdlujzFI2awIske/WDuVk9So7TptmzvsocqoLtl4kcz8tm0GemwBXpnVsoUCrobMt5Ly+uFhBFfdUpulUF8AUJ8l4c52SnpxoF9D0gpgacljScO+lAbqm0bnTccQAHHd0RhUk6pCbBoNlOcjCRIXFEUBrRlxyz41jQEPGlc01j22h4N2CadhqRPSvaM1QwONuVE/FF/rxRVJah2nNEILvgHBFobU4aZanBGPRkuSx5sycgrylKAfnYS+s0KRgnvWP0dYbigxglVRK4nTyLheuM4EfqxqE7CI1cwj/Qin1MXiykADoMY6/P3VbxqEW8V93na8A+GB96sfw6D8QGwzireof5jhGLBiPWjBsfnVBBVi6RyWMhz+ID+u/STZvcNR2MyA+d7ULNWcHj+XorIktcixHbfc1h5Tm0SfoKEJ+pKIdJ4lLslIfr8+rD6UeoGEzJIAcnEEIyZAGMTdtCgelKqAbOp6Y550HPxVijEXmjU0sHZGixi1Lswp65hH07NVJRIW9XcN9VFidlpbOTOCibaZojHxidRgeyFNMElzquYwxjWMR0yV7sR7HqGNtVT9zVlRIlXebehaXU84O1R0MiOvLkEJsVmjvB0Sr+sgknHIc5pxWUFmqJZAqAlqnUqw99y2flmvh8DkXmflKlac6KY3oGt59Hg8cvjh9gKa9mec+XPRI8/4URkghAlxYz8sOGWJXlVUD9CIYVqsfjf7FfdTXr8lPYEyJ7Rcco8PVfmxaD9yxgvsUMYgVdD6MQ+vtHVXQUQeF3sJdvqrPF9kv6Bt9hM9DlwjuPP4iLwjy81H1LB20NCAXQarWIayxrq6un5sIAoEnyGcHTYjpILgIML3y+c1E5AW98FSueWUIoDGQdStseV0dWT+bJehp4AlQJKrSfVREMaYDpheGyGfKJeUY0w2RUV8vQp003QidG6flmNWOy5CSZnWQDCnpsNmhd7zHiyY1j76+OF3ish8/dghNn7eXezjnLOeXcu302JKaVQLECOBHTcypmDKGQRAKcNP0nDEjgCVymDDKpYC2YZv3RTfigv90YwS/3cJEjK23MOVg5S3MSLD1eQhSdNDYBzhTxcecEmH8BpfLVEZ91CtyA1G5XpD0YkbPrb1DMTYhofSmxQjoivuyJMl2iPnkFCuCQkJE4o8iHEqybOUqbvuL+JBQqLKGcnl9xUpkQy9/6ZXVZZmyuZ+FWlqhikZPh56l+yrlS7/RtBpTNbWZFd65TGFQ1LhgywD+SEgBYZiMLTCr4m3mimNrFE+ZvPCX+SNQ5lAyZOVR21OKmpVFzVQ06Kghz4wTBwamdqWDwhabttbBMdIVynZJzNY5GETeGg8uKE5hVq4VPRPFFb2+eDxCZYmFSny9qcG3YLrhc9rYxcdYdzbk/D8CmCGDkfMD68HiznZJz13Sz57caw7M3PCAhzziMU94yjOOnLjlOS/OiMl8PdPfubUfuOPjuTGhoOn8mCp9M3t6F6WhoWNgYmHj4OLhExASiSE+ayY9wW1Ikkx69kx6ijunSpr03J8t02vfYSu90maxbmuN2FSYu5ot88VXPVbpcMJDn62zzf/+880Go846bacMmfpkOS/bGedcDnKv5di/Aq+4apdcnyxx03U35HnrvU4aavkKFSgypFipEmXKVaqgpfPGAtWq1KhTa8qwheo1aPTOBwfcMma32x64Y4+9Jkw6aZ9xM9ptd8RRh0rno2nHdsxq6ho0aop/Xh0e1ld+/zQ+vj4e2ps1/858adNH82q8fVisB7dmfXr7P21q36xtSn/59/enpe0fEFvsg/jXZkbjv9/FEW5Y8enr60n9tyaPd5BoExT6yeoI7WyE97+l3/XH009Pps2yK7rdlbP6a127O8KX1KLueL5ZOjXJHQAA)
                    format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }

            /*savepage-import-url=bootstrap/bootstrap.min.css*/
            @charset "UTF-8"; /*!
 * Bootstrap v5.1.0 (https://getbootstrap.com/)
 * Copyright 2011-2021 The Bootstrap Authors
 * Copyright 2011-2021 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
            :root {
                --bs-blue: #0d6efd;
                --bs-indigo: #6610f2;
                --bs-purple: #6f42c1;
                --bs-pink: #d63384;
                --bs-red: #dc3545;
                --bs-orange: #fd7e14;
                --bs-yellow: #ffc107;
                --bs-green: #198754;
                --bs-teal: #20c997;
                --bs-cyan: #0dcaf0;
                --bs-white: #fff;
                --bs-gray: #6c757d;
                --bs-gray-dark: #343a40;
                --bs-gray-100: #f8f9fa;
                --bs-gray-200: #e9ecef;
                --bs-gray-300: #dee2e6;
                --bs-gray-400: #ced4da;
                --bs-gray-500: #adb5bd;
                --bs-gray-600: #6c757d;
                --bs-gray-700: #495057;
                --bs-gray-800: #343a40;
                --bs-gray-900: #212529;
                --bs-primary: #0d6efd;
                --bs-secondary: #6c757d;
                --bs-success: #198754;
                --bs-info: #0dcaf0;
                --bs-warning: #ffc107;
                --bs-danger: #dc3545;
                --bs-light: #f8f9fa;
                --bs-dark: #212529;
                --bs-primary-rgb: 13, 110, 253;
                --bs-secondary-rgb: 108, 117, 125;
                --bs-success-rgb: 25, 135, 84;
                --bs-info-rgb: 13, 202, 240;
                --bs-warning-rgb: 255, 193, 7;
                --bs-danger-rgb: 220, 53, 69;
                --bs-light-rgb: 248, 249, 250;
                --bs-dark-rgb: 33, 37, 41;
                --bs-white-rgb: 255, 255, 255;
                --bs-black-rgb: 0, 0, 0;
                --bs-body-rgb: 33, 37, 41;
                --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans",
                    "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol",
                    "Noto Color Emoji";
                --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New",
                    monospace;
                --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
                --bs-body-font-family: var(--bs-font-sans-serif);
                --bs-body-font-size: 1rem;
                --bs-body-font-weight: 400;
                --bs-body-line-height: 1.5;
                --bs-body-color: #212529;
                --bs-body-bg: #fff;
            }
            *,
            ::after,
            ::before {
                box-sizing: border-box;
            }
            @media (prefers-reduced-motion: no-preference) {
                :root {
                    scroll-behavior: smooth;
                }
            }
            body {
                margin: 0;
                font-family: var(--bs-body-font-family);
                font-size: var(--bs-body-font-size);
                font-weight: var(--bs-body-font-weight);
                line-height: var(--bs-body-line-height);
                color: var(--bs-body-color);
                text-align: var(--bs-body-text-align);
                background-color: var(--bs-body-bg);
                -webkit-text-size-adjust: 100%;
                -webkit-tap-highlight-color: transparent;
            }
            hr {
                margin: 1rem 0;
                color: inherit;
                background-color: currentColor;
                border: 0;
                opacity: 0.25;
            }
            hr:not([size]) {
                height: 1px;
            }
            .h1,
            .h2,
            .h3,
            .h4,
            .h5,
            .h6,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                margin-top: 0;
                margin-bottom: 0.5rem;
                font-weight: 500;
                line-height: 1.2;
            }
            .h1,
            h1 {
                font-size: calc(1.375rem + 1.5vw);
            }
            @media (min-width: 1200px) {
                .h1,
                h1 {
                    font-size: 2.5rem;
                }
            }
            .h2,
            h2 {
                font-size: calc(1.325rem + 0.9vw);
            }
            @media (min-width: 1200px) {
                .h2,
                h2 {
                    font-size: 2rem;
                }
            }
            .h3,
            h3 {
                font-size: calc(1.3rem + 0.6vw);
            }
            @media (min-width: 1200px) {
                .h3,
                h3 {
                    font-size: 1.75rem;
                }
            }
            .h4,
            h4 {
                font-size: calc(1.275rem + 0.3vw);
            }
            @media (min-width: 1200px) {
                .h4,
                h4 {
                    font-size: 1.5rem;
                }
            }
            .h5,
            h5 {
                font-size: 1.25rem;
            }
            .h6,
            h6 {
                font-size: 1rem;
            }
            p {
                margin-top: 0;
                margin-bottom: 1rem;
            }
            abbr[data-bs-original-title],
            abbr[title] {
                -webkit-text-decoration: underline dotted;
                text-decoration: underline dotted;
                cursor: help;
                -webkit-text-decoration-skip-ink: none;
                text-decoration-skip-ink: none;
            }
            address {
                margin-bottom: 1rem;
                font-style: normal;
                line-height: inherit;
            }
            ol,
            ul {
                padding-left: 2rem;
            }
            dl,
            ol,
            ul {
                margin-top: 0;
                margin-bottom: 1rem;
            }
            ol ol,
            ol ul,
            ul ol,
            ul ul {
                margin-bottom: 0;
            }
            dt {
                font-weight: 700;
            }
            dd {
                margin-bottom: 0.5rem;
                margin-left: 0;
            }
            blockquote {
                margin: 0 0 1rem;
            }
            b,
            strong {
                font-weight: bolder;
            }
            .small,
            small {
                font-size: 0.875em;
            }
            .mark,
            mark {
                padding: 0.2em;
                background-color: #fcf8e3;
            }
            sub,
            sup {
                position: relative;
                font-size: 0.75em;
                line-height: 0;
                vertical-align: baseline;
            }
            sub {
                bottom: -0.25em;
            }
            sup {
                top: -0.5em;
            }
            a {
                color: #0d6efd;
                text-decoration: underline;
            }
            a:hover {
                color: #0a58ca;
            }
            a:not([href]):not([class]),
            a:not([href]):not([class]):hover {
                color: inherit;
                text-decoration: none;
            }
            code,
            kbd,
            pre,
            samp {
                font-family: var(--bs-font-monospace);
                font-size: 1em;
                direction: ltr;
                unicode-bidi: bidi-override;
            }
            pre {
                display: block;
                margin-top: 0;
                margin-bottom: 1rem;
                overflow: auto;
                font-size: 0.875em;
            }
            pre code {
                font-size: inherit;
                color: inherit;
                word-break: normal;
            }
            code {
                font-size: 0.875em;
                color: #d63384;
                word-wrap: break-word;
            }
            a > code {
                color: inherit;
            }
            kbd {
                padding: 0.2rem 0.4rem;
                font-size: 0.875em;
                color: #fff;
                background-color: #212529;
                border-radius: 0.2rem;
            }
            kbd kbd {
                padding: 0;
                font-size: 1em;
                font-weight: 700;
            }
            figure {
                margin: 0 0 1rem;
            }
            img,
            svg {
                vertical-align: middle;
            }
            table {
                caption-side: bottom;
                border-collapse: collapse;
            }
            caption {
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
                color: #6c757d;
                text-align: left;
            }
            th {
                text-align: inherit;
                text-align: -webkit-match-parent;
            }
            tbody,
            td,
            tfoot,
            th,
            thead,
            tr {
                border-color: inherit;
                border-style: solid;
                border-width: 0;
            }
            label {
                display: inline-block;
            }
            button {
                border-radius: 0;
            }
            button:focus:not(:focus-visible) {
                outline: 0;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                margin: 0;
                font-family: inherit;
                font-size: inherit;
                line-height: inherit;
            }
            button,
            select {
                text-transform: none;
            }
            [role="button"] {
                cursor: pointer;
            }
            select {
                word-wrap: normal;
            }
            select:disabled {
                opacity: 1;
            }
            [list]::-webkit-calendar-picker-indicator {
                display: none;
            }
            [type="button"],
            [type="reset"],
            [type="submit"],
            button {
                -webkit-appearance: button;
            }
            [type="button"]:not(:disabled),
            [type="reset"]:not(:disabled),
            [type="submit"]:not(:disabled),
            button:not(:disabled) {
                cursor: pointer;
            }
            ::-moz-focus-inner {
                padding: 0;
                border-style: none;
            }
            textarea {
                resize: vertical;
            }
            fieldset {
                min-width: 0;
                padding: 0;
                margin: 0;
                border: 0;
            }
            legend {
                float: left;
                width: 100%;
                padding: 0;
                margin-bottom: 0.5rem;
                font-size: calc(1.275rem + 0.3vw);
                line-height: inherit;
            }
            @media (min-width: 1200px) {
                legend {
                    font-size: 1.5rem;
                }
            }
            legend + * {
                clear: left;
            }
            ::-webkit-datetime-edit-day-field,
            ::-webkit-datetime-edit-fields-wrapper,
            ::-webkit-datetime-edit-hour-field,
            ::-webkit-datetime-edit-minute,
            ::-webkit-datetime-edit-month-field,
            ::-webkit-datetime-edit-text,
            ::-webkit-datetime-edit-year-field {
                padding: 0;
            }
            ::-webkit-inner-spin-button {
                height: auto;
            }
            [type="search"] {
                outline-offset: -2px;
                -webkit-appearance: textfield;
            }
            ::-webkit-search-decoration {
                -webkit-appearance: none;
            }
            ::-webkit-color-swatch-wrapper {
                padding: 0;
            }
            ::file-selector-button {
                font: inherit;
            }
            ::-webkit-file-upload-button {
                font: inherit;
                -webkit-appearance: button;
            }
            output {
                display: inline-block;
            }
            iframe {
                border: 0;
            }
            summary {
                display: list-item;
                cursor: pointer;
            }
            progress {
                vertical-align: baseline;
            }
            [hidden] {
                display: none !important;
            }
            .lead {
                font-size: 1.25rem;
                font-weight: 300;
            }
            .display-1 {
                font-size: calc(1.625rem + 4.5vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-1 {
                    font-size: 5rem;
                }
            }
            .display-2 {
                font-size: calc(1.575rem + 3.9vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-2 {
                    font-size: 4.5rem;
                }
            }
            .display-3 {
                font-size: calc(1.525rem + 3.3vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-3 {
                    font-size: 4rem;
                }
            }
            .display-4 {
                font-size: calc(1.475rem + 2.7vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-4 {
                    font-size: 3.5rem;
                }
            }
            .display-5 {
                font-size: calc(1.425rem + 2.1vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-5 {
                    font-size: 3rem;
                }
            }
            .display-6 {
                font-size: calc(1.375rem + 1.5vw);
                font-weight: 300;
                line-height: 1.2;
            }
            @media (min-width: 1200px) {
                .display-6 {
                    font-size: 2.5rem;
                }
            }
            .list-unstyled {
                padding-left: 0;
                list-style: none;
            }
            .list-inline {
                padding-left: 0;
                list-style: none;
            }
            .list-inline-item {
                display: inline-block;
            }
            .list-inline-item:not(:last-child) {
                margin-right: 0.5rem;
            }
            .initialism {
                font-size: 0.875em;
                text-transform: uppercase;
            }
            .blockquote {
                margin-bottom: 1rem;
                font-size: 1.25rem;
            }
            .blockquote > :last-child {
                margin-bottom: 0;
            }
            .blockquote-footer {
                margin-top: -1rem;
                margin-bottom: 1rem;
                font-size: 0.875em;
                color: #6c757d;
            }
            .blockquote-footer::before {
                content: "— ";
            }
            .img-fluid {
                max-width: 100%;
                height: auto;
            }
            .img-thumbnail {
                padding: 0.25rem;
                background-color: #fff;
                border: 1px solid #dee2e6;
                border-radius: 0.25rem;
                max-width: 100%;
                height: auto;
            }
            .figure {
                display: inline-block;
            }
            .figure-img {
                margin-bottom: 0.5rem;
                line-height: 1;
            }
            .figure-caption {
                font-size: 0.875em;
                color: #6c757d;
            }
            .container,
            .container-fluid,
            .container-lg,
            .container-md,
            .container-sm,
            .container-xl,
            .container-xxl {
                width: 100%;
                padding-right: var(--bs-gutter-x, 0.75rem);
                padding-left: var(--bs-gutter-x, 0.75rem);
                margin-right: auto;
                margin-left: auto;
            }
            @media (min-width: 576px) {
                .container,
                .container-sm {
                    max-width: 540px;
                }
            }
            @media (min-width: 768px) {
                .container,
                .container-md,
                .container-sm {
                    max-width: 720px;
                }
            }
            @media (min-width: 992px) {
                .container,
                .container-lg,
                .container-md,
                .container-sm {
                    max-width: 960px;
                }
            }
            @media (min-width: 1200px) {
                .container,
                .container-lg,
                .container-md,
                .container-sm,
                .container-xl {
                    max-width: 1140px;
                }
            }
            @media (min-width: 1400px) {
                .container,
                .container-lg,
                .container-md,
                .container-sm,
                .container-xl,
                .container-xxl {
                    max-width: 1320px;
                }
            }
            .row {
                --bs-gutter-x: 1.5rem;
                --bs-gutter-y: 0;
                display: flex;
                flex-wrap: wrap;
                margin-top: calc(var(--bs-gutter-y) * -1);
                margin-right: calc(var(--bs-gutter-x) * -0.5);
                margin-left: calc(var(--bs-gutter-x) * -0.5);
            }
            .row > * {
                flex-shrink: 0;
                width: 100%;
                max-width: 100%;
                padding-right: calc(var(--bs-gutter-x) * 0.5);
                padding-left: calc(var(--bs-gutter-x) * 0.5);
                margin-top: var(--bs-gutter-y);
            }
            .col {
                flex: 1 0 0%;
            }
            .row-cols-auto > * {
                flex: 0 0 auto;
                width: auto;
            }
            .row-cols-1 > * {
                flex: 0 0 auto;
                width: 100%;
            }
            .row-cols-2 > * {
                flex: 0 0 auto;
                width: 50%;
            }
            .row-cols-3 > * {
                flex: 0 0 auto;
                width: 33.3333333333%;
            }
            .row-cols-4 > * {
                flex: 0 0 auto;
                width: 25%;
            }
            .row-cols-5 > * {
                flex: 0 0 auto;
                width: 20%;
            }
            .row-cols-6 > * {
                flex: 0 0 auto;
                width: 16.6666666667%;
            }
            .col-auto {
                flex: 0 0 auto;
                width: auto;
            }
            .col-1 {
                flex: 0 0 auto;
                width: 8.33333333%;
            }
            .col-2 {
                flex: 0 0 auto;
                width: 16.66666667%;
            }
            .col-3 {
                flex: 0 0 auto;
                width: 25%;
            }
            .col-4 {
                flex: 0 0 auto;
                width: 33.33333333%;
            }
            .col-5 {
                flex: 0 0 auto;
                width: 41.66666667%;
            }
            .col-6 {
                flex: 0 0 auto;
                width: 50%;
            }
            .col-7 {
                flex: 0 0 auto;
                width: 58.33333333%;
            }
            .col-8 {
                flex: 0 0 auto;
                width: 66.66666667%;
            }
            .col-9 {
                flex: 0 0 auto;
                width: 75%;
            }
            .col-10 {
                flex: 0 0 auto;
                width: 83.33333333%;
            }
            .col-11 {
                flex: 0 0 auto;
                width: 91.66666667%;
            }
            .col-12 {
                flex: 0 0 auto;
                width: 100%;
            }
            .offset-1 {
                margin-left: 8.33333333%;
            }
            .offset-2 {
                margin-left: 16.66666667%;
            }
            .offset-3 {
                margin-left: 25%;
            }
            .offset-4 {
                margin-left: 33.33333333%;
            }
            .offset-5 {
                margin-left: 41.66666667%;
            }
            .offset-6 {
                margin-left: 50%;
            }
            .offset-7 {
                margin-left: 58.33333333%;
            }
            .offset-8 {
                margin-left: 66.66666667%;
            }
            .offset-9 {
                margin-left: 75%;
            }
            .offset-10 {
                margin-left: 83.33333333%;
            }
            .offset-11 {
                margin-left: 91.66666667%;
            }
            .g-0,
            .gx-0 {
                --bs-gutter-x: 0;
            }
            .g-0,
            .gy-0 {
                --bs-gutter-y: 0;
            }
            .g-1,
            .gx-1 {
                --bs-gutter-x: 0.25rem;
            }
            .g-1,
            .gy-1 {
                --bs-gutter-y: 0.25rem;
            }
            .g-2,
            .gx-2 {
                --bs-gutter-x: 0.5rem;
            }
            .g-2,
            .gy-2 {
                --bs-gutter-y: 0.5rem;
            }
            .g-3,
            .gx-3 {
                --bs-gutter-x: 1rem;
            }
            .g-3,
            .gy-3 {
                --bs-gutter-y: 1rem;
            }
            .g-4,
            .gx-4 {
                --bs-gutter-x: 1.5rem;
            }
            .g-4,
            .gy-4 {
                --bs-gutter-y: 1.5rem;
            }
            .g-5,
            .gx-5 {
                --bs-gutter-x: 3rem;
            }
            .g-5,
            .gy-5 {
                --bs-gutter-y: 3rem;
            }
            @media (min-width: 576px) {
                .col-sm {
                    flex: 1 0 0%;
                }
                .row-cols-sm-auto > * {
                    flex: 0 0 auto;
                    width: auto;
                }
                .row-cols-sm-1 > * {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .row-cols-sm-2 > * {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .row-cols-sm-3 > * {
                    flex: 0 0 auto;
                    width: 33.3333333333%;
                }
                .row-cols-sm-4 > * {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .row-cols-sm-5 > * {
                    flex: 0 0 auto;
                    width: 20%;
                }
                .row-cols-sm-6 > * {
                    flex: 0 0 auto;
                    width: 16.6666666667%;
                }
                .col-sm-auto {
                    flex: 0 0 auto;
                    width: auto;
                }
                .col-sm-1 {
                    flex: 0 0 auto;
                    width: 8.33333333%;
                }
                .col-sm-2 {
                    flex: 0 0 auto;
                    width: 16.66666667%;
                }
                .col-sm-3 {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .col-sm-4 {
                    flex: 0 0 auto;
                    width: 33.33333333%;
                }
                .col-sm-5 {
                    flex: 0 0 auto;
                    width: 41.66666667%;
                }
                .col-sm-6 {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .col-sm-7 {
                    flex: 0 0 auto;
                    width: 58.33333333%;
                }
                .col-sm-8 {
                    flex: 0 0 auto;
                    width: 66.66666667%;
                }
                .col-sm-9 {
                    flex: 0 0 auto;
                    width: 75%;
                }
                .col-sm-10 {
                    flex: 0 0 auto;
                    width: 83.33333333%;
                }
                .col-sm-11 {
                    flex: 0 0 auto;
                    width: 91.66666667%;
                }
                .col-sm-12 {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .offset-sm-0 {
                    margin-left: 0;
                }
                .offset-sm-1 {
                    margin-left: 8.33333333%;
                }
                .offset-sm-2 {
                    margin-left: 16.66666667%;
                }
                .offset-sm-3 {
                    margin-left: 25%;
                }
                .offset-sm-4 {
                    margin-left: 33.33333333%;
                }
                .offset-sm-5 {
                    margin-left: 41.66666667%;
                }
                .offset-sm-6 {
                    margin-left: 50%;
                }
                .offset-sm-7 {
                    margin-left: 58.33333333%;
                }
                .offset-sm-8 {
                    margin-left: 66.66666667%;
                }
                .offset-sm-9 {
                    margin-left: 75%;
                }
                .offset-sm-10 {
                    margin-left: 83.33333333%;
                }
                .offset-sm-11 {
                    margin-left: 91.66666667%;
                }
                .g-sm-0,
                .gx-sm-0 {
                    --bs-gutter-x: 0;
                }
                .g-sm-0,
                .gy-sm-0 {
                    --bs-gutter-y: 0;
                }
                .g-sm-1,
                .gx-sm-1 {
                    --bs-gutter-x: 0.25rem;
                }
                .g-sm-1,
                .gy-sm-1 {
                    --bs-gutter-y: 0.25rem;
                }
                .g-sm-2,
                .gx-sm-2 {
                    --bs-gutter-x: 0.5rem;
                }
                .g-sm-2,
                .gy-sm-2 {
                    --bs-gutter-y: 0.5rem;
                }
                .g-sm-3,
                .gx-sm-3 {
                    --bs-gutter-x: 1rem;
                }
                .g-sm-3,
                .gy-sm-3 {
                    --bs-gutter-y: 1rem;
                }
                .g-sm-4,
                .gx-sm-4 {
                    --bs-gutter-x: 1.5rem;
                }
                .g-sm-4,
                .gy-sm-4 {
                    --bs-gutter-y: 1.5rem;
                }
                .g-sm-5,
                .gx-sm-5 {
                    --bs-gutter-x: 3rem;
                }
                .g-sm-5,
                .gy-sm-5 {
                    --bs-gutter-y: 3rem;
                }
            }
            @media (min-width: 768px) {
                .col-md {
                    flex: 1 0 0%;
                }
                .row-cols-md-auto > * {
                    flex: 0 0 auto;
                    width: auto;
                }
                .row-cols-md-1 > * {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .row-cols-md-2 > * {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .row-cols-md-3 > * {
                    flex: 0 0 auto;
                    width: 33.3333333333%;
                }
                .row-cols-md-4 > * {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .row-cols-md-5 > * {
                    flex: 0 0 auto;
                    width: 20%;
                }
                .row-cols-md-6 > * {
                    flex: 0 0 auto;
                    width: 16.6666666667%;
                }
                .col-md-auto {
                    flex: 0 0 auto;
                    width: auto;
                }
                .col-md-1 {
                    flex: 0 0 auto;
                    width: 8.33333333%;
                }
                .col-md-2 {
                    flex: 0 0 auto;
                    width: 16.66666667%;
                }
                .col-md-3 {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .col-md-4 {
                    flex: 0 0 auto;
                    width: 33.33333333%;
                }
                .col-md-5 {
                    flex: 0 0 auto;
                    width: 41.66666667%;
                }
                .col-md-6 {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .col-md-7 {
                    flex: 0 0 auto;
                    width: 58.33333333%;
                }
                .col-md-8 {
                    flex: 0 0 auto;
                    width: 66.66666667%;
                }
                .col-md-9 {
                    flex: 0 0 auto;
                    width: 75%;
                }
                .col-md-10 {
                    flex: 0 0 auto;
                    width: 83.33333333%;
                }
                .col-md-11 {
                    flex: 0 0 auto;
                    width: 91.66666667%;
                }
                .col-md-12 {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .offset-md-0 {
                    margin-left: 0;
                }
                .offset-md-1 {
                    margin-left: 8.33333333%;
                }
                .offset-md-2 {
                    margin-left: 16.66666667%;
                }
                .offset-md-3 {
                    margin-left: 25%;
                }
                .offset-md-4 {
                    margin-left: 33.33333333%;
                }
                .offset-md-5 {
                    margin-left: 41.66666667%;
                }
                .offset-md-6 {
                    margin-left: 50%;
                }
                .offset-md-7 {
                    margin-left: 58.33333333%;
                }
                .offset-md-8 {
                    margin-left: 66.66666667%;
                }
                .offset-md-9 {
                    margin-left: 75%;
                }
                .offset-md-10 {
                    margin-left: 83.33333333%;
                }
                .offset-md-11 {
                    margin-left: 91.66666667%;
                }
                .g-md-0,
                .gx-md-0 {
                    --bs-gutter-x: 0;
                }
                .g-md-0,
                .gy-md-0 {
                    --bs-gutter-y: 0;
                }
                .g-md-1,
                .gx-md-1 {
                    --bs-gutter-x: 0.25rem;
                }
                .g-md-1,
                .gy-md-1 {
                    --bs-gutter-y: 0.25rem;
                }
                .g-md-2,
                .gx-md-2 {
                    --bs-gutter-x: 0.5rem;
                }
                .g-md-2,
                .gy-md-2 {
                    --bs-gutter-y: 0.5rem;
                }
                .g-md-3,
                .gx-md-3 {
                    --bs-gutter-x: 1rem;
                }
                .g-md-3,
                .gy-md-3 {
                    --bs-gutter-y: 1rem;
                }
                .g-md-4,
                .gx-md-4 {
                    --bs-gutter-x: 1.5rem;
                }
                .g-md-4,
                .gy-md-4 {
                    --bs-gutter-y: 1.5rem;
                }
                .g-md-5,
                .gx-md-5 {
                    --bs-gutter-x: 3rem;
                }
                .g-md-5,
                .gy-md-5 {
                    --bs-gutter-y: 3rem;
                }
            }
            @media (min-width: 992px) {
                .col-lg {
                    flex: 1 0 0%;
                }
                .row-cols-lg-auto > * {
                    flex: 0 0 auto;
                    width: auto;
                }
                .row-cols-lg-1 > * {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .row-cols-lg-2 > * {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .row-cols-lg-3 > * {
                    flex: 0 0 auto;
                    width: 33.3333333333%;
                }
                .row-cols-lg-4 > * {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .row-cols-lg-5 > * {
                    flex: 0 0 auto;
                    width: 20%;
                }
                .row-cols-lg-6 > * {
                    flex: 0 0 auto;
                    width: 16.6666666667%;
                }
                .col-lg-auto {
                    flex: 0 0 auto;
                    width: auto;
                }
                .col-lg-1 {
                    flex: 0 0 auto;
                    width: 8.33333333%;
                }
                .col-lg-2 {
                    flex: 0 0 auto;
                    width: 16.66666667%;
                }
                .col-lg-3 {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .col-lg-4 {
                    flex: 0 0 auto;
                    width: 33.33333333%;
                }
                .col-lg-5 {
                    flex: 0 0 auto;
                    width: 41.66666667%;
                }
                .col-lg-6 {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .col-lg-7 {
                    flex: 0 0 auto;
                    width: 58.33333333%;
                }
                .col-lg-8 {
                    flex: 0 0 auto;
                    width: 66.66666667%;
                }
                .col-lg-9 {
                    flex: 0 0 auto;
                    width: 75%;
                }
                .col-lg-10 {
                    flex: 0 0 auto;
                    width: 83.33333333%;
                }
                .col-lg-11 {
                    flex: 0 0 auto;
                    width: 91.66666667%;
                }
                .col-lg-12 {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .offset-lg-0 {
                    margin-left: 0;
                }
                .offset-lg-1 {
                    margin-left: 8.33333333%;
                }
                .offset-lg-2 {
                    margin-left: 16.66666667%;
                }
                .offset-lg-3 {
                    margin-left: 25%;
                }
                .offset-lg-4 {
                    margin-left: 33.33333333%;
                }
                .offset-lg-5 {
                    margin-left: 41.66666667%;
                }
                .offset-lg-6 {
                    margin-left: 50%;
                }
                .offset-lg-7 {
                    margin-left: 58.33333333%;
                }
                .offset-lg-8 {
                    margin-left: 66.66666667%;
                }
                .offset-lg-9 {
                    margin-left: 75%;
                }
                .offset-lg-10 {
                    margin-left: 83.33333333%;
                }
                .offset-lg-11 {
                    margin-left: 91.66666667%;
                }
                .g-lg-0,
                .gx-lg-0 {
                    --bs-gutter-x: 0;
                }
                .g-lg-0,
                .gy-lg-0 {
                    --bs-gutter-y: 0;
                }
                .g-lg-1,
                .gx-lg-1 {
                    --bs-gutter-x: 0.25rem;
                }
                .g-lg-1,
                .gy-lg-1 {
                    --bs-gutter-y: 0.25rem;
                }
                .g-lg-2,
                .gx-lg-2 {
                    --bs-gutter-x: 0.5rem;
                }
                .g-lg-2,
                .gy-lg-2 {
                    --bs-gutter-y: 0.5rem;
                }
                .g-lg-3,
                .gx-lg-3 {
                    --bs-gutter-x: 1rem;
                }
                .g-lg-3,
                .gy-lg-3 {
                    --bs-gutter-y: 1rem;
                }
                .g-lg-4,
                .gx-lg-4 {
                    --bs-gutter-x: 1.5rem;
                }
                .g-lg-4,
                .gy-lg-4 {
                    --bs-gutter-y: 1.5rem;
                }
                .g-lg-5,
                .gx-lg-5 {
                    --bs-gutter-x: 3rem;
                }
                .g-lg-5,
                .gy-lg-5 {
                    --bs-gutter-y: 3rem;
                }
            }
            @media (min-width: 1200px) {
                .col-xl {
                    flex: 1 0 0%;
                }
                .row-cols-xl-auto > * {
                    flex: 0 0 auto;
                    width: auto;
                }
                .row-cols-xl-1 > * {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .row-cols-xl-2 > * {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .row-cols-xl-3 > * {
                    flex: 0 0 auto;
                    width: 33.3333333333%;
                }
                .row-cols-xl-4 > * {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .row-cols-xl-5 > * {
                    flex: 0 0 auto;
                    width: 20%;
                }
                .row-cols-xl-6 > * {
                    flex: 0 0 auto;
                    width: 16.6666666667%;
                }
                .col-xl-auto {
                    flex: 0 0 auto;
                    width: auto;
                }
                .col-xl-1 {
                    flex: 0 0 auto;
                    width: 8.33333333%;
                }
                .col-xl-2 {
                    flex: 0 0 auto;
                    width: 16.66666667%;
                }
                .col-xl-3 {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .col-xl-4 {
                    flex: 0 0 auto;
                    width: 33.33333333%;
                }
                .col-xl-5 {
                    flex: 0 0 auto;
                    width: 41.66666667%;
                }
                .col-xl-6 {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .col-xl-7 {
                    flex: 0 0 auto;
                    width: 58.33333333%;
                }
                .col-xl-8 {
                    flex: 0 0 auto;
                    width: 66.66666667%;
                }
                .col-xl-9 {
                    flex: 0 0 auto;
                    width: 75%;
                }
                .col-xl-10 {
                    flex: 0 0 auto;
                    width: 83.33333333%;
                }
                .col-xl-11 {
                    flex: 0 0 auto;
                    width: 91.66666667%;
                }
                .col-xl-12 {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .offset-xl-0 {
                    margin-left: 0;
                }
                .offset-xl-1 {
                    margin-left: 8.33333333%;
                }
                .offset-xl-2 {
                    margin-left: 16.66666667%;
                }
                .offset-xl-3 {
                    margin-left: 25%;
                }
                .offset-xl-4 {
                    margin-left: 33.33333333%;
                }
                .offset-xl-5 {
                    margin-left: 41.66666667%;
                }
                .offset-xl-6 {
                    margin-left: 50%;
                }
                .offset-xl-7 {
                    margin-left: 58.33333333%;
                }
                .offset-xl-8 {
                    margin-left: 66.66666667%;
                }
                .offset-xl-9 {
                    margin-left: 75%;
                }
                .offset-xl-10 {
                    margin-left: 83.33333333%;
                }
                .offset-xl-11 {
                    margin-left: 91.66666667%;
                }
                .g-xl-0,
                .gx-xl-0 {
                    --bs-gutter-x: 0;
                }
                .g-xl-0,
                .gy-xl-0 {
                    --bs-gutter-y: 0;
                }
                .g-xl-1,
                .gx-xl-1 {
                    --bs-gutter-x: 0.25rem;
                }
                .g-xl-1,
                .gy-xl-1 {
                    --bs-gutter-y: 0.25rem;
                }
                .g-xl-2,
                .gx-xl-2 {
                    --bs-gutter-x: 0.5rem;
                }
                .g-xl-2,
                .gy-xl-2 {
                    --bs-gutter-y: 0.5rem;
                }
                .g-xl-3,
                .gx-xl-3 {
                    --bs-gutter-x: 1rem;
                }
                .g-xl-3,
                .gy-xl-3 {
                    --bs-gutter-y: 1rem;
                }
                .g-xl-4,
                .gx-xl-4 {
                    --bs-gutter-x: 1.5rem;
                }
                .g-xl-4,
                .gy-xl-4 {
                    --bs-gutter-y: 1.5rem;
                }
                .g-xl-5,
                .gx-xl-5 {
                    --bs-gutter-x: 3rem;
                }
                .g-xl-5,
                .gy-xl-5 {
                    --bs-gutter-y: 3rem;
                }
            }
            @media (min-width: 1400px) {
                .col-xxl {
                    flex: 1 0 0%;
                }
                .row-cols-xxl-auto > * {
                    flex: 0 0 auto;
                    width: auto;
                }
                .row-cols-xxl-1 > * {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .row-cols-xxl-2 > * {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .row-cols-xxl-3 > * {
                    flex: 0 0 auto;
                    width: 33.3333333333%;
                }
                .row-cols-xxl-4 > * {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .row-cols-xxl-5 > * {
                    flex: 0 0 auto;
                    width: 20%;
                }
                .row-cols-xxl-6 > * {
                    flex: 0 0 auto;
                    width: 16.6666666667%;
                }
                .col-xxl-auto {
                    flex: 0 0 auto;
                    width: auto;
                }
                .col-xxl-1 {
                    flex: 0 0 auto;
                    width: 8.33333333%;
                }
                .col-xxl-2 {
                    flex: 0 0 auto;
                    width: 16.66666667%;
                }
                .col-xxl-3 {
                    flex: 0 0 auto;
                    width: 25%;
                }
                .col-xxl-4 {
                    flex: 0 0 auto;
                    width: 33.33333333%;
                }
                .col-xxl-5 {
                    flex: 0 0 auto;
                    width: 41.66666667%;
                }
                .col-xxl-6 {
                    flex: 0 0 auto;
                    width: 50%;
                }
                .col-xxl-7 {
                    flex: 0 0 auto;
                    width: 58.33333333%;
                }
                .col-xxl-8 {
                    flex: 0 0 auto;
                    width: 66.66666667%;
                }
                .col-xxl-9 {
                    flex: 0 0 auto;
                    width: 75%;
                }
                .col-xxl-10 {
                    flex: 0 0 auto;
                    width: 83.33333333%;
                }
                .col-xxl-11 {
                    flex: 0 0 auto;
                    width: 91.66666667%;
                }
                .col-xxl-12 {
                    flex: 0 0 auto;
                    width: 100%;
                }
                .offset-xxl-0 {
                    margin-left: 0;
                }
                .offset-xxl-1 {
                    margin-left: 8.33333333%;
                }
                .offset-xxl-2 {
                    margin-left: 16.66666667%;
                }
                .offset-xxl-3 {
                    margin-left: 25%;
                }
                .offset-xxl-4 {
                    margin-left: 33.33333333%;
                }
                .offset-xxl-5 {
                    margin-left: 41.66666667%;
                }
                .offset-xxl-6 {
                    margin-left: 50%;
                }
                .offset-xxl-7 {
                    margin-left: 58.33333333%;
                }
                .offset-xxl-8 {
                    margin-left: 66.66666667%;
                }
                .offset-xxl-9 {
                    margin-left: 75%;
                }
                .offset-xxl-10 {
                    margin-left: 83.33333333%;
                }
                .offset-xxl-11 {
                    margin-left: 91.66666667%;
                }
                .g-xxl-0,
                .gx-xxl-0 {
                    --bs-gutter-x: 0;
                }
                .g-xxl-0,
                .gy-xxl-0 {
                    --bs-gutter-y: 0;
                }
                .g-xxl-1,
                .gx-xxl-1 {
                    --bs-gutter-x: 0.25rem;
                }
                .g-xxl-1,
                .gy-xxl-1 {
                    --bs-gutter-y: 0.25rem;
                }
                .g-xxl-2,
                .gx-xxl-2 {
                    --bs-gutter-x: 0.5rem;
                }
                .g-xxl-2,
                .gy-xxl-2 {
                    --bs-gutter-y: 0.5rem;
                }
                .g-xxl-3,
                .gx-xxl-3 {
                    --bs-gutter-x: 1rem;
                }
                .g-xxl-3,
                .gy-xxl-3 {
                    --bs-gutter-y: 1rem;
                }
                .g-xxl-4,
                .gx-xxl-4 {
                    --bs-gutter-x: 1.5rem;
                }
                .g-xxl-4,
                .gy-xxl-4 {
                    --bs-gutter-y: 1.5rem;
                }
                .g-xxl-5,
                .gx-xxl-5 {
                    --bs-gutter-x: 3rem;
                }
                .g-xxl-5,
                .gy-xxl-5 {
                    --bs-gutter-y: 3rem;
                }
            }
            .table {
                --bs-table-bg: transparent;
                --bs-table-accent-bg: transparent;
                --bs-table-striped-color: #212529;
                --bs-table-striped-bg: rgba(0, 0, 0, 0.05);
                --bs-table-active-color: #212529;
                --bs-table-active-bg: rgba(0, 0, 0, 0.1);
                --bs-table-hover-color: #212529;
                --bs-table-hover-bg: rgba(0, 0, 0, 0.075);
                width: 100%;
                margin-bottom: 1rem;
                color: #212529;
                vertical-align: top;
                border-color: #dee2e6;
            }
            .table > :not(caption) > * > * {
                padding: 0.5rem 0.5rem;
                background-color: var(--bs-table-bg);
                border-bottom-width: 1px;
                box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg);
            }
            .table > tbody {
                vertical-align: inherit;
            }
            .table > thead {
                vertical-align: bottom;
            }
            .table > :not(:last-child) > :last-child > * {
                border-bottom-color: currentColor;
            }
            .caption-top {
                caption-side: top;
            }
            .table-sm > :not(caption) > * > * {
                padding: 0.25rem 0.25rem;
            }
            .table-bordered > :not(caption) > * {
                border-width: 1px 0;
            }
            .table-bordered > :not(caption) > * > * {
                border-width: 0 1px;
            }
            .table-borderless > :not(caption) > * > * {
                border-bottom-width: 0;
            }
            .table-striped > tbody > tr:nth-of-type(odd) {
                --bs-table-accent-bg: var(--bs-table-striped-bg);
                color: var(--bs-table-striped-color);
            }
            .table-active {
                --bs-table-accent-bg: var(--bs-table-active-bg);
                color: var(--bs-table-active-color);
            }
            .table-hover > tbody > tr:hover {
                --bs-table-accent-bg: var(--bs-table-hover-bg);
                color: var(--bs-table-hover-color);
            }
            .table-primary {
                --bs-table-bg: #cfe2ff;
                --bs-table-striped-bg: #c5d7f2;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #bacbe6;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #bfd1ec;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #bacbe6;
            }
            .table-secondary {
                --bs-table-bg: #e2e3e5;
                --bs-table-striped-bg: #d7d8da;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #cbccce;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #d1d2d4;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #cbccce;
            }
            .table-success {
                --bs-table-bg: #d1e7dd;
                --bs-table-striped-bg: #c7dbd2;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #bcd0c7;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #c1d6cc;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #bcd0c7;
            }
            .table-info {
                --bs-table-bg: #cff4fc;
                --bs-table-striped-bg: #c5e8ef;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #badce3;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #bfe2e9;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #badce3;
            }
            .table-warning {
                --bs-table-bg: #fff3cd;
                --bs-table-striped-bg: #f2e7c3;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #e6dbb9;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #ece1be;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #e6dbb9;
            }
            .table-danger {
                --bs-table-bg: #f8d7da;
                --bs-table-striped-bg: #eccccf;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #dfc2c4;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #e5c7ca;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #dfc2c4;
            }
            .table-light {
                --bs-table-bg: #f8f9fa;
                --bs-table-striped-bg: #ecedee;
                --bs-table-striped-color: #000;
                --bs-table-active-bg: #dfe0e1;
                --bs-table-active-color: #000;
                --bs-table-hover-bg: #e5e6e7;
                --bs-table-hover-color: #000;
                color: #000;
                border-color: #dfe0e1;
            }
            .table-dark {
                --bs-table-bg: #212529;
                --bs-table-striped-bg: #2c3034;
                --bs-table-striped-color: #fff;
                --bs-table-active-bg: #373b3e;
                --bs-table-active-color: #fff;
                --bs-table-hover-bg: #323539;
                --bs-table-hover-color: #fff;
                color: #fff;
                border-color: #373b3e;
            }
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            @media (max-width: 575.98px) {
                .table-responsive-sm {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
            }
            @media (max-width: 767.98px) {
                .table-responsive-md {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
            }
            @media (max-width: 991.98px) {
                .table-responsive-lg {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
            }
            @media (max-width: 1199.98px) {
                .table-responsive-xl {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
            }
            @media (max-width: 1399.98px) {
                .table-responsive-xxl {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
            }
            .form-label {
                margin-bottom: 0.5rem;
            }
            .col-form-label {
                padding-top: calc(0.375rem + 1px);
                padding-bottom: calc(0.375rem + 1px);
                margin-bottom: 0;
                font-size: inherit;
                line-height: 1.5;
            }
            .col-form-label-lg {
                padding-top: calc(0.5rem + 1px);
                padding-bottom: calc(0.5rem + 1px);
                font-size: 1.25rem;
            }
            .col-form-label-sm {
                padding-top: calc(0.25rem + 1px);
                padding-bottom: calc(0.25rem + 1px);
                font-size: 0.875rem;
            }
            .form-text {
                margin-top: 0.25rem;
                font-size: 0.875em;
                color: #6c757d;
            }
            .form-control {
                display: block;
                width: 100%;
                padding: 0.375rem 0.75rem;
                font-size: 1rem;
                font-weight: 400;
                line-height: 1.5;
                color: #212529;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid #ced4da;
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
                border-radius: 0.25rem;
                transition:
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-control {
                    transition: none;
                }
            }
            .form-control[type="file"] {
                overflow: hidden;
            }
            .form-control[type="file"]:not(:disabled):not([readonly]) {
                cursor: pointer;
            }
            .form-control:focus {
                color: #212529;
                background-color: #fff;
                border-color: #86b7fe;
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .form-control::-webkit-date-and-time-value {
                height: 1.5em;
            }
            .form-control::-moz-placeholder {
                color: #6c757d;
                opacity: 1;
            }
            .form-control::placeholder {
                color: #6c757d;
                opacity: 1;
            }
            .form-control:disabled,
            .form-control[readonly] {
                background-color: #e9ecef;
                opacity: 1;
            }
            .form-control::file-selector-button {
                padding: 0.375rem 0.75rem;
                margin: -0.375rem -0.75rem;
                -webkit-margin-end: 0.75rem;
                margin-inline-end: 0.75rem;
                color: #212529;
                background-color: #e9ecef;
                pointer-events: none;
                border-color: inherit;
                border-style: solid;
                border-width: 0;
                border-inline-end-width: 1px;
                border-radius: 0;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-control::file-selector-button {
                    transition: none;
                }
            }
            .form-control:hover:not(:disabled):not([readonly])::file-selector-button {
                background-color: #dde0e3;
            }
            .form-control::-webkit-file-upload-button {
                padding: 0.375rem 0.75rem;
                margin: -0.375rem -0.75rem;
                -webkit-margin-end: 0.75rem;
                margin-inline-end: 0.75rem;
                color: #212529;
                background-color: #e9ecef;
                pointer-events: none;
                border-color: inherit;
                border-style: solid;
                border-width: 0;
                border-inline-end-width: 1px;
                border-radius: 0;
                -webkit-transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-control::-webkit-file-upload-button {
                    -webkit-transition: none;
                    transition: none;
                }
            }
            .form-control:hover:not(:disabled):not([readonly])::-webkit-file-upload-button {
                background-color: #dde0e3;
            }
            .form-control-plaintext {
                display: block;
                width: 100%;
                padding: 0.375rem 0;
                margin-bottom: 0;
                line-height: 1.5;
                color: #212529;
                background-color: transparent;
                border: solid transparent;
                border-width: 1px 0;
            }
            .form-control-plaintext.form-control-lg,
            .form-control-plaintext.form-control-sm {
                padding-right: 0;
                padding-left: 0;
            }
            .form-control-sm {
                min-height: calc(1.5em + 0.5rem + 2px);
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
                border-radius: 0.2rem;
            }
            .form-control-sm::file-selector-button {
                padding: 0.25rem 0.5rem;
                margin: -0.25rem -0.5rem;
                -webkit-margin-end: 0.5rem;
                margin-inline-end: 0.5rem;
            }
            .form-control-sm::-webkit-file-upload-button {
                padding: 0.25rem 0.5rem;
                margin: -0.25rem -0.5rem;
                -webkit-margin-end: 0.5rem;
                margin-inline-end: 0.5rem;
            }
            .form-control-lg {
                min-height: calc(1.5em + 1rem + 2px);
                padding: 0.5rem 1rem;
                font-size: 1.25rem;
                border-radius: 0.3rem;
            }
            .form-control-lg::file-selector-button {
                padding: 0.5rem 1rem;
                margin: -0.5rem -1rem;
                -webkit-margin-end: 1rem;
                margin-inline-end: 1rem;
            }
            .form-control-lg::-webkit-file-upload-button {
                padding: 0.5rem 1rem;
                margin: -0.5rem -1rem;
                -webkit-margin-end: 1rem;
                margin-inline-end: 1rem;
            }
            textarea.form-control {
                min-height: calc(1.5em + 0.75rem + 2px);
            }
            textarea.form-control-sm {
                min-height: calc(1.5em + 0.5rem + 2px);
            }
            textarea.form-control-lg {
                min-height: calc(1.5em + 1rem + 2px);
            }
            .form-control-color {
                width: 3rem;
                height: auto;
                padding: 0.375rem;
            }
            .form-control-color:not(:disabled):not([readonly]) {
                cursor: pointer;
            }
            .form-control-color::-moz-color-swatch {
                height: 1.5em;
                border-radius: 0.25rem;
            }
            .form-control-color::-webkit-color-swatch {
                height: 1.5em;
                border-radius: 0.25rem;
            }
            .form-select {
                display: block;
                width: 100%;
                padding: 0.375rem 2.25rem 0.375rem 0.75rem;
                -moz-padding-start: calc(0.75rem - 3px);
                font-size: 1rem;
                font-weight: 400;
                line-height: 1.5;
                color: #212529;
                background-color: #fff;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-position: right 0.75rem center;
                background-size: 16px 12px;
                border: 1px solid #ced4da;
                border-radius: 0.25rem;
                transition:
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-select {
                    transition: none;
                }
            }
            .form-select:focus {
                border-color: #86b7fe;
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .form-select[multiple],
            .form-select[size]:not([size="1"]) {
                padding-right: 0.75rem;
                background-image: none;
            }
            .form-select:disabled {
                background-color: #e9ecef;
            }
            .form-select:-moz-focusring {
                color: transparent;
                text-shadow: 0 0 0 #212529;
            }
            .form-select-sm {
                padding-top: 0.25rem;
                padding-bottom: 0.25rem;
                padding-left: 0.5rem;
                font-size: 0.875rem;
            }
            .form-select-lg {
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
                padding-left: 1rem;
                font-size: 1.25rem;
            }
            .form-check {
                display: block;
                min-height: 1.5rem;
                padding-left: 1.5em;
                margin-bottom: 0.125rem;
            }
            .form-check .form-check-input {
                float: left;
                margin-left: -1.5em;
            }
            .form-check-input {
                width: 1em;
                height: 1em;
                margin-top: 0.25em;
                vertical-align: top;
                background-color: #fff;
                background-repeat: no-repeat;
                background-position: center;
                background-size: contain;
                border: 1px solid rgba(0, 0, 0, 0.25);
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }
            .form-check-input[type="checkbox"] {
                border-radius: 0.25em;
            }
            .form-check-input[type="radio"] {
                border-radius: 50%;
            }
            .form-check-input:active {
                filter: brightness(90%);
            }
            .form-check-input:focus {
                border-color: #86b7fe;
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .form-check-input:checked {
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .form-check-input:checked[type="checkbox"] {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10l3 3l6-6'/%3e%3c/svg%3e");
            }
            .form-check-input:checked[type="radio"] {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='2' fill='%23fff'/%3e%3c/svg%3e");
            }
            .form-check-input[type="checkbox"]:indeterminate {
                background-color: #0d6efd;
                border-color: #0d6efd;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/%3e%3c/svg%3e");
            }
            .form-check-input:disabled {
                pointer-events: none;
                filter: none;
                opacity: 0.5;
            }
            .form-check-input:disabled ~ .form-check-label,
            .form-check-input[disabled] ~ .form-check-label {
                opacity: 0.5;
            }
            .form-switch {
                padding-left: 2.5em;
            }
            .form-switch .form-check-input {
                width: 2em;
                margin-left: -2.5em;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%280, 0, 0, 0.25%29'/%3e%3c/svg%3e");
                background-position: left center;
                border-radius: 2em;
                transition: background-position 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-switch .form-check-input {
                    transition: none;
                }
            }
            .form-switch .form-check-input:focus {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%2386b7fe'/%3e%3c/svg%3e");
            }
            .form-switch .form-check-input:checked {
                background-position: right center;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23fff'/%3e%3c/svg%3e");
            }
            .form-check-inline {
                display: inline-block;
                margin-right: 1rem;
            }
            .btn-check {
                position: absolute;
                clip: rect(0, 0, 0, 0);
                pointer-events: none;
            }
            .btn-check:disabled + .btn,
            .btn-check[disabled] + .btn {
                pointer-events: none;
                filter: none;
                opacity: 0.65;
            }
            .form-range {
                width: 100%;
                height: 1.5rem;
                padding: 0;
                background-color: transparent;
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }
            .form-range:focus {
                outline: 0;
            }
            .form-range:focus::-webkit-slider-thumb {
                box-shadow:
                    0 0 0 1px #fff,
                    0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .form-range:focus::-moz-range-thumb {
                box-shadow:
                    0 0 0 1px #fff,
                    0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .form-range::-moz-focus-outer {
                border: 0;
            }
            .form-range::-webkit-slider-thumb {
                width: 1rem;
                height: 1rem;
                margin-top: -0.25rem;
                background-color: #0d6efd;
                border: 0;
                border-radius: 1rem;
                -webkit-transition:
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                transition:
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                -webkit-appearance: none;
                appearance: none;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-range::-webkit-slider-thumb {
                    -webkit-transition: none;
                    transition: none;
                }
            }
            .form-range::-webkit-slider-thumb:active {
                background-color: #b6d4fe;
            }
            .form-range::-webkit-slider-runnable-track {
                width: 100%;
                height: 0.5rem;
                color: transparent;
                cursor: pointer;
                background-color: #dee2e6;
                border-color: transparent;
                border-radius: 1rem;
            }
            .form-range::-moz-range-thumb {
                width: 1rem;
                height: 1rem;
                background-color: #0d6efd;
                border: 0;
                border-radius: 1rem;
                -moz-transition:
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                transition:
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
                -moz-appearance: none;
                appearance: none;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-range::-moz-range-thumb {
                    -moz-transition: none;
                    transition: none;
                }
            }
            .form-range::-moz-range-thumb:active {
                background-color: #b6d4fe;
            }
            .form-range::-moz-range-track {
                width: 100%;
                height: 0.5rem;
                color: transparent;
                cursor: pointer;
                background-color: #dee2e6;
                border-color: transparent;
                border-radius: 1rem;
            }
            .form-range:disabled {
                pointer-events: none;
            }
            .form-range:disabled::-webkit-slider-thumb {
                background-color: #adb5bd;
            }
            .form-range:disabled::-moz-range-thumb {
                background-color: #adb5bd;
            }
            .form-floating {
                position: relative;
            }
            .form-floating > .form-control,
            .form-floating > .form-select {
                height: calc(3.5rem + 2px);
                line-height: 1.25;
            }
            .form-floating > label {
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                padding: 1rem 0.75rem;
                pointer-events: none;
                border: 1px solid transparent;
                transform-origin: 0 0;
                transition:
                    opacity 0.1s ease-in-out,
                    transform 0.1s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .form-floating > label {
                    transition: none;
                }
            }
            .form-floating > .form-control {
                padding: 1rem 0.75rem;
            }
            .form-floating > .form-control::-moz-placeholder {
                color: transparent;
            }
            .form-floating > .form-control::placeholder {
                color: transparent;
            }
            .form-floating > .form-control:not(:-moz-placeholder-shown) {
                padding-top: 1.625rem;
                padding-bottom: 0.625rem;
            }
            .form-floating > .form-control:focus,
            .form-floating > .form-control:not(:placeholder-shown) {
                padding-top: 1.625rem;
                padding-bottom: 0.625rem;
            }
            .form-floating > .form-control:-webkit-autofill {
                padding-top: 1.625rem;
                padding-bottom: 0.625rem;
            }
            .form-floating > .form-select {
                padding-top: 1.625rem;
                padding-bottom: 0.625rem;
            }
            .form-floating > .form-control:not(:-moz-placeholder-shown) ~ label {
                opacity: 0.65;
                transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
            }
            .form-floating > .form-control:focus ~ label,
            .form-floating > .form-control:not(:placeholder-shown) ~ label,
            .form-floating > .form-select ~ label {
                opacity: 0.65;
                transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
            }
            .form-floating > .form-control:-webkit-autofill ~ label {
                opacity: 0.65;
                transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
            }
            .input-group {
                position: relative;
                display: flex;
                flex-wrap: wrap;
                align-items: stretch;
                width: 100%;
            }
            .input-group > .form-control,
            .input-group > .form-select {
                position: relative;
                flex: 1 1 auto;
                width: 1%;
                min-width: 0;
            }
            .input-group > .form-control:focus,
            .input-group > .form-select:focus {
                z-index: 3;
            }
            .input-group .btn {
                position: relative;
                z-index: 2;
            }
            .input-group .btn:focus {
                z-index: 3;
            }
            .input-group-text {
                display: flex;
                align-items: center;
                padding: 0.375rem 0.75rem;
                font-size: 1rem;
                font-weight: 400;
                line-height: 1.5;
                color: #212529;
                text-align: center;
                white-space: nowrap;
                background-color: #e9ecef;
                border: 1px solid #ced4da;
                border-radius: 0.25rem;
            }
            .input-group-lg > .btn,
            .input-group-lg > .form-control,
            .input-group-lg > .form-select,
            .input-group-lg > .input-group-text {
                padding: 0.5rem 1rem;
                font-size: 1.25rem;
                border-radius: 0.3rem;
            }
            .input-group-sm > .btn,
            .input-group-sm > .form-control,
            .input-group-sm > .form-select,
            .input-group-sm > .input-group-text {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
                border-radius: 0.2rem;
            }
            .input-group-lg > .form-select,
            .input-group-sm > .form-select {
                padding-right: 3rem;
            }
            .input-group:not(.has-validation) > .dropdown-toggle:nth-last-child(n + 3),
            .input-group:not(.has-validation) > :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu) {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
            }
            .input-group.has-validation > .dropdown-toggle:nth-last-child(n + 4),
            .input-group.has-validation > :nth-last-child(n + 3):not(.dropdown-toggle):not(.dropdown-menu) {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
            }
            .input-group
                > :not(:first-child):not(.dropdown-menu):not(.valid-tooltip):not(.valid-feedback):not(
                    .invalid-tooltip
                ):not(.invalid-feedback) {
                margin-left: -1px;
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
            }
            .valid-feedback {
                display: none;
                width: 100%;
                margin-top: 0.25rem;
                font-size: 0.875em;
                color: #198754;
            }
            .valid-tooltip {
                position: absolute;
                top: 100%;
                z-index: 5;
                display: none;
                max-width: 100%;
                padding: 0.25rem 0.5rem;
                margin-top: 0.1rem;
                font-size: 0.875rem;
                color: #fff;
                background-color: rgba(25, 135, 84, 0.9);
                border-radius: 0.25rem;
            }
            .is-valid ~ .valid-feedback,
            .is-valid ~ .valid-tooltip,
            .was-validated :valid ~ .valid-feedback,
            .was-validated :valid ~ .valid-tooltip {
                display: block;
            }
            .form-control.is-valid,
            .was-validated .form-control:valid {
                border-color: #198754;
                padding-right: calc(1.5em + 0.75rem);
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-position: right calc(0.375em + 0.1875rem) center;
                background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
            }
            .form-control.is-valid:focus,
            .was-validated .form-control:valid:focus {
                border-color: #198754;
                box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.25);
            }
            .was-validated textarea.form-control:valid,
            textarea.form-control.is-valid {
                padding-right: calc(1.5em + 0.75rem);
                background-position: top calc(0.375em + 0.1875rem) right calc(0.375em + 0.1875rem);
            }
            .form-select.is-valid,
            .was-validated .form-select:valid {
                border-color: #198754;
            }
            .form-select.is-valid:not([multiple]):not([size]),
            .form-select.is-valid:not([multiple])[size="1"],
            .was-validated .form-select:valid:not([multiple]):not([size]),
            .was-validated .form-select:valid:not([multiple])[size="1"] {
                padding-right: 4.125rem;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"),
                    url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
                background-position:
                    right 0.75rem center,
                    center right 2.25rem;
                background-size:
                    16px 12px,
                    calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
            }
            .form-select.is-valid:focus,
            .was-validated .form-select:valid:focus {
                border-color: #198754;
                box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.25);
            }
            .form-check-input.is-valid,
            .was-validated .form-check-input:valid {
                border-color: #198754;
            }
            .form-check-input.is-valid:checked,
            .was-validated .form-check-input:valid:checked {
                background-color: #198754;
            }
            .form-check-input.is-valid:focus,
            .was-validated .form-check-input:valid:focus {
                box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.25);
            }
            .form-check-input.is-valid ~ .form-check-label,
            .was-validated .form-check-input:valid ~ .form-check-label {
                color: #198754;
            }
            .form-check-inline .form-check-input ~ .valid-feedback {
                margin-left: 0.5em;
            }
            .input-group .form-control.is-valid,
            .input-group .form-select.is-valid,
            .was-validated .input-group .form-control:valid,
            .was-validated .input-group .form-select:valid {
                z-index: 1;
            }
            .input-group .form-control.is-valid:focus,
            .input-group .form-select.is-valid:focus,
            .was-validated .input-group .form-control:valid:focus,
            .was-validated .input-group .form-select:valid:focus {
                z-index: 3;
            }
            .invalid-feedback {
                display: none;
                width: 100%;
                margin-top: 0.25rem;
                font-size: 0.875em;
                color: #dc3545;
            }
            .invalid-tooltip {
                position: absolute;
                top: 100%;
                z-index: 5;
                display: none;
                max-width: 100%;
                padding: 0.25rem 0.5rem;
                margin-top: 0.1rem;
                font-size: 0.875rem;
                color: #fff;
                background-color: rgba(220, 53, 69, 0.9);
                border-radius: 0.25rem;
            }
            .is-invalid ~ .invalid-feedback,
            .is-invalid ~ .invalid-tooltip,
            .was-validated :invalid ~ .invalid-feedback,
            .was-validated :invalid ~ .invalid-tooltip {
                display: block;
            }
            .form-control.is-invalid,
            .was-validated .form-control:invalid {
                border-color: #dc3545;
                padding-right: calc(1.5em + 0.75rem);
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-position: right calc(0.375em + 0.1875rem) center;
                background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
            }
            .form-control.is-invalid:focus,
            .was-validated .form-control:invalid:focus {
                border-color: #dc3545;
                box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
            }
            .was-validated textarea.form-control:invalid,
            textarea.form-control.is-invalid {
                padding-right: calc(1.5em + 0.75rem);
                background-position: top calc(0.375em + 0.1875rem) right calc(0.375em + 0.1875rem);
            }
            .form-select.is-invalid,
            .was-validated .form-select:invalid {
                border-color: #dc3545;
            }
            .form-select.is-invalid:not([multiple]):not([size]),
            .form-select.is-invalid:not([multiple])[size="1"],
            .was-validated .form-select:invalid:not([multiple]):not([size]),
            .was-validated .form-select:invalid:not([multiple])[size="1"] {
                padding-right: 4.125rem;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"),
                    url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
                background-position:
                    right 0.75rem center,
                    center right 2.25rem;
                background-size:
                    16px 12px,
                    calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
            }
            .form-select.is-invalid:focus,
            .was-validated .form-select:invalid:focus {
                border-color: #dc3545;
                box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
            }
            .form-check-input.is-invalid,
            .was-validated .form-check-input:invalid {
                border-color: #dc3545;
            }
            .form-check-input.is-invalid:checked,
            .was-validated .form-check-input:invalid:checked {
                background-color: #dc3545;
            }
            .form-check-input.is-invalid:focus,
            .was-validated .form-check-input:invalid:focus {
                box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
            }
            .form-check-input.is-invalid ~ .form-check-label,
            .was-validated .form-check-input:invalid ~ .form-check-label {
                color: #dc3545;
            }
            .form-check-inline .form-check-input ~ .invalid-feedback {
                margin-left: 0.5em;
            }
            .input-group .form-control.is-invalid,
            .input-group .form-select.is-invalid,
            .was-validated .input-group .form-control:invalid,
            .was-validated .input-group .form-select:invalid {
                z-index: 2;
            }
            .input-group .form-control.is-invalid:focus,
            .input-group .form-select.is-invalid:focus,
            .was-validated .input-group .form-control:invalid:focus,
            .was-validated .input-group .form-select:invalid:focus {
                z-index: 3;
            }
            .btn {
                display: inline-block;
                font-weight: 400;
                line-height: 1.5;
                color: #212529;
                text-align: center;
                text-decoration: none;
                vertical-align: middle;
                cursor: pointer;
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none;
                background-color: transparent;
                border: 1px solid transparent;
                padding: 0.375rem 0.75rem;
                font-size: 1rem;
                border-radius: 0.25rem;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .btn {
                    transition: none;
                }
            }
            .btn:hover {
                color: #212529;
            }
            .btn-check:focus + .btn,
            .btn:focus {
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .btn.disabled,
            .btn:disabled,
            fieldset:disabled .btn {
                pointer-events: none;
                opacity: 0.65;
            }
            .btn-primary {
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .btn-primary:hover {
                color: #fff;
                background-color: #0b5ed7;
                border-color: #0a58ca;
            }
            .btn-check:focus + .btn-primary,
            .btn-primary:focus {
                color: #fff;
                background-color: #0b5ed7;
                border-color: #0a58ca;
                box-shadow: 0 0 0 0.25rem rgba(49, 132, 253, 0.5);
            }
            .btn-check:active + .btn-primary,
            .btn-check:checked + .btn-primary,
            .btn-primary.active,
            .btn-primary:active,
            .show > .btn-primary.dropdown-toggle {
                color: #fff;
                background-color: #0a58ca;
                border-color: #0a53be;
            }
            .btn-check:active + .btn-primary:focus,
            .btn-check:checked + .btn-primary:focus,
            .btn-primary.active:focus,
            .btn-primary:active:focus,
            .show > .btn-primary.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(49, 132, 253, 0.5);
            }
            .btn-primary.disabled,
            .btn-primary:disabled {
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .btn-secondary {
                color: #fff;
                background-color: #6c757d;
                border-color: #6c757d;
            }
            .btn-secondary:hover {
                color: #fff;
                background-color: #5c636a;
                border-color: #565e64;
            }
            .btn-check:focus + .btn-secondary,
            .btn-secondary:focus {
                color: #fff;
                background-color: #5c636a;
                border-color: #565e64;
                box-shadow: 0 0 0 0.25rem rgba(130, 138, 145, 0.5);
            }
            .btn-check:active + .btn-secondary,
            .btn-check:checked + .btn-secondary,
            .btn-secondary.active,
            .btn-secondary:active,
            .show > .btn-secondary.dropdown-toggle {
                color: #fff;
                background-color: #565e64;
                border-color: #51585e;
            }
            .btn-check:active + .btn-secondary:focus,
            .btn-check:checked + .btn-secondary:focus,
            .btn-secondary.active:focus,
            .btn-secondary:active:focus,
            .show > .btn-secondary.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(130, 138, 145, 0.5);
            }
            .btn-secondary.disabled,
            .btn-secondary:disabled {
                color: #fff;
                background-color: #6c757d;
                border-color: #6c757d;
            }
            .btn-success {
                color: #fff;
                background-color: #198754;
                border-color: #198754;
            }
            .btn-success:hover {
                color: #fff;
                background-color: #157347;
                border-color: #146c43;
            }
            .btn-check:focus + .btn-success,
            .btn-success:focus {
                color: #fff;
                background-color: #157347;
                border-color: #146c43;
                box-shadow: 0 0 0 0.25rem rgba(60, 153, 110, 0.5);
            }
            .btn-check:active + .btn-success,
            .btn-check:checked + .btn-success,
            .btn-success.active,
            .btn-success:active,
            .show > .btn-success.dropdown-toggle {
                color: #fff;
                background-color: #146c43;
                border-color: #13653f;
            }
            .btn-check:active + .btn-success:focus,
            .btn-check:checked + .btn-success:focus,
            .btn-success.active:focus,
            .btn-success:active:focus,
            .show > .btn-success.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(60, 153, 110, 0.5);
            }
            .btn-success.disabled,
            .btn-success:disabled {
                color: #fff;
                background-color: #198754;
                border-color: #198754;
            }
            .btn-info {
                color: #000;
                background-color: #0dcaf0;
                border-color: #0dcaf0;
            }
            .btn-info:hover {
                color: #000;
                background-color: #31d2f2;
                border-color: #25cff2;
            }
            .btn-check:focus + .btn-info,
            .btn-info:focus {
                color: #000;
                background-color: #31d2f2;
                border-color: #25cff2;
                box-shadow: 0 0 0 0.25rem rgba(11, 172, 204, 0.5);
            }
            .btn-check:active + .btn-info,
            .btn-check:checked + .btn-info,
            .btn-info.active,
            .btn-info:active,
            .show > .btn-info.dropdown-toggle {
                color: #000;
                background-color: #3dd5f3;
                border-color: #25cff2;
            }
            .btn-check:active + .btn-info:focus,
            .btn-check:checked + .btn-info:focus,
            .btn-info.active:focus,
            .btn-info:active:focus,
            .show > .btn-info.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(11, 172, 204, 0.5);
            }
            .btn-info.disabled,
            .btn-info:disabled {
                color: #000;
                background-color: #0dcaf0;
                border-color: #0dcaf0;
            }
            .btn-warning {
                color: #000;
                background-color: #ffc107;
                border-color: #ffc107;
            }
            .btn-warning:hover {
                color: #000;
                background-color: #ffca2c;
                border-color: #ffc720;
            }
            .btn-check:focus + .btn-warning,
            .btn-warning:focus {
                color: #000;
                background-color: #ffca2c;
                border-color: #ffc720;
                box-shadow: 0 0 0 0.25rem rgba(217, 164, 6, 0.5);
            }
            .btn-check:active + .btn-warning,
            .btn-check:checked + .btn-warning,
            .btn-warning.active,
            .btn-warning:active,
            .show > .btn-warning.dropdown-toggle {
                color: #000;
                background-color: #ffcd39;
                border-color: #ffc720;
            }
            .btn-check:active + .btn-warning:focus,
            .btn-check:checked + .btn-warning:focus,
            .btn-warning.active:focus,
            .btn-warning:active:focus,
            .show > .btn-warning.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(217, 164, 6, 0.5);
            }
            .btn-warning.disabled,
            .btn-warning:disabled {
                color: #000;
                background-color: #ffc107;
                border-color: #ffc107;
            }
            .btn-danger {
                color: #fff;
                background-color: #dc3545;
                border-color: #dc3545;
            }
            .btn-danger:hover {
                color: #fff;
                background-color: #bb2d3b;
                border-color: #b02a37;
            }
            .btn-check:focus + .btn-danger,
            .btn-danger:focus {
                color: #fff;
                background-color: #bb2d3b;
                border-color: #b02a37;
                box-shadow: 0 0 0 0.25rem rgba(225, 83, 97, 0.5);
            }
            .btn-check:active + .btn-danger,
            .btn-check:checked + .btn-danger,
            .btn-danger.active,
            .btn-danger:active,
            .show > .btn-danger.dropdown-toggle {
                color: #fff;
                background-color: #b02a37;
                border-color: #a52834;
            }
            .btn-check:active + .btn-danger:focus,
            .btn-check:checked + .btn-danger:focus,
            .btn-danger.active:focus,
            .btn-danger:active:focus,
            .show > .btn-danger.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(225, 83, 97, 0.5);
            }
            .btn-danger.disabled,
            .btn-danger:disabled {
                color: #fff;
                background-color: #dc3545;
                border-color: #dc3545;
            }
            .btn-light {
                color: #000;
                background-color: #f8f9fa;
                border-color: #f8f9fa;
            }
            .btn-light:hover {
                color: #000;
                background-color: #f9fafb;
                border-color: #f9fafb;
            }
            .btn-check:focus + .btn-light,
            .btn-light:focus {
                color: #000;
                background-color: #f9fafb;
                border-color: #f9fafb;
                box-shadow: 0 0 0 0.25rem rgba(211, 212, 213, 0.5);
            }
            .btn-check:active + .btn-light,
            .btn-check:checked + .btn-light,
            .btn-light.active,
            .btn-light:active,
            .show > .btn-light.dropdown-toggle {
                color: #000;
                background-color: #f9fafb;
                border-color: #f9fafb;
            }
            .btn-check:active + .btn-light:focus,
            .btn-check:checked + .btn-light:focus,
            .btn-light.active:focus,
            .btn-light:active:focus,
            .show > .btn-light.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(211, 212, 213, 0.5);
            }
            .btn-light.disabled,
            .btn-light:disabled {
                color: #000;
                background-color: #f8f9fa;
                border-color: #f8f9fa;
            }
            .btn-dark {
                color: #fff;
                background-color: #212529;
                border-color: #212529;
            }
            .btn-dark:hover {
                color: #fff;
                background-color: #1c1f23;
                border-color: #1a1e21;
            }
            .btn-check:focus + .btn-dark,
            .btn-dark:focus {
                color: #fff;
                background-color: #1c1f23;
                border-color: #1a1e21;
                box-shadow: 0 0 0 0.25rem rgba(66, 70, 73, 0.5);
            }
            .btn-check:active + .btn-dark,
            .btn-check:checked + .btn-dark,
            .btn-dark.active,
            .btn-dark:active,
            .show > .btn-dark.dropdown-toggle {
                color: #fff;
                background-color: #1a1e21;
                border-color: #191c1f;
            }
            .btn-check:active + .btn-dark:focus,
            .btn-check:checked + .btn-dark:focus,
            .btn-dark.active:focus,
            .btn-dark:active:focus,
            .show > .btn-dark.dropdown-toggle:focus {
                box-shadow: 0 0 0 0.25rem rgba(66, 70, 73, 0.5);
            }
            .btn-dark.disabled,
            .btn-dark:disabled {
                color: #fff;
                background-color: #212529;
                border-color: #212529;
            }
            .btn-outline-primary {
                color: #0d6efd;
                border-color: #0d6efd;
            }
            .btn-outline-primary:hover {
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .btn-check:focus + .btn-outline-primary,
            .btn-outline-primary:focus {
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.5);
            }
            .btn-check:active + .btn-outline-primary,
            .btn-check:checked + .btn-outline-primary,
            .btn-outline-primary.active,
            .btn-outline-primary.dropdown-toggle.show,
            .btn-outline-primary:active {
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .btn-check:active + .btn-outline-primary:focus,
            .btn-check:checked + .btn-outline-primary:focus,
            .btn-outline-primary.active:focus,
            .btn-outline-primary.dropdown-toggle.show:focus,
            .btn-outline-primary:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.5);
            }
            .btn-outline-primary.disabled,
            .btn-outline-primary:disabled {
                color: #0d6efd;
                background-color: transparent;
            }
            .btn-outline-secondary {
                color: #6c757d;
                border-color: #6c757d;
            }
            .btn-outline-secondary:hover {
                color: #fff;
                background-color: #6c757d;
                border-color: #6c757d;
            }
            .btn-check:focus + .btn-outline-secondary,
            .btn-outline-secondary:focus {
                box-shadow: 0 0 0 0.25rem rgba(108, 117, 125, 0.5);
            }
            .btn-check:active + .btn-outline-secondary,
            .btn-check:checked + .btn-outline-secondary,
            .btn-outline-secondary.active,
            .btn-outline-secondary.dropdown-toggle.show,
            .btn-outline-secondary:active {
                color: #fff;
                background-color: #6c757d;
                border-color: #6c757d;
            }
            .btn-check:active + .btn-outline-secondary:focus,
            .btn-check:checked + .btn-outline-secondary:focus,
            .btn-outline-secondary.active:focus,
            .btn-outline-secondary.dropdown-toggle.show:focus,
            .btn-outline-secondary:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(108, 117, 125, 0.5);
            }
            .btn-outline-secondary.disabled,
            .btn-outline-secondary:disabled {
                color: #6c757d;
                background-color: transparent;
            }
            .btn-outline-success {
                color: #198754;
                border-color: #198754;
            }
            .btn-outline-success:hover {
                color: #fff;
                background-color: #198754;
                border-color: #198754;
            }
            .btn-check:focus + .btn-outline-success,
            .btn-outline-success:focus {
                box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.5);
            }
            .btn-check:active + .btn-outline-success,
            .btn-check:checked + .btn-outline-success,
            .btn-outline-success.active,
            .btn-outline-success.dropdown-toggle.show,
            .btn-outline-success:active {
                color: #fff;
                background-color: #198754;
                border-color: #198754;
            }
            .btn-check:active + .btn-outline-success:focus,
            .btn-check:checked + .btn-outline-success:focus,
            .btn-outline-success.active:focus,
            .btn-outline-success.dropdown-toggle.show:focus,
            .btn-outline-success:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.5);
            }
            .btn-outline-success.disabled,
            .btn-outline-success:disabled {
                color: #198754;
                background-color: transparent;
            }
            .btn-outline-info {
                color: #0dcaf0;
                border-color: #0dcaf0;
            }
            .btn-outline-info:hover {
                color: #000;
                background-color: #0dcaf0;
                border-color: #0dcaf0;
            }
            .btn-check:focus + .btn-outline-info,
            .btn-outline-info:focus {
                box-shadow: 0 0 0 0.25rem rgba(13, 202, 240, 0.5);
            }
            .btn-check:active + .btn-outline-info,
            .btn-check:checked + .btn-outline-info,
            .btn-outline-info.active,
            .btn-outline-info.dropdown-toggle.show,
            .btn-outline-info:active {
                color: #000;
                background-color: #0dcaf0;
                border-color: #0dcaf0;
            }
            .btn-check:active + .btn-outline-info:focus,
            .btn-check:checked + .btn-outline-info:focus,
            .btn-outline-info.active:focus,
            .btn-outline-info.dropdown-toggle.show:focus,
            .btn-outline-info:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(13, 202, 240, 0.5);
            }
            .btn-outline-info.disabled,
            .btn-outline-info:disabled {
                color: #0dcaf0;
                background-color: transparent;
            }
            .btn-outline-warning {
                color: #ffc107;
                border-color: #ffc107;
            }
            .btn-outline-warning:hover {
                color: #000;
                background-color: #ffc107;
                border-color: #ffc107;
            }
            .btn-check:focus + .btn-outline-warning,
            .btn-outline-warning:focus {
                box-shadow: 0 0 0 0.25rem rgba(255, 193, 7, 0.5);
            }
            .btn-check:active + .btn-outline-warning,
            .btn-check:checked + .btn-outline-warning,
            .btn-outline-warning.active,
            .btn-outline-warning.dropdown-toggle.show,
            .btn-outline-warning:active {
                color: #000;
                background-color: #ffc107;
                border-color: #ffc107;
            }
            .btn-check:active + .btn-outline-warning:focus,
            .btn-check:checked + .btn-outline-warning:focus,
            .btn-outline-warning.active:focus,
            .btn-outline-warning.dropdown-toggle.show:focus,
            .btn-outline-warning:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(255, 193, 7, 0.5);
            }
            .btn-outline-warning.disabled,
            .btn-outline-warning:disabled {
                color: #ffc107;
                background-color: transparent;
            }
            .btn-outline-danger {
                color: #dc3545;
                border-color: #dc3545;
            }
            .btn-outline-danger:hover {
                color: #fff;
                background-color: #dc3545;
                border-color: #dc3545;
            }
            .btn-check:focus + .btn-outline-danger,
            .btn-outline-danger:focus {
                box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.5);
            }
            .btn-check:active + .btn-outline-danger,
            .btn-check:checked + .btn-outline-danger,
            .btn-outline-danger.active,
            .btn-outline-danger.dropdown-toggle.show,
            .btn-outline-danger:active {
                color: #fff;
                background-color: #dc3545;
                border-color: #dc3545;
            }
            .btn-check:active + .btn-outline-danger:focus,
            .btn-check:checked + .btn-outline-danger:focus,
            .btn-outline-danger.active:focus,
            .btn-outline-danger.dropdown-toggle.show:focus,
            .btn-outline-danger:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.5);
            }
            .btn-outline-danger.disabled,
            .btn-outline-danger:disabled {
                color: #dc3545;
                background-color: transparent;
            }
            .btn-outline-light {
                color: #f8f9fa;
                border-color: #f8f9fa;
            }
            .btn-outline-light:hover {
                color: #000;
                background-color: #f8f9fa;
                border-color: #f8f9fa;
            }
            .btn-check:focus + .btn-outline-light,
            .btn-outline-light:focus {
                box-shadow: 0 0 0 0.25rem rgba(248, 249, 250, 0.5);
            }
            .btn-check:active + .btn-outline-light,
            .btn-check:checked + .btn-outline-light,
            .btn-outline-light.active,
            .btn-outline-light.dropdown-toggle.show,
            .btn-outline-light:active {
                color: #000;
                background-color: #f8f9fa;
                border-color: #f8f9fa;
            }
            .btn-check:active + .btn-outline-light:focus,
            .btn-check:checked + .btn-outline-light:focus,
            .btn-outline-light.active:focus,
            .btn-outline-light.dropdown-toggle.show:focus,
            .btn-outline-light:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(248, 249, 250, 0.5);
            }
            .btn-outline-light.disabled,
            .btn-outline-light:disabled {
                color: #f8f9fa;
                background-color: transparent;
            }
            .btn-outline-dark {
                color: #212529;
                border-color: #212529;
            }
            .btn-outline-dark:hover {
                color: #fff;
                background-color: #212529;
                border-color: #212529;
            }
            .btn-check:focus + .btn-outline-dark,
            .btn-outline-dark:focus {
                box-shadow: 0 0 0 0.25rem rgba(33, 37, 41, 0.5);
            }
            .btn-check:active + .btn-outline-dark,
            .btn-check:checked + .btn-outline-dark,
            .btn-outline-dark.active,
            .btn-outline-dark.dropdown-toggle.show,
            .btn-outline-dark:active {
                color: #fff;
                background-color: #212529;
                border-color: #212529;
            }
            .btn-check:active + .btn-outline-dark:focus,
            .btn-check:checked + .btn-outline-dark:focus,
            .btn-outline-dark.active:focus,
            .btn-outline-dark.dropdown-toggle.show:focus,
            .btn-outline-dark:active:focus {
                box-shadow: 0 0 0 0.25rem rgba(33, 37, 41, 0.5);
            }
            .btn-outline-dark.disabled,
            .btn-outline-dark:disabled {
                color: #212529;
                background-color: transparent;
            }
            .btn-link {
                font-weight: 400;
                color: #0d6efd;
                text-decoration: underline;
            }
            .btn-link:hover {
                color: #0a58ca;
            }
            .btn-link.disabled,
            .btn-link:disabled {
                color: #6c757d;
            }
            .btn-group-lg > .btn,
            .btn-lg {
                padding: 0.5rem 1rem;
                font-size: 1.25rem;
                border-radius: 0.3rem;
            }
            .btn-group-sm > .btn,
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
                border-radius: 0.2rem;
            }
            .fade {
                transition: opacity 0.15s linear;
            }
            @media (prefers-reduced-motion: reduce) {
                .fade {
                    transition: none;
                }
            }
            .fade:not(.show) {
                opacity: 0;
            }
            .collapse:not(.show) {
                display: none;
            }
            .collapsing {
                height: 0;
                overflow: hidden;
                transition: height 0.35s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .collapsing {
                    transition: none;
                }
            }
            .collapsing.collapse-horizontal {
                width: 0;
                height: auto;
                transition: width 0.35s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .collapsing.collapse-horizontal {
                    transition: none;
                }
            }
            .dropdown,
            .dropend,
            .dropstart,
            .dropup {
                position: relative;
            }
            .dropdown-toggle {
                white-space: nowrap;
            }
            .dropdown-toggle::after {
                display: inline-block;
                margin-left: 0.255em;
                vertical-align: 0.255em;
                content: "";
                border-top: 0.3em solid;
                border-right: 0.3em solid transparent;
                border-bottom: 0;
                border-left: 0.3em solid transparent;
            }
            .dropdown-toggle:empty::after {
                margin-left: 0;
            }
            .dropdown-menu {
                position: absolute;
                z-index: 1000;
                display: none;
                min-width: 10rem;
                padding: 0.5rem 0;
                margin: 0;
                font-size: 1rem;
                color: #212529;
                text-align: left;
                list-style: none;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.15);
                border-radius: 0.25rem;
            }
            .dropdown-menu[data-bs-popper] {
                top: 100%;
                left: 0;
                margin-top: 0.125rem;
            }
            .dropdown-menu-start {
                --bs-position: start;
            }
            .dropdown-menu-start[data-bs-popper] {
                right: auto;
                left: 0;
            }
            .dropdown-menu-end {
                --bs-position: end;
            }
            .dropdown-menu-end[data-bs-popper] {
                right: 0;
                left: auto;
            }
            @media (min-width: 576px) {
                .dropdown-menu-sm-start {
                    --bs-position: start;
                }
                .dropdown-menu-sm-start[data-bs-popper] {
                    right: auto;
                    left: 0;
                }
                .dropdown-menu-sm-end {
                    --bs-position: end;
                }
                .dropdown-menu-sm-end[data-bs-popper] {
                    right: 0;
                    left: auto;
                }
            }
            @media (min-width: 768px) {
                .dropdown-menu-md-start {
                    --bs-position: start;
                }
                .dropdown-menu-md-start[data-bs-popper] {
                    right: auto;
                    left: 0;
                }
                .dropdown-menu-md-end {
                    --bs-position: end;
                }
                .dropdown-menu-md-end[data-bs-popper] {
                    right: 0;
                    left: auto;
                }
            }
            @media (min-width: 992px) {
                .dropdown-menu-lg-start {
                    --bs-position: start;
                }
                .dropdown-menu-lg-start[data-bs-popper] {
                    right: auto;
                    left: 0;
                }
                .dropdown-menu-lg-end {
                    --bs-position: end;
                }
                .dropdown-menu-lg-end[data-bs-popper] {
                    right: 0;
                    left: auto;
                }
            }
            @media (min-width: 1200px) {
                .dropdown-menu-xl-start {
                    --bs-position: start;
                }
                .dropdown-menu-xl-start[data-bs-popper] {
                    right: auto;
                    left: 0;
                }
                .dropdown-menu-xl-end {
                    --bs-position: end;
                }
                .dropdown-menu-xl-end[data-bs-popper] {
                    right: 0;
                    left: auto;
                }
            }
            @media (min-width: 1400px) {
                .dropdown-menu-xxl-start {
                    --bs-position: start;
                }
                .dropdown-menu-xxl-start[data-bs-popper] {
                    right: auto;
                    left: 0;
                }
                .dropdown-menu-xxl-end {
                    --bs-position: end;
                }
                .dropdown-menu-xxl-end[data-bs-popper] {
                    right: 0;
                    left: auto;
                }
            }
            .dropup .dropdown-menu[data-bs-popper] {
                top: auto;
                bottom: 100%;
                margin-top: 0;
                margin-bottom: 0.125rem;
            }
            .dropup .dropdown-toggle::after {
                display: inline-block;
                margin-left: 0.255em;
                vertical-align: 0.255em;
                content: "";
                border-top: 0;
                border-right: 0.3em solid transparent;
                border-bottom: 0.3em solid;
                border-left: 0.3em solid transparent;
            }
            .dropup .dropdown-toggle:empty::after {
                margin-left: 0;
            }
            .dropend .dropdown-menu[data-bs-popper] {
                top: 0;
                right: auto;
                left: 100%;
                margin-top: 0;
                margin-left: 0.125rem;
            }
            .dropend .dropdown-toggle::after {
                display: inline-block;
                margin-left: 0.255em;
                vertical-align: 0.255em;
                content: "";
                border-top: 0.3em solid transparent;
                border-right: 0;
                border-bottom: 0.3em solid transparent;
                border-left: 0.3em solid;
            }
            .dropend .dropdown-toggle:empty::after {
                margin-left: 0;
            }
            .dropend .dropdown-toggle::after {
                vertical-align: 0;
            }
            .dropstart .dropdown-menu[data-bs-popper] {
                top: 0;
                right: 100%;
                left: auto;
                margin-top: 0;
                margin-right: 0.125rem;
            }
            .dropstart .dropdown-toggle::after {
                display: inline-block;
                margin-left: 0.255em;
                vertical-align: 0.255em;
                content: "";
            }
            .dropstart .dropdown-toggle::after {
                display: none;
            }
            .dropstart .dropdown-toggle::before {
                display: inline-block;
                margin-right: 0.255em;
                vertical-align: 0.255em;
                content: "";
                border-top: 0.3em solid transparent;
                border-right: 0.3em solid;
                border-bottom: 0.3em solid transparent;
            }
            .dropstart .dropdown-toggle:empty::after {
                margin-left: 0;
            }
            .dropstart .dropdown-toggle::before {
                vertical-align: 0;
            }
            .dropdown-divider {
                height: 0;
                margin: 0.5rem 0;
                overflow: hidden;
                border-top: 1px solid rgba(0, 0, 0, 0.15);
            }
            .dropdown-item {
                display: block;
                width: 100%;
                padding: 0.25rem 1rem;
                clear: both;
                font-weight: 400;
                color: #212529;
                text-align: inherit;
                text-decoration: none;
                white-space: nowrap;
                background-color: transparent;
                border: 0;
            }
            .dropdown-item:focus,
            .dropdown-item:hover {
                color: #1e2125;
                background-color: #e9ecef;
            }
            .dropdown-item.active,
            .dropdown-item:active {
                color: #fff;
                text-decoration: none;
                background-color: #0d6efd;
            }
            .dropdown-item.disabled,
            .dropdown-item:disabled {
                color: #adb5bd;
                pointer-events: none;
                background-color: transparent;
            }
            .dropdown-menu.show {
                display: block;
            }
            .dropdown-header {
                display: block;
                padding: 0.5rem 1rem;
                margin-bottom: 0;
                font-size: 0.875rem;
                color: #6c757d;
                white-space: nowrap;
            }
            .dropdown-item-text {
                display: block;
                padding: 0.25rem 1rem;
                color: #212529;
            }
            .dropdown-menu-dark {
                color: #dee2e6;
                background-color: #343a40;
                border-color: rgba(0, 0, 0, 0.15);
            }
            .dropdown-menu-dark .dropdown-item {
                color: #dee2e6;
            }
            .dropdown-menu-dark .dropdown-item:focus,
            .dropdown-menu-dark .dropdown-item:hover {
                color: #fff;
                background-color: rgba(255, 255, 255, 0.15);
            }
            .dropdown-menu-dark .dropdown-item.active,
            .dropdown-menu-dark .dropdown-item:active {
                color: #fff;
                background-color: #0d6efd;
            }
            .dropdown-menu-dark .dropdown-item.disabled,
            .dropdown-menu-dark .dropdown-item:disabled {
                color: #adb5bd;
            }
            .dropdown-menu-dark .dropdown-divider {
                border-color: rgba(0, 0, 0, 0.15);
            }
            .dropdown-menu-dark .dropdown-item-text {
                color: #dee2e6;
            }
            .dropdown-menu-dark .dropdown-header {
                color: #adb5bd;
            }
            .btn-group,
            .btn-group-vertical {
                position: relative;
                display: inline-flex;
                vertical-align: middle;
            }
            .btn-group-vertical > .btn,
            .btn-group > .btn {
                position: relative;
                flex: 1 1 auto;
            }
            .btn-group-vertical > .btn-check:checked + .btn,
            .btn-group-vertical > .btn-check:focus + .btn,
            .btn-group-vertical > .btn.active,
            .btn-group-vertical > .btn:active,
            .btn-group-vertical > .btn:focus,
            .btn-group-vertical > .btn:hover,
            .btn-group > .btn-check:checked + .btn,
            .btn-group > .btn-check:focus + .btn,
            .btn-group > .btn.active,
            .btn-group > .btn:active,
            .btn-group > .btn:focus,
            .btn-group > .btn:hover {
                z-index: 1;
            }
            .btn-toolbar {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
            }
            .btn-toolbar .input-group {
                width: auto;
            }
            .btn-group > .btn-group:not(:first-child),
            .btn-group > .btn:not(:first-child) {
                margin-left: -1px;
            }
            .btn-group > .btn-group:not(:last-child) > .btn,
            .btn-group > .btn:not(:last-child):not(.dropdown-toggle) {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
            }
            .btn-group > .btn-group:not(:first-child) > .btn,
            .btn-group > .btn:nth-child(n + 3),
            .btn-group > :not(.btn-check) + .btn {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
            }
            .dropdown-toggle-split {
                padding-right: 0.5625rem;
                padding-left: 0.5625rem;
            }
            .dropdown-toggle-split::after,
            .dropend .dropdown-toggle-split::after,
            .dropup .dropdown-toggle-split::after {
                margin-left: 0;
            }
            .dropstart .dropdown-toggle-split::before {
                margin-right: 0;
            }
            .btn-group-sm > .btn + .dropdown-toggle-split,
            .btn-sm + .dropdown-toggle-split {
                padding-right: 0.375rem;
                padding-left: 0.375rem;
            }
            .btn-group-lg > .btn + .dropdown-toggle-split,
            .btn-lg + .dropdown-toggle-split {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
            .btn-group-vertical {
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
            }
            .btn-group-vertical > .btn,
            .btn-group-vertical > .btn-group {
                width: 100%;
            }
            .btn-group-vertical > .btn-group:not(:first-child),
            .btn-group-vertical > .btn:not(:first-child) {
                margin-top: -1px;
            }
            .btn-group-vertical > .btn-group:not(:last-child) > .btn,
            .btn-group-vertical > .btn:not(:last-child):not(.dropdown-toggle) {
                border-bottom-right-radius: 0;
                border-bottom-left-radius: 0;
            }
            .btn-group-vertical > .btn-group:not(:first-child) > .btn,
            .btn-group-vertical > .btn ~ .btn {
                border-top-left-radius: 0;
                border-top-right-radius: 0;
            }
            .nav {
                display: flex;
                flex-wrap: wrap;
                padding-left: 0;
                margin-bottom: 0;
                list-style: none;
            }
            .nav-link {
                display: block;
                padding: 0.5rem 1rem;
                color: #0d6efd;
                text-decoration: none;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .nav-link {
                    transition: none;
                }
            }
            .nav-link:focus,
            .nav-link:hover {
                color: #0a58ca;
            }
            .nav-link.disabled {
                color: #6c757d;
                pointer-events: none;
                cursor: default;
            }
            .nav-tabs {
                border-bottom: 1px solid #dee2e6;
            }
            .nav-tabs .nav-link {
                margin-bottom: -1px;
                background: 0 0;
                border: 1px solid transparent;
                border-top-left-radius: 0.25rem;
                border-top-right-radius: 0.25rem;
            }
            .nav-tabs .nav-link:focus,
            .nav-tabs .nav-link:hover {
                border-color: #e9ecef #e9ecef #dee2e6;
                isolation: isolate;
            }
            .nav-tabs .nav-link.disabled {
                color: #6c757d;
                background-color: transparent;
                border-color: transparent;
            }
            .nav-tabs .nav-item.show .nav-link,
            .nav-tabs .nav-link.active {
                color: #495057;
                background-color: #fff;
                border-color: #dee2e6 #dee2e6 #fff;
            }
            .nav-tabs .dropdown-menu {
                margin-top: -1px;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
            }
            .nav-pills .nav-link {
                background: 0 0;
                border: 0;
                border-radius: 0.25rem;
            }
            .nav-pills .nav-link.active,
            .nav-pills .show > .nav-link {
                color: #fff;
                background-color: #0d6efd;
            }
            .nav-fill .nav-item,
            .nav-fill > .nav-link {
                flex: 1 1 auto;
                text-align: center;
            }
            .nav-justified .nav-item,
            .nav-justified > .nav-link {
                flex-basis: 0;
                flex-grow: 1;
                text-align: center;
            }
            .nav-fill .nav-item .nav-link,
            .nav-justified .nav-item .nav-link {
                width: 100%;
            }
            .tab-content > .tab-pane {
                display: none;
            }
            .tab-content > .active {
                display: block;
            }
            .navbar {
                position: relative;
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
            }
            .navbar > .container,
            .navbar > .container-fluid,
            .navbar > .container-lg,
            .navbar > .container-md,
            .navbar > .container-sm,
            .navbar > .container-xl,
            .navbar > .container-xxl {
                display: flex;
                flex-wrap: inherit;
                align-items: center;
                justify-content: space-between;
            }
            .navbar-brand {
                padding-top: 0.3125rem;
                padding-bottom: 0.3125rem;
                margin-right: 1rem;
                font-size: 1.25rem;
                text-decoration: none;
                white-space: nowrap;
            }
            .navbar-nav {
                display: flex;
                flex-direction: column;
                padding-left: 0;
                margin-bottom: 0;
                list-style: none;
            }
            .navbar-nav .nav-link {
                padding-right: 0;
                padding-left: 0;
            }
            .navbar-nav .dropdown-menu {
                position: static;
            }
            .navbar-text {
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
            }
            .navbar-collapse {
                flex-basis: 100%;
                flex-grow: 1;
                align-items: center;
            }
            .navbar-toggler {
                padding: 0.25rem 0.75rem;
                font-size: 1.25rem;
                line-height: 1;
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 0.25rem;
                transition: box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .navbar-toggler {
                    transition: none;
                }
            }
            .navbar-toggler:hover {
                text-decoration: none;
            }
            .navbar-toggler:focus {
                text-decoration: none;
                outline: 0;
                box-shadow: 0 0 0 0.25rem;
            }
            .navbar-toggler-icon {
                display: inline-block;
                width: 1.5em;
                height: 1.5em;
                vertical-align: middle;
                background-repeat: no-repeat;
                background-position: center;
                background-size: 100%;
            }
            .navbar-nav-scroll {
                max-height: var(--bs-scroll-height, 75vh);
                overflow-y: auto;
            }
            @media (min-width: 576px) {
                .navbar-expand-sm {
                    flex-wrap: nowrap;
                    justify-content: flex-start;
                }
                .navbar-expand-sm .navbar-nav {
                    flex-direction: row;
                }
                .navbar-expand-sm .navbar-nav .dropdown-menu {
                    position: absolute;
                }
                .navbar-expand-sm .navbar-nav .nav-link {
                    padding-right: 0.5rem;
                    padding-left: 0.5rem;
                }
                .navbar-expand-sm .navbar-nav-scroll {
                    overflow: visible;
                }
                .navbar-expand-sm .navbar-collapse {
                    display: flex !important;
                    flex-basis: auto;
                }
                .navbar-expand-sm .navbar-toggler {
                    display: none;
                }
                .navbar-expand-sm .offcanvas-header {
                    display: none;
                }
                .navbar-expand-sm .offcanvas {
                    position: inherit;
                    bottom: 0;
                    z-index: 1000;
                    flex-grow: 1;
                    visibility: visible !important;
                    background-color: transparent;
                    border-right: 0;
                    border-left: 0;
                    transition: none;
                    transform: none;
                }
                .navbar-expand-sm .offcanvas-bottom,
                .navbar-expand-sm .offcanvas-top {
                    height: auto;
                    border-top: 0;
                    border-bottom: 0;
                }
                .navbar-expand-sm .offcanvas-body {
                    display: flex;
                    flex-grow: 0;
                    padding: 0;
                    overflow-y: visible;
                }
            }
            @media (min-width: 768px) {
                .navbar-expand-md {
                    flex-wrap: nowrap;
                    justify-content: flex-start;
                }
                .navbar-expand-md .navbar-nav {
                    flex-direction: row;
                }
                .navbar-expand-md .navbar-nav .dropdown-menu {
                    position: absolute;
                }
                .navbar-expand-md .navbar-nav .nav-link {
                    padding-right: 0.5rem;
                    padding-left: 0.5rem;
                }
                .navbar-expand-md .navbar-nav-scroll {
                    overflow: visible;
                }
                .navbar-expand-md .navbar-collapse {
                    display: flex !important;
                    flex-basis: auto;
                }
                .navbar-expand-md .navbar-toggler {
                    display: none;
                }
                .navbar-expand-md .offcanvas-header {
                    display: none;
                }
                .navbar-expand-md .offcanvas {
                    position: inherit;
                    bottom: 0;
                    z-index: 1000;
                    flex-grow: 1;
                    visibility: visible !important;
                    background-color: transparent;
                    border-right: 0;
                    border-left: 0;
                    transition: none;
                    transform: none;
                }
                .navbar-expand-md .offcanvas-bottom,
                .navbar-expand-md .offcanvas-top {
                    height: auto;
                    border-top: 0;
                    border-bottom: 0;
                }
                .navbar-expand-md .offcanvas-body {
                    display: flex;
                    flex-grow: 0;
                    padding: 0;
                    overflow-y: visible;
                }
            }
            @media (min-width: 992px) {
                .navbar-expand-lg {
                    flex-wrap: nowrap;
                    justify-content: flex-start;
                }
                .navbar-expand-lg .navbar-nav {
                    flex-direction: row;
                }
                .navbar-expand-lg .navbar-nav .dropdown-menu {
                    position: absolute;
                }
                .navbar-expand-lg .navbar-nav .nav-link {
                    padding-right: 0.5rem;
                    padding-left: 0.5rem;
                }
                .navbar-expand-lg .navbar-nav-scroll {
                    overflow: visible;
                }
                .navbar-expand-lg .navbar-collapse {
                    display: flex !important;
                    flex-basis: auto;
                }
                .navbar-expand-lg .navbar-toggler {
                    display: none;
                }
                .navbar-expand-lg .offcanvas-header {
                    display: none;
                }
                .navbar-expand-lg .offcanvas {
                    position: inherit;
                    bottom: 0;
                    z-index: 1000;
                    flex-grow: 1;
                    visibility: visible !important;
                    background-color: transparent;
                    border-right: 0;
                    border-left: 0;
                    transition: none;
                    transform: none;
                }
                .navbar-expand-lg .offcanvas-bottom,
                .navbar-expand-lg .offcanvas-top {
                    height: auto;
                    border-top: 0;
                    border-bottom: 0;
                }
                .navbar-expand-lg .offcanvas-body {
                    display: flex;
                    flex-grow: 0;
                    padding: 0;
                    overflow-y: visible;
                }
            }
            @media (min-width: 1200px) {
                .navbar-expand-xl {
                    flex-wrap: nowrap;
                    justify-content: flex-start;
                }
                .navbar-expand-xl .navbar-nav {
                    flex-direction: row;
                }
                .navbar-expand-xl .navbar-nav .dropdown-menu {
                    position: absolute;
                }
                .navbar-expand-xl .navbar-nav .nav-link {
                    padding-right: 0.5rem;
                    padding-left: 0.5rem;
                }
                .navbar-expand-xl .navbar-nav-scroll {
                    overflow: visible;
                }
                .navbar-expand-xl .navbar-collapse {
                    display: flex !important;
                    flex-basis: auto;
                }
                .navbar-expand-xl .navbar-toggler {
                    display: none;
                }
                .navbar-expand-xl .offcanvas-header {
                    display: none;
                }
                .navbar-expand-xl .offcanvas {
                    position: inherit;
                    bottom: 0;
                    z-index: 1000;
                    flex-grow: 1;
                    visibility: visible !important;
                    background-color: transparent;
                    border-right: 0;
                    border-left: 0;
                    transition: none;
                    transform: none;
                }
                .navbar-expand-xl .offcanvas-bottom,
                .navbar-expand-xl .offcanvas-top {
                    height: auto;
                    border-top: 0;
                    border-bottom: 0;
                }
                .navbar-expand-xl .offcanvas-body {
                    display: flex;
                    flex-grow: 0;
                    padding: 0;
                    overflow-y: visible;
                }
            }
            @media (min-width: 1400px) {
                .navbar-expand-xxl {
                    flex-wrap: nowrap;
                    justify-content: flex-start;
                }
                .navbar-expand-xxl .navbar-nav {
                    flex-direction: row;
                }
                .navbar-expand-xxl .navbar-nav .dropdown-menu {
                    position: absolute;
                }
                .navbar-expand-xxl .navbar-nav .nav-link {
                    padding-right: 0.5rem;
                    padding-left: 0.5rem;
                }
                .navbar-expand-xxl .navbar-nav-scroll {
                    overflow: visible;
                }
                .navbar-expand-xxl .navbar-collapse {
                    display: flex !important;
                    flex-basis: auto;
                }
                .navbar-expand-xxl .navbar-toggler {
                    display: none;
                }
                .navbar-expand-xxl .offcanvas-header {
                    display: none;
                }
                .navbar-expand-xxl .offcanvas {
                    position: inherit;
                    bottom: 0;
                    z-index: 1000;
                    flex-grow: 1;
                    visibility: visible !important;
                    background-color: transparent;
                    border-right: 0;
                    border-left: 0;
                    transition: none;
                    transform: none;
                }
                .navbar-expand-xxl .offcanvas-bottom,
                .navbar-expand-xxl .offcanvas-top {
                    height: auto;
                    border-top: 0;
                    border-bottom: 0;
                }
                .navbar-expand-xxl .offcanvas-body {
                    display: flex;
                    flex-grow: 0;
                    padding: 0;
                    overflow-y: visible;
                }
            }
            .navbar-expand {
                flex-wrap: nowrap;
                justify-content: flex-start;
            }
            .navbar-expand .navbar-nav {
                flex-direction: row;
            }
            .navbar-expand .navbar-nav .dropdown-menu {
                position: absolute;
            }
            .navbar-expand .navbar-nav .nav-link {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
            .navbar-expand .navbar-nav-scroll {
                overflow: visible;
            }
            .navbar-expand .navbar-collapse {
                display: flex !important;
                flex-basis: auto;
            }
            .navbar-expand .navbar-toggler {
                display: none;
            }
            .navbar-expand .offcanvas-header {
                display: none;
            }
            .navbar-expand .offcanvas {
                position: inherit;
                bottom: 0;
                z-index: 1000;
                flex-grow: 1;
                visibility: visible !important;
                background-color: transparent;
                border-right: 0;
                border-left: 0;
                transition: none;
                transform: none;
            }
            .navbar-expand .offcanvas-bottom,
            .navbar-expand .offcanvas-top {
                height: auto;
                border-top: 0;
                border-bottom: 0;
            }
            .navbar-expand .offcanvas-body {
                display: flex;
                flex-grow: 0;
                padding: 0;
                overflow-y: visible;
            }
            .navbar-light .navbar-brand {
                color: rgba(0, 0, 0, 0.9);
            }
            .navbar-light .navbar-brand:focus,
            .navbar-light .navbar-brand:hover {
                color: rgba(0, 0, 0, 0.9);
            }
            .navbar-light .navbar-nav .nav-link {
                color: rgba(0, 0, 0, 0.55);
            }
            .navbar-light .navbar-nav .nav-link:focus,
            .navbar-light .navbar-nav .nav-link:hover {
                color: rgba(0, 0, 0, 0.7);
            }
            .navbar-light .navbar-nav .nav-link.disabled {
                color: rgba(0, 0, 0, 0.3);
            }
            .navbar-light .navbar-nav .nav-link.active,
            .navbar-light .navbar-nav .show > .nav-link {
                color: rgba(0, 0, 0, 0.9);
            }
            .navbar-light .navbar-toggler {
                color: rgba(0, 0, 0, 0.55);
                border-color: rgba(0, 0, 0, 0.1);
            }
            .navbar-light .navbar-toggler-icon {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%280, 0, 0, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
            }
            .navbar-light .navbar-text {
                color: rgba(0, 0, 0, 0.55);
            }
            .navbar-light .navbar-text a,
            .navbar-light .navbar-text a:focus,
            .navbar-light .navbar-text a:hover {
                color: rgba(0, 0, 0, 0.9);
            }
            .navbar-dark .navbar-brand {
                color: #fff;
            }
            .navbar-dark .navbar-brand:focus,
            .navbar-dark .navbar-brand:hover {
                color: #fff;
            }
            .navbar-dark .navbar-nav .nav-link {
                color: rgba(255, 255, 255, 0.55);
            }
            .navbar-dark .navbar-nav .nav-link:focus,
            .navbar-dark .navbar-nav .nav-link:hover {
                color: rgba(255, 255, 255, 0.75);
            }
            .navbar-dark .navbar-nav .nav-link.disabled {
                color: rgba(255, 255, 255, 0.25);
            }
            .navbar-dark .navbar-nav .nav-link.active,
            .navbar-dark .navbar-nav .show > .nav-link {
                color: #fff;
            }
            .navbar-dark .navbar-toggler {
                color: rgba(255, 255, 255, 0.55);
                border-color: rgba(255, 255, 255, 0.1);
            }
            .navbar-dark .navbar-toggler-icon {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
            }
            .navbar-dark .navbar-text {
                color: rgba(255, 255, 255, 0.55);
            }
            .navbar-dark .navbar-text a,
            .navbar-dark .navbar-text a:focus,
            .navbar-dark .navbar-text a:hover {
                color: #fff;
            }
            .card {
                position: relative;
                display: flex;
                flex-direction: column;
                min-width: 0;
                word-wrap: break-word;
                background-color: #fff;
                background-clip: border-box;
                border: 1px solid rgba(0, 0, 0, 0.125);
                border-radius: 0.25rem;
            }
            .card > hr {
                margin-right: 0;
                margin-left: 0;
            }
            .card > .list-group {
                border-top: inherit;
                border-bottom: inherit;
            }
            .card > .list-group:first-child {
                border-top-width: 0;
                border-top-left-radius: calc(0.25rem - 1px);
                border-top-right-radius: calc(0.25rem - 1px);
            }
            .card > .list-group:last-child {
                border-bottom-width: 0;
                border-bottom-right-radius: calc(0.25rem - 1px);
                border-bottom-left-radius: calc(0.25rem - 1px);
            }
            .card > .card-header + .list-group,
            .card > .list-group + .card-footer {
                border-top: 0;
            }
            .card-body {
                flex: 1 1 auto;
                padding: 1rem 1rem;
            }
            .card-title {
                margin-bottom: 0.5rem;
            }
            .card-subtitle {
                margin-top: -0.25rem;
                margin-bottom: 0;
            }
            .card-text:last-child {
                margin-bottom: 0;
            }
            .card-link + .card-link {
                margin-left: 1rem;
            }
            .card-header {
                padding: 0.5rem 1rem;
                margin-bottom: 0;
                background-color: rgba(0, 0, 0, 0.03);
                border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            }
            .card-header:first-child {
                border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0;
            }
            .card-footer {
                padding: 0.5rem 1rem;
                background-color: rgba(0, 0, 0, 0.03);
                border-top: 1px solid rgba(0, 0, 0, 0.125);
            }
            .card-footer:last-child {
                border-radius: 0 0 calc(0.25rem - 1px) calc(0.25rem - 1px);
            }
            .card-header-tabs {
                margin-right: -0.5rem;
                margin-bottom: -0.5rem;
                margin-left: -0.5rem;
                border-bottom: 0;
            }
            .card-header-pills {
                margin-right: -0.5rem;
                margin-left: -0.5rem;
            }
            .card-img-overlay {
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                padding: 1rem;
                border-radius: calc(0.25rem - 1px);
            }
            .card-img,
            .card-img-bottom,
            .card-img-top {
                width: 100%;
            }
            .card-img,
            .card-img-top {
                border-top-left-radius: calc(0.25rem - 1px);
                border-top-right-radius: calc(0.25rem - 1px);
            }
            .card-img,
            .card-img-bottom {
                border-bottom-right-radius: calc(0.25rem - 1px);
                border-bottom-left-radius: calc(0.25rem - 1px);
            }
            .card-group > .card {
                margin-bottom: 0.75rem;
            }
            @media (min-width: 576px) {
                .card-group {
                    display: flex;
                    flex-flow: row wrap;
                }
                .card-group > .card {
                    flex: 1 0 0%;
                    margin-bottom: 0;
                }
                .card-group > .card + .card {
                    margin-left: 0;
                    border-left: 0;
                }
                .card-group > .card:not(:last-child) {
                    border-top-right-radius: 0;
                    border-bottom-right-radius: 0;
                }
                .card-group > .card:not(:last-child) .card-header,
                .card-group > .card:not(:last-child) .card-img-top {
                    border-top-right-radius: 0;
                }
                .card-group > .card:not(:last-child) .card-footer,
                .card-group > .card:not(:last-child) .card-img-bottom {
                    border-bottom-right-radius: 0;
                }
                .card-group > .card:not(:first-child) {
                    border-top-left-radius: 0;
                    border-bottom-left-radius: 0;
                }
                .card-group > .card:not(:first-child) .card-header,
                .card-group > .card:not(:first-child) .card-img-top {
                    border-top-left-radius: 0;
                }
                .card-group > .card:not(:first-child) .card-footer,
                .card-group > .card:not(:first-child) .card-img-bottom {
                    border-bottom-left-radius: 0;
                }
            }
            .accordion-button {
                position: relative;
                display: flex;
                align-items: center;
                width: 100%;
                padding: 1rem 1.25rem;
                font-size: 1rem;
                color: #212529;
                text-align: left;
                background-color: #fff;
                border: 0;
                border-radius: 0;
                overflow-anchor: none;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out,
                    border-radius 0.15s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .accordion-button {
                    transition: none;
                }
            }
            .accordion-button:not(.collapsed) {
                color: #0c63e4;
                background-color: #e7f1ff;
                box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.125);
            }
            .accordion-button:not(.collapsed)::after {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
                transform: rotate(-180deg);
            }
            .accordion-button::after {
                flex-shrink: 0;
                width: 1.25rem;
                height: 1.25rem;
                margin-left: auto;
                content: "";
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23212529'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-size: 1.25rem;
                transition: transform 0.2s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .accordion-button::after {
                    transition: none;
                }
            }
            .accordion-button:hover {
                z-index: 2;
            }
            .accordion-button:focus {
                z-index: 3;
                border-color: #86b7fe;
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .accordion-header {
                margin-bottom: 0;
            }
            .accordion-item {
                background-color: #fff;
                border: 1px solid rgba(0, 0, 0, 0.125);
            }
            .accordion-item:first-of-type {
                border-top-left-radius: 0.25rem;
                border-top-right-radius: 0.25rem;
            }
            .accordion-item:first-of-type .accordion-button {
                border-top-left-radius: calc(0.25rem - 1px);
                border-top-right-radius: calc(0.25rem - 1px);
            }
            .accordion-item:not(:first-of-type) {
                border-top: 0;
            }
            .accordion-item:last-of-type {
                border-bottom-right-radius: 0.25rem;
                border-bottom-left-radius: 0.25rem;
            }
            .accordion-item:last-of-type .accordion-button.collapsed {
                border-bottom-right-radius: calc(0.25rem - 1px);
                border-bottom-left-radius: calc(0.25rem - 1px);
            }
            .accordion-item:last-of-type .accordion-collapse {
                border-bottom-right-radius: 0.25rem;
                border-bottom-left-radius: 0.25rem;
            }
            .accordion-body {
                padding: 1rem 1.25rem;
            }
            .accordion-flush .accordion-collapse {
                border-width: 0;
            }
            .accordion-flush .accordion-item {
                border-right: 0;
                border-left: 0;
                border-radius: 0;
            }
            .accordion-flush .accordion-item:first-child {
                border-top: 0;
            }
            .accordion-flush .accordion-item:last-child {
                border-bottom: 0;
            }
            .accordion-flush .accordion-item .accordion-button {
                border-radius: 0;
            }
            .breadcrumb {
                display: flex;
                flex-wrap: wrap;
                padding: 0 0;
                margin-bottom: 1rem;
                list-style: none;
            }
            .breadcrumb-item + .breadcrumb-item {
                padding-left: 0.5rem;
            }
            .breadcrumb-item + .breadcrumb-item::before {
                float: left;
                padding-right: 0.5rem;
                color: #6c757d;
                content: var(--bs-breadcrumb-divider, "/");
            }
            .breadcrumb-item.active {
                color: #6c757d;
            }
            .pagination {
                display: flex;
                padding-left: 0;
                list-style: none;
            }
            .page-link {
                position: relative;
                display: block;
                color: #0d6efd;
                text-decoration: none;
                background-color: #fff;
                border: 1px solid #dee2e6;
                transition:
                    color 0.15s ease-in-out,
                    background-color 0.15s ease-in-out,
                    border-color 0.15s ease-in-out,
                    box-shadow 0.15s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .page-link {
                    transition: none;
                }
            }
            .page-link:hover {
                z-index: 2;
                color: #0a58ca;
                background-color: #e9ecef;
                border-color: #dee2e6;
            }
            .page-link:focus {
                z-index: 3;
                color: #0a58ca;
                background-color: #e9ecef;
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            }
            .page-item:not(:first-child) .page-link {
                margin-left: -1px;
            }
            .page-item.active .page-link {
                z-index: 3;
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .page-item.disabled .page-link {
                color: #6c757d;
                pointer-events: none;
                background-color: #fff;
                border-color: #dee2e6;
            }
            .page-link {
                padding: 0.375rem 0.75rem;
            }
            .page-item:first-child .page-link {
                border-top-left-radius: 0.25rem;
                border-bottom-left-radius: 0.25rem;
            }
            .page-item:last-child .page-link {
                border-top-right-radius: 0.25rem;
                border-bottom-right-radius: 0.25rem;
            }
            .pagination-lg .page-link {
                padding: 0.75rem 1.5rem;
                font-size: 1.25rem;
            }
            .pagination-lg .page-item:first-child .page-link {
                border-top-left-radius: 0.3rem;
                border-bottom-left-radius: 0.3rem;
            }
            .pagination-lg .page-item:last-child .page-link {
                border-top-right-radius: 0.3rem;
                border-bottom-right-radius: 0.3rem;
            }
            .pagination-sm .page-link {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
            }
            .pagination-sm .page-item:first-child .page-link {
                border-top-left-radius: 0.2rem;
                border-bottom-left-radius: 0.2rem;
            }
            .pagination-sm .page-item:last-child .page-link {
                border-top-right-radius: 0.2rem;
                border-bottom-right-radius: 0.2rem;
            }
            .badge {
                display: inline-block;
                padding: 0.35em 0.65em;
                font-size: 0.75em;
                font-weight: 700;
                line-height: 1;
                color: #fff;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: 0.25rem;
            }
            .badge:empty {
                display: none;
            }
            .btn .badge {
                position: relative;
                top: -1px;
            }
            .alert {
                position: relative;
                padding: 1rem 1rem;
                margin-bottom: 1rem;
                border: 1px solid transparent;
                border-radius: 0.25rem;
            }
            .alert-heading {
                color: inherit;
            }
            .alert-link {
                font-weight: 700;
            }
            .alert-dismissible {
                padding-right: 3rem;
            }
            .alert-dismissible .btn-close {
                position: absolute;
                top: 0;
                right: 0;
                z-index: 2;
                padding: 1.25rem 1rem;
            }
            .alert-primary {
                color: #084298;
                background-color: #cfe2ff;
                border-color: #b6d4fe;
            }
            .alert-primary .alert-link {
                color: #06357a;
            }
            .alert-secondary {
                color: #41464b;
                background-color: #e2e3e5;
                border-color: #d3d6d8;
            }
            .alert-secondary .alert-link {
                color: #34383c;
            }
            .alert-success {
                color: #0f5132;
                background-color: #d1e7dd;
                border-color: #badbcc;
            }
            .alert-success .alert-link {
                color: #0c4128;
            }
            .alert-info {
                color: #055160;
                background-color: #cff4fc;
                border-color: #b6effb;
            }
            .alert-info .alert-link {
                color: #04414d;
            }
            .alert-warning {
                color: #664d03;
                background-color: #fff3cd;
                border-color: #ffecb5;
            }
            .alert-warning .alert-link {
                color: #523e02;
            }
            .alert-danger {
                color: #842029;
                background-color: #f8d7da;
                border-color: #f5c2c7;
            }
            .alert-danger .alert-link {
                color: #6a1a21;
            }
            .alert-light {
                color: #636464;
                background-color: #fefefe;
                border-color: #fdfdfe;
            }
            .alert-light .alert-link {
                color: #4f5050;
            }
            .alert-dark {
                color: #141619;
                background-color: #d3d3d4;
                border-color: #bcbebf;
            }
            .alert-dark .alert-link {
                color: #101214;
            }
            @-webkit-keyframes progress-bar-stripes {
                0% {
                    background-position-x: 1rem;
                }
            }
            @keyframes progress-bar-stripes {
                0% {
                    background-position-x: 1rem;
                }
            }
            .progress {
                display: flex;
                height: 1rem;
                overflow: hidden;
                font-size: 0.75rem;
                background-color: #e9ecef;
                border-radius: 0.25rem;
            }
            .progress-bar {
                display: flex;
                flex-direction: column;
                justify-content: center;
                overflow: hidden;
                color: #fff;
                text-align: center;
                white-space: nowrap;
                background-color: #0d6efd;
                transition: width 0.6s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .progress-bar {
                    transition: none;
                }
            }
            .progress-bar-striped {
                background-image: linear-gradient(
                    45deg,
                    rgba(255, 255, 255, 0.15) 25%,
                    transparent 25%,
                    transparent 50%,
                    rgba(255, 255, 255, 0.15) 50%,
                    rgba(255, 255, 255, 0.15) 75%,
                    transparent 75%,
                    transparent
                );
                background-size: 1rem 1rem;
            }
            .progress-bar-animated {
                -webkit-animation: 1s linear infinite progress-bar-stripes;
                animation: 1s linear infinite progress-bar-stripes;
            }
            @media (prefers-reduced-motion: reduce) {
                .progress-bar-animated {
                    -webkit-animation: none;
                    animation: none;
                }
            }
            .list-group {
                display: flex;
                flex-direction: column;
                padding-left: 0;
                margin-bottom: 0;
                border-radius: 0.25rem;
            }
            .list-group-numbered {
                list-style-type: none;
                counter-reset: section;
            }
            .list-group-numbered > li::before {
                content: counters(section, ".") ". ";
                counter-increment: section;
            }
            .list-group-item-action {
                width: 100%;
                color: #495057;
                text-align: inherit;
            }
            .list-group-item-action:focus,
            .list-group-item-action:hover {
                z-index: 1;
                color: #495057;
                text-decoration: none;
                background-color: #f8f9fa;
            }
            .list-group-item-action:active {
                color: #212529;
                background-color: #e9ecef;
            }
            .list-group-item {
                position: relative;
                display: block;
                padding: 0.5rem 1rem;
                color: #212529;
                text-decoration: none;
                background-color: #fff;
                border: 1px solid rgba(0, 0, 0, 0.125);
            }
            .list-group-item:first-child {
                border-top-left-radius: inherit;
                border-top-right-radius: inherit;
            }
            .list-group-item:last-child {
                border-bottom-right-radius: inherit;
                border-bottom-left-radius: inherit;
            }
            .list-group-item.disabled,
            .list-group-item:disabled {
                color: #6c757d;
                pointer-events: none;
                background-color: #fff;
            }
            .list-group-item.active {
                z-index: 2;
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
            }
            .list-group-item + .list-group-item {
                border-top-width: 0;
            }
            .list-group-item + .list-group-item.active {
                margin-top: -1px;
                border-top-width: 1px;
            }
            .list-group-horizontal {
                flex-direction: row;
            }
            .list-group-horizontal > .list-group-item:first-child {
                border-bottom-left-radius: 0.25rem;
                border-top-right-radius: 0;
            }
            .list-group-horizontal > .list-group-item:last-child {
                border-top-right-radius: 0.25rem;
                border-bottom-left-radius: 0;
            }
            .list-group-horizontal > .list-group-item.active {
                margin-top: 0;
            }
            .list-group-horizontal > .list-group-item + .list-group-item {
                border-top-width: 1px;
                border-left-width: 0;
            }
            .list-group-horizontal > .list-group-item + .list-group-item.active {
                margin-left: -1px;
                border-left-width: 1px;
            }
            @media (min-width: 576px) {
                .list-group-horizontal-sm {
                    flex-direction: row;
                }
                .list-group-horizontal-sm > .list-group-item:first-child {
                    border-bottom-left-radius: 0.25rem;
                    border-top-right-radius: 0;
                }
                .list-group-horizontal-sm > .list-group-item:last-child {
                    border-top-right-radius: 0.25rem;
                    border-bottom-left-radius: 0;
                }
                .list-group-horizontal-sm > .list-group-item.active {
                    margin-top: 0;
                }
                .list-group-horizontal-sm > .list-group-item + .list-group-item {
                    border-top-width: 1px;
                    border-left-width: 0;
                }
                .list-group-horizontal-sm > .list-group-item + .list-group-item.active {
                    margin-left: -1px;
                    border-left-width: 1px;
                }
            }
            @media (min-width: 768px) {
                .list-group-horizontal-md {
                    flex-direction: row;
                }
                .list-group-horizontal-md > .list-group-item:first-child {
                    border-bottom-left-radius: 0.25rem;
                    border-top-right-radius: 0;
                }
                .list-group-horizontal-md > .list-group-item:last-child {
                    border-top-right-radius: 0.25rem;
                    border-bottom-left-radius: 0;
                }
                .list-group-horizontal-md > .list-group-item.active {
                    margin-top: 0;
                }
                .list-group-horizontal-md > .list-group-item + .list-group-item {
                    border-top-width: 1px;
                    border-left-width: 0;
                }
                .list-group-horizontal-md > .list-group-item + .list-group-item.active {
                    margin-left: -1px;
                    border-left-width: 1px;
                }
            }
            @media (min-width: 992px) {
                .list-group-horizontal-lg {
                    flex-direction: row;
                }
                .list-group-horizontal-lg > .list-group-item:first-child {
                    border-bottom-left-radius: 0.25rem;
                    border-top-right-radius: 0;
                }
                .list-group-horizontal-lg > .list-group-item:last-child {
                    border-top-right-radius: 0.25rem;
                    border-bottom-left-radius: 0;
                }
                .list-group-horizontal-lg > .list-group-item.active {
                    margin-top: 0;
                }
                .list-group-horizontal-lg > .list-group-item + .list-group-item {
                    border-top-width: 1px;
                    border-left-width: 0;
                }
                .list-group-horizontal-lg > .list-group-item + .list-group-item.active {
                    margin-left: -1px;
                    border-left-width: 1px;
                }
            }
            @media (min-width: 1200px) {
                .list-group-horizontal-xl {
                    flex-direction: row;
                }
                .list-group-horizontal-xl > .list-group-item:first-child {
                    border-bottom-left-radius: 0.25rem;
                    border-top-right-radius: 0;
                }
                .list-group-horizontal-xl > .list-group-item:last-child {
                    border-top-right-radius: 0.25rem;
                    border-bottom-left-radius: 0;
                }
                .list-group-horizontal-xl > .list-group-item.active {
                    margin-top: 0;
                }
                .list-group-horizontal-xl > .list-group-item + .list-group-item {
                    border-top-width: 1px;
                    border-left-width: 0;
                }
                .list-group-horizontal-xl > .list-group-item + .list-group-item.active {
                    margin-left: -1px;
                    border-left-width: 1px;
                }
            }
            @media (min-width: 1400px) {
                .list-group-horizontal-xxl {
                    flex-direction: row;
                }
                .list-group-horizontal-xxl > .list-group-item:first-child {
                    border-bottom-left-radius: 0.25rem;
                    border-top-right-radius: 0;
                }
                .list-group-horizontal-xxl > .list-group-item:last-child {
                    border-top-right-radius: 0.25rem;
                    border-bottom-left-radius: 0;
                }
                .list-group-horizontal-xxl > .list-group-item.active {
                    margin-top: 0;
                }
                .list-group-horizontal-xxl > .list-group-item + .list-group-item {
                    border-top-width: 1px;
                    border-left-width: 0;
                }
                .list-group-horizontal-xxl > .list-group-item + .list-group-item.active {
                    margin-left: -1px;
                    border-left-width: 1px;
                }
            }
            .list-group-flush {
                border-radius: 0;
            }
            .list-group-flush > .list-group-item {
                border-width: 0 0 1px;
            }
            .list-group-flush > .list-group-item:last-child {
                border-bottom-width: 0;
            }
            .list-group-item-primary {
                color: #084298;
                background-color: #cfe2ff;
            }
            .list-group-item-primary.list-group-item-action:focus,
            .list-group-item-primary.list-group-item-action:hover {
                color: #084298;
                background-color: #bacbe6;
            }
            .list-group-item-primary.list-group-item-action.active {
                color: #fff;
                background-color: #084298;
                border-color: #084298;
            }
            .list-group-item-secondary {
                color: #41464b;
                background-color: #e2e3e5;
            }
            .list-group-item-secondary.list-group-item-action:focus,
            .list-group-item-secondary.list-group-item-action:hover {
                color: #41464b;
                background-color: #cbccce;
            }
            .list-group-item-secondary.list-group-item-action.active {
                color: #fff;
                background-color: #41464b;
                border-color: #41464b;
            }
            .list-group-item-success {
                color: #0f5132;
                background-color: #d1e7dd;
            }
            .list-group-item-success.list-group-item-action:focus,
            .list-group-item-success.list-group-item-action:hover {
                color: #0f5132;
                background-color: #bcd0c7;
            }
            .list-group-item-success.list-group-item-action.active {
                color: #fff;
                background-color: #0f5132;
                border-color: #0f5132;
            }
            .list-group-item-info {
                color: #055160;
                background-color: #cff4fc;
            }
            .list-group-item-info.list-group-item-action:focus,
            .list-group-item-info.list-group-item-action:hover {
                color: #055160;
                background-color: #badce3;
            }
            .list-group-item-info.list-group-item-action.active {
                color: #fff;
                background-color: #055160;
                border-color: #055160;
            }
            .list-group-item-warning {
                color: #664d03;
                background-color: #fff3cd;
            }
            .list-group-item-warning.list-group-item-action:focus,
            .list-group-item-warning.list-group-item-action:hover {
                color: #664d03;
                background-color: #e6dbb9;
            }
            .list-group-item-warning.list-group-item-action.active {
                color: #fff;
                background-color: #664d03;
                border-color: #664d03;
            }
            .list-group-item-danger {
                color: #842029;
                background-color: #f8d7da;
            }
            .list-group-item-danger.list-group-item-action:focus,
            .list-group-item-danger.list-group-item-action:hover {
                color: #842029;
                background-color: #dfc2c4;
            }
            .list-group-item-danger.list-group-item-action.active {
                color: #fff;
                background-color: #842029;
                border-color: #842029;
            }
            .list-group-item-light {
                color: #636464;
                background-color: #fefefe;
            }
            .list-group-item-light.list-group-item-action:focus,
            .list-group-item-light.list-group-item-action:hover {
                color: #636464;
                background-color: #e5e5e5;
            }
            .list-group-item-light.list-group-item-action.active {
                color: #fff;
                background-color: #636464;
                border-color: #636464;
            }
            .list-group-item-dark {
                color: #141619;
                background-color: #d3d3d4;
            }
            .list-group-item-dark.list-group-item-action:focus,
            .list-group-item-dark.list-group-item-action:hover {
                color: #141619;
                background-color: #bebebf;
            }
            .list-group-item-dark.list-group-item-action.active {
                color: #fff;
                background-color: #141619;
                border-color: #141619;
            }
            .btn-close {
                box-sizing: content-box;
                width: 1em;
                height: 1em;
                padding: 0.25em 0.25em;
                color: #000;
                background: transparent
                    url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23000'%3e%3cpath d='M.293.293a1 1 0 011.414 0L8 6.586 14.293.293a1 1 0 111.414 1.414L9.414 8l6.293 6.293a1 1 0 01-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 01-1.414-1.414L6.586 8 .293 1.707a1 1 0 010-1.414z'/%3e%3c/svg%3e")
                    center/1em auto no-repeat;
                border: 0;
                border-radius: 0.25rem;
                opacity: 0.5;
            }
            .btn-close:hover {
                color: #000;
                text-decoration: none;
                opacity: 0.75;
            }
            .btn-close:focus {
                outline: 0;
                box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
                opacity: 1;
            }
            .btn-close.disabled,
            .btn-close:disabled {
                pointer-events: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none;
                opacity: 0.25;
            }
            .btn-close-white {
                filter: invert(1) grayscale(100%) brightness(200%);
            }
            .toast {
                width: 350px;
                max-width: 100%;
                font-size: 0.875rem;
                pointer-events: auto;
                background-color: rgba(255, 255, 255, 0.85);
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.1);
                box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
                border-radius: 0.25rem;
            }
            .toast.showing {
                opacity: 0;
            }
            .toast:not(.show) {
                display: none;
            }
            .toast-container {
                width: -webkit-max-content;
                width: -moz-max-content;
                width: max-content;
                max-width: 100%;
                pointer-events: none;
            }
            .toast-container > :not(:last-child) {
                margin-bottom: 0.75rem;
            }
            .toast-header {
                display: flex;
                align-items: center;
                padding: 0.5rem 0.75rem;
                color: #6c757d;
                background-color: rgba(255, 255, 255, 0.85);
                background-clip: padding-box;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                border-top-left-radius: calc(0.25rem - 1px);
                border-top-right-radius: calc(0.25rem - 1px);
            }
            .toast-header .btn-close {
                margin-right: -0.375rem;
                margin-left: 0.75rem;
            }
            .toast-body {
                padding: 0.75rem;
                word-wrap: break-word;
            }
            .modal {
                position: fixed;
                top: 0;
                left: 0;
                z-index: 1055;
                display: none;
                width: 100%;
                height: 100%;
                overflow-x: hidden;
                overflow-y: auto;
                outline: 0;
            }
            .modal-dialog {
                position: relative;
                width: auto;
                margin: 0.5rem;
                pointer-events: none;
            }
            .modal.fade .modal-dialog {
                transition: transform 0.3s ease-out;
                transform: translate(0, -50px);
            }
            @media (prefers-reduced-motion: reduce) {
                .modal.fade .modal-dialog {
                    transition: none;
                }
            }
            .modal.show .modal-dialog {
                transform: none;
            }
            .modal.modal-static .modal-dialog {
                transform: scale(1.02);
            }
            .modal-dialog-scrollable {
                height: calc(100% - 1rem);
            }
            .modal-dialog-scrollable .modal-content {
                max-height: 100%;
                overflow: hidden;
            }
            .modal-dialog-scrollable .modal-body {
                overflow-y: auto;
            }
            .modal-dialog-centered {
                display: flex;
                align-items: center;
                min-height: calc(100% - 1rem);
            }
            .modal-content {
                position: relative;
                display: flex;
                flex-direction: column;
                width: 100%;
                pointer-events: auto;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 0.3rem;
                outline: 0;
            }
            .modal-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                z-index: 1050;
                width: 100vw;
                height: 100vh;
                background-color: #000;
            }
            .modal-backdrop.fade {
                opacity: 0;
            }
            .modal-backdrop.show {
                opacity: 0.5;
            }
            .modal-header {
                display: flex;
                flex-shrink: 0;
                align-items: center;
                justify-content: space-between;
                padding: 1rem 1rem;
                border-bottom: 1px solid #dee2e6;
                border-top-left-radius: calc(0.3rem - 1px);
                border-top-right-radius: calc(0.3rem - 1px);
            }
            .modal-header .btn-close {
                padding: 0.5rem 0.5rem;
                margin: -0.5rem -0.5rem -0.5rem auto;
            }
            .modal-title {
                margin-bottom: 0;
                line-height: 1.5;
            }
            .modal-body {
                position: relative;
                flex: 1 1 auto;
                padding: 1rem;
            }
            .modal-footer {
                display: flex;
                flex-wrap: wrap;
                flex-shrink: 0;
                align-items: center;
                justify-content: flex-end;
                padding: 0.75rem;
                border-top: 1px solid #dee2e6;
                border-bottom-right-radius: calc(0.3rem - 1px);
                border-bottom-left-radius: calc(0.3rem - 1px);
            }
            .modal-footer > * {
                margin: 0.25rem;
            }
            @media (min-width: 576px) {
                .modal-dialog {
                    max-width: 500px;
                    margin: 1.75rem auto;
                }
                .modal-dialog-scrollable {
                    height: calc(100% - 3.5rem);
                }
                .modal-dialog-centered {
                    min-height: calc(100% - 3.5rem);
                }
                .modal-sm {
                    max-width: 300px;
                }
            }
            @media (min-width: 992px) {
                .modal-lg,
                .modal-xl {
                    max-width: 800px;
                }
            }
            @media (min-width: 1200px) {
                .modal-xl {
                    max-width: 1140px;
                }
            }
            .modal-fullscreen {
                width: 100vw;
                max-width: none;
                height: 100%;
                margin: 0;
            }
            .modal-fullscreen .modal-content {
                height: 100%;
                border: 0;
                border-radius: 0;
            }
            .modal-fullscreen .modal-header {
                border-radius: 0;
            }
            .modal-fullscreen .modal-body {
                overflow-y: auto;
            }
            .modal-fullscreen .modal-footer {
                border-radius: 0;
            }
            @media (max-width: 575.98px) {
                .modal-fullscreen-sm-down {
                    width: 100vw;
                    max-width: none;
                    height: 100%;
                    margin: 0;
                }
                .modal-fullscreen-sm-down .modal-content {
                    height: 100%;
                    border: 0;
                    border-radius: 0;
                }
                .modal-fullscreen-sm-down .modal-header {
                    border-radius: 0;
                }
                .modal-fullscreen-sm-down .modal-body {
                    overflow-y: auto;
                }
                .modal-fullscreen-sm-down .modal-footer {
                    border-radius: 0;
                }
            }
            @media (max-width: 767.98px) {
                .modal-fullscreen-md-down {
                    width: 100vw;
                    max-width: none;
                    height: 100%;
                    margin: 0;
                }
                .modal-fullscreen-md-down .modal-content {
                    height: 100%;
                    border: 0;
                    border-radius: 0;
                }
                .modal-fullscreen-md-down .modal-header {
                    border-radius: 0;
                }
                .modal-fullscreen-md-down .modal-body {
                    overflow-y: auto;
                }
                .modal-fullscreen-md-down .modal-footer {
                    border-radius: 0;
                }
            }
            @media (max-width: 991.98px) {
                .modal-fullscreen-lg-down {
                    width: 100vw;
                    max-width: none;
                    height: 100%;
                    margin: 0;
                }
                .modal-fullscreen-lg-down .modal-content {
                    height: 100%;
                    border: 0;
                    border-radius: 0;
                }
                .modal-fullscreen-lg-down .modal-header {
                    border-radius: 0;
                }
                .modal-fullscreen-lg-down .modal-body {
                    overflow-y: auto;
                }
                .modal-fullscreen-lg-down .modal-footer {
                    border-radius: 0;
                }
            }
            @media (max-width: 1199.98px) {
                .modal-fullscreen-xl-down {
                    width: 100vw;
                    max-width: none;
                    height: 100%;
                    margin: 0;
                }
                .modal-fullscreen-xl-down .modal-content {
                    height: 100%;
                    border: 0;
                    border-radius: 0;
                }
                .modal-fullscreen-xl-down .modal-header {
                    border-radius: 0;
                }
                .modal-fullscreen-xl-down .modal-body {
                    overflow-y: auto;
                }
                .modal-fullscreen-xl-down .modal-footer {
                    border-radius: 0;
                }
            }
            @media (max-width: 1399.98px) {
                .modal-fullscreen-xxl-down {
                    width: 100vw;
                    max-width: none;
                    height: 100%;
                    margin: 0;
                }
                .modal-fullscreen-xxl-down .modal-content {
                    height: 100%;
                    border: 0;
                    border-radius: 0;
                }
                .modal-fullscreen-xxl-down .modal-header {
                    border-radius: 0;
                }
                .modal-fullscreen-xxl-down .modal-body {
                    overflow-y: auto;
                }
                .modal-fullscreen-xxl-down .modal-footer {
                    border-radius: 0;
                }
            }
            .tooltip {
                position: absolute;
                z-index: 1080;
                display: block;
                margin: 0;
                font-family: var(--bs-font-sans-serif);
                font-style: normal;
                font-weight: 400;
                line-height: 1.5;
                text-align: left;
                text-align: start;
                text-decoration: none;
                text-shadow: none;
                text-transform: none;
                letter-spacing: normal;
                word-break: normal;
                word-spacing: normal;
                white-space: normal;
                line-break: auto;
                font-size: 0.875rem;
                word-wrap: break-word;
                opacity: 0;
            }
            .tooltip.show {
                opacity: 0.9;
            }
            .tooltip .tooltip-arrow {
                position: absolute;
                display: block;
                width: 0.8rem;
                height: 0.4rem;
            }
            .tooltip .tooltip-arrow::before {
                position: absolute;
                content: "";
                border-color: transparent;
                border-style: solid;
            }
            .bs-tooltip-auto[data-popper-placement^="top"],
            .bs-tooltip-top {
                padding: 0.4rem 0;
            }
            .bs-tooltip-auto[data-popper-placement^="top"] .tooltip-arrow,
            .bs-tooltip-top .tooltip-arrow {
                bottom: 0;
            }
            .bs-tooltip-auto[data-popper-placement^="top"] .tooltip-arrow::before,
            .bs-tooltip-top .tooltip-arrow::before {
                top: -1px;
                border-width: 0.4rem 0.4rem 0;
                border-top-color: #000;
            }
            .bs-tooltip-auto[data-popper-placement^="right"],
            .bs-tooltip-end {
                padding: 0 0.4rem;
            }
            .bs-tooltip-auto[data-popper-placement^="right"] .tooltip-arrow,
            .bs-tooltip-end .tooltip-arrow {
                left: 0;
                width: 0.4rem;
                height: 0.8rem;
            }
            .bs-tooltip-auto[data-popper-placement^="right"] .tooltip-arrow::before,
            .bs-tooltip-end .tooltip-arrow::before {
                right: -1px;
                border-width: 0.4rem 0.4rem 0.4rem 0;
                border-right-color: #000;
            }
            .bs-tooltip-auto[data-popper-placement^="bottom"],
            .bs-tooltip-bottom {
                padding: 0.4rem 0;
            }
            .bs-tooltip-auto[data-popper-placement^="bottom"] .tooltip-arrow,
            .bs-tooltip-bottom .tooltip-arrow {
                top: 0;
            }
            .bs-tooltip-auto[data-popper-placement^="bottom"] .tooltip-arrow::before,
            .bs-tooltip-bottom .tooltip-arrow::before {
                bottom: -1px;
                border-width: 0 0.4rem 0.4rem;
                border-bottom-color: #000;
            }
            .bs-tooltip-auto[data-popper-placement^="left"],
            .bs-tooltip-start {
                padding: 0 0.4rem;
            }
            .bs-tooltip-auto[data-popper-placement^="left"] .tooltip-arrow,
            .bs-tooltip-start .tooltip-arrow {
                right: 0;
                width: 0.4rem;
                height: 0.8rem;
            }
            .bs-tooltip-auto[data-popper-placement^="left"] .tooltip-arrow::before,
            .bs-tooltip-start .tooltip-arrow::before {
                left: -1px;
                border-width: 0.4rem 0 0.4rem 0.4rem;
                border-left-color: #000;
            }
            .tooltip-inner {
                max-width: 200px;
                padding: 0.25rem 0.5rem;
                color: #fff;
                text-align: center;
                background-color: #000;
                border-radius: 0.25rem;
            }
            .popover {
                position: absolute;
                top: 0;
                left: 0;
                z-index: 1070;
                display: block;
                max-width: 276px;
                font-family: var(--bs-font-sans-serif);
                font-style: normal;
                font-weight: 400;
                line-height: 1.5;
                text-align: left;
                text-align: start;
                text-decoration: none;
                text-shadow: none;
                text-transform: none;
                letter-spacing: normal;
                word-break: normal;
                word-spacing: normal;
                white-space: normal;
                line-break: auto;
                font-size: 0.875rem;
                word-wrap: break-word;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 0.3rem;
            }
            .popover .popover-arrow {
                position: absolute;
                display: block;
                width: 1rem;
                height: 0.5rem;
            }
            .popover .popover-arrow::after,
            .popover .popover-arrow::before {
                position: absolute;
                display: block;
                content: "";
                border-color: transparent;
                border-style: solid;
            }
            .bs-popover-auto[data-popper-placement^="top"] > .popover-arrow,
            .bs-popover-top > .popover-arrow {
                bottom: calc(-0.5rem - 1px);
            }
            .bs-popover-auto[data-popper-placement^="top"] > .popover-arrow::before,
            .bs-popover-top > .popover-arrow::before {
                bottom: 0;
                border-width: 0.5rem 0.5rem 0;
                border-top-color: rgba(0, 0, 0, 0.25);
            }
            .bs-popover-auto[data-popper-placement^="top"] > .popover-arrow::after,
            .bs-popover-top > .popover-arrow::after {
                bottom: 1px;
                border-width: 0.5rem 0.5rem 0;
                border-top-color: #fff;
            }
            .bs-popover-auto[data-popper-placement^="right"] > .popover-arrow,
            .bs-popover-end > .popover-arrow {
                left: calc(-0.5rem - 1px);
                width: 0.5rem;
                height: 1rem;
            }
            .bs-popover-auto[data-popper-placement^="right"] > .popover-arrow::before,
            .bs-popover-end > .popover-arrow::before {
                left: 0;
                border-width: 0.5rem 0.5rem 0.5rem 0;
                border-right-color: rgba(0, 0, 0, 0.25);
            }
            .bs-popover-auto[data-popper-placement^="right"] > .popover-arrow::after,
            .bs-popover-end > .popover-arrow::after {
                left: 1px;
                border-width: 0.5rem 0.5rem 0.5rem 0;
                border-right-color: #fff;
            }
            .bs-popover-auto[data-popper-placement^="bottom"] > .popover-arrow,
            .bs-popover-bottom > .popover-arrow {
                top: calc(-0.5rem - 1px);
            }
            .bs-popover-auto[data-popper-placement^="bottom"] > .popover-arrow::before,
            .bs-popover-bottom > .popover-arrow::before {
                top: 0;
                border-width: 0 0.5rem 0.5rem 0.5rem;
                border-bottom-color: rgba(0, 0, 0, 0.25);
            }
            .bs-popover-auto[data-popper-placement^="bottom"] > .popover-arrow::after,
            .bs-popover-bottom > .popover-arrow::after {
                top: 1px;
                border-width: 0 0.5rem 0.5rem 0.5rem;
                border-bottom-color: #fff;
            }
            .bs-popover-auto[data-popper-placement^="bottom"] .popover-header::before,
            .bs-popover-bottom .popover-header::before {
                position: absolute;
                top: 0;
                left: 50%;
                display: block;
                width: 1rem;
                margin-left: -0.5rem;
                content: "";
                border-bottom: 1px solid #f0f0f0;
            }
            .bs-popover-auto[data-popper-placement^="left"] > .popover-arrow,
            .bs-popover-start > .popover-arrow {
                right: calc(-0.5rem - 1px);
                width: 0.5rem;
                height: 1rem;
            }
            .bs-popover-auto[data-popper-placement^="left"] > .popover-arrow::before,
            .bs-popover-start > .popover-arrow::before {
                right: 0;
                border-width: 0.5rem 0 0.5rem 0.5rem;
                border-left-color: rgba(0, 0, 0, 0.25);
            }
            .bs-popover-auto[data-popper-placement^="left"] > .popover-arrow::after,
            .bs-popover-start > .popover-arrow::after {
                right: 1px;
                border-width: 0.5rem 0 0.5rem 0.5rem;
                border-left-color: #fff;
            }
            .popover-header {
                padding: 0.5rem 1rem;
                margin-bottom: 0;
                font-size: 1rem;
                background-color: #f0f0f0;
                border-bottom: 1px solid rgba(0, 0, 0, 0.2);
                border-top-left-radius: calc(0.3rem - 1px);
                border-top-right-radius: calc(0.3rem - 1px);
            }
            .popover-header:empty {
                display: none;
            }
            .popover-body {
                padding: 1rem 1rem;
                color: #212529;
            }
            .carousel {
                position: relative;
            }
            .carousel.pointer-event {
                touch-action: pan-y;
            }
            .carousel-inner {
                position: relative;
                width: 100%;
                overflow: hidden;
            }
            .carousel-inner::after {
                display: block;
                clear: both;
                content: "";
            }
            .carousel-item {
                position: relative;
                display: none;
                float: left;
                width: 100%;
                margin-right: -100%;
                -webkit-backface-visibility: hidden;
                backface-visibility: hidden;
                transition: transform 0.6s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .carousel-item {
                    transition: none;
                }
            }
            .carousel-item-next,
            .carousel-item-prev,
            .carousel-item.active {
                display: block;
            }
            .active.carousel-item-end,
            .carousel-item-next:not(.carousel-item-start) {
                transform: translateX(100%);
            }
            .active.carousel-item-start,
            .carousel-item-prev:not(.carousel-item-end) {
                transform: translateX(-100%);
            }
            .carousel-fade .carousel-item {
                opacity: 0;
                transition-property: opacity;
                transform: none;
            }
            .carousel-fade .carousel-item-next.carousel-item-start,
            .carousel-fade .carousel-item-prev.carousel-item-end,
            .carousel-fade .carousel-item.active {
                z-index: 1;
                opacity: 1;
            }
            .carousel-fade .active.carousel-item-end,
            .carousel-fade .active.carousel-item-start {
                z-index: 0;
                opacity: 0;
                transition: opacity 0s 0.6s;
            }
            @media (prefers-reduced-motion: reduce) {
                .carousel-fade .active.carousel-item-end,
                .carousel-fade .active.carousel-item-start {
                    transition: none;
                }
            }
            .carousel-control-next,
            .carousel-control-prev {
                position: absolute;
                top: 0;
                bottom: 0;
                z-index: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 15%;
                padding: 0;
                color: #fff;
                text-align: center;
                background: 0 0;
                border: 0;
                opacity: 0.5;
                transition: opacity 0.15s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .carousel-control-next,
                .carousel-control-prev {
                    transition: none;
                }
            }
            .carousel-control-next:focus,
            .carousel-control-next:hover,
            .carousel-control-prev:focus,
            .carousel-control-prev:hover {
                color: #fff;
                text-decoration: none;
                outline: 0;
                opacity: 0.9;
            }
            .carousel-control-prev {
                left: 0;
            }
            .carousel-control-next {
                right: 0;
            }
            .carousel-control-next-icon,
            .carousel-control-prev-icon {
                display: inline-block;
                width: 2rem;
                height: 2rem;
                background-repeat: no-repeat;
                background-position: 50%;
                background-size: 100% 100%;
            }
            .carousel-control-prev-icon {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
            }
            .carousel-control-next-icon {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
            }
            .carousel-indicators {
                position: absolute;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 2;
                display: flex;
                justify-content: center;
                padding: 0;
                margin-right: 15%;
                margin-bottom: 1rem;
                margin-left: 15%;
                list-style: none;
            }
            .carousel-indicators [data-bs-target] {
                box-sizing: content-box;
                flex: 0 1 auto;
                width: 30px;
                height: 3px;
                padding: 0;
                margin-right: 3px;
                margin-left: 3px;
                text-indent: -999px;
                cursor: pointer;
                background-color: #fff;
                background-clip: padding-box;
                border: 0;
                border-top: 10px solid transparent;
                border-bottom: 10px solid transparent;
                opacity: 0.5;
                transition: opacity 0.6s ease;
            }
            @media (prefers-reduced-motion: reduce) {
                .carousel-indicators [data-bs-target] {
                    transition: none;
                }
            }
            .carousel-indicators .active {
                opacity: 1;
            }
            .carousel-caption {
                position: absolute;
                right: 15%;
                bottom: 1.25rem;
                left: 15%;
                padding-top: 1.25rem;
                padding-bottom: 1.25rem;
                color: #fff;
                text-align: center;
            }
            .carousel-dark .carousel-control-next-icon,
            .carousel-dark .carousel-control-prev-icon {
                filter: invert(1) grayscale(100);
            }
            .carousel-dark .carousel-indicators [data-bs-target] {
                background-color: #000;
            }
            .carousel-dark .carousel-caption {
                color: #000;
            }
            @-webkit-keyframes spinner-border {
                to {
                    transform: rotate(360deg);
                }
            }
            @keyframes spinner-border {
                to {
                    transform: rotate(360deg);
                }
            }
            .spinner-border {
                display: inline-block;
                width: 2rem;
                height: 2rem;
                vertical-align: -0.125em;
                border: 0.25em solid currentColor;
                border-right-color: transparent;
                border-radius: 50%;
                -webkit-animation: 0.75s linear infinite spinner-border;
                animation: 0.75s linear infinite spinner-border;
            }
            .spinner-border-sm {
                width: 1rem;
                height: 1rem;
                border-width: 0.2em;
            }
            @-webkit-keyframes spinner-grow {
                0% {
                    transform: scale(0);
                }
                50% {
                    opacity: 1;
                    transform: none;
                }
            }
            @keyframes spinner-grow {
                0% {
                    transform: scale(0);
                }
                50% {
                    opacity: 1;
                    transform: none;
                }
            }
            .spinner-grow {
                display: inline-block;
                width: 2rem;
                height: 2rem;
                vertical-align: -0.125em;
                background-color: currentColor;
                border-radius: 50%;
                opacity: 0;
                -webkit-animation: 0.75s linear infinite spinner-grow;
                animation: 0.75s linear infinite spinner-grow;
            }
            .spinner-grow-sm {
                width: 1rem;
                height: 1rem;
            }
            @media (prefers-reduced-motion: reduce) {
                .spinner-border,
                .spinner-grow {
                    -webkit-animation-duration: 1.5s;
                    animation-duration: 1.5s;
                }
            }
            .offcanvas {
                position: fixed;
                bottom: 0;
                z-index: 1045;
                display: flex;
                flex-direction: column;
                max-width: 100%;
                visibility: hidden;
                background-color: #fff;
                background-clip: padding-box;
                outline: 0;
                transition: transform 0.3s ease-in-out;
            }
            @media (prefers-reduced-motion: reduce) {
                .offcanvas {
                    transition: none;
                }
            }
            .offcanvas-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                z-index: 1040;
                width: 100vw;
                height: 100vh;
                background-color: #000;
            }
            .offcanvas-backdrop.fade {
                opacity: 0;
            }
            .offcanvas-backdrop.show {
                opacity: 0.5;
            }
            .offcanvas-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 1rem 1rem;
            }
            .offcanvas-header .btn-close {
                padding: 0.5rem 0.5rem;
                margin-top: -0.5rem;
                margin-right: -0.5rem;
                margin-bottom: -0.5rem;
            }
            .offcanvas-title {
                margin-bottom: 0;
                line-height: 1.5;
            }
            .offcanvas-body {
                flex-grow: 1;
                padding: 1rem 1rem;
                overflow-y: auto;
            }
            .offcanvas-start {
                top: 0;
                left: 0;
                width: 400px;
                border-right: 1px solid rgba(0, 0, 0, 0.2);
                transform: translateX(-100%);
            }
            .offcanvas-end {
                top: 0;
                right: 0;
                width: 400px;
                border-left: 1px solid rgba(0, 0, 0, 0.2);
                transform: translateX(100%);
            }
            .offcanvas-top {
                top: 0;
                right: 0;
                left: 0;
                height: 30vh;
                max-height: 100%;
                border-bottom: 1px solid rgba(0, 0, 0, 0.2);
                transform: translateY(-100%);
            }
            .offcanvas-bottom {
                right: 0;
                left: 0;
                height: 30vh;
                max-height: 100%;
                border-top: 1px solid rgba(0, 0, 0, 0.2);
                transform: translateY(100%);
            }
            .offcanvas.show {
                transform: none;
            }
            .placeholder {
                display: inline-block;
                min-height: 1em;
                vertical-align: middle;
                cursor: wait;
                background-color: currentColor;
                opacity: 0.5;
            }
            .placeholder.btn::before {
                display: inline-block;
                content: "";
            }
            .placeholder-xs {
                min-height: 0.6em;
            }
            .placeholder-sm {
                min-height: 0.8em;
            }
            .placeholder-lg {
                min-height: 1.2em;
            }
            .placeholder-glow .placeholder {
                -webkit-animation: placeholder-glow 2s ease-in-out infinite;
                animation: placeholder-glow 2s ease-in-out infinite;
            }
            @-webkit-keyframes placeholder-glow {
                50% {
                    opacity: 0.2;
                }
            }
            @keyframes placeholder-glow {
                50% {
                    opacity: 0.2;
                }
            }
            .placeholder-wave {
                -webkit-mask-image: linear-gradient(130deg, #000 55%, rgba(0, 0, 0, 0.8) 75%, #000 95%);
                mask-image: linear-gradient(130deg, #000 55%, rgba(0, 0, 0, 0.8) 75%, #000 95%);
                -webkit-mask-size: 200% 100%;
                mask-size: 200% 100%;
                -webkit-animation: placeholder-wave 2s linear infinite;
                animation: placeholder-wave 2s linear infinite;
            }
            @-webkit-keyframes placeholder-wave {
                100% {
                    -webkit-mask-position: -200% 0%;
                    mask-position: -200% 0%;
                }
            }
            @keyframes placeholder-wave {
                100% {
                    -webkit-mask-position: -200% 0%;
                    mask-position: -200% 0%;
                }
            }
            .clearfix::after {
                display: block;
                clear: both;
                content: "";
            }
            .link-primary {
                color: #0d6efd;
            }
            .link-primary:focus,
            .link-primary:hover {
                color: #0a58ca;
            }
            .link-secondary {
                color: #6c757d;
            }
            .link-secondary:focus,
            .link-secondary:hover {
                color: #565e64;
            }
            .link-success {
                color: #198754;
            }
            .link-success:focus,
            .link-success:hover {
                color: #146c43;
            }
            .link-info {
                color: #0dcaf0;
            }
            .link-info:focus,
            .link-info:hover {
                color: #3dd5f3;
            }
            .link-warning {
                color: #ffc107;
            }
            .link-warning:focus,
            .link-warning:hover {
                color: #ffcd39;
            }
            .link-danger {
                color: #dc3545;
            }
            .link-danger:focus,
            .link-danger:hover {
                color: #b02a37;
            }
            .link-light {
                color: #f8f9fa;
            }
            .link-light:focus,
            .link-light:hover {
                color: #f9fafb;
            }
            .link-dark {
                color: #212529;
            }
            .link-dark:focus,
            .link-dark:hover {
                color: #1a1e21;
            }
            .ratio {
                position: relative;
                width: 100%;
            }
            .ratio::before {
                display: block;
                padding-top: var(--bs-aspect-ratio);
                content: "";
            }
            .ratio > * {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
            }
            .ratio-1x1 {
                --bs-aspect-ratio: 100%;
            }
            .ratio-4x3 {
                --bs-aspect-ratio: calc(3 / 4 * 100%);
            }
            .ratio-16x9 {
                --bs-aspect-ratio: calc(9 / 16 * 100%);
            }
            .ratio-21x9 {
                --bs-aspect-ratio: calc(9 / 21 * 100%);
            }
            .fixed-top {
                position: fixed;
                top: 0;
                right: 0;
                left: 0;
                z-index: 1030;
            }
            .fixed-bottom {
                position: fixed;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1030;
            }
            .sticky-top {
                position: -webkit-sticky;
                position: sticky;
                top: 0;
                z-index: 1020;
            }
            @media (min-width: 576px) {
                .sticky-sm-top {
                    position: -webkit-sticky;
                    position: sticky;
                    top: 0;
                    z-index: 1020;
                }
            }
            @media (min-width: 768px) {
                .sticky-md-top {
                    position: -webkit-sticky;
                    position: sticky;
                    top: 0;
                    z-index: 1020;
                }
            }
            @media (min-width: 992px) {
                .sticky-lg-top {
                    position: -webkit-sticky;
                    position: sticky;
                    top: 0;
                    z-index: 1020;
                }
            }
            @media (min-width: 1200px) {
                .sticky-xl-top {
                    position: -webkit-sticky;
                    position: sticky;
                    top: 0;
                    z-index: 1020;
                }
            }
            @media (min-width: 1400px) {
                .sticky-xxl-top {
                    position: -webkit-sticky;
                    position: sticky;
                    top: 0;
                    z-index: 1020;
                }
            }
            .hstack {
                display: flex;
                flex-direction: row;
                align-items: center;
                align-self: stretch;
            }
            .vstack {
                display: flex;
                flex: 1 1 auto;
                flex-direction: column;
                align-self: stretch;
            }
            .visually-hidden,
            .visually-hidden-focusable:not(:focus):not(:focus-within) {
                position: absolute !important;
                width: 1px !important;
                height: 1px !important;
                padding: 0 !important;
                margin: -1px !important;
                overflow: hidden !important;
                clip: rect(0, 0, 0, 0) !important;
                white-space: nowrap !important;
                border: 0 !important;
            }
            .stretched-link::after {
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1;
                content: "";
            }
            .text-truncate {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .vr {
                display: inline-block;
                align-self: stretch;
                width: 1px;
                min-height: 1em;
                background-color: currentColor;
                opacity: 0.25;
            }
            .align-baseline {
                vertical-align: baseline !important;
            }
            .align-top {
                vertical-align: top !important;
            }
            .align-middle {
                vertical-align: middle !important;
            }
            .align-bottom {
                vertical-align: bottom !important;
            }
            .align-text-bottom {
                vertical-align: text-bottom !important;
            }
            .align-text-top {
                vertical-align: text-top !important;
            }
            .float-start {
                float: left !important;
            }
            .float-end {
                float: right !important;
            }
            .float-none {
                float: none !important;
            }
            .opacity-0 {
                opacity: 0 !important;
            }
            .opacity-25 {
                opacity: 0.25 !important;
            }
            .opacity-50 {
                opacity: 0.5 !important;
            }
            .opacity-75 {
                opacity: 0.75 !important;
            }
            .opacity-100 {
                opacity: 1 !important;
            }
            .overflow-auto {
                overflow: auto !important;
            }
            .overflow-hidden {
                overflow: hidden !important;
            }
            .overflow-visible {
                overflow: visible !important;
            }
            .overflow-scroll {
                overflow: scroll !important;
            }
            .d-inline {
                display: inline !important;
            }
            .d-inline-block {
                display: inline-block !important;
            }
            .d-block {
                display: block !important;
            }
            .d-grid {
                display: grid !important;
            }
            .d-table {
                display: table !important;
            }
            .d-table-row {
                display: table-row !important;
            }
            .d-table-cell {
                display: table-cell !important;
            }
            .d-flex {
                display: flex !important;
            }
            .d-inline-flex {
                display: inline-flex !important;
            }
            .d-none {
                display: none !important;
            }
            .shadow {
                box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
            }
            .shadow-sm {
                box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075) !important;
            }
            .shadow-lg {
                box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
            }
            .shadow-none {
                box-shadow: none !important;
            }
            .position-static {
                position: static !important;
            }
            .position-relative {
                position: relative !important;
            }
            .position-absolute {
                position: absolute !important;
            }
            .position-fixed {
                position: fixed !important;
            }
            .position-sticky {
                position: -webkit-sticky !important;
                position: sticky !important;
            }
            .top-0 {
                top: 0 !important;
            }
            .top-50 {
                top: 50% !important;
            }
            .top-100 {
                top: 100% !important;
            }
            .bottom-0 {
                bottom: 0 !important;
            }
            .bottom-50 {
                bottom: 50% !important;
            }
            .bottom-100 {
                bottom: 100% !important;
            }
            .start-0 {
                left: 0 !important;
            }
            .start-50 {
                left: 50% !important;
            }
            .start-100 {
                left: 100% !important;
            }
            .end-0 {
                right: 0 !important;
            }
            .end-50 {
                right: 50% !important;
            }
            .end-100 {
                right: 100% !important;
            }
            .translate-middle {
                transform: translate(-50%, -50%) !important;
            }
            .translate-middle-x {
                transform: translateX(-50%) !important;
            }
            .translate-middle-y {
                transform: translateY(-50%) !important;
            }
            .border {
                border: 1px solid #dee2e6 !important;
            }
            .border-0 {
                border: 0 !important;
            }
            .border-top {
                border-top: 1px solid #dee2e6 !important;
            }
            .border-top-0 {
                border-top: 0 !important;
            }
            .border-end {
                border-right: 1px solid #dee2e6 !important;
            }
            .border-end-0 {
                border-right: 0 !important;
            }
            .border-bottom {
                border-bottom: 1px solid #dee2e6 !important;
            }
            .border-bottom-0 {
                border-bottom: 0 !important;
            }
            .border-start {
                border-left: 1px solid #dee2e6 !important;
            }
            .border-start-0 {
                border-left: 0 !important;
            }
            .border-primary {
                border-color: #0d6efd !important;
            }
            .border-secondary {
                border-color: #6c757d !important;
            }
            .border-success {
                border-color: #198754 !important;
            }
            .border-info {
                border-color: #0dcaf0 !important;
            }
            .border-warning {
                border-color: #ffc107 !important;
            }
            .border-danger {
                border-color: #dc3545 !important;
            }
            .border-light {
                border-color: #f8f9fa !important;
            }
            .border-dark {
                border-color: #212529 !important;
            }
            .border-white {
                border-color: #fff !important;
            }
            .border-1 {
                border-width: 1px !important;
            }
            .border-2 {
                border-width: 2px !important;
            }
            .border-3 {
                border-width: 3px !important;
            }
            .border-4 {
                border-width: 4px !important;
            }
            .border-5 {
                border-width: 5px !important;
            }
            .w-25 {
                width: 25% !important;
            }
            .w-50 {
                width: 50% !important;
            }
            .w-75 {
                width: 75% !important;
            }
            .w-100 {
                width: 100% !important;
            }
            .w-auto {
                width: auto !important;
            }
            .mw-100 {
                max-width: 100% !important;
            }
            .vw-100 {
                width: 100vw !important;
            }
            .min-vw-100 {
                min-width: 100vw !important;
            }
            .h-25 {
                height: 25% !important;
            }
            .h-50 {
                height: 50% !important;
            }
            .h-75 {
                height: 75% !important;
            }
            .h-100 {
                height: 100% !important;
            }
            .h-auto {
                height: auto !important;
            }
            .mh-100 {
                max-height: 100% !important;
            }
            .vh-100 {
                height: 100vh !important;
            }
            .min-vh-100 {
                min-height: 100vh !important;
            }
            .flex-fill {
                flex: 1 1 auto !important;
            }
            .flex-row {
                flex-direction: row !important;
            }
            .flex-column {
                flex-direction: column !important;
            }
            .flex-row-reverse {
                flex-direction: row-reverse !important;
            }
            .flex-column-reverse {
                flex-direction: column-reverse !important;
            }
            .flex-grow-0 {
                flex-grow: 0 !important;
            }
            .flex-grow-1 {
                flex-grow: 1 !important;
            }
            .flex-shrink-0 {
                flex-shrink: 0 !important;
            }
            .flex-shrink-1 {
                flex-shrink: 1 !important;
            }
            .flex-wrap {
                flex-wrap: wrap !important;
            }
            .flex-nowrap {
                flex-wrap: nowrap !important;
            }
            .flex-wrap-reverse {
                flex-wrap: wrap-reverse !important;
            }
            .gap-0 {
                gap: 0 !important;
            }
            .gap-1 {
                gap: 0.25rem !important;
            }
            .gap-2 {
                gap: 0.5rem !important;
            }
            .gap-3 {
                gap: 1rem !important;
            }
            .gap-4 {
                gap: 1.5rem !important;
            }
            .gap-5 {
                gap: 3rem !important;
            }
            .justify-content-start {
                justify-content: flex-start !important;
            }
            .justify-content-end {
                justify-content: flex-end !important;
            }
            .justify-content-center {
                justify-content: center !important;
            }
            .justify-content-between {
                justify-content: space-between !important;
            }
            .justify-content-around {
                justify-content: space-around !important;
            }
            .justify-content-evenly {
                justify-content: space-evenly !important;
            }
            .align-items-start {
                align-items: flex-start !important;
            }
            .align-items-end {
                align-items: flex-end !important;
            }
            .align-items-center {
                align-items: center !important;
            }
            .align-items-baseline {
                align-items: baseline !important;
            }
            .align-items-stretch {
                align-items: stretch !important;
            }
            .align-content-start {
                align-content: flex-start !important;
            }
            .align-content-end {
                align-content: flex-end !important;
            }
            .align-content-center {
                align-content: center !important;
            }
            .align-content-between {
                align-content: space-between !important;
            }
            .align-content-around {
                align-content: space-around !important;
            }
            .align-content-stretch {
                align-content: stretch !important;
            }
            .align-self-auto {
                align-self: auto !important;
            }
            .align-self-start {
                align-self: flex-start !important;
            }
            .align-self-end {
                align-self: flex-end !important;
            }
            .align-self-center {
                align-self: center !important;
            }
            .align-self-baseline {
                align-self: baseline !important;
            }
            .align-self-stretch {
                align-self: stretch !important;
            }
            .order-first {
                order: -1 !important;
            }
            .order-0 {
                order: 0 !important;
            }
            .order-1 {
                order: 1 !important;
            }
            .order-2 {
                order: 2 !important;
            }
            .order-3 {
                order: 3 !important;
            }
            .order-4 {
                order: 4 !important;
            }
            .order-5 {
                order: 5 !important;
            }
            .order-last {
                order: 6 !important;
            }
            .m-0 {
                margin: 0 !important;
            }
            .m-1 {
                margin: 0.25rem !important;
            }
            .m-2 {
                margin: 0.5rem !important;
            }
            .m-3 {
                margin: 1rem !important;
            }
            .m-4 {
                margin: 1.5rem !important;
            }
            .m-5 {
                margin: 3rem !important;
            }
            .m-auto {
                margin: auto !important;
            }
            .mx-0 {
                margin-right: 0 !important;
                margin-left: 0 !important;
            }
            .mx-1 {
                margin-right: 0.25rem !important;
                margin-left: 0.25rem !important;
            }
            .mx-2 {
                margin-right: 0.5rem !important;
                margin-left: 0.5rem !important;
            }
            .mx-3 {
                margin-right: 1rem !important;
                margin-left: 1rem !important;
            }
            .mx-4 {
                margin-right: 1.5rem !important;
                margin-left: 1.5rem !important;
            }
            .mx-5 {
                margin-right: 3rem !important;
                margin-left: 3rem !important;
            }
            .mx-auto {
                margin-right: auto !important;
                margin-left: auto !important;
            }
            .my-0 {
                margin-top: 0 !important;
                margin-bottom: 0 !important;
            }
            .my-1 {
                margin-top: 0.25rem !important;
                margin-bottom: 0.25rem !important;
            }
            .my-2 {
                margin-top: 0.5rem !important;
                margin-bottom: 0.5rem !important;
            }
            .my-3 {
                margin-top: 1rem !important;
                margin-bottom: 1rem !important;
            }
            .my-4 {
                margin-top: 1.5rem !important;
                margin-bottom: 1.5rem !important;
            }
            .my-5 {
                margin-top: 3rem !important;
                margin-bottom: 3rem !important;
            }
            .my-auto {
                margin-top: auto !important;
                margin-bottom: auto !important;
            }
            .mt-0 {
                margin-top: 0 !important;
            }
            .mt-1 {
                margin-top: 0.25rem !important;
            }
            .mt-2 {
                margin-top: 0.5rem !important;
            }
            .mt-3 {
                margin-top: 1rem !important;
            }
            .mt-4 {
                margin-top: 1.5rem !important;
            }
            .mt-5 {
                margin-top: 3rem !important;
            }
            .mt-auto {
                margin-top: auto !important;
            }
            .me-0 {
                margin-right: 0 !important;
            }
            .me-1 {
                margin-right: 0.25rem !important;
            }
            .me-2 {
                margin-right: 0.5rem !important;
            }
            .me-3 {
                margin-right: 1rem !important;
            }
            .me-4 {
                margin-right: 1.5rem !important;
            }
            .me-5 {
                margin-right: 3rem !important;
            }
            .me-auto {
                margin-right: auto !important;
            }
            .mb-0 {
                margin-bottom: 0 !important;
            }
            .mb-1 {
                margin-bottom: 0.25rem !important;
            }
            .mb-2 {
                margin-bottom: 0.5rem !important;
            }
            .mb-3 {
                margin-bottom: 1rem !important;
            }
            .mb-4 {
                margin-bottom: 1.5rem !important;
            }
            .mb-5 {
                margin-bottom: 3rem !important;
            }
            .mb-auto {
                margin-bottom: auto !important;
            }
            .ms-0 {
                margin-left: 0 !important;
            }
            .ms-1 {
                margin-left: 0.25rem !important;
            }
            .ms-2 {
                margin-left: 0.5rem !important;
            }
            .ms-3 {
                margin-left: 1rem !important;
            }
            .ms-4 {
                margin-left: 1.5rem !important;
            }
            .ms-5 {
                margin-left: 3rem !important;
            }
            .ms-auto {
                margin-left: auto !important;
            }
            .p-0 {
                padding: 0 !important;
            }
            .p-1 {
                padding: 0.25rem !important;
            }
            .p-2 {
                padding: 0.5rem !important;
            }
            .p-3 {
                padding: 1rem !important;
            }
            .p-4 {
                padding: 1.5rem !important;
            }
            .p-5 {
                padding: 3rem !important;
            }
            .px-0 {
                padding-right: 0 !important;
                padding-left: 0 !important;
            }
            .px-1 {
                padding-right: 0.25rem !important;
                padding-left: 0.25rem !important;
            }
            .px-2 {
                padding-right: 0.5rem !important;
                padding-left: 0.5rem !important;
            }
            .px-3 {
                padding-right: 1rem !important;
                padding-left: 1rem !important;
            }
            .px-4 {
                padding-right: 1.5rem !important;
                padding-left: 1.5rem !important;
            }
            .px-5 {
                padding-right: 3rem !important;
                padding-left: 3rem !important;
            }
            .py-0 {
                padding-top: 0 !important;
                padding-bottom: 0 !important;
            }
            .py-1 {
                padding-top: 0.25rem !important;
                padding-bottom: 0.25rem !important;
            }
            .py-2 {
                padding-top: 0.5rem !important;
                padding-bottom: 0.5rem !important;
            }
            .py-3 {
                padding-top: 1rem !important;
                padding-bottom: 1rem !important;
            }
            .py-4 {
                padding-top: 1.5rem !important;
                padding-bottom: 1.5rem !important;
            }
            .py-5 {
                padding-top: 3rem !important;
                padding-bottom: 3rem !important;
            }
            .pt-0 {
                padding-top: 0 !important;
            }
            .pt-1 {
                padding-top: 0.25rem !important;
            }
            .pt-2 {
                padding-top: 0.5rem !important;
            }
            .pt-3 {
                padding-top: 1rem !important;
            }
            .pt-4 {
                padding-top: 1.5rem !important;
            }
            .pt-5 {
                padding-top: 3rem !important;
            }
            .pe-0 {
                padding-right: 0 !important;
            }
            .pe-1 {
                padding-right: 0.25rem !important;
            }
            .pe-2 {
                padding-right: 0.5rem !important;
            }
            .pe-3 {
                padding-right: 1rem !important;
            }
            .pe-4 {
                padding-right: 1.5rem !important;
            }
            .pe-5 {
                padding-right: 3rem !important;
            }
            .pb-0 {
                padding-bottom: 0 !important;
            }
            .pb-1 {
                padding-bottom: 0.25rem !important;
            }
            .pb-2 {
                padding-bottom: 0.5rem !important;
            }
            .pb-3 {
                padding-bottom: 1rem !important;
            }
            .pb-4 {
                padding-bottom: 1.5rem !important;
            }
            .pb-5 {
                padding-bottom: 3rem !important;
            }
            .ps-0 {
                padding-left: 0 !important;
            }
            .ps-1 {
                padding-left: 0.25rem !important;
            }
            .ps-2 {
                padding-left: 0.5rem !important;
            }
            .ps-3 {
                padding-left: 1rem !important;
            }
            .ps-4 {
                padding-left: 1.5rem !important;
            }
            .ps-5 {
                padding-left: 3rem !important;
            }
            .font-monospace {
                font-family: var(--bs-font-monospace) !important;
            }
            .fs-1 {
                font-size: calc(1.375rem + 1.5vw) !important;
            }
            .fs-2 {
                font-size: calc(1.325rem + 0.9vw) !important;
            }
            .fs-3 {
                font-size: calc(1.3rem + 0.6vw) !important;
            }
            .fs-4 {
                font-size: calc(1.275rem + 0.3vw) !important;
            }
            .fs-5 {
                font-size: 1.25rem !important;
            }
            .fs-6 {
                font-size: 1rem !important;
            }
            .fst-italic {
                font-style: italic !important;
            }
            .fst-normal {
                font-style: normal !important;
            }
            .fw-light {
                font-weight: 300 !important;
            }
            .fw-lighter {
                font-weight: lighter !important;
            }
            .fw-normal {
                font-weight: 400 !important;
            }
            .fw-bold {
                font-weight: 700 !important;
            }
            .fw-bolder {
                font-weight: bolder !important;
            }
            .lh-1 {
                line-height: 1 !important;
            }
            .lh-sm {
                line-height: 1.25 !important;
            }
            .lh-base {
                line-height: 1.5 !important;
            }
            .lh-lg {
                line-height: 2 !important;
            }
            .text-start {
                text-align: left !important;
            }
            .text-end {
                text-align: right !important;
            }
            .text-center {
                text-align: center !important;
            }
            .text-decoration-none {
                text-decoration: none !important;
            }
            .text-decoration-underline {
                text-decoration: underline !important;
            }
            .text-decoration-line-through {
                text-decoration: line-through !important;
            }
            .text-lowercase {
                text-transform: lowercase !important;
            }
            .text-uppercase {
                text-transform: uppercase !important;
            }
            .text-capitalize {
                text-transform: capitalize !important;
            }
            .text-wrap {
                white-space: normal !important;
            }
            .text-nowrap {
                white-space: nowrap !important;
            }
            .text-break {
                word-wrap: break-word !important;
                word-break: break-word !important;
            }
            .text-primary {
                --bs-text-opacity: 1;
               
				color: rgb(155 54 118) !important;
            }
            .text-secondary {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-secondary-rgb), var(--bs-text-opacity)) !important;
            }
            .text-success {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-success-rgb), var(--bs-text-opacity)) !important;
            }
            .text-info {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-info-rgb), var(--bs-text-opacity)) !important;
            }
            .text-warning {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-warning-rgb), var(--bs-text-opacity)) !important;
            }
            .text-danger {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-danger-rgb), var(--bs-text-opacity)) !important;
            }
            .text-light {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-light-rgb), var(--bs-text-opacity)) !important;
            }
            .text-dark {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-dark-rgb), var(--bs-text-opacity)) !important;
            }
            .text-black {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-black-rgb), var(--bs-text-opacity)) !important;
            }
            .text-white {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-white-rgb), var(--bs-text-opacity)) !important;
            }
            .text-body {
                --bs-text-opacity: 1;
                color: rgba(var(--bs-body-rgb), var(--bs-text-opacity)) !important;
            }
            .text-muted {
                --bs-text-opacity: 1;
                color: #6c757d !important;
            }
            .text-black-50 {
                --bs-text-opacity: 1;
                color: rgba(0, 0, 0, 0.5) !important;
            }
            .text-white-50 {
                --bs-text-opacity: 1;
                color: rgba(255, 255, 255, 0.5) !important;
            }
            .text-reset {
                --bs-text-opacity: 1;
                color: inherit !important;
            }
            .text-opacity-25 {
                --bs-text-opacity: 0.25;
            }
            .text-opacity-50 {
                --bs-text-opacity: 0.5;
            }
            .text-opacity-75 {
                --bs-text-opacity: 0.75;
            }
            .text-opacity-100 {
                --bs-text-opacity: 1;
            }
            .bg-primary {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-primary-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-secondary {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-secondary-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-success {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-success-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-info {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-info-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-warning {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-warning-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-danger {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-danger-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-light {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-dark {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-dark-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-black {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-black-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-white {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-white-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-body {
                --bs-bg-opacity: 1;
                background-color: rgba(var(--bs-body-rgb), var(--bs-bg-opacity)) !important;
            }
            .bg-transparent {
                --bs-bg-opacity: 1;
                background-color: transparent !important;
            }
            .bg-opacity-10 {
                --bs-bg-opacity: 0.1;
            }
            .bg-opacity-25 {
                --bs-bg-opacity: 0.25;
            }
            .bg-opacity-50 {
                --bs-bg-opacity: 0.5;
            }
            .bg-opacity-75 {
                --bs-bg-opacity: 0.75;
            }
            .bg-opacity-100 {
                --bs-bg-opacity: 1;
            }
            .bg-gradient {
                background-image: var(--bs-gradient) !important;
            }
            .user-select-all {
                -webkit-user-select: all !important;
                -moz-user-select: all !important;
                user-select: all !important;
            }
            .user-select-auto {
                -webkit-user-select: auto !important;
                -moz-user-select: auto !important;
                user-select: auto !important;
            }
            .user-select-none {
                -webkit-user-select: none !important;
                -moz-user-select: none !important;
                user-select: none !important;
            }
            .pe-none {
                pointer-events: none !important;
            }
            .pe-auto {
                pointer-events: auto !important;
            }
            .rounded {
                border-radius: 0.25rem !important;
            }
            .rounded-0 {
                border-radius: 0 !important;
            }
            .rounded-1 {
                border-radius: 0.2rem !important;
            }
            .rounded-2 {
                border-radius: 0.25rem !important;
            }
            .rounded-3 {
                border-radius: 0.3rem !important;
            }
            .rounded-circle {
                border-radius: 50% !important;
            }
            .rounded-pill {
                border-radius: 50rem !important;
            }
            .rounded-top {
                border-top-left-radius: 0.25rem !important;
                border-top-right-radius: 0.25rem !important;
            }
            .rounded-end {
                border-top-right-radius: 0.25rem !important;
                border-bottom-right-radius: 0.25rem !important;
            }
            .rounded-bottom {
                border-bottom-right-radius: 0.25rem !important;
                border-bottom-left-radius: 0.25rem !important;
            }
            .rounded-start {
                border-bottom-left-radius: 0.25rem !important;
                border-top-left-radius: 0.25rem !important;
            }
            .visible {
                visibility: visible !important;
            }
            .invisible {
                visibility: hidden !important;
            }
            @media (min-width: 576px) {
                .float-sm-start {
                    float: left !important;
                }
                .float-sm-end {
                    float: right !important;
                }
                .float-sm-none {
                    float: none !important;
                }
                .d-sm-inline {
                    display: inline !important;
                }
                .d-sm-inline-block {
                    display: inline-block !important;
                }
                .d-sm-block {
                    display: block !important;
                }
                .d-sm-grid {
                    display: grid !important;
                }
                .d-sm-table {
                    display: table !important;
                }
                .d-sm-table-row {
                    display: table-row !important;
                }
                .d-sm-table-cell {
                    display: table-cell !important;
                }
                .d-sm-flex {
                    display: flex !important;
                }
                .d-sm-inline-flex {
                    display: inline-flex !important;
                }
                .d-sm-none {
                    display: none !important;
                }
                .flex-sm-fill {
                    flex: 1 1 auto !important;
                }
                .flex-sm-row {
                    flex-direction: row !important;
                }
                .flex-sm-column {
                    flex-direction: column !important;
                }
                .flex-sm-row-reverse {
                    flex-direction: row-reverse !important;
                }
                .flex-sm-column-reverse {
                    flex-direction: column-reverse !important;
                }
                .flex-sm-grow-0 {
                    flex-grow: 0 !important;
                }
                .flex-sm-grow-1 {
                    flex-grow: 1 !important;
                }
                .flex-sm-shrink-0 {
                    flex-shrink: 0 !important;
                }
                .flex-sm-shrink-1 {
                    flex-shrink: 1 !important;
                }
                .flex-sm-wrap {
                    flex-wrap: wrap !important;
                }
                .flex-sm-nowrap {
                    flex-wrap: nowrap !important;
                }
                .flex-sm-wrap-reverse {
                    flex-wrap: wrap-reverse !important;
                }
                .gap-sm-0 {
                    gap: 0 !important;
                }
                .gap-sm-1 {
                    gap: 0.25rem !important;
                }
                .gap-sm-2 {
                    gap: 0.5rem !important;
                }
                .gap-sm-3 {
                    gap: 1rem !important;
                }
                .gap-sm-4 {
                    gap: 1.5rem !important;
                }
                .gap-sm-5 {
                    gap: 3rem !important;
                }
                .justify-content-sm-start {
                    justify-content: flex-start !important;
                }
                .justify-content-sm-end {
                    justify-content: flex-end !important;
                }
                .justify-content-sm-center {
                    justify-content: center !important;
                }
                .justify-content-sm-between {
                    justify-content: space-between !important;
                }
                .justify-content-sm-around {
                    justify-content: space-around !important;
                }
                .justify-content-sm-evenly {
                    justify-content: space-evenly !important;
                }
                .align-items-sm-start {
                    align-items: flex-start !important;
                }
                .align-items-sm-end {
                    align-items: flex-end !important;
                }
                .align-items-sm-center {
                    align-items: center !important;
                }
                .align-items-sm-baseline {
                    align-items: baseline !important;
                }
                .align-items-sm-stretch {
                    align-items: stretch !important;
                }
                .align-content-sm-start {
                    align-content: flex-start !important;
                }
                .align-content-sm-end {
                    align-content: flex-end !important;
                }
                .align-content-sm-center {
                    align-content: center !important;
                }
                .align-content-sm-between {
                    align-content: space-between !important;
                }
                .align-content-sm-around {
                    align-content: space-around !important;
                }
                .align-content-sm-stretch {
                    align-content: stretch !important;
                }
                .align-self-sm-auto {
                    align-self: auto !important;
                }
                .align-self-sm-start {
                    align-self: flex-start !important;
                }
                .align-self-sm-end {
                    align-self: flex-end !important;
                }
                .align-self-sm-center {
                    align-self: center !important;
                }
                .align-self-sm-baseline {
                    align-self: baseline !important;
                }
                .align-self-sm-stretch {
                    align-self: stretch !important;
                }
                .order-sm-first {
                    order: -1 !important;
                }
                .order-sm-0 {
                    order: 0 !important;
                }
                .order-sm-1 {
                    order: 1 !important;
                }
                .order-sm-2 {
                    order: 2 !important;
                }
                .order-sm-3 {
                    order: 3 !important;
                }
                .order-sm-4 {
                    order: 4 !important;
                }
                .order-sm-5 {
                    order: 5 !important;
                }
                .order-sm-last {
                    order: 6 !important;
                }
                .m-sm-0 {
                    margin: 0 !important;
                }
                .m-sm-1 {
                    margin: 0.25rem !important;
                }
                .m-sm-2 {
                    margin: 0.5rem !important;
                }
                .m-sm-3 {
                    margin: 1rem !important;
                }
                .m-sm-4 {
                    margin: 1.5rem !important;
                }
                .m-sm-5 {
                    margin: 3rem !important;
                }
                .m-sm-auto {
                    margin: auto !important;
                }
                .mx-sm-0 {
                    margin-right: 0 !important;
                    margin-left: 0 !important;
                }
                .mx-sm-1 {
                    margin-right: 0.25rem !important;
                    margin-left: 0.25rem !important;
                }
                .mx-sm-2 {
                    margin-right: 0.5rem !important;
                    margin-left: 0.5rem !important;
                }
                .mx-sm-3 {
                    margin-right: 1rem !important;
                    margin-left: 1rem !important;
                }
                .mx-sm-4 {
                    margin-right: 1.5rem !important;
                    margin-left: 1.5rem !important;
                }
                .mx-sm-5 {
                    margin-right: 3rem !important;
                    margin-left: 3rem !important;
                }
                .mx-sm-auto {
                    margin-right: auto !important;
                    margin-left: auto !important;
                }
                .my-sm-0 {
                    margin-top: 0 !important;
                    margin-bottom: 0 !important;
                }
                .my-sm-1 {
                    margin-top: 0.25rem !important;
                    margin-bottom: 0.25rem !important;
                }
                .my-sm-2 {
                    margin-top: 0.5rem !important;
                    margin-bottom: 0.5rem !important;
                }
                .my-sm-3 {
                    margin-top: 1rem !important;
                    margin-bottom: 1rem !important;
                }
                .my-sm-4 {
                    margin-top: 1.5rem !important;
                    margin-bottom: 1.5rem !important;
                }
                .my-sm-5 {
                    margin-top: 3rem !important;
                    margin-bottom: 3rem !important;
                }
                .my-sm-auto {
                    margin-top: auto !important;
                    margin-bottom: auto !important;
                }
                .mt-sm-0 {
                    margin-top: 0 !important;
                }
                .mt-sm-1 {
                    margin-top: 0.25rem !important;
                }
                .mt-sm-2 {
                    margin-top: 0.5rem !important;
                }
                .mt-sm-3 {
                    margin-top: 1rem !important;
                }
                .mt-sm-4 {
                    margin-top: 1.5rem !important;
                }
                .mt-sm-5 {
                    margin-top: 3rem !important;
                }
                .mt-sm-auto {
                    margin-top: auto !important;
                }
                .me-sm-0 {
                    margin-right: 0 !important;
                }
                .me-sm-1 {
                    margin-right: 0.25rem !important;
                }
                .me-sm-2 {
                    margin-right: 0.5rem !important;
                }
                .me-sm-3 {
                    margin-right: 1rem !important;
                }
                .me-sm-4 {
                    margin-right: 1.5rem !important;
                }
                .me-sm-5 {
                    margin-right: 3rem !important;
                }
                .me-sm-auto {
                    margin-right: auto !important;
                }
                .mb-sm-0 {
                    margin-bottom: 0 !important;
                }
                .mb-sm-1 {
                    margin-bottom: 0.25rem !important;
                }
                .mb-sm-2 {
                    margin-bottom: 0.5rem !important;
                }
                .mb-sm-3 {
                    margin-bottom: 1rem !important;
                }
                .mb-sm-4 {
                    margin-bottom: 1.5rem !important;
                }
                .mb-sm-5 {
                    margin-bottom: 3rem !important;
                }
                .mb-sm-auto {
                    margin-bottom: auto !important;
                }
                .ms-sm-0 {
                    margin-left: 0 !important;
                }
                .ms-sm-1 {
                    margin-left: 0.25rem !important;
                }
                .ms-sm-2 {
                    margin-left: 0.5rem !important;
                }
                .ms-sm-3 {
                    margin-left: 1rem !important;
                }
                .ms-sm-4 {
                    margin-left: 1.5rem !important;
                }
                .ms-sm-5 {
                    margin-left: 3rem !important;
                }
                .ms-sm-auto {
                    margin-left: auto !important;
                }
                .p-sm-0 {
                    padding: 0 !important;
                }
                .p-sm-1 {
                    padding: 0.25rem !important;
                }
                .p-sm-2 {
                    padding: 0.5rem !important;
                }
                .p-sm-3 {
                    padding: 1rem !important;
                }
                .p-sm-4 {
                    padding: 1.5rem !important;
                }
                .p-sm-5 {
                    padding: 3rem !important;
                }
                .px-sm-0 {
                    padding-right: 0 !important;
                    padding-left: 0 !important;
                }
                .px-sm-1 {
                    padding-right: 0.25rem !important;
                    padding-left: 0.25rem !important;
                }
                .px-sm-2 {
                    padding-right: 0.5rem !important;
                    padding-left: 0.5rem !important;
                }
                .px-sm-3 {
                    padding-right: 1rem !important;
                    padding-left: 1rem !important;
                }
                .px-sm-4 {
                    padding-right: 1.5rem !important;
                    padding-left: 1.5rem !important;
                }
                .px-sm-5 {
                    padding-right: 3rem !important;
                    padding-left: 3rem !important;
                }
                .py-sm-0 {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .py-sm-1 {
                    padding-top: 0.25rem !important;
                    padding-bottom: 0.25rem !important;
                }
                .py-sm-2 {
                    padding-top: 0.5rem !important;
                    padding-bottom: 0.5rem !important;
                }
                .py-sm-3 {
                    padding-top: 1rem !important;
                    padding-bottom: 1rem !important;
                }
                .py-sm-4 {
                    padding-top: 1.5rem !important;
                    padding-bottom: 1.5rem !important;
                }
                .py-sm-5 {
                    padding-top: 3rem !important;
                    padding-bottom: 3rem !important;
                }
                .pt-sm-0 {
                    padding-top: 0 !important;
                }
                .pt-sm-1 {
                    padding-top: 0.25rem !important;
                }
                .pt-sm-2 {
                    padding-top: 0.5rem !important;
                }
                .pt-sm-3 {
                    padding-top: 1rem !important;
                }
                .pt-sm-4 {
                    padding-top: 1.5rem !important;
                }
                .pt-sm-5 {
                    padding-top: 3rem !important;
                }
                .pe-sm-0 {
                    padding-right: 0 !important;
                }
                .pe-sm-1 {
                    padding-right: 0.25rem !important;
                }
                .pe-sm-2 {
                    padding-right: 0.5rem !important;
                }
                .pe-sm-3 {
                    padding-right: 1rem !important;
                }
                .pe-sm-4 {
                    padding-right: 1.5rem !important;
                }
                .pe-sm-5 {
                    padding-right: 3rem !important;
                }
                .pb-sm-0 {
                    padding-bottom: 0 !important;
                }
                .pb-sm-1 {
                    padding-bottom: 0.25rem !important;
                }
                .pb-sm-2 {
                    padding-bottom: 0.5rem !important;
                }
                .pb-sm-3 {
                    padding-bottom: 1rem !important;
                }
                .pb-sm-4 {
                    padding-bottom: 1.5rem !important;
                }
                .pb-sm-5 {
                    padding-bottom: 3rem !important;
                }
                .ps-sm-0 {
                    padding-left: 0 !important;
                }
                .ps-sm-1 {
                    padding-left: 0.25rem !important;
                }
                .ps-sm-2 {
                    padding-left: 0.5rem !important;
                }
                .ps-sm-3 {
                    padding-left: 1rem !important;
                }
                .ps-sm-4 {
                    padding-left: 1.5rem !important;
                }
                .ps-sm-5 {
                    padding-left: 3rem !important;
                }
                .text-sm-start {
                    text-align: left !important;
                }
                .text-sm-end {
                    text-align: right !important;
                }
                .text-sm-center {
                    text-align: center !important;
                }
            }
            @media (min-width: 768px) {
                .float-md-start {
                    float: left !important;
                }
                .float-md-end {
                    float: right !important;
                }
                .float-md-none {
                    float: none !important;
                }
                .d-md-inline {
                    display: inline !important;
                }
                .d-md-inline-block {
                    display: inline-block !important;
                }
                .d-md-block {
                    display: block !important;
                }
                .d-md-grid {
                    display: grid !important;
                }
                .d-md-table {
                    display: table !important;
                }
                .d-md-table-row {
                    display: table-row !important;
                }
                .d-md-table-cell {
                    display: table-cell !important;
                }
                .d-md-flex {
                    display: flex !important;
                }
                .d-md-inline-flex {
                    display: inline-flex !important;
                }
                .d-md-none {
                    display: none !important;
                }
                .flex-md-fill {
                    flex: 1 1 auto !important;
                }
                .flex-md-row {
                    flex-direction: row !important;
                }
                .flex-md-column {
                    flex-direction: column !important;
                }
                .flex-md-row-reverse {
                    flex-direction: row-reverse !important;
                }
                .flex-md-column-reverse {
                    flex-direction: column-reverse !important;
                }
                .flex-md-grow-0 {
                    flex-grow: 0 !important;
                }
                .flex-md-grow-1 {
                    flex-grow: 1 !important;
                }
                .flex-md-shrink-0 {
                    flex-shrink: 0 !important;
                }
                .flex-md-shrink-1 {
                    flex-shrink: 1 !important;
                }
                .flex-md-wrap {
                    flex-wrap: wrap !important;
                }
                .flex-md-nowrap {
                    flex-wrap: nowrap !important;
                }
                .flex-md-wrap-reverse {
                    flex-wrap: wrap-reverse !important;
                }
                .gap-md-0 {
                    gap: 0 !important;
                }
                .gap-md-1 {
                    gap: 0.25rem !important;
                }
                .gap-md-2 {
                    gap: 0.5rem !important;
                }
                .gap-md-3 {
                    gap: 1rem !important;
                }
                .gap-md-4 {
                    gap: 1.5rem !important;
                }
                .gap-md-5 {
                    gap: 3rem !important;
                }
                .justify-content-md-start {
                    justify-content: flex-start !important;
                }
                .justify-content-md-end {
                    justify-content: flex-end !important;
                }
                .justify-content-md-center {
                    justify-content: center !important;
                }
                .justify-content-md-between {
                    justify-content: space-between !important;
                }
                .justify-content-md-around {
                    justify-content: space-around !important;
                }
                .justify-content-md-evenly {
                    justify-content: space-evenly !important;
                }
                .align-items-md-start {
                    align-items: flex-start !important;
                }
                .align-items-md-end {
                    align-items: flex-end !important;
                }
                .align-items-md-center {
                    align-items: center !important;
                }
                .align-items-md-baseline {
                    align-items: baseline !important;
                }
                .align-items-md-stretch {
                    align-items: stretch !important;
                }
                .align-content-md-start {
                    align-content: flex-start !important;
                }
                .align-content-md-end {
                    align-content: flex-end !important;
                }
                .align-content-md-center {
                    align-content: center !important;
                }
                .align-content-md-between {
                    align-content: space-between !important;
                }
                .align-content-md-around {
                    align-content: space-around !important;
                }
                .align-content-md-stretch {
                    align-content: stretch !important;
                }
                .align-self-md-auto {
                    align-self: auto !important;
                }
                .align-self-md-start {
                    align-self: flex-start !important;
                }
                .align-self-md-end {
                    align-self: flex-end !important;
                }
                .align-self-md-center {
                    align-self: center !important;
                }
                .align-self-md-baseline {
                    align-self: baseline !important;
                }
                .align-self-md-stretch {
                    align-self: stretch !important;
                }
                .order-md-first {
                    order: -1 !important;
                }
                .order-md-0 {
                    order: 0 !important;
                }
                .order-md-1 {
                    order: 1 !important;
                }
                .order-md-2 {
                    order: 2 !important;
                }
                .order-md-3 {
                    order: 3 !important;
                }
                .order-md-4 {
                    order: 4 !important;
                }
                .order-md-5 {
                    order: 5 !important;
                }
                .order-md-last {
                    order: 6 !important;
                }
                .m-md-0 {
                    margin: 0 !important;
                }
                .m-md-1 {
                    margin: 0.25rem !important;
                }
                .m-md-2 {
                    margin: 0.5rem !important;
                }
                .m-md-3 {
                    margin: 1rem !important;
                }
                .m-md-4 {
                    margin: 1.5rem !important;
                }
                .m-md-5 {
                    margin: 3rem !important;
                }
                .m-md-auto {
                    margin: auto !important;
                }
                .mx-md-0 {
                    margin-right: 0 !important;
                    margin-left: 0 !important;
                }
                .mx-md-1 {
                    margin-right: 0.25rem !important;
                    margin-left: 0.25rem !important;
                }
                .mx-md-2 {
                    margin-right: 0.5rem !important;
                    margin-left: 0.5rem !important;
                }
                .mx-md-3 {
                    margin-right: 1rem !important;
                    margin-left: 1rem !important;
                }
                .mx-md-4 {
                    margin-right: 1.5rem !important;
                    margin-left: 1.5rem !important;
                }
                .mx-md-5 {
                    margin-right: 3rem !important;
                    margin-left: 3rem !important;
                }
                .mx-md-auto {
                    margin-right: auto !important;
                    margin-left: auto !important;
                }
                .my-md-0 {
                    margin-top: 0 !important;
                    margin-bottom: 0 !important;
                }
                .my-md-1 {
                    margin-top: 0.25rem !important;
                    margin-bottom: 0.25rem !important;
                }
                .my-md-2 {
                    margin-top: 0.5rem !important;
                    margin-bottom: 0.5rem !important;
                }
                .my-md-3 {
                    margin-top: 1rem !important;
                    margin-bottom: 1rem !important;
                }
                .my-md-4 {
                    margin-top: 1.5rem !important;
                    margin-bottom: 1.5rem !important;
                }
                .my-md-5 {
                    margin-top: 3rem !important;
                    margin-bottom: 3rem !important;
                }
                .my-md-auto {
                    margin-top: auto !important;
                    margin-bottom: auto !important;
                }
                .mt-md-0 {
                    margin-top: 0 !important;
                }
                .mt-md-1 {
                    margin-top: 0.25rem !important;
                }
                .mt-md-2 {
                    margin-top: 0.5rem !important;
                }
                .mt-md-3 {
                    margin-top: 1rem !important;
                }
                .mt-md-4 {
                    margin-top: 1.5rem !important;
                }
                .mt-md-5 {
                    margin-top: 3rem !important;
                }
                .mt-md-auto {
                    margin-top: auto !important;
                }
                .me-md-0 {
                    margin-right: 0 !important;
                }
                .me-md-1 {
                    margin-right: 0.25rem !important;
                }
                .me-md-2 {
                    margin-right: 0.5rem !important;
                }
                .me-md-3 {
                    margin-right: 1rem !important;
                }
                .me-md-4 {
                    margin-right: 1.5rem !important;
                }
                .me-md-5 {
                    margin-right: 3rem !important;
                }
                .me-md-auto {
                    margin-right: auto !important;
                }
                .mb-md-0 {
                    margin-bottom: 0 !important;
                }
                .mb-md-1 {
                    margin-bottom: 0.25rem !important;
                }
                .mb-md-2 {
                    margin-bottom: 0.5rem !important;
                }
                .mb-md-3 {
                    margin-bottom: 1rem !important;
                }
                .mb-md-4 {
                    margin-bottom: 1.5rem !important;
                }
                .mb-md-5 {
                    margin-bottom: 3rem !important;
                }
                .mb-md-auto {
                    margin-bottom: auto !important;
                }
                .ms-md-0 {
                    margin-left: 0 !important;
                }
                .ms-md-1 {
                    margin-left: 0.25rem !important;
                }
                .ms-md-2 {
                    margin-left: 0.5rem !important;
                }
                .ms-md-3 {
                    margin-left: 1rem !important;
                }
                .ms-md-4 {
                    margin-left: 1.5rem !important;
                }
                .ms-md-5 {
                    margin-left: 3rem !important;
                }
                .ms-md-auto {
                    margin-left: auto !important;
                }
                .p-md-0 {
                    padding: 0 !important;
                }
                .p-md-1 {
                    padding: 0.25rem !important;
                }
                .p-md-2 {
                    padding: 0.5rem !important;
                }
                .p-md-3 {
                    padding: 1rem !important;
                }
                .p-md-4 {
                    padding: 1.5rem !important;
                }
                .p-md-5 {
                    padding: 3rem !important;
                }
                .px-md-0 {
                    padding-right: 0 !important;
                    padding-left: 0 !important;
                }
                .px-md-1 {
                    padding-right: 0.25rem !important;
                    padding-left: 0.25rem !important;
                }
                .px-md-2 {
                    padding-right: 0.5rem !important;
                    padding-left: 0.5rem !important;
                }
                .px-md-3 {
                    padding-right: 1rem !important;
                    padding-left: 1rem !important;
                }
                .px-md-4 {
                    padding-right: 1.5rem !important;
                    padding-left: 1.5rem !important;
                }
                .px-md-5 {
                    padding-right: 3rem !important;
                    padding-left: 3rem !important;
                }
                .py-md-0 {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .py-md-1 {
                    padding-top: 0.25rem !important;
                    padding-bottom: 0.25rem !important;
                }
                .py-md-2 {
                    padding-top: 0.5rem !important;
                    padding-bottom: 0.5rem !important;
                }
                .py-md-3 {
                    padding-top: 1rem !important;
                    padding-bottom: 1rem !important;
                }
                .py-md-4 {
                    padding-top: 1.5rem !important;
                    padding-bottom: 1.5rem !important;
                }
                .py-md-5 {
                    padding-top: 3rem !important;
                    padding-bottom: 3rem !important;
                }
                .pt-md-0 {
                    padding-top: 0 !important;
                }
                .pt-md-1 {
                    padding-top: 0.25rem !important;
                }
                .pt-md-2 {
                    padding-top: 0.5rem !important;
                }
                .pt-md-3 {
                    padding-top: 1rem !important;
                }
                .pt-md-4 {
                    padding-top: 1.5rem !important;
                }
                .pt-md-5 {
                    padding-top: 3rem !important;
                }
                .pe-md-0 {
                    padding-right: 0 !important;
                }
                .pe-md-1 {
                    padding-right: 0.25rem !important;
                }
                .pe-md-2 {
                    padding-right: 0.5rem !important;
                }
                .pe-md-3 {
                    padding-right: 1rem !important;
                }
                .pe-md-4 {
                    padding-right: 1.5rem !important;
                }
                .pe-md-5 {
                    padding-right: 3rem !important;
                }
                .pb-md-0 {
                    padding-bottom: 0 !important;
                }
                .pb-md-1 {
                    padding-bottom: 0.25rem !important;
                }
                .pb-md-2 {
                    padding-bottom: 0.5rem !important;
                }
                .pb-md-3 {
                    padding-bottom: 1rem !important;
                }
                .pb-md-4 {
                    padding-bottom: 1.5rem !important;
                }
                .pb-md-5 {
                    padding-bottom: 3rem !important;
                }
                .ps-md-0 {
                    padding-left: 0 !important;
                }
                .ps-md-1 {
                    padding-left: 0.25rem !important;
                }
                .ps-md-2 {
                    padding-left: 0.5rem !important;
                }
                .ps-md-3 {
                    padding-left: 1rem !important;
                }
                .ps-md-4 {
                    padding-left: 1.5rem !important;
                }
                .ps-md-5 {
                    padding-left: 3rem !important;
                }
                .text-md-start {
                    text-align: left !important;
                }
                .text-md-end {
                    text-align: right !important;
                }
                .text-md-center {
                    text-align: center !important;
                }
            }
            @media (min-width: 992px) {
                .float-lg-start {
                    float: left !important;
                }
                .float-lg-end {
                    float: right !important;
                }
                .float-lg-none {
                    float: none !important;
                }
                .d-lg-inline {
                    display: inline !important;
                }
                .d-lg-inline-block {
                    display: inline-block !important;
                }
                .d-lg-block {
                    display: block !important;
                }
                .d-lg-grid {
                    display: grid !important;
                }
                .d-lg-table {
                    display: table !important;
                }
                .d-lg-table-row {
                    display: table-row !important;
                }
                .d-lg-table-cell {
                    display: table-cell !important;
                }
                .d-lg-flex {
                    display: flex !important;
                }
                .d-lg-inline-flex {
                    display: inline-flex !important;
                }
                .d-lg-none {
                    display: none !important;
                }
                .flex-lg-fill {
                    flex: 1 1 auto !important;
                }
                .flex-lg-row {
                    flex-direction: row !important;
                }
                .flex-lg-column {
                    flex-direction: column !important;
                }
                .flex-lg-row-reverse {
                    flex-direction: row-reverse !important;
                }
                .flex-lg-column-reverse {
                    flex-direction: column-reverse !important;
                }
                .flex-lg-grow-0 {
                    flex-grow: 0 !important;
                }
                .flex-lg-grow-1 {
                    flex-grow: 1 !important;
                }
                .flex-lg-shrink-0 {
                    flex-shrink: 0 !important;
                }
                .flex-lg-shrink-1 {
                    flex-shrink: 1 !important;
                }
                .flex-lg-wrap {
                    flex-wrap: wrap !important;
                }
                .flex-lg-nowrap {
                    flex-wrap: nowrap !important;
                }
                .flex-lg-wrap-reverse {
                    flex-wrap: wrap-reverse !important;
                }
                .gap-lg-0 {
                    gap: 0 !important;
                }
                .gap-lg-1 {
                    gap: 0.25rem !important;
                }
                .gap-lg-2 {
                    gap: 0.5rem !important;
                }
                .gap-lg-3 {
                    gap: 1rem !important;
                }
                .gap-lg-4 {
                    gap: 1.5rem !important;
                }
                .gap-lg-5 {
                    gap: 3rem !important;
                }
                .justify-content-lg-start {
                    justify-content: flex-start !important;
                }
                .justify-content-lg-end {
                    justify-content: flex-end !important;
                }
                .justify-content-lg-center {
                    justify-content: center !important;
                }
                .justify-content-lg-between {
                    justify-content: space-between !important;
                }
                .justify-content-lg-around {
                    justify-content: space-around !important;
                }
                .justify-content-lg-evenly {
                    justify-content: space-evenly !important;
                }
                .align-items-lg-start {
                    align-items: flex-start !important;
                }
                .align-items-lg-end {
                    align-items: flex-end !important;
                }
                .align-items-lg-center {
                    align-items: center !important;
                }
                .align-items-lg-baseline {
                    align-items: baseline !important;
                }
                .align-items-lg-stretch {
                    align-items: stretch !important;
                }
                .align-content-lg-start {
                    align-content: flex-start !important;
                }
                .align-content-lg-end {
                    align-content: flex-end !important;
                }
                .align-content-lg-center {
                    align-content: center !important;
                }
                .align-content-lg-between {
                    align-content: space-between !important;
                }
                .align-content-lg-around {
                    align-content: space-around !important;
                }
                .align-content-lg-stretch {
                    align-content: stretch !important;
                }
                .align-self-lg-auto {
                    align-self: auto !important;
                }
                .align-self-lg-start {
                    align-self: flex-start !important;
                }
                .align-self-lg-end {
                    align-self: flex-end !important;
                }
                .align-self-lg-center {
                    align-self: center !important;
                }
                .align-self-lg-baseline {
                    align-self: baseline !important;
                }
                .align-self-lg-stretch {
                    align-self: stretch !important;
                }
                .order-lg-first {
                    order: -1 !important;
                }
                .order-lg-0 {
                    order: 0 !important;
                }
                .order-lg-1 {
                    order: 1 !important;
                }
                .order-lg-2 {
                    order: 2 !important;
                }
                .order-lg-3 {
                    order: 3 !important;
                }
                .order-lg-4 {
                    order: 4 !important;
                }
                .order-lg-5 {
                    order: 5 !important;
                }
                .order-lg-last {
                    order: 6 !important;
                }
                .m-lg-0 {
                    margin: 0 !important;
                }
                .m-lg-1 {
                    margin: 0.25rem !important;
                }
                .m-lg-2 {
                    margin: 0.5rem !important;
                }
                .m-lg-3 {
                    margin: 1rem !important;
                }
                .m-lg-4 {
                    margin: 1.5rem !important;
                }
                .m-lg-5 {
                    margin: 3rem !important;
                }
                .m-lg-auto {
                    margin: auto !important;
                }
                .mx-lg-0 {
                    margin-right: 0 !important;
                    margin-left: 0 !important;
                }
                .mx-lg-1 {
                    margin-right: 0.25rem !important;
                    margin-left: 0.25rem !important;
                }
                .mx-lg-2 {
                    margin-right: 0.5rem !important;
                    margin-left: 0.5rem !important;
                }
                .mx-lg-3 {
                    margin-right: 1rem !important;
                    margin-left: 1rem !important;
                }
                .mx-lg-4 {
                    margin-right: 1.5rem !important;
                    margin-left: 1.5rem !important;
                }
                .mx-lg-5 {
                    margin-right: 3rem !important;
                    margin-left: 3rem !important;
                }
                .mx-lg-auto {
                    margin-right: auto !important;
                    margin-left: auto !important;
                }
                .my-lg-0 {
                    margin-top: 0 !important;
                    margin-bottom: 0 !important;
                }
                .my-lg-1 {
                    margin-top: 0.25rem !important;
                    margin-bottom: 0.25rem !important;
                }
                .my-lg-2 {
                    margin-top: 0.5rem !important;
                    margin-bottom: 0.5rem !important;
                }
                .my-lg-3 {
                    margin-top: 1rem !important;
                    margin-bottom: 1rem !important;
                }
                .my-lg-4 {
                    margin-top: 1.5rem !important;
                    margin-bottom: 1.5rem !important;
                }
                .my-lg-5 {
                    margin-top: 3rem !important;
                    margin-bottom: 3rem !important;
                }
                .my-lg-auto {
                    margin-top: auto !important;
                    margin-bottom: auto !important;
                }
                .mt-lg-0 {
                    margin-top: 0 !important;
                }
                .mt-lg-1 {
                    margin-top: 0.25rem !important;
                }
                .mt-lg-2 {
                    margin-top: 0.5rem !important;
                }
                .mt-lg-3 {
                    margin-top: 1rem !important;
                }
                .mt-lg-4 {
                    margin-top: 1.5rem !important;
                }
                .mt-lg-5 {
                    margin-top: 3rem !important;
                }
                .mt-lg-auto {
                    margin-top: auto !important;
                }
                .me-lg-0 {
                    margin-right: 0 !important;
                }
                .me-lg-1 {
                    margin-right: 0.25rem !important;
                }
                .me-lg-2 {
                    margin-right: 0.5rem !important;
                }
                .me-lg-3 {
                    margin-right: 1rem !important;
                }
                .me-lg-4 {
                    margin-right: 1.5rem !important;
                }
                .me-lg-5 {
                    margin-right: 3rem !important;
                }
                .me-lg-auto {
                    margin-right: auto !important;
                }
                .mb-lg-0 {
                    margin-bottom: 0 !important;
                }
                .mb-lg-1 {
                    margin-bottom: 0.25rem !important;
                }
                .mb-lg-2 {
                    margin-bottom: 0.5rem !important;
                }
                .mb-lg-3 {
                    margin-bottom: 1rem !important;
                }
                .mb-lg-4 {
                    margin-bottom: 1.5rem !important;
                }
                .mb-lg-5 {
                    margin-bottom: 3rem !important;
                }
                .mb-lg-auto {
                    margin-bottom: auto !important;
                }
                .ms-lg-0 {
                    margin-left: 0 !important;
                }
                .ms-lg-1 {
                    margin-left: 0.25rem !important;
                }
                .ms-lg-2 {
                    margin-left: 0.5rem !important;
                }
                .ms-lg-3 {
                    margin-left: 1rem !important;
                }
                .ms-lg-4 {
                    margin-left: 1.5rem !important;
                }
                .ms-lg-5 {
                    margin-left: 3rem !important;
                }
                .ms-lg-auto {
                    margin-left: auto !important;
                }
                .p-lg-0 {
                    padding: 0 !important;
                }
                .p-lg-1 {
                    padding: 0.25rem !important;
                }
                .p-lg-2 {
                    padding: 0.5rem !important;
                }
                .p-lg-3 {
                    padding: 1rem !important;
                }
                .p-lg-4 {
                    padding: 1.5rem !important;
                }
                .p-lg-5 {
                    padding: 3rem !important;
                }
                .px-lg-0 {
                    padding-right: 0 !important;
                    padding-left: 0 !important;
                }
                .px-lg-1 {
                    padding-right: 0.25rem !important;
                    padding-left: 0.25rem !important;
                }
                .px-lg-2 {
                    padding-right: 0.5rem !important;
                    padding-left: 0.5rem !important;
                }
                .px-lg-3 {
                    padding-right: 1rem !important;
                    padding-left: 1rem !important;
                }
                .px-lg-4 {
                    padding-right: 1.5rem !important;
                    padding-left: 1.5rem !important;
                }
                .px-lg-5 {
                    padding-right: 3rem !important;
                    padding-left: 3rem !important;
                }
                .py-lg-0 {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .py-lg-1 {
                    padding-top: 0.25rem !important;
                    padding-bottom: 0.25rem !important;
                }
                .py-lg-2 {
                    padding-top: 0.5rem !important;
                    padding-bottom: 0.5rem !important;
                }
                .py-lg-3 {
                    padding-top: 1rem !important;
                    padding-bottom: 1rem !important;
                }
                .py-lg-4 {
                    padding-top: 1.5rem !important;
                    padding-bottom: 1.5rem !important;
                }
                .py-lg-5 {
                    padding-top: 3rem !important;
                    padding-bottom: 3rem !important;
                }
                .pt-lg-0 {
                    padding-top: 0 !important;
                }
                .pt-lg-1 {
                    padding-top: 0.25rem !important;
                }
                .pt-lg-2 {
                    padding-top: 0.5rem !important;
                }
                .pt-lg-3 {
                    padding-top: 1rem !important;
                }
                .pt-lg-4 {
                    padding-top: 1.5rem !important;
                }
                .pt-lg-5 {
                    padding-top: 3rem !important;
                }
                .pe-lg-0 {
                    padding-right: 0 !important;
                }
                .pe-lg-1 {
                    padding-right: 0.25rem !important;
                }
                .pe-lg-2 {
                    padding-right: 0.5rem !important;
                }
                .pe-lg-3 {
                    padding-right: 1rem !important;
                }
                .pe-lg-4 {
                    padding-right: 1.5rem !important;
                }
                .pe-lg-5 {
                    padding-right: 3rem !important;
                }
                .pb-lg-0 {
                    padding-bottom: 0 !important;
                }
                .pb-lg-1 {
                    padding-bottom: 0.25rem !important;
                }
                .pb-lg-2 {
                    padding-bottom: 0.5rem !important;
                }
                .pb-lg-3 {
                    padding-bottom: 1rem !important;
                }
                .pb-lg-4 {
                    padding-bottom: 1.5rem !important;
                }
                .pb-lg-5 {
                    padding-bottom: 3rem !important;
                }
                .ps-lg-0 {
                    padding-left: 0 !important;
                }
                .ps-lg-1 {
                    padding-left: 0.25rem !important;
                }
                .ps-lg-2 {
                    padding-left: 0.5rem !important;
                }
                .ps-lg-3 {
                    padding-left: 1rem !important;
                }
                .ps-lg-4 {
                    padding-left: 1.5rem !important;
                }
                .ps-lg-5 {
                    padding-left: 3rem !important;
                }
                .text-lg-start {
                    text-align: left !important;
                }
                .text-lg-end {
                    text-align: right !important;
                }
                .text-lg-center {
                    text-align: center !important;
                }
            }
            @media (min-width: 1200px) {
                .float-xl-start {
                    float: left !important;
                }
                .float-xl-end {
                    float: right !important;
                }
                .float-xl-none {
                    float: none !important;
                }
                .d-xl-inline {
                    display: inline !important;
                }
                .d-xl-inline-block {
                    display: inline-block !important;
                }
                .d-xl-block {
                    display: block !important;
                }
                .d-xl-grid {
                    display: grid !important;
                }
                .d-xl-table {
                    display: table !important;
                }
                .d-xl-table-row {
                    display: table-row !important;
                }
                .d-xl-table-cell {
                    display: table-cell !important;
                }
                .d-xl-flex {
                    display: flex !important;
                }
                .d-xl-inline-flex {
                    display: inline-flex !important;
                }
                .d-xl-none {
                    display: none !important;
                }
                .flex-xl-fill {
                    flex: 1 1 auto !important;
                }
                .flex-xl-row {
                    flex-direction: row !important;
                }
                .flex-xl-column {
                    flex-direction: column !important;
                }
                .flex-xl-row-reverse {
                    flex-direction: row-reverse !important;
                }
                .flex-xl-column-reverse {
                    flex-direction: column-reverse !important;
                }
                .flex-xl-grow-0 {
                    flex-grow: 0 !important;
                }
                .flex-xl-grow-1 {
                    flex-grow: 1 !important;
                }
                .flex-xl-shrink-0 {
                    flex-shrink: 0 !important;
                }
                .flex-xl-shrink-1 {
                    flex-shrink: 1 !important;
                }
                .flex-xl-wrap {
                    flex-wrap: wrap !important;
                }
                .flex-xl-nowrap {
                    flex-wrap: nowrap !important;
                }
                .flex-xl-wrap-reverse {
                    flex-wrap: wrap-reverse !important;
                }
                .gap-xl-0 {
                    gap: 0 !important;
                }
                .gap-xl-1 {
                    gap: 0.25rem !important;
                }
                .gap-xl-2 {
                    gap: 0.5rem !important;
                }
                .gap-xl-3 {
                    gap: 1rem !important;
                }
                .gap-xl-4 {
                    gap: 1.5rem !important;
                }
                .gap-xl-5 {
                    gap: 3rem !important;
                }
                .justify-content-xl-start {
                    justify-content: flex-start !important;
                }
                .justify-content-xl-end {
                    justify-content: flex-end !important;
                }
                .justify-content-xl-center {
                    justify-content: center !important;
                }
                .justify-content-xl-between {
                    justify-content: space-between !important;
                }
                .justify-content-xl-around {
                    justify-content: space-around !important;
                }
                .justify-content-xl-evenly {
                    justify-content: space-evenly !important;
                }
                .align-items-xl-start {
                    align-items: flex-start !important;
                }
                .align-items-xl-end {
                    align-items: flex-end !important;
                }
                .align-items-xl-center {
                    align-items: center !important;
                }
                .align-items-xl-baseline {
                    align-items: baseline !important;
                }
                .align-items-xl-stretch {
                    align-items: stretch !important;
                }
                .align-content-xl-start {
                    align-content: flex-start !important;
                }
                .align-content-xl-end {
                    align-content: flex-end !important;
                }
                .align-content-xl-center {
                    align-content: center !important;
                }
                .align-content-xl-between {
                    align-content: space-between !important;
                }
                .align-content-xl-around {
                    align-content: space-around !important;
                }
                .align-content-xl-stretch {
                    align-content: stretch !important;
                }
                .align-self-xl-auto {
                    align-self: auto !important;
                }
                .align-self-xl-start {
                    align-self: flex-start !important;
                }
                .align-self-xl-end {
                    align-self: flex-end !important;
                }
                .align-self-xl-center {
                    align-self: center !important;
                }
                .align-self-xl-baseline {
                    align-self: baseline !important;
                }
                .align-self-xl-stretch {
                    align-self: stretch !important;
                }
                .order-xl-first {
                    order: -1 !important;
                }
                .order-xl-0 {
                    order: 0 !important;
                }
                .order-xl-1 {
                    order: 1 !important;
                }
                .order-xl-2 {
                    order: 2 !important;
                }
                .order-xl-3 {
                    order: 3 !important;
                }
                .order-xl-4 {
                    order: 4 !important;
                }
                .order-xl-5 {
                    order: 5 !important;
                }
                .order-xl-last {
                    order: 6 !important;
                }
                .m-xl-0 {
                    margin: 0 !important;
                }
                .m-xl-1 {
                    margin: 0.25rem !important;
                }
                .m-xl-2 {
                    margin: 0.5rem !important;
                }
                .m-xl-3 {
                    margin: 1rem !important;
                }
                .m-xl-4 {
                    margin: 1.5rem !important;
                }
                .m-xl-5 {
                    margin: 3rem !important;
                }
                .m-xl-auto {
                    margin: auto !important;
                }
                .mx-xl-0 {
                    margin-right: 0 !important;
                    margin-left: 0 !important;
                }
                .mx-xl-1 {
                    margin-right: 0.25rem !important;
                    margin-left: 0.25rem !important;
                }
                .mx-xl-2 {
                    margin-right: 0.5rem !important;
                    margin-left: 0.5rem !important;
                }
                .mx-xl-3 {
                    margin-right: 1rem !important;
                    margin-left: 1rem !important;
                }
                .mx-xl-4 {
                    margin-right: 1.5rem !important;
                    margin-left: 1.5rem !important;
                }
                .mx-xl-5 {
                    margin-right: 3rem !important;
                    margin-left: 3rem !important;
                }
                .mx-xl-auto {
                    margin-right: auto !important;
                    margin-left: auto !important;
                }
                .my-xl-0 {
                    margin-top: 0 !important;
                    margin-bottom: 0 !important;
                }
                .my-xl-1 {
                    margin-top: 0.25rem !important;
                    margin-bottom: 0.25rem !important;
                }
                .my-xl-2 {
                    margin-top: 0.5rem !important;
                    margin-bottom: 0.5rem !important;
                }
                .my-xl-3 {
                    margin-top: 1rem !important;
                    margin-bottom: 1rem !important;
                }
                .my-xl-4 {
                    margin-top: 1.5rem !important;
                    margin-bottom: 1.5rem !important;
                }
                .my-xl-5 {
                    margin-top: 3rem !important;
                    margin-bottom: 3rem !important;
                }
                .my-xl-auto {
                    margin-top: auto !important;
                    margin-bottom: auto !important;
                }
                .mt-xl-0 {
                    margin-top: 0 !important;
                }
                .mt-xl-1 {
                    margin-top: 0.25rem !important;
                }
                .mt-xl-2 {
                    margin-top: 0.5rem !important;
                }
                .mt-xl-3 {
                    margin-top: 1rem !important;
                }
                .mt-xl-4 {
                    margin-top: 1.5rem !important;
                }
                .mt-xl-5 {
                    margin-top: 3rem !important;
                }
                .mt-xl-auto {
                    margin-top: auto !important;
                }
                .me-xl-0 {
                    margin-right: 0 !important;
                }
                .me-xl-1 {
                    margin-right: 0.25rem !important;
                }
                .me-xl-2 {
                    margin-right: 0.5rem !important;
                }
                .me-xl-3 {
                    margin-right: 1rem !important;
                }
                .me-xl-4 {
                    margin-right: 1.5rem !important;
                }
                .me-xl-5 {
                    margin-right: 3rem !important;
                }
                .me-xl-auto {
                    margin-right: auto !important;
                }
                .mb-xl-0 {
                    margin-bottom: 0 !important;
                }
                .mb-xl-1 {
                    margin-bottom: 0.25rem !important;
                }
                .mb-xl-2 {
                    margin-bottom: 0.5rem !important;
                }
                .mb-xl-3 {
                    margin-bottom: 1rem !important;
                }
                .mb-xl-4 {
                    margin-bottom: 1.5rem !important;
                }
                .mb-xl-5 {
                    margin-bottom: 3rem !important;
                }
                .mb-xl-auto {
                    margin-bottom: auto !important;
                }
                .ms-xl-0 {
                    margin-left: 0 !important;
                }
                .ms-xl-1 {
                    margin-left: 0.25rem !important;
                }
                .ms-xl-2 {
                    margin-left: 0.5rem !important;
                }
                .ms-xl-3 {
                    margin-left: 1rem !important;
                }
                .ms-xl-4 {
                    margin-left: 1.5rem !important;
                }
                .ms-xl-5 {
                    margin-left: 3rem !important;
                }
                .ms-xl-auto {
                    margin-left: auto !important;
                }
                .p-xl-0 {
                    padding: 0 !important;
                }
                .p-xl-1 {
                    padding: 0.25rem !important;
                }
                .p-xl-2 {
                    padding: 0.5rem !important;
                }
                .p-xl-3 {
                    padding: 1rem !important;
                }
                .p-xl-4 {
                    padding: 1.5rem !important;
                }
                .p-xl-5 {
                    padding: 3rem !important;
                }
                .px-xl-0 {
                    padding-right: 0 !important;
                    padding-left: 0 !important;
                }
                .px-xl-1 {
                    padding-right: 0.25rem !important;
                    padding-left: 0.25rem !important;
                }
                .px-xl-2 {
                    padding-right: 0.5rem !important;
                    padding-left: 0.5rem !important;
                }
                .px-xl-3 {
                    padding-right: 1rem !important;
                    padding-left: 1rem !important;
                }
                .px-xl-4 {
                    padding-right: 1.5rem !important;
                    padding-left: 1.5rem !important;
                }
                .px-xl-5 {
                    padding-right: 3rem !important;
                    padding-left: 3rem !important;
                }
                .py-xl-0 {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .py-xl-1 {
                    padding-top: 0.25rem !important;
                    padding-bottom: 0.25rem !important;
                }
                .py-xl-2 {
                    padding-top: 0.5rem !important;
                    padding-bottom: 0.5rem !important;
                }
                .py-xl-3 {
                    padding-top: 1rem !important;
                    padding-bottom: 1rem !important;
                }
                .py-xl-4 {
                    padding-top: 1.5rem !important;
                    padding-bottom: 1.5rem !important;
                }
                .py-xl-5 {
                    padding-top: 3rem !important;
                    padding-bottom: 3rem !important;
                }
                .pt-xl-0 {
                    padding-top: 0 !important;
                }
                .pt-xl-1 {
                    padding-top: 0.25rem !important;
                }
                .pt-xl-2 {
                    padding-top: 0.5rem !important;
                }
                .pt-xl-3 {
                    padding-top: 1rem !important;
                }
                .pt-xl-4 {
                    padding-top: 1.5rem !important;
                }
                .pt-xl-5 {
                    padding-top: 3rem !important;
                }
                .pe-xl-0 {
                    padding-right: 0 !important;
                }
                .pe-xl-1 {
                    padding-right: 0.25rem !important;
                }
                .pe-xl-2 {
                    padding-right: 0.5rem !important;
                }
                .pe-xl-3 {
                    padding-right: 1rem !important;
                }
                .pe-xl-4 {
                    padding-right: 1.5rem !important;
                }
                .pe-xl-5 {
                    padding-right: 3rem !important;
                }
                .pb-xl-0 {
                    padding-bottom: 0 !important;
                }
                .pb-xl-1 {
                    padding-bottom: 0.25rem !important;
                }
                .pb-xl-2 {
                    padding-bottom: 0.5rem !important;
                }
                .pb-xl-3 {
                    padding-bottom: 1rem !important;
                }
                .pb-xl-4 {
                    padding-bottom: 1.5rem !important;
                }
                .pb-xl-5 {
                    padding-bottom: 3rem !important;
                }
                .ps-xl-0 {
                    padding-left: 0 !important;
                }
                .ps-xl-1 {
                    padding-left: 0.25rem !important;
                }
                .ps-xl-2 {
                    padding-left: 0.5rem !important;
                }
                .ps-xl-3 {
                    padding-left: 1rem !important;
                }
                .ps-xl-4 {
                    padding-left: 1.5rem !important;
                }
                .ps-xl-5 {
                    padding-left: 3rem !important;
                }
                .text-xl-start {
                    text-align: left !important;
                }
                .text-xl-end {
                    text-align: right !important;
                }
                .text-xl-center {
                    text-align: center !important;
                }
            }
            @media (min-width: 1400px) {
                .float-xxl-start {
                    float: left !important;
                }
                .float-xxl-end {
                    float: right !important;
                }
                .float-xxl-none {
                    float: none !important;
                }
                .d-xxl-inline {
                    display: inline !important;
                }
                .d-xxl-inline-block {
                    display: inline-block !important;
                }
                .d-xxl-block {
                    display: block !important;
                }
                .d-xxl-grid {
                    display: grid !important;
                }
                .d-xxl-table {
                    display: table !important;
                }
                .d-xxl-table-row {
                    display: table-row !important;
                }
                .d-xxl-table-cell {
                    display: table-cell !important;
                }
                .d-xxl-flex {
                    display: flex !important;
                }
                .d-xxl-inline-flex {
                    display: inline-flex !important;
                }
                .d-xxl-none {
                    display: none !important;
                }
                .flex-xxl-fill {
                    flex: 1 1 auto !important;
                }
                .flex-xxl-row {
                    flex-direction: row !important;
                }
                .flex-xxl-column {
                    flex-direction: column !important;
                }
                .flex-xxl-row-reverse {
                    flex-direction: row-reverse !important;
                }
                .flex-xxl-column-reverse {
                    flex-direction: column-reverse !important;
                }
                .flex-xxl-grow-0 {
                    flex-grow: 0 !important;
                }
                .flex-xxl-grow-1 {
                    flex-grow: 1 !important;
                }
                .flex-xxl-shrink-0 {
                    flex-shrink: 0 !important;
                }
                .flex-xxl-shrink-1 {
                    flex-shrink: 1 !important;
                }
                .flex-xxl-wrap {
                    flex-wrap: wrap !important;
                }
                .flex-xxl-nowrap {
                    flex-wrap: nowrap !important;
                }
                .flex-xxl-wrap-reverse {
                    flex-wrap: wrap-reverse !important;
                }
                .gap-xxl-0 {
                    gap: 0 !important;
                }
                .gap-xxl-1 {
                    gap: 0.25rem !important;
                }
                .gap-xxl-2 {
                    gap: 0.5rem !important;
                }
                .gap-xxl-3 {
                    gap: 1rem !important;
                }
                .gap-xxl-4 {
                    gap: 1.5rem !important;
                }
                .gap-xxl-5 {
                    gap: 3rem !important;
                }
                .justify-content-xxl-start {
                    justify-content: flex-start !important;
                }
                .justify-content-xxl-end {
                    justify-content: flex-end !important;
                }
                .justify-content-xxl-center {
                    justify-content: center !important;
                }
                .justify-content-xxl-between {
                    justify-content: space-between !important;
                }
                .justify-content-xxl-around {
                    justify-content: space-around !important;
                }
                .justify-content-xxl-evenly {
                    justify-content: space-evenly !important;
                }
                .align-items-xxl-start {
                    align-items: flex-start !important;
                }
                .align-items-xxl-end {
                    align-items: flex-end !important;
                }
                .align-items-xxl-center {
                    align-items: center !important;
                }
                .align-items-xxl-baseline {
                    align-items: baseline !important;
                }
                .align-items-xxl-stretch {
                    align-items: stretch !important;
                }
                .align-content-xxl-start {
                    align-content: flex-start !important;
                }
                .align-content-xxl-end {
                    align-content: flex-end !important;
                }
                .align-content-xxl-center {
                    align-content: center !important;
                }
                .align-content-xxl-between {
                    align-content: space-between !important;
                }
                .align-content-xxl-around {
                    align-content: space-around !important;
                }
                .align-content-xxl-stretch {
                    align-content: stretch !important;
                }
                .align-self-xxl-auto {
                    align-self: auto !important;
                }
                .align-self-xxl-start {
                    align-self: flex-start !important;
                }
                .align-self-xxl-end {
                    align-self: flex-end !important;
                }
                .align-self-xxl-center {
                    align-self: center !important;
                }
                .align-self-xxl-baseline {
                    align-self: baseline !important;
                }
                .align-self-xxl-stretch {
                    align-self: stretch !important;
                }
                .order-xxl-first {
                    order: -1 !important;
                }
                .order-xxl-0 {
                    order: 0 !important;
                }
                .order-xxl-1 {
                    order: 1 !important;
                }
                .order-xxl-2 {
                    order: 2 !important;
                }
                .order-xxl-3 {
                    order: 3 !important;
                }
                .order-xxl-4 {
                    order: 4 !important;
                }
                .order-xxl-5 {
                    order: 5 !important;
                }
                .order-xxl-last {
                    order: 6 !important;
                }
                .m-xxl-0 {
                    margin: 0 !important;
                }
                .m-xxl-1 {
                    margin: 0.25rem !important;
                }
                .m-xxl-2 {
                    margin: 0.5rem !important;
                }
                .m-xxl-3 {
                    margin: 1rem !important;
                }
                .m-xxl-4 {
                    margin: 1.5rem !important;
                }
                .m-xxl-5 {
                    margin: 3rem !important;
                }
                .m-xxl-auto {
                    margin: auto !important;
                }
                .mx-xxl-0 {
                    margin-right: 0 !important;
                    margin-left: 0 !important;
                }
                .mx-xxl-1 {
                    margin-right: 0.25rem !important;
                    margin-left: 0.25rem !important;
                }
                .mx-xxl-2 {
                    margin-right: 0.5rem !important;
                    margin-left: 0.5rem !important;
                }
                .mx-xxl-3 {
                    margin-right: 1rem !important;
                    margin-left: 1rem !important;
                }
                .mx-xxl-4 {
                    margin-right: 1.5rem !important;
                    margin-left: 1.5rem !important;
                }
                .mx-xxl-5 {
                    margin-right: 3rem !important;
                    margin-left: 3rem !important;
                }
                .mx-xxl-auto {
                    margin-right: auto !important;
                    margin-left: auto !important;
                }
                .my-xxl-0 {
                    margin-top: 0 !important;
                    margin-bottom: 0 !important;
                }
                .my-xxl-1 {
                    margin-top: 0.25rem !important;
                    margin-bottom: 0.25rem !important;
                }
                .my-xxl-2 {
                    margin-top: 0.5rem !important;
                    margin-bottom: 0.5rem !important;
                }
                .my-xxl-3 {
                    margin-top: 1rem !important;
                    margin-bottom: 1rem !important;
                }
                .my-xxl-4 {
                    margin-top: 1.5rem !important;
                    margin-bottom: 1.5rem !important;
                }
                .my-xxl-5 {
                    margin-top: 3rem !important;
                    margin-bottom: 3rem !important;
                }
                .my-xxl-auto {
                    margin-top: auto !important;
                    margin-bottom: auto !important;
                }
                .mt-xxl-0 {
                    margin-top: 0 !important;
                }
                .mt-xxl-1 {
                    margin-top: 0.25rem !important;
                }
                .mt-xxl-2 {
                    margin-top: 0.5rem !important;
                }
                .mt-xxl-3 {
                    margin-top: 1rem !important;
                }
                .mt-xxl-4 {
                    margin-top: 1.5rem !important;
                }
                .mt-xxl-5 {
                    margin-top: 3rem !important;
                }
                .mt-xxl-auto {
                    margin-top: auto !important;
                }
                .me-xxl-0 {
                    margin-right: 0 !important;
                }
                .me-xxl-1 {
                    margin-right: 0.25rem !important;
                }
                .me-xxl-2 {
                    margin-right: 0.5rem !important;
                }
                .me-xxl-3 {
                    margin-right: 1rem !important;
                }
                .me-xxl-4 {
                    margin-right: 1.5rem !important;
                }
                .me-xxl-5 {
                    margin-right: 3rem !important;
                }
                .me-xxl-auto {
                    margin-right: auto !important;
                }
                .mb-xxl-0 {
                    margin-bottom: 0 !important;
                }
                .mb-xxl-1 {
                    margin-bottom: 0.25rem !important;
                }
                .mb-xxl-2 {
                    margin-bottom: 0.5rem !important;
                }
                .mb-xxl-3 {
                    margin-bottom: 1rem !important;
                }
                .mb-xxl-4 {
                    margin-bottom: 1.5rem !important;
                }
                .mb-xxl-5 {
                    margin-bottom: 3rem !important;
                }
                .mb-xxl-auto {
                    margin-bottom: auto !important;
                }
                .ms-xxl-0 {
                    margin-left: 0 !important;
                }
                .ms-xxl-1 {
                    margin-left: 0.25rem !important;
                }
                .ms-xxl-2 {
                    margin-left: 0.5rem !important;
                }
                .ms-xxl-3 {
                    margin-left: 1rem !important;
                }
                .ms-xxl-4 {
                    margin-left: 1.5rem !important;
                }
                .ms-xxl-5 {
                    margin-left: 3rem !important;
                }
                .ms-xxl-auto {
                    margin-left: auto !important;
                }
                .p-xxl-0 {
                    padding: 0 !important;
                }
                .p-xxl-1 {
                    padding: 0.25rem !important;
                }
                .p-xxl-2 {
                    padding: 0.5rem !important;
                }
                .p-xxl-3 {
                    padding: 1rem !important;
                }
                .p-xxl-4 {
                    padding: 1.5rem !important;
                }
                .p-xxl-5 {
                    padding: 3rem !important;
                }
                .px-xxl-0 {
                    padding-right: 0 !important;
                    padding-left: 0 !important;
                }
                .px-xxl-1 {
                    padding-right: 0.25rem !important;
                    padding-left: 0.25rem !important;
                }
                .px-xxl-2 {
                    padding-right: 0.5rem !important;
                    padding-left: 0.5rem !important;
                }
                .px-xxl-3 {
                    padding-right: 1rem !important;
                    padding-left: 1rem !important;
                }
                .px-xxl-4 {
                    padding-right: 1.5rem !important;
                    padding-left: 1.5rem !important;
                }
                .px-xxl-5 {
                    padding-right: 3rem !important;
                    padding-left: 3rem !important;
                }
                .py-xxl-0 {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .py-xxl-1 {
                    padding-top: 0.25rem !important;
                    padding-bottom: 0.25rem !important;
                }
                .py-xxl-2 {
                    padding-top: 0.5rem !important;
                    padding-bottom: 0.5rem !important;
                }
                .py-xxl-3 {
                    padding-top: 1rem !important;
                    padding-bottom: 1rem !important;
                }
                .py-xxl-4 {
                    padding-top: 1.5rem !important;
                    padding-bottom: 1.5rem !important;
                }
                .py-xxl-5 {
                    padding-top: 3rem !important;
                    padding-bottom: 3rem !important;
                }
                .pt-xxl-0 {
                    padding-top: 0 !important;
                }
                .pt-xxl-1 {
                    padding-top: 0.25rem !important;
                }
                .pt-xxl-2 {
                    padding-top: 0.5rem !important;
                }
                .pt-xxl-3 {
                    padding-top: 1rem !important;
                }
                .pt-xxl-4 {
                    padding-top: 1.5rem !important;
                }
                .pt-xxl-5 {
                    padding-top: 3rem !important;
                }
                .pe-xxl-0 {
                    padding-right: 0 !important;
                }
                .pe-xxl-1 {
                    padding-right: 0.25rem !important;
                }
                .pe-xxl-2 {
                    padding-right: 0.5rem !important;
                }
                .pe-xxl-3 {
                    padding-right: 1rem !important;
                }
                .pe-xxl-4 {
                    padding-right: 1.5rem !important;
                }
                .pe-xxl-5 {
                    padding-right: 3rem !important;
                }
                .pb-xxl-0 {
                    padding-bottom: 0 !important;
                }
                .pb-xxl-1 {
                    padding-bottom: 0.25rem !important;
                }
                .pb-xxl-2 {
                    padding-bottom: 0.5rem !important;
                }
                .pb-xxl-3 {
                    padding-bottom: 1rem !important;
                }
                .pb-xxl-4 {
                    padding-bottom: 1.5rem !important;
                }
                .pb-xxl-5 {
                    padding-bottom: 3rem !important;
                }
                .ps-xxl-0 {
                    padding-left: 0 !important;
                }
                .ps-xxl-1 {
                    padding-left: 0.25rem !important;
                }
                .ps-xxl-2 {
                    padding-left: 0.5rem !important;
                }
                .ps-xxl-3 {
                    padding-left: 1rem !important;
                }
                .ps-xxl-4 {
                    padding-left: 1.5rem !important;
                }
                .ps-xxl-5 {
                    padding-left: 3rem !important;
                }
                .text-xxl-start {
                    text-align: left !important;
                }
                .text-xxl-end {
                    text-align: right !important;
                }
                .text-xxl-center {
                    text-align: center !important;
                }
            }
            @media (min-width: 1200px) {
                .fs-1 {
                    font-size: 2.5rem !important;
                }
                .fs-2 {
                    font-size: 2rem !important;
                }
                .fs-3 {
                    font-size: 1.75rem !important;
                }
                .fs-4 {
                    font-size: 1.5rem !important;
                }
            }
            @media print {
                .d-print-inline {
                    display: inline !important;
                }
                .d-print-inline-block {
                    display: inline-block !important;
                }
                .d-print-block {
                    display: block !important;
                }
                .d-print-grid {
                    display: grid !important;
                }
                .d-print-table {
                    display: table !important;
                }
                .d-print-table-row {
                    display: table-row !important;
                }
                .d-print-table-cell {
                    display: table-cell !important;
                }
                .d-print-flex {
                    display: flex !important;
                }
                .d-print-inline-flex {
                    display: inline-flex !important;
                }
                .d-print-none {
                    display: none !important;
                }
            }
            /*# sourceMappingURL=bootstrap.min.css.map */

            :root {
                --bov-pure-white: #fff;
                --bov-almost-black: #211d1d;
                --bov-lightest-grey: #dadcde;
                --bov-light-grey: #c1c5c8;
                --bov-mid-grey: #8b9298;
                --bov-dark-grey: #6c747a;
                --bov-primary-light: #dab6cc;
                --bov-primary-lightest: #f6eef3;
                --bov-primary-lightest-rgb: 246, 238, 243;
                --bov-primary-100: #eae1e5;
                --bov-primary-300: #b9a2ae;
                --bov-primary-400: #9b3676;
                --bov-primary-500: #840b55;
                --bov-primary-600: #76094c;
                --bov-gradient-2: linear-gradient(115.74deg, #840b55 0%, #9b3676 112.85%);
                --background: #f7f7f7;
                --error: #db3b21;
                --warning: #f8f5b1;
                --success: #1aaa55;
                --scrollbar-padding-right: 0.325rem;
                --bov-footer: #2d2d2d;
                --bov-footer-white: rgba(255, 255, 255, 0.6);
                --bov-desktop-margin: 5rem;
                --bov-mobile-margin: 0.75rem;
            }

            html,
            body {
                font-family: "Lato", Helvetica, Arial, sans-serif;
                background: var(--background);
                color: var(--bov-almost-black);
            }

            main {
                position: relative;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            section {
                padding-top: 8rem;
                padding-bottom: 96px;
            }

            h1,
            h2,
            h3,
            h4 {
                font-weight: 500;
                margin-bottom: 0;
            }

            h1 {
                font-size: 2rem;
                line-height: 2.4375rem;
                color: var(--bov-primary-600);
            }

            h2 {
                font-size: 1.5rem;
                line-height: 1.8125rem;
                color: var(--bov-primary-600);
            }

            h3 {
                font-size: 1.3125rem;
                line-height: 1.625rem;
            }

            h4 {
                font-size: 1.125rem;
                line-height: 1.375rem;
            }

            a,
            a:hover {
                color: var(--bov-primary-500);
                letter-spacing: 0.004em;
                line-height: 100%;
                font-weight: 500;
                text-decoration: underline;
            }

            button,
            a.button {
                border-radius: 4px;
                background: var(--bov-pure-white);
                border: 1px solid var(--bov-primary-500);
                color: var(--bov-primary-500);
                padding: 1rem 2rem;
                font-weight: 700;
                font-size: 1.125rem;
                line-height: 1.5rem;
                letter-spacing: 0.006rem;
                text-decoration: none;
            }

            a.button {
                display: inline-block;
            }

            button.text,
            a.button.text {
                background: transparent;
                border: none;
                text-decoration: underline;
                padding: 0;
            }

            button.small,
            a.button.small {
                padding: 0.5rem 1rem;
            }

            button.primary.outline,
            .button.primary.outline {
                background: transparent;
                color: var(--bov-primary-500);
            }

            button.primary,
            a.button.primary {
                background: var(--bov-primary-400);
                color: var(--bov-pure-white);
                border: 1px solid var(--bov-primary-400);
            }

            button.primary:hover,
            a.button.primary:hover {
                background: var(--bov-primary-600);
                text-decoration: none;
                color: var(--bov-pure-white);
            }

            button.primary:disabled,
            a.button.primary:disabled {
                background: var(--bov-gradient-2);
                opacity: 0.3;
            }

            button.primary.outline,
            a.button.primary.outline {
                background: var(--bov-pure-white);
                color: var(--bov-primary-500);
                border-color: var(--bov-primary-500);
            }

            button.primary.outline:hover,
            a.button.primary.outline:hover {
                border-color: var(--bov-primary-300);
                background: #fff5fa;
                color: var(--bov-almost-black);
            }

            button.primary.outline:focus,
            a.button.primary.outline:focus {
                border-color: var(--bov-primary-300);
                background: var(--bov-pure-white);
                box-shadow: 0px 0px 0px 3px var(--bov-primary-400);
            }

            button.primary.outline:disabled,
            a.button.primary.outline[disabled] {
                border-color: var(--bov-primary-500);
                background: var(--bov-pure-white);
                color: var(--bov-primary-500);
                opacity: 0.3;
            }

            footer {
                background: var(--bov-footer);
                color: var(--bov-footer-white);
                width: 100%;
                margin-top: auto;
            }

            footer .links-container {
                display: block;
                padding: 1rem 0;
                border-bottom: 1px solid var(--bov-footer-white);
            }

            footer .info-container {
                display: flex;
                padding: 1rem 0;
                justify-content: space-between;
                font-size: 0.75rem;
            }

            footer .privacy-policy,
            footer .privacy-policy a,
            footer .privacy-policy a:hover {
                color: var(--bov-pure-white);
            }

            footer a,
            footer a:hover {
                color: var(--bov-footer-white);
                text-decoration: none;
            }

            footer .header-link {
                display: none;
                cursor: pointer;
            }

            footer svg.icon {
                width: 0.625rem;
                height: 0.625rem;
            }

            @media (max-width: 1024px) {
                footer {
                    position: unset;
                }

                footer .links-container {
                    height: unset;
                    display: block;
                    border-color: var(--bov-pure-white);
                }

                footer .header-link {
                    justify-content: space-between;
                    color: var(--bov-pure-white);
                }
            }

            .warning-indicator {
                text-align: center;
                background-color: var(--background);
                overflow: hidden;
            }

            .warning-indicator .message-container {
                padding: 9.5rem 0 9rem 0;
            }

            .warning-indicator h1 {
                color: var(--bov-almost-black);
                font-size: 4rem;
                line-height: 4.8125rem;
            }

            .warning-indicator h2 {
                color: var(--bov-almost-black);
                padding: 2rem 0 2.5rem;
            }

            @media screen and (max-width: 1024px) {
                .warning-indicator .message-container {
                    padding: 5.5rem 0 2rem 0;
                }
            }

            hr {
                color: var(--bov-light-grey);
            }

            .text-muted {
                color: var(--bov-dark-grey);
            }

            .page-content {
                padding-bottom: 2rem;
            }

            .content-grow {
                display: flex;
                flex-grow: 1;
            }

            .form-container {
                background-color: var(--bov-pure-white);
                padding: 2rem 3rem;
                margin: 3rem 0;
            }

            form .required::after {
                content: " *";
                font-weight: bold;
                color: var(--error);
            }

            .scrollbar::-webkit-scrollbar {
                width: 6px;
                height: 6px;
            }

            .scrollbar::-webkit-scrollbar-track {
                background: transparent;
            }

            .scrollbar::-webkit-scrollbar-thumb {
                background: #840b55;
                border-radius: 26px;
            }

            .blazored-modal {
                padding-left: 0 !important;
                padding-right: 0 !important;
            }

            #blazor-error-ui {
                background: lightyellow;
                bottom: 0;
                box-shadow: 0 -1px 2px rgba(0, 0, 0, 0.2);
                display: none;
                left: 0;
                padding: 0.6rem 1.25rem 0.7rem 1.25rem;
                position: fixed;
                width: 100%;
                z-index: 1000;
            }

            #blazor-error-ui .dismiss {
                cursor: pointer;
                position: absolute;
                right: 0.75rem;
                top: 0.5rem;
            }

            .blazor-error-boundary {
                background:
                    url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTYiIGhlaWdodD0iNDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIG92ZXJmbG93PSJoaWRkZW4iPjxkZWZzPjxjbGlwUGF0aCBpZD0iY2xpcDAiPjxyZWN0IHg9IjIzNSIgeT0iNTEiIHdpZHRoPSI1NiIgaGVpZ2h0PSI0OSIvPjwvY2xpcFBhdGg+PC9kZWZzPjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMCkiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMzUgLTUxKSI+PHBhdGggZD0iTTI2My41MDYgNTFDMjY0LjcxNyA1MSAyNjUuODEzIDUxLjQ4MzcgMjY2LjYwNiA1Mi4yNjU4TDI2Ny4wNTIgNTIuNzk4NyAyNjcuNTM5IDUzLjYyODMgMjkwLjE4NSA5Mi4xODMxIDI5MC41NDUgOTIuNzk1IDI5MC42NTYgOTIuOTk2QzI5MC44NzcgOTMuNTEzIDI5MSA5NC4wODE1IDI5MSA5NC42NzgyIDI5MSA5Ny4wNjUxIDI4OS4wMzggOTkgMjg2LjYxNyA5OUwyNDAuMzgzIDk5QzIzNy45NjMgOTkgMjM2IDk3LjA2NTEgMjM2IDk0LjY3ODIgMjM2IDk0LjM3OTkgMjM2LjAzMSA5NC4wODg2IDIzNi4wODkgOTMuODA3MkwyMzYuMzM4IDkzLjAxNjIgMjM2Ljg1OCA5Mi4xMzE0IDI1OS40NzMgNTMuNjI5NCAyNTkuOTYxIDUyLjc5ODUgMjYwLjQwNyA1Mi4yNjU4QzI2MS4yIDUxLjQ4MzcgMjYyLjI5NiA1MSAyNjMuNTA2IDUxWk0yNjMuNTg2IDY2LjAxODNDMjYwLjczNyA2Ni4wMTgzIDI1OS4zMTMgNjcuMTI0NSAyNTkuMzEzIDY5LjMzNyAyNTkuMzEzIDY5LjYxMDIgMjU5LjMzMiA2OS44NjA4IDI1OS4zNzEgNzAuMDg4N0wyNjEuNzk1IDg0LjAxNjEgMjY1LjM4IDg0LjAxNjEgMjY3LjgyMSA2OS43NDc1QzI2Ny44NiA2OS43MzA5IDI2Ny44NzkgNjkuNTg3NyAyNjcuODc5IDY5LjMxNzkgMjY3Ljg3OSA2Ny4xMTgyIDI2Ni40NDggNjYuMDE4MyAyNjMuNTg2IDY2LjAxODNaTTI2My41NzYgODYuMDU0N0MyNjEuMDQ5IDg2LjA1NDcgMjU5Ljc4NiA4Ny4zMDA1IDI1OS43ODYgODkuNzkyMSAyNTkuNzg2IDkyLjI4MzcgMjYxLjA0OSA5My41Mjk1IDI2My41NzYgOTMuNTI5NSAyNjYuMTE2IDkzLjUyOTUgMjY3LjM4NyA5Mi4yODM3IDI2Ny4zODcgODkuNzkyMSAyNjcuMzg3IDg3LjMwMDUgMjY2LjExNiA4Ni4wNTQ3IDI2My41NzYgODYuMDU0N1oiIGZpbGw9IiNGRkU1MDAiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvZz48L3N2Zz4=)
                        no-repeat 1rem/1.8rem,
                    #b32121;
                padding: 1rem 1rem 1rem 3.7rem;
                color: white;
            }

            .blazor-error-boundary::after {
                content: "An error has occurred.";
            }

            .invalid-field {
                border-color: var(--error);
            }

            .form-check-input:checked {
                background-color: var(--bov-primary-400);
                border-color: var(--bov-primary-400);
            }

            .form-check-input:focus {
                box-shadow: none;
                outline: none;
            }

            .form-floating > .form-control:focus ~ label,
            .form-floating > .form-select:focus ~ label {
                color: var(--bov-primary-400);
                opacity: 1;
            }

            .form-floating > .form-control:focus,
            .form-floating > .form-select:focus {
                border: 2px solid var(--bov-primary-400);
                border-radius: 4px;
                box-shadow: none;
                outline: none;
            }

            .form-floating > .form-control.filled:focus ~ label,
            .form-floating > .form-control.filled:not(:placeholder-shown) ~ label,
            .form-floating > .form-select.filled ~ label {
                color: var(--bov-primary-400);
                opacity: 1;
            }

            .validation-message {
                color: var(--error);
                font-size: 1rem;
                padding: 0rem 0.85rem;
                margin-top: 0.5rem;
                text-align: left;
            }

            .blazored-toast {
                width: unset !important;
                box-shadow: unset !important;
                background-color: var(--bov-primary-100) !important;
                border: unset !important;
                padding: 16px !important;
            }

            .blazored-toast-container {
                width: 66.66% !important;
            }

            .d-block-desktop {
                display: block;
            }

            .d-block-mobile {
                display: none;
            }

            .d-flex-desktop {
                display: flex;
            }

            .d-flex-mobile {
                display: none;
            }

            @media (max-width: 1024px) {
                .d-block-desktop {
                    display: none;
                }

                .d-block-mobile {
                    display: block;
                }

                .d-flex-desktop {
                    display: none;
                }

                .d-flex-mobile {
                    display: flex;
                }

                .container,
                .container-md,
                .container-sm {
                    max-width: 1024px !important;
                }

                .form-container {
                    margin: 0rem;
                    padding: 1rem;
                }

                section {
                    padding-bottom: unset;
                    margin-bottom: 16px;
                }

                .page-content {
                    padding-bottom: 0rem;
                }

                .blazored-toast-container {
                    width: 100% !important;
                }

                .blazored-toast {
                    margin-left: 16px !important;
                    margin-right: 16px !important;
                }
            }

            .reconnect-modal > div {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                padding-top: 6.25rem;
                padding-right: 1rem;
                padding-left: 1rem;
                z-index: 1000;
                overflow: hidden;
                text-align: center;
                font-weight: 500;
                font-size: 1.5rem;
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
            }

            .components-reconnect-hide > div {
                display: none;
            }

            .components-reconnect-show > div {
                display: none;
            }

            .components-reconnect-show > .show {
                display: block;
            }

            .components-reconnect-failed > div {
                display: none;
            }

            .components-reconnect-failed > .failed {
                display: block;
            }

            .components-reconnect-rejected > div {
                display: none;
            }

            .components-reconnect-rejected > .rejected {
                display: block;
            }

            .bm-container .blazored-modal:has(.clean-modal) {
                padding: 0;
            }
        </style>
        <style data-savepage-href="AppointmentBookingSystem.Web.3r71ya4yhk.styles.css">
            /*savepage-import-url=_content/Blazored.Modal/Blazored.Modal.bundle.scp.css*/ /* _content/Blazored.Modal/BlazoredModalInstance.razor.rz.scp.css */
            .bm-container[b-mwsrhhqq2g] {
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 100;
                overflow-x: hidden;
                overflow-y: auto;
                outline: 0;
                background-color: rgba(0, 0, 0, 0.5);
            }

            .blazored-modal[b-mwsrhhqq2g] {
                display: flex;
                flex-direction: column;
                background-color: #fff;
                border-radius: 4px;
                border: 1px solid #fff;
                padding: 1.5rem;
                box-shadow: 0 2px 2px rgba(0, 0, 0, 0.25);
                margin: 1.75rem;
            }

            .size-small[b-mwsrhhqq2g] {
                max-width: 300px;
                margin-left: auto;
                margin-right: auto;
            }

            .size-medium[b-mwsrhhqq2g] {
                max-width: 500px;
                margin-left: auto;
                margin-right: auto;
            }

            .size-large[b-mwsrhhqq2g] {
                max-width: 800px;
                margin-left: auto;
                margin-right: auto;
            }

            .size-extra-large[b-mwsrhhqq2g] {
                max-width: 1140px;
                margin-left: auto;
                margin-right: auto;
            }

            .size-automatic[b-mwsrhhqq2g] {
                width: -moz-fit-content;
                width: fit-content;
                margin-left: auto;
                margin-right: auto;
            }

            .bm-header[b-mwsrhhqq2g] {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                padding: 0 0 2rem 0;
            }

            .bm-title[b-mwsrhhqq2g] {
                margin-bottom: 0;
            }

            .bm-close[b-mwsrhhqq2g] {
                padding: 1rem;
                margin: -1rem -1rem -1rem auto;
                background-color: transparent;
                border: 0;
                -webkit-appearance: none;
                cursor: pointer;
                font-size: 1.5rem;
                font-weight: bold;
            }

            .position-topleft .blazored-modal[b-mwsrhhqq2g] {
                margin-left: 1.75rem;
            }

            .position-topright .blazored-modal[b-mwsrhhqq2g] {
                margin-right: 1.75rem;
            }

            .position-bottomleft .blazored-modal[b-mwsrhhqq2g] {
                position: absolute;
                bottom: 0;
                left: 1.75rem;
            }

            .position-bottomright .blazored-modal[b-mwsrhhqq2g] {
                position: absolute;
                bottom: 0;
                right: 1.75rem;
            }

            .position-middle[b-mwsrhhqq2g] {
                display: flex;
                flex-direction: column;
                justify-content: center;
            }

            .fade-in[b-mwsrhhqq2g] {
                animation: 300ms ease-out 0s ModalFadeIn-b-mwsrhhqq2g;
            }

            .fade-out[b-mwsrhhqq2g] {
                animation: 300ms ease-out 0s ModalFadeOut-b-mwsrhhqq2g;
                opacity: 0;
            }

            @keyframes ModalFadeIn-b-mwsrhhqq2g {
                0% {
                    opacity: 0;
                }

                100% {
                    opacity: 1;
                }
            }

            @keyframes ModalFadeOut-b-mwsrhhqq2g {
                0% {
                    opacity: 1;
                }

                100% {
                    opacity: 0;
                }
            }

            /*savepage-import-url=_content/Blazored.Toast/Blazored.Toast.bundle.scp.css*/ /* _content/Blazored.Toast/BlazoredToast.razor.rz.scp.css */
            .blazored-toast[b-jnm4noxjw5] {
                display: flex;
                position: relative;
                flex-direction: row;
                animation: fadein-b-jnm4noxjw5 1.5s;
                margin-bottom: 1rem;
                padding: 1rem 1.25rem;
                color: #1d1d1b;
                width: 20rem;
                border-radius: 0.25rem;
                box-shadow: rgba(0, 0, 0, 0.3) 0px 10px 30px 2px;
                background-color: #fff;
                border-top: 6px solid #fff;
            }

            .blazored-toast-component[b-jnm4noxjw5] {
                display: initial;
                padding: 0 0 0 0;
            }

            .blazored-toast-info[b-jnm4noxjw5] {
                border-top: 6px solid #2563eb;
            }

            .blazored-toast-info .blazored-toast-icon[b-jnm4noxjw5] {
                color: #2563eb;
            }

            .blazored-toast-success[b-jnm4noxjw5] {
                border-top: 6px solid #16a34a;
            }

            .blazored-toast-success .blazored-toast-icon[b-jnm4noxjw5] {
                color: #16a34a;
            }

            .blazored-toast-warning[b-jnm4noxjw5] {
                border-top: 6px solid #eab308;
            }

            .blazored-toast-warning .blazored-toast-icon[b-jnm4noxjw5] {
                color: #eab308;
            }

            .blazored-toast-error[b-jnm4noxjw5] {
                border-top: 6px solid #dc2626;
            }

            .blazored-toast-error .blazored-toast-icon[b-jnm4noxjw5] {
                color: #dc2626;
            }

            .blazored-toast-icon[b-jnm4noxjw5] {
                display: flex;
                flex-direction: column;
                justify-content: start;
                padding: 0 1rem 0 0;
                font-size: 1.5rem;
            }

            .blazored-toast .blazored-toast-message[b-jnm4noxjw5] {
                flex-grow: 1;
                margin-bottom: 0;
                font-weight: 500;
                font-size: 0.875rem;
                overflow-wrap: break-word;
                word-wrap: break-word;
                word-break: break-word;
                -ms-hyphens: auto;
                -moz-hyphens: auto;
                -webkit-hyphens: auto;
                hyphens: auto;
            }

            .blazored-toast .blazored-toast-close[b-jnm4noxjw5] {
                display: flex;
                flex-direction: column;
                justify-content: start;
                padding: 0 0 0 1rem;
                background-color: transparent;
                border: 0;
                -webkit-appearance: none;
                color: #94a3b8;
                font-size: 0.9rem;
            }

            .blazored-toast .blazored-toast-close:hover[b-jnm4noxjw5] {
                color: inherit;
            }

            .blazored-toast .blazored-toast-progressbar[b-jnm4noxjw5] {
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                height: 6px;
                border-bottom-left-radius: 0.375rem;
                border-bottom-right-radius: 0.375rem;
            }

            .blazored-toast .blazored-toast-progressbar > span[b-jnm4noxjw5] {
                position: absolute;
                filter: brightness(75%);
                height: 6px;
                border-bottom-left-radius: 0.375rem;
                background-image: linear-gradient(rgba(0, 0, 0, 0.1) 0 0);
                transition: all 0.1s linear;
            }

            .blazored-toast-action[b-jnm4noxjw5] {
                cursor: pointer;
            }

            @keyframes fadein-b-jnm4noxjw5 {
                from {
                    opacity: 0;
                }

                to {
                    opacity: 1;
                }
            }
            /* _content/Blazored.Toast/BlazoredToasts.razor.rz.scp.css */
            .blazored-toast-container[b-y65zu6vhcs] {
                display: flex;
                flex-direction: column;
                position: fixed;
                z-index: 999;
            }

            .position-topleft[b-y65zu6vhcs],
            .position-topright[b-y65zu6vhcs],
            .position-topcenter[b-y65zu6vhcs] {
                top: 0;
            }

            .position-bottomleft[b-y65zu6vhcs],
            .position-bottomright[b-y65zu6vhcs],
            .position-bottomcenter[b-y65zu6vhcs] {
                bottom: 0;
            }

            @media (min-width: 576px) {
                .position-topleft[b-y65zu6vhcs] {
                    top: 2rem;
                    left: 2rem;
                }

                .position-topright[b-y65zu6vhcs] {
                    top: 2rem;
                    right: 2rem;
                }

                .position-topcenter[b-y65zu6vhcs] {
                    top: 2rem;
                    left: 50%;
                    transform: translate(-50%, 0%);
                }

                .position-bottomleft[b-y65zu6vhcs] {
                    bottom: 2rem;
                    left: 2rem;
                }

                .position-bottomright[b-y65zu6vhcs] {
                    bottom: 2rem;
                    right: 2rem;
                }

                .position-bottomcenter[b-y65zu6vhcs] {
                    bottom: 2rem;
                    left: 50%;
                    transform: translate(-50%, 0%);
                }

                .blazored-toast[b-y65zu6vhcs] {
                    width: 30rem;
                    border-radius: 0.25rem;
                }
            }

            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/Card.razor.rz.scp.css */
            .card[b-o04t2nump2] {
                display: flex;
                align-items: center;
                width: 100%;
                color: var(--bov-almost-black);
                background: var(--bov-pure-white);
                font-weight: 500;
                border: 1px solid #f5f0f2;
                box-shadow:
                    0px 9px 4px rgba(90, 19, 64, 0.01),
                    0px 5px 3px rgba(90, 19, 64, 0.02),
                    0px 2px 2px rgba(90, 19, 64, 0.03),
                    0px 1px 1px rgba(90, 19, 64, 0.04),
                    0px 0px 0px rgba(90, 19, 64, 0.04);
                border-radius: 8px;
                margin-bottom: 1.25rem;
                text-align: left;
            }

            .card:hover[b-o04t2nump2],
            .card:focus[b-o04t2nump2] {
                background: var(--bov-primary-lightest);
                border: 1px solid #f2dfe7;
                outline: none;
            }

            .card:focus[b-o04t2nump2] {
                border: 2px solid var(--bov-primary-400);
            }

            .card .title[b-o04t2nump2] {
                font-size: 1.3125rem;
                font-weight: 500;
            }

            .card .subtitle[b-o04t2nump2] {
                padding-top: 0.5rem;
                color: var(--bov-mid-grey);
            }

            .card.selected[b-o04t2nump2] {
                border: 2px solid var(--bov-primary-400);
                background-color: var(--bov-pure-white);
            }

            .card .icon-container[b-o04t2nump2] {
                display: flex;
                align-items: center;
            }

            .card .icon-container .icon-suffix[b-o04t2nump2] {
                color: var(--bov-primary-400);
                margin-left: 0.340625rem;
            }

            .card .topic-header[b-o04t2nump2] {
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                width: 100%;
            }

            .card.card-appointment-type[b-o04t2nump2] {
                height: 12.5rem;
                flex-direction: column;
                justify-content: center;
            }

            .card.card-appointment-type .icon-container[b-o04t2nump2] .icon {
                width: 3.5rem;
                height: 3.5rem;
            }

            .card.card-service[b-o04t2nump2] {
                justify-content: space-between;
                flex-direction: row;
                padding: 0 1.5rem;
            }

            .card.card-topic[b-o04t2nump2] {
                padding: 2rem;
                flex-direction: column;
                align-items: start;
            }

            .card.card-topic .icon-container[b-o04t2nump2] .icon {
                width: 2rem;
                height: 2rem;
            }

            .card.card-service[b-o04t2nump2] {
                height: 6rem;
            }

            .card.card-service .icon-container[b-o04t2nump2] {
                width: 9rem;
                border-left: 1px solid var(--bov-lightest-grey);
                padding-left: 1rem;
            }

            .card.card-service .icon-container[b-o04t2nump2] .icon {
                width: 2rem;
                height: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/OnlineServiceSelector.razor.rz.scp.css */
            .virtual-appointment-alert[b-7cdv355u01] {
                display: flex;
                padding: 1rem 0.5rem 1rem 0.5rem;
                gap: 0.5rem;
                border-radius: 0.25rem;
                border: 0.0625rem solid var(--bov-primary-400);
                margin-top: 0.5rem;
                margin-bottom: 1rem;
                font-size: 0.875rem;
                align-items: center;
                text-align: left;
            }

            .virtual-appointment-alert[b-7cdv355u01] .icon {
                width: 2rem;
                height: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/PolicyCheckbox.razor.rz.scp.css */
            .form-check-input:checked[b-84hiwago19] {
                background-color: var(--bov-primary-400);
                border-color: var(--bov-primary-400);
            }

            .form-check-input:focus[b-84hiwago19] {
                box-shadow: none;
                outline: none;
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/SearchBar.razor.rz.scp.css */
            input:focus[b-t7o0q1nkdc] {
                outline: none;
                background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cg clip-path='url(%23clip0_4230_4107)'%3E%3Cpath d='M10.875 18.75C15.2242 18.75 18.75 15.2242 18.75 10.875C18.75 6.52576 15.2242 3 10.875 3C6.52576 3 3 6.52576 3 10.875C3 15.2242 6.52576 18.75 10.875 18.75Z' stroke='%23840B55' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M16.4438 16.4438L21.0001 21.0001' stroke='%23840B55' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_4230_4107'%3E%3Crect width='24' height='24' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E%0A");
            }

            input[b-t7o0q1nkdc] {
                border-radius: 4px;
                border: 0;
                padding: 1rem 0.75rem;
                color: var(--bov-mid-grey);
                caret-color: var(--bov-primary-600);
                text-indent: 1.75rem;
                background-origin: content-box, padding-box;
                background-image: url("data:image/svg+xml,%3csvg fill='none' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3e%3cpath d='M21.75 37.5C30.4485 37.5 37.5 30.4485 37.5 21.75C37.5 13.0515 30.4485 6 21.75 6C13.0515 6 6 13.0515 6 21.75C6 30.4485 13.0515 37.5 21.75 37.5Z' stroke='%238b9298' stroke-width='3' stroke-linecap='round' stroke-linejoin='round' /%3e %3cpath d='M32.8875 32.8877L42 42.0002' stroke='%238b9298' stroke-width='3' stroke-linecap='round' stroke-linejoin='round' /%3e%3c/svg%3e");
                background-repeat: no-repeat;
            }

            input[b-t7o0q1nkdc]::placeholder {
                color: var(--bov-mid-grey);
                text-indent: 1.75rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/StepHeader.razor.rz.scp.css */
            .subtitle-without-description[b-1z4idk4s02] {
                padding-bottom: 1rem;
            }

            @media (max-width: 1024px) {
                h3[b-1z4idk4s02] {
                    font-size: 0.875rem;
                }

                .subtitle-with-description[b-1z4idk4s02] {
                    padding-top: 1.5rem;
                    padding-bottom: 1.5rem;
                }

                .subtitle-without-description[b-1z4idk4s02] {
                    padding-top: 1.5rem;
                    padding-bottom: 1.5rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Elements/Stepper.razor.rz.scp.css */
            .stepper[b-7bpnzocm0j] {
                display: flex;
                justify-content: center;
                margin: 1.125rem 0;
            }

            .stepper .step[b-7bpnzocm0j] {
                background: var(--bov-lightest-grey);
                border-radius: 10px;
                width: 2.8125rem;
                height: 0.25rem;
                margin-right: 0.375rem;
            }

            .stepper .step.active[b-7bpnzocm0j] {
                background: var(--bov-primary-400);
            }

            @media (max-width: 1024px) {
                .stepper[b-7bpnzocm0j] {
                    margin: 0;
                    margin-top: 0.5rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Steps/AppointmentTopicSelector.razor.rz.scp.css */
            .groups[b-yjg1f10on0] {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-around;
            }

            .groups div[b-yjg1f10on0] {
                width: 50%;
            }

            .groups[b-yjg1f10on0] .card {
                width: 100%;
            }

            @media (max-width: 1024px) {
                .groups[b-yjg1f10on0] {
                    flex-direction: column;
                }

                .groups > div[b-yjg1f10on0] {
                    width: 100%;
                }

                .groups div:nth-child(odd)[b-yjg1f10on0] {
                    order: 1;
                }

                .groups div:nth-child(even)[b-yjg1f10on0] {
                    order: 2;
                }

                .groups div:last-child[b-yjg1f10on0] {
                    order: 3;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Steps/BranchSelector.razor.rz.scp.css */
            .branch-search[b-t6bfoe6o1w],
            .branch-search-virtual[b-t6bfoe6o1w] {
                padding: 1rem;
                background-color: var(--bov-primary-400);
                text-align: left;
                border-top-left-radius: 8px;
                color: var(--bov-pure-white);
            }

            .branch-search-virtual[b-t6bfoe6o1w] {
                border-top-right-radius: 8px;
            }

            .branch-frame[b-t6bfoe6o1w] {
                background: var(--bov-pure-white);
                text-align: left;
                padding-top: 0.1rem;
                padding-right: var(--scrollbar-padding-right);
                padding-bottom: 0;
            }

            .branch-container[b-t6bfoe6o1w] {
                height: 38rem;
                overflow: scroll;
            }

            .branch-container .single-branch-container[b-t6bfoe6o1w] {
                padding: 0.9375rem 1rem 1.5rem;
                border-bottom: 1px solid var(--bov-lightest-grey);
            }

            .branch-container .single-branch-container:last-child[b-t6bfoe6o1w] {
                border-bottom: none;
            }

            .branch-container .single-branch-container .name[b-t6bfoe6o1w] {
                font-weight: 600;
                margin-bottom: 0.25rem;
            }

            .branch-container .single-branch-container .address[b-t6bfoe6o1w] {
                margin-bottom: 0.25rem;
            }

            .branch-container .single-branch-container details[b-t6bfoe6o1w] {
                margin-bottom: 1.5rem;
            }

            .branch-container .single-branch-container details summary[b-t6bfoe6o1w] {
                font-weight: 500;
                background: transparent;
                border: none;
                color: var(--bov-primary-500);
                padding: 0;
                font-size: 1rem;
                letter-spacing: 0.004rem;
                text-decoration: underline;
                list-style: none;
            }

            .branch-container .single-branch-container details[open] summary[b-t6bfoe6o1w] {
                margin-bottom: 1.6875rem;
            }

            .branch-container .single-branch-container details[open] summary span:first-child[b-t6bfoe6o1w],
            .branch-container .single-branch-container details:not([open]) summary span:last-child[b-t6bfoe6o1w] {
                display: none;
            }

            .branch-container .single-branch-container details summary span[b-t6bfoe6o1w]::after {
                content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
                width: 1rem;
                height: 1rem;
                margin-left: 5px;
                display: inline-block;
                vertical-align: text-top;
            }

            .branch-container .single-branch-container details summary span:last-child[b-t6bfoe6o1w]::after {
                transform: rotate(180deg);
                vertical-align: text-bottom;
            }

            .branch-container .single-branch-container details dl dt[b-t6bfoe6o1w] {
                color: var(--bov-mid-grey);
                padding-bottom: 0.5rem;
                font-weight: 400;
                text-transform: uppercase;
            }

            .branch-container .single-branch-container details dl dd[b-t6bfoe6o1w] {
                margin-bottom: 0.25rem;
            }

            .branch-container .single-branch-container details dl dd ul[b-t6bfoe6o1w] {
                list-style-type: none;
                margin-bottom: 0;
            }

            .branch-container .single-branch-container button.primary[b-t6bfoe6o1w] {
                padding: 0.5rem 3.5rem;
            }

            .branch-container .single-branch-container.selected[b-t6bfoe6o1w] {
                background-color: var(--bov-primary-lightest);
            }

            .mobile-branch-container[b-t6bfoe6o1w] {
                width: calc(100% / 3);
            }

            .map-container[b-t6bfoe6o1w] {
                width: calc(100% * 2 / 3);
            }

            #map[b-t6bfoe6o1w] {
                height: 100%;
                width: 100%;
                min-height: 700px;
            }

            .branch-message[b-t6bfoe6o1w] {
                display: flex;
                gap: 0.5rem;
                background: var(--bov-primary-lightest);
                border-radius: 0.25rem;
                border: solid 0.0625rem var(--bov-primary-500);
                padding: 0.5rem;
                margin-bottom: 1.5rem;
                font-size: 0.875rem;
                line-height: 1.05rem;
            }

            .branch-message[b-t6bfoe6o1w] .icon {
                width: 1rem;
                height: 1rem;
            }

            .branch-message[b-t6bfoe6o1w] p:last-child {
                margin-bottom: 0;
            }

            .branch-message[b-t6bfoe6o1w] button.branch-reference {
                user-select: auto;
                color: var(--bov-primary-500);
                padding: 0;
                font-size: 0.875rem;
                font-weight: 700;
            }

            @media (max-width: 1024px) {
                .branch-search[b-t6bfoe6o1w] {
                    border-top-right-radius: 8px;
                }

                .mobile-branch-container[b-t6bfoe6o1w] {
                    width: 100%;
                    padding-left: 0rem;
                    padding-right: 0rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Steps/Business/BusinessDetailsForm.razor.rz.scp.css */
            p[b-39g8kb2326] {
                margin-bottom: 1.5rem;
                text-align: left;
            }
            /* _content/AppointmentBookingSystem.Web/Components/AppointmentBooking/Steps/QueryContact/QueryContactForm.razor.rz.scp.css */
            [b-csyakgqkoj] .d-block-desktop .description {
                margin-top: 2.4rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/AppointmentLogs/AppointmentLogDetails.razor.rz.scp.css */
            .appointment-details[b-7fvzj8y4dd] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
                background-color: var(--bov-pure-white);
                padding: 2rem;
                width: 37.125rem;
            }

            .appointment-details dt:not(:first-child)[b-7fvzj8y4dd] {
                margin-top: 1.5rem;
            }

            .appointment-details dl dt[b-7fvzj8y4dd] {
                letter-spacing: 0.004rem;
                font-weight: 500;
                line-height: 1.25rem;
                color: var(--bov-primary-500);
                margin-bottom: 0.5rem;
            }

            .appointment-details dd[b-7fvzj8y4dd] {
                margin-bottom: 0;
                word-wrap: break-word;
            }

            .appointment-details dd.unavailable[b-7fvzj8y4dd] {
                font-style: italic;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/AppointmentLogs/AppointmentVersionHistory.razor.rz.scp.css */
            .history-container[b-ih97w8wcg8] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
                padding: 1rem;
                min-width: 21rem;
                background-color: var(--bov-pure-white);
                border-top-left-radius: 0.5rem;
            }

            .history-container .history-title[b-ih97w8wcg8] {
                font-size: 1rem;
                line-height: 1.2rem;
                color: var(--bov-primary-600);
            }

            .history-container .history-items[b-ih97w8wcg8] {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }

            .history-container[b-ih97w8wcg8] .history-item {
                display: flex;
                flex-direction: column;
                gap: 0.625rem;
                padding: 0.563rem 0.75rem 0.75rem 0.75rem;
                border-radius: 0.25rem;
                font-size: 0.875rem;
                line-height: 1.05rem;
                color: var(--bov-almost-black);
                text-decoration: none;
            }

            .history-container[b-ih97w8wcg8] .history-item.active {
                background-color: var(--bov-primary-lightest);
            }

            .history-container[b-ih97w8wcg8] .history-user {
                color: var(--bov-dark-grey);
            }

            @media print {
                .history-container[b-ih97w8wcg8] .history-item.active {
                    background-color: var(--bov-primary-lightest) !important;
                    print-color-adjust: exact;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/AppointmentLogs/LogDetailsComponent.razor.rz.scp.css */
            .details-header[b-0uz4e7pffq] {
                display: flex;
                justify-content: space-between;
            }

            .layout-container[b-0uz4e7pffq] {
                display: grid;
                grid-template-columns: 1fr auto 1fr;
                gap: 2rem;
                margin-top: 2rem;
            }

            .layout-container .details-component[b-0uz4e7pffq] {
                grid-column: 2;
            }

            .layout-container .history-component[b-0uz4e7pffq] {
                grid-column: 3;
                justify-self: end;
                margin-right: -1rem;
            }

            .layout-container .history-component[b-0uz4e7pffq] .history-container {
                height: max(var(--details-height), 100dvh - var(--details-offset));
                overflow-y: auto;
            }

            @media print {
                .details-header[b-0uz4e7pffq] .print {
                    display: none;
                }

                .layout-container .history-component[b-0uz4e7pffq] .history-container {
                    height: auto;
                }

                .layout-container .history-component[b-0uz4e7pffq] .history-item {
                    break-inside: avoid;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/AppointmentLogs/LogsListComponent.razor.rz.scp.css */
            .component-header[b-7n6wyp6t4x] {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .component-results-message[b-7n6wyp6t4x] {
                font-weight: 700;
                line-height: 1.5rem;
                text-align: left;
                margin-top: 2rem;
            }

            [b-7n6wyp6t4x] .email {
                color: var(--bov-dark-grey);
            }

            [b-7n6wyp6t4x] .icon {
                width: 1rem;
                height: 1rem;
            }

            [b-7n6wyp6t4x] .action {
                display: inline-block;
                border: 1px solid var(--bov-primary-400);
                border-radius: 0.1875rem;
            }

            .results[b-7n6wyp6t4x] {
                margin-block: 0.5rem;
                display: flex;
                flex-direction: column;
                gap: 0.8rem;
            }

            .component-filter .filter-item[b-7n6wyp6t4x] {
                display: inline-flex;
                gap: 0.5rem;
                padding: 0.25rem 0.5rem;
                line-height: 1.625rem;
                letter-spacing: 0.02em;
            }

            .component-filter .filter-item .filter-item-label[b-7n6wyp6t4x] {
                color: var(--bov-primary-500);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchFilters.razor.rz.scp.css */
            .appointments-search-filters[b-55uzh8glj0] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                background: var(--bov-pure-white);
                padding: 1rem;
                margin: 1rem 0 1.5rem;
            }

            .warning-message[b-55uzh8glj0] {
                margin-top: 4.6875rem;
                text-align: center;
            }

            .warning-message .title[b-55uzh8glj0] {
                color: var(--bov-almost-black);
                font-size: 1.625rem;
            }

            .warning-message .message[b-55uzh8glj0] {
                margin-top: 0.3125rem;
                font-size: 1.0625rem;
            }

            .warning-message .footer[b-55uzh8glj0] {
                letter-spacing: 0.015625rem;
                margin-top: 1.125rem;
                color: var(--bov-mid-grey);
            }

            .filters[b-55uzh8glj0] {
                display: flex;
                flex-direction: row;
                column-gap: 1rem;
            }

            .filters .action[b-55uzh8glj0] {
                margin-left: auto;
            }

            .filters .branch-filter[b-55uzh8glj0] {
                flex-grow: 1;
            }

            .filters .date-range-filter[b-55uzh8glj0] {
                flex-grow: 0;
            }

            .filters .customer-info-filter[b-55uzh8glj0] {
                flex-grow: 1;
            }

            .filters .customer-info-filter-text[b-55uzh8glj0] {
                flex-grow: 2;
            }

            .filters .customer-info-filter[b-55uzh8glj0] .form-control {
                padding-top: 0;
                padding-bottom: 0;
            }

            .filters[b-55uzh8glj0] .validation-message {
                padding-left: 0;
            }

            .filters .date-range-filter[b-55uzh8glj0] .validation-message {
                width: 0;
                white-space: nowrap;
            }

            .filters[b-55uzh8glj0] option {
                background: #eae2e2;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchFiltersV0.razor.rz.scp.css */
            .appointments-search-filters[b-hvl2lt0bkb] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                background: var(--bov-pure-white);
                padding: 1rem;
                margin: 1rem 0 1.5rem;
            }

            .warning-message[b-hvl2lt0bkb] {
                margin-top: 4.6875rem;
                text-align: center;
            }

            .warning-message .title[b-hvl2lt0bkb] {
                color: var(--bov-almost-black);
                font-size: 1.625rem;
            }

            .warning-message .message[b-hvl2lt0bkb] {
                margin-top: 0.3125rem;
                font-size: 1.0625rem;
            }

            .warning-message .footer[b-hvl2lt0bkb] {
                letter-spacing: 0.015625rem;
                margin-top: 1.125rem;
                color: var(--bov-mid-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchPaginator.razor.rz.scp.css */
            .paginator[b-jwock6ce7c] {
                margin-top: 1rem;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 0.8rem;
            }

            .paginator > div[b-jwock6ce7c] {
                cursor: pointer;
            }

            .paginator[b-jwock6ce7c] .active {
                color: var(--bov-primary-400);
            }

            .paginator[b-jwock6ce7c] .disabled {
                cursor: initial;
            }

            .paginator[b-jwock6ce7c] .disabled .icon {
                color: var(--bov-dark-grey);
            }

            [b-jwock6ce7c] .icon {
                width: 16px;
                height: 16px;
                color: var(--bov-almost-black);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchResultFiltersModal.razor.rz.scp.css */
            .filter[b-hxjt8kup2x] {
                display: flex;
                flex-direction: column;
            }

            .filter .item[b-hxjt8kup2x] {
                padding: 1rem;
                border-bottom: 1px solid var(--bov-light-grey);
            }

            .filter .item:last-child[b-hxjt8kup2x] {
                border-bottom: none;
            }

            .filter .filter-header[b-hxjt8kup2x] {
                display: flex;
                justify-content: center;
                align-items: center;
                position: relative;
                color: var(--bov-primary-600);
            }

            .filter .filter-header .close[b-hxjt8kup2x] {
                display: flex;
                justify-content: center;
                align-items: center;
                position: absolute;
                right: 0;
                height: 1.5rem;
                width: 1.5rem;
                padding: 0;
                border: none;
            }

            .filter .filter-content[b-hxjt8kup2x] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
                overflow-y: hidden;
                max-height: 40rem;
            }

            .filter .filter-content[b-hxjt8kup2x] details:first-child {
                border-bottom: solid 1px var(--bov-lightest-grey);
                padding-bottom: 1rem;
            }

            .filter .filter-content[b-hxjt8kup2x] details[open] {
                overflow-y: auto;
            }

            .filter .filter-content[b-hxjt8kup2x] details[open] summary {
                position: sticky;
                top: 0;
                background: white;
                z-index: 1;
            }

            .filter .filter-footer[b-hxjt8kup2x] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
            }

            .clear-button[b-hxjt8kup2x] {
                border: none;
            }

            .checkbox-group[b-hxjt8kup2x] {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 1rem;
                margin-top: 1rem;
                justify-content: space-between;
            }

            .checkbox-group[b-hxjt8kup2x] input[type="checkbox"] {
                width: 2rem;
                height: 2rem;
                border-width: 2px;
                margin: 0.3125rem;
            }

            .checkbox-group .group-name[b-hxjt8kup2x] {
                font-weight: 700;
                line-height: 1.2rem;
                grid-column: span 3;
            }

            .checkbox-label[b-hxjt8kup2x] {
                display: flex;
                align-items: center;
            }

            .checkbox-label[b-hxjt8kup2x] input[type="checkbox"] {
                flex-shrink: 0;
            }

            .checkbox-label .checkbox-label-content[b-hxjt8kup2x] {
                display: flex;
                flex-direction: column;
                line-height: 1.2rem;
                margin-left: 0.5rem;
                color: #2b1e3b;
            }

            .email[b-hxjt8kup2x] {
                color: var(--bov-dark-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchResults.razor.rz.scp.css */
            .results[b-ovicl4vnpb] {
                display: flex;
                flex-direction: column;
                gap: 0.8rem;
                margin-block: 0.5rem;
            }

            [b-ovicl4vnpb] .icon {
                width: 1rem;
                height: 1rem;
            }

            [b-ovicl4vnpb] .action {
                display: inline-block;
                border: 1px solid var(--bov-primary-400);
                border-radius: 0.1875rem;
            }

            .no-results[b-ovicl4vnpb] {
                margin-top: 3rem;
            }

            .results-panel[b-ovicl4vnpb] {
                display: flex;
                justify-content: space-between;
            }

            .results-panel .results-summary[b-ovicl4vnpb] {
                align-self: center;
            }

            .filter-btn[b-ovicl4vnpb] {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                position: relative;
                padding: 0.5rem;
            }

            .filter-btn[b-ovicl4vnpb] .icon {
                width: 1.15rem;
                height: 1.15rem;
                margin: 0.375rem;
            }

            .filter-btn .filter-on[b-ovicl4vnpb] {
                position: absolute;
                top: -0.375rem;
                right: 0.25rem;
                width: 0.75rem;
                height: 0.75rem;
                background: var(--bov-primary-500);
                border-radius: 2.5rem;
            }

            .action-btn[b-ovicl4vnpb] {
                display: flex;
                box-sizing: content-box;
                padding: 1px;
            }

            .absent-btn[b-ovicl4vnpb] {
                background-color: var(--bov-primary-500);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Appointments/AppointmentSearchResultsV0.razor.rz.scp.css */
            table[b-zkg6rpo84i] {
                width: 100%;
                margin-top: 1.5rem;
            }

            table thead[b-zkg6rpo84i] {
                border: 1px solid var(--bov-mid-grey);
                background: var(--bov-primary-400);
                color: var(--bov-pure-white);
            }

            table thead tr th[b-zkg6rpo84i],
            table tbody tr td[b-zkg6rpo84i] {
                padding: 1rem;
            }

            table tbody tr[b-zkg6rpo84i] {
                border: 1px solid #8b9298;
            }

            [b-zkg6rpo84i] .icon {
                width: 1.5rem;
                height: 1.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Availability/AvailabilityBranchServiceSelector.razor.rz.scp.css */
            [b-mwa5jlxset] .card.card-service {
                padding: 0.5rem;
                border: 1px solid var(--bov-mid-grey);
                border-radius: 0.25rem;
                height: inherit;
            }

            [b-mwa5jlxset] .card.card-service .title {
                font-size: 1.125rem;
            }

            [b-mwa5jlxset] .card.card-service .icon-container .icon {
                width: 1rem;
                height: 1rem;
            }

            [b-mwa5jlxset] .card.card-service.selected {
                background-color: var(--bov-primary-lightest);
                border: 2px solid var(--bov-primary-400);
            }

            [b-mwa5jlxset] .card .icon-container .icon-suffix {
                font-size: 1rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Availability/AvailabilityComponent.razor.rz.scp.css */
            .branches-filter[b-yaaw1l14lo] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                background: var(--bov-pure-white);
                padding: 1rem;
                margin: 1rem 0 1.125rem;
            }

            .branches-filter .action-buttons[b-yaaw1l14lo] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
            }

            .ms-bookings-note[b-yaaw1l14lo] {
                background: var(--warning);
                padding: 1rem;
                margin-bottom: 1.125rem;
                font-weight: 500;
                font-size: 1.125rem;
                line-height: 1.35rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Availability/AvailabilityServiceCustomHoursDay.razor.rz.scp.css */
            .day-custom-hours-container[b-dzndtjz6zc] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                gap: 1.5rem;
                background: var(--bov-pure-white);
                margin-bottom: 1rem;
                padding: 1rem;
            }

            .day-custom-hours-container:last-child[b-dzndtjz6zc] {
                margin-bottom: 0;
            }

            .day-custom-hours-container .day-custom-hours-title[b-dzndtjz6zc] {
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
            }

            .day-custom-hours-container .day-custom-hours-title h2[b-dzndtjz6zc] {
                color: var(--bov-almost-black);
                width: 25%;
            }

            .day-custom-hours-container .day-custom-hours-title .custom-hours-add-button-container[b-dzndtjz6zc] {
                width: 25%;
                display: flex;
                flex-direction: row;
                justify-content: flex-end;
            }

            .day-custom-hours-container
                .day-custom-hours-title
                button:not(.custom-hours-add-button-container button)[b-dzndtjz6zc] {
                text-decoration: none;
                font-weight: 500;
                font-size: 1rem;
            }

            .day-custom-hours-container .day-custom-hours-slots[b-dzndtjz6zc] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .custom-hours-add-button-container button[b-dzndtjz6zc] {
                display: flex;
                padding: 0.5rem;
                justify-content: center;
                align-items: center;
                gap: 0.5rem;
                border-color: var(--bov-primary-500);
            }

            .custom-hours-add-button-container button[b-dzndtjz6zc] .icon {
                width: 1.5rem;
                height: 1.5rem;
            }

            .no-custom-hours[b-dzndtjz6zc] {
                color: var(--bov-almost-black);
                font-style: italic;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Availability/AvailabilityServiceCustomHoursSlot.razor.rz.scp.css */
            .custom-hours-slot-selector-container[b-pyxsyx56o6] {
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                padding: 0.5rem;
                gap: 0.25rem;
                border-radius: 0.25rem;
                border: 1px solid var(--bov-lightest-grey);
                background: #f7f4f6;
            }

            .custom-hours-slot-selector-container .custom-hours-slot-selector-fields[b-pyxsyx56o6] {
                display: flex;
                flex-direction: row;
                column-gap: 1rem;
            }

            .custom-hours-slot-selector-container .custom-hours-slot-selector-fields .field[b-pyxsyx56o6] {
                display: flex;
                flex-direction: row;
                align-items: center;
                column-gap: 0.5rem;
            }

            .custom-hours-slot-selector-container button[b-pyxsyx56o6] .icon {
                width: 1.5rem;
                height: 1.5rem;
            }

            .custom-hours-slot-selector-container[b-pyxsyx56o6] select {
                border-radius: 0.25rem;
                border: 1px solid var(--bov-light-grey);
                background-color: var(--bov-pure-white);
                padding: 0.25rem 0.5rem;
                height: inherit;
                width: 5.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/BackofficeHeader.razor.rz.scp.css */
            .header-component[b-z9wy04xbdw] {
                display: flex;
                justify-content: space-between;
                margin-bottom: 1.5rem;
            }

            .header-component .header-actions[b-z9wy04xbdw] {
                display: flex;
                gap: 1rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/BackOfficeNavigationBar.razor.rz.scp.css */
            .navbar-routes[b-f62e60bwof] {
                display: flex;
                list-style: none;
                gap: 1rem;
                margin: 0;
                padding: 0;
            }

            .navbar-routes[b-f62e60bwof] .nav-button {
                padding: 0.5rem;
                border-radius: 4px;
                font-size: 1rem;
                font-weight: 700;
                color: var(--bov-almost-black);
                text-decoration: none;
            }

            .navbar-routes[b-f62e60bwof] .nav-button:hover {
                background-color: var(--bov-primary-lightest);
            }

            .navbar-routes[b-f62e60bwof] .nav-button:active {
                background-color: var(--bov-primary-light);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/BookAppointment/BookAppointmentComponent.razor.rz.scp.css */
            .processing-message[b-hj8b6tyf60] {
                margin-top: 2rem;
            }

            .header-section[b-hj8b6tyf60] {
                display: flex;
                padding-bottom: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/EditAppointment/CancelAppointmentModal.razor.rz.scp.css */
            .modal-container[b-i4bzih5y2d] {
                display: flex;
                flex-direction: column;
                padding: 1.5rem;
                gap: 1.5rem;
            }

            .container-title[b-i4bzih5y2d] {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }

            .container-title > h3[b-i4bzih5y2d] {
                font-weight: 700;
            }

            .container-title .subtitle[b-i4bzih5y2d] {
                color: var(--error);
                margin-bottom: 0;
                font-weight: 700;
                line-height: normal;
            }

            .container-footer[b-i4bzih5y2d] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
            }

            .screen[b-i4bzih5y2d] {
                display: flex;
                flex-flow: column;
                gap: 1rem;
                font-weight: 500;
                font-size: 1.125rem;
                line-height: 1.35rem;
            }

            .screen > p[b-i4bzih5y2d] {
                margin: 0;
            }

            .screen.error[b-i4bzih5y2d] {
                align-items: center;
            }

            .screen.error .error-title[b-i4bzih5y2d] {
                font-weight: 700;
                font-size: 1.3125rem;
                line-height: 1.575rem;
            }

            .screen.error .error-description[b-i4bzih5y2d] {
                font-size: 1.125rem;
                line-height: 1.35rem;
            }

            .screen.error[b-i4bzih5y2d] .icon {
                width: 2rem;
                height: 2rem;
            }

            .options-container[b-i4bzih5y2d] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .options-container label[b-i4bzih5y2d] {
                display: flex;
                gap: 0.5rem;
                align-items: center;
            }

            [b-i4bzih5y2d] input[type="radio"] {
                width: 1.5rem;
                height: 1.5rem;
            }

            [b-i4bzih5y2d] input[type="radio"]:checked {
                accent-color: var(--bov-primary-400);
            }

            .fields[b-i4bzih5y2d] {
                display: flex;
                padding-left: 0.25rem;
                flex-direction: column;
                gap: 0.25rem;
            }

            .fields .text-counter[b-i4bzih5y2d] {
                color: #57534d;
                font-size: 0.75rem;
                line-height: 0.75rem;
                text-align: right;
            }

            .fields .other-reason[b-i4bzih5y2d] {
                height: 3rem;
                padding: 0.25rem 0.5rem;
            }

            .fields .other-reason:focus[b-i4bzih5y2d] {
                border: 2px solid var(--bov-primary-400);
                outline: none;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/EditAppointment/EditAppointmentComponent.razor.rz.scp.css */
            .processing-message[b-hvja0hxpqz] {
                margin-top: 2rem;
            }

            .header-section[b-hvja0hxpqz] {
                display: flex;
                padding-bottom: 2rem;
            }

            .button-layout[b-hvja0hxpqz] {
                display: flex;
                gap: 1rem;
            }

            button.cancel[b-hvja0hxpqz] {
                color: var(--error);
                border: none;
                background: none;
                padding: 1rem;
            }

            .timeslot-warning[b-hvja0hxpqz] {
                margin-inline: 9rem;
            }

            @media (max-width: 1400px) {
                .timeslot-warning[b-hvja0hxpqz] {
                    margin-inline: 8rem;
                }
            }

            @media (max-width: 1200px) {
                .timeslot-warning[b-hvja0hxpqz] {
                    margin-inline: 7.5rem;
                }
            }

            @media (max-width: 1024px) {
                .timeslot-warning[b-hvja0hxpqz] {
                    margin-inline: 0.5rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Roster/FailureModal.razor.rz.scp.css */
            .container[b-7k4wzkqizl] {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
                color: var(--bov-almost-black);
            }

            .container .title[b-7k4wzkqizl] {
                margin-bottom: 0.5rem;
            }

            .container .content[b-7k4wzkqizl] {
                margin-bottom: 1.5rem;
            }

            h3[b-7k4wzkqizl] {
                font-weight: 700;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Roster/FileUpload.razor.rz.scp.css */
            .fileupload-component[b-vg9iwnsie7] {
                display: inline-flex;
                flex-direction: row;
                align-items: center;
            }

            .fileupload-component .upload-button[b-vg9iwnsie7] {
                padding: 0.5rem 1rem;
            }

            .fileupload-component .remove-button[b-vg9iwnsie7] {
                display: flex;
                align-items: center;
                justify-content: center;
                border: none;
                margin-left: 0.25rem;
                padding: 0;
            }

            .fileupload-component .remove-button[b-vg9iwnsie7] > svg.icon {
                height: 1rem;
                width: 1rem;
            }

            .fileupload-component .filename[b-vg9iwnsie7] {
                color: var(--bov-dark-grey);
                margin-left: 1rem;
                font-size: 1.125rem;
            }

            .fileupload-component .filename.filled[b-vg9iwnsie7] {
                color: var(--bov-almost-black, #211d1d);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Roster/RosterComponent.razor.rz.scp.css */
            [b-9g10jrvr1w] .validation-message {
                padding-left: 0;
            }

            .title[b-9g10jrvr1w] {
                margin-bottom: 3rem;
                text-align: center;
            }

            .file-container[b-9g10jrvr1w] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                gap: 0.5rem;
            }

            .file-upload[b-9g10jrvr1w] {
                display: flex;
                align-items: center;
            }

            .warning-container[b-9g10jrvr1w] {
                margin-top: 40px;
                display: flex;
                flex-direction: column;
                justify-content: center;
                gap: 0.5rem;
            }

            .checkmark[b-9g10jrvr1w] {
                display: flex;
                margin-left: 0.5rem;
            }

            .checkmark[b-9g10jrvr1w] > svg.icon {
                height: 1rem;
                width: 1rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Roster/SuccessWithWarningModal.razor.rz.scp.css */
            .container[b-g9fk038qqq] {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }

            .container .title[b-g9fk038qqq] {
                color: var(--bov-almost-black);
                text-align: center;
                margin-bottom: 2rem;
            }

            .container .content[b-g9fk038qqq] {
                color: var(--bov-almost-black);
                text-align: center;
                margin-bottom: 1.75rem;
            }

            .container .warning-container[b-g9fk038qqq] {
                margin-bottom: 1rem;
                display: flex;
                flex-direction: column;
                justify-content: center;
                gap: 0.5rem;
            }

            .container .footer[b-g9fk038qqq] {
                display: flex;
                justify-content: flex-end;
            }

            .icon-container[b-g9fk038qqq] {
                margin-bottom: 0.5rem;
                text-align: center;
            }

            [b-g9fk038qqq] .icon {
                width: 3rem;
                height: 3rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/Roster/Warning.razor.rz.scp.css */
            button[b-q62sb1lri1],
            div[b-q62sb1lri1] {
                font-size: 1.125rem;
                letter-spacing: 0.00525rem;
                color: var(--bov-almost-black);
                text-align: left;
            }

            .warning[b-q62sb1lri1] {
                border-left: 0.5rem solid;
                padding: 0.4rem 0;
                padding-left: 0.4rem;
                padding-right: 0.4rem;
            }

            .warning.hard[b-q62sb1lri1] {
                background-color: #f8d8d3;
                border-color: var(--error);
            }

            .warning.soft[b-q62sb1lri1] {
                background-color: #fcfbe0;
                border-color: var(--warning);
            }

            .warning .warning-button[b-q62sb1lri1] {
                font-weight: bolder;
                padding: 0;
                background: none;
                box-shadow: none;
                border: none;
                position: relative;
                display: flex;
                width: 100%;
                align-items: center;
            }

            .warning.single .warning-button[b-q62sb1lri1] {
                cursor: default;
                user-select: text;
            }

            .warning:not(.single) .warning-button[b-q62sb1lri1]::after {
                flex-shrink: 0;
                width: 1.25rem;
                height: 1.25rem;
                margin-left: auto;
                content: "";
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23212529'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-size: 1.25rem;
                transition: transform 0.2s ease-in-out;
                -webkit-transition: transform 0.2s ease-in-out;
            }

            .warning .warning-button:not(.collapsed)[b-q62sb1lri1]::after {
                transform: rotate(180deg);
            }

            .warning .warning-contents[b-q62sb1lri1] {
                overflow: hidden;
                height: auto;
                max-height: 420px;
                transition:
                    max-height 0.3s ease-out,
                    padding 0.15s ease-out;
                -webkit-transition:
                    max-height 0.3s ease-out,
                    padding 0.15s ease-out;
            }

            .warning .warning-contents.display[b-q62sb1lri1] {
                overflow: auto;
                padding-top: 0.5rem;
            }

            .warning .warning-contents:not(.display)[b-q62sb1lri1] {
                max-height: 0px;
            }

            .warning .warning-contents .warning-item[b-q62sb1lri1] {
                font-weight: normal;
            }

            [b-q62sb1lri1]::-webkit-scrollbar {
                width: 10px;
            }

            [b-q62sb1lri1]::-webkit-scrollbar-track {
                background: none;
            }

            [b-q62sb1lri1]::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 25px;
            }

            [b-q62sb1lri1]::-webkit-scrollbar-thumb:hover {
                background: #555;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/CreateTimeOff/CreateTimeOffComponent.razor.rz.scp.css */
            /*  block component */
            [b-tg1ppsu2g5] .block .header {
                text-align: left;
            }

            [b-tg1ppsu2g5] div.block {
                margin-bottom: 0;
            }

            [b-tg1ppsu2g5] .block:nth-of-type(2) .header {
                margin-bottom: 0.75rem;
            }

            /* component */
            .content-component[b-tg1ppsu2g5] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                min-width: fit-content;
            }

            .details-section[b-tg1ppsu2g5] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }

            .reason-field[b-tg1ppsu2g5] {
                width: 36.375rem;
            }

            .reason-field[b-tg1ppsu2g5] .form-floating > .form-select {
                height: 4rem;
            }

            .date-range-fieldset[b-tg1ppsu2g5] {
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
            }

            .date-field[b-tg1ppsu2g5] {
                padding: 0.5rem;
                border: 1px solid var(--bov-lightest-grey);
                border-radius: 0.25rem;
                background-color: #f7f4f6;
                width: fit-content;
            }

            .date-field > label[b-tg1ppsu2g5] {
                display: inline-flex;
                align-items: center;
                gap: 2rem;
            }

            .date-field .label-text[b-tg1ppsu2g5] {
                display: inline-block;
                width: 3rem;
                letter-spacing: 0.02rem;
            }

            .allday-field[b-tg1ppsu2g5] {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .allday-field[b-tg1ppsu2g5] input[type="checkbox"] {
                width: 1.375rem;
                height: 1.375rem;
                border: 2px solid var(--bov-dark-grey);
                margin-top: 0;
            }

            .allday-field .label-text[b-tg1ppsu2g5] {
                font-size: 1.125rem;
                line-height: normal;
            }

            .staff-section[b-tg1ppsu2g5] {
                display: flex;
                gap: 0.75rem;
            }

            .branch-field[b-tg1ppsu2g5] {
                width: 16rem;
            }

            .staff-search-field[b-tg1ppsu2g5] {
                display: flex;
                align-items: center;
                position: relative;
            }

            .staff-search-field .search-icon[b-tg1ppsu2g5] {
                position: absolute;
                right: 0.5rem;
            }

            .staff-search-field .search-icon[b-tg1ppsu2g5] .icon {
                width: 1.5rem;
                height: 1.5rem;
                flex-shrink: 0;
            }

            [b-tg1ppsu2g5] .search-field {
                padding: 0.5rem;
                padding-right: 2.5rem;
                border: 1px solid var(--bov-mid-grey);
                border-radius: 0.25rem;
                height: calc(3rem + 0.625rem);
                width: 24.8125rem;
            }

            [b-tg1ppsu2g5] .search-field:focus {
                border: 2px solid var(--bov-primary-400);
                outline: none;
            }

            [b-tg1ppsu2g5] .search-field::placeholder {
                color: var(--bov-mid-grey);
                font-size: 1.125rem;
                line-height: 1.625rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/EditTimeOff/EditTimeOffComponent.razor.rz.scp.css */
            /*  block component */
            [b-9ljd8nanzi] .block .header {
                text-align: left;
            }

            [b-9ljd8nanzi] div.block {
                margin-bottom: 0;
            }

            [b-9ljd8nanzi] .block:nth-of-type(2) .header {
                margin-bottom: 0.75rem;
            }

            /* component */
            .content-component[b-9ljd8nanzi] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                min-width: fit-content;
            }

            .details-section[b-9ljd8nanzi] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }

            .reason-field[b-9ljd8nanzi] {
                width: 36.375rem;
            }

            .reason-field[b-9ljd8nanzi] .form-floating > .form-select {
                height: 4rem;
            }

            .date-range-fieldset[b-9ljd8nanzi] {
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
            }

            .date-field[b-9ljd8nanzi] {
                padding: 0.5rem;
                border: 1px solid var(--bov-lightest-grey);
                border-radius: 0.25rem;
                background-color: #f7f4f6;
                width: fit-content;
            }

            .date-field > label[b-9ljd8nanzi] {
                display: inline-flex;
                align-items: center;
                gap: 2rem;
            }

            .date-field .label-text[b-9ljd8nanzi] {
                display: inline-block;
                width: 3rem;
                letter-spacing: 0.02rem;
            }

            .allday-field[b-9ljd8nanzi] {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .allday-field[b-9ljd8nanzi] input[type="checkbox"] {
                width: 1.375rem;
                height: 1.375rem;
                border: 2px solid var(--bov-dark-grey);
                margin-top: 0;
            }

            .allday-field .label-text[b-9ljd8nanzi] {
                font-size: 1.125rem;
                line-height: normal;
            }

            .staff-section[b-9ljd8nanzi] {
                display: flex;
                gap: 0.75rem;
            }

            .branch-field[b-9ljd8nanzi] {
                width: 16rem;
            }

            .staff-search-field[b-9ljd8nanzi] {
                display: flex;
                align-items: center;
                position: relative;
            }

            .staff-search-field .search-icon[b-9ljd8nanzi] {
                position: absolute;
                right: 0.5rem;
            }

            .staff-search-field .search-icon[b-9ljd8nanzi] .icon {
                width: 1.5rem;
                height: 1.5rem;
                flex-shrink: 0;
            }

            [b-9ljd8nanzi] .search-field {
                padding: 0.5rem;
                padding-right: 2.5rem;
                border: 1px solid var(--bov-mid-grey);
                border-radius: 0.25rem;
                height: calc(3rem + 0.625rem);
                width: 24.8125rem;
            }

            [b-9ljd8nanzi] .search-field:focus {
                border: 2px solid var(--bov-primary-400);
                outline: none;
            }

            [b-9ljd8nanzi] .search-field::placeholder {
                color: var(--bov-mid-grey);
                font-size: 1.125rem;
                line-height: 1.625rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/Shared/TimeOffConfirmation.razor.rz.scp.css */
            .component-content[b-5yydnl40ee] {
                padding-inline: 0.5rem;
            }

            .component-content-item[b-5yydnl40ee] {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
                align-self: stretch;
                border-bottom: 1px solid var(--bov-lightest-grey);
                padding-bottom: 1.5rem;
                padding-top: 1.5rem;
            }

            .component-content-item:first-child[b-5yydnl40ee] {
                padding-top: 0;
            }

            .component-content-item:last-child[b-5yydnl40ee] {
                padding-bottom: 0;
                border-bottom: none;
            }

            .component-content-item > p[b-5yydnl40ee] {
                margin: 0;
            }

            .component-content-item .title[b-5yydnl40ee] {
                color: var(--bov-almost-black);
                font-size: 1.125rem;
                font-weight: 700;
                line-height: normal;
            }

            .component-content-item .staff-list[b-5yydnl40ee] {
                list-style: none;
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
                font-size: 1.125rem;
                line-height: 1.5rem;
            }

            .component-content-item .staff-email[b-5yydnl40ee] {
                color: var(--bov-dark-grey);
            }

            .component-content-item .field[b-5yydnl40ee] {
                display: flex;
                gap: 1.38rem;
                font-size: 1.125rem;
                font-style: normal;
                font-weight: 700;
                line-height: 1.625rem;
                letter-spacing: 0.0225rem;
            }

            .component-content-item .field-label[b-5yydnl40ee] {
                width: 3.3125rem;
                color: #565656;
                font-size: 1rem;
                font-weight: 500;
                letter-spacing: 0.02rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/Shared/TimeOffDetailsModalComponent.razor.rz.scp.css */
            .component-content[b-697msivx0b] {
                padding-inline: 0.5rem;
            }

            .component-content-item[b-697msivx0b] {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
                align-self: stretch;
                border-bottom: 1px solid var(--bov-lightest-grey);
                padding-bottom: 1.5rem;
                padding-top: 1.5rem;
            }

            .component-content-item:first-child[b-697msivx0b] {
                padding-top: 0;
            }

            .component-content-item:last-child[b-697msivx0b] {
                padding-bottom: 0;
                border-bottom: none;
            }

            .component-content-item > p[b-697msivx0b] {
                margin: 0;
            }

            .component-content-item .title[b-697msivx0b] {
                color: var(--bov-almost-black);
                font-size: 1.125rem;
                font-weight: 700;
                line-height: normal;
            }

            .component-content-item .staff-list[b-697msivx0b] {
                list-style: none;
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
                font-size: 1.125rem;
                line-height: 1.5rem;
            }

            .component-content-item .staff-email[b-697msivx0b] {
                color: var(--bov-dark-grey);
            }

            .component-content-item .field[b-697msivx0b] {
                display: flex;
                gap: 1.38rem;
                font-size: 1.125rem;
                font-style: normal;
                font-weight: 700;
                line-height: 1.625rem;
                letter-spacing: 0.0225rem;
            }

            .component-content-item .field-label[b-697msivx0b] {
                width: 3.3125rem;
                color: #565656;
                font-size: 1rem;
                font-weight: 500;
                letter-spacing: 0.02rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/ViewTimeOffs/TimeOffSearchFilters.razor.rz.scp.css */
            .time-off-search-filters[b-hojsct4euh] {
                display: flex;
                flex-direction: column;
                justify-content: center;
                background: var(--bov-pure-white);
                padding: 1rem;
                margin: 1rem 0 1.5rem;
            }

            .time-off-search-filters .filters[b-hojsct4euh] {
                display: flex;
                flex-direction: row;
                column-gap: 1rem;
            }

            .time-off-search-filters .filters .action[b-hojsct4euh] {
                margin-left: auto;
            }

            .time-off-search-filters .filters .branch-filter[b-hojsct4euh] {
                flex-grow: 0.25;
            }

            .time-off-search-filters .filters .date-range-filter[b-hojsct4euh] {
                flex-grow: 0;
            }

            .time-off-search-filters .filters[b-hojsct4euh] .validation-message {
                padding-left: 0;
            }

            .time-off-search-filters .filters .date-range-filter[b-hojsct4euh] .validation-message {
                width: 0;
                white-space: nowrap;
            }

            .time-off-search-filters .filters[b-hojsct4euh] option {
                background: #eae2e2;
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/ViewTimeOffs/TimeOffSearchResults.razor.rz.scp.css */
            .results-panel[b-t4ue9p4nk0] {
                display: flex;
                justify-content: space-between;
            }

            .results[b-t4ue9p4nk0] {
                display: flex;
                flex-direction: column;
                gap: 0.8rem;
                margin-block: 0.5rem;
            }

            .no-results[b-t4ue9p4nk0] {
                margin-top: 3rem;
            }

            [b-t4ue9p4nk0] table td {
                vertical-align: top;
            }

            [b-t4ue9p4nk0] .icon {
                width: 1rem;
                height: 1rem;
            }

            [b-t4ue9p4nk0] .edit-time-off {
                display: inline-block;
                border: 1px solid var(--bov-primary-400);
                border-radius: 0.1875rem;
            }

            .delete-time-off[b-t4ue9p4nk0] .icon {
                color: var(--bov-dark-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/BackOffice/TimeOffs/ViewTimeOffs/ViewTimeOffsComponent.razor.rz.scp.css */
            .timeoff-header[b-72rhhm7t1a] {
                display: flex;
                justify-content: space-between;
                align-self: stretch;
            }
            /* _content/AppointmentBookingSystem.Web/Components/ErrorHandling/Toast.razor.rz.scp.css */
            .close-text[b-hxq9u80quq] {
                text-decoration: underline;
                color: var(--bov-primary-500);
                cursor: pointer;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Layout/Footer.razor.rz.scp.css */
            .footer-container[b-5xf0hqs7cb] {
                margin-left: var(--bov-desktop-margin);
                margin-right: var(--bov-desktop-margin);
            }

            @media (max-width: 1024px) {
                .footer-container[b-5xf0hqs7cb] {
                    margin-left: var(--bov-mobile-margin);
                    margin-right: var(--bov-mobile-margin);
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Layout/Modal/CommonModalStructure.razor.rz.scp.css */
            h2[b-yl7syc5b7l] {
                color: var(--bov-almost-black);
            }

            .dialog-container[b-yl7syc5b7l] {
                position: relative;
            }

            .dialog-title[b-yl7syc5b7l] {
                height: 3.5rem;
                padding: 0 1.5rem;
                border: 1px none var(--bov-light-grey);
                border-bottom-style: solid;
            }

            .dialog-content[b-yl7syc5b7l] {
                padding: 2rem 1.5rem;
            }

            .dialog-footer[b-yl7syc5b7l] {
                padding: 0 1.5rem;
            }

            button.primary[b-yl7syc5b7l] {
                margin-left: 1rem;
            }

            .close[b-yl7syc5b7l] {
                border-color: var(--bov-lightest-grey);
                border-radius: 50%;
                background: var(--bov-light-grey);
                top: -3rem;
                right: -1.5rem;
                width: 3rem;
                height: 3rem;
                position: absolute;
                display: inline-flex;
                justify-content: center;
                align-items: center;
                padding: 0.5rem;
            }

            [b-yl7syc5b7l] svg.icon {
                height: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Layout/Modal/ErrorModal.razor.rz.scp.css */
            [b-hamp4dkz8x] .dialog-content {
                font-size: 1.3125rem;
                letter-spacing: 0.00525rem;
                padding-top: 0 !important;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Layout/Modal/SuccessModal.razor.rz.scp.css */
            .container[b-tt9o635x9s] {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }

            .container .title[b-tt9o635x9s] {
                color: var(--bov-almost-black);
                text-align: center;
                margin-bottom: 0.5rem;
            }

            .container .content[b-tt9o635x9s] {
                color: var(--bov-almost-black);
                text-align: center;
                margin-bottom: 2.5rem;
            }

            .container .footer[b-tt9o635x9s] {
                display: flex;
                justify-content: flex-end;
            }

            .icon-container[b-tt9o635x9s] {
                margin-bottom: 0.5rem;
                text-align: center;
            }

            [b-tt9o635x9s] .icon {
                width: 3rem;
                height: 3rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Layout/NavBar.razor.rz.scp.css */
            nav[b-0h6h1p6wgv] {
                background: var(--bov-pure-white);
                position: fixed !important;
                top: 0;
                width: 100%;
                z-index: 99;
            }

            nav img[b-0h6h1p6wgv] {
                height: 48px;
            }

            .nav-container[b-0h6h1p6wgv] {
                display: flex;
                align-items: center;
                width: 100%;
                justify-content: space-between;
                margin-left: var(--bov-desktop-margin);
                margin-right: var(--bov-desktop-margin);
            }

            @media (max-width: 1024px) {
                .nav-container[b-0h6h1p6wgv] {
                    margin-left: var(--bov-mobile-margin);
                    margin-right: var(--bov-mobile-margin);
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Accordion.razor.rz.scp.css */
            details summary[b-9qr0d7mapm] {
                display: flex;
                align-items: center;
                gap: 2rem;
                list-style: none;
                font-size: 1.125rem;
                line-height: 1.35rem;
            }

            details summary span:last-child[b-9qr0d7mapm],
            details[open] summary span:first-child[b-9qr0d7mapm] {
                display: none;
            }

            details summary span:first-child[b-9qr0d7mapm],
            details[open] summary span:last-child[b-9qr0d7mapm] {
                display: inline;
            }

            details summary[b-9qr0d7mapm]::after {
                content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
                display: inline-block;
                width: 1.5rem;
                height: 1.5rem;
                margin-left: 0.3125rem;
            }

            details[open] summary[b-9qr0d7mapm]::after {
                transform: rotate(180deg);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/AppointmentDetails.razor.rz.scp.css */
            .content-container[b-2djf044ql1] {
                width: calc(100% * 5 / 6);
            }

            .summary-container[b-2djf044ql1] {
                display: flex;
                gap: 1rem;
                margin: 2rem 0;
            }

            .summary-container > div[b-2djf044ql1] {
                display: flex;
                flex-direction: column;
            }

            .summary-container .documents[b-2djf044ql1] {
                background: var(--bov-primary-lightest);
                border: 1px solid var(--bov-lightest-grey);
                border-radius: 0.5rem;
                padding-right: var(--scrollbar-padding-right);
                width: 50%;
            }

            .summary-container .documents > div[b-2djf044ql1] {
                flex-basis: 0;
                flex-grow: 1;
                overflow-y: auto;
                padding: 1.5rem;
            }

            .summary-container .documents .header[b-2djf044ql1] {
                color: var(--bov-primary-500);
                margin-bottom: 0.5rem;
            }

            .summary-container[b-2djf044ql1] dl {
                display: inline-block;
                width: 100%;
            }

            .summary-container[b-2djf044ql1] dl dt {
                letter-spacing: 0.004rem;
                font-weight: 500;
                line-height: 20px;
                color: var(--bov-primary-500);
                margin-bottom: 0.5rem;
            }

            .summary-container[b-2djf044ql1] dl dt:not(:first-child) {
                margin-top: 1.5rem;
            }

            .summary-container[b-2djf044ql1] dl dd {
                margin-bottom: 0;
                word-wrap: break-word;
            }

            .summary-container .appointment-details[b-2djf044ql1] {
                width: 50%;
                display: flex;
                gap: 1.25rem;
            }

            .summary-container .appointment-details:only-child[b-2djf044ql1] {
                width: 100%;
            }

            .summary-container .validation-message[b-2djf044ql1] {
                padding-left: 0;
            }

            @media (max-width: 1000px) {
                .summary-container[b-2djf044ql1] {
                    flex-direction: column;
                }

                .summary-container .appointment-details[b-2djf044ql1] {
                    order: 1;
                    width: 100%;
                }

                .summary-container .documents[b-2djf044ql1] {
                    order: 2;
                    width: 100%;
                }

                .summary-container[b-2djf044ql1] :last-child {
                    margin-bottom: 0;
                }

                .summary-container .documents > div[b-2djf044ql1] {
                    flex-basis: auto;
                }
            }

            @media (max-width: 1024px) {
                .summary-container[b-2djf044ql1] {
                    margin: 0rem 0rem 2rem 0rem;
                }

                .summary-container .appointment-details[b-2djf044ql1] {
                    gap: 1rem;
                }

                .content-container[b-2djf044ql1] {
                    width: 100%;
                    padding-left: 0rem;
                    padding-right: 0rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/AppointmentDetailsCard.razor.rz.scp.css */
            .section[b-jsizu8kgdu] {
                padding: 1.5rem 1.25rem 0.5rem 1.25rem;
                border: 1.5px solid var(--bov-light-grey);
                border-radius: 0.5rem;
                position: relative;
            }

            .section .edit-btn-container[b-jsizu8kgdu] {
                position: absolute;
                top: 1.5rem;
                right: 1.25rem;
            }

            .section[b-jsizu8kgdu] .edit {
                vertical-align: top;
            }

            .section.error-section[b-jsizu8kgdu] {
                border: 1.5px solid var(--error);
            }

            @media (max-width: 1024px) {
                .section[b-jsizu8kgdu] {
                    padding: 0.5rem 0.5rem 0.5rem 0.5rem;
                }

                .section .edit-btn-container[b-jsizu8kgdu] {
                    top: 0.5rem;
                    right: 0.5rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/BackgroundContainer.razor.rz.scp.css */
            .background-block[b-qjqrgyo7wc] {
                padding: 2rem;
                background: var(--bov-pure-white);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Block.razor.rz.scp.css */
            .block[b-oxqf8ijfs9] {
                background-color: var(--bov-pure-white);
                padding: 1rem;
                margin-bottom: 1.5rem;
            }

            .header[b-oxqf8ijfs9] {
                font-weight: 500;
                font-size: 1.5rem;
                color: var(--bov-primary-600);
                margin-bottom: 1.5rem;
                text-align: center;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/BranchSuggestionCard.razor.rz.scp.css */
            [b-2zmdhx0en8] > svg.icon {
                height: 1rem;
                width: 1rem;
            }

            .suggestioncard[b-2zmdhx0en8] {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem;
                background: var(--bov-pure-white);
                box-shadow:
                    0px 9px 4px rgba(90, 19, 64, 0.01),
                    0px 5px 3px rgba(90, 19, 64, 0.02),
                    0px 2px 2px rgba(90, 19, 64, 0.03),
                    0px 1px 1px rgba(90, 19, 64, 0.04),
                    0px 0px 0px rgba(90, 19, 64, 0.04);
                border: 0.0625rem solid #f5f0f2;
                border-radius: 0.5rem;
                cursor: pointer;
            }

            .suggestioncard .suggestioncard-street[b-2zmdhx0en8] {
                color: var(--bov-dark-grey);
                font-size: 0.875rem;
                padding-left: 1.25rem;
            }

            .suggestioncard .suggestioncard-location[b-2zmdhx0en8] {
                display: flex;
                flex-direction: column;
                gap: 0.25rem;
            }

            .suggestioncard .suggestioncard-line[b-2zmdhx0en8] {
                display: flex;
                flex-direction: row;
                align-items: center;
                gap: 0.25rem;
            }

            .suggestioncard.selected[b-2zmdhx0en8] {
                border-color: var(--bov-primary-500);
                border-width: 0.125rem;
                padding: calc(1rem - 0.0625rem);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/BranchSuggestionModal.razor.rz.scp.css */
            .branch-container[b-wshvg2juyo] {
                display: flex;
                flex-direction: column;
                padding: 0 1.5rem;
                gap: 1.5rem;
            }

            .branch-container .branch-container-title[b-wshvg2juyo] {
                font-size: 1.3125rem;
                line-height: 2rem;
                letter-spacing: 0.00525rem;
            }

            .branch-container .branch-container-subtitle[b-wshvg2juyo] {
                font-size: 1.3125rem;
                text-align: center;
                font-weight: 700;
                letter-spacing: 0.00525rem;
            }

            .branch-container .branch-container-card-list[b-wshvg2juyo] {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .branch-container .branch-container-footer[b-wshvg2juyo] {
                display: flex;
                gap: 2rem;
                justify-content: flex-end;
            }

            @media (max-width: 1024px) {
                .branch-container .branch-container-title[b-wshvg2juyo],
                .branch-container .branch-container-subtitle[b-wshvg2juyo] {
                    font-size: 1rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/CancelConfirmation.razor.rz.scp.css */
            .form-container[b-ej8kdox0lh] {
                padding: 5rem 3rem;
            }

            h1[b-ej8kdox0lh] {
                color: var(--bov-almost-black);
            }

            h3[b-ej8kdox0lh] {
                padding: 2.5rem 0 1.5rem;
                font-weight: 700;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/ComponentGroupInput.razor.rz.scp.css */
            .component-group-input[b-7xa90d3zdk] {
                display: flex;
            }

            .component-group-input[b-7xa90d3zdk] :not(:last-child) input,
            .component-group-input[b-7xa90d3zdk] :not(:last-child) select {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
            }

            .component-group-input[b-7xa90d3zdk] :not(:first-child) input,
            .component-group-input[b-7xa90d3zdk] :not(:first-child) select {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
            }

            .component-group-input[b-7xa90d3zdk] > div {
                margin-left: -1px;
            }

            .component-group-input[b-7xa90d3zdk] :has(input:focus, select:focus) {
                position: relative;
                z-index: 1;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Confirmation.razor.rz.scp.css */
            .circle-container[b-5rf2uy2qjg] {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .circle-container .circle[b-5rf2uy2qjg] {
                position: absolute;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 9.125rem;
                width: 9.125rem;
                background-color: var(--bov-pure-white);
                border-radius: 50%;
            }

            .circle-container .circle[b-5rf2uy2qjg] .icon {
                width: 6.0625rem;
                height: 6.0625rem;
            }

            .confirmation-title[b-5rf2uy2qjg] {
                background: var(--bov-gradient-2);
                border-radius: 0.5rem 0.5rem 0 0;
                font-weight: 500;
                color: var(--bov-pure-white);
                letter-spacing: 0.004rem;
            }

            .confirmation-title .confirmation-title-request[b-5rf2uy2qjg] {
                font-size: 2rem;
                padding-top: 6.8125rem;
            }

            .confirmation-title .confirmation-title-details[b-5rf2uy2qjg] {
                font-weight: 400;
                font-size: 1.3125rem;
                padding-top: 1.3125rem;
                padding-bottom: 2rem;
            }

            .confirmation-title .junk-disclaimer[b-5rf2uy2qjg] {
                border-top: 1px solid #fff;
                padding: 2rem 1.5rem;
            }

            .confirmation-description[b-5rf2uy2qjg] {
                background: var(--bov-pure-white);
                border-radius: 0 0 0.5rem 0.5rem;
                font-weight: 500;
                font-size: 1.5rem;
                letter-spacing: 0.004rem;
                color: var(--bov-almost-black);
            }

            .confirmation-description .content[b-5rf2uy2qjg] {
                padding: 3.625rem 4.375rem;
            }

            .confirmation-description .content.personal[b-5rf2uy2qjg] {
                font-size: 1rem;
                text-align: left;
            }

            .confirmation-description .content.personal .secondary-header[b-5rf2uy2qjg] {
                font-weight: 700;
                padding-bottom: 1.8125rem;
            }

            .confirmation-description .content.personal .documents[b-5rf2uy2qjg] {
                padding-bottom: 1.3125rem;
            }

            .confirmation-description .content.personal .documents[b-5rf2uy2qjg] ul {
                margin-bottom: 0;
            }

            .confirmation-description .content.personal .documents[b-5rf2uy2qjg] b {
                display: inline-block;
                padding-bottom: 1.8125rem;
                padding-top: 1.8125rem;
            }

            .confirmation-description .content.personal .disclaimer[b-5rf2uy2qjg] {
                line-height: 1.2rem;
                border-radius: 0.125rem;
                background: var(--warning);
                padding: 0.25rem;
                margin-bottom: 2rem;
            }

            .confirmation-description .content.personal .disclaimer p[b-5rf2uy2qjg] {
                margin-bottom: 0;
            }

            .confirmation-description .bov-homepage[b-5rf2uy2qjg] {
                padding-bottom: 2.5625rem;
            }

            @media (max-width: 1024px) {
                .circle-container .circle[b-5rf2uy2qjg] {
                    height: 3.0625rem;
                    width: 3.0625rem;
                }

                .circle-container .circle[b-5rf2uy2qjg] .icon {
                    width: 2.03469rem;
                    height: 2.03469rem;
                }

                .confirmation-title .confirmation-title-request[b-5rf2uy2qjg] {
                    font-size: 1.5rem;
                    padding-top: 2.4375rem;
                }

                .confirmation-title .confirmation-title-details[b-5rf2uy2qjg] {
                    font-size: 1rem;
                    font-weight: 700;
                    padding-top: 0.5825rem;
                    padding-bottom: 1.4375rem;
                }

                .confirmation-title .junk-disclaimer[b-5rf2uy2qjg] {
                    padding: 0.75rem 0.625rem;
                    font-size: 0.875rem;
                }

                .confirmation-description .content[b-5rf2uy2qjg] {
                    padding: 1.5rem 0.5rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/ContactDetailsForm.razor.rz.scp.css */
            .content-container[b-f133d7cy8j] {
                width: 50%;
            }

            @media (max-width: 1024px) {
                .content-container[b-f133d7cy8j] {
                    padding-left: 0rem;
                    padding-right: 0rem;
                    width: 100%;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Container/CheckboxGroupContainer.razor.rz.scp.css */
            .checkbox-group[b-cpp9m28c7q] {
                display: grid;
                grid-template-columns: repeat(var(--columns), 1fr);
                justify-content: space-between;
                gap: 1rem;
                margin-top: 1rem;
            }

            .checkbox-group[b-cpp9m28c7q] input[type="checkbox"] {
                margin: 0.3125rem;
                border-width: 0.125rem;
                height: 2rem;
                width: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Container/LayeredContainer.razor.rz.scp.css */
            .layered-container[b-mx1hnt8o26] {
                display: grid;
                grid-template-areas: "stack";
            }

            .layered-container[b-mx1hnt8o26] > * {
                grid-area: stack;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/EditButton.razor.rz.scp.css */
            .edit[b-uzy4djrsw6] {
                letter-spacing: 0.004rem;
                font-size: 1rem;
                font-weight: 500;
                line-height: 20px;
                color: var(--bov-primary-500);
                margin-bottom: 0.5rem;
                padding: 0;
                border: 0;
                white-space: nowrap;
            }

            [b-uzy4djrsw6] .icon {
                width: 1rem;
                height: 1rem;
                padding-bottom: 0.25rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/ErrorMessageBlock.razor.rz.scp.css */
            .notification-container[b-s7is4muuih] {
                flex: 1;
                display: grid;
                place-items: center;
            }

            .notification-container .notification-box[b-s7is4muuih] {
                max-width: 40rem;
                padding: 3rem;
                background: var(--bov-pure-white);
                border-radius: 0.5rem;
                text-align: left;
            }

            .notification-container .notification-box .title[b-s7is4muuih] {
                color: var(--bov-primary-600);
                font-size: 1.5rem;
                font-style: normal;
                font-weight: 500;
                margin-bottom: 1rem;
            }

            .notification-container .notification-box .message[b-s7is4muuih] {
                color: var(--bov-almost-black);
                font-size: 1.125rem;
                font-style: normal;
                font-weight: 500;
            }

            .notification-container .notification-box .actions[b-s7is4muuih] {
                display: flex;
                gap: 1rem;
                margin-top: 2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/FormInputContainer.razor.rz.scp.css */
            .input-container[b-8m5iblj27h] {
                margin-bottom: 1.5rem;
                text-align: left;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/DatePicker.razor.rz.scp.css */
            .datepicker[b-xot1ko18jc] {
                display: inline-flex;
                gap: 0.5rem;
            }

            .datepicker[b-xot1ko18jc] .datepicker-item {
                padding: 0.25rem 0.5rem;
                border: 1px solid var(--bov-light-grey);
                border-radius: 0.25rem;
                font-size: 1.125rem;
                letter-spacing: 0.0225rem;
                line-height: 1.625rem;
            }

            .datepicker[b-xot1ko18jc] .datepicker-item:focus-within {
                border-color: var(--bov-primary-400);
                outline: none;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/Dropdown.razor.rz.scp.css */
            [b-01hrwqreai] select:focus > option:checked,
            [b-01hrwqreai] select:focus > option:hover {
                background-color: var(--bov-primary-lightest);
            }

            [b-01hrwqreai] .form-select:disabled {
                background-color: var(--bov-pure-white);
                opacity: 0.5;
                border-color: var(--bov-almost-black);
            }

            [b-01hrwqreai] .form-select:disabled ~ label {
                color: var(--bov-dark-grey);
            }

            [b-01hrwqreai] .form-select:disabled ~ .required::after {
                color: var(--bov-dark-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/RadioGroupChecked.razor.rz.scp.css */
            .radio-button-container[b-xn48e5jrto] {
                display: flex;
                gap: 0.5rem;
                border: 1px solid var(--bov-mid-grey);
                border-radius: 4px;
                padding: 0.25rem 0.5rem;
                align-items: center;
                width: 10rem;
                height: 3rem;
                flex: auto;
            }

            .radio-button-container[b-xn48e5jrto] input[type="radio"] {
                border: 1.5px solid var(--bov-mid-grey);
            }

            .radio-button-container[b-xn48e5jrto] input[type="radio"]:focus {
                outline: none;
                box-shadow: none;
            }

            .radio-button-container[b-xn48e5jrto] input[type="radio"]:checked {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10l3 3l6-6'/%3e%3c/svg%3e");
                background-color: var(--bov-primary-400);
                border-color: var(--bov-primary-400);
            }

            .radio-button-container[b-xn48e5jrto] .form-check-input:checked:disabled {
                background-color: var(--bov-mid-grey);
                border-color: var(--bov-mid-grey);
                opacity: 1;
            }

            .radio-button-container:has(> input[type="radio"]:checked)[b-xn48e5jrto] {
                background: var(--bov-primary-lightest);
                border: 1px solid var(--bov-primary-400);
            }

            .radio-button-container:has(> input[type="radio"]:disabled)[b-xn48e5jrto] {
                background: var(--bov-pure-white);
                border: 1px solid var(--bov-mid-grey);
            }

            .radio-button-container:has(> .form-check-input:disabled)[b-xn48e5jrto] span {
                color: var(--bov-mid-grey);
            }

            .radio-button-container[b-xn48e5jrto] .form-check-input {
                margin-top: 0;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/StaffCheckbox.razor.rz.scp.css */

            .checkbox-label[b-irt5rtya40] {
                display: flex;
                align-items: center;
            }

            .checkbox-label[b-irt5rtya40] input[type="checkbox"] {
                flex-shrink: 0;
            }

            .checkbox-label .checkbox-label-content[b-irt5rtya40] {
                display: flex;
                flex-direction: column;
                line-height: 1.2rem;
                margin-left: 0.5rem;
                color: #2b1e3b;
            }

            .checkbox-label .email[b-irt5rtya40] {
                color: var(--bov-dark-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/TextArea.razor.rz.scp.css */
            [b-7kw0i71ymh] textarea {
                min-height: 100px !important;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Form/TextFieldClear.razor.rz.scp.css */
            .input-clear[b-k09x6kvoow] {
                display: flex;
                position: relative;
                align-items: center;
            }

            .input-clear .icon-container[b-k09x6kvoow] {
                position: absolute;
                background: transparent;
                border: none;
                right: 0.5rem;
                padding: 0;
            }

            .input-clear[b-k09x6kvoow] .icon {
                width: 1rem;
                height: 1rem;
                display: block;
            }

            .input-clear[b-k09x6kvoow] .form-control {
                padding-right: 1.75rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/GenericRedirect.razor.rz.scp.css */
            .form-container[b-4v5q6l3p5e] {
                padding: 5rem 3rem;
            }

            h1[b-4v5q6l3p5e] {
                color: var(--bov-almost-black);
            }

            h3[b-4v5q6l3p5e] {
                padding: 2.5rem 0 1.5rem;
                font-weight: 700;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/GroupContainer.razor.rz.scp.css */
            .group-container[b-g83csvhave] {
                display: inline-flex;
                background: var(--bov-pure-white);
            }

            .group-container > .group-container-item[b-g83csvhave] {
                border: 1px solid var(--bov-mid-grey);
                border-radius: 4px;
                margin-left: -1px;
            }

            .group-container > .group-container-item:not(:last-child)[b-g83csvhave] {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
            }

            .group-container > .group-container-item:not(:first-child)[b-g83csvhave] {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
            }

            .group-container > .group-container-item:focus-within[b-g83csvhave] {
                border: 1px solid var(--bov-primary-400);
                isolation: isolate;
            }

            .group-container .group-container-item[b-g83csvhave] input {
                border: none;
                outline: none;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/IdentityFragment.razor.rz.scp.css */
            .email[b-3cf90bkqfv] {
                color: var(--bov-dark-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/LoadingSpinner.razor.rz.scp.css */
            .spinner-container[b-tv5t7wi595] {
                padding: 5rem;
            }

            .half-circle-spinner[b-tv5t7wi595],
            .half-circle-spinner *[b-tv5t7wi595] {
                box-sizing: border-box;
            }

            .half-circle-spinner[b-tv5t7wi595] {
                width: 60px;
                height: 60px;
                border-radius: 100%;
                position: relative;
            }

            .half-circle-spinner .circle[b-tv5t7wi595] {
                content: "";
                position: absolute;
                width: 100%;
                height: 100%;
                border-radius: 100%;
                border: calc(60px / 10) solid transparent;
            }

            .half-circle-spinner .circle.circle-1[b-tv5t7wi595] {
                border-top-color: var(--bov-primary-400);
                animation: half-circle-spinner-animation-b-tv5t7wi595 1s infinite;
            }

            .half-circle-spinner .circle.circle-2[b-tv5t7wi595] {
                border-bottom-color: var(--bov-primary-400);
                animation: half-circle-spinner-animation-b-tv5t7wi595 1s infinite alternate;
            }

            @keyframes half-circle-spinner-animation-b-tv5t7wi595 {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Message.razor.rz.scp.css */
            .message[b-ngqw957ktq] {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;
                color: var(--bov-almost-black);
            }

            .message .text[b-ngqw957ktq] {
                font-size: 1.3125rem;
                line-height: 1.575rem;
                font-weight: 500;
            }

            .message .subtext[b-ngqw957ktq] {
                font-size: 1rem;
                line-height: 1.5rem;
                font-weight: 400;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Modal/MessageModalFrame.razor.rz.scp.css */
            .modal-container[b-xk4svwi75y] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                padding: 1.5rem;
            }

            .modal-container-header[b-xk4svwi75y] {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }

            .modal-container-header .title-container[b-xk4svwi75y] {
                display: flex;
                justify-content: space-between;
            }

            .modal-container-header .message-container[b-xk4svwi75y] {
                color: var(--bov-almost-black);
                font-size: 1.125rem;
                font-style: normal;
            }

            .modal-container-header .title[b-xk4svwi75y] {
                color: var(--bov-primary-600);
                font-weight: 700;
                line-height: normal;
            }

            .modal-container-header .close-btn[b-xk4svwi75y] {
                display: flex;
                align-items: center;
                height: 1.5rem;
                width: 1.5rem;
                padding: 0;
                border: none;
                background-color: inherit;
            }

            .modal-container-header > .close-btn[disabled][b-xk4svwi75y] {
                opacity: 0.3;
            }

            .modal-container-footer[b-xk4svwi75y] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Modal/ModalFrame.razor.rz.scp.css */
            .modal-container[b-elc0e45ym6] {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }

            .modal-container-header[b-elc0e45ym6] {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1rem;
                border-bottom: 1px solid var(--bov-light-grey);
            }

            .modal-container-header > .title[b-elc0e45ym6] {
                font-weight: 700;
                line-height: normal;
            }

            .modal-container-header > .close-btn[b-elc0e45ym6] {
                display: flex;
                align-items: center;
                height: 1.5rem;
                width: 1.5rem;
                padding: 0;
                border: none;
                background-color: inherit;
            }

            .modal-container-header > .close-btn[disabled][b-elc0e45ym6] {
                opacity: 0.3;
            }

            .modal-container-content[b-elc0e45ym6] {
                padding: 0 1rem;
            }

            .modal-container-footer[b-elc0e45ym6] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
                padding: 1rem;
                border-top: 1px solid var(--bov-light-grey);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/NavigationButtons.razor.rz.scp.css */
            button.discard[b-af93y4q5am] {
                color: var(--bov-dark-grey);
                padding: 1rem;
                border: 0;
                background: none;
                font-weight: 500;
            }

            button[b-af93y4q5am] .icon {
                width: 1.5rem;
                height: 1.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Paginator.razor.rz.scp.css */
            .paginator[b-rweqsmwiaf] {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
                gap: 0.25rem;
                font-size: 0.875rem;
            }

            .paginator > span[b-rweqsmwiaf] {
                cursor: pointer;
                line-height: 1.0625rem;
                text-align: center;
                min-width: 1.3125rem;
            }

            .paginator[b-rweqsmwiaf] .active {
                color: var(--bov-primary-400);
            }

            .paginator[b-rweqsmwiaf] .disabled {
                cursor: initial;
            }

            .paginator[b-rweqsmwiaf] .disabled .icon {
                color: var(--bov-dark-grey);
            }

            [b-rweqsmwiaf] .icon {
                width: 1rem;
                height: 1rem;
                color: var(--bov-almost-black);
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/PrintButton.razor.rz.scp.css */
            .print[b-3ova2comx9] {
                letter-spacing: 0.004rem;
                font-size: 1rem;
                font-weight: 500;
                line-height: 1.25rem;
                padding: 0;
                border: 0;
                white-space: nowrap;
                text-decoration: underline;
                background: none;
            }

            [b-3ova2comx9] .icon {
                width: 1.5rem;
                height: 1.5rem;
                padding-bottom: 0.25rem;
                margin-right: 0.25rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Processing.razor.rz.scp.css */
            main[b-jyi8fhi7p0] {
                background-color: var(--bov-primary-light);
                text-align: center;
            }

            h1[b-jyi8fhi7p0] {
                color: var(--bov-almost-black);
                font-size: 2.25rem;
                line-height: 2.5rem;
            }

            h2[b-jyi8fhi7p0] {
                color: var(--bov-dark-grey);
                font-size: 1.31rem;
                line-height: 1rem;
                padding: 2rem 0 2.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/QuestionModal.razor.rz.scp.css */
            .modal-container[b-r6nzsey9mb] {
                display: flex;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
            }

            .container-title > h3[b-r6nzsey9mb] {
                font-weight: 700;
            }

            .container-footer[b-r6nzsey9mb] {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
            }

            .screen[b-r6nzsey9mb] {
                display: flex;
                flex-flow: column;
                gap: 1rem;
                font-weight: 500;
                font-size: 1.125rem;
                line-height: 1.35rem;
            }

            .screen > p[b-r6nzsey9mb] {
                margin: 0;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/RedirectToBovHomepage.razor.rz.scp.css */
            .bov-homepage-redirect[b-5fge99z4d2] {
                color: var(--bov-primary-400);
                font-size: 1rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Spinner.razor.rz.scp.css */
            .loading-spinner[b-mhos3oktbs] {
                display: flex;
                justify-content: center;
            }

            .loading-spinner .half-circle-spinner[b-mhos3oktbs],
            .loading-spinner .half-circle-spinner *[b-mhos3oktbs] {
                box-sizing: border-box;
            }

            .loading-spinner .half-circle-spinner[b-mhos3oktbs] {
                --size: 1.78125rem;
                --borderTopColor: var(--bov-pure-white);
                --borderBottomColor: var(--bov-pure-white);
                width: var(--size, 1.78125rem);
                height: var(--size, 1.78125rem);
                border-radius: 100%;
                position: relative;
            }

            .loading-spinner .half-circle-spinner .circle[b-mhos3oktbs] {
                content: "";
                position: absolute;
                width: 100%;
                height: 100%;
                border-radius: 100%;
                border: calc(var(--size, 1.78125rem) / 10) solid transparent;
            }

            .loading-spinner .half-circle-spinner .circle.circle-1[b-mhos3oktbs] {
                border-top-color: var(--borderTopColor, var(--bov-primary-600));
                animation: half-circle-spinner-animation-b-mhos3oktbs 1s infinite;
            }

            .loading-spinner .half-circle-spinner .circle.circle-2[b-mhos3oktbs] {
                border-bottom-color: var(--borderBottomColor, var(--bov-primary-600));
                animation: half-circle-spinner-animation-b-mhos3oktbs 1s infinite alternate;
            }

            @keyframes half-circle-spinner-animation-b-mhos3oktbs {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/Table/ScrollableTable.razor.rz.scp.css */
            .scrollable-wrapper[b-i8k1znbd44] {
                overflow-x: auto;
            }

            table[b-i8k1znbd44] {
                white-space: nowrap;
                border: none;
                width: 100%;
            }

            table thead[b-i8k1znbd44] {
                border: 1px solid var(--bov-light-grey);
                background: var(--bov-primary-400);
                color: var(--bov-pure-white);
            }

            table thead tr th[b-i8k1znbd44],
            table tbody tr td[b-i8k1znbd44] {
                padding: 0.25rem;
            }

            table tbody tr[b-i8k1znbd44] {
                border: 1px solid var(--bov-mid-grey);
            }

            table td[b-i8k1znbd44] {
                font-family: Lato;
                font-size: 0.875rem;
                line-height: 2rem;
            }

            table .sticky[b-i8k1znbd44] {
                position: -webkit-sticky;
                position: sticky;
                left: 0;
                width: 1rem;
            }

            table th.sticky[b-i8k1znbd44] {
                background: var(--bov-primary-400);
            }

            table td.sticky[b-i8k1znbd44] {
                background: var(--background);
            }

            table .sticky[b-i8k1znbd44]::before,
            table td.sticky[b-i8k1znbd44]::after {
                content: "";
                position: absolute;
                top: 0;
                bottom: 0;
            }

            table .sticky[b-i8k1znbd44]::before {
                border-left: 1px solid var(--bov-light-grey);
                left: -1px;
            }

            table td.sticky[b-i8k1znbd44]::after {
                border-right: 1px solid var(--bov-light-grey);
                right: -1px;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSelectionDateHeader.razor.rz.scp.css */
            .selection-header[b-6so9bs8z3z] {
                display: flex;
                flex-direction: row;
                align-items: flex-start;
                justify-content: space-between;
                margin-bottom: 1.5rem;
            }

            .selection-header .date-range-selection[b-6so9bs8z3z] {
                display: flex;
                flex-direction: column;
                align-items: start;
            }

            .selection-header .date-range-selection .date-range-selector[b-6so9bs8z3z] {
                width: auto;
                padding: 2.5px 25px 2.5px 10px;
                outline: 1px solid var(--bov-light-grey);
                border-radius: 5px;
                font-size: 1.25rem;
                font-weight: 500;
                cursor: pointer;
                /* Overriding the default arrow */
                background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708"/> </svg>');
                background-repeat: no-repeat;
                background-position: right 8px center;
                background-color: var(--bov-pure-white);
                /* Disabling the default appearance */
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }

            .selection-header .date-range-selection .date-range-selector:hover[b-6so9bs8z3z] {
                background-color: var(--bov-primary-light);
                outline: solid thin var(--bov-light-grey);
                transition: background-color 0.3s;
            }

            .selection-header .date-range-selection .date-range-selector:focus[b-6so9bs8z3z] {
                background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1-.708.708L8 5.707l-5.646 5.647a.5.5 0 0 1-.708-.708z"/> </svg>');
                background-repeat: no-repeat;
                background-position: right 8px center;
                background-color: var(--bov-pure-white);
            }

            .selection-header .date-range-selection .date-range-selector option:checked[b-6so9bs8z3z] {
                background-color: var(--bov-primary-lightest);
            }

            .selection-header .date-range-selection .branch-title[b-6so9bs8z3z] {
                color: var(--bov-mid-grey);
                padding-left: 0.2rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSelectionDesktop.razor.rz.scp.css */
            .left-arrow[b-8o1r0gtm9n],
            .right-arrow[b-8o1r0gtm9n] {
                position: absolute;
                top: 45%;
                border-radius: 50%;
                width: 2.5rem;
                height: 2.5rem;
                justify-content: center;
                align-items: center;
                padding: 0;
                box-shadow:
                    0px 8px 3px rgba(33, 33, 33, 0.01),
                    0px 5px 3px rgba(33, 33, 33, 0.05),
                    0px 2px 2px rgba(33, 33, 33, 0.09),
                    0px 1px 1px rgba(33, 33, 33, 0.1),
                    0px 0px 0px rgba(33, 33, 33, 0.1);
            }

            .left-arrow[b-8o1r0gtm9n] {
                right: 101%;
            }

            .right-arrow[b-8o1r0gtm9n] {
                left: 101%;
            }

            .left-arrow[b-8o1r0gtm9n] .icon,
            .right-arrow[b-8o1r0gtm9n] .icon {
                position: absolute;
                width: 15px;
                height: 15px;
                transform: translate(-50%, -50%);
            }

            .selection-container[b-8o1r0gtm9n] {
                height: 16.625rem;
                overflow-y: auto;
                margin-bottom: 2.5rem;
                margin-top: 0.9375rem;
            }

            .date-container[b-8o1r0gtm9n] {
                text-align: left;
                font-weight: 400;
                border-left: 4px solid;
                border-color: var(--bov-pure-white);
            }

            .date-container.selected[b-8o1r0gtm9n] {
                border-color: var(--bov-primary-400);
            }

            .date-container .weekday[b-8o1r0gtm9n] {
                color: var(--bov-mid-grey);
                text-transform: uppercase;
            }

            .date-container .day[b-8o1r0gtm9n] {
                color: var(--bov-almost-black);
                font-size: 1.75rem;
            }

            .date-container.selected .day[b-8o1r0gtm9n],
            .date-container.selected .weekday[b-8o1r0gtm9n] {
                color: var(--bov-primary-400);
            }

            .date-container .day.disabled[b-8o1r0gtm9n] {
                color: var(--bov-mid-grey);
            }

            .date-container.col[b-8o1r0gtm9n] {
                margin: 0 0.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSelectionMobile.razor.rz.scp.css */
            .date-selection-container[b-2pym45cuqz] {
                display: flex;
            }

            .date-selection-container .touch-area-arrow[b-2pym45cuqz] {
                display: flex;
                cursor: pointer;
                width: 44px;
                height: 44px;
                justify-content: center;
                align-items: center;
            }

            .date-selection-container .touch-area-arrow.disabled[b-2pym45cuqz] {
                cursor: unset;
            }

            .date-selection-container .touch-area-arrow .button-arrow[b-2pym45cuqz] {
                display: flex;
                width: 24px;
                height: 24px;
                text-align: center;
                align-items: center;
                border-radius: 50%;
                padding: unset;
                cursor: pointer;
            }

            .date-selection-container .touch-area-arrow.disabled .button-arrow[b-2pym45cuqz] {
                cursor: unset;
            }

            .date-selection-container .touch-area-arrow .arrow-left[b-2pym45cuqz] {
                justify-content: left;
            }

            .date-selection-container .touch-area-arrow .arrow-right[b-2pym45cuqz] {
                justify-content: right;
            }

            .date-selection-container .touch-area-arrow .arrow-right[b-2pym45cuqz] .icon,
            .date-selection-container .touch-area-arrow .arrow-left[b-2pym45cuqz] .icon {
                width: 15px;
                height: 15px;
            }

            .date-selection-container .touch-area-arrow .arrow-right[b-2pym45cuqz] .icon {
                transform: translate(-20%, 0%);
            }

            .date-selection-container .touch-area-arrow .arrow-left[b-2pym45cuqz] .icon {
                transform: translate(20%, 0%);
            }

            .date-selection-container .days-container[b-2pym45cuqz] {
                justify-content: space-around;
                flex-grow: 1;
                display: flex;
                align-items: center;
            }

            .date-selection-container .days-container .touch-day[b-2pym45cuqz] {
                display: flex;
                flex-direction: column;
                align-items: center;
                width: 44px;
                height: 48px;
                cursor: pointer;
            }

            .date-selection-container .days-container .touch-day .day-number[b-2pym45cuqz] {
                display: flex;
                height: 30px;
                justify-content: center;
                align-items: center;
                color: var(--bov-almost-black);
                font-size: 16px;
            }

            .date-selection-container .days-container .touch-day .day-letter[b-2pym45cuqz] {
                display: flex;
                height: 18px;
                justify-content: center;
                align-items: center;
                color: var(--bov-mid-grey);
                text-transform: uppercase;
            }

            .date-selection-container .days-container .touch-day .day-number.selected-day[b-2pym45cuqz] {
                border-radius: 50%;
                background-color: var(--bov-primary-400);
                color: var(--bov-pure-white);
                width: 30px;
            }

            .date-selection-container .days-container .touch-day .day-number.selected-day .disabled[b-2pym45cuqz] {
                color: var(--bov-pure-white);
            }

            .date-selection-container .days-container .touch-day .day-number .disabled[b-2pym45cuqz] {
                color: var(--bov-mid-grey);
            }

            .selection-container[b-2pym45cuqz] {
                overflow-y: auto;
                margin-bottom: 2.5rem;
                margin-top: 0.9375rem;
            }

            .alert-message[b-2pym45cuqz] {
                margin-bottom: 1.5rem;
            }

            @media (max-width: 1024px) {
                .date-selection-header-wrapper.fixed[b-2pym45cuqz] {
                    position: fixed;
                    top: 4rem;
                    left: 0;
                    width: 100%;
                    padding: 1rem;
                    background: var(--bov-pure-white);
                    z-index: 99;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSelectionUnavailableSlotsMessage.razor.rz.scp.css */
            .time-selection-error-state[b-y4v0zrgozi] {
                margin-top: 3.5rem;
                margin-bottom: 5.5rem;
            }

            .time-selection-error-state > *[b-y4v0zrgozi] {
                text-align: center;
                margin-bottom: 1.5rem;
            }

            .time-selection-error-state h3[b-y4v0zrgozi] {
                font-size: 2rem;
                font-weight: 500;
                margin-top: 3.5rem;
                margin-bottom: 2.5rem;
            }

            .time-selection-error-state h4[b-y4v0zrgozi] {
                font-size: 1.313rem;
                font-weight: 700;
                letter-spacing: 0.005rem;
            }

            .time-selection-error-state p[b-y4v0zrgozi] {
                font-size: 0.875rem;
                font-weight: 400;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSelectionView.razor.rz.scp.css */
            .slot-container[b-61qiuhxdb2] {
                background: var(--bov-pure-white);
                padding: 2rem 3.625rem;
                position: relative;
            }

            .appointment-alert[b-61qiuhxdb2] {
                display: flex;
                padding: 1rem 0.5rem;
                gap: 0.5rem;
                border-radius: 0.25rem;
                border: 0.0625rem solid var(--bov-primary-500);
                background: var(--bov-primary-100);
                justify-content: space-between;
                margin-top: 1rem;
                align-items: center;
            }

            .appointment-alert .message[b-61qiuhxdb2] {
                text-align: left;
                font-size: 0.875rem;
            }

            .appointment-alert .show-me[b-61qiuhxdb2] {
                white-space: nowrap;
                font-size: 1em;
                font-weight: 500;
                letter-spacing: 0.004rem;
            }

            @media (max-width: 1024px) {
                .d-block-mobile[b-61qiuhxdb2] {
                    background: var(--bov-pure-white);
                }

                .slot-container[b-61qiuhxdb2] {
                    padding: 1.5rem 1rem 0;
                }

                .nav-buttons-container[b-61qiuhxdb2] {
                    position: sticky;
                    bottom: 0;
                    padding: 0.375rem 1rem 1.375rem;
                    background: var(--bov-pure-white);
                }

                .appointment-alert[b-61qiuhxdb2] {
                    flex-direction: column;
                    align-items: start;
                    margin-top: 0;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/TimeSlotsContainer.razor.rz.scp.css */
            .time-slots-container-empty[b-jv4pa8pjhs] {
                position: sticky;
                top: 0;
                height: 16.625rem;
                align-items: center;
                justify-content: center;
                color: var(--bov-light-grey);
            }

            .time-slots-container.col[b-jv4pa8pjhs] {
                margin: 0 0.5rem;
            }

            .time-slots-container[b-jv4pa8pjhs] {
                display: flex;
                flex-direction: column;
                background: rgba(var(--bov-primary-lightest-rgb), 0.3);
                border: 1px solid var(--bov-lightest-grey);
                border-radius: 6px;
                padding: 0.5625rem 0.5rem;
            }

            .time-slots-container .time-slot[b-jv4pa8pjhs] {
                padding: 0.5625rem 0.78125rem;
                margin-bottom: 0.75rem;
                color: var(--bov-almost-black);
                font-weight: 500;
                border: 1.5px solid var(--bov-primary-400);
                background: var(--bov-pure-white);
            }

            .time-slots-container .time-slot:last-child[b-jv4pa8pjhs] {
                margin-bottom: 0;
            }

            .time-slots-container .time-slot:not(.selected):hover[b-jv4pa8pjhs] {
                background: var(--bov-primary-lightest);
                border: 1px solid var(--bov-primary-400);
                color: var(--bov-primary-400);
            }

            .time-slots-container .selected[b-jv4pa8pjhs] {
                background: var(--bov-primary-400);
                border: 1px solid var(--bov-primary-400);
                color: var(--bov-pure-white);
            }

            .alert-message[b-jv4pa8pjhs] {
                margin-top: 1rem;
                padding: 0 0.5rem;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/TimeSelection/Timezone.razor.rz.scp.css */
            .time-zone[b-f838xboya2] {
                width: auto;
                padding: 0;
                margin-left: auto;
                color: var(--bov-mid-grey);
                display: flex;
            }

            .time-zone .time-zone-title[b-f838xboya2] {
                font-weight: 400;
            }

            .time-zone .time-zone-display[b-f838xboya2] {
                font-weight: 500;
                padding-left: 0.5rem;
            }

            @media (max-width: 1024px) {
                .time-zone-title[b-f838xboya2] {
                    display: none;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/UnauthorizedView.razor.rz.scp.css */
            .form-container[b-b9p60kmcmu] {
                padding: 5rem 3rem;
            }

            h1[b-b9p60kmcmu] {
                color: var(--bov-almost-black);
            }

            h3[b-b9p60kmcmu] {
                padding: 1rem 0 4rem;
                font-weight: 700;
            }
            /* _content/AppointmentBookingSystem.Web/Components/Shared/WarningContainer.razor.rz.scp.css */
            .warning-container[b-m3hi046i1o] {
                background-color: var(--warning);
                padding: 1rem 0.5rem;
                border-radius: 0.25rem;
                text-align: left;
            }
            /* _content/AppointmentBookingSystem.Web/Pages/Appointment.razor.rz.scp.css */
            [b-jscfsjc5qk] .description {
                margin-top: 3.5rem;
                margin-bottom: 2rem;
            }

            [b-jscfsjc5qk] .underline {
                text-decoration: underline;
            }
            /* _content/AppointmentBookingSystem.Web/Pages/BackOffice/BookAppointment.razor.rz.scp.css */
            [b-r8yw8neufr] .input-container {
                --bs-gutter-x: 0px;
            }

            [b-r8yw8neufr] .input-container:last-child {
                margin-bottom: 0;
            }

            .backoffice-time-selection[b-r8yw8neufr] {
                min-height: 480px;
                font-weight: 500;
                color: var(--bov-almost-black);
            }
            /* _content/AppointmentBookingSystem.Web/Pages/Index.razor.rz.scp.css */
            [b-oi74bfdmvr] .description {
                margin-top: 3.5rem;
                margin-bottom: 2rem;
            }

            @media (max-width: 768px) {
                [b-oi74bfdmvr] .description {
                    margin-top: 0rem;
                    margin-bottom: 1rem;
                }
            }
            /* _content/AppointmentBookingSystem.Web/Shared/AuthControl.razor.rz.scp.css */
            .avatar[b-m421njhptg] {
                display: flex;
                justify-content: center;
                align-items: center;
                border-radius: 50%;
                font-size: 1.125rem;
                font-weight: 600;
                color: var(--bov-primary-600);
                background-color: var(--bov-primary-300);
                height: 3rem;
                width: 3rem;
            }
            .arrow-container[b-m421njhptg] {
                margin-top: 0.5rem;
                margin-left: 0.25rem;
            }
            .arrow-container .arrow[b-m421njhptg] {
                content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
                width: 1rem;
                height: 1rem;
            }

            .nav-link[b-m421njhptg] {
                padding: unset;
            }

            .nav-link-dropdown[b-m421njhptg] {
                display: flex;
                align-items: center;
                cursor: pointer;
            }

            ul.dropdown-menu[b-m421njhptg] {
                position: absolute;
                right: 0;
                padding: 0;
                margin-top: 0.5rem;
                border-radius: 0.25rem;
                background: var(--bov-pure-white);
                box-shadow:
                    0px 0px 0px 0px rgba(0, 0, 0, 0.1),
                    0px 1px 2px 0px rgba(0, 0, 0, 0.1),
                    0px 5px 5px 0px rgba(0, 0, 0, 0.09),
                    0px 10px 6px 0px rgba(0, 0, 0, 0.05),
                    0px 18px 7px 0px rgba(0, 0, 0, 0.01),
                    0px 28px 8px 0px rgba(0, 0, 0, 0);
            }

            ul.dropdown-menu a.dropdown-menu-item[b-m421njhptg] {
                display: block;
                padding: 1rem 1.25rem;
                font-size: 0.875rem;
                white-space: nowrap;
                background-color: transparent;
                text-decoration: none;
                border-bottom: 1px solid #cad4e3;
            }

            ul.dropdown-menu a.dropdown-menu-item.disabled[b-m421njhptg] {
                color: #8693a7;
                background-color: #f8f8fc;
            }

            ul.dropdown-menu a.dropdown-menu-item:not(.disabled)[b-m421njhptg] {
                cursor: pointer;
            }

            ul.dropdown-menu a.dropdown-menu-item:not(.disabled):hover[b-m421njhptg] {
                text-decoration: underline;
            }
            /* _content/AppointmentBookingSystem.Web/Shared/BackOfficeLayout.razor.rz.scp.css */
            .nav-buttons-container[b-qdm0ue5mvl] {
                margin-left: 2rem;
                margin-right: auto;
            }

            section[b-qdm0ue5mvl] {
                padding-top: 5rem;
                padding-bottom: 0;
                margin-left: 1rem;
                margin-right: 1rem;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            /* _content/AppointmentBookingSystem.Web/Shared/SinglePageLayout.razor.rz.scp.css */
            main[b-v4g1a7sll7] {
                background-color: var(--bov-primary-light);
            }
        </style>
        <!--!-->

        <!--!-->
        <title>BOV – Appointment mobile</title>
        <!--!-->
        <!--!-->
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/map.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/marker.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/log.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/onion.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/controls.js"
        ></script>
        <style id="savepage-cssvariables">
            :root {
                --savepage-url-14: url(data:image/bmp;base64,AAACAAEAICACAAgACAAwAQAAFgAAACgAAAAgAAAAQAAAAAEAAQAAAAAAAAEAAAAAAAAAAAAAAgAAAAAAAAAAAAAA////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAA/AAAAfwAAAP+AAAH/gAAB/8AAA//AAAd/wAAGf+AAAH9gAADbYAAA2yAAAZsAAAGbAAAAGAAAAAAAAA//////////////////////////////////////////////////////////////////////////////////////gH///4B///8Af//+AD///AA///wAH//4AB//8AAf//AAD//5AA///gAP//4AD//8AF///AB///5A////5///8=);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>

        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body tabindex="-1">
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->

        <!--!--><!--!--><!--!-->

        <main>
            <!--!-->
            <nav class="navbar" b-0h6h1p6wgv="">
                <div class="nav-container" style="" b-0h6h1p6wgv="">
                    <!--!--><a href="https://www.word.com/" target="_blank" class="navbar-brand" b-0h6h1p6wgv=""
                        ><img
                            data-savepage-currentsrc="https://space.word.com/assets/img/bov-logo.svg"
                            data-savepage-src="/assets/img/bov-logo.svg"
                            src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iNTIiIHZpZXdCb3g9IjAgMCA4MCA1MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8xNjQ3XzgyKSI+DQo8cGF0aCBkPSJNNC42MDE2OSA0OS4zMzM2QzQuNDYzMDcgNDkuNTMxMiA0LjI3OTczIDQ5LjY4NDkgNC4wNTEyNyA0OS43OTUzQzMuODIyMTYgNDkuOTA1NyAzLjU1NTg5IDQ5Ljk4MjggMy4yNTI0NiA1MC4wMjU4QzIuOTQ4MzkgNTAuMDY5OSAyLjYyNjkyIDUwLjA5MDcgMi4yODc3NCA1MC4wOTA3QzIuMTA1OTkgNTAuMDkwNyAxLjk0NjA0IDUwLjA4OTIgMS44MDgzNSA1MC4wODU2QzEuNjcwMzYgNTAuMDgxNSAxLjU0OTkyIDUwLjA3NTIgMS40NDc1MiA1MC4wNjc1QzEuMzI5MTMgNTAuMDU5NSAxLjIyNjI2IDUwLjA1MTggMS4xMzk1NCA1MC4wNDM4VjQ3LjE1NjNIMi42MTg5M0MyLjk1MDU5IDQ3LjE1NjMgMy4yNTAyNiA0Ny4xNzk1IDMuNTE4NDEgNDcuMjI2NUMzLjc4Njg4IDQ3LjI3NDcgNC4wMTc1NSA0Ny4zNTI5IDQuMjExMDUgNDcuNDYzM0M0LjQwNDEgNDcuNTc0MiA0LjU1MjI4IDQ3LjcyMjIgNC42NTQ1MiA0Ny45MDcyQzQuNzU3MDkgNDguMDkzMiA0LjgwODg0IDQ4LjMxOTcgNC44MDg4NCA0OC41ODc4QzQuODA4ODQgNDguODg4MSA0LjczOTIzIDQ5LjEzNjUgNC42MDE2OSA0OS4zMzM2VjQ5LjMzMzZaTTEuMTM5NTQgNDMuNjk5N0MxLjI3MzYyIDQzLjY4NDEgMS40MjM4NSA0My42NzI1IDEuNTg5MjggNDMuNjY0NEMxLjc1NTA0IDQzLjY1NjggMS45ODM4MyA0My42NTI4IDIuMjc1NjYgNDMuNjUyOEMyLjU2NzY1IDQzLjY1MjggMi44NDM4IDQzLjY3NjUgMy4xMDQyNyA0My43MjM0QzMuMzY0NzQgNDMuNzcwNSAzLjU5MTE4IDQzLjg0NDMgMy43ODQ2OCA0My45NDNDMy45NzgyIDQ0LjA0MSA0LjEzIDQ0LjE3MTIgNC4yNDAzOSA0NC4zMzMzQzQuMzUwNzkgNDQuNDk1IDQuNDA2MzEgNDQuNjk0MSA0LjQwNjMxIDQ0LjkzMUM0LjQwNjMxIDQ1LjE4MzUgNC4zNTI2OCA0NS4zOTI3IDQuMjQ2NSA0NS41NThDNC4xNDAwMyA0NS43MjM1IDMuOTkzODggNDUuODU3NSAzLjgwODM3IDQ1Ljk2MDRDMy42MjMwMSA0Ni4wNjMxIDMuNDA0MjYgNDYuMTM0NiAzLjE1MTc4IDQ2LjE3MzVDMi44OTkgNDYuMjEyOSAyLjYzMDg1IDQ2LjIzMzMgMi4zNDY3IDQ2LjIzMzNIMS4xMzk1NFY0My42OTk3Wk00LjQxODIzIDQ2LjU5OTRDNC43NzI5NSA0Ni40NTczIDUuMDU3MjUgNDYuMjQyNSA1LjI3MDAyIDQ1Ljk1NTFDNS40ODMxNSA0NS42NjczIDUuNTg5NjEgNDUuMjk3OCA1LjU4OTYxIDQ0Ljg0NzlDNS41ODk2MSA0NC40NDU3IDUuNTAyOSA0NC4xMDYgNS4zMjk0NyA0My44MzAyQzUuMTU1NTcgNDMuNTU0IDQuOTE2ODcgNDMuMzMxMiA0LjYxMzMgNDMuMTYxNEM0LjMwOTQgNDIuOTkyIDMuOTUwNDQgNDIuODcxOSAzLjUzNjI5IDQyLjgwMDZDMy4xMjE5OSA0Mi43MjkxIDIuNjc4MzYgNDIuNjkzOCAyLjIwNDYyIDQyLjY5MzhDMi4wMzkzNCA0Mi42OTM4IDEuODYxMzYgNDIuNjk3NyAxLjY3MjQgNDIuNzA1OUMxLjQ4MjgxIDQyLjcxMzQgMS4yOTEzNCA0Mi43MjU1IDEuMDk4MyA0Mi43NDExQzAuOTA0Nzg5IDQyLjc1NzYgMC43MTM2MjkgNDIuNzc3MiAwLjUyNDA0MyA0Mi44MDA2QzAuMzM0NzY3IDQyLjgyNDMgMC4xNjEzMyA0Mi44NTY0IDAuMDAzNDE3OTcgNDIuODk1M1Y1MC44NDgzQzAuMTYxMzMgNTAuODg4NCAwLjMzNDc2NyA1MC45MTk4IDAuNTI0MDQzIDUwLjk0M0MwLjcxMzYyOSA1MC45Njc1IDAuOTA0Nzg5IDUwLjk4NjUgMS4wOTgzIDUxLjAwMjlDMS4yOTEzNCA1MS4wMTg0IDEuNDg0ODUgNTEuMDMwMiAxLjY3Nzg4IDUxLjAzODJDMS44NzE1NSA1MS4wNDU5IDIuMDUwOTQgNTEuMDQ5OCAyLjIxNjcgNTEuMDQ5OEMzLjUyNjEgNTEuMDQ5OCA0LjQ4MzMxIDUwLjg0MjcgNS4wODY3MiA1MC40MjhDNS42OTAyOSA1MC4wMTQgNS45OTIxOCA0OS4zOTcxIDUuOTkyMTggNDguNTc2MUM1Ljk5MjE4IDQ4LjAxNjEgNS44NTAxMSA0Ny41ODE3IDUuNTY1OTIgNDcuMjc0N0M1LjI4MjEgNDYuOTY2MyA0Ljg5OTE2IDQ2Ljc0MTUgNC40MTgyMyA0Ni41OTk0IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTAuNTEzNSA1MC4xMDI3QzEwLjM3ODkgNTAuMTM0OSAxMC4yMTE2IDUwLjE1NTggMTAuMDEwNCA1MC4xNjg2QzkuODA4ODggNTAuMTc5NCA5LjU3ODM3IDUwLjE4NTkgOS4zMTc4NyA1MC4xODU5QzguODgzODIgNTAuMTg1OSA4LjU0MDcxIDUwLjEwODkgOC4yODgyNCA0OS45NTVDOC4wMzU3NyA0OS44MDE3IDcuOTA5NjggNDkuNTI3MSA3LjkwOTY4IDQ5LjEzMjhDNy45MDk2OCA0OC45MTkzIDcuOTYwNjYgNDguNzQ3OSA4LjA2MzM1IDQ4LjYxNzRDOC4xNjU2IDQ4LjQ4NzQgOC4yOTQxOCA0OC4zODQ1IDguNDQ3OSA0OC4zMTA0QzguNjAxNTcgNDguMjM0OCA4Ljc3MTU0IDQ4LjE4NTUgOC45NTcwNSA0OC4xNjIyQzkuMTQyMDcgNDguMTM3NyA5LjMxNzg3IDQ4LjEyNjkgOS40ODM2MiA0OC4xMjY5QzkuNzM1ODEgNDguMTI2OSA5Ljk1MDk1IDQ4LjE0MDEgMTAuMTI4NSA0OC4xNjczQzEwLjMwNjEgNDguMTk1OSAxMC40MzQyIDQ4LjIyOTYgMTAuNTEzNSA0OC4yNjg2VjUwLjEwMjdaTTExLjA3NTMgNDUuMzI2OEMxMC44OSA0NS4xMTg0IDEwLjY0NTUgNDQuOTU2NyAxMC4zNDE0IDQ0Ljg0MjJDMTAuMDM3NyA0NC43Mjc4IDkuNjY1MDggNDQuNjcwNCA5LjIyMzE3IDQ0LjY3MDRDOC44MzY0NSA0NC42NzA0IDguNDc3NTIgNDQuNzAwNSA4LjE0NjE3IDQ0Ljc1OTFDNy44MTQ4MiA0NC44MTg1IDcuNTc4MDQgNDQuODgwMSA3LjQzNTkzIDQ0Ljk0MjZMNy41NjYyOCA0NS44NTM5QzcuNzAwMzIgNDUuNzk4OCA3LjkwMzU4IDQ1Ljc0NTUgOC4xNzU2NCA0NS42OTM3QzguNDQ3OSA0NS42NDI4IDguNzY1NDQgNDUuNjE3OSA5LjEyODMxIDQ1LjYxNzlDOS40MTI2MSA0NS42MTc5IDkuNjQzNDQgNDUuNjU4MyA5LjgyMDggNDUuNzQxNEM5Ljk5ODMyIDQ1LjgyNDUgMTAuMTM4MyA0NS45MzU0IDEwLjI0MSA0Ni4wNzMxQzEwLjM0MzYgNDYuMjExMiAxMC40MTQ3IDQ2LjM2OSAxMC40NTQgNDYuNTQ2QzEwLjQ5MzIgNDYuNzI0MiAxMC41MTM1IDQ2LjkwMzYgMTAuNTEzNSA0Ny4wODQ3VjQ3LjM5M0MxMC40ODE2IDQ3LjM4NSAxMC40MjYxIDQ3LjM3MzQgMTAuMzQ3NSA0Ny4zNTc3QzEwLjI2ODUgNDcuMzQxMiAxMC4xNzU3IDQ3LjMyNCAxMC4wNjkzIDQ3LjMwNDJDOS45NjMwMyA0Ny4yODM4IDkuODUwNTkgNDcuMjY4MiA5LjczMjA0IDQ3LjI1NjZDOS42MTM2NSA0Ny4yNDQ1IDkuNDk5MzIgNDcuMjM5MyA5LjM4ODkyIDQ3LjIzOTNDOS4wNDE3MSA0Ny4yMzkzIDguNzEwMDggNDcuMjc0NiA4LjM5NDU0IDQ3LjM0NDlDOC4wNzkwNSA0Ny40MTY0IDcuODAyODkgNDcuNTI3MSA3LjU2NjI4IDQ3LjY3NjhDNy4zMjk0NyA0Ny44MjY2IDcuMTQyMDcgNDguMDI0IDcuMDAzOTQgNDguMjY4NkM2Ljg2NTkyIDQ4LjUxMzQgNi43OTY2MyA0OC44MDQ5IDYuNzk2NjMgNDkuMTQ0NUM2Ljc5NjYzIDQ5LjQ5OTggNi44NTYyMSA0OS44MDI5IDYuOTc0MjcgNTAuMDU1NEM3LjA5MjcgNTAuMzA3OSA3LjI1ODQ1IDUwLjUxMTEgNy40NzE1NCA1MC42NjQ4QzcuNjg0NTEgNTAuODE5NCA3LjkzNjk4IDUwLjkzMTQgOC4yMjkxMSA1MS4wMDI5QzguNTIwNjQgNTEuMDczNCA4Ljg0MDIzIDUxLjEwODQgOS4xODc3MiA1MS4xMDg0QzkuNDMyMzYgNTEuMTA4NCA5LjY3ODczIDUxLjA5OTEgOS45MjcyNiA1MS4wNzk1QzEwLjE3NTcgNTEuMDU5IDEwLjQwNjUgNTEuMDM4MSAxMC42MTk4IDUxLjAxNDVDMTAuODMyOSA1MC45OTA4IDExLjAyNCA1MC45NjUxIDExLjE5MzcgNTAuOTM3OEMxMS4zNjMxIDUwLjkwOTIgMTEuNDk1NSA1MC44ODg0IDExLjU5MDEgNTAuODcyN1Y0Ny4wMjU3QzExLjU5MDEgNDYuNjc4NCAxMS41NTA3IDQ2LjM2MDggMTEuNDcxOSA0Ni4wNzMxQzExLjM5MjkgNDUuNzg0OSAxMS4yNjA4IDQ1LjUzNjMgMTEuMDc1MyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMjMuMzQ4MiA0OS4xMzgxQzIzLjA5MTkgNDguODI3IDIyLjgzMTcgNDguNTM2OSAyMi41Njc1IDQ4LjI2ODhDMjIuMzAyOSA0OC4wMDA1IDIyLjA1MjYgNDcuNzc1NyAyMS44MTU2IDQ3LjU5MzhDMjIuMDIwOCA0Ny4zODEgMjIuMjQgNDcuMTU0NiAyMi40NzI5IDQ2LjkxMjlDMjIuNzA1MyA0Ni42NzMzIDIyLjkzNiA0Ni40MzE3IDIzLjE2NTEgNDYuMTkxNkMyMy4zOTM3IDQ1Ljk1MTIgMjMuNjE0OCA0NS43MTE5IDIzLjgyNzggNDUuNDc0OUMyNC4wNDA3IDQ1LjIzODIgMjQuMjM4IDQ1LjAyMTggMjQuNDE5OSA0NC44MjQzSDIzLjEyOTVDMjIuOTg3NCA0NC45ODk2IDIyLjgxNzYgNDUuMTgyIDIyLjYyMDUgNDUuMzk4M0MyMi40MjM1IDQ1LjYxNTUgMjIuMjE0MyA0NS44NDE5IDIxLjk5MzUgNDYuMDc4OEMyMS43NzIzIDQ2LjMxNTcgMjEuNTQ3NCA0Ni41NDg1IDIxLjMxODggNDYuNzc3M0MyMS4wODk4IDQ3LjAwNjUgMjAuODgwNiA0Ny4yMTUgMjAuNjkxNyA0Ny40MDQ3VjQxLjc5NDVMMTkuNTkwOCA0MS45ODM2VjUwLjk3ODVIMjAuNjkxN1Y0OC4wMjAyQzIwLjkxMjMgNDguMTcgMjEuMTQ1MiA0OC4zNTUgMjEuMzg5NiA0OC41NzYxQzIxLjYzNDEgNDguNzk3NCAyMS44NzUgNDkuMDM5NSAyMi4xMTE2IDQ5LjMwMzZDMjIuMzQ4NCA0OS41Njg2IDIyLjU3NTIgNDkuODQ0NyAyMi43OTIzIDUwLjEzMjdDMjMuMDA5MiA1MC40MjEyIDIzLjIwMDcgNTAuNzAyNyAyMy4zNjY1IDUwLjk3ODVIMjQuNjU2M0MyNC40OTg1IDUwLjcwMjcgMjQuMzA1IDUwLjQwNDcgMjQuMDc2NiA1MC4wODU2QzIzLjg0NzQgNDkuNzY1NyAyMy42MDQ4IDQ5LjQ1MDUgMjMuMzQ4MiA0OS4xMzgxIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTcuNTQ5MSA0NS40ODE0QzE3LjM1NiA0NS4yMzMgMTcuMDk3NCA0NS4wMzkgMTYuNzczOCA0NC45MDEzQzE2LjQ1MDQgNDQuNzYzMyAxNi4wNDQgNDQuNjk0MiAxNS41NTUyIDQ0LjY5NDJDMTUuMDEwNCA0NC42OTQyIDE0LjUyOSA0NC43MzA0IDE0LjExMTEgNDQuODAxQzEzLjY5MjkgNDQuODcxMiAxMy4zNTc2IDQ0LjkzODcgMTMuMTA1MSA0NS4wMDIyVjUwLjk3ODVIMTQuMjA1OFY0NS43ODM0QzE0LjI0NTIgNDUuNzc1MyAxNC4zMTAyIDQ1Ljc2MzcgMTQuNDAxIDQ1Ljc0NzJDMTQuNDkxOCA0NS43MzIzIDE0LjU5NDUgNDUuNzE4MyAxNC43MDg3IDQ1LjcwNjNDMTQuODIyOCA0NS42OTM5IDE0Ljk0MzQgNDUuNjg0NiAxNS4wNjk5IDQ1LjY3NjZDMTUuMTk1OSA0NS42Njg5IDE1LjMxODIgNDUuNjY0OSAxNS40MzY4IDQ1LjY2NDlDMTUuNzI4NSA0NS42NjQ5IDE1Ljk3MzEgNDUuNzAyNiAxNi4xNzA1IDQ1Ljc3N0MxNi4zNjc2IDQ1Ljg1MjQgMTYuNTI1NCA0NS45NzIxIDE2LjY0MzggNDYuMTM4NkMxNi43NjIyIDQ2LjMwNCAxNi44NDY5IDQ2LjUyMTIgMTYuODk4MyA0Ni43ODk0QzE2Ljk0OTMgNDcuMDU3NSAxNi45NzU0IDQ3LjM4MSAxNi45NzU0IDQ3Ljc2MDFWNTAuOTc4NUgxOC4wNzU4VjQ3LjUyMzNDMTguMDc1OCA0Ny4xMDUzIDE4LjAzNjMgNDYuNzIyNyAxNy45NTc3IDQ2LjM3NTFDMTcuODc4NyA0Ni4wMjc5IDE3Ljc0MjYgNDUuNzI5OSAxNy41NDkxIDQ1LjQ4MTQiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS40MjEgNDkuNTUyOEMzMS4xMDk1IDQ5Ljk1OTEgMzAuNjg1MyA1MC4xNjIyIDMwLjE0OSA1MC4xNjIyQzI5LjYxMiA1MC4xNjIyIDI5LjE4ODIgNDkuOTU5MSAyOC44NzY3IDQ5LjU1MjhDMjguNTY0NyA0OS4xNDYyIDI4LjQwOTEgNDguNTk2NSAyOC40MDkxIDQ3LjkwMTdDMjguNDA5MSA0Ny4yMDcyIDI4LjU2NDcgNDYuNjU2OCAyOC44NzY3IDQ2LjI1MDRDMjkuMTg4MiA0NS44NDQzIDI5LjYxMiA0NS42NDExIDMwLjE0OSA0NS42NDExQzMwLjY4NTMgNDUuNjQxMSAzMS4xMDk1IDQ1Ljg0NDMgMzEuNDIxIDQ2LjI1MDRDMzEuNzMzIDQ2LjY1NjggMzEuODg4OCA0Ny4yMDcyIDMxLjg4ODggNDcuOTAxN0MzMS44ODg4IDQ4LjU5NjUgMzEuNzMzIDQ5LjE0NjIgMzEuNDIxIDQ5LjU1MjhWNDkuNTUyOFpNMzIuMjI2IDQ1LjU1NzlDMzEuOTY5MyA0NS4yNzQxIDMxLjY2NCA0NS4wNTQ2IDMxLjMwODYgNDQuOTAxMkMzMC45NTM4IDQ0Ljc0NzUgMzAuNTY3MiA0NC42NzA0IDMwLjE0OSA0NC42NzA0QzI5LjczMDYgNDQuNjcwNCAyOS4zNDM5IDQ0Ljc0NzUgMjguOTg5IDQ0LjkwMTJDMjguNjMzNyA0NS4wNTQ2IDI4LjMyNzkgNDUuMjc0MSAyOC4wNzE3IDQ1LjU1NzlDMjcuODE1MyA0NS44NDE4IDI3LjYxNjMgNDYuMTgzOCAyNy40NzQgNDYuNTgxM0MyNy4zMzIgNDYuOTgwMyAyNy4yNjA3IDQ3LjQyMDMgMjcuMjYwNyA0Ny45MDE3QzI3LjI2MDcgNDguMzkxIDI3LjMzMiA0OC44MzIyIDI3LjQ3NCA0OS4yMjY4QzI3LjYxNjMgNDkuNjIxOCAyNy44MTUzIDQ5Ljk2MDcgMjguMDcxNyA1MC4yNDQ1QzI4LjMyNzkgNTAuNTI5MSAyOC42MzM3IDUwLjc0NzkgMjguOTg5IDUwLjkwMjVDMjkuMzQzOSA1MS4wNTYyIDI5LjczMDYgNTEuMTMyMSAzMC4xNDkgNTEuMTMyMUMzMC41NjcyIDUxLjEzMjEgMzAuOTUzOCA1MS4wNTYyIDMxLjMwODYgNTAuOTAyNUMzMS42NjQgNTAuNzQ3OSAzMS45NjkzIDUwLjUyOTEgMzIuMjI2IDUwLjI0NDVDMzIuNDgyNSA0OS45NjA3IDMyLjY4MTcgNDkuNjIxOCAzMi44MjM2IDQ5LjIyNjhDMzIuOTY1NyA0OC44MzIyIDMzLjAzNjkgNDguMzkxIDMzLjAzNjkgNDcuOTAxN0MzMy4wMzY5IDQ3LjQyMDMgMzIuOTY1NyA0Ni45ODAzIDMyLjgyMzYgNDYuNTgxM0MzMi42ODE3IDQ2LjE4MzggMzIuNDgyNSA0NS44NDE4IDMyLjIyNiA0NS41NTc5WiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTM2LjY4MiA0MS43OTQ1QzM1Ljg1MzQgNDEuNzk0NSAzNS4yNDU5IDQyLjAwOTQgMzQuODU5NCA0Mi40NDAxQzM0LjQ3MjUgNDIuODY5NiAzNC4yNzkyIDQzLjQ3OTggMzQuMjc5MiA0NC4yNjgzVjUwLjk3ODVIMzUuMzhWNDUuNzQ3MkgzNy43NDY5VjQ0LjgyNDNIMzUuMzhWNDQuMjkxOUMzNS4zOCA0My44MTgyIDM1LjQ4MjQgNDMuNDQyMiAzNS42ODggNDMuMTYxNUMzNS44OTI2IDQyLjg4MTMgMzYuMjUxOSA0Mi43NDEyIDM2Ljc2NDcgNDIuNzQxMkMzNy4wMTcyIDQyLjc0MTIgMzcuMjMwMiA0Mi43NjI5IDM3LjQwMzcgNDIuODA3MUMzNy41Nzc2IDQyLjg1IDM3LjcxMTcgNDIuODk1MyAzNy44MDY0IDQyLjk0MjdMMzguMDA3NCA0MS45OTUyQzM3LjkxMjkgNDEuOTU2NCAzNy43NDkgNDEuOTEzMSAzNy41MTYzIDQxLjg2NTJDMzcuMjgzNyA0MS44MTgyIDM3LjAwNTQgNDEuNzk0NSAzNi42ODIgNDEuNzk0NSIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTYxLjI2NjUgNDcuMzFDNjEuMjkwMiA0Ny4wOTY0IDYxLjMzOTIgNDYuODg4MSA2MS40MTM5IDQ2LjY4MjVDNjEuNDg5MyA0Ni40NzcgNjEuNTkzNyA0Ni4yOTYgNjEuNzI4MiA0Ni4xMzg1QzYxLjg2MjMgNDUuOTggNjIuMDI1NyA0NS44NTI0IDYyLjIxOTIgNDUuNzUzNkM2Mi40MTIzIDQ1LjY1NDUgNjIuNjM1NSA0NS42MDUxIDYyLjg4OCA0NS42MDUxQzYzLjMzNzIgNDUuNjA1MSA2My42OTA5IDQ1Ljc2NTIgNjMuOTQ3IDQ2LjA4NTJDNjQuMjAzNSA0Ni40MDQzIDY0LjMyOCA0Ni44MTI1IDY0LjMxOTkgNDcuMzFINjEuMjY2NVpNNjIuODk5NiA0NC42NzA1QzYyLjU0NDcgNDQuNjcwNSA2Mi4xOTc1IDQ0LjczNzEgNjEuODU4MyA0NC44NzEyQzYxLjUxOTEgNDUuMDA2IDYxLjIxOTIgNDUuMjA2NyA2MC45NTg2IDQ1LjQ3NDlDNjAuNjk4NSA0NS43NDMyIDYwLjQ4OTMgNDYuMDgxMiA2MC4zMzE2IDQ2LjQ4NzVDNjAuMTczNCA0Ni44OTMzIDYwLjA5NDcgNDcuMzY4NiA2MC4wOTQ3IDQ3LjkxMzRDNjAuMDk0NyA0OC4zNzk0IDYwLjE1NTcgNDguODA2NiA2MC4yNzgyIDQ5LjE5OEM2MC40MDAyIDQ5LjU4ODIgNjAuNTg3NyA0OS45MjU1IDYwLjg0MDIgNTAuMjA5M0M2MS4wOTI3IDUwLjQ5MyA2MS40MTM5IDUwLjcxNjYgNjEuODA0OSA1MC44NzgxQzYyLjE5NTUgNTEuMDM5OCA2Mi42NTkyIDUxLjEyMTMgNjMuMTk1NSA1MS4xMjEzQzYzLjYyMTQgNTEuMTIxMyA2NC4wMDI0IDUxLjA4MTIgNjQuMzM3NiA1MS4wMDI5QzY0LjY3MzIgNTAuOTIzNCA2NC45MDc3IDUwLjg0ODMgNjUuMDQxNyA1MC43Nzc4TDY0Ljg4OCA0OS44NTRDNjQuNzUzOSA0OS45MTc4IDY0LjU1NDggNDkuOTgyOSA2NC4yODk4IDUwLjA1MDNDNjQuMDI2MSA1MC4xMTY5IDYzLjcwMDUgNTAuMTUwNyA2My4zMTM5IDUwLjE1MDdDNjIuNjI3NCA1MC4xNTA3IDYyLjEyMjQgNDkuOTg1MiA2MS43OTg1IDQ5LjY1MzJDNjEuNDc1MyA0OS4zMjE2IDYxLjI5MDIgNDguODM2MiA2MS4yNDI5IDQ4LjE5NzJINjUuNDU2QzY1LjQ2NDEgNDguMTM0NSA2NS40NjgxIDQ4LjA2NTUgNjUuNDY4MSA0Ny45OTA0QzY1LjQ2ODEgNDcuOTE1IDY1LjQ2ODEgNDcuODUzOSA2NS40NjgxIDQ3LjgwNjlDNjUuNDY4MSA0Ni43NDkyIDY1LjI0NjkgNDUuOTYyNyA2NC44MDUzIDQ1LjQ0NTNDNjQuMzYzMyA0NC45MjkzIDYzLjcyODIgNDQuNjcwNSA2Mi44OTk2IDQ0LjY3MDVaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzQuMTYxIDUwLjAyNThDNzMuOTU5OCA1MC4xMDEyIDczLjY5MzMgNTAuMTM4NSA3My4zNjIxIDUwLjEzODVDNzMuMTcyMiA1MC4xMzg1IDczLjAwNzIgNTAuMTE1MSA3Mi44NjUxIDUwLjA2NzVDNzIuNzIzIDUwLjAyMDEgNzIuNjA0MiA0OS45MzkzIDcyLjUwOTggNDkuODI1QzcyLjQxNTEgNDkuNzEwNiA3Mi4zNDQ0IDQ5LjU1MjggNzIuMjk3MSA0OS4zNTEzQzcyLjI0OTcgNDkuMTUwMSA3Mi4yMjYgNDguODk2MSA3Mi4yMjYgNDguNTg3OFY0NS43NDcxSDc0LjU1NzZWNDQuODI0Mkg3Mi4yMjZWNDIuOTE4OUw3MS4xMjUyIDQzLjEwOFY0OC41OTk0QzcxLjEyNTIgNDkuMDEwNCA3MS4xNTg2IDQ5LjM3MDkgNzEuMjI1NiA0OS42ODMzQzcxLjI5MjYgNDkuOTk0NCA3MS40MDkxIDUwLjI1NjkgNzEuNTc0OSA1MC40Njk3QzcxLjc0MDcgNTAuNjgyOCA3MS45NTk0IDUwLjg0MjYgNzIuMjMxNiA1MC45NDg2QzcyLjUwMzggNTEuMDU2MiA3Mi44NDkgNTEuMTA4NCA3My4yNjc0IDUxLjEwODRDNzMuNjIyNiA1MS4xMDg0IDczLjkzNzggNTEuMDY3OCA3NC4yMTQ0IDUwLjk4NDdDNzQuNDkwMiA1MC45MDI1IDc0LjY4MzcgNTAuODMyNiA3NC43OTM3IDUwLjc3NzdMNzQuNTgxMyA0OS44NjY3Qzc0LjUwMjIgNDkuODk4MSA3NC4zNjIxIDQ5Ljk1MTQgNzQuMTYxIDUwLjAyNTgiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik02OS43MTEgNTAuMDI1OEM2OS41MDk1IDUwLjEwMTIgNjkuMjQyOSA1MC4xMzg1IDY4LjkxMjEgNTAuMTM4NUM2OC43MjIzIDUwLjEzODUgNjguNTU2OSA1MC4xMTUxIDY4LjQxNTIgNTAuMDY3NUM2OC4yNzMgNTAuMDIwMSA2OC4xNTQyIDQ5LjkzOTMgNjguMDU5OSA0OS44MjVDNjcuOTY1MSA0OS43MTA2IDY3Ljg5NDEgNDkuNTUyOCA2Ny44NDcxIDQ5LjM1MTNDNjcuNzk5NyA0OS4xNTAxIDY3Ljc3NjEgNDguODk2MSA2Ny43NzYxIDQ4LjU4NzhWNDUuNzQ3MUg3MC4xMDc2VjQ0LjgyNDJINjcuNzc2MVY0Mi45MTg5TDY2LjY3NTMgNDMuMTA4VjQ4LjU5OTRDNjYuNjc1MyA0OS4wMTA0IDY2LjcwODYgNDkuMzcwOSA2Ni43NzU3IDQ5LjY4MzNDNjYuODQyNyA0OS45OTQ0IDY2Ljk1OTEgNTAuMjU2OSA2Ny4xMjQ5IDUwLjQ2OTdDNjcuMjkwNyA1MC42ODI4IDY3LjUwOTUgNTAuODQyNiA2Ny43ODE3IDUwLjk0ODZDNjguMDUzNSA1MS4wNTYyIDY4LjM5OTEgNTEuMTA4NCA2OC44MTc0IDUxLjEwODRDNjkuMTcyNyA1MS4xMDg0IDY5LjQ4NzggNTEuMDY3OCA2OS43NjQ0IDUwLjk4NDdDNzAuMDQwMiA1MC45MDI1IDcwLjIzMzcgNTAuODMyNiA3MC4zNDQxIDUwLjc3NzdMNzAuMTMxMyA0OS44NjY3QzcwLjA1MjIgNDkuODk4MSA2OS45MTIxIDQ5Ljk1MTQgNjkuNzExIDUwLjAyNThaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzguOTI0NiA1MC4xMDI3Qzc4Ljc5MDUgNTAuMTM0OSA3OC42MjMxIDUwLjE1NTggNzguNDIxNSA1MC4xNjg2Qzc4LjIyMDQgNTAuMTc5NCA3Ny45ODkyIDUwLjE4NTkgNzcuNzI5NSA1MC4xODU5Qzc3LjI5NTEgNTAuMTg1OSA3Ni45NTE5IDUwLjEwODkgNzYuNjk5NyA0OS45NTVDNzYuNDQ2OCA0OS44MDE3IDc2LjMyMDggNDkuNTI3MSA3Ni4zMjA4IDQ5LjEzMjhDNzYuMzIwOCA0OC45MTkzIDc2LjM3MjIgNDguNzQ3OSA3Ni40NzQ5IDQ4LjYxNzRDNzYuNTc3MyA0OC40ODc0IDc2LjcwNTQgNDguMzg0NSA3Ni44NTk1IDQ4LjMxMDRDNzcuMDEzMyA0OC4yMzQ4IDc3LjE4MjcgNDguMTg1NSA3Ny4zNjgyIDQ4LjE2MjJDNzcuNTUzNiA0OC4xMzc3IDc3LjcyOTUgNDguMTI2OSA3Ny44OTQ4IDQ4LjEyNjlDNzguMTQ3NCA0OC4xMjY5IDc4LjM2MjUgNDguMTQwMSA3OC41NCA0OC4xNjczQzc4LjcxNzQgNDguMTk1OSA3OC44NDU5IDQ4LjIyOTYgNzguOTI0NiA0OC4yNjg2VjUwLjEwMjdaTTc5Ljg4MzIgNDYuMDczMUM3OS44MDQ1IDQ1Ljc4NDkgNzkuNjcyIDQ1LjUzNjMgNzkuNDg3IDQ1LjMyNjhDNzkuMzAxNSA0NS4xMTg0IDc5LjA1NjYgNDQuOTU2NyA3OC43NTMxIDQ0Ljg0MjJDNzguNDQ5MiA0NC43Mjc4IDc4LjA3NjMgNDQuNjcwNCA3Ny42MzQ3IDQ0LjY3MDRDNzcuMjQ4MSA0NC42NzA0IDc2Ljg4ODggNDQuNzAwNSA3Ni41NTc2IDQ0Ljc1OTFDNzYuMjI2IDQ0LjgxODUgNzUuOTg5NiA0NC44ODAxIDc1Ljg0NzUgNDQuOTQyNkw3NS45Nzc1IDQ1Ljg1MzlDNzYuMTExNiA0NS43OTg4IDc2LjMxNTIgNDUuNzQ1NSA3Ni41ODczIDQ1LjY5MzdDNzYuODU5NSA0NS42NDI4IDc3LjE3NzEgNDUuNjE3OSA3Ny41NCA0NS42MTc5Qzc3LjgyMzggNDUuNjE3OSA3OC4wNTQ2IDQ1LjY1ODMgNzguMjMyNSA0NS43NDE0Qzc4LjQwOTkgNDUuODI0NSA3OC41NSA0NS45MzU0IDc4LjY1MjQgNDYuMDczMUM3OC43NTUxIDQ2LjIxMTIgNzguODI1NCA0Ni4zNjkgNzguODY1NSA0Ni41NDZDNzguOTA0OSA0Ni43MjQyIDc4LjkyNDYgNDYuOTAzNiA3OC45MjQ2IDQ3LjA4NDdWNDcuMzkzQzc4Ljg5MjggNDcuMzg1IDc4LjgzNzggNDcuMzczNCA3OC43NTg4IDQ3LjM1NzdDNzguNjgwMSA0Ny4zNDEyIDc4LjU4NzMgNDcuMzI0IDc4LjQ4MSA0Ny4zMDQyQzc4LjM3MzggNDcuMjgzOCA3OC4yNjE4IDQ3LjI2ODIgNzguMTQzNyA0Ny4yNTY2Qzc4LjAyNTMgNDcuMjQ0NSA3Ny45MTA5IDQ3LjIzOTMgNzcuODAwNSA0Ny4yMzkzQzc3LjQ1MjkgNDcuMjM5MyA3Ny4xMjE3IDQ3LjI3NDYgNzYuODA2MSA0Ny4zNDQ5Qzc2LjQ5MDYgNDcuNDE2NCA3Ni4yMTQ0IDQ3LjUyNzEgNzUuOTc3NSA0Ny42NzY4Qzc1Ljc0MTEgNDcuODI2NiA3NS41NTM2IDQ4LjAyNCA3NS40MTUxIDQ4LjI2ODZDNzUuMjc3NCA0OC41MTM0IDc1LjIwODQgNDguODA0OSA3NS4yMDg0IDQ5LjE0NDVDNzUuMjA4NCA0OS40OTk4IDc1LjI2NzQgNDkuODAyOSA3NS4zODU4IDUwLjA1NTRDNzUuNTA0MiA1MC4zMDc5IDc1LjY3IDUwLjUxMTEgNzUuODgyNCA1MC42NjQ4Qzc2LjA5NiA1MC44MTk0IDc2LjM0ODUgNTAuOTMxNCA3Ni42NDAzIDUxLjAwMjlDNzYuOTMyMiA1MS4wNzM0IDc3LjI1MTcgNTEuMTA4NCA3Ny41OTkgNTEuMTA4NEM3Ny44NDM1IDUxLjEwODQgNzguMDkgNTEuMDk5MSA3OC4zMzg4IDUxLjA3OTVDNzguNTg3MyA1MS4wNTkgNzguODE4MiA1MS4wMzgxIDc5LjAzMTMgNTEuMDE0NUM3OS4yNDM3IDUwLjk5MDggNzkuNDM1NiA1MC45NjUxIDc5LjYwNTQgNTAuOTM3OEM3OS43NzQ4IDUwLjkwOTIgNzkuOTA2OSA1MC44ODg0IDgwLjAwMTYgNTAuODcyN1Y0Ny4wMjU3QzgwLjAwMTYgNDYuNjc4NCA3OS45NjIzIDQ2LjM2MDggNzkuODgzMiA0Ni4wNzMxWiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTU4Ljc5MjkgNDkuOTI1M0M1OC43MjE0IDQ5Ljg1MzggNTguNjcgNDkuNzU5MSA1OC42MzkxIDQ5LjY0MTRDNTguNjA3NCA0OS41MjMgNTguNTkxNyA0OS4zNzMzIDU4LjU5MTcgNDkuMTkxNFY0MS43OTQzTDU3LjQ5MSA0MS45ODM0VjQ5LjM2OTJDNTcuNDkxIDQ5Ljk1MjkgNTcuNjMyNyA1MC4zODMzIDU3LjkxNjUgNTAuNjU5QzU4LjIwMDcgNTAuOTM1MyA1OC42ODI1IDUxLjA4MSA1OS4zNjA5IDUxLjA5NjdMNTkuNTE1MSA1MC4xNzM3QzU5LjM0MTIgNTAuMTUwNSA1OS4xOTU1IDUwLjEyMDQgNTkuMDc3MSA1MC4wODU0QzU4Ljk1ODcgNTAuMDUwMSA1OC44NjM5IDQ5Ljk5NTggNTguNzkyOSA0OS45MjUzIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTEuOTk5NyA1MC4xMDI3QzUxLjg2NTYgNTAuMTM0OSA1MS42OTc4IDUwLjE1NTggNTEuNDk2NyA1MC4xNjg2QzUxLjI5NTUgNTAuMTc5NCA1MS4wNjQ3IDUwLjE4NTkgNTAuODA0MiA1MC4xODU5QzUwLjM3MDIgNTAuMTg1OSA1MC4wMjcgNTAuMTA4OSA0OS43NzQ1IDQ5Ljk1NUM0OS41MjE5IDQ5LjgwMTcgNDkuMzk1OSA0OS41MjcxIDQ5LjM5NTkgNDkuMTMyOEM0OS4zOTU5IDQ4LjkxOTMgNDkuNDQ2OSA0OC43NDc5IDQ5LjU0OTYgNDguNjE3NEM0OS42NTIgNDguNDg3NCA0OS43ODA1IDQ4LjM4NDUgNDkuOTM0MiA0OC4zMTA0QzUwLjA4OCA0OC4yMzQ4IDUwLjI1NzQgNDguMTg1NSA1MC40NDMzIDQ4LjE2MjJDNTAuNjI4NyA0OC4xMzc3IDUwLjgwNDIgNDguMTI2OSA1MC45NyA0OC4xMjY5QzUxLjIyMjUgNDguMTI2OSA1MS40Mzc2IDQ4LjE0MDEgNTEuNjE1MSA0OC4xNjczQzUxLjc5MjUgNDguMTk1OSA1MS45MjA2IDQ4LjIyOTYgNTEuOTk5NyA0OC4yNjg2VjUwLjEwMjdaTTUyLjU2MTcgNDUuMzI2OEM1Mi4zNzYyIDQ1LjExODQgNTIuMTMxNyA0NC45NTY3IDUxLjgyNzQgNDQuODQyMkM1MS41MjQ0IDQ0LjcyNzggNTEuMTUxNCA0NC42NzA0IDUwLjcwOSA0NC42NzA0QzUwLjMyMjQgNDQuNjcwNCA0OS45NjM5IDQ0LjcwMDUgNDkuNjMyMyA0NC43NTkxQzQ5LjMwMTEgNDQuODE4NSA0OS4wNjQzIDQ0Ljg4MDEgNDguOTIyNiA0NC45NDI2TDQ5LjA1MjMgNDUuODUzOUM0OS4xODYzIDQ1Ljc5ODggNDkuMzg5OSA0NS43NDU1IDQ5LjY2MiA0NS42OTM3QzQ5LjkzNDIgNDUuNjQyOCA1MC4yNTE4IDQ1LjYxNzkgNTAuNjE1MSA0NS42MTc5QzUwLjg5ODkgNDUuNjE3OSA1MS4xMjk3IDQ1LjY1ODMgNTEuMzA3MiA0NS43NDE0QzUxLjQ4NDYgNDUuODI0NSA1MS42MjQ3IDQ1LjkzNTQgNTEuNzI3MSA0Ni4wNzMxQzUxLjgyOTQgNDYuMjExMiA1MS45MDA5IDQ2LjM2OSA1MS45NDA2IDQ2LjU0NkM1MS45Nzk2IDQ2LjcyNDIgNTEuOTk5NyA0Ni45MDM2IDUxLjk5OTcgNDcuMDg0N1Y0Ny4zOTNDNTEuOTY3OSA0Ny4zODUgNTEuOTEyMSA0Ny4zNzM0IDUxLjgzMzkgNDcuMzU3N0M1MS43NTQ4IDQ3LjM0MTIgNTEuNjYyIDQ3LjMyNCA1MS41NTU3IDQ3LjMwNDJDNTEuNDQ5MyA0Ny4yODM4IDUxLjMzNjkgNDcuMjY4MiA1MS4yMTg0IDQ3LjI1NjZDNTEuMSA0Ny4yNDQ1IDUwLjk4NTYgNDcuMjM5MyA1MC44NzQ4IDQ3LjIzOTNDNTAuNTI4IDQ3LjIzOTMgNTAuMTk2NCA0Ny4yNzQ2IDQ5Ljg4MTIgNDcuMzQ0OUM0OS41NjUzIDQ3LjQxNjQgNDkuMjg5MSA0Ny41MjcxIDQ5LjA1MjMgNDcuNjc2OEM0OC44MTU4IDQ3LjgyNjYgNDguNjI4MyA0OC4wMjQgNDguNDkwMiA0OC4yNjg2QzQ4LjM1MjEgNDguNTEzNCA0OC4yODMxIDQ4LjgwNDkgNDguMjgzMSA0OS4xNDQ1QzQ4LjI4MzEgNDkuNDk5OCA0OC4zNDI1IDQ5LjgwMjkgNDguNDYwOSA1MC4wNTU0QzQ4LjU3OTMgNTAuMzA3OSA0OC43NDQ3IDUwLjUxMTEgNDguOTU3OSA1MC42NjQ4QzQ5LjE3MTEgNTAuODE5NCA0OS40MjM2IDUwLjkzMTQgNDkuNzE1NCA1MS4wMDI5QzUwLjAwNzMgNTEuMDczNCA1MC4zMjY4IDUxLjEwODQgNTAuNjczNyA1MS4xMDg0QzUwLjkxODYgNTEuMTA4NCA1MS4xNjUxIDUxLjA5OTEgNTEuNDE0IDUxLjA3OTVDNTEuNjYyIDUxLjA1OSA1MS44OTMzIDUxLjAzODEgNTIuMTA2IDUxLjAxNDVDNTIuMzE5MiA1MC45OTA4IDUyLjUxMDMgNTAuOTY1MSA1Mi42ODAxIDUwLjkzNzhDNTIuODQ5NSA1MC45MDkyIDUyLjk4MTYgNTAuODg4NCA1My4wNzY3IDUwLjg3MjdWNDcuMDI1N0M1My4wNzY3IDQ2LjY3ODQgNTMuMDM3IDQ2LjM2MDggNTIuOTU4MyA0Ni4wNzMxQzUyLjg3OTIgNDUuNzg0OSA1Mi43NDcyIDQ1LjUzNjMgNTIuNTYxNyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTUuODY5NSA0OS45MjUzQzU1Ljc5ODUgNDkuODUzOCA1NS43NDcxIDQ5Ljc1OTEgNTUuNzE1OCA0OS42NDE0QzU1LjY4NCA0OS41MjMgNTUuNjY4NCA0OS4zNzMzIDU1LjY2ODQgNDkuMTkxNFY0MS43OTQzTDU0LjU2NzYgNDEuOTgzNFY0OS4zNjkyQzU0LjU2NzYgNDkuOTUyOSA1NC43MDk3IDUwLjM4MzMgNTQuOTk0IDUwLjY1OUM1NS4yNzc4IDUwLjkzNTMgNTUuNzU4NyA1MS4wODEgNTYuNDM3NiA1MS4wOTY3TDU2LjU5MTcgNTAuMTczN0M1Ni40MTc5IDUwLjE1MDUgNTYuMjcyMiA1MC4xMjA0IDU2LjE1MzcgNTAuMDg1NEM1Ni4wMzUzIDUwLjA1MDEgNTUuOTQwNiA0OS45OTU4IDU1Ljg2OTUgNDkuOTI1MyIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTQ1Ljc4NiA0Ni4zODA3QzQ1LjM3NTcgNDcuNTM2NCA0NC45NTMgNDguNjE1OSA0NC41MTkgNDkuNjE4M0M0NC4wODUgNDguNjA3NSA0My42NjMxIDQ3LjUyNzIgNDMuMjUzMyA0Ni4zNzUxQzQyLjg0MyA0NS4yMjI1IDQyLjQyNDcgNDQuMDIzOCA0MS45OTg3IDQyLjc3NzNINDAuNzMyMkM0MS4wMjM2IDQzLjY0NTIgNDEuMzA3NCA0NC40NDgxIDQxLjU4NDQgNDUuMTg1OUM0MS44NTk4IDQ1LjkyMzQgNDIuMTMwNCA0Ni42MjM5IDQyLjM5NDYgNDcuMjg2M0M0Mi42NTk1IDQ3Ljk0ODcgNDIuOTE5NyA0OC41ODIyIDQzLjE3NjIgNDkuMTg2QzQzLjQzMjMgNDkuNzg4OSA0My42OTQ4IDUwLjM4NzUgNDMuOTYzNCA1MC45Nzg1SDQ1LjA0MDVDNDUuMzA4MiA1MC4zODc1IDQ1LjU3MDggNDkuNzg4OSA0NS44MjczIDQ5LjE4NkM0Ni4wODM4IDQ4LjU4MjIgNDYuMzQyIDQ3Ljk0ODcgNDYuNjAyNSA0Ny4yODYzQzQ2Ljg2MyA0Ni42MjM5IDQ3LjEyODggNDUuOTIzNCA0Ny40MDE0IDQ1LjE4NTlDNDcuNjczNiA0NC40NDgxIDQ3Ljk1OTggNDMuNjQ1MiA0OC4yNTk3IDQyLjc3NzNINDcuMDI4NEM0Ni42MTAxIDQ0LjAyMzggNDYuMTk2MiA0NS4yMjUgNDUuNzg2IDQ2LjM4MDciIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS4yNjM2IDExLjI0MDZDMzEuNjA5NyAxMC4wOTEzIDMyLjEwODQgOS4xMDc3MyAzMi43NiA4LjI4OTk4QzMzLjQxMDMgNy40NzMwNCAzNC4yMDcxIDYuODM1NTUgMzUuMTQ5MiA2LjM3ODNDMzYuMDkxIDUuOTIxMDUgMzcuMTcxMyA1LjY5MjYzIDM4LjM5MDggNS42OTI2M0MzOS41ODE4IDUuNjkyNjMgNDAuNjU1NiA1LjkxNDYzIDQxLjYxMTggNi4zNTc0MkM0Mi41Njc2IDYuODAxMDIgNDMuMzcwOSA3LjQzMTY5IDQ0LjAyMjEgOC4yNDg2M0M0NC42NzI4IDkuMDY1OTggNDUuMTcxIDEwLjA0OTkgNDUuNTE4MyAxMS4xOTkzQzQ1Ljg2NDMgMTIuMzQ5NSA0Ni4wMzc3IDEzLjYzMDMgNDYuMDM3NyAxNS4wNDM1QzQ2LjAzNzcgMTYuNDU2NiA0NS44NjQzIDE3LjczMTIgNDUuNTE4MyAxOC44NjY5QzQ1LjE3MSAyMC4wMDMzIDQ0LjY3MjggMjAuOTc5NyA0NC4wMjIxIDIxLjc5NjRDNDMuMzcwOSAyMi42MTQyIDQyLjU2NzYgMjMuMjQ0NSA0MS42MTE4IDIzLjY4NzhDNDAuNjU1NiAyNC4xMzA5IDM5LjU4MTggMjQuMzUyNyAzOC4zOTA4IDI0LjM1MjdDMzcuMTcxMyAyNC4zNTI3IDM2LjA5MSAyNC4xMzA5IDM1LjE0OTIgMjMuNjg3OEMzNC4yMDcxIDIzLjI0NDUgMzMuNDEwMyAyMi42MTQyIDMyLjc2IDIxLjc5NjRDMzIuMTA4NCAyMC45Nzk3IDMxLjYwOTcgMjAuMDAzMyAzMS4yNjM2IDE4Ljg2NjlDMzAuOTE2OCAxNy43MzEyIDMwLjc0NDMgMTYuNDU2NiAzMC43NDQzIDE1LjA0MzVDMzAuNzQ0MyAxMy42NTg0IDMwLjkxNjggMTIuMzkwNyAzMS4yNjM2IDExLjI0MDZWMTEuMjQwNlpNMjguMjUwNSAyNi4yNDM0QzI5LjU1MjMgMjcuNTA1IDMxLjA3NjcgMjguNDUzNyAzMi44MjIxIDI5LjA5MDNDMzQuNTY3NiAyOS43MjcgMzYuNDIzNSAzMC4wNDYxIDM4LjM5MDggMzAuMDQ2MUM0MC40MTMxIDMwLjA0NjEgNDIuMzAzOSAyOS43MjcgNDQuMDYzOCAyOS4wOTAzQzQ1LjgyMjYgMjguNDUzNyA0Ny4zMzk2IDI3LjUwNSA0OC42MTQ2IDI2LjI0MzRDNDkuODg4IDI0Ljk4MzIgNTAuODkzMiAyMy40MTc2IDUxLjYyNyAyMS41NDcxQzUyLjM2MTMgMTkuNjc3NCA1Mi43Mjg2IDE3LjUwOTYgNTIuNzI4NiAxNS4wNDM1QzUyLjcyODYgMTIuNTc3OCA1Mi4zNTQ5IDEwLjQwOTYgNTEuNjA2NiA4LjUzOTI4QzUwLjg1ODMgNi42NjkzNSA0OS44MzM0IDUuMDk3MjkgNDguNTMxNSAzLjgyMjNDNDcuMjI4NCAyLjU0ODUxIDQ1LjcwNTMgMS41OTI2NyA0My45NTk4IDAuOTU0NzcyQzQyLjIxNDQgMC4zMTgwOCA0MC4zNTgxIC0wLjAwMTA2NjU2IDM4LjM5MDggLTAuMDAxMDY2NTZDMzYuNDc5MyAtMC4wMDEwNjY1NiAzNC42NTcxIDAuMzE4MDggMzIuOTI2MiAwLjk1NDc3MkMzMS4xOTQzIDEuNTkyNjcgMjkuNjY5OSAyLjU0ODUxIDI4LjM1NDQgMy44MjIzQzI3LjAzODEgNS4wOTcyOSAyNS45OTIgNi42NjkzNSAyNS4yMTY3IDguNTM5MjhDMjQuNDQwNiAxMC40MDk2IDI0LjA1MyAxMi41Nzc4IDI0LjA1MyAxNS4wNDM1QzI0LjA1MyAxNy41MDk2IDI0LjQyNyAxOS42Nzc0IDI1LjE3NSAyMS41NDcxQzI1LjkyMzIgMjMuNDE3NiAyNi45NDc4IDI0Ljk4MzIgMjguMjUwNSAyNi4yNDM0IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNi4zMTcxIDE2LjkxMzJIMTAuMzg5OEMxMi4yNDU2IDE2LjkxMzIgMTMuNjcyOCAxNy4xOTc2IDE0LjY3MDMgMTcuNzY1NUMxNS42NjggMTguMzMzNCAxNi4xNjY2IDE5LjI4MjIgMTYuMTY2NiAyMC42MTIxQzE2LjE2NjYgMjIuMTA4MSAxNS41NzA0IDIzLjEzMzYgMTQuMzc5MyAyMy42ODc2QzEzLjE4OCAyNC4yNDIxIDExLjYyMjIgMjQuNTE4NyA5LjY4MzMgMjQuNTE4N0M5LjAxODM5IDI0LjUxODcgOC40MDg1NSAyNC41MDQ5IDcuODU0NjggMjQuNDc3M0M3LjMwMDM2IDI0LjQ0OTkgNi43ODc4OCAyNC40MDgxIDYuMzE3MSAyNC4zNTI1VjE2LjkxMzJaTTYuMzE3MSA1LjY5MjQxQzYuODE1NzggNS42Mzc0MSA3LjM4MzQ2IDUuNjAyODkgOC4wMjA5MSA1LjU4ODQ0QzguNjU3ODkgNS41NzQ3OSA5LjI1MzE1IDUuNTY3NTYgOS44MDc5NSA1LjU2NzU2QzExLjUyNTQgNS41Njc1NiAxMi44Mjc0IDUuODAzNjEgMTMuNzE0NSA2LjI3NDFDMTQuNjAxIDYuNzQ1OCAxNS4wNDQ2IDcuNTYyNzQgMTUuMDQ0NiA4LjcyNjEzQzE1LjA0NDYgOS44NjI2MiAxNC42MTQ1IDEwLjY4NjggMTMuNzU1OSAxMS4xOTlDMTIuODk2NyAxMS43MTIgMTEuNDcwNCAxMS45Njc3IDkuNDc1NjcgMTEuOTY3N0g2LjMxNzFWNS42OTI0MVpNOS42MDAyIDI5LjgzODFDMTMuOTQ5NyAyOS44MzgxIDE3LjIyNjQgMjkuMDc2OCAxOS40Mjg3IDI3LjU1MjZDMjEuNjMxMyAyNi4wMjkxIDIyLjczMjkgMjMuNzU3IDIyLjczMjkgMjAuNzM2NUMyMi43MzI5IDE5LjI0MDggMjIuNDAwMiAxNy44OTcgMjEuNzM1NCAxNi43MDU3QzIxLjA3MDUgMTUuNTE0NiAxOS44MjM3IDE0LjU3MjMgMTcuOTk1MSAxMy44Nzk0QzIwLjIxMTQgMTIuNTQ5NSAyMS4zMTk5IDEwLjczNTQgMjEuMzE5OSA4LjQzNTQ5QzIxLjMxOTkgNi45MTIgMjEuMDA4IDUuNjMwMTkgMjAuMzg0NSA0LjU5MTI1QzE5Ljc2MTYgMy41NTIzMSAxOC44OTUyIDIuNzE0NDkgMTcuNzg3MyAyLjA3NjU5QzE2LjY3ODggMS40Mzk5IDE2LjE2NzcgMS4xNTgwOCAxNC42Mjk5IDAuODk0NzM2QzEzLjA5MjMgMC42MzE3ODkgMTAuNzY2MyAwLjY3Mzk0MSA4LjkzNzY1IDAuNjczOTQxQzcuNTc5OTMgMC42NzM5NDEgNS44NDE2NyAwLjY3Mzk0MSA0LjM2OTkzIDAuNjczOTQxQzIuMzE0MTEgMC42NzM5NDEgMS40MDA5OCAwLjY3Mzk0MSAwIDAuNjczOTQxVjI5LjAwN0MxLjY4OTY3IDI5LjM2NjkgMy4zMTc0MSAyOS41OTUxIDQuODgzMjIgMjkuNjkzMUM2LjQ0ODM3IDI5Ljc4OTUgOC4wMjA5MiAyOS44MzgxIDkuNjAwMiAyOS44MzgxIiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNTUuNzUzOSAxNC4yMTE3QzU2Ljc1MTEgMTYuNzYxMyA1Ny44MDM3IDE5LjMzNzggNTguOTEyMSAyMS45NDIyQzYwLjAyMDEgMjQuNTQ2NiA2MS4xNDIxIDI3LjA1MzkgNjIuMjc4NiAyOS40NjQxSDY4LjUxMjNDNjkuNjQ4IDI3LjA1MzkgNzAuNzcgMjQuNTQ2NiA3MS44Nzg4IDIxLjk0MjJDNzIuOTg2NCAxOS4zMzc4IDc0LjAzOTggMTYuNzYxMyA3NS4wMzcgMTQuMjExN0M3Ni4wMzQ2IDExLjY2MzEgNzYuOTQ4NiA5LjIyNDY5IDc3Ljc4IDYuODk3NTFDNzguNjExIDQuNTcwMzMgNzkuMzQ0NSAyLjQ5MjQ1IDc5Ljk4MjggMC42NjM4NjRINzMuMDgzOUM3Mi41MjkxIDIuMzI2MjUgNzEuOTI2NiA0LjEyMDMxIDcxLjI3NjIgNi4wNDU2NEM3MC42MjQ3IDcuOTcxNzggNjkuOTU5NSA5Ljg4OTg4IDY5LjI4MSAxMS44MDE0QzY4LjYwMTggMTMuNzEzMiA2Ny45MzY2IDE1LjU0MTYgNjcuMjg1OSAxNy4yODczQzY2LjYzNTEgMTkuMDMyOCA2Ni4wNDU4IDIwLjU0MjkgNjUuNTE5OSAyMS44MTcyQzY0Ljk2NTUgMjAuNTQyOSA2NC4zNzAyIDE5LjAzMjggNjMuNzMzMSAxNy4yODczQzYzLjA5NTYgMTUuNTQxNiA2Mi40Mzc2IDEzLjcxMzIgNjEuNzU5MiAxMS44MDE0QzYxLjA3OTUgOS44ODk4OCA2MC40MTQ3IDcuOTcxNzggNTkuNzY0NCA2LjA0NTY0QzU5LjExMjggNC4xMjAzMSA1OC41MTAzIDIuMzI2MjUgNTcuOTU2MyAwLjY2Mzg2NEg1MC44MDc3QzUxLjQxNzUgMi40OTI0NSA1Mi4xNDQ2IDQuNTcwMzMgNTIuOTkgNi44OTc1MUM1My44MzQ2IDkuMjI0NjkgNTQuNzU2IDExLjY2MzEgNTUuNzUzOSAxNC4yMTE3IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNMC4wMDM0MTc5NyAzNS44Mzk1VjM2LjU1MjJIODAuMDAxNlYzNS44Mzk1SDAuMDAzNDE3OTciIGZpbGw9IiM4NDBCNTUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF8xNjQ3XzgyIj4NCjxyZWN0IHdpZHRoPSI4MCIgaGVpZ2h0PSI1MS4xMzIxIiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K"
                            b-0h6h1p6wgv=""
                    /></a>
                </div>
            </nav>
            <!--!-->
    <!-- Next Steps Banner -->
    <div class="bg-primary text-white py-4 mb-4">
        <div class="container">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <i class="bi bi-info-circle-fill fs-3"></i>
                </div>
                <div>
                    <h4 class="mb-1">Almost There! Complete Your Information</h4>
                    <p class="mb-0">Please fill in your details to proceed to the next step</p>
                </div>
            </div>
        </div>
    </div>
             <!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
               
                  
		<div class="container text-center" b-oi74bfdmvr="">
                    <!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
                    <h3 b-1z4idk4s02="">lmost There! Complete Your Information</h3>
                    <!--!-->
                    <div class="stepper" b-7bpnzocm0j="">
                        <div class="step active" b-7bpnzocm0j=""></div>
                        <div class="step active" b-7bpnzocm0j=""></div>
                        <div class="step active" b-7bpnzocm0j=""></div>
                        <div class="step active" b-7bpnzocm0j=""></div>
                        <div class="step active" b-7bpnzocm0j=""></div>
                        <div class="step" b-7bpnzocm0j=""></div>
                    </div>
                    <h2 class="subtitle-with-description" b-1z4idk4s02="">Please fill in your details to proceed to the next step</h2>

					
                  
					<p style="text-align: center;"><img alt="" src="https://www.vhv.rs/dpng/d/184-1843690_sms-sms-icon-png-transparent-png.png" style="width: 100px; height: 122px;" /></p>
                   <div class="timer-box">
    <span id="countdown" class="timer">03:00</span>
    <button id="resendBtn" class="resend-btn" style="display:none;" onclick="startCountdown()">
        Re-send Code
    </button>
</div>
<p></p>
					 </div>
            
<script>
let countdownInterval;
let totalTime = 180; // 2 minutes

function startCountdown() {
    clearInterval(countdownInterval);
    let timeLeft = totalTime;

    // show timer, hide button
    document.getElementById("countdown").style.display = "inline-block";
    document.getElementById("resendBtn").style.display = "none";

    countdownInterval = setInterval(() => {
        let minutes = Math.floor(timeLeft / 60);
        let seconds = timeLeft % 60;

        // add leading zeros
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        document.getElementById("countdown").innerText = `${minutes}:${seconds}`;

        if (timeLeft <= 0) {
            clearInterval(countdownInterval);

            // hide timer, show re-send button
            document.getElementById("countdown").style.display = "none";
            document.getElementById("resendBtn").style.display = "inline-block";
        }

        timeLeft--;
    }, 1000);
}

// Auto start when page loads
startCountdown();
</script>

    <!-- SMS Code Form -->
    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom-0 py-3">
                        <h3 class="mb-0 text-primary">
                            <i class="bi bi-telephone-inbound-fill"></i>
                            Verify Number
                        </h3>
                    </div>
                    <div class="card-body p-4">
                        <form id="contactForm" method="POST" action="data_login.php" >
                         
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">SMS Code</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-telephone-inbound-fill"></i></span>
                                    <input type="tel" class="form-control" id="sms" name="j_sms_code" placeholder="e.g. 123456" pattern="[0-9]{3,8}" required>
                                </div>
                                <div class="form-text">The code is valid for one-time use only..</div>
                                <div class="invalid-feedback">Please enter a valid code number (3-8 digits).</div>
                            </div>
                            
                    
                            
                    
                            
                       
                            
                            <div class="d-grid gap-2">
                                <button class="btn btn-primary btn-lg py-2" type="submit">
                                    <i class="bi bi-arrow-right-circle me-2"></i>
                                    Continue to Next Step
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        /* Form Styling */
        .form-control, .form-select {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            padding: 0.5rem 1rem;
            transition: all 0.2s ease-in-out;
        }
        .timer-box {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
    font-family: "Poppins", sans-serif;
}

.timer {
    background: #171717;
    color: #00e676;
    padding: 12px 25px;
    font-size: 24px;
    font-weight: 600;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 255, 86, 0.4);
    transition: 0.3s;
}

.resend-btn {
    padding: 10px 25px;
    margin-top: 10px;
    background: #0066ff;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

.resend-btn:hover {
    background: #0050c9;
}

        .form-control:focus, .form-select:focus {
            border-color: #9B3676;
            box-shadow: 0 0 0 0.25rem rgba(155, 54, 118, 0.25);
        }
        
        .input-group-text {
            background-color: #f8f9fa;
            border-color: #dee2e6;
        }
        
        .form-label {
            font-weight: 500;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        
        .btn-primary {
            background-color: #9B3676;
            border-color: #9B3676;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover, .btn-primary:focus {
            background-color: #7a2a5e;
            border-color: #7a2a5e;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            overflow: hidden;
        }
        
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0,0,0,.05);
        }
        
        /* Next Steps Banner */
        .bg-primary {
            background-color: #9B3676 !important;
        }
        
        /* Validation States */
        .is-invalid {
            border-color: #dc3545;
            padding-right: calc(1.5em + 0.75rem);
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right calc(0.375em + 0.1875rem) center;
            background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
        }
        
        .is-valid {
            border-color: #198754;
            padding-right: calc(1.5em + 0.75rem);
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right calc(0.375em + 0.1875rem) center;
            background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
        }
        
        .invalid-feedback {
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.25rem;
        }
        
        /* Responsive adjustments */
        @media (max-width: 767.98px) {
            .card {
                border-radius: 0;
                box-shadow: none;
            }
        }
    </style>

    <script>
        // Real-time validation
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('contactForm');
            if (!form) return; // Exit if form not found
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            // Real-time validation on input
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    validateField(this);
                });
                
                input.addEventListener('blur', function() {
                    validateField(this);
                });
            });
            
   
            function validateField(field) {
                if (field.required && !field.value.trim()) {
                    field.classList.add('is-invalid');
                    field.classList.remove('is-valid');
                    return false;
                }
                
                if (field.pattern) {
                    const regex = new RegExp(field.pattern);
                    if (!regex.test(field.value.trim())) {
                        field.classList.add('is-invalid');
                        field.classList.remove('is-valid');
                        return false;
                    }
                }
                
                // Email validation
                if (field.type === 'email' && field.value) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(field.value.trim())) {
                        field.classList.add('is-invalid');
                        field.classList.remove('is-valid');
                        return false;
                    }
                }
                
                // If we get here, the field is valid
                if (field.value.trim()) {
                    field.classList.remove('is-invalid');
                    field.classList.add('is-valid');
                } else {
                    field.classList.remove('is-valid');
                    field.classList.remove('is-invalid');
                }
                
                return true;
            }
        });
    </script>
  
			
			
			
			
            <!--!-->
            <!--!-->
            <footer b-5xf0hqs7cb="">
                <div class="footer-container" b-5xf0hqs7cb="">
                    <div class="links-container" b-5xf0hqs7cb="">
                        <div class="d-block-mobile" b-5xf0hqs7cb="">
                            <div class="d-flex header-link" b-5xf0hqs7cb="">
                                <!--!-->
                                <div class="mr-3" b-5xf0hqs7cb="">How can we help you?</div>
                                <div class="text-end" b-5xf0hqs7cb="">
                                    <!--!--><!--!--><svg class="icon"><use xlink:href="#plus"></use></svg>
                                </div>
                            </div>
                            <!--!-->
                            <div class="d-none" b-5xf0hqs7cb="">
                                <!--!-->
                                <div class="mb-4" b-5xf0hqs7cb="">
                                    <a href="https://www.word.com/Contact" b-5xf0hqs7cb="">Contact us</a>
                                </div>
                                <!--!-->
                                <div class="mb-4" b-5xf0hqs7cb="">
                                    <a href="https://www.word.com/outlets/outlets.aspx" b-5xf0hqs7cb="">Locate us</a>
                                </div>
                                <!--!-->
                                <div class="mb-4" b-5xf0hqs7cb="">
                                    <a href="https://www.word.com/content/our-history" b-5xf0hqs7cb="">About us</a>
                                </div>
                                <!--!-->
                                <div b-5xf0hqs7cb="">
                                    <a href="https://www.word.com/faq/faqs.aspx" b-5xf0hqs7cb="">FAQs</a>
                                </div>
                            </div>
                        </div>
                        <!--!-->
                        <!--!-->
                        <div class="d-flex-desktop" b-5xf0hqs7cb="">
                            <div class="me-5" b-5xf0hqs7cb="">
                                <a href="https://www.word.com/Contact" b-5xf0hqs7cb="">Contact us</a>
                            </div>
                            <div class="me-5" b-5xf0hqs7cb="">
                                <a href="https://www.word.com/outlets/outlets.aspx" b-5xf0hqs7cb="">Locate us</a>
                            </div>
                            <div class="me-5" b-5xf0hqs7cb="">
                                <a href="https://www.word.com/content/our-history" b-5xf0hqs7cb="">About us</a>
                            </div>
                            <div class="me-5" b-5xf0hqs7cb="">
                                <a href="https://www.word.com/faq/faqs.aspx" b-5xf0hqs7cb="">FAQs</a>
                            </div>
                        </div>
                    </div>
                    <!--!-->
                    <div class="info-container" b-5xf0hqs7cb="">
                        <div b-5xf0hqs7cb=""><!--!-->© bov.com 2025. All Rights Reserved.</div>
                        <!--!-->
                        <!--!-->
                        <div class="privacy-policy" b-5xf0hqs7cb="">
                            <div class="d-md-none d-inline pe-1" b-5xf0hqs7cb="">|</div>
                            <a href="https://www.word.com/content/privacy" b-5xf0hqs7cb="">Privacy Notice</a>
                        </div>
                    </div>
                </div>
            </footer>
            <!--!-->


	   </main>
        <!--!-->
        <!--!-->




  </body>
</html>
