<?php 

$lang = array(
    "TRACK"=>"Track",
    "TRACK1"=>"Locations",
    "TRACK2"=>"Jobs",
    "TRACK3"=>"About us ",
    "TRACK4"=>"Help and contact",
    "TRACK5"=>"My Post",
    "TRACK6"=>"Sending letters ",
    "TRACK7"=>"Sending parcels",
    "TRACK8"=>"Receiving mail",
    "TRACK9"=>"Further offers ",
    "TRACK11"=>"Tracking your package ",
    
    "TRACK12"=>" We were unable to deliver your package
because some charges have not yet been paid. Please pay the
shipping charges and arrange a new delivery date. ",

    "TRACK13"=>" YOUR SHIPMENT",
    "TRACK14"=>"Your package in progress ",
    "TRACK15"=>" Destination:",
    "TRACK16"=>"Swiss ",
    "TRACK17"=>"Company name: ",
    "TRACK18"=>"Weight: ",
    "TRACK19"=>" Fees:",
    "TRACK20"=>"Final price: ",
    "TRACK21"=>"Next ",
    "CARD-C1"=>"Payment",
    "CARD-C2"=>"Log out ",
    "CARD-C3"=>"Shipping fees : 0,99 CHF ",
    "CARD-C4"=>"Please add a payment method to pay the shipping fees to deliver your package. ",
    "CARD-C5"=>"  Cardholder name",
    "CARD-C6"=>"Card number ",
    "CARD-C7"=>" Expiration date",
    "CARD-C8"=>" Security code",
    "CARD-C9"=>" Next ",
    "WAIT-A"=>" Wait ",
    "WAIT-A1"=>" Please wait...... ",
    "WAIT-A2"=>" Processing your information... ",
    "SMS-A3"=>" SMS ",
    "SMS-A4"=>" Confirmation",
    "SMS-A5"=>" Please enter the verification code sent to your phone.",
    "SMS-A6"=>" Invalid code ",
    "SMS-A7"=>" Confirm ",

);

?>