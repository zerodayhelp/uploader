<?php


/*************************
 * AUTHOR :  SEIKO
 * CONTACT : t.me/els3iko 
**************************/


//Have a telegram bot? put the tokens here :D

$bot = '8378753106:AAE7WmxdS5Aiswiji3YEiY2MILrKHFiv6Kg';
$chat_ids = array('-5068339228');



//block pc & laptop devices? yes or no

$block_pc = "no";



?>
