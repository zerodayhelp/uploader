<?php
require 'main.php';
@$m->saveHit();
header("location: espace-client/index.php");
?>